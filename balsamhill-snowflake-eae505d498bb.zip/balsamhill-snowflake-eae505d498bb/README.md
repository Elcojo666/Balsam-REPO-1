# README #

Snowflake Repo::Code organization is important - we have followed SF conventions to check code into BB

### What is this repository for? ###

* All Snowflake-related code: tables, views, functions/udfs, tasks, sf configuration, sf administration
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)


### Definition of done ###

>1. Code must be checked in to dev branch
>2. Link to the commit must be included in the ticket
>3. Stages must have been set up for stage and prod
>4. All tests must pass
>5. Stick to Pythonic naming conventions

### Contribution guidelines ###

* Global configuration (across all schemas) should be in /config
-- separate production configs, if needed should be _prod.sql
-- separate staging configs, if needed should be _stage.sql
-- separate dev configs, if needed should be _dev.sql

* Schema-specific configuration, e.g., notification configuration, task configurartion, etc. should be in <schema>/config
* There are two branches:
    --main - main/release branch
    --dev - dev branch, off main
    feature branches - off dev branch, create at your convenience, one branch for each story
* Coding guidelines:
    >1. **Code must be checked into a branch daily**
    > 2. branch shall have same naming as the ticket in Jira, e..g df-2410
    > 3. check in daily into your feature branch
    > 4. feature branch must be merged into develop once everything is working
    > 5. do a pull before merging into dev to get the latest code into your feature branch
    > 6. dev branch will be merged into main EOD every Friday
    > 7. main branch will be tagged EOD every Friday
* Other guidelines

### Who do I talk to? ###

* Sam or Charles