USE DATABASE dev;

CREATE OR REPLACE TABLE master.dim_payment_type (
    pk_payment_typeid SMALLINT NOT NULL,
    payment_type_name VARCHAR(50) NOT NULL,
    PRIMARY KEY (pk_payment_typeid)
);
