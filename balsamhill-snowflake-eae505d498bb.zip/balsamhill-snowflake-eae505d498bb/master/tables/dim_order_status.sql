USE DATABASE dev;

CREATE OR REPLACE TABLE master.dim_order_status (
    pk_order_statusid       SMALLINT        NOT NULL,
    order_status_name       VARCHAR(50)     NOT NULL,
    oms_order_status_code   VARCHAR(100),
    PRIMARY KEY (pk_order_statusid)
);