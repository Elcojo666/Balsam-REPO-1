USE DATABASE dev;

CREATE OR REPLACE TABLE master.dim_payment_method (
    pk_payment_method_id SMALLINT NOT NULL,
    payment_method_name VARCHAR(50) NOT NULL,
    PRIMARY KEY (pk_payment_method_id)
);
