USE DATABASE dev;

CREATE OR REPLACE TABLE master.dim_currency (
    pk_currencyid INT NOT NULL,
    currency_code VARCHAR(50) NOT NULL,
    currency_desc VARCHAR(50) NOT NULL,
    currency_symbol VARCHAR(50) NOT NULL,
    active_flag INT NOT NULL,
    inserted_date TIMESTAMP_NTZ NOT NULL,
    last_updated_date TIMESTAMP_NTZ NOT NULL,
    PRIMARY KEY (pk_currencyid)
);