USE DATABASE dev;

CREATE OR REPLACE TABLE master.dim_shipping_method (
    pk_shipping_methodid SMALLINT NOT NULL,
    shipping_method_name VARCHAR(50) NOT NULL,
    isactive BOOLEAN NOT NULL,
    PRIMARY KEY (pk_shipping_methodid)
);
