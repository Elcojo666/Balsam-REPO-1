USE DATABASE dev;

CREATE OR REPLACE TABLE master.dim_order_type (
    pk_order_typeid SMALLINT NOT NULL,
    order_type_name VARCHAR(50) NOT NULL,
    PRIMARY KEY (pk_order_typeid)
);
