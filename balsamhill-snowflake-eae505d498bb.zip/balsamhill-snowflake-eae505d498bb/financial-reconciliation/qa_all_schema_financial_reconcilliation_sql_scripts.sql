
USE DATABASE BALSAM_EDW_QA;




create or replace TABLE RAW.RAW_FINANCIAL_RECONCILIATION (
	DOCUMENT_TYPE VARCHAR(20),
	ENTERPRISE_CODE VARCHAR(16777216),
	ORDER_HEADER_KEY VARCHAR(16777216),
    RETURN_ORDER_HEADER_KEY VARCHAR(16777216),
	ORDER_NO VARCHAR(16777216),
    RETURN_ORDER_NO VARCHAR(16777216),
	MODIFYTS VARCHAR(16777216),
	EVENT_TYPE VARCHAR(16777216),
	GRAND_TOTAL VARCHAR(16777216),
	PRIME_LINE_NO VARCHAR(16777216),
	SUB_LINE_NO VARCHAR(16777216),
    ORDER_LINE_KEY VARCHAR(16777216),
    ORDERED_QUANTITY VARCHAR(16777216),
	LINE_TOTAL VARCHAR(16777216),
	UNIT_PRICE VARCHAR(16777216),
	LINE_TAX_CHARGE_CATEGORY VARCHAR(16777216),
	LINE_TAX_CHARGE_NAME VARCHAR(16777216),
	LINE_TAX VARCHAR(16777216),
	LINE_TAX_NAME VARCHAR(16777216),
	LINE_CHARGE_AMOUNT VARCHAR(16777216),
	LINE_CHARGE_CATEGORY VARCHAR(16777216),
	LINE_CHARGE_NAME VARCHAR(16777216),
	HEADER_CHARGE_AMOUNT VARCHAR(16777216),
	HEADER_CHARGE_CATEGORY VARCHAR(16777216),
	HEADER_CHARGE_NAME VARCHAR(16777216),
	HEADER_TAX_CHARGE_CATEGORY VARCHAR(16777216),
	HEADER_TAX_CHARGE_NAME VARCHAR(16777216),
	HEADER_TAX VARCHAR(16777216),
	HEADER_TAX_NAME VARCHAR(16777216),
    SKU VARCHAR(16777216),
	IMPORTED_DATE TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP(),
	TXN_ID VARCHAR(16777216) DEFAULT UUID_STRING(),
	PROCESSING_STATUS VARCHAR(16777216) DEFAULT 'Pending',
	PROCESSING_ERRORTYPE VARCHAR(16777216) DEFAULT '',
	PROCESSING_COMMENT VARCHAR(16777216) DEFAULT ''
);


create or replace TABLE TRANSFORMED.STG_FINANCIAL_RECONCILIATION (
	DOCUMENT_TYPE VARCHAR(16777216),
	ENTERPRISE_CODE VARCHAR(16777216),
	ORDER_HEADER_KEY VARCHAR(16777216),
	ORDER_NO VARCHAR(16777216),
	MODIFYTS VARCHAR(16777216),
	EVENT_TYPE VARCHAR(16777216),
	PRIME_LINE_NO VARCHAR(16777216),
	SUB_LINE_NO VARCHAR(16777216),
	LINE_TOTAL VARCHAR(16777216),
	UNIT_PRICE VARCHAR(16777216),
	LINE_TAX_CHARGE_CATEGORY VARCHAR(16777216),
	LINE_TAX_CHARGE_NAME VARCHAR(16777216),
	LINE_TAX VARCHAR(16777216),
	GRAND_TOTAL VARCHAR(16777216),
	HEADER_CHARGE_AMOUNT VARCHAR(16777216),
	HEADER_CHARGE_CATEGORY VARCHAR(16777216),
	HEADER_CHARGE_NAME VARCHAR(16777216),
	LINE_TAX_NAME VARCHAR(16777216),
	LINE_CHARGE_AMOUNT VARCHAR(16777216),
	LINE_CHARGE_CATEGORY VARCHAR(16777216),
	LINE_CHARGE_NAME VARCHAR(16777216),
	HEADER_TAX_CHARGE_CATEGORY VARCHAR(16777216),
	HEADER_TAX_CHARGE_NAME VARCHAR(16777216),
	HEADER_TAX VARCHAR(16777216),
	HEADER_TAX_NAME VARCHAR(16777216),
    RETURN_ORDER_HEADER_KEY VARCHAR(16777216),
    RETURN_ORDER_NO VARCHAR(16777216),
    ORDER_LINE_KEY VARCHAR(16777216),
    ORDERED_QUANTITY VARCHAR(16777216),
    SKU VARCHAR(16777216),
	TXN_ID VARCHAR(16777216) DEFAULT UUID_STRING()
);

CREATE OR REPLACE PROCEDURE TRANSFORMED.USP_INSERT_STG_FINANCIAL_RECONCILIATION("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    toBeProcessedRecordCount INT;
    error_object OBJECT;

BEGIN

    -- Log the start of the staging process
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :PIPELINE_NAME,
        'staging',
        'STARTED',
        CURRENT_TIMESTAMP(),
        NULL,
        'Staging started'
    );

    TRUNCATE TABLE TRANSFORMED.STG_Financial_Reconciliation;

    -- Drop the temporary table if it exists
    DROP TABLE IF EXISTS TRANSFORMED.STG_Financial_Reconciliation_temp1;

    -- Create the temporary table
    CREATE TEMPORARY TABLE TRANSFORMED.STG_Financial_Reconciliation_temp1 AS
    SELECT DISTINCT
       Document_Type,
        Enterprise_Code,
        rooh.Order_Header_Key,
        rooh.Order_No,
        rooh.Modifyts,
        rooh.Event_Type,
        rooh.Prime_Line_No,
        rooh.Sub_Line_No,
        Line_Total,
        Unit_Price,
        rooh.Line_Tax_Charge_Category,
        rooh.Line_Tax_Charge_Name,
        Line_Tax,
        Grand_Total,
        Header_Charge_Amount,
        Header_Charge_Category,
        Header_Charge_Name,
        rooh.Line_Tax_Name,
        Line_Charge_Amount,
        rooh.Line_Charge_Category,
        rooh.Line_Charge_Name,
        Header_Tax_Charge_Category,
        Header_Tax_Charge_Name,
        Header_Tax,
        Header_Tax_Name,
        RETURN_ORDER_HEADER_KEY,
        RETURN_ORDER_NO,
        ORDER_LINE_KEY,
        ORDERED_QUANTITY,
        SKU,
        prelines.TXN_ID
    FROM raw.RAW_Financial_Reconciliation AS rooh
    INNER JOIN (
        SELECT DISTINCT
            MIN(MODIFYTS) AS MODIFYTS, 
            min(TXN_ID) AS TXN_ID,
            Order_Header_Key, 
            Order_No
           /* EVENT_TYPE,
            PRIME_LINE_NO,
            SUB_LINE_NO,
            LINE_TAX_CHARGE_CATEGORY,
            LINE_TAX_CHARGE_NAME,
            Line_Tax_Name,
            Line_Charge_Category,
            Line_Charge_Name */
        FROM raw.RAW_Financial_Reconciliation
        WHERE processing_status IN ('Pending', 'Failed')
        GROUP BY Order_Header_Key, 
            Order_No
            /*EVENT_TYPE,
            PRIME_LINE_NO,
            SUB_LINE_NO,
            LINE_TAX_CHARGE_CATEGORY,
            LINE_TAX_CHARGE_NAME,
            Line_Tax_Name,
            Line_Charge_Category,
            Line_Charge_Name */
    ) AS prelines
    ON prelines.MODIFYTS = rooh.MODIFYTS
    AND rooh.Order_No = prelines.Order_No
    AND rooh.Order_Header_Key = prelines.Order_Header_Key 
   /* AND rooh.EVENT_TYPE = prelines.EVENT_TYPE 
    AND rooh.PRIME_LINE_NO = prelines.PRIME_LINE_NO 
    AND rooh.SUB_LINE_NO = prelines.SUB_LINE_NO 
    AND rooh.LINE_TAX_CHARGE_CATEGORY = prelines.LINE_TAX_CHARGE_CATEGORY 
    AND rooh.LINE_TAX_CHARGE_NAME = prelines.LINE_TAX_CHARGE_NAME 
    AND rooh.Line_Tax_Name = prelines.Line_Tax_Name 
    AND rooh.Line_Charge_Category = prelines.Line_Charge_Category 
    AND rooh.Line_Charge_Name = prelines.Line_Charge_Name */
    WHERE rooh.processing_status IN ('Pending', 'Failed');

    INSERT INTO TRANSFORMED.STG_Financial_Reconciliation 
    SELECT *
    FROM TRANSFORMED.STG_Financial_Reconciliation_temp1;

    -- Select the count of records to be processed
    SELECT COUNT(*) INTO :toBeProcessedRecordCount
    FROM TRANSFORMED.STG_Financial_Reconciliation;

    -- Update the log table with the count of records to be processed
    UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    WHERE file_name = 'FINANCIAL_RECONCILIATION';

    -- Log the completion of the staging process
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :PIPELINE_NAME,
        'staging',
        'COMPLETED',
        NULL,
        CURRENT_TIMESTAMP(),
        'Staging completed successfully'
    );

    RETURN 'USP_INSERT_STG_Financial_Reconciliation executed successfully';

EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    -- Handle error
    UPDATE ANALYTICS.log_files_import_status
    SET processed = 0,
        status = 'Failed'
    WHERE file_name = 'FINANCIAL_RECONCILIATION';

    -- Create error object
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', SQLCODE,
                                     'SQLERRM', SQLERRM,
                                     'SQLSTATE', SQLSTATE);

    -- Log the failure
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :PIPELINE_NAME,
        'staging',
        'FAILED',
        NULL,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    RETURN :error_object;
END;




create or replace TABLE ANALYTICS.TXN_FINANCIAL_RECONCILIATION (
	DOCUMENT_TYPE VARCHAR(16777216),
	ENTERPRISE_CODE VARCHAR(16777216),
	ORDER_HEADER_KEY VARCHAR(16777216),
	ORDER_NO VARCHAR(16777216),
	MODIFYTS VARCHAR(16777216),
	EVENT_TYPE VARCHAR(16777216),
	PRIME_LINE_NO NUMBER(15,0),
	SUB_LINE_NO NUMBER(15,0),
	LINE_TOTAL NUMBER(15,6),
	UNIT_PRICE NUMBER(15,6),
	LINE_TAX_CHARGE_CATEGORY VARCHAR(16777216),
	LINE_TAX_CHARGE_NAME VARCHAR(16777216),
	LINE_TAX NUMBER(15,6),
	GRAND_TOTAL NUMBER(15,6),
	HEADER_CHARGE_AMOUNT NUMBER(15,6),
	HEADER_CHARGE_CATEGORY VARCHAR(16777216),
	HEADER_CHARGE_NAME VARCHAR(16777216),
    Line_Tax_Name VARCHAR(16777216),
    Line_Charge_Amount NUMBER(15,6),
    Line_Charge_Category VARCHAR(16777216),
    Line_Charge_Name VARCHAR(16777216),
    Header_Tax_Charge_Category VARCHAR(16777216),
    Header_Tax_Charge_Name VARCHAR(16777216),
    Header_Tax NUMBER(15,6),
    Header_Tax_Name VARCHAR(16777216),
    RETURN_ORDER_HEADER_KEY VARCHAR(16777216),
    RETURN_ORDER_NO VARCHAR(16777216),
    ORDER_LINE_KEY VARCHAR(16777216),
    ORDERED_QUANTITY NUMBER(15,0),
    SKU VARCHAR(16777216),
	TXN_ID VARCHAR(16777216),
	MODIFYTS_UTC TIMESTAMP_NTZ(9),
	INSERTED_DATE TIMESTAMP_NTZ(9),
	MODIFIED_DATE TIMESTAMP_NTZ(9)
);


create or replace TABLE ANALYTICS.AUDIT_FINANCIAL_RECONCILIATION (
	DOCUMENT_TYPE VARCHAR(16777216),
	ENTERPRISE_CODE VARCHAR(16777216),
	ORDER_HEADER_KEY VARCHAR(16777216),
	ORDER_NO VARCHAR(16777216),
	MODIFYTS VARCHAR(16777216),
	EVENT_TYPE VARCHAR(16777216),
	PRIME_LINE_NO NUMBER(15,0),
	SUB_LINE_NO NUMBER(15,0),
	LINE_TOTAL NUMBER(15,6),
	UNIT_PRICE NUMBER(15,6),
	LINE_TAX_CHARGE_CATEGORY VARCHAR(16777216),
	LINE_TAX_CHARGE_NAME VARCHAR(16777216),
	LINE_TAX NUMBER(15,6),
	GRAND_TOTAL NUMBER(15,6),
	HEADER_CHARGE_AMOUNT NUMBER(15,6),
	HEADER_CHARGE_CATEGORY VARCHAR(16777216),
	HEADER_CHARGE_NAME VARCHAR(16777216),
    Line_Tax_Name VARCHAR(16777216),
    Line_Charge_Amount NUMBER(15,6),
    Line_Charge_Category VARCHAR(16777216),
    Line_Charge_Name VARCHAR(16777216),
    Header_Tax_Charge_Category VARCHAR(16777216),
    Header_Tax_Charge_Name VARCHAR(16777216),
    Header_Tax NUMBER(15,6),
    Header_Tax_Name VARCHAR(16777216),
    RETURN_ORDER_HEADER_KEY VARCHAR(16777216),
    RETURN_ORDER_NO VARCHAR(16777216),
    ORDER_LINE_KEY VARCHAR(16777216),
    ORDERED_QUANTITY NUMBER(15,0),
    SKU VARCHAR(16777216),
	TXN_ID VARCHAR(16777216),
	MODIFYTS_UTC TIMESTAMP_NTZ(9),
	INSERTED_DATE TIMESTAMP_NTZ(9),
	MODIFIED_DATE TIMESTAMP_NTZ(9),
	REVISION NUMBER(15,0)
);


CREATE OR REPLACE PROCEDURE ANALYTICS.USP_FINANCIAL_RECONCILIATION_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
BEGIN

-- Assign current timestamp to processedDate
processedDate := CURRENT_TIMESTAMP();

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
    :PIPELINE_NAME,
    'upsert',
    'STARTED',
    CURRENT_TIMESTAMP(),
    NULL,
    'upsert started'
);

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.insertedFinancialReconciliation (
    Document_Type VARCHAR(16777216),
    Enterprise_Code VARCHAR(16777216),
    Order_Header_Key VARCHAR(16777216),
    Order_No VARCHAR(16777216),
    Modifyts VARCHAR(16777216),
    Event_Type VARCHAR(16777216),
    Prime_Line_No NUMBER(15,0),
    Sub_Line_No NUMBER(15,0),
    Line_Total NUMBER(15,6),
    Unit_Price NUMBER(15,6),
    Line_Tax_Charge_Category VARCHAR(16777216),
    Line_Tax_Charge_Name VARCHAR(16777216),
    Line_Tax NUMBER(15,6),
    Grand_Total NUMBER(15,6),
    Header_Charge_Amount NUMBER(15,6),
    Header_Charge_Category VARCHAR(16777216),
    Header_Charge_Name VARCHAR(16777216),
    Line_Tax_Name VARCHAR(16777216),
    Line_Charge_Amount NUMBER(15,6),
    Line_Charge_Category VARCHAR(16777216),
    Line_Charge_Name VARCHAR(16777216),
    Header_Tax_Charge_Category VARCHAR(16777216),
    Header_Tax_Charge_Name VARCHAR(16777216),
    Header_Tax NUMBER(15,6),
    Header_Tax_Name VARCHAR(16777216),
    RETURN_ORDER_HEADER_KEY VARCHAR(16777216),
    RETURN_ORDER_NO VARCHAR(16777216),
    ORDER_LINE_KEY VARCHAR(16777216),
    ORDERED_QUANTITY NUMBER(15,0),
    SKU VARCHAR(16777216),
    TXN_ID VARCHAR(16777216),
    Modifyts_utc TIMESTAMP_NTZ(9),
    INSERTED_DATE TIMESTAMP_NTZ(9),
    MODIFIED_DATE TIMESTAMP_NTZ(9),
    REVISION NUMBER(15,0)
);


INSERT INTO ANALYTICS.insertedFinancialReconciliation (
    Document_Type,
    Enterprise_Code,
    Order_Header_Key,
    Order_No,
    Modifyts,
    Event_Type,
    Prime_Line_No,
    Sub_Line_No,
    Line_Total,
    Unit_Price,
    Line_Tax_Charge_Category,
    Line_Tax_Charge_Name,
    Line_Tax,
    Grand_Total,
    Header_Charge_Amount,
    Header_Charge_Category,
    Header_Charge_Name,
    Line_Tax_Name ,
    Line_Charge_Amount ,
    Line_Charge_Category ,
    Line_Charge_Name ,
    Header_Tax_Charge_Category ,
    Header_Tax_Charge_Name ,
    Header_Tax ,
    Header_Tax_Name ,
    RETURN_ORDER_HEADER_KEY,
    RETURN_ORDER_NO,
    ORDER_LINE_KEY,
    ORDERED_QUANTITY,
    SKU,
    TXN_ID,
    Modifyts_utc,
    INSERTED_DATE,
    MODIFIED_DATE,
    REVISION
)
SELECT
    si.Document_Type,
    si.Enterprise_Code,
    si.Order_Header_Key,
    si.Order_No,
    si.Modifyts,
    si.Event_Type,
    si.Prime_Line_No,
    si.Sub_Line_No,
    si.Line_Total,
    si.Unit_Price,
    si.Line_Tax_Charge_Category,
    si.Line_Tax_Charge_Name,
    si.Line_Tax,
    si.Grand_Total,
    si.Header_Charge_Amount,
    si.Header_Charge_Category,
    si.Header_Charge_Name,
    si.Line_Tax_Name ,
    si.Line_Charge_Amount ,
    si.Line_Charge_Category ,
    si.Line_Charge_Name ,
    si.Header_Tax_Charge_Category ,
    si.Header_Tax_Charge_Name ,
    si.Header_Tax ,
    si.Header_Tax_Name ,
    si.RETURN_ORDER_HEADER_KEY,
    si.RETURN_ORDER_NO,
    si.ORDER_LINE_KEY,
    si.ORDERED_QUANTITY,
    si.SKU,
    si.TXN_ID,
    si.Modifyts,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    1
FROM  TRANSFORMED.STG_Financial_Reconciliation si;

DELETE FROM ANALYTICS.TXN_Financial_Reconciliation txn
USING ANALYTICS.insertedFinancialReconciliation temp
WHERE txn.Order_Header_Key = temp.Order_Header_Key;


INSERT INTO ANALYTICS.TXN_Financial_Reconciliation(
     Document_Type,
        Enterprise_Code,
        Order_Header_Key,
        Order_No,
        Modifyts,
        Event_Type,
        Prime_Line_No,
        Sub_Line_No,
        Line_Total,
        Unit_Price,
        Line_Tax_Charge_Category,
        Line_Tax_Charge_Name,
        Line_Tax,
        Grand_Total,
        Header_Charge_Amount,
        Header_Charge_Category,
        Header_Charge_Name,
        Line_Tax_Name ,
        Line_Charge_Amount ,
        Line_Charge_Category ,
        Line_Charge_Name ,
        Header_Tax_Charge_Category ,
        Header_Tax_Charge_Name ,
        Header_Tax ,
        Header_Tax_Name ,
        RETURN_ORDER_HEADER_KEY,
        RETURN_ORDER_NO,
        ORDER_LINE_KEY,
        ORDERED_QUANTITY,
        SKU,
        INSERTED_DATE,
        TXN_ID
)
select Document_Type,
        Enterprise_Code,
        Order_Header_Key,
        Order_No,
        Modifyts,
        Event_Type,
        Prime_Line_No,
        Sub_Line_No,
        Line_Total,
        Unit_Price,
        Line_Tax_Charge_Category,
        Line_Tax_Charge_Name,
        Line_Tax,
        Grand_Total,
        Header_Charge_Amount,
        Header_Charge_Category,
        Header_Charge_Name,
        Line_Tax_Name ,
        Line_Charge_Amount ,
        Line_Charge_Category ,
        Line_Charge_Name ,
        Header_Tax_Charge_Category ,
        Header_Tax_Charge_Name ,
        Header_Tax ,
        Header_Tax_Name ,
        RETURN_ORDER_HEADER_KEY,
        RETURN_ORDER_NO,
        ORDER_LINE_KEY,
        ORDERED_QUANTITY,
        SKU,
        INSERTED_DATE,
        TXN_ID
    FROM ANALYTICS.insertedFinancialReconciliation;


CREATE OR REPLACE TEMPORARY TABLE temp_max_revisions AS
SELECT
    MAX(aot.REVISION) AS REVISION,
    aot.Order_Header_Key
FROM
    ANALYTICS.AUDIT_Financial_Reconciliation aot
GROUP BY
    aot.Order_Header_Key;

UPDATE ANALYTICS.insertedFinancialReconciliation AS ttd
SET
    ttd.revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM
    temp_max_revisions AS aot
WHERE
    ttd.Order_Header_Key = aot.Order_Header_Key;

DROP TABLE IF EXISTS temp_max_revisions;

/*UPDATE ANALYTICS.insertedFinancialReconciliation ttm
SET ttm.REVISION = CAST((COALESCE(aot.REVISION, 0) + 1) AS INTEGER)
FROM ANALYTICS.insertedFinancialReconciliation ttd
    left JOIN (
        SELECT
            MAX(aot.REVISION) AS REVISION,
            aot.Order_Header_Key
        FROM ANALYTICS.AUDIT_Financial_Reconciliation aot
            INNER JOIN ANALYTICS.insertedFinancialReconciliation ttd ON 
            ttd.Order_Header_Key = aot.Order_Header_Key 
        GROUP BY aot.Order_Header_Key
    ) aot ON ttd.Order_Header_Key = aot.Order_Header_Key 
;*/



INSERT INTO ANALYTICS.AUDIT_Financial_Reconciliation (
    Document_Type,
    Enterprise_Code,
    Order_Header_Key,
    Order_No,
    Modifyts,
    Event_Type,
    Prime_Line_No,
    Sub_Line_No,
    Line_Total,
    Unit_Price,
    Line_Tax_Charge_Category,
    Line_Tax_Charge_Name,
    Line_Tax,
    Grand_Total,
    Header_Charge_Amount,
    Header_Charge_Category,
    Header_Charge_Name,
    Line_Tax_Name ,
    Line_Charge_Amount ,
    Line_Charge_Category ,
    Line_Charge_Name ,
    Header_Tax_Charge_Category ,
    Header_Tax_Charge_Name ,
    Header_Tax ,
    Header_Tax_Name ,
    RETURN_ORDER_HEADER_KEY,
    RETURN_ORDER_NO,
    ORDER_LINE_KEY,
    ORDERED_QUANTITY,
    SKU,
    TXN_ID,
    Modifyts_utc,
    INSERTED_DATE,
    MODIFIED_DATE,
    REVISION
)
SELECT
    si.Document_Type,
    si.Enterprise_Code,
    si.Order_Header_Key,
    si.Order_No,
    si.Modifyts,
    si.Event_Type,
    si.Prime_Line_No,
    si.Sub_Line_No,
    si.Line_Total,
    si.Unit_Price,
    si.Line_Tax_Charge_Category,
    si.Line_Tax_Charge_Name,
    si.Line_Tax,
    si.Grand_Total,
    si.Header_Charge_Amount,
    si.Header_Charge_Category,
    si.Header_Charge_Name,
    si.Line_Tax_Name ,
    si.Line_Charge_Amount ,
    si.Line_Charge_Category ,
    si.Line_Charge_Name ,
    si.Header_Tax_Charge_Category ,
    si.Header_Tax_Charge_Name ,
    si.Header_Tax ,
    si.Header_Tax_Name ,
    si.RETURN_ORDER_HEADER_KEY,
    si.RETURN_ORDER_NO,
    si.ORDER_LINE_KEY,
    si.ORDERED_QUANTITY,
    si.SKU,
    si.TXN_ID,
    si.Modifyts,
    si.INSERTED_DATE,
    si.MODIFIED_DATE,
    si.REVISION
FROM ANALYTICS.insertedFinancialReconciliation si;

UPDATE RAW.RAW_Financial_Reconciliation rom
SET 
    rom.processing_status = 'Processed',
    rom.processing_comment = '',
    rom.processing_errortype = ''
FROM ANALYTICS.insertedFinancialReconciliation toi
WHERE 
    rom.Order_Header_Key = toi.Order_Header_Key 
    --AND rom.TXN_ID = toi.TXN_ID 
    AND rom.Modifyts = toi.Modifyts ;


SELECT
    COUNT(*)
INTO :processedRecordCount
FROM ANALYTICS.insertedFinancialReconciliation;

UPDATE ANALYTICS.log_files_import_status lofis
SET
    lofis.processed = :processedRecordCount,
    lofis.status = 'Success'
WHERE lofis.file_name = 'FINANCIAL_RECONCILIATION';

DROP TABLE IF EXISTS ANALYTICS.insertedFinancialReconciliation;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
    :PIPELINE_NAME,
    'upsert',
    'COMPLETED',
    NULL,
    CURRENT_TIMESTAMP(),
    'upsert completed successfully'
);
COMMIT;

RETURN 'Success';

EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'FINANCIAL_RECONCILIATION';
            
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :PIPELINE_NAME,
        'upsert',
        'FAILED',
        NULL,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );
    
    RETURN error_object;
END;






CREATE OR REPLACE PIPE RAW.PIPE_FINANCIAL_RECONCILIATION
AUTO_INGEST = TRUE AS
COPY INTO RAW.RAW_FINANCIAL_RECONCILIATION(
Document_Type,
Enterprise_Code,
Order_Header_Key,
RETURN_ORDER_HEADER_KEY,
Order_No,
RETURN_ORDER_NO,
Modifyts,
Event_Type,
Grand_Total,
Prime_Line_No,
Sub_Line_No,
ORDER_LINE_KEY,
ORDERED_QUANTITY,
Line_Total,
Unit_Price,
Line_Tax_Charge_Category,
Line_Tax_Charge_Name,
Line_Tax,
Line_Tax_Name,
Line_Charge_Amount,
Line_Charge_Category,
Line_Charge_Name,
Header_Charge_Amount,
Header_Charge_Category,
Header_Charge_Name,
Header_Tax_Charge_Category,
Header_Tax_Charge_Name,
Header_Tax,
Header_Tax_Name,
sku
)
FROM @BALSAM_EDW_QA.RAW.STAGE_FINANCIAL_RECONCILIATION;





create or replace TABLE TRANSFORMED.LOG_PIPELINE_TASKS_EXECUTION_DETAILS (
	PIPELINE_NAME VARCHAR(16777216),
	STAGE_NAME VARCHAR(16777216),
	STATUS VARCHAR(16777216),
	START_TIME TIMESTAMP_NTZ(9),
	END_TIME TIMESTAMP_NTZ(9),
	MESSAGE VARCHAR(16777216),
	RETENTION NUMBER(38,0) DEFAULT 90
);






CREATE OR REPLACE PROCEDURE TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS("PIPELINE_NAME" VARCHAR(16777216), "STAGE_NAME" VARCHAR(16777216), "STATUS" VARCHAR(16777216), "START_TIME" TIMESTAMP_NTZ(9), "END_TIME" TIMESTAMP_NTZ(9), "MESSAGE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
    INSERT INTO TRANSFORMED.log_pipeline_tasks_execution_details (
        pipeline_name,
        stage_name,
        status,
        start_time,
        end_time,
        message
    ) VALUES (
        :pipeline_name,
        :stage_name,
        :status,
        :start_time,
        :end_time,
        :message
    );

    RETURN ''Insert operation completed successfully'';
END';



create or replace TABLE ANALYTICS.LOG_FILES_IMPORT_STATUS (
	FILE_NAME VARCHAR(16777216) NOT NULL,
	RECORDS NUMBER(38,0),
	SINCE_ TIMESTAMP_NTZ(9),
	TO_ TIMESTAMP_NTZ(9),
	PROCESSED NUMBER(38,0),
	RAW_TABLE VARCHAR(16777216),
	STATUS VARCHAR(100),
	TO_BE_PROCESSED NUMBER(38,0) NOT NULL,
	PRIMARY_KEY_NAME VARCHAR(16777216),
	primary key (FILE_NAME)
);


CREATE OR REPLACE STAGE RAW.STAGE_FINANCIAL_RECONCILIATION   URL = 's3://balsambrands-snowpipe-qa/financial/reconciliation/'   
STORAGE_INTEGRATION = aws_qa   FILE_FORMAT = RAW.CUSTOM_RAW_CSV_FORMAT ;



