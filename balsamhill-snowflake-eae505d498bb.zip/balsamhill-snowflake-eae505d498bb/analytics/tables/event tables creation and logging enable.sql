
--event tables creation and logging enable

create event table balsam_edw_dev.analytics.dev_logging_events;

show event tables in account;

--setting custom event table using naming convintion

alter account set event_table=balsam_edw_dev.analytics.dev_logging_events;

--System default logging parameters

SYSTEM$LOG('TRACE','sp started'||:pipeline_name);
SYSTEM$LOG('DEBUG','');
SYSTEM$LOG('WARN','');
SYSTEM$LOG('ERROR','');
SYSTEM$LOG('FATAL','');
SYSTEM$LOG('INFO','');
SYSTEM$LOG('TRACE','sp COMPLETED'||:pipeline_name);



--Grants 

ALTER ACCOUNT SET LOG_LEVEL=TRACE;
ALTER ACCOUNT SET TRACE_LEVEL=ALWAYS;

ALTER USER SET LOG_LEVEL=TRACE;
ALTER USER SET TRACE_LEVEL=ALWAYS;

ALTER SESSION SET LOG_LEVEL=TRACE;
ALTER SESSION SET TRACE_LEVEL=ALWAYS;



--creating stored procedure 

CREATE OR REPLACE PROCEDURE BALSAM_EDW_DEV.ANALYTICS.DEV_LOGGING_EVENTS_TEST( pipeline_name STRING)
    RETURNS varchar
    LANGUAGE SQL
As
DECLARE
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

    CALL BALSAM_EDW_DEV.TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'staging',
        'STARTED',
        :start_time_proc,
        NULL,
        'Staging started '
    );
    
--SQL query 
select system$wait('10');



commit;

CALL BALSAM_EDW_DEV.TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'staging',
        'COMPLETED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        'Staging completed successfully'
    );

--Log the completion of the stored procedure execution
SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

    
-- Return success message
return 'success';

-- Exception handling block
EXCEPTION when statement_error then

-- Rollback the transaction in case of an error
rollback;


-- Capture error details in an object
error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);
                                     
-- Log the failure event in the pipeline tasks execution details table
CALL BALSAM_EDW_DEV.TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'staging',
        'FAILED',
        :start_time_proc,
        current_timestamp(),
        to_json(:error_object)
    );

-- Log the failure of the stored procedure
SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);


 RETURN 'Error occured: '||:pipeline_name||' : '||sqlerrm;
 
END;

--altering procs to enable the logs 

ALTER PROCEDURE BALSAM_EDW_DEV.ANALYTICS.DEV_LOGGING_EVENTS_TEST(VARCHAR) SET LOG_LEVEL=TRACE;
ALTER PROCEDURE BALSAM_EDW_DEV.ANALYTICS.DEV_LOGGING_EVENTS_TEST(VARCHAR) SET TRACE_LEVEL=ALWAYS;

--calling sp
CALL BALSAM_EDW_DEV.ANALYTICS.DEV_LOGGING_EVENTS_TEST('TEST_LOG_ORDER');

--validation

select * from balsam_edw_dev.transformed.log_pipeline_tasks_execution_details where pipeline_name='TEST_LOG_ORDER';
