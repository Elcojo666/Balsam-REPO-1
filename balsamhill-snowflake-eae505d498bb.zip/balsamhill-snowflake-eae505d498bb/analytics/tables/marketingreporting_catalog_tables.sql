

USE SCHEMA ANALYTICS;

CREATE TABLE CatalogMatchback (
    SourceRefNum VARCHAR(20),
    AllocatedDrop VARCHAR(20),
    KeyCode VARCHAR(20),
    Brand VARCHAR(30),
    CatalogYear INT
);

CREATE TABLE CatalogKeycode (
    KeyCode VARCHAR(100),
    CustomerSegment VARCHAR(20),
    Test VARCHAR(255),
    AllocatedDrop VARCHAR(20),
    Circulation FLOAT,
    CatalogYear FLOAT,
    Brand VARCHAR(30),
    DropDate DATE,
    BelardiKeyCode VARCHAR(20)
);



