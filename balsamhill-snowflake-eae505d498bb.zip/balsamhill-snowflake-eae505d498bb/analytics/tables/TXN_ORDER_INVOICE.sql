CREATE TABLE ANALYTICS.TXN_ORDER_INVOICE(
	  order_invoice_key  VARCHAR(16777216) NOT NULL
      ,order_header_key VARCHAR(16777216) NOT NULL
      ,return_release_key VARCHAR(16777216)
      ,shipment_key VARCHAR(16777216)
      ,charge_transaction_key VARCHAR(16777216)
      ,master_invoice_no VARCHAR(16777216)
      ,invoice_no VARCHAR(16777216)
      ,invoice_type VARCHAR(16777216)
      ,currency VARCHAR(16777216)
      ,charged_actual_freight VARCHAR(16777216)
      ,tax FLOAT
      ,actual_freight_charge FLOAT
      ,total_tax FLOAT
      ,line_subtotal FLOAT
      ,status VARCHAR(16777216)
      ,total_amount FLOAT
      ,amount_collected FLOAT
      ,collected_externally VARCHAR(16777216) 
      ,amount_passed_to_ar FLOAT
      ,other_charges FLOAT
      ,derived_from_order_header_key VARCHAR(16777216)
      ,reference_1 VARCHAR(16777216)
      ,invoice_creation_reason VARCHAR(16777216)
      ,document_type VARCHAR(16777216)
      ,enterprise_code VARCHAR(16777216)
      ,order_no VARCHAR(16777216)
      ,shipnode_key FLOAT
      ,shipment_no VARCHAR(16777216)
      ,seller_organization_code VARCHAR(16777216)
      ,rollout_version VARCHAR(16777216)
      ,createts TIMESTAMP_NTZ(9)
      ,modifyts TIMESTAMP_NTZ(9)
      ,createuserid VARCHAR(16777216)
      ,modifyuserid VARCHAR(16777216)
      ,createprogid VARCHAR(16777216)
      ,modifyprogid VARCHAR(16777216)
      ,lockid VARCHAR(16777216)
	  ,inserted_date TIMESTAMP_NTZ(9)
	  ,modified_date TIMESTAMP_NTZ(9)
);
