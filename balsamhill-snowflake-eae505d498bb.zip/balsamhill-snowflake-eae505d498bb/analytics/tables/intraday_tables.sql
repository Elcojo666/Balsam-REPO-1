USE DATABASE DEV; 

CREATE OR REPLACE TABLE ANALYTICS.TXN_INTRA_DAY_ORDER_REPORTING(
    source_ref_num STRING,
    order_date TIMESTAMP_NTZ(9),
    net_amount DECIMAL(38,2),
    currency STRING,
    order_status STRING,
    enterprise_code STRING,
    entry_type STRING,
    order_type STRING,
    inserted_date TIMESTAMP_NTZ(9),
    fk_sourceid NUMBER(38, 0),
    fk_order_statusid NUMBER(38, 0)
)
;
