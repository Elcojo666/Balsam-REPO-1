USE DATABASE dev;
USE SCHEMA analytics;

CREATE OR REPLACE TABLE analytics.txn_gladly_customer (
        id VARCHAR,
        name VARCHAR,
        address VARCHAR,
        external_customer_ids VARCHAR,
        phone_numbers VARCHAR,
        email_addresses VARCHAR,
        created_at TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
        updated_at TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);