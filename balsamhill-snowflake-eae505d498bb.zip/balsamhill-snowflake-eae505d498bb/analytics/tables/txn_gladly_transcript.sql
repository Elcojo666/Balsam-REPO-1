USE DATABASE DEV;
USE SCHEMA ANALYTICS;

CREATE OR REPLACE TABLE analytics.txn_gladly_transcript (
    item_id               STRING,
    customer_id           STRING,
    paragraphs            VARIANT,
    number_of_speakers    NUMBER,
    language              STRING,
    transcript_created_at TIMESTAMP_NTZ,
    transcript_updated_at TIMESTAMP_NTZ,
    created_at            TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    updated_at            TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
)
CLUSTER BY (item_id);