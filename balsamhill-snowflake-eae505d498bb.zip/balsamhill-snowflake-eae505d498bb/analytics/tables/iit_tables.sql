 
create or replace TABLE ANALYTICS.TXN_PO_DETAIL (
	PK_PO_DETAILID NUMBER(38,0) NOT NULL autoincrement start 1 increment 1 order,
	FK_PO_HEADERID NUMBER(38,0) NOT NULL,
	FK_SKUPRODUCTID NUMBER(38,0),
	FK_INNER_UPCID NUMBER(38,0),
	FK_MASTER_UPCID NUMBER(38,0),
	ORDERED_QUANTITY NUMBER(38,0) NOT NULL,
	RECEIVED_QUANTITY NUMBER(38,0) NOT NULL,
	EXTERNAL_ID NUMBER(38,0),
	PO_NUMBER VARCHAR(16777216) NOT NULL,
	SKU_NAME VARCHAR(16777216),
	DESCRIPTION VARCHAR(16777216),
	INITIAL_UNIT_PRICE FLOAT,
	TOTAL_SPEND FLOAT,
	VARIANCE NUMBER(38,0),
	RECEIVED_ON TIMESTAMP_NTZ(9),
	NOTES_ON_RECEIPT VARCHAR(16777216),
	ATA_TO_WAREHOUSE VARCHAR(16777216),
	ION_RECEIPTS NUMBER(38,0),
	ION_RECEIVE_ON TIMESTAMP_NTZ(9),
	MANUAL_RECEIPTS NUMBER(38,0),
	MANUAL_RECEIVE_ON TIMESTAMP_NTZ(9),
	HTS_CODE VARCHAR(16777216),
	HTS_RATE FLOAT,
	CBF_PER_UNIT FLOAT,
	TOTAL_CBF FLOAT,
	SPEND_BY_QTY_RECEIVED FLOAT,
	ENTERED_BY_ACCT TIMESTAMP_NTZ(9),
	LANDED_COSTS FLOAT,
	TOTAL_COSTS_BY_QTY_RECEIVED FLOAT,
	TOTAL_COMMISSION FLOAT,
	CATEGORY VARCHAR(16777216),
	SUB_CATEGORY VARCHAR(16777216),
	PG_LANDED_COST FLOAT,
	TOTAL_LANDED_COST FLOAT,
	EXPECTED_SHIP_WEEK NUMBER(38,0),
	WEEK_NO_EXPECTED_ARIVAL NUMBER(38,0),
	CREATED_BY NUMBER(38,0),
	MODIFIED_DATE TIMESTAMP_NTZ(9),
	INSERTED_DATE TIMESTAMP_NTZ(9),
	VALID_FROM TIMESTAMP_NTZ(9),
	VALID_TO TIMESTAMP_NTZ(9),
	FK_BRANDID NUMBER(38,0),
	SKUPRODUCTCODE VARCHAR(16777216),
	INNER_UPCCODE VARCHAR(16777216),
	MASTER_UPCCODE VARCHAR(16777216),
	DISCREPANCYREASON VARCHAR(16777216)
);

create or replace TABLE ANALYTICS.TXN_PO_HEADER (
	PK_PO_HEADERID NUMBER(38,0) NOT NULL autoincrement start 1 increment 1 order,
	PO_NUMBER VARCHAR(16777216) NOT NULL,
	FK_RECEIVING_WAREHOUSEID NUMBER(38,0),
	FK_PO_STATUSID NUMBER(38,0) NOT NULL,
	AMOUNT FLOAT,
	PO_DATE TIMESTAMP_NTZ(9) NOT NULL,
	EXTERNAL_ID NUMBER(38,0),
	FK_SUPPLIERID NUMBER(38,0),
	ETD_SHIPPING_START TIMESTAMP_NTZ(9),
	ETD_SHIPPING_END TIMESTAMP_NTZ(9),
	INITIAL_ETA TIMESTAMP_NTZ(9),
	FK_ORIGIN_COUNTRYID NUMBER(38,0),
	FK_DESTINATION_COUNTRYID NUMBER(38,0),
	SUR_CHARGE FLOAT,
	FK_AGENTID NUMBER(38,0),
	PAYMENT_TERM VARCHAR(16777216),
	INITIAL_PAYMENT_APPROVED_ON TIMESTAMP_NTZ(9),
	FINAL_PAYMENT_APPROVED_ON TIMESTAMP_NTZ(9),
	NOTES VARCHAR(16777216),
	ETD_SHIPPING_START_DATE TIMESTAMP_NTZ(9),
	ETD_SHIPPING_END_DATE TIMESTAMP_NTZ(9),
	CONFIRM_ON TIMESTAMP_NTZ(9),
	HBL_BOOKED VARCHAR(16777216),
	SAIL_ON TIMESTAMP_NTZ(9),
	FTN_ETA TIMESTAMP_NTZ(9),
	FTN_ETA_NOTE VARCHAR(16777216),
	ETA_WAREHOUSE_DATE TIMESTAMP_NTZ(9),
	ATA_WAREHOUSE_DATE TIMESTAMP_NTZ(9),
	FK_DESTINATION_WAREHOUSEID NUMBER(38,0),
	TOTAL_CONTAINERS NUMBER(38,0),
	ETD NUMBER(38,0),
	CREATED_BY NUMBER(38,0),
	MODIFIED_DATE TIMESTAMP_NTZ(9),
	INSERTED_DATE TIMESTAMP_NTZ(9),
	VALID_FROM TIMESTAMP_NTZ(9),
	VALID_TO TIMESTAMP_NTZ(9),
	FK_PORTID NUMBER(38,0),
	SEASON_NAME VARCHAR(16777216),
	COMMISSION_PERCENTAGE FLOAT,
	WHO_PAYS VARCHAR(16777216),
	QB_VENDOR VARCHAR(16777216),
	NOTE VARCHAR(16777216),
	FK_PO_TYPEID NUMBER(38,0)
);

create  TABLE analytics.p44container_tracking (
	ID NUMBER(38,0),
	CONTAINERNUMBER VARCHAR(200),
	PROJECT44ETATOPORT TIMESTAMP_NTZ(9),
	PROJECT44ETATOWAREHOUSE TIMESTAMP_NTZ(9),
	PROJECT44ETATOINSTOCK TIMESTAMP_NTZ(9),
	CARRIERETATOPORT TIMESTAMP_NTZ(9),
	CARRIERETATOWAREHOUSE TIMESTAMP_NTZ(9),
	CARRIERETATOINSTOCK TIMESTAMP_NTZ(9),
	MANUALETATOPORT TIMESTAMP_NTZ(9),
	MANUALETATOWAREHOUSE TIMESTAMP_NTZ(9),
	MANUALETATOINSTOCK TIMESTAMP_NTZ(9),
	BILLOFLADING VARCHAR(200),
	CARRIERSCAC VARCHAR(25),
	SHIPMENTSHARELINK VARCHAR(16777216),
	CALCULATEDETATOPORT TIMESTAMP_NTZ(9),
	CALCULATEDETATOINSTOCK TIMESTAMP_NTZ(9),
	CALCULATEDETATOWAREHOUSE TIMESTAMP_NTZ(9),
	CREATEDON TIMESTAMP_NTZ(9),
	MODIFIEDON TIMESTAMP_NTZ(9),
	MODIFIEDBY NUMBER(38,0),
	LASTUPDATEDDATE TIMESTAMP_NTZ(7),
	PROJECT44ETATOPORT_MODIFIEDON TIMESTAMP_NTZ(9),
	PROJECT44ETATOWAREHOUSE_MODIFIEDON TIMESTAMP_NTZ(9),
	CARRIERETATOPORT_MODIFIEDON TIMESTAMP_NTZ(9),
	CARRIERETATOWAREHOUSE_MODIFIEDON TIMESTAMP_NTZ(9),
	MANUALETATOPORT_MODIFIEDON TIMESTAMP_NTZ(9),
	MANUALETATOPORT_MODIFIEDBY NUMBER(38,0),
	MANUALETATOWAREHOUSE_MODIFIEDON TIMESTAMP_NTZ(9),
	MANUALETATOWAREHOUSE_MODIFIEDBY NUMBER(38,0),
	MANUALETATOINSTOCK_MODIFIEDON TIMESTAMP_NTZ(9),
	MANUALETATOINSTOCK_MODIFIEDBY NUMBER(38,0),
	P44SHIPMENTID VARCHAR(16777216),
	GATEINFULL_ACTUALDATE TIMESTAMP_NTZ(9),
	GATEINFULL_ACTUALDATE_MODIFIEDON TIMESTAMP_NTZ(9),
	DEPARTUREFROMSTOP_ACTUALDATE TIMESTAMP_NTZ(9),
	DEPARTUREFROMSTOP_ACTUALDATE_MODIFIEDON TIMESTAMP_NTZ(9),
	DISCHARGE_ACTUALDATE TIMESTAMP_NTZ(9),
	DISCHARGE_ACTUALDATE_MODIFIEDON TIMESTAMP_NTZ(9),
	GATEOUTFULL_ACTUALDATE TIMESTAMP_NTZ(9),
	GATEOUTFULL_ACTUALDATE_MODIFIEDON TIMESTAMP_NTZ(9),
	DELETEDDATE TIMESTAMP_NTZ(9)
);

CREATE  TABLE analytics.log_bizlogic_validation (
    id BIGINT NOT NULL AUTOINCREMENT START 1 INCREMENT  1 order, -- Equivalent to IDENTITY in SQL Server
    fk_log_inputsheet_id INT,
    fk_log_inputtxn_id INT,
    primary_field_name VARCHAR(100),
    primary_field_value STRING,
    secondary_field_name STRING,
    secondary_field_value STRING,
    issue_type STRING,
    issue STRING,
    
    PRIMARY KEY (id)
);


CREATE TABLE transformed.stg_InventoryWarehouseReceiptDetail (
    ID INT NOT NULL,
    Upc VARCHAR(100) NOT NULL,
    ExpectedQty INT NOT NULL,
    ReceivedQty INT,
    InventoryWarehouseReceiptID INT NOT NULL,
    DiscrepancyReason STRING,               -- VARCHAR(MAX) → STRING
    PackingListID INT,
    IncludedInIR DATETIME,
    Sku STRING,                             -- NVARCHAR(MAX) → STRING
    IsUnexpectedUpc BOOLEAN,                -- BIT → BOOLEAN
    modifiedon DATETIME,
    PONumber VARCHAR(50)
);


CREATE TABLE transformed.stg_InventoryWarehouseReceipt (
    ID INT NOT NULL,
    DateReceived DATETIME,
    WarehouseID INT NOT NULL,
    InventoryReleaseID INT NOT NULL,
    InventoryPackingListSummaryID INT NOT NULL,
    ContainerNumber VARCHAR(100) NOT NULL,
    DepartureDate DATETIME,
    modifiedon DATETIME
);

CREATE TABLE transformed.stg_InventoryPackingList (
    ID BIGINT,
    StoreSku VARCHAR(100),
    Upc VARCHAR(100),
    Qty INT,
    Weight VARCHAR(50),
    CBM DECIMAL(19, 5),
    CartonNumber VARCHAR(50),
    UnitCost DECIMAL(19, 5),
    ProductDescription VARCHAR(255),
    Length VARCHAR(50),
    Width VARCHAR(50),
    Height VARCHAR(50),
    InvoiceID VARCHAR(100),
    InvoiceDate DATETIME,
    Vessel VARCHAR(100),
    OriginPort VARCHAR(2000),
    DestinationPort VARCHAR(2000),
    VoyageID VARCHAR(100),
    DepartureDate DATETIME,
    CargoReceivedDate DATETIME,
    Notes VARCHAR(500),
    Vendor VARCHAR(2000),
    BillOfLading VARCHAR(100),
    TransportMode VARCHAR(50),
    ContainerNumber VARCHAR(100),
    SealNumber VARCHAR(100),
    SO_Number VARCHAR(100),
    WarehouseID INT,
    PreviousWarehouseID INT,
    RerouteDate DATETIME,
    InventoryReleaseID INT,
    InventoryPackingListSummaryID INT,
    ContainerSize STRING,                   -- nvarchar(max) → STRING
    modifiedon DATETIME,
    DestinationPortID BIGINT
);

CREATE TABLE transformed.stg_InventoryPackingListSummary (
    ID INT NOT NULL,
    File STRING NOT NULL,                      -- varchar(max) → STRING, and "File" is quoted due to it being a reserved keyword
    InvoiceID STRING,                            -- nvarchar(max) → STRING
    InvoiceDate DATETIME NOT NULL,
    DateLoaded DATETIME NOT NULL,
    InventoryReleaseID INT NOT NULL,
    DeletedDate DATETIME,
    Notes VARCHAR(2000),
    WarehouseID BIGINT,
    modifiedon DATETIME
);


CREATE  TABLE transformed.stg_InventoryRelease (
    ID INT NOT NULL,
    DateLoaded DATETIME NOT NULL,
    User VARCHAR(200),                   -- "User" is a reserved keyword, so we quote it
    Name VARCHAR(255) NOT NULL,
    SourcingCategoryID INT,
    Notes VARCHAR(200),
    modifiedon DATETIME
);

CREATE TABLE transformed.stg_sku_detail (
    id STRING,
    sku_code STRING,
    sku_name STRING,
    description STRING,
    quantity_ordered STRING,
    initial_unit_price STRING,
    total_spend STRING,
    inner_upc STRING,
    master_upc STRING,
    quantity_received STRING,
    variance STRING,
    received_on DATETIME,
    notes_on_receipt STRING,
    ata_to_warehouse STRING,
    ion_receipts STRING,
    ion_receive_on DATETIME,
    manual_receipts STRING,
    manual_receive_on DATETIME,
    hts_code STRING,
    hts_rate STRING,
    cbf_per_unit STRING,
    total_cbf STRING,
    spend_by_qty_received STRING,
    entered_by_acct DATETIME,
    landed_costs STRING,
    total_costs_by_qty_received STRING,
    total_commission STRING,
    category STRING,
    sub_category STRING,
    pg_landed_cost STRING,
    total_landed_cost STRING,
    expected_ship_week STRING,
    week_no_expected_arival STRING,
    created_on DATETIME,
    created_by STRING,
    modified_on DATETIME,
    modified_by STRING,
    valid_from DATETIME,
    valid_to DATETIME,
    po_number STRING,
    brandid STRING,
    DiscrepancyReason STRING                 -- varchar(max) → STRING
);

CREATE TABLE transformed.stg_po_detail (
    id STRING,
    po_number STRING,
    supplierid STRING,
    season_name STRING,
    receiving_warehouse_name STRING,
    statusid STRING,
    etd_shipping_start DATETIME,
    etd_shipping_end DATETIME,
    initial_eta DATETIME,
    origin_countryid STRING,
    destination_countryid STRING,
    po_value STRING,
    sur_charge STRING,
    agentid STRING,
    payment_term STRING,                    -- nvarchar(max) → STRING
    initial_payment_approved_on DATETIME,
    final_payment_approved_on DATETIME,
    notes STRING,
    etd_shipping_start_date DATETIME,
    etd_shipping_end_date DATETIME,
    confirm_on DATETIME,
    hbl_booked STRING,
    sail_on DATETIME,
    ftn_eta DATETIME,
    ftn_eta_note STRING,
    eta_warehouse_date DATETIME,
    ata_warehouse_date STRING,             -- was nvarchar(max), stored as text
    origin_portid STRING,
    destination_warehouse_name STRING,
    total_containers STRING,
    etd STRING,
    created_on DATETIME,
    created_by STRING,
    modified_on DATETIME,
    modified_by STRING,
    valid_from DATETIME,
    valid_to DATETIME,
    note STRING,
    who_pays STRING,
    qb_vendor STRING,
    commission_percentage STRING,
    POType STRING
);

CREATE TABLE ANALYTICS.log_txn_runstatus (
    pk_runstatus_id INT  NOT NULL AUTOINCREMENT START  1 INCREMENT  1 order,
    fk_platform_id SMALLINT,
    activity_type STRING,        -- nvarchar(100) → STRING
    lastrun DATETIME,
    status STRING,               -- nvarchar(20) → STRING
    source STRING,               -- nvarchar(100) → STRING
    PRIMARY KEY (pk_runstatus_id)
);


CREATE TABLE if not exists  ANALYTICS.log_input_txn (
    id INT  NOT NULL AUTOINCREMENT START 1 INCREMENT  1 order,
    process_header_id BIGINT NOT NULL,
    source_database STRING NOT NULL,            -- nvarchar(100) → STRING
    record_count BIGINT,
    error_message STRING,                       -- nvarchar(max) → STRING
    is_rejected BOOLEAN,                        -- bit → BOOLEAN
    PRIMARY KEY (id)
);


CREATE TABLE  if not exists ANALYTICS.log_exportfile (
    pk_exportfileid INT NOT NULL AUTOINCREMENT START  1 INCREMENT  1 order ,
    export_file_name STRING NOT NULL,                 -- nvarchar(1000) → STRING
    export_date DATETIME NOT NULL,
    is_rejected INT NOT NULL,                         -- can also be BOOLEAN if only 0/1 used
    rejection_reason STRING,                          -- nvarchar(1000) → STRING
    fk_config_files_export_id INT NOT NULL,
    fk_processheaderid BIGINT NOT NULL,
    fk_filesourceid INT,
    PRIMARY KEY (pk_exportfileid)
);


CREATE TABLE  if not exists ANALYTICS.log_process_header (
    id BIGINT NOT NULL AUTOINCREMENT START  1 INCREMENT 1 order ,
    reference CHAR(12) NOT NULL,                         -- nchar(12) → CHAR(12)
    datafactoryname STRING,                             -- nvarchar(100) → STRING
    pipelinename STRING,                                -- nvarchar(150) → STRING
    runid STRING,                                        -- nvarchar(250) → STRING
    starttime DATETIME NOT NULL,
    endtime DATETIME,
    processstatus STRING NOT NULL,                      -- nvarchar(15) → STRING
    PRIMARY KEY (id)
);


CREATE  TABLE  if not exists  master.SourcingCategory (
    ID INT NOT NULL AUTOINCREMENT START 1 INCREMENT 1 ORDER ,
    Name VARCHAR(255) NOT NULL
);

CREATE  TABLE  if not exists  master.powarehouse (
    Id INT NOT NULL,
    CountryId INT NOT NULL,
    WarehouseName VARCHAR(22) NOT NULL,
    DaysToInStock INT NOT NULL
);

CREATE   TABLE  if not exists  ANALYTICS.audit_po_header (
    pk_po_headerid BIGINT NOT NULL,
    po_number STRING NOT NULL,                         -- NVARCHAR(100) → STRING
    fk_receiving_warehouseid SMALLINT,
    fk_po_statusid SMALLINT NOT NULL,
    amount DECIMAL(9, 0),
    po_date DATETIME NOT NULL,
    external_id BIGINT,
    fk_supplierid INT,
    etd_shipping_start DATETIME,
    etd_shipping_end DATETIME,
    initial_eta DATETIME,
    fk_origin_countryid INT,
    fk_destination_countryid INT,
    sur_charge DECIMAL(18, 2),
    fk_agentid INT,
    payment_term STRING,                              -- NVARCHAR(MAX)
    initial_payment_approved_on DATETIME,
    final_payment_approved_on DATETIME,
    notes STRING,                                     -- NVARCHAR(MAX)
    etd_shipping_start_date DATETIME,
    etd_shipping_end_date DATETIME,
    confirm_on DATETIME,
    hbl_booked STRING,                                -- NVARCHAR(MAX)
    sail_on DATETIME,
    ftn_eta DATETIME,
    ftn_eta_note STRING,                              -- NVARCHAR(MAX)
    eta_warehouse_date DATETIME,
    ata_warehouse_date DATETIME,
    fk_destination_warehouseid SMALLINT,
    total_containers INT,
    etd INT,
    created_by INT,
    modified_date DATETIME,                           -- SMALLEST DATETIME supported in Snowflake is DATETIME
    inserted_date DATETIME,
    valid_from DATETIME,
    valid_to DATETIME,
    fk_portid INT,
    season_name VARCHAR(100),
    note STRING,                                      -- NVARCHAR(MAX)
    qb_vendor STRING,                                 -- NVARCHAR(MAX)
    who_pays STRING,                                  -- NVARCHAR(MAX)
    commission_percentage DECIMAL(18, 2),
    fk_po_typeid INT
);


CREATE   TABLE  if not exists  ANALYTICS.audit_po_detail (
    pk_po_detailid BIGINT NOT NULL,
    fk_po_headerid BIGINT NOT NULL,
    fk_skuproductid BIGINT,
    fk_inner_upcid INT,
    fk_master_upcid INT,
    ordered_quantity INT NOT NULL,
    received_quantity INT NOT NULL,
    external_id BIGINT,
    po_number STRING NOT NULL,                         -- NVARCHAR(100) → STRING
    sku_name VARCHAR(255),
    description STRING,                                -- NVARCHAR(MAX) → STRING
    initial_unit_price DECIMAL(18, 2),
    total_spend DECIMAL(18, 2),
    variance INT,
    received_on DATETIME,
    notes_on_receipt STRING,                           -- NVARCHAR(MAX) → STRING
    ata_to_warehouse STRING,
    ion_receipts INT,
    ion_receive_on DATETIME,
    manual_receipts INT,
    manual_receive_on DATETIME,
    hts_code STRING,                                   -- NVARCHAR(255) → STRING
    hts_rate DECIMAL(18, 2),
    cbf_per_unit DECIMAL(18, 2),
    total_cbf DECIMAL(18, 2),
    spend_by_qty_received DECIMAL(18, 2),
    entered_by_acct DATETIME,
    landed_costs DECIMAL(18, 2),
    total_costs_by_qty_received DECIMAL(18, 2),
    total_commission DECIMAL(18, 2),
    category STRING,                                   -- NVARCHAR(MAX) → STRING
    sub_category STRING,
    pg_landed_cost DECIMAL(18, 2),
    total_landed_cost DECIMAL(18, 2),
    expected_ship_week INT,
    week_no_expected_arival INT,
    created_by INT,
    modified_date DATETIME,                            -- SmallDatetime → DATETIME (closest match)
    inserted_date DATETIME,
    valid_from DATETIME,
    valid_to DATETIME,
    fk_brandid SMALLINT,
    skuproductcode STRING,
    inner_upccode STRING,
    master_upccode STRING
);


CREATE   TABLE  if not exists  ANALYTICS.InventoryWarehouseReceiptDetail (
    ID INT NOT NULL AUTOINCREMENT START  1 INCREMENT  1 order,
    Upc VARCHAR(100) NOT NULL,
    ExpectedQty INT NOT NULL,
    ReceivedQty INT,
    InventoryWarehouseReceiptID INT NOT NULL,
    DiscrepancyReason STRING, -- equivalent to VARCHAR(MAX)
    PackingListID INT,
    IncludedInIR DATETIME,
    Sku STRING, -- equivalent to NVARCHAR(MAX)
    IsUnexpectedUpc BOOLEAN,
    modifiedon DATETIME,
    PONumber VARCHAR(50),
    PRIMARY KEY (ID)
);


CREATE   TABLE  if not exists  ANALYTICS.InventoryWarehouseReceipt (
    ID INT NOT NULL AUTOINCREMENT START  1 INCREMENT  1 order,
    DateReceived DATETIME,
    WarehouseID INT NOT NULL,
    InventoryReleaseID INT NOT NULL,
    InventoryPackingListSummaryID INT NOT NULL,
    ContainerNumber VARCHAR(100)  NULL,
    DepartureDate DATETIME,
    modifiedon DATETIME,
    PRIMARY KEY (ID)
);


CREATE TABLE  if not exists ANALYTICS.InventoryRelease (
    ID INT NOT NULL AUTOINCREMENT  start 1 increment 1 order,
    DateLoaded TIMESTAMP NOT NULL,
    User VARCHAR(200),
    Name VARCHAR(255) NOT NULL,
    SourcingCategoryID INT,
    Notes VARCHAR(200),
    modifiedon TIMESTAMP
);


create  TABLE  if not exists ANALYTICS.INVENTORYPACKINGLISTSUMMARY (
	ID NUMBER(38,0) NOT NULL AUTOINCREMENT  start 1 increment 1 order,
	FILE VARCHAR(16777216),
	INVOICEID VARCHAR(16777216),
	INVOICEDATE TIMESTAMP_NTZ(9),
	DATELOADED TIMESTAMP_NTZ(9),
	INVENTORYRELEASEID NUMBER(38,0),
	DELETEDDATE TIMESTAMP_NTZ(9),
	NOTES VARCHAR(16777216),
	WAREHOUSEID NUMBER(38,0),
	MODIFIEDON TIMESTAMP_NTZ(9)
);

create  TABLE  if not exists ANALYTICS.INVENTORYPACKINGLIST (
	ID INT NOT NULL AUTOINCREMENT  start 1 increment 1 order,
	STORESKU VARCHAR(16777216),
	UPC VARCHAR(16777216),
	QTY NUMBER(38,0),
	WEIGHT VARCHAR(16777216),
	CBM FLOAT,
	CARTONNUMBER VARCHAR(16777216),
	UNITCOST FLOAT,
	PRODUCTDESCRIPTION VARCHAR(16777216),
	LENGTH VARCHAR(16777216),
	WIDTH VARCHAR(16777216),
	HEIGHT VARCHAR(16777216),
	INVOICEID VARCHAR(16777216),
	INVOICEDATE TIMESTAMP_NTZ(9),
	VESSEL VARCHAR(16777216),
	ORIGINPORT VARCHAR(16777216),
	DESTINATIONPORT VARCHAR(16777216),
	VOYAGEID VARCHAR(16777216),
	DEPARTUREDATE TIMESTAMP_NTZ(9),
	CARGORECEIVEDDATE TIMESTAMP_NTZ(9),
	NOTES VARCHAR(16777216),
	VENDOR VARCHAR(16777216),
	BILLOFLADING VARCHAR(16777216),
	TRANSPORTMODE VARCHAR(16777216),
	CONTAINERNUMBER VARCHAR(16777216),
	SEALNUMBER VARCHAR(16777216),
	SO_NUMBER VARCHAR(16777216),
	WAREHOUSEID NUMBER(38,0),
	PREVIOUSWAREHOUSEID NUMBER(38,0),
	REROUTEDATE TIMESTAMP_NTZ(9),
	INVENTORYRELEASEID NUMBER(38,0),
	INVENTORYPACKINGLISTSUMMARYID NUMBER(38,0),
	CONTAINERSIZE VARCHAR(16777216),
	MODIFIEDON TIMESTAMP_NTZ(9),
	DESTINATIONPORTID NUMBER(38,0)
);


CREATE   TABLE   if not exists ANALYTICS.InventoryPackingListHistory (
    ID INT NOT NULL AUTOINCREMENT  start 1 increment 1 order,
    StoreSku VARCHAR(100)  NULL,
    Upc VARCHAR(100)  NULL,
    Qty INT  NULL,
    Weight VARCHAR(50),
    CBM DECIMAL(19,5),
    CartonNumber VARCHAR(50)  NULL,
    UnitCost DECIMAL(19,5),
    ProductDescription VARCHAR(255)  NULL,
    Length VARCHAR(50),
    Width VARCHAR(50),
    Height VARCHAR(50),
    InvoiceID VARCHAR(100)  NULL,
    InvoiceDate DATETIME  NULL,
    Vessel VARCHAR(100),
    OriginPort VARCHAR(2000)  NULL,
    DestinationPort VARCHAR(2000)  NULL,
    VoyageID VARCHAR(100)  NULL,
    DepartureDate DATETIME  NULL,
    CargoReceivedDate DATETIME  NULL,
    Notes VARCHAR(500),
    Vendor VARCHAR(2000)  NULL,
    BillOfLading VARCHAR(100)  NULL,
    TransportMode VARCHAR(50),
    ContainerNumber VARCHAR(100)  NULL,
    SealNumber VARCHAR(100),
    SO_Number VARCHAR(100),
    WarehouseID INT,
    PreviousWarehouseID INT,
    RerouteDate DATETIME,
    InventoryReleaseID INT  NULL,
    InventoryPackingListSummaryID INT  NULL,
    LengthInInches FLOAT,
    WidthInInches FLOAT,
    HeightInInches FLOAT,
    WeightInPounds FLOAT
);
