USE DATABASE dev;

CREATE TABLE analytics.txn_klaviyo_back_in_stock_subscriptions
(
    klaviyo_event_id VARCHAR,
    sku              VARCHAR,
    email            VARCHAR,
    datetime         TIMESTAMPNTZ,
    fk_brandid       NUMBER,
    created_at       TIMESTAMPNTZ default CURRENT_TIMESTAMP(),
    updated_at       TIMESTAMPNTZ default CURRENT_TIMESTAMP()
);