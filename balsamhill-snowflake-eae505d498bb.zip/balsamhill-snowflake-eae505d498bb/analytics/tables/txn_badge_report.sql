USE DATABASE DEV;
USE SCHEMA analytics;

CREATE OR REPLACE TABLE analytics.txn_badge_report
(
    sku                               VARCHAR NOT NULL,
    family_name                       VARCHAR,
    parent_name                       VARCHAR,
    sku_variant_configuration_details VARCHAR,
    badge_on_pdp                      VARCHAR,
    badge_on_plp                      VARCHAR,
    future_stock_date                 TIMESTAMP_NTZ,
    inventory_last_updated_time       TIMESTAMP_NTZ,
    brand_id                          SMALLINT NOT NULL,
    report_run_time                   TIMESTAMP_NTZ NOT NULL,
    created_at                        TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    updated_at                        TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);