USE DATABASE dev;
USE SCHEMA analytics;

CREATE OR REPLACE TABLE analytics.txn_gladly_conversation (
      id                                  VARCHAR,
      conversation_id                     VARCHAR,
      content_type                        VARCHAR,
      content_to                          VARCHAR,
      content_from                        VARCHAR,
      content_subject                     VARCHAR,
      content_content                     VARCHAR,
      content_body                        VARCHAR,
      content_status                      VARCHAR,
      content_started_at                  VARCHAR,
      content_answered_at                 VARCHAR,
      content_completed_at                VARCHAR,
      content_recording_URL               VARCHAR,
      content_recording_status            VARCHAR,
      content_recording_duration          VARCHAR,
      content_message_type                VARCHAR,
      content_session_id                  VARCHAR,
      content_added_topic_ids             VARCHAR,
      customer_id                         VARCHAR,
      initiator_type                      VARCHAR,
      initiator_id                        VARCHAR,
      timestamp                           TIMESTAMP_NTZ,
      responder_type                      VARCHAR,
      responder_id                        VARCHAR,
      created_at                          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
      updated_at                          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);