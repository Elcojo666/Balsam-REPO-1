CREATE OR REPLACE TABLE analytics.pipeline_run_alerts_config (
    pipeline_name STRING,
    table_name STRING,
    frequency STRING, 
    threshold_time INT,
    aud_insert_date_column_name STRING,
    alert_type STRING,
    inserted_date TIMESTAMP_NTZ(9),
    modified_date TIMESTAMP_NTZ(9),
    comment STRING
);