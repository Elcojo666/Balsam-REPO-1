USE DATABASE dev;

CREATE TABLE analytics.txn_payment (
    pk_paymentid        NUMBER(38, 0)    NOT NULL autoincrement start 1 increment 1 noorder,
    transactionid       VARCHAR(200),
    ext_paymentid       VARCHAR(16777216),
    fk_sourceid         NUMBER(38, 0)    NOT NULL,
    fk_payment_methodid NUMBER(38, 0)    NOT NULL,
    fk_payment_typeid   NUMBER(38, 0)    NOT NULL,
    authorization_code  VARCHAR(200),
    avs_response        VARCHAR(50),
    cvv2_response       VARCHAR(50),
    payment_amount      NUMBER(9, 2)     NOT NULL,
    fk_currencyid       NUMBER(38, 0),
    payment_details     VARCHAR(16777216),
    isdeleted           BOOLEAN          NOT NULL,
    payment_date        TIMESTAMP_NTZ(9) NOT NULL,
    cc_last4            VARCHAR(55),
    fk_parent_paymentid NUMBER(38, 0),
    fk_order_headerid   NUMBER(38, 0),
    seq_no              NUMBER(38, 0),
    createddate         TIMESTAMP_NTZ(9),
    modified_date       TIMESTAMP_NTZ(9),
    primary key (pk_paymentid)
);

