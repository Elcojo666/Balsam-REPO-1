USE DATABASE DEV;
USE SCHEMA ANALYTICS;

CREATE OR REPLACE TABLE ANALYTICS.txn_shipnode_snapshot
(
    code                        VARCHAR,
    id                          VARCHAR,
    timestamp                   TIMESTAMP_NTZ,
    snapshotId                  VARCHAR,
    productId                   VARCHAR,
    segment                     VARCHAR,
    segmentType                 VARCHAR,
    shipNode                    INTEGER,
    onHandAvailableQuantity     INTEGER,
    fulfillmentAllowed          BOOLEAN,
    created_at                  TIMESTAMPNTZ DEFAULT CURRENT_TIMESTAMP(),
    updated_at                  TIMESTAMPNTZ DEFAULT CURRENT_TIMESTAMP()
);