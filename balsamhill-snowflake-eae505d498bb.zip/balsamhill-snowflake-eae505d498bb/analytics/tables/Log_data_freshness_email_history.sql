CREATE OR REPLACE TABLE analytics.Log_data_freshness_email_history (
    table_name STRING,
    last_inserted_time TIMESTAMP_NTZ(9),
    minutes_since_insert INT,
    frequency STRING,
    alert_type STRING,
    INSERTED_DATE TIMESTAMP_NTZ(9)
);
