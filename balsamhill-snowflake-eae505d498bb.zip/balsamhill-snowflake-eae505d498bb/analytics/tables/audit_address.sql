USE DATABASE dev;

CREATE TABLE analytics.audit_address (
    first_name        VARCHAR(255),
    last_name         VARCHAR(100),
    company_name      VARCHAR(100),
    phone_number      VARCHAR(255),
    address1          VARCHAR(255),
    address2          VARCHAR(255),
    city              VARCHAR(255),
    state             VARCHAR(255),
    country           VARCHAR(255),
    postal_code       VARCHAR(255),
    fk_address_typeid NUMBER(38, 0)    NOT NULL,
    inserted_date     TIMESTAMP_NTZ(9) NOT NULL,
    created_by        NUMBER(38, 0),
    modified_date     TIMESTAMP_NTZ(9),
    pk_addressid      NUMBER(38, 0)    NOT NULL,
    revision          NUMBER(38, 0),
    ext_address_id    VARCHAR(16777216),
    address3          VARCHAR(250),
    address4          VARCHAR(250),
    address5          VARCHAR(250),
    address6          VARCHAR(250)
);

