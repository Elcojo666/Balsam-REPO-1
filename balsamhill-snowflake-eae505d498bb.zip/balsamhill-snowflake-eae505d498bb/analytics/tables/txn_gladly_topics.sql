USE DATABASE dev;
USE SCHEMA analytics;

CREATE OR REPLACE TABLE analytics.txn_gladly_topics (
    id          VARCHAR,
    disabled    BOOLEAN,
    name        VARCHAR,
    created_at TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    updated_at TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);