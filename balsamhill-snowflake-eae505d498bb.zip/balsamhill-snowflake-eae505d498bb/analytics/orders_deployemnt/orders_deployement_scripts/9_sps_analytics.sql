use schema ANALYTICS;

CREATE PROCEDURE "USP_CHARGE_TRANSACTION_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,
    raw_table = ''raw_order_charge_transaction''
WHERE
    file_name = ''YFS_CHARGE_TRANSACTION'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
    
    
CREATE OR REPLACE TEMPORARY TABLE TempChargeTransaction (
    charge_transaction_key STRING,
    charge_type STRING,
    transfer_from_oh_key STRING,
    transfer_to_oh_key STRING,
    status STRING,
    credit_amount FLOAT,
    debit_amount FLOAT,
    book_amount FLOAT,
    open_authorized_amount FLOAT,
    request_amount FLOAT,
    distributed_amount FLOAT,
    settled_amount FLOAT,
    authorization_id STRING,
    authorization_expiration_date TIMESTAMP_NTZ(9),
    order_invoice_key STRING,
    order_header_key STRING,
    payment_key STRING,
    audit_transaction_id STRING,
    user_exit_status STRING,
    execution_date TIMESTAMP_NTZ(9),
    is_collection_date_firm STRING,
    collection_date TIMESTAMP_NTZ(9),
    hold_against_book STRING,
    in_person STRING,
    void_transaction STRING,
    postponed_amount FLOAT,
    offline_status STRING,
    call_for_auth_status STRING,
    cash_back_amount FLOAT,
    payment_entry_type STRING,
    async_request_identifier STRING,
    for_async_request_identifier STRING,
    reason_code STRING,
    createts TIMESTAMP_NTZ(9),
    modifyts TIMESTAMP_NTZ(9),
    createuserid STRING,
    modifyuserid STRING,
    createprogid STRING,
    modifyprogid STRING,
    lockid STRING,
    running_order_amount NUMBER(15,6),
    inserted_date TIMESTAMP_NTZ(9),
    modified_date TIMESTAMP_NTZ(9),
    revision INT
);

processedDate := current_timestamp();

CREATE OR REPLACE TEMPORARY TABLE TempChargeTransaction_running_order_amount (
    CHARGE_TRANSACTION_KEY VARCHAR(16777216),
    order_header_key VARCHAR(16777216),
    payment_key VARCHAR(16777216),
    CREDIT_AMOUNT VARCHAR(16777216),
    AUTHORIZATION_ID VARCHAR(16777216),
    running_order_amount NUMBER(15,6)
);

INSERT INTO TempChargeTransaction_running_order_amount (
    CHARGE_TRANSACTION_KEY,
    order_header_key,
    payment_key,
    CREDIT_AMOUNT,
    AUTHORIZATION_ID,
    running_order_amount
)
SELECT  
    CHARGE_TRANSACTION_KEY,
    order_header_key,
    payment_key,
    credit_amount,
    authorization_id,
    SUM(CAST(REQUEST_AMOUNT AS NUMBER(15,6))) OVER (PARTITION BY order_header_key ORDER BY createts ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_order_amount
FROM 
     TRANSFORMED.stg_order_charge_transaction
WHERE 
    authorization_id <> '''' --and order_header_key = ''20240903195400188447384'';
ORDER BY 
    order_header_key, createts;

MERGE INTO  ANALYTICS.txn_charge_transaction AS txn
USING (
    SELECT 
        sct.charge_transaction_key,
        charge_type,
        transfer_from_oh_key,
        transfer_to_oh_key,
        status,
        sct.credit_amount,
        debit_amount,
        book_amount,
        open_authorized_amount,
        request_amount,
        distributed_amount,
        settled_amount,
        sct.authorization_id,
        authorization_expiration_date,
        order_invoice_key,
        sct.order_header_key,
        sct.payment_key,
        audit_transaction_id,
        user_exit_status,
        execution_date,
        is_collection_date_firm,
        collection_date,
        hold_against_book,
        in_person,
        void_transaction,
        postponed_amount,
        offline_status,
        call_for_auth_status,
        cash_back_amount,
        payment_entry_type,
        async_request_identifier,
        for_async_request_identifier,
        reason_code,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        roamt.running_order_amount
    FROM TRANSFORMED.stg_order_charge_transaction sct
    left join TempChargeTransaction_running_order_amount roamt
        on roamt.authorization_id = sct.authorization_id and roamt.CHARGE_TRANSACTION_KEY = sct.CHARGE_TRANSACTION_KEY
) AS stg
ON txn.charge_transaction_key = stg.charge_transaction_key
WHEN MATCHED THEN
    UPDATE SET 
        txn.charge_transaction_key = stg.charge_transaction_key,
        txn.charge_type = stg.charge_type,
        txn.transfer_from_oh_key = stg.transfer_from_oh_key,
        txn.transfer_to_oh_key = stg.transfer_to_oh_key,
        txn.status = stg.status,
        txn.credit_amount = TRY_CAST(stg.credit_amount AS FLOAT),
        txn.debit_amount = TRY_CAST(stg.debit_amount AS FLOAT),
        txn.book_amount = TRY_CAST(stg.book_amount AS FLOAT),
        txn.open_authorized_amount = TRY_CAST(stg.open_authorized_amount AS FLOAT),
        txn.request_amount = TRY_CAST(stg.request_amount AS FLOAT),
        txn.distributed_amount = TRY_CAST(stg.distributed_amount AS FLOAT),
        txn.settled_amount = TRY_CAST(stg.settled_amount AS FLOAT),
        txn.authorization_id = stg.authorization_id,
        txn.authorization_expiration_date = TRY_TO_TIMESTAMP(stg.authorization_expiration_date,''YYYYMMDDHHMISS''),
        txn.order_invoice_key = stg.order_invoice_key,
        txn.order_header_key = stg.order_header_key,
        txn.payment_key = stg.payment_key,
        txn.audit_transaction_id = stg.audit_transaction_id,
        txn.user_exit_status = stg.user_exit_status,
        txn.execution_date = TRY_TO_TIMESTAMP(stg.execution_date,''YYYYMMDDHHMISS''),
        txn.is_collection_date_firm = stg.is_collection_date_firm,
        txn.collection_date = TRY_TO_TIMESTAMP(stg.collection_date,''YYYYMMDDHHMISS''),
        txn.hold_against_book = stg.hold_against_book,
        txn.in_person = stg.in_person,
        txn.void_transaction = stg.void_transaction,
        txn.postponed_amount = TRY_CAST(stg.postponed_amount AS FLOAT),
        txn.offline_status = stg.offline_status,
        txn.call_for_auth_status = stg.call_for_auth_status,
        txn.cash_back_amount = TRY_CAST(stg.cash_back_amount AS FLOAT),
        txn.payment_entry_type = stg.payment_entry_type,
        txn.async_request_identifier = stg.async_request_identifier,
        txn.for_async_request_identifier = stg.for_async_request_identifier,
        txn.reason_code = stg.reason_code,
        txn.createts = TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
        txn.modifyts = TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
        txn.createuserid = stg.createuserid,
        txn.modifyuserid = stg.modifyuserid,
        txn.createprogid = stg.createprogid,
        txn.modifyprogid = stg.modifyprogid,
        txn.lockid = stg.lockid,
        txn.running_order_amount = stg.running_order_amount,
        txn.modified_date = CURRENT_TIMESTAMP
WHEN NOT MATCHED THEN
    INSERT (
        charge_transaction_key,
        charge_type,
        transfer_from_oh_key,
        transfer_to_oh_key,
        status,
        credit_amount,
        debit_amount,
        book_amount,
        open_authorized_amount,
        request_amount,
        distributed_amount,
        settled_amount,
        authorization_id,
        authorization_expiration_date,
        order_invoice_key,
        order_header_key,
        payment_key,
        audit_transaction_id,
        user_exit_status,
        execution_date,
        is_collection_date_firm,
        collection_date,
        hold_against_book,
        in_person,
        void_transaction,
        postponed_amount,
        offline_status,
        call_for_auth_status,
        cash_back_amount,
        payment_entry_type,
        async_request_identifier,
        for_async_request_identifier,
        reason_code,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        running_order_amount,
        inserted_date
    ) VALUES (
        stg.charge_transaction_key,
        stg.charge_type,
        stg.transfer_from_oh_key,
        stg.transfer_to_oh_key,
        stg.status,
        TRY_CAST(stg.credit_amount AS FLOAT),
        TRY_CAST(stg.debit_amount AS FLOAT),
        TRY_CAST(stg.book_amount AS FLOAT),
        TRY_CAST(stg.open_authorized_amount AS FLOAT),
        TRY_CAST(stg.request_amount AS FLOAT),
        TRY_CAST(stg.distributed_amount AS FLOAT),
        TRY_CAST(stg.settled_amount AS FLOAT),
        stg.authorization_id ,
        TRY_TO_TIMESTAMP(stg.authorization_expiration_date,''YYYYMMDDHHMISS''),
        stg.order_invoice_key,
        stg.order_header_key,
        stg.payment_key,
        stg.audit_transaction_id,
        stg.user_exit_status,
        TRY_TO_TIMESTAMP(stg.execution_date,''YYYYMMDDHHMISS''),
        stg.is_collection_date_firm,
        TRY_TO_TIMESTAMP(stg.collection_date,''YYYYMMDDHHMISS''),
        stg.hold_against_book,
        stg.in_person,
        stg.void_transaction,
        TRY_CAST(stg.postponed_amount AS FLOAT),
        stg.offline_status,
        stg.call_for_auth_status,
        TRY_CAST(stg.cash_back_amount AS FLOAT),
        stg.payment_entry_type,
        stg.async_request_identifier,
        stg.for_async_request_identifier,
        stg.reason_code,
        TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
        stg.createuserid,
        stg.modifyuserid,
        stg.createprogid,
        stg.modifyprogid,
        stg.lockid,
        stg.running_order_amount,
        CURRENT_TIMESTAMP
    );

    

INSERT INTO TempChargeTransaction (
    charge_transaction_key,
    charge_type,
    transfer_from_oh_key,
    transfer_to_oh_key,
    status,
    credit_amount,
    debit_amount,
    book_amount,
    open_authorized_amount,
    request_amount,
    distributed_amount,
    settled_amount,
    authorization_id,
    authorization_expiration_date,
    order_invoice_key,
    order_header_key,
    payment_key,
    audit_transaction_id,
    user_exit_status,
    execution_date,
    is_collection_date_firm,
    collection_date,
    hold_against_book,
    in_person,
    void_transaction,
    postponed_amount,
    offline_status,
    call_for_auth_status,
    cash_back_amount,
    payment_entry_type,
    async_request_identifier,
    for_async_request_identifier,
    reason_code,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    running_order_amount,
    inserted_date,
    Revision
)
SELECT
    charge_transaction_key,
    charge_type,
    transfer_from_oh_key,
    transfer_to_oh_key,
    status,
    credit_amount,
    debit_amount,
    book_amount,
    open_authorized_amount,
    request_amount,
    distributed_amount,
    settled_amount,
    authorization_id,
    authorization_expiration_date,
    order_invoice_key,
    order_header_key,
    payment_key,
    audit_transaction_id,
    user_exit_status,
    execution_date,
    is_collection_date_firm,
    collection_date,
    hold_against_book,
    in_person,
    void_transaction,
    postponed_amount,
    offline_status,
    call_for_auth_status,
    cash_back_amount,
    payment_entry_type,
    async_request_identifier,
    for_async_request_identifier,
    reason_code,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    running_order_amount,
    inserted_date,
    1
FROM ANALYTICS.txn_charge_transaction tct
WHERE tct.inserted_date >= :processedDate or tct.modified_date > :processedDate
;

MERGE INTO TempChargeTransaction AS ttd
USING (
    SELECT
        aot.charge_transaction_key,
        MAX(aot.revision) AS revision
    FROM ANALYTICS.audit_charge_transaction AS aot
    INNER JOIN TempChargeTransaction AS ttd2
        ON ttd2.charge_transaction_key = aot.charge_transaction_key
    GROUP BY aot.charge_transaction_key
) AS aot
ON ttd.charge_transaction_key = aot.charge_transaction_key
WHEN MATCHED THEN
    UPDATE SET
        ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS int);

MERGE INTO RAW.raw_order_charge_transaction AS roh
USING (  
    SELECT distinct stg.charge_transaction_key
    FROM TRANSFORMED.stg_order_charge_transaction AS stg
    INNER JOIN ANALYTICS.txn_charge_transaction AS toh 
        ON toh.charge_transaction_key = stg.charge_transaction_key
) AS join_result
ON roh.charge_transaction_key = join_result.charge_transaction_key
WHEN MATCHED THEN
    UPDATE SET
        roh.processing_status = ''Processed'',
        roh.processing_comment = '''',
        roh.processing_errortype = '''';

INSERT INTO ANALYTICS.audit_charge_transaction (
    charge_transaction_key,
    charge_type,
    transfer_from_oh_key,
    transfer_to_oh_key,
    status,
    credit_amount,
    debit_amount,
    book_amount,
    open_authorized_amount,
    request_amount,
    distributed_amount,
    settled_amount,
    authorization_id,
    authorization_expiration_date,
    order_invoice_key,
    order_header_key,
    payment_key,
    audit_transaction_id,
    user_exit_status,
    execution_date,
    is_collection_date_firm,
    collection_date,
    hold_against_book,
    in_person,
    void_transaction,
    postponed_amount,
    offline_status,
    call_for_auth_status,
    cash_back_amount,
    payment_entry_type,
    async_request_identifier,
    for_async_request_identifier,
    reason_code,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    running_order_amount,
    inserted_date,
    Revision
)
SELECT distinct
    stg.charge_transaction_key,
    stg.charge_type,
    stg.transfer_from_oh_key,
    stg.transfer_to_oh_key,
    stg.status,
    TRY_CAST(stg.credit_amount AS FLOAT),
    TRY_CAST(stg.debit_amount AS FLOAT),
    TRY_CAST(stg.book_amount AS FLOAT),
    TRY_CAST(stg.open_authorized_amount AS FLOAT),
    TRY_CAST(stg.request_amount AS FLOAT),
    TRY_CAST(stg.distributed_amount AS FLOAT),
    TRY_CAST(stg.settled_amount AS FLOAT),
    stg.authorization_id,
    TRY_TO_TIMESTAMP(stg.authorization_expiration_date,''YYYYMMDDHHMISS''),
    stg.order_invoice_key,
    stg.order_header_key,
    stg.payment_key,
    stg.audit_transaction_id,
    stg.user_exit_status,
    TRY_TO_TIMESTAMP(stg.execution_date,''YYYYMMDDHHMISS''),
    stg.is_collection_date_firm,
    TRY_TO_TIMESTAMP(stg.collection_date,''YYYYMMDDHHMISS''),
    stg.hold_against_book,
    stg.in_person,
    stg.void_transaction,
    TRY_CAST(stg.postponed_amount AS FLOAT),
    stg.offline_status,
    stg.call_for_auth_status,
    TRY_CAST(stg.cash_back_amount AS FLOAT),
    stg.payment_entry_type,
    stg.async_request_identifier,
    stg.for_async_request_identifier,
    stg.reason_code,
    TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    ord.running_order_amount,
    CURRENT_TIMESTAMP,
    ord.Revision
FROM TRANSFORMED.stg_order_charge_transaction stg
INNER JOIN TempChargeTransaction ord
ON ord.charge_transaction_key = stg.charge_transaction_key;

SELECT COUNT(*)
INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_order_charge_transaction;

SELECT COUNT(*)
INTO :processedRecordCount
FROM TempChargeTransaction;

UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
WHERE file_name = ''YFS_CHARGE_TRANSACTION'';

DROP TABLE IF EXISTS TempChargeTransaction;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''upsert completed successfully''
    );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;
RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_CHARGE_TRANSACTION'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';

CREATE PROCEDURE "USP_CREDIT_CARD_TRANSACTION_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount,
    raw_table = ''raw_order_credit_card_transaction''
WHERE file_name = ''YFS_CREDIT_CARD_TRANSACTION'';

CREATE OR REPLACE TEMPORARY TABLE TempCreditCardTransaction (
    credit_card_transaction_key VARCHAR,
    charge_transaction_key VARCHAR,
    tran_type VARCHAR,
    tran_amount FLOAT,
    tran_request_time  TIMESTAMP_NTZ(9),
    tran_return_code VARCHAR,
    tran_return_message VARCHAR,
    tran_return_flag VARCHAR,
    request_id VARCHAR,
    internal_return_code VARCHAR,
    internal_return_flag VARCHAR,
    internal_return_message VARCHAR,
    auth_amount FLOAT,
    auth_code VARCHAR,
    auth_avs VARCHAR,
    auth_return_code VARCHAR,
    auth_return_flag VARCHAR,
    auth_return_message VARCHAR,
    auth_time  TIMESTAMP_NTZ(9),
    parent_key VARCHAR,
    reference1 VARCHAR,
    reference2 VARCHAR,
    cvv_auth_code VARCHAR,
    createts TIMESTAMP_NTZ(9),
    modifyts TIMESTAMP_NTZ(9),
    createuserid VARCHAR,
    modifyuserid VARCHAR,
    createprogid VARCHAR,
    modifyprogid VARCHAR,
    lockid VARCHAR,
    inserted_date TIMESTAMP_NTZ(9),
    modified_date TIMESTAMP_NTZ(9),
    revision INT
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.txn_credit_card_transaction txn
USING (
    SELECT
        credit_card_transaction_key,
        charge_transaction_key,
        tran_type,
        tran_amount,
        tran_request_time,
        tran_return_code,
        tran_return_message,
        tran_return_flag,
        request_id,
        internal_return_code,
        internal_return_flag,
        internal_return_message,
        auth_amount,
        auth_code,
        auth_avs,
        auth_return_code,
        auth_return_flag,
        auth_return_message,
        auth_time,
        parent_key,
        reference1,
        reference2,
        cvv_auth_code,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid
    FROM TRANSFORMED.stg_order_credit_card_transaction stg
) stg
ON txn.credit_card_transaction_key = stg.credit_card_transaction_key
WHEN MATCHED THEN
    UPDATE SET
        txn.charge_transaction_key = stg.charge_transaction_key,
        txn.tran_type = stg.tran_type,
        txn.tran_amount = TRY_CAST(stg.tran_amount AS FLOAT),
        txn.tran_request_time = TRY_TO_TIMESTAMP(stg.tran_request_time,''YYYYMMDDHHMISS''),
        txn.tran_return_code = stg.tran_return_code,
        txn.tran_return_message = stg.tran_return_message,
        txn.tran_return_flag = stg.tran_return_flag,
        txn.request_id = stg.request_id,
        txn.internal_return_code = stg.internal_return_code,
        txn.internal_return_flag = stg.internal_return_flag,
        txn.internal_return_message = stg.internal_return_message,
        txn.auth_amount = TRY_CAST(stg.auth_amount AS FLOAT),
        txn.auth_code = stg.auth_code,
        txn.auth_avs = stg.auth_avs,
        txn.auth_return_code = stg.auth_return_code,
        txn.auth_return_flag = stg.auth_return_flag,
        txn.auth_return_message = stg.auth_return_message,
        txn.auth_time = TRY_TO_TIMESTAMP(stg.auth_time,''YYYYMMDDHHMISS''),
        txn.parent_key = stg.parent_key,
        txn.reference1 = stg.reference1,
        txn.reference2 = stg.reference2,
        txn.cvv_auth_code = stg.cvv_auth_code,
        txn.createts = TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
        txn.modifyts = TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
        txn.createuserid = stg.createuserid,
        txn.modifyuserid = stg.modifyuserid,
        txn.createprogid = stg.createprogid,
        txn.modifyprogid = stg.modifyprogid,
        txn.lockid = stg.lockid,
        txn.modified_date = current_timestamp
WHEN NOT MATCHED THEN
    INSERT (
        credit_card_transaction_key,
        charge_transaction_key,
        tran_type,
        tran_amount,
        tran_request_time,
        tran_return_code,
        tran_return_message,
        tran_return_flag,
        request_id,
        internal_return_code,
        internal_return_flag,
        internal_return_message,
        auth_amount,
        auth_code,
        auth_avs,
        auth_return_code,
        auth_return_flag,
        auth_return_message,
        auth_time,
        parent_key,
        reference1,
        reference2,
        cvv_auth_code,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        inserted_date
    )
    VALUES (
        stg.credit_card_transaction_key,
        stg.charge_transaction_key,
        stg.tran_type,
        TRY_CAST(stg.tran_amount AS FLOAT),
        TRY_TO_TIMESTAMP(stg.tran_request_time,''YYYYMMDDHHMISS''),
        stg.tran_return_code,
        stg.tran_return_message,
        stg.tran_return_flag,
        stg.request_id,
        stg.internal_return_code,
        stg.internal_return_flag,
        stg.internal_return_message,
        TRY_CAST(stg.auth_amount AS FLOAT),
        stg.auth_code,
        stg.auth_avs,
        stg.auth_return_code,
        stg.auth_return_flag,
        stg.auth_return_message,
        TRY_TO_TIMESTAMP(stg.auth_time,''YYYYMMDDHHMISS''),
        stg.parent_key,
        stg.reference1,
        stg.reference2,
        stg.cvv_auth_code,
        TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
        stg.createuserid,
        stg.modifyuserid,
        stg.createprogid,
        stg.modifyprogid,
        stg.lockid,
        current_timestamp
    );

INSERT INTO TempCreditCardTransaction (
    credit_card_transaction_key,
    charge_transaction_key,
    tran_type,
    tran_amount,
    tran_request_time,
    tran_return_code,
    tran_return_message,
    tran_return_flag,
    request_id,
    internal_return_code,
    internal_return_flag,
    internal_return_message,
    auth_amount,
    auth_code,
    auth_avs,
    auth_return_code,
    auth_return_flag,
    auth_return_message,
    auth_time,
    parent_key,
    reference1,
    reference2,
    cvv_auth_code,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    revision
)
SELECT  stg.credit_card_transaction_key,
        stg.charge_transaction_key,
        stg.tran_type,
        stg.tran_amount,
        stg.tran_request_time,
        stg.tran_return_code,
        stg.tran_return_message,
        stg.tran_return_flag,
        stg.request_id,
        stg.internal_return_code,
        stg.internal_return_flag,
        stg.internal_return_message,
        stg.auth_amount,
        stg.auth_code,
        stg.auth_avs,
        stg.auth_return_code,
        stg.auth_return_flag,
        stg.auth_return_message,
        stg.auth_time,
        stg.parent_key,
        stg.reference1,
        stg.reference2,
        stg.cvv_auth_code,
        stg.createts,
        stg.modifyts,
        stg.createuserid,
        stg.modifyuserid,
        stg.createprogid,
        stg.modifyprogid,
        stg.lockid,
        current_timestamp, 1
FROM ANALYTICS.txn_credit_card_transaction stg
where stg.inserted_date > :processedDate or modified_date >= :processedDate;

CREATE OR REPLACE TEMPORARY TABLE TempAuditRevision AS
SELECT
    MAX(aot.revision) as revision,
    aot.credit_card_transaction_key
FROM
    ANALYTICS.audit_credit_card_transaction as aot
    INNER JOIN TempCreditCardTransaction as ttd
    ON ttd.credit_card_transaction_key = aot.credit_card_transaction_key
GROUP BY
    aot.credit_card_transaction_key;

UPDATE TempCreditCardTransaction ttd
SET ttd.Revision = CAST((coalesce(aot.revision, 0) + 1) as int)
FROM TempAuditRevision aot
WHERE ttd.credit_card_transaction_key = aot.credit_card_transaction_key;


-- UPDATE RAW.raw_order_credit_card_transaction AS roh
-- SET roh.processing_status = ''Processed'',
--     roh.processing_comment = '''',
--     roh.processing_errortype = ''''
-- FROM (select stg.credit_card_transaction_key from TRANSFORMED.stg_order_credit_card_transaction AS stg
--     JOIN ANALYTICS.txn_credit_card_transaction AS toh
--     ON toh.credit_card_transaction_key = stg.credit_card_transaction_key)stgt
--     WHERE stgt.credit_card_transaction_key = roh.credit_card_transaction_key;

UPDATE RAW.raw_order_credit_card_transaction AS roh
SET 
    roh.processing_status = ''Processed'',
    roh.processing_comment = '''',
    roh.processing_errortype = ''''
FROM TRANSFORMED.stg_order_credit_card_transaction AS stg
INNER JOIN ANALYTICS.txn_credit_card_transaction AS toh
    ON toh.credit_card_transaction_key = stg.credit_card_transaction_key
WHERE roh.credit_card_transaction_key = stg.credit_card_transaction_key;

-- Insert data into audit_credit_card_transaction
INSERT INTO ANALYTICS.audit_credit_card_transaction (
    credit_card_transaction_key,
    charge_transaction_key,
    tran_type,
    tran_amount,
    tran_request_time,
    tran_return_code,
    tran_return_message,
    tran_return_flag,
    request_id,
    internal_return_code,
    internal_return_flag,
    internal_return_message,
    auth_amount,
    auth_code,
    auth_avs,
    auth_return_code,
    auth_return_flag,
    auth_return_message,
    auth_time,
    parent_key,
    reference1,
    reference2,
    cvv_auth_code,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    Revision
)
SELECT
    stg.credit_card_transaction_key,
    stg.charge_transaction_key,
    stg.tran_type,
    TRY_CAST(stg.tran_amount AS FLOAT),
    TRY_TO_TIMESTAMP(stg.tran_request_time,''YYYYMMDDHHMISS''),
    stg.tran_return_code,
    stg.tran_return_message,
    stg.tran_return_flag,
    stg.request_id,
    stg.internal_return_code,
    stg.internal_return_flag,
    stg.internal_return_message,
    TRY_CAST(stg.auth_amount AS FLOAT),
    stg.auth_code,
    stg.auth_avs,
    stg.auth_return_code,
    stg.auth_return_flag,
    stg.auth_return_message,
    TRY_TO_TIMESTAMP(stg.auth_time,''YYYYMMDDHHMISS''),
    stg.parent_key,
    stg.reference1,
    stg.reference2,
    stg.cvv_auth_code,
     TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
     TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    CURRENT_TIMESTAMP(),  -- Use CURRENT_TIMESTAMP() for the current date and time
    ord.Revision
FROM TRANSFORMED.stg_order_credit_card_transaction stg
INNER JOIN TempCreditCardTransaction ord
ON ord.credit_card_transaction_key = stg.credit_card_transaction_key;

SELECT COUNT(*)
INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_order_credit_card_transaction;

-- Calculate the count of records from TempCreditCardTransaction
SELECT COUNT(*)
INTO :processedRecordCount
FROM TempCreditCardTransaction;

UPDATE log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
WHERE file_name = ''YFS_CREDIT_CARD_TRANSACTION'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

-- Drop temporary table
DROP TABLE IF EXISTS TempCreditCardTransaction;
COMMIT;
RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_CREDIT_CARD_TRANSACTION'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';

CREATE PROCEDURE "USP_EXT_ADDRESS_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 'DECLARE 
    processedDate TIMESTAMP_NTZ(9);
    start_time_proc TIMESTAMP_NTZ(9);
    error_object VARIANT;
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
        -- Creating a temporary table with columns similar to the original SQL Server code
    CREATE OR REPLACE TEMPORARY TABLE TempExtAddress (
        ext_address_id STRING,
        person_id STRING,
        title STRING,
        suffix STRING,
        department STRING,
        job_title STRING,
        day_phone STRING,
        evening_phone STRING,
        mobile_phone STRING,
        beeper STRING,
        other_phone STRING,
        day_fax_no STRING,
        evening_fax_no STRING,
        emailid STRING,
        alternate_emailid STRING,
        preferred_ship_address STRING,
        http_url STRING,
        use_count STRING,
        verification_status STRING,
        is_address_verified STRING,
        latitude FLOAT,
        longitude FLOAT,
        tax_geo_code STRING,
        error_txt STRING,
        is_commercial_address STRING,
        time_zone STRING,
        lockid STRING,
        createts TIMESTAMP,
        modifyts TIMESTAMP,
        createuserid STRING,
        modifyuserid STRING,
        createprogid STRING,
        modifyprogid STRING,
        address_id STRING,
        short_zip_code STRING,
        last_updated_date TIMESTAMP,
        revision INT NOT NULL
    );
 processedDate := current_timestamp();

    -- Merge logic to update or insert records in ext_address
    MERGE INTO  analytics.ext_address AS tgt
    USING (
        SELECT DISTINCT
            stg.person_info_key,
            stg.person_id,
            stg.title,
            stg.suffix,
            stg.department,
            stg.job_title,
            stg.day_phone,
            stg.evening_phone,
            stg.mobile_phone,
            stg.beeper,
            stg.other_phone,
            stg.day_fax_no,
            stg.evening_fax_no,
            stg.emailid,
            stg.alternate_emailid,
            stg.preferred_ship_address,
            stg.http_url,
            stg.use_count,
            stg.verification_status,
            stg.is_address_verified,
            TRY_CAST(stg.latitude AS FLOAT) AS latitude,
            TRY_CAST(stg.longitude AS FLOAT) AS longitude,
            stg.tax_geo_code,
            stg.error_txt,
            stg.is_commercial_address,
            stg.time_zone,
            stg.lockid,
            TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'') AS createts,
            TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'') AS modifyts,
            stg.createuserid,
            stg.modifyuserid,
            stg.createprogid,
            stg.modifyprogid,
            stg.address_id,
            stg.short_zip_code
        FROM transformed.stg_order_person_info stg
        INNER JOIN raw.raw_order_person_info r
            ON stg.person_info_key = r.person_info_key
            AND stg.modifyts = r.modifyts
            AND r.processing_status = ''Processed''
    ) AS src
    ON tgt.ext_address_id = src.person_info_key
    WHEN MATCHED THEN
        UPDATE SET
            tgt.person_id = src.person_id,
            tgt.title = src.title,
            tgt.suffix = src.suffix,
            tgt.department = src.department,
            tgt.job_title = src.job_title,
            tgt.day_phone = src.day_phone,
            tgt.evening_phone = src.evening_phone,
            tgt.mobile_phone = src.mobile_phone,
            tgt.other_phone = src.other_phone,
            tgt.day_fax_no = src.day_fax_no,
            tgt.evening_fax_no = src.evening_fax_no,
            tgt.emailid = src.emailid,
            tgt.alternate_emailid = src.alternate_emailid,
            tgt.preferred_ship_address = src.preferred_ship_address,
            tgt.http_url = src.http_url,
            tgt.use_count = src.use_count,
            tgt.verification_status = src.verification_status,
            tgt.is_address_verified = src.is_address_verified,
            tgt.latitude = src.latitude,
            tgt.longitude = src.longitude,
            tgt.tax_geo_code = src.tax_geo_code,
            tgt.error_txt = src.error_txt,
            tgt.is_commercial_address = src.is_commercial_address,
            tgt.time_zone = src.time_zone,
            tgt.lockid = src.lockid,
            tgt.createts = src.createts,
            tgt.modifyts = src.modifyts,
            tgt.createuserid = src.createuserid,
            tgt.modifyuserid = src.modifyuserid,
            tgt.createprogid = src.createprogid,
            tgt.modifyprogid = src.modifyprogid,
            tgt.address_id = src.address_id,
            tgt.short_zip_code = src.short_zip_code,
            tgt.last_updated_date = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
            ext_address_id, person_id, title, suffix, department, job_title, day_phone, evening_phone, mobile_phone,
            beeper, other_phone, day_fax_no, evening_fax_no, emailid, alternate_emailid, preferred_ship_address, http_url,
            use_count, verification_status, is_address_verified, latitude, longitude, tax_geo_code, error_txt,
            is_commercial_address, time_zone, lockid, createts, modifyts, createuserid, modifyuserid, createprogid,
            modifyprogid, address_id, short_zip_code, last_updated_date
        )
        VALUES (
            src.person_info_key, src.person_id, src.title, src.suffix, src.department, src.job_title, src.day_phone,
            src.evening_phone, src.mobile_phone, src.beeper, src.other_phone, src.day_fax_no, src.evening_fax_no,
            src.emailid, src.alternate_emailid, src.preferred_ship_address, src.http_url, src.use_count,
            src.verification_status, src.is_address_verified, src.latitude, src.longitude, src.tax_geo_code,
            src.error_txt, src.is_commercial_address, src.time_zone, src.lockid, src.createts, src.modifyts,
            src.createuserid, src.modifyuserid, src.createprogid, src.modifyprogid, src.address_id, src.short_zip_code,
            CURRENT_TIMESTAMP()
        );

        INSERT INTO TempExtAddress 
						(ext_address_id,
						 person_id ,
						title ,
						suffix ,
						department ,
						job_title ,
						day_phone ,
						evening_phone,
						mobile_phone,
						beeper,
						other_phone,
						day_fax_no,
						evening_fax_no,
						emailid,
						alternate_emailid,
						preferred_ship_address ,
						http_url,
						use_count,
						verification_status,
						is_address_verified,
						latitude,
						longitude,
						tax_geo_code,
						error_txt,
						is_commercial_address,
						time_zone,
						lockid,
						createts,
						modifyts,
						createuserid,
						modifyuserid,
						createprogid,
						modifyprogid,
						address_id ,
						short_zip_code,
						last_updated_date,
						revision)
                        select 
                        inserted.ext_address_id,
						inserted. person_id ,
						inserted.title ,
						inserted.suffix ,
						inserted.department ,
						inserted.job_title ,
						inserted.day_phone ,
						inserted.evening_phone,
						inserted.mobile_phone,
						inserted.beeper,
						inserted.other_phone,
						inserted.day_fax_no,
						inserted.evening_fax_no,
						inserted.emailid,
						inserted.alternate_emailid,
						inserted.preferred_ship_address ,
						inserted.http_url,
						inserted.use_count,
						inserted.verification_status,
						inserted.is_address_verified,
						inserted.latitude,
						inserted.longitude,
						inserted.tax_geo_code,
						inserted.error_txt,
						inserted.is_commercial_address,
						inserted.time_zone,
						inserted.lockid,
						inserted.createts,
						inserted.modifyts,
						inserted.createuserid,
						inserted.modifyuserid,
						inserted.createprogid,
						inserted.modifyprogid,
						inserted.address_id ,
						inserted.short_zip_code,
						inserted.last_updated_date,
						1
                      from analytics.ext_address inserted
                      where inserted.last_updated_date >= :processedDate ; 

    -- Update revision in TempExtAddress
    MERGE INTO TempExtAddress ttd
USING (
    SELECT
        MAX(aot.revision) AS revision,
        aot.ext_address_id
    FROM  analytics.audit_ext_address aot
    INNER JOIN TempExtAddress ttd 
        ON ttd.ext_address_id = aot.ext_address_id
    GROUP BY aot.ext_address_id
) aot
ON ttd.ext_address_id = aot.ext_address_id
WHEN MATCHED THEN
    UPDATE SET 
        ttd.revision = COALESCE(aot.revision, 0) + 1;


    -- Insert into audit_ext_address table
    INSERT INTO analytics.audit_ext_address (
        ext_address_id, person_id, title, suffix, department, job_title, day_phone, evening_phone, mobile_phone, beeper,
        other_phone, day_fax_no, evening_fax_no, emailid, alternate_emailid, preferred_ship_address, http_url, use_count,
        verification_status, is_address_verified, latitude, longitude, tax_geo_code, error_txt, is_commercial_address,
        time_zone, lockid, createts, modifyts, createuserid, modifyuserid, createprogid, modifyprogid, address_id,
        short_zip_code, last_updated_date, revision
    )
    SELECT
        stg.person_info_key, stg.person_id, stg.title, stg.suffix, stg.department, stg.job_title, stg.day_phone,
        stg.evening_phone, stg.mobile_phone, stg.beeper, stg.other_phone, stg.day_fax_no, stg.evening_fax_no,
        stg.emailid, stg.alternate_emailid, stg.preferred_ship_address, stg.http_url, stg.use_count,
        stg.verification_status, stg.is_address_verified, 
        TRY_CAST(stg.latitude AS FLOAT) AS latitude,
            TRY_CAST(stg.longitude AS FLOAT) AS longitude,
            stg.tax_geo_code,
            stg.error_txt,
            stg.is_commercial_address,
            stg.time_zone,
            stg.lockid,
            TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'') AS createts,
            TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'') AS modifyts,
             stg.createuserid,
        stg.modifyuserid, stg.createprogid, stg.modifyprogid, stg.address_id, stg.short_zip_code, CURRENT_TIMESTAMP,
        ord.revision
    FROM transformed.stg_order_person_info stg
    INNER JOIN raw.raw_order_person_info r
        ON stg.person_info_key = r.person_info_key
        AND stg.modifyts = r.modifyts
        AND r.processing_status = ''Processed''
    INNER JOIN TempExtAddress ord ON ord.ext_address_id = stg.person_info_key;

    -- Commit the transaction
 CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;

RETURN ''Success'';
EXCEPTION 
WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
            
    RETURN sqlerrm;
END';
CREATE PROCEDURE "USP_EXT_DELIVERED_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    processedDate TIMESTAMP_NTZ(9);
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE TempExtDelivered (
    external_Id TEXT NULL,
    pick_list_no TEXT NULL,
    original_shipment_key TEXT NULL,
    merge_node TEXT NULL,
    pickticket_no TEXT NULL,
    ship_date TIMESTAMP NULL,
    unplaced_quantity TEXT NULL,
    shipnode_key TEXT NULL,
    receiving_node TEXT NULL,
    buyer_receiving_node_id TEXT NULL,
    shipment_consol_group_id TEXT NULL,
    ship_mode TEXT NULL,
    from_address_key TEXT NULL,
    to_address_key TEXT NULL,
    bill_to_address_key TEXT NULL,
    ship_to_customer_id TEXT NULL,
    bill_to_customer_id TEXT NULL,
    has_other_shipments TEXT NULL,
    parent_shipment_key TEXT NULL,
    ship_via TEXT NULL,
    seal_no TEXT NULL,
    tracking_no TEXT NULL,
    trailer_no TEXT NULL,
    manifest_no TEXT NULL,
    pro_no TEXT NULL,
    scac TEXT NULL,
    actual_freight_charge TEXT NULL,
    carrier_service_code TEXT NULL,
    requested_carrier_service_code TEXT NULL,
    status TEXT NULL,
    pod_no TEXT NULL,
    bol_no TEXT NULL,
    total_weight TEXT NULL,
    total_weight_uom TEXT NULL,
    total_volume TEXT NULL,
    total_volume_uom TEXT NULL,
    total_quantity TEXT NULL,
    containerized_quantity TEXT NULL,
    placed_quantity TEXT NULL,
    is_product_placing_complete TEXT NULL,
    is_pack_process_complete TEXT NULL,
    is_revised TEXT NULL,
    hold_flag TEXT NULL,
    it_no TEXT NULL,
    it_date TIMESTAMP NULL,
    appointment_no TEXT NULL,
    from_appointment TEXT NULL,
    to_appointment TEXT NULL,
    delivery_ts TEXT NULL,
    code TEXT NULL,
    num_of_pallets TEXT NULL,
    num_of_cartons TEXT NULL,
    export_taxpayer_id TEXT NULL,
    freight_terms TEXT NULL,
    delivery_code TEXT NULL,
    carrier_type TEXT NULL,
    download_count TEXT NULL,
    currency TEXT NULL,
    delivery_plan_key TEXT NULL,
    shipment_no TEXT NULL,
    pipeline_key TEXT NULL,
    gift_flag TEXT NULL,
    shipment_planned_flag TEXT NULL,
    shipment_closed_flag TEXT NULL,
    seller_organization_code TEXT NULL,
    buyer_organization_code TEXT NULL,
    enterprise_code TEXT NULL,
    requested_shipment_date TIMESTAMP NULL,
    expected_shipment_date TIMESTAMP NULL,
    actual_shipment_date TIMESTAMP NULL,
    requested_delivery_date TIMESTAMP NULL,
    expected_delivery_date TIMESTAMP NULL,
    actual_delivery_date TIMESTAMP NULL,
    return_by_date TIMESTAMP NULL,
    return_authorization_number TEXT NULL,
    document_type TEXT NULL,
    origin_zone TEXT NULL,
    destination_zone TEXT NULL,
    status_date TIMESTAMP NULL,
    shipment_type TEXT NULL,
    commercial_value TEXT NULL,
    hazardous_material_flag TEXT NULL,
    total_estimated_charge TEXT NULL,
    total_actual_charge TEXT NULL,
    next_alert_ts TEXT NULL,
    shipment_confirm_updates_done TEXT NULL,
    shipment_deliver_updates_done TEXT NULL,
    shipment_containerized_flag TEXT NULL,
    scac_integration_required TEXT NULL,
    packlist_type TEXT NULL,
    custcarrier_account_no TEXT NULL,
    manifest_key TEXT NULL,
    is_single_order TEXT NULL,
    lines_entered TEXT NULL,
    order_available_on_system TEXT NULL,
    override_manual_shipment_entry TEXT NULL,
    do_not_verify_pallet_content TEXT NULL,
    do_not_verify_case_content TEXT NULL,
    allow_overage TEXT NULL,
    manually_entered TEXT NULL,
    allow_new_item_receipt TEXT NULL,
    order_no TEXT NULL,
    order_header_key TEXT NULL,
    release_no TEXT NULL,
    order_release_key TEXT NULL,
    export_license_no TEXT NULL,
    export_license_exp_date TIMESTAMP NULL,
    delivery_method TEXT NULL,
    requires_appt_confirmation TEXT NULL,
    work_order_key TEXT NULL,
    work_order_appt_key TEXT NULL,
    order_type TEXT NULL,
    do_not_consolidate TEXT NULL,
    department_code TEXT NULL,
    item_classification TEXT NULL,
    mark_for_key TEXT NULL,
    buyer_mark_for_node_id TEXT NULL,
    routing_contact_info TEXT NULL,
    customer_po_no TEXT NULL,
    carrier_pickup_time TEXT NULL,
    pack_and_hold TEXT NULL,
    esp_check_required TEXT NULL,
    is_appointment_reqd TEXT NULL,
    routing_source TEXT NULL,
    routing_error_code TEXT NULL,
    routing_guide_maintained TEXT NULL,
    must_ship_before_date TIMESTAMP NULL,
    priority_code TEXT NULL,
    estimated_price TEXT NULL,
    has_node_exceptions TEXT NULL,
    cod_pay_method TEXT NULL,
    airway_bill_no TEXT NULL,
    invoice_complete TEXT NULL,
    expected_pick_date TIMESTAMP NULL,
    return_carrier_service TEXT NULL,
    return_freight_terms TEXT NULL,
    return_billing_account TEXT NULL,
    break_bulk_node TEXT NULL,
    bbn_min_weight TEXT NULL,
    bbn_min_volume TEXT NULL,
    fedx_open_ship_index TEXT NULL,
    itn_no TEXT NULL,
    email_return_label TEXT NULL,
    profile_id TEXT NULL,
    profileid_provided_by_sterling TEXT NULL,
    level_of_service TEXT NULL,
    hold_location TEXT NULL,
    assigned_to_user_id TEXT NULL,
    lockid TEXT NULL,
    createts TIMESTAMP NULL,
    modifyts TIMESTAMP NULL,
    createuserid TEXT NULL,
    modifyuserid TEXT NULL,
    createprogid TEXT NULL,
    modifyprogid TEXT NULL,
    shipment_sort_location_id TEXT NULL,
    carrier_sort_location_id TEXT NULL,
    shipment_group_id TEXT NULL,
    notification_sent TEXT NULL,
    pickticket_printed TEXT NULL,
    backroom_pick_required TEXT NULL,
    included_in_batch TEXT NULL,
    is_receiving_complete TEXT NULL,
    received_damaged TEXT NULL,
    index_version TEXT NULL,
    extn_narvar_url TEXT NULL,
    extn_is_sent TEXT NULL,
    last_updated_date TIMESTAMP NULL,
    revision INTEGER NOT NULL
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.EXT_ORDER_DELIVERED AS tgt
USING (
    SELECT DISTINCT 
        shipment_key,
        pick_list_no,
        original_shipment_key,
        merge_node,
        pickticket_no,
        ship_date,
        TRY_TO_NUMBER(unplaced_quantity) AS unplaced_quantity,
        shipnode_key,
        receiving_node,
        buyer_receiving_node_id,
        shipment_consol_group_id,
        ship_mode,
        from_address_key,
        to_address_key,
        bill_to_address_key,
        ship_to_customer_id,
        bill_to_customer_id,
        has_other_shipments,
        parent_shipment_key,
        ship_via,
        seal_no,
        tracking_no,
        trailer_no,
        manifest_no,
        pro_no,
        scac,
        TRY_CAST(actual_freight_charge AS FLOAT) AS actual_freight_charge,
        carrier_service_code,
        requested_carrier_service_code,
        status,
        pod_no,
        bol_no,
        TRY_CAST(total_weight AS FLOAT) AS total_weight,
        total_weight_uom,
        TRY_CAST(total_volume AS FLOAT ) AS total_volume,
        total_volume_uom,
        TRY_TO_NUMBER(total_quantity) AS total_quantity,
        TRY_TO_NUMBER(containerized_quantity) AS containerized_quantity,
        TRY_TO_NUMBER(placed_quantity) AS placed_quantity,
        is_product_placing_complete,
        is_pack_process_complete,
        is_revised,
        hold_flag,
        it_no,
        it_date,
        appointment_no,
        from_appointment,
        to_appointment,
        TRY_TO_TIMESTAMP(delivery_ts  ,''YYYYMMDDHHMISS'') as delivery_ts,
        code,
        TRY_TO_NUMBER(num_of_pallets) AS num_of_pallets,
        TRY_TO_NUMBER(num_of_cartons) AS num_of_cartons,
        export_taxpayer_id,
        freight_terms,
        delivery_code,
        carrier_type,
        download_count,
        currency,
        delivery_plan_key,
        shipment_no,
        pipeline_key,
        gift_flag,
        shipment_planned_flag,
        shipment_closed_flag,
        seller_organization_code,
        buyer_organization_code,
        enterprise_code,
        requested_shipment_date,
        expected_shipment_date,
        actual_shipment_date,
        requested_delivery_date,
        expected_delivery_date,
        actual_delivery_date,
        return_by_date,
        return_authorization_number,
        document_type,
        origin_zone,
        destination_zone,
        status_date,
        shipment_type,
        commercial_value,
        hazardous_material_flag,
        total_estimated_charge,
        total_actual_charge,
        next_alert_ts,
        shipment_confirm_updates_done,
        shipment_deliver_updates_done,
        shipment_containerized_flag,
        scac_integration_required,
        packlist_type,
        custcarrier_account_no,
        manifest_key,
        is_single_order,
        lines_entered,
        order_available_on_system,
        override_manual_shipment_entry,
        do_not_verify_pallet_content,
        do_not_verify_case_content,
        allow_overage,
        manually_entered,
        allow_new_item_receipt,
        order_no,
        order_header_key,
        release_no,
        order_release_key,
        export_license_no,
        export_license_exp_date,
        delivery_method,
        requires_appt_confirmation,
        work_order_key,
        work_order_appt_key,
        order_type,
        do_not_consolidate,
        department_code,
        item_classification,
        mark_for_key,
        buyer_mark_for_node_id,
        routing_contact_info,
        customer_po_no,
        TRY_TO_TIMESTAMP(carrier_pickup_time   ,''YYYYMMDDHHMISS'')  AS carrier_pickup_time,
        pack_and_hold,
        esp_check_required,
        is_appointment_reqd,
        routing_source,
        routing_error_code,
        routing_guide_maintained,
        must_ship_before_date,
        priority_code,
        estimated_price,
        has_node_exceptions,
        cod_pay_method,
        airway_bill_no,
        invoice_complete,
        expected_pick_date,
        return_carrier_service,
        return_freight_terms,
        return_billing_account,
        break_bulk_node,
        TRY_CAST(bbn_min_weight AS FLOAT ) as bbn_min_weight,
        TRY_CAST(bbn_min_volume AS FLOAT ) as bbn_min_volume,
        fedx_open_ship_index,
        itn_no,
        email_return_label,
        profile_id,
        profileid_provided_by_sterling,
        level_of_service,
        hold_location,
        assigned_to_user_id,
        lockid,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        shipment_sort_location_id,
        carrier_sort_location_id,
        shipment_group_id,
        notification_sent,
        pickticket_printed,
        backroom_pick_required,
        included_in_batch,
        is_receiving_complete,
        received_damaged,
        index_version,
        extn_narvar_url,
        extn_is_sent
    FROM TRANSFORMED.STG_ORDER_SHIPMENT 
) AS src
ON src.shipment_key = tgt.external_id
WHEN MATCHED THEN UPDATE SET 
			tgt.external_Id  =  src.shipment_key    ,
			tgt.pick_list_no  =  src.pick_list_no    ,
			tgt.original_shipment_key  =  src.original_shipment_key    ,
			tgt.merge_node  =  src.merge_node    ,
			tgt.pickticket_no  =  src.pickticket_no    ,
			tgt.ship_date  =  TRY_TO_TIMESTAMP(src.ship_date ,''YYYYMMDDHHMISS'')   ,
			tgt.unplaced_quantity  =  src.unplaced_quantity    ,
			tgt.shipnode_key  =  src.shipnode_key    ,
			tgt.receiving_node  =  src.receiving_node    ,
			tgt.buyer_receiving_node_id  =  src.buyer_receiving_node_id    ,
			tgt.shipment_consol_group_id  =  src.shipment_consol_group_id    ,
			tgt.ship_mode  =  src.ship_mode    ,
			tgt.from_address_key  =  src.from_address_key    ,
			tgt.to_address_key  =  src.to_address_key    ,
			tgt.bill_to_address_key  =  src.bill_to_address_key    ,
			tgt.ship_to_customer_id  =  src.ship_to_customer_id    ,
			tgt.bill_to_customer_id  =  src.bill_to_customer_id    ,
			tgt.has_other_shipments  =  src.has_other_shipments    ,
			tgt.parent_shipment_key  =  src.parent_shipment_key    ,
			tgt.ship_via  =  src.ship_via    ,
			tgt.seal_no  =  src.seal_no    ,
			tgt.tracking_no  =  src.tracking_no    ,
			tgt.trailer_no  =  src.trailer_no    ,
			tgt.manifest_no  =  src.manifest_no    ,
			tgt.pro_no  =  src.pro_no    ,
			tgt.scac  =  src.scac    ,
			tgt.actual_freight_charge  =  src.actual_freight_charge    ,
			tgt.carrier_service_code  =  src.carrier_service_code    ,
			tgt.requested_carrier_service_code  =  src.requested_carrier_service_code    ,
			tgt.status  =  src.status    ,
			tgt.pod_no  =  src.pod_no    ,
			tgt.bol_no  =  src.bol_no    ,
			tgt.total_weight  =  src.total_weight    ,
			tgt.total_weight_uom  =  src.total_weight_uom    ,
			tgt.total_volume  =  src.total_volume    ,
			tgt.total_volume_uom  =  src.total_volume_uom    ,
			tgt.total_quantity  =  src.total_quantity    ,
			tgt.containerized_quantity  =  src.containerized_quantity    ,
			tgt.placed_quantity  =  src.placed_quantity    ,
			tgt.is_product_placing_complete  =  src.is_product_placing_complete    ,
			tgt.is_pack_process_complete  =  src.is_pack_process_complete    ,
			tgt.is_revised  =  src.is_revised    ,
			tgt.hold_flag  =  src.hold_flag    ,
			tgt.it_no  =  src.it_no    ,
			tgt.it_date  =  TRY_TO_TIMESTAMP(src.it_date  ,''YYYYMMDDHHMISS'')    ,
			tgt.appointment_no  =  src.appointment_no    ,
			tgt.from_appointment  =  src.from_appointment    ,
			tgt.to_appointment  =  src.to_appointment    ,
			tgt.delivery_ts  =  src.delivery_ts    ,
			tgt.code  =  src.code    ,
			tgt.num_of_pallets  =  src.num_of_pallets    ,
			tgt.num_of_cartons  =  src.num_of_cartons    ,
			tgt.export_taxpayer_id  =  src.export_taxpayer_id    ,
			tgt.freight_terms  =  src.freight_terms    ,
			tgt.delivery_code  =  src.delivery_code    ,
			tgt.carrier_type  =  src.carrier_type    ,
			tgt.download_count  =  src.download_count    ,
			tgt.currency  =  src.currency    ,
			tgt.delivery_plan_key  =  src.delivery_plan_key    ,
			tgt.shipment_no  =  src.shipment_no    ,
			tgt.pipeline_key  =  src.pipeline_key    ,
			tgt.gift_flag  =  src.gift_flag    ,
			tgt.shipment_planned_flag  =  src.shipment_planned_flag    ,
			tgt.shipment_closed_flag  =  src.shipment_closed_flag    ,
			tgt.seller_organization_code  =  src.seller_organization_code    ,
			tgt.buyer_organization_code  =  src.buyer_organization_code    ,
			tgt.enterprise_code  =  src.enterprise_code    ,
			tgt.requested_shipment_date  = TRY_TO_TIMESTAMP(src.requested_shipment_date   ,''YYYYMMDDHHMISS'')    ,
			tgt.expected_shipment_date  =  TRY_TO_TIMESTAMP(src.expected_shipment_date   ,''YYYYMMDDHHMISS'')    ,
			tgt.actual_shipment_date  =  TRY_TO_TIMESTAMP(src.actual_shipment_date   ,''YYYYMMDDHHMISS'')   ,
			tgt.requested_delivery_date  = TRY_TO_TIMESTAMP(src.requested_delivery_date    ,''YYYYMMDDHHMISS'')     ,
			tgt.expected_delivery_date  =  TRY_TO_TIMESTAMP(src.expected_delivery_date    ,''YYYYMMDDHHMISS'')    ,
			tgt.actual_delivery_date  =  TRY_TO_TIMESTAMP(src.actual_delivery_date    ,''YYYYMMDDHHMISS'')    ,
			tgt.return_by_date  = TRY_TO_TIMESTAMP(src.return_by_date    ,''YYYYMMDDHHMISS'')     ,
			tgt.return_authorization_number  =  src.return_authorization_number    ,
			tgt.document_type  =  src.document_type    ,
			tgt.origin_zone  =  src.origin_zone    ,
			tgt.destination_zone  =  src.destination_zone    ,
			tgt.status_date  =  TRY_TO_TIMESTAMP(src.status_date     ,''YYYYMMDDHHMISS'')   ,
			tgt.shipment_type  =  src.shipment_type    ,
			tgt.commercial_value  =  src.commercial_value    ,
			tgt.hazardous_material_flag  =  src.hazardous_material_flag    ,
			tgt.total_estimated_charge  =  TRY_CAST(src.total_estimated_charge AS FLOAT)    ,
			tgt.total_actual_charge  =  TRY_CAST(src.total_actual_charge  AS FLOAT)   ,
			tgt.next_alert_ts  =  src.next_alert_ts    ,
			tgt.shipment_confirm_updates_done  =  src.shipment_confirm_updates_done    ,
			tgt.shipment_deliver_updates_done  =  src.shipment_deliver_updates_done    ,
			tgt.shipment_containerized_flag  =  src.shipment_containerized_flag    ,
			tgt.scac_integration_required  =  src.scac_integration_required    ,
			tgt.packlist_type  =  src.packlist_type    ,
			tgt.custcarrier_account_no  =  src.custcarrier_account_no    ,
			tgt.manifest_key  =  src.manifest_key    ,
			tgt.is_single_order  =  src.is_single_order    ,
			tgt.lines_entered  =  src.lines_entered    ,
			tgt.order_available_on_system  =  src.order_available_on_system    ,
			tgt.override_manual_shipment_entry  =  src.override_manual_shipment_entry    ,
			tgt.do_not_verify_pallet_content  =  src.do_not_verify_pallet_content    ,
			tgt.do_not_verify_case_content  =  src.do_not_verify_case_content    ,
			tgt.allow_overage  =  src.allow_overage    ,
			tgt.manually_entered  =  src.manually_entered    ,
			tgt.allow_new_item_receipt  =  src.allow_new_item_receipt    ,
			tgt.order_no  =  src.order_no    ,
			tgt.order_header_key  =  src.order_header_key    ,
			tgt.release_no  =  src.release_no    ,
			tgt.order_release_key  =  src.order_release_key    ,
			tgt.export_license_no  =  src.export_license_no    ,
			tgt.export_license_exp_date  =  TRY_TO_TIMESTAMP(src.export_license_exp_date    ,''YYYYMMDDHHMISS'')     ,
			tgt.delivery_method  =  src.delivery_method    ,
			tgt.requires_appt_confirmation  =  src.requires_appt_confirmation    ,
			tgt.work_order_key  =  src.work_order_key    ,
			tgt.work_order_appt_key  =  src.work_order_appt_key    ,
			tgt.order_type  =  src.order_type    ,
			tgt.do_not_consolidate  =  src.do_not_consolidate    ,
			tgt.department_code  =  src.department_code    ,
			tgt.item_classification  =  src.item_classification    ,
			tgt.mark_for_key  =  src.mark_for_key    ,
			tgt.buyer_mark_for_node_id  =  src.buyer_mark_for_node_id    ,
			tgt.routing_contact_info  =  src.routing_contact_info    ,
			tgt.customer_po_no  =  src.customer_po_no    ,
			tgt.carrier_pickup_time  =  src.carrier_pickup_time    ,
			tgt.pack_and_hold  =  src.pack_and_hold    ,
			tgt.esp_check_required  =  src.esp_check_required    ,
			tgt.is_appointment_reqd  =  src.is_appointment_reqd    ,
			tgt.routing_source  =  src.routing_source    ,
			tgt.routing_error_code  =  src.routing_error_code    ,
			tgt.routing_guide_maintained  =  src.routing_guide_maintained    ,
			tgt.must_ship_before_date  =  TRY_TO_TIMESTAMP(src.must_ship_before_date    ,''YYYYMMDDHHMISS'')  ,
			tgt.priority_code  =  src.priority_code    ,
			tgt.estimated_price  = TRY_CAST(src.estimated_price  AS FLOAT)      ,
			tgt.has_node_exceptions  =  src.has_node_exceptions    ,
			tgt.cod_pay_method  =  src.cod_pay_method    ,
			tgt.airway_bill_no  =  src.airway_bill_no    ,
			tgt.invoice_complete  =  src.invoice_complete    ,
			tgt.expected_pick_date  =   TRY_TO_TIMESTAMP(src.expected_pick_date     ,''YYYYMMDDHHMISS'')  ,
			tgt.return_carrier_service  =  src.return_carrier_service    ,
			tgt.return_freight_terms  =  src.return_freight_terms    ,
			tgt.return_billing_account  =  src.return_billing_account    ,
			tgt.break_bulk_node  =  src.break_bulk_node    ,
			tgt.bbn_min_weight  =  src.bbn_min_weight    ,
			tgt.bbn_min_volume  =  src.bbn_min_volume    ,
			tgt.fedx_open_ship_index  =  src.fedx_open_ship_index    ,
			tgt.itn_no  =  src.itn_no    ,
			tgt.email_return_label  =  src.email_return_label    ,
			tgt.profile_id  =  src.profile_id    ,
			tgt.profileid_provided_by_sterling  =  src.profileid_provided_by_sterling    ,
			tgt.level_of_service  =  src.level_of_service    ,
			tgt.hold_location  =  src.hold_location    ,
			tgt.assigned_to_user_id  =  src.assigned_to_user_id    ,
			tgt.lockid  =  src.lockid    ,
			tgt.createts  =  TRY_TO_TIMESTAMP(src.createts    ,''YYYYMMDDHHMISS'')   ,
			tgt.modifyts  =  TRY_TO_TIMESTAMP(src.modifyts,''YYYYMMDDHHMISS'')    ,
			tgt.createuserid  =  src.createuserid    ,
			tgt.modifyuserid  =  src.modifyuserid    ,
			tgt.createprogid  =  src.createprogid    ,
			tgt.modifyprogid  =  src.modifyprogid    ,
			tgt.shipment_sort_location_id  =  src.shipment_sort_location_id    ,
			tgt.carrier_sort_location_id  =  src.carrier_sort_location_id    ,
			tgt.shipment_group_id  =  src.shipment_group_id    ,
			tgt.notification_sent  =  src.notification_sent    ,
			tgt.pickticket_printed  =  src.pickticket_printed    ,
			tgt.backroom_pick_required  =  src.backroom_pick_required    ,
			tgt.included_in_batch  =  src.included_in_batch    ,
			tgt.is_receiving_complete  =  src.is_receiving_complete    ,
			tgt.received_damaged  =  src.received_damaged    ,
			tgt.index_version  =  src.index_version    ,
			tgt.extn_narvar_url  =  src.extn_narvar_url    ,
			tgt.extn_is_sent  =  src.extn_is_sent    ,
			tgt.last_updated_date = :processedDate
WHEN NOT MATCHED THEN 
INSERT (external_Id   ,
						pick_list_no    ,
						original_shipment_key    ,
						merge_node    ,
						pickticket_no    ,
						ship_date    ,
						unplaced_quantity    ,
						shipnode_key    ,
						receiving_node    ,
						buyer_receiving_node_id    ,
						shipment_consol_group_id    ,
						ship_mode    ,
						from_address_key    ,
						to_address_key    ,
						bill_to_address_key    ,
						ship_to_customer_id    ,
						bill_to_customer_id    ,
						has_other_shipments    ,
						parent_shipment_key    ,
						ship_via    ,
						seal_no    ,
						tracking_no    ,
						trailer_no    ,
						manifest_no    ,
						pro_no    ,
						scac    ,
						actual_freight_charge    ,
						carrier_service_code    ,
						requested_carrier_service_code    ,
						status    ,
						pod_no    ,
						bol_no    ,
						total_weight    ,
						total_weight_uom    ,
						total_volume    ,
						total_volume_uom    ,
						total_quantity    ,
						containerized_quantity    ,
						placed_quantity    ,
						is_product_placing_complete    ,
						is_pack_process_complete    ,
						is_revised    ,
						hold_flag    ,
						it_no    ,
						it_date    ,
						appointment_no    ,
						from_appointment    ,
						to_appointment    ,
						delivery_ts    ,
						code    ,
						num_of_pallets    ,
						num_of_cartons    ,
						export_taxpayer_id    ,
						freight_terms    ,
						delivery_code    ,
						carrier_type    ,
						download_count    ,
						currency    ,
						delivery_plan_key    ,
						shipment_no    ,
						pipeline_key    ,
						gift_flag    ,
						shipment_planned_flag    ,
						shipment_closed_flag    ,
						seller_organization_code    ,
						buyer_organization_code    ,
						enterprise_code    ,
						requested_shipment_date    ,
						expected_shipment_date    ,
						actual_shipment_date    ,
						requested_delivery_date    ,
						expected_delivery_date    ,
						actual_delivery_date    ,
						return_by_date    ,
						return_authorization_number    ,
						document_type    ,
						origin_zone    ,
						destination_zone    ,
						status_date    ,
						shipment_type    ,
						commercial_value    ,
						hazardous_material_flag    ,
						total_estimated_charge    ,
						total_actual_charge    ,
						next_alert_ts    ,
						shipment_confirm_updates_done    ,
						shipment_deliver_updates_done    ,
						shipment_containerized_flag    ,
						scac_integration_required    ,
						packlist_type    ,
						custcarrier_account_no    ,
						manifest_key    ,
						is_single_order    ,
						lines_entered    ,
						order_available_on_system    ,
						override_manual_shipment_entry    ,
						do_not_verify_pallet_content    ,
						do_not_verify_case_content    ,
						allow_overage    ,
						manually_entered    ,
						allow_new_item_receipt    ,
						order_no    ,
						order_header_key    ,
						release_no    ,
						order_release_key    ,
						export_license_no    ,
						export_license_exp_date    ,
						delivery_method    ,
						requires_appt_confirmation    ,
						work_order_key    ,
						work_order_appt_key    ,
						order_type    ,
						do_not_consolidate    ,
						department_code    ,
						item_classification    ,
						mark_for_key    ,
						buyer_mark_for_node_id    ,
						routing_contact_info    ,
						customer_po_no    ,
						carrier_pickup_time    ,
						pack_and_hold    ,
						esp_check_required    ,
						is_appointment_reqd    ,
						routing_source    ,
						routing_error_code    ,
						routing_guide_maintained    ,
						must_ship_before_date    ,
						priority_code    ,
						estimated_price    ,
						has_node_exceptions    ,
						cod_pay_method    ,
						airway_bill_no    ,
						invoice_complete    ,
						expected_pick_date    ,
						return_carrier_service    ,
						return_freight_terms    ,
						return_billing_account    ,
						break_bulk_node    ,
						bbn_min_weight    ,
						bbn_min_volume    ,
						fedx_open_ship_index    ,
						itn_no    ,
						email_return_label    ,
						profile_id    ,
						profileid_provided_by_sterling    ,
						level_of_service    ,
						hold_location    ,
						assigned_to_user_id    ,
						lockid    ,
						createts    ,
						modifyts    ,
						createuserid    ,
						modifyuserid    ,
						createprogid    ,
						modifyprogid    ,
						shipment_sort_location_id    ,
						carrier_sort_location_id    ,
						shipment_group_id    ,
						notification_sent    ,
						pickticket_printed    ,
						backroom_pick_required    ,
						included_in_batch    ,
						is_receiving_complete    ,
						received_damaged    ,
						index_version    ,
						extn_narvar_url    ,
						extn_is_sent    ,
						last_updated_date )
			    VALUES( src.shipment_key    ,
						src.pick_list_no    ,
						src.original_shipment_key    ,
						src.merge_node    ,
						src.pickticket_no    ,
						TRY_TO_TIMESTAMP(src.ship_date,''YYYYMMDDHHMISS'')   ,
						src.unplaced_quantity    ,
						src.shipnode_key    ,
						src.receiving_node    ,
						src.buyer_receiving_node_id    ,
						src.shipment_consol_group_id    ,
						src.ship_mode    ,
						src.from_address_key    ,
						src.to_address_key    ,
						src.bill_to_address_key    ,
						src.ship_to_customer_id    ,
						src.bill_to_customer_id    ,
						src.has_other_shipments    ,
						src.parent_shipment_key    ,
						src.ship_via    ,
						src.seal_no    ,
						src.tracking_no    ,
						src.trailer_no    ,
						src.manifest_no    ,
						src.pro_no    ,
						src.scac    ,
						src.actual_freight_charge    ,
						src.carrier_service_code    ,
						src.requested_carrier_service_code    ,
						src.status    ,
						src.pod_no    ,
						src.bol_no    ,
						src.total_weight    ,
						src.total_weight_uom    ,
						src.total_volume    ,
						src.total_volume_uom    ,
						src.total_quantity    ,
						src.containerized_quantity    ,
						src.placed_quantity    ,
						src.is_product_placing_complete    ,
						src.is_pack_process_complete    ,
						src.is_revised    ,
						src.hold_flag    ,
						src.it_no    ,
						TRY_TO_TIMESTAMP(src.it_date ,''YYYYMMDDHHMISS'')    ,
						src.appointment_no    ,
						src.from_appointment    ,
						src.to_appointment    ,
						src.delivery_ts    ,
						src.code    ,
						src.num_of_pallets    ,
						src.num_of_cartons    ,
						src.export_taxpayer_id    ,
						src.freight_terms    ,
						src.delivery_code    ,
						src.carrier_type    ,
						src.download_count    ,
						src.currency    ,
						src.delivery_plan_key    ,
						src.shipment_no    ,
						src.pipeline_key    ,
						src.gift_flag    ,
						src.shipment_planned_flag    ,
						src.shipment_closed_flag    ,
						src.seller_organization_code    ,
						src.buyer_organization_code    ,
						src.enterprise_code    ,
						TRY_TO_TIMESTAMP(src.requested_shipment_date ,''YYYYMMDDHHMISS'')      ,
						TRY_TO_TIMESTAMP(src.expected_shipment_date   ,''YYYYMMDDHHMISS'')  ,
						TRY_TO_TIMESTAMP(src.actual_shipment_date   ,''YYYYMMDDHHMISS'')     ,
						TRY_TO_TIMESTAMP(src.requested_delivery_date    ,''YYYYMMDDHHMISS'')   ,
						TRY_TO_TIMESTAMP(src.expected_delivery_date    ,''YYYYMMDDHHMISS'')    ,
						TRY_TO_TIMESTAMP(src.actual_delivery_date     ,''YYYYMMDDHHMISS'')  ,
						TRY_TO_TIMESTAMP(src.return_by_date    ,''YYYYMMDDHHMISS'')   ,
						src.return_authorization_number    ,
						src.document_type    ,
						src.origin_zone    ,
						src.destination_zone    ,
						TRY_TO_TIMESTAMP(src.status_date   ,''YYYYMMDDHHMISS'')    ,
						src.shipment_type    ,
						src.commercial_value    ,
						src.hazardous_material_flag    ,
						TRY_CAST(src.total_estimated_charge   AS FLOAT)    ,
						TRY_CAST(src.total_actual_charge   AS FLOAT)    ,
						src.next_alert_ts    ,
						src.shipment_confirm_updates_done    ,
						src.shipment_deliver_updates_done    ,
						src.shipment_containerized_flag    ,
						src.scac_integration_required    ,
						src.packlist_type    ,
						src.custcarrier_account_no    ,
						src.manifest_key    ,
						src.is_single_order    ,
						src.lines_entered    ,
						src.order_available_on_system    ,
						src.override_manual_shipment_entry    ,
						src.do_not_verify_pallet_content    ,
						src.do_not_verify_case_content    ,
						src.allow_overage    ,
						src.manually_entered    ,
						src.allow_new_item_receipt    ,
						src.order_no    ,
						src.order_header_key    ,
						src.release_no    ,
						src.order_release_key    ,
						src.export_license_no    ,
						TRY_TO_TIMESTAMP(src.export_license_exp_date   ,''YYYYMMDDHHMISS'')     ,
						src.delivery_method    ,
						src.requires_appt_confirmation    ,
						src.work_order_key    ,
						src.work_order_appt_key    ,
						src.order_type    ,
						src.do_not_consolidate    ,
						src.department_code    ,
						src.item_classification    ,
						src.mark_for_key    ,
						src.buyer_mark_for_node_id    ,
						src.routing_contact_info    ,
						src.customer_po_no    ,
						src.carrier_pickup_time    ,
						src.pack_and_hold    ,
						src.esp_check_required    ,
						src.is_appointment_reqd    ,
						src.routing_source    ,
						src.routing_error_code    ,
						src.routing_guide_maintained    ,
						TRY_TO_TIMESTAMP(src.must_ship_before_date    ,''YYYYMMDDHHMISS'')   ,
						src.priority_code    ,
						TRY_CAST(src.estimated_price   AS FLOAT)     ,
						src.has_node_exceptions    ,
						src.cod_pay_method    ,
						src.airway_bill_no    ,
						src.invoice_complete    ,
						TRY_TO_TIMESTAMP(src.expected_pick_date    ,''YYYYMMDDHHMISS'')   ,
						src.return_carrier_service    ,
						src.return_freight_terms    ,
						src.return_billing_account    ,
						src.break_bulk_node    ,
						src.bbn_min_weight    ,
						src.bbn_min_volume    ,
						src.fedx_open_ship_index    ,
						src.itn_no    ,
						src.email_return_label    ,
						src.profile_id    ,
						src.profileid_provided_by_sterling    ,
						src.level_of_service    ,
						src.hold_location    ,
						src.assigned_to_user_id    ,
						src.lockid    ,
						TRY_TO_TIMESTAMP(src.createts  ,''YYYYMMDDHHMISS'')    ,
						TRY_TO_TIMESTAMP(src.modifyts  ,''YYYYMMDDHHMISS'')   ,
						src.createuserid    ,
						src.modifyuserid    ,
						src.createprogid    ,
						src.modifyprogid    ,
						src.shipment_sort_location_id    ,
						src.carrier_sort_location_id    ,
						src.shipment_group_id    ,
						src.notification_sent    ,
						src.pickticket_printed    ,
						src.backroom_pick_required    ,
						src.included_in_batch    ,
						src.is_receiving_complete    ,
						src.received_damaged    ,
						src.index_version    ,
						src.extn_narvar_url    ,
						src.extn_is_sent    ,
                        :processedDate)
;

INSERT INTO TempExtDelivered (
    external_id,
    pick_list_no,
    original_shipment_key,
    merge_node,
    pickticket_no,
    ship_date,
    unplaced_quantity,
    shipnode_key,
    receiving_node,
    buyer_receiving_node_id,
    shipment_consol_group_id,
    ship_mode,
    from_address_key,
    to_address_key,
    bill_to_address_key,
    ship_to_customer_id,
    bill_to_customer_id,
    has_other_shipments,
    parent_shipment_key,
    ship_via,
    seal_no,
    tracking_no,
    trailer_no,
    manifest_no,
    pro_no,
    scac,
    actual_freight_charge,
    carrier_service_code,
    requested_carrier_service_code,
    status,
    pod_no,
    bol_no,
    total_weight,
    total_weight_uom,
    total_volume,
    total_volume_uom,
    total_quantity,
    containerized_quantity,
    placed_quantity,
    is_product_placing_complete,
    is_pack_process_complete,
    is_revised,
    hold_flag,
    it_no,
    it_date,
    appointment_no,
    from_appointment,
    to_appointment,
    delivery_ts,
    code,
    num_of_pallets,
    num_of_cartons,
    export_taxpayer_id,
    freight_terms,
    delivery_code,
    carrier_type,
    download_count,
    currency,
    delivery_plan_key,
    shipment_no,
    pipeline_key,
    gift_flag,
    shipment_planned_flag,
    shipment_closed_flag,
    seller_organization_code,
    buyer_organization_code,
    enterprise_code,
    requested_shipment_date,
    expected_shipment_date,
    actual_shipment_date,
    requested_delivery_date,
    expected_delivery_date,
    actual_delivery_date,
    return_by_date,
    return_authorization_number,
    document_type,
    origin_zone,
    destination_zone,
    status_date,
    shipment_type,
    commercial_value,
    hazardous_material_flag,
    total_estimated_charge,
    total_actual_charge,
    next_alert_ts,
    shipment_confirm_updates_done,
    shipment_deliver_updates_done,
    shipment_containerized_flag,
    scac_integration_required,
    packlist_type,
    custcarrier_account_no,
    manifest_key,
    is_single_order,
    lines_entered,
    order_available_on_system,
    override_manual_shipment_entry,
    do_not_verify_pallet_content,
    do_not_verify_case_content,
    allow_overage,
    manually_entered,
    allow_new_item_receipt,
    order_no,
    order_header_key,
    release_no,
    order_release_key,
    export_license_no,
    export_license_exp_date,
    delivery_method,
    requires_appt_confirmation,
    work_order_key,
    work_order_appt_key,
    order_type,
    do_not_consolidate,
    department_code,
    item_classification,
    mark_for_key,
    buyer_mark_for_node_id,
    routing_contact_info,
    customer_po_no,
    carrier_pickup_time,
    pack_and_hold,
    esp_check_required,
    is_appointment_reqd,
    routing_source,
    routing_error_code,
    routing_guide_maintained,
    must_ship_before_date,
    priority_code,
    estimated_price,
    has_node_exceptions,
    cod_pay_method,
    airway_bill_no,
    invoice_complete,
    expected_pick_date,
    return_carrier_service,
    return_freight_terms,
    return_billing_account,
    break_bulk_node,
    bbn_min_weight,
    bbn_min_volume,
    fedx_open_ship_index,
    itn_no,
    email_return_label,
    profile_id,
    profileid_provided_by_sterling,
    level_of_service,
    hold_location,
    assigned_to_user_id,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    shipment_sort_location_id,
    carrier_sort_location_id,
    shipment_group_id,
    notification_sent,
    pickticket_printed,
    backroom_pick_required,
    included_in_batch,
    is_receiving_complete,
    received_damaged,
    index_version,
    extn_narvar_url,
    extn_is_sent,
    last_updated_date,
    revision
)
SELECT 
    shipment_key,
    pick_list_no,
    original_shipment_key,
    merge_node,
    pickticket_no,
    TRY_TO_TIMESTAMP(ship_date   ,''YYYYMMDDHHMISS'') ,
    unplaced_quantity,
    shipnode_key,
    receiving_node,
    buyer_receiving_node_id,
    shipment_consol_group_id,
    ship_mode,
    from_address_key,
    to_address_key,
    bill_to_address_key,
    ship_to_customer_id,
    bill_to_customer_id,
    has_other_shipments,
    parent_shipment_key,
    ship_via,
    seal_no,
    tracking_no,
    trailer_no,
    manifest_no,
    pro_no,
    scac,
    actual_freight_charge,
    carrier_service_code,
    requested_carrier_service_code,
    status,
    pod_no,
    bol_no,
    total_weight,
    total_weight_uom,
    total_volume,
    total_volume_uom,
    total_quantity,
    containerized_quantity,
    placed_quantity,
    is_product_placing_complete,
    is_pack_process_complete,
    is_revised,
    hold_flag,
    it_no,
    TRY_TO_TIMESTAMP(it_date  ,''YYYYMMDDHHMISS''),
    appointment_no,
    from_appointment,
    to_appointment,
    delivery_ts,
    code,
    num_of_pallets,
    num_of_cartons,
    export_taxpayer_id,
    freight_terms,
    delivery_code,
    carrier_type,
    download_count,
    currency,
    delivery_plan_key,
    shipment_no,
    pipeline_key,
    gift_flag,
    shipment_planned_flag,
    shipment_closed_flag,
    seller_organization_code,
    buyer_organization_code,
    enterprise_code,
    TRY_TO_TIMESTAMP(requested_shipment_date  ,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(expected_shipment_date  ,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(actual_shipment_date  ,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(requested_delivery_date  ,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(expected_delivery_date  ,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(actual_delivery_date  ,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(return_by_date  ,''YYYYMMDDHHMISS''),
    return_authorization_number,
    document_type,
    origin_zone,
    destination_zone,
    TRY_TO_TIMESTAMP(status_date  ,''YYYYMMDDHHMISS''),
    shipment_type,
    commercial_value,
    hazardous_material_flag,
    TRY_CAST(total_estimated_charge AS FLOAT)  ,
    TRY_CAST(total_actual_charge AS FLOAT) ,
    next_alert_ts,
    shipment_confirm_updates_done,
    shipment_deliver_updates_done,
    shipment_containerized_flag,
    scac_integration_required,
    packlist_type,
    custcarrier_account_no,
    manifest_key,
    is_single_order,
    lines_entered,
    order_available_on_system,
    override_manual_shipment_entry,
    do_not_verify_pallet_content,
    do_not_verify_case_content,
    allow_overage,
    manually_entered,
    allow_new_item_receipt,
    order_no,
    order_header_key,
    release_no,
    order_release_key,
    export_license_no,
    TRY_TO_TIMESTAMP(export_license_exp_date  ,''YYYYMMDDHHMISS''),
    delivery_method,
    requires_appt_confirmation,
    work_order_key,
    work_order_appt_key,
    order_type,
    do_not_consolidate,
    department_code,
    item_classification,
    mark_for_key,
    buyer_mark_for_node_id,
    routing_contact_info,
    customer_po_no,
    carrier_pickup_time,
    pack_and_hold,
    esp_check_required,
    is_appointment_reqd,
    routing_source,
    routing_error_code,
    routing_guide_maintained,
    TRY_TO_TIMESTAMP(must_ship_before_date  ,''YYYYMMDDHHMISS''),
    priority_code,
    TRY_CAST(estimated_price AS FLOAT),
    has_node_exceptions,
    cod_pay_method,
    airway_bill_no,
    invoice_complete,
    TRY_TO_TIMESTAMP(expected_pick_date ,''YYYYMMDDHHMISS''),
    return_carrier_service,
    return_freight_terms,
    return_billing_account,
    break_bulk_node,
    bbn_min_weight,
    bbn_min_volume,
    fedx_open_ship_index,
    itn_no,
    email_return_label,
    profile_id,
    profileid_provided_by_sterling,
    level_of_service,
    hold_location,
    assigned_to_user_id,
    lockid,
    TRY_TO_TIMESTAMP(createts ,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(modifyts ,''YYYYMMDDHHMISS''),
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    shipment_sort_location_id,
    carrier_sort_location_id,
    shipment_group_id,
    notification_sent,
    pickticket_printed,
    backroom_pick_required,
    included_in_batch,
    is_receiving_complete,
    received_damaged,
    index_version,
    extn_narvar_url,
    extn_is_sent,
    :processedDate,
    1 AS revision
FROM 
    TRANSFORMED.STG_ORDER_SHIPMENT;

CREATE OR REPLACE TEMPORARY TABLE TempMaxRevisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.external_Id
FROM
    ANALYTICS.AUDIT_EXT_ORDER_DELIVERED AS aot
INNER JOIN 
    TempExtDelivered AS ttd ON ttd.external_Id = aot.external_Id
GROUP BY
    aot.external_Id;

UPDATE TempExtDelivered ttd
SET
    ttd.Revision = CAST((COALESCE(tmr.revision, 0) + 1) AS INT)
FROM
    TempMaxRevisions AS tmr
WHERE
    ttd.external_Id = tmr.external_Id;

DROP TABLE IF EXISTS TempMaxRevisions;

INSERT INTO ANALYTICS.audit_ext_order_delivered (
external_Id,
pick_list_no,
original_shipment_key,
merge_node,
pickticket_no,
ship_date,
unplaced_quantity,
shipnode_key,
receiving_node,
buyer_receiving_node_id,
shipment_consol_group_id,
ship_mode,
from_address_key,
to_address_key,
bill_to_address_key,
ship_to_customer_id,
bill_to_customer_id,
has_other_shipments,
parent_shipment_key,
ship_via,
seal_no,
tracking_no,
trailer_no,
manifest_no,
pro_no,
scac,
actual_freight_charge,
carrier_service_code,
requested_carrier_service_code,
status,
pod_no,
bol_no,
total_weight,
total_weight_uom,
total_volume,
total_volume_uom,
total_quantity,
containerized_quantity,
placed_quantity,
is_product_placing_complete,
is_pack_process_complete,
is_revised,
hold_flag,
it_no,
it_date,
appointment_no,
from_appointment,
to_appointment,
delivery_ts,
code,
num_of_pallets,
num_of_cartons,
export_taxpayer_id,
freight_terms,
delivery_code,
carrier_type,
download_count,
currency,
delivery_plan_key,
shipment_no,
pipeline_key,
gift_flag,
shipment_planned_flag,
shipment_closed_flag,
seller_organization_code,
buyer_organization_code,
enterprise_code,
requested_shipment_date,
expected_shipment_date,
actual_shipment_date,
requested_delivery_date,
expected_delivery_date,
actual_delivery_date,
return_by_date,
return_authorization_number,
document_type,
origin_zone,
destination_zone,
status_date,
shipment_type,
commercial_value,
hazardous_material_flag,
total_estimated_charge,
total_actual_charge,
next_alert_ts,
shipment_confirm_updates_done,
shipment_deliver_updates_done,
shipment_containerized_flag,
scac_integration_required,
packlist_type,
custcarrier_account_no,
manifest_key,
is_single_order,
lines_entered,
order_available_on_system,
override_manual_shipment_entry,
do_not_verify_pallet_content,
do_not_verify_case_content,
allow_overage,
manually_entered,
allow_new_item_receipt,
order_no,
order_header_key,
release_no,
order_release_key,
export_license_no,
export_license_exp_date,
delivery_method,
requires_appt_confirmation,
work_order_key,
work_order_appt_key,
order_type,
do_not_consolidate,
department_code,
item_classification,
mark_for_key,
buyer_mark_for_node_id,
routing_contact_info,
customer_po_no,
carrier_pickup_time,
pack_and_hold,
esp_check_required,
is_appointment_reqd,
routing_source,
routing_error_code,
routing_guide_maintained,
must_ship_before_date,
priority_code,
estimated_price,
has_node_exceptions,
cod_pay_method,
airway_bill_no,
invoice_complete,
expected_pick_date,
return_carrier_service,
return_freight_terms,
return_billing_account,
break_bulk_node,
bbn_min_weight,
bbn_min_volume,
fedx_open_ship_index,
itn_no,
email_return_label,
profile_id,
profileid_provided_by_sterling,
level_of_service,
hold_location,
assigned_to_user_id,
lockid,
createts,
modifyts,
createuserid,
modifyuserid,
createprogid,
modifyprogid,
shipment_sort_location_id,
carrier_sort_location_id,
shipment_group_id,
notification_sent,
pickticket_printed,
backroom_pick_required,
included_in_batch,
is_receiving_complete,
received_damaged,
index_version,
extn_narvar_url,
extn_is_sent,
last_updated_date,
revision
)
SELECT 
stg.shipment_key,
stg.pick_list_no,
stg.original_shipment_key,
stg.merge_node,
stg.pickticket_no,
TRY_TO_TIMESTAMP(stg.ship_date, ''YYYYMMDDHHMISS''),
try_to_number(stg.unplaced_quantity),
stg.shipnode_key,
stg.receiving_node,
stg.buyer_receiving_node_id,
stg.shipment_consol_group_id,
stg.ship_mode,
stg.from_address_key,
stg.to_address_key,
stg.bill_to_address_key,
stg.ship_to_customer_id,
stg.bill_to_customer_id,
stg.has_other_shipments,
stg.parent_shipment_key,
stg.ship_via,
stg.seal_no,
stg.tracking_no,
stg.trailer_no,
stg.manifest_no,
stg.pro_no,
stg.scac,
TRY_CAST(stg.actual_freight_charge AS FLOAT) ,
stg.carrier_service_code,
stg.requested_carrier_service_code,
stg.status,
stg.pod_no,
stg.bol_no,
TRY_CAST(stg.total_weight AS FLOAT),
stg.total_weight_uom,
TRY_CAST(stg.total_volume AS FLOAT) ,
stg.total_volume_uom,
try_to_number(stg.total_quantity),
try_to_number(stg.containerized_quantity),
try_to_number(stg.placed_quantity),
stg.is_product_placing_complete,
stg.is_pack_process_complete,
stg.is_revised,
stg.hold_flag,
stg.it_no,
TRY_TO_TIMESTAMP(stg.it_date, ''YYYYMMDDHHMISS''),
stg.appointment_no,
stg.from_appointment,
stg.to_appointment,
TRY_TO_TIMESTAMP(stg.delivery_ts, ''YYYYMMDDHHMISS''),
stg.code,
try_to_number(stg.num_of_pallets),
try_to_number(stg.num_of_cartons),
stg.export_taxpayer_id,
stg.freight_terms,
stg.delivery_code,
stg.carrier_type,
stg.download_count,
stg.currency,
stg.delivery_plan_key,
stg.shipment_no,
stg.pipeline_key,
stg.gift_flag,
stg.shipment_planned_flag,
stg.shipment_closed_flag,
stg.seller_organization_code,
stg.buyer_organization_code,
stg.enterprise_code,
TRY_TO_TIMESTAMP(stg.requested_shipment_date, ''YYYYMMDDHHMISS''),
TRY_TO_TIMESTAMP(stg.expected_shipment_date, ''YYYYMMDDHHMISS''),
TRY_TO_TIMESTAMP(stg.actual_shipment_date, ''YYYYMMDDHHMISS''),
TRY_TO_TIMESTAMP(stg.requested_delivery_date, ''YYYYMMDDHHMISS''),
TRY_TO_TIMESTAMP(stg.expected_delivery_date, ''YYYYMMDDHHMISS''),
TRY_TO_TIMESTAMP(stg.actual_delivery_date, ''YYYYMMDDHHMISS''),
TRY_TO_TIMESTAMP(stg.return_by_date, ''YYYYMMDDHHMISS''),
stg.return_authorization_number,
stg.document_type,
stg.origin_zone,
stg.destination_zone,
TRY_TO_TIMESTAMP(stg.status_date, ''YYYYMMDDHHMISS''),
stg.shipment_type,
stg.commercial_value,
stg.hazardous_material_flag,
TRY_CAST(stg.total_estimated_charge AS FLOAT) ,
TRY_CAST(stg.total_actual_charge AS FLOAT) ,
stg.next_alert_ts,
stg.shipment_confirm_updates_done,
stg.shipment_deliver_updates_done,
stg.shipment_containerized_flag,
stg.scac_integration_required,
stg.packlist_type,
stg.custcarrier_account_no,
stg.manifest_key,
stg.is_single_order,
stg.lines_entered,
stg.order_available_on_system,
stg.override_manual_shipment_entry,
stg.do_not_verify_pallet_content,
stg.do_not_verify_case_content,
stg.allow_overage,
stg.manually_entered,
stg.allow_new_item_receipt,
stg.order_no,
stg.order_header_key,
stg.release_no,
stg.order_release_key,
stg.export_license_no,
TRY_TO_TIMESTAMP(stg.export_license_exp_date, ''YYYYMMDDHHMISS''),
stg.delivery_method,
stg.requires_appt_confirmation,
stg.work_order_key,
stg.work_order_appt_key,
stg.order_type,
stg.do_not_consolidate,
stg.department_code,
stg.item_classification,
stg.mark_for_key,
stg.buyer_mark_for_node_id,
stg.routing_contact_info,
stg.customer_po_no,
TRY_TO_TIMESTAMP(stg.carrier_pickup_time   ,''YYYYMMDDHHMISS'')  ,
stg.pack_and_hold,
stg.esp_check_required,
stg.is_appointment_reqd,
stg.routing_source,
stg.routing_error_code,
stg.routing_guide_maintained,
TRY_TO_TIMESTAMP(stg.must_ship_before_date, ''YYYYMMDDHHMISS''),
stg.priority_code,
TRY_CAST(stg.estimated_price AS FLOAT),
stg.has_node_exceptions,
stg.cod_pay_method,
stg.airway_bill_no,
stg.invoice_complete,
TRY_TO_TIMESTAMP(stg.expected_pick_date, ''YYYYMMDDHHMISS''),
stg.return_carrier_service,
stg.return_freight_terms,
stg.return_billing_account,
stg.break_bulk_node,
try_cast(stg.bbn_min_weight as float),
try_cast(stg.bbn_min_volume as float),
stg.fedx_open_ship_index,
stg.itn_no,
stg.email_return_label,
stg.profile_id,
stg.profileid_provided_by_sterling,
stg.level_of_service,
stg.hold_location,
stg.assigned_to_user_id,
stg.lockid,
TRY_TO_TIMESTAMP(stg.createts, ''YYYYMMDDHHMISS''),
TRY_TO_TIMESTAMP(stg.modifyts, ''YYYYMMDDHHMISS''),
stg.createuserid,
stg.modifyuserid,
stg.createprogid,
stg.modifyprogid,
stg.shipment_sort_location_id,
stg.carrier_sort_location_id,
stg.shipment_group_id,
stg.notification_sent,
stg.pickticket_printed,
stg.backroom_pick_required,
stg.included_in_batch,
stg.is_receiving_complete,
stg.received_damaged,
stg.index_version,
stg.extn_narvar_url,
stg.extn_is_sent,
:processedDate,
ord.revision
FROM TRANSFORMED.STG_ORDER_SHIPMENT stg
		INNER JOIN TempExtDelivered ord ON ord.external_Id = stg.shipment_key
;


CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

        error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';



CREATE OR REPLACE PROCEDURE ANALYTICS.USP_EXT_ORDER_HEADER_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    createdby NUMBER DEFAULT 1;
    action STRING DEFAULT 'CREATE';
    productTaxType STRING DEFAULT 'PRODUCT';
    personalizationFeeType STRING DEFAULT 'FEE-PERSONALIZE';
    domesticSource STRING DEFAULT 'domestic';
    internationalSource STRING DEFAULT 'international';
    processedRecordCount BIGINT DEFAULT 0;
    processedDate TIMESTAMP_NTZ(9);
    start_time_proc TIMESTAMP_NTZ(9);
    error_object VARIANT;
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

CREATE OR REPLACE TEMPORARY TABLE TempExtOrderHeader (
   order_header_key VARCHAR,
   sourcing_classification VARCHAR,
   buyer_organization_code VARCHAR,
   seller_organization_code VARCHAR,
   document_type VARCHAR,
   bill_to_id VARCHAR,
   customer_rewards_no VARCHAR,
   vendor_id VARCHAR,
   ship_to_id VARCHAR,
   ship_node VARCHAR,
   receiving_node VARCHAR,
   buyer_receiving_node_id VARCHAR,
   mark_for_key VARCHAR,
   buyer_mark_for_node_id VARCHAR,
   req_delivery_date VARCHAR,
   req_cancel_date VARCHAR,
   req_ship_date VARCHAR,
   default_template VARCHAR,
   division VARCHAR,
   draft_order_flag VARCHAR,
   order_purpose VARCHAR,
   return_oh_key_for_exchange VARCHAR,
   exchange_type VARCHAR,
   pending_transfer_in VARCHAR,
   return_by_gift_recipient VARCHAR,
   allocation_rule_id VARCHAR,
   priority_code VARCHAR,
   priority_number VARCHAR,
   contact_key VARCHAR,
   scac VARCHAR,
   carrier_service_code VARCHAR,
   custcarrier_account_no VARCHAR,
   notify_after_shipment_flag VARCHAR,
   created_at_node VARCHAR,
   has_derived_child VARCHAR,
   has_derived_parent VARCHAR,
   notification_type VARCHAR,
   notification_reference VARCHAR,
   entry_type VARCHAR,
   authorized_client VARCHAR,
   entered_by VARCHAR,
   personalize_code VARCHAR,
   hold_flag VARCHAR,
   hold_reason_code VARCHAR,
   customer_po_no VARCHAR,
   customer_customer_po_no VARCHAR,
   order_name VARCHAR,
   payment_rule_id VARCHAR,
   terms_code VARCHAR,
   delivery_code VARCHAR,
   charge_actual_freight VARCHAR,
   original_tax VARCHAR,
   currency VARCHAR,
   enterprise_currency VARCHAR,
   reporting_conversion_rate VARCHAR,
   reporting_conversion_date VARCHAR,
   payment_status VARCHAR,
   authorization_expiration_date VARCHAR,
   search_criteria_1 VARCHAR,
   search_criteria_2 VARCHAR,
   fob VARCHAR,
   other_charges VARCHAR,
   price_program_key VARCHAR,
   taxpayer_id VARCHAR,
   tax_jurisdiction VARCHAR,
   tax_exemption_certificate VARCHAR,
   purpose VARCHAR,
   invoice_complete VARCHAR,
   order_closed VARCHAR,
   next_alert_ts VARCHAR,
   do_not_consolidate VARCHAR,
   chain_type VARCHAR,
   adjustment_invoice_pending VARCHAR,
   auto_cancel_date VARCHAR,
   sale_voided VARCHAR,
   is_ship_complete VARCHAR,
   is_line_ship_complete VARCHAR,
   is_ship_single_node VARCHAR,
   is_line_ship_single_node VARCHAR,
   cancel_order_on_excp_flag VARCHAR,
   optimization_type VARCHAR,
   purge_history_date VARCHAR,
   pricing_classification_code VARCHAR,
   source_type VARCHAR,
   source_key VARCHAR,
   linked_source_key VARCHAR,
   original_container_key VARCHAR,
   sold_to_key VARCHAR,
   team_code VARCHAR,
   next_iter_seq_no VARCHAR,
   next_iter_date VARCHAR,
   hrs_before_next_iter VARCHAR,
   createuserid VARCHAR,
   modifyuserid VARCHAR,
   createprogid VARCHAR,
   modifyprogid VARCHAR,
   lockid VARCHAR,
   department_code VARCHAR,
   buyer_user_id VARCHAR,
   recreate_authorizations VARCHAR,
   customer_contact_id VARCHAR,
   opportunity_key VARCHAR,
   is_expiration_date_overridden VARCHAR,
   expiration_date VARCHAR,
   approval_cycle VARCHAR,
   in_store_payment_required VARCHAR,
   immediate_settlement_value VARCHAR,
   customer_age VARCHAR,
   cart_id VARCHAR,
   rollout_version VARCHAR,
   all_addresses_verified VARCHAR,
   compl_gift_box_qty VARCHAR,
   no_of_auth_strikes VARCHAR,
   source_ip_address VARCHAR,
   customer_first_name VARCHAR,
   customer_last_name VARCHAR,
   customer_phone_no VARCHAR,
   customer_zip_code VARCHAR,
   index_version VARCHAR,
   extn_customer_type VARCHAR,
   extn_customer_id VARCHAR,
   extn_cba_ship_label VARCHAR,
   extn_amazon_tfm VARCHAR,
   extn_tfm_ship_status VARCHAR,
   extn_financed_by_affirm VARCHAR,
   extn_risk_status VARCHAR,
   extn_sales_rep_cust_id VARCHAR,
   extn_latest_ship_date VARCHAR,
   extn_latest_delivery_date VARCHAR,
   extn_market_place_id VARCHAR,
   extn_order_status VARCHAR,
   extn_is_prime VARCHAR,
   extn_giftee_full_name VARCHAR,
   extn_giftee_email_id VARCHAR,
   extn_sms_opt_in VARCHAR,
   extn_ga_tag_id VARCHAR,
   extn_fraud_status VARCHAR,
   extn_order_locale_code VARCHAR,
   extn_shipto_firstname VARCHAR,
   extn_shipto_lastname VARCHAR,
   extn_shipto_zipcode VARCHAR,
   extn_return_confirmed_by VARCHAR,
   extn_edi_gcn VARCHAR,
   extn_pk_header_key VARCHAR,
   extn_merchant_id VARCHAR,
   extn_is_avalara VARCHAR,
   extn_req_cancel_date VARCHAR,
   extn_is_email_sent VARCHAR,
   extn_is_txn_committed VARCHAR,
   extn_tax_txn_date VARCHAR,
   extn_last_refund_txn_code VARCHAR,
   extn_refund_txn_code VARCHAR,
   extn_min_estimated_delivery_date VARCHAR,
   extn_max_estimated_delivery_date VARCHAR,
   extn_apply_migration_hold VARCHAR,
   extn_signifyd_order_id VARCHAR,
   extn_primary_reason VARCHAR,
   extn_secondary_reason VARCHAR,
   extn_sales_entry_type VARCHAR,
   extn_sales_order_type VARCHAR,
   extn_warranty_order_no VARCHAR,
   extn_seller_payment_type VARCHAR,
   createts VARCHAR,
   modifyts VARCHAR,
   revision VARCHAR
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.ext_order_header eoh
USING (
  SELECT DISTINCT
    stg.order_header_key,
    stg.sourcing_classification,
    stg.buyer_organization_code,
    stg.seller_organization_code,
    stg.document_type,
    stg.bill_to_id,
    stg.customer_rewards_no,
    stg.vendor_id,
    stg.ship_to_id,
    stg.ship_node,
    stg.receiving_node,
    stg.buyer_receiving_node_id,
    stg.mark_for_key,
    stg.buyer_mark_for_node_id,
    stg.req_delivery_date,
    stg.req_cancel_date,
    stg.req_ship_date,
    stg.default_template,
    stg.division,
    stg.draft_order_flag,
    stg.order_purpose,
    stg.return_oh_key_for_exchange,
    stg.exchange_type,
    stg.pending_transfer_in,
    stg.return_by_gift_recipient,
    stg.allocation_rule_id,
    stg.priority_code,
    stg.priority_number,
    stg.contact_key,
    stg.scac,
    stg.carrier_service_code,
    stg.custcarrier_account_no,
    stg.notify_after_shipment_flag,
    stg.created_at_node,
    stg.has_derived_child,
    stg.has_derived_parent,
    stg.notification_type,
    stg.notification_reference,
    stg.entry_type,
    stg.authorized_client,
    stg.entered_by,
    stg.personalize_code,
    stg.hold_flag,
    stg.hold_reason_code,
    stg.customer_po_no,
    stg.customer_customer_po_no,
    stg.order_name,
    stg.payment_rule_id,
    stg.terms_code,
    stg.delivery_code,
    stg.charge_actual_freight,
    stg.original_tax,
    stg.currency,
    stg.enterprise_currency,
    stg.reporting_conversion_rate,
    stg.reporting_conversion_date,
    stg.payment_status,
    stg.authorization_expiration_date,
    stg.search_criteria_1,
    stg.search_criteria_2,
    stg.fob,
    stg.other_charges,
    stg.price_program_key,
    stg.taxpayer_id,
    stg.tax_jurisdiction,
    stg.tax_exemption_certificate,
    stg.purpose,
    stg.invoice_complete,
    stg.order_closed,
    stg.next_alert_ts,
    stg.do_not_consolidate,
    stg.chain_type,
    stg.adjustment_invoice_pending,
    stg.auto_cancel_date,
    stg.sale_voided,
    stg.is_ship_complete,
    stg.is_line_ship_complete,
    stg.is_ship_single_node,
    stg.is_line_ship_single_node,
    stg.cancel_order_on_excp_flag,
    stg.optimization_type,
    stg.purge_history_date,
    stg.pricing_classification_code,
    stg.source_type,
    stg.source_key,
    stg.linked_source_key,
    stg.original_container_key,
    stg.sold_to_key,
    stg.team_code,
    stg.next_iter_seq_no,
    stg.next_iter_date,
    stg.hrs_before_next_iter,
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    stg.department_code,
    stg.buyer_user_id,
    stg.recreate_authorizations,
    stg.customer_contact_id,
    stg.opportunity_key,
    stg.is_expiration_date_overridden,
    stg.expiration_date,
    stg.approval_cycle,
    stg.in_store_payment_required,
    stg.immediate_settlement_value,
    stg.customer_age,
    stg.cart_id,
    stg.rollout_version,
    stg.all_addresses_verified,
    stg.compl_gift_box_qty,
    stg.no_of_auth_strikes,
    stg.source_ip_address,
    stg.customer_first_name,
    stg.customer_last_name,
    stg.customer_phone_no,
    stg.customer_zip_code,
    stg.index_version,
    stg.extn_customer_type,
    stg.extn_customer_id,
    stg.extn_cba_ship_label,
    stg.extn_amazon_tfm,
    stg.extn_tfm_ship_status,
    stg.extn_financed_by_affirm,
    stg.extn_risk_status,
    stg.extn_sales_rep_cust_id,
    stg.extn_latest_ship_date,
    stg.extn_latest_delivery_date,
    stg.extn_market_place_id,
    stg.extn_order_status,
    stg.extn_is_prime,
    stg.extn_giftee_full_name,
    stg.extn_giftee_email_id,
    stg.extn_sms_opt_in,
    stg.extn_ga_tag_id,
    stg.extn_fraud_status,
    stg.extn_order_locale_code,
    stg.extn_shipto_firstname,
    stg.extn_shipto_lastname,
    stg.extn_shipto_zipcode,
    stg.extn_return_confirmed_by,
    stg.extn_edi_gcn,
    stg.extn_pk_header_key,
    stg.extn_merchant_id,
    stg.extn_is_avalara,
    stg.extn_req_cancel_date,
    stg.extn_is_email_sent,
    stg.extn_is_txn_committed,
    stg.extn_tax_txn_date,
    stg.extn_last_refund_txn_code,
    stg.extn_refund_txn_code,
    stg.extn_min_estimated_delivery_date,
    stg.extn_max_estimated_delivery_date,
    stg.extn_apply_migration_hold,
    stg.extn_signifyd_order_id,
    stg.extn_primary_reason,
    stg.extn_secondary_reason,
    stg.extn_sales_entry_type,
    stg.extn_sales_order_type,
    stg.extn_warranty_order_no,
    stg.extn_seller_payment_type,
    stg.createts,
    stg.modifyts
  FROM TRANSFORMED.stg_order_header stg
  INNER JOIN RAW.raw_order_header r
    ON r.order_header_key = stg.order_header_key
    AND r.modifyts = stg.modifyts
    AND r.processing_status = 'Processed'
) soh
ON eoh.order_header_key = soh.order_header_key
WHEN MATCHED THEN
  UPDATE SET
    eoh.order_header_key = soh.order_header_key,
    eoh.sourcing_classification = soh.sourcing_classification,
    eoh.buyer_organization_code = soh.buyer_organization_code,
    eoh.seller_organization_code = soh.seller_organization_code,
    eoh.document_type = soh.document_type,
    eoh.bill_to_id = soh.bill_to_id,
    eoh.customer_rewards_no = soh.customer_rewards_no,
    eoh.vendor_id = soh.vendor_id,
    eoh.ship_to_id = soh.ship_to_id,
    eoh.ship_node = soh.ship_node,
    eoh.receiving_node = soh.receiving_node,
    eoh.buyer_receiving_node_id = soh.buyer_receiving_node_id,
    eoh.mark_for_key = soh.mark_for_key,
    eoh.buyer_mark_for_node_id = soh.buyer_mark_for_node_id,
    eoh.req_delivery_date = TRY_TO_TIMESTAMP(soh.req_delivery_date,'YYYYMMDDHHMISS')  ,
    eoh.req_cancel_date = TRY_TO_TIMESTAMP(soh.req_cancel_date,'YYYYMMDDHHMISS')  ,
    eoh.req_ship_date = TRY_TO_TIMESTAMP(soh.req_ship_date,'YYYYMMDDHHMISS')  ,
    eoh.default_template = soh.default_template,
    eoh.division = soh.division,
    eoh.draft_order_flag = soh.draft_order_flag,
    eoh.order_purpose = soh.order_purpose,
    eoh.return_oh_key_for_exchange = soh.return_oh_key_for_exchange,
    eoh.exchange_type = soh.exchange_type,
    eoh.pending_transfer_in = soh.pending_transfer_in,
    eoh.return_by_gift_recipient = soh.return_by_gift_recipient,
    eoh.allocation_rule_id = soh.allocation_rule_id,
    eoh.priority_code = soh.priority_code,
    eoh.priority_number = soh.priority_number,
    eoh.contact_key = soh.contact_key,
    eoh.scac = soh.scac,
    eoh.carrier_service_code = soh.carrier_service_code,
    eoh.custcarrier_account_no = soh.custcarrier_account_no,
    eoh.notify_after_shipment_flag = soh.notify_after_shipment_flag,
    eoh.created_at_node = soh.created_at_node,
    eoh.has_derived_child = soh.has_derived_child,
    eoh.has_derived_parent = soh.has_derived_parent,
    eoh.notification_type = soh.notification_type,
    eoh.notification_reference = soh.notification_reference,
    eoh.entry_type = soh.entry_type,
    eoh.authorized_client = soh.authorized_client,
    eoh.entered_by = soh.entered_by,
    eoh.personalize_code = soh.personalize_code,
    eoh.hold_flag = soh.hold_flag,
    eoh.hold_reason_code = soh.hold_reason_code,
    eoh.customer_po_no = soh.customer_po_no,
    eoh.customer_customer_po_no = soh.customer_customer_po_no,
    eoh.order_name = soh.order_name,
    eoh.payment_rule_id = soh.payment_rule_id,
    eoh.terms_code = soh.terms_code,
    eoh.delivery_code = soh.delivery_code,
    eoh.charge_actual_freight = soh.charge_actual_freight,
    eoh.original_tax = soh.original_tax,
    eoh.currency = soh.currency,
    eoh.enterprise_currency = soh.enterprise_currency,
    eoh.reporting_conversion_rate = soh.reporting_conversion_rate,
    eoh.reporting_conversion_date =  TRY_TO_TIMESTAMP(soh.reporting_conversion_date,'YYYYMMDDHHMISS')  ,
    eoh.payment_status = TRY_TO_TIMESTAMP(soh.payment_status,'YYYYMMDDHHMISS')  ,
    eoh.authorization_expiration_date = TRY_TO_TIMESTAMP(soh.authorization_expiration_date,'YYYYMMDDHHMISS')  ,
    eoh.search_criteria_1 = soh.search_criteria_1,
    eoh.search_criteria_2 = soh.search_criteria_2,
    eoh.fob = soh.fob,
    eoh.other_charges = soh.other_charges,
    eoh.price_program_key = soh.price_program_key,
    eoh.taxpayer_id = soh.taxpayer_id,
    eoh.tax_jurisdiction = soh.tax_jurisdiction,
    eoh.tax_exemption_certificate = soh.tax_exemption_certificate,
    eoh.purpose = soh.purpose,
    eoh.invoice_complete = soh.invoice_complete,
    eoh.order_closed = soh.order_closed,
    eoh.next_alert_ts = soh.next_alert_ts,
    eoh.do_not_consolidate = soh.do_not_consolidate,
    eoh.chain_type = soh.chain_type,
    eoh.adjustment_invoice_pending = soh.adjustment_invoice_pending,
    eoh.auto_cancel_date = TRY_TO_TIMESTAMP(soh.auto_cancel_date,'YYYYMMDDHHMISS')  ,
    eoh.sale_voided = soh.sale_voided,
    eoh.is_ship_complete = soh.is_ship_complete,
    eoh.is_line_ship_complete = soh.is_line_ship_complete,
    eoh.is_ship_single_node = soh.is_ship_single_node,
    eoh.is_line_ship_single_node = soh.is_line_ship_single_node,
    eoh.cancel_order_on_excp_flag = soh.cancel_order_on_excp_flag,
    eoh.optimization_type = soh.optimization_type,
    eoh.purge_history_date = TRY_TO_TIMESTAMP(soh.purge_history_date,'YYYYMMDDHHMISS')  ,
    eoh.pricing_classification_code = soh.pricing_classification_code,
    eoh.source_type = soh.source_type,
    eoh.source_key = soh.source_key,
    eoh.linked_source_key = soh.linked_source_key,
    eoh.original_container_key = soh.original_container_key,
    eoh.sold_to_key = soh.sold_to_key,
    eoh.team_code = soh.team_code,
    eoh.next_iter_seq_no = soh.next_iter_seq_no,
    eoh.next_iter_date = TRY_TO_TIMESTAMP(soh.next_iter_date,'YYYYMMDDHHMISS')  ,
    eoh.hrs_before_next_iter = soh.hrs_before_next_iter,
    eoh.createuserid = soh.createuserid,
    eoh.modifyuserid = soh.modifyuserid,
    eoh.createprogid = soh.createprogid,
    eoh.modifyprogid = soh.modifyprogid,
    eoh.lockid = soh.lockid,
    eoh.department_code = soh.department_code,
    eoh.buyer_user_id = soh.buyer_user_id,
    eoh.recreate_authorizations = soh.recreate_authorizations,
    eoh.customer_contact_id = soh.customer_contact_id,
    eoh.opportunity_key = soh.opportunity_key,
    eoh.is_expiration_date_overridden = soh.is_expiration_date_overridden ,
    eoh.expiration_date = TRY_TO_TIMESTAMP(soh.expiration_date,'YYYYMMDDHHMISS')  ,
    eoh.approval_cycle = soh.approval_cycle,
    eoh.in_store_payment_required = soh.in_store_payment_required,
    eoh.immediate_settlement_value = soh.immediate_settlement_value,
    eoh.customer_age = soh.customer_age,
    eoh.cart_id = soh.cart_id,
    eoh.rollout_version = soh.rollout_version,
    eoh.all_addresses_verified = soh.all_addresses_verified,
    eoh.compl_gift_box_qty = soh.compl_gift_box_qty,
    eoh.no_of_auth_strikes = soh.no_of_auth_strikes,
    eoh.source_ip_address = soh.source_ip_address,
    eoh.customer_first_name = soh.customer_first_name,
    eoh.customer_last_name = soh.customer_last_name,
    eoh.customer_phone_no = soh.customer_phone_no,
    eoh.customer_zip_code = soh.customer_zip_code,
    eoh.index_version = soh.index_version,
    eoh.extn_customer_type = soh.extn_customer_type,
    eoh.extn_customer_id = soh.extn_customer_id,
    eoh.extn_cba_ship_label = soh.extn_cba_ship_label,
    eoh.extn_amazon_tfm = soh.extn_amazon_tfm,
    eoh.extn_tfm_ship_status = soh.extn_tfm_ship_status,
    eoh.extn_financed_by_affirm = soh.extn_financed_by_affirm,
    eoh.extn_risk_status = soh.extn_risk_status,
    eoh.extn_sales_rep_cust_id = soh.extn_sales_rep_cust_id,
    eoh.extn_latest_ship_date = TRY_TO_TIMESTAMP(soh.extn_latest_ship_date,'YYYYMMDDHHMISS')  ,
    eoh.extn_latest_delivery_date = TRY_TO_TIMESTAMP(soh.extn_latest_delivery_date,'YYYYMMDDHHMISS')  ,
    eoh.extn_market_place_id = soh.extn_market_place_id,
    eoh.extn_order_status = soh.extn_order_status,
    eoh.extn_is_prime = soh.extn_is_prime,
    eoh.extn_giftee_full_name = soh.extn_giftee_full_name,
    eoh.extn_giftee_email_id = soh.extn_giftee_email_id,
    eoh.extn_sms_opt_in = soh.extn_sms_opt_in,
    eoh.extn_ga_tag_id = soh.extn_ga_tag_id,
    eoh.extn_fraud_status = soh.extn_fraud_status,
    eoh.extn_order_locale_code = soh.extn_order_locale_code,
    eoh.extn_shipto_firstname = soh.extn_shipto_firstname,
    eoh.extn_shipto_lastname = soh.extn_shipto_lastname,
    eoh.extn_shipto_zipcode = soh.extn_shipto_zipcode,
    eoh.extn_return_confirmed_by = soh.extn_return_confirmed_by,
    eoh.extn_edi_gcn = soh.extn_edi_gcn,
    eoh.extn_pk_header_key = soh.extn_pk_header_key,
    eoh.extn_merchant_id = soh.extn_merchant_id,
    eoh.extn_is_avalara = soh.extn_is_avalara,
    eoh.extn_req_cancel_date = TRY_TO_TIMESTAMP(soh.extn_req_cancel_date,'YYYYMMDDHHMISS'),
    eoh.extn_is_email_sent = soh.extn_is_email_sent,
    eoh.extn_is_txn_committed = soh.extn_is_txn_committed,
    eoh.extn_tax_txn_date = TO_date(soh.extn_tax_txn_date)  ,
    eoh.extn_last_refund_txn_code = soh.extn_last_refund_txn_code,
    eoh.extn_refund_txn_code = soh.extn_refund_txn_code,
    eoh.extn_min_estimated_delivery_date = soh.extn_min_estimated_delivery_date,  
    eoh.extn_max_estimated_delivery_date = soh.extn_max_estimated_delivery_date,
    eoh.extn_apply_migration_hold = soh.extn_apply_migration_hold,    
    eoh.extn_signifyd_order_id = soh.extn_signifyd_order_id,
    eoh.extn_primary_reason = soh.extn_primary_reason,
    eoh.extn_secondary_reason = soh.extn_secondary_reason,
    eoh.extn_sales_entry_type = soh.extn_sales_entry_type,
    eoh.extn_sales_order_type = soh.extn_sales_order_type,
    eoh.extn_warranty_order_no = soh.extn_warranty_order_no,
    eoh.extn_seller_payment_type = soh.extn_seller_payment_type,
    eoh.createts = TRY_TO_TIMESTAMP(soh.createts,'YYYYMMDDHHMISS'),
    eoh.modifyts = TRY_TO_TIMESTAMP(soh.modifyts,'YYYYMMDDHHMISS')
WHEN NOT MATCHED THEN
  INSERT  (  
    order_header_key  
    ,sourcing_classification  
    ,buyer_organization_code  
    ,seller_organization_code  
    ,document_type  
    ,bill_to_id  
    ,customer_rewards_no  
    ,vendor_id  
    ,ship_to_id  
    ,ship_node  
    ,receiving_node  
    ,buyer_receiving_node_id  
    ,mark_for_key  
    ,buyer_mark_for_node_id  
    ,req_delivery_date  
    ,req_cancel_date  
    ,req_ship_date  
    ,default_template  
    ,division  
    ,draft_order_flag  
    ,order_purpose  
    ,return_oh_key_for_exchange  
    ,exchange_type  
    ,pending_transfer_in  
    ,return_by_gift_recipient  
    ,allocation_rule_id  
    ,priority_code  
    ,priority_number  
    ,contact_key  
    ,scac  
    ,carrier_service_code  
    ,custcarrier_account_no  
    ,notify_after_shipment_flag  
    ,created_at_node  
    ,has_derived_child  
    ,has_derived_parent  
    ,notification_type  
    ,notification_reference  
    ,entry_type  
    ,authorized_client  
    ,entered_by  
    ,personalize_code  
    ,hold_flag  
    ,hold_reason_code  
    ,customer_po_no  
    ,customer_customer_po_no  
    ,order_name  
    ,payment_rule_id  
    ,terms_code  
    ,delivery_code  
    ,charge_actual_freight  
    ,original_tax  
    ,currency  
    ,enterprise_currency  
    ,reporting_conversion_rate  
    ,reporting_conversion_date  
    ,payment_status  
    ,authorization_expiration_date  
    ,search_criteria_1  
    ,search_criteria_2  
    ,fob  
    ,other_charges  
    ,price_program_key  
    ,taxpayer_id  
    ,tax_jurisdiction  
    ,tax_exemption_certificate  
    ,purpose  
    ,invoice_complete  
    ,order_closed  
    ,next_alert_ts  
    ,do_not_consolidate  
    ,chain_type  
    ,adjustment_invoice_pending  
    ,auto_cancel_date  
    ,sale_voided  
    ,is_ship_complete  
    ,is_line_ship_complete  
    ,is_ship_single_node  
    ,is_line_ship_single_node  
    ,cancel_order_on_excp_flag  
    ,optimization_type  
    ,purge_history_date  
    ,pricing_classification_code  
    ,source_type  
    ,source_key  
    ,linked_source_key  
    ,original_container_key  
    ,sold_to_key  
    ,team_code  
    ,next_iter_seq_no  
    ,next_iter_date  
    ,hrs_before_next_iter  
    ,createuserid  
    ,modifyuserid  
    ,createprogid  
    ,modifyprogid  
    ,lockid  
    ,department_code  
    ,buyer_user_id  
    ,recreate_authorizations  
    ,customer_contact_id  
    ,opportunity_key  
    ,is_expiration_date_overridden  
    ,expiration_date  
    ,approval_cycle  
    ,in_store_payment_required  
    ,immediate_settlement_value  
    ,customer_age  
    ,cart_id  
    ,rollout_version  
    ,all_addresses_verified  
    ,compl_gift_box_qty  
    ,no_of_auth_strikes  
    ,source_ip_address  
    ,customer_first_name  
    ,customer_last_name  
    ,customer_phone_no  
    ,customer_zip_code  
    ,index_version  
    ,extn_customer_type  
    ,extn_customer_id  
    ,extn_cba_ship_label  
    ,extn_amazon_tfm  
    ,extn_tfm_ship_status  
    ,extn_financed_by_affirm  
    ,extn_risk_status  
    ,extn_sales_rep_cust_id  
    ,extn_latest_ship_date  
    ,extn_latest_delivery_date  
    ,extn_market_place_id  
    ,extn_order_status  
    ,extn_is_prime  
    ,extn_giftee_full_name  
    ,extn_giftee_email_id  
    ,extn_sms_opt_in  
    ,extn_ga_tag_id  
    ,extn_fraud_status  
    ,extn_order_locale_code  
    ,extn_shipto_firstname  
    ,extn_shipto_lastname  
    ,extn_shipto_zipcode  
   ,extn_return_confirmed_by
   ,extn_edi_gcn
   ,extn_pk_header_key
   ,extn_merchant_id
   ,extn_is_avalara
   ,extn_req_cancel_date
   ,extn_is_email_sent
   ,extn_is_txn_committed
   ,extn_tax_txn_date
   ,extn_last_refund_txn_code
   ,extn_refund_txn_code
   ,extn_min_estimated_delivery_date
   ,extn_max_estimated_delivery_date
   ,extn_apply_migration_hold
   ,extn_signifyd_order_id
   ,extn_primary_reason
   ,extn_secondary_reason
   ,extn_sales_entry_type
   ,extn_sales_order_type
   ,extn_warranty_order_no
   ,extn_seller_payment_type
   ,createts
   ,modifyts
   ,inserted_date
   )  
  VALUES (
    soh.order_header_key,
    soh.sourcing_classification,
    soh.buyer_organization_code,
    soh.seller_organization_code,
    soh.document_type,
    soh.bill_to_id,
    soh.customer_rewards_no,
    soh.vendor_id,
    soh.ship_to_id,
    soh.ship_node,
    soh.receiving_node,
    soh.buyer_receiving_node_id,
    soh.mark_for_key,
    soh.buyer_mark_for_node_id,
    TRY_TO_TIMESTAMP(soh.req_delivery_date,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(soh.req_cancel_date,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(soh.req_ship_date,'YYYYMMDDHHMISS'),
    soh.default_template,
    soh.division,
    soh.draft_order_flag,
    soh.order_purpose,
    soh.return_oh_key_for_exchange,
    soh.exchange_type,
    soh.pending_transfer_in,
    soh.return_by_gift_recipient,
    soh.allocation_rule_id,
    soh.priority_code,
    soh.priority_number,
    soh.contact_key,
    soh.scac,
    soh.carrier_service_code,
    soh.custcarrier_account_no,
    soh.notify_after_shipment_flag,
    soh.created_at_node,
    soh.has_derived_child,
    soh.has_derived_parent,
    soh.notification_type,
    soh.notification_reference,
    soh.entry_type,
    soh.authorized_client,
    soh.entered_by,
    soh.personalize_code,
    soh.hold_flag,
    soh.hold_reason_code,
    soh.customer_po_no,
    soh.customer_customer_po_no,
    soh.order_name,
    soh.payment_rule_id,
    soh.terms_code,
    soh.delivery_code,
    soh.charge_actual_freight,
    soh.original_tax,
    soh.currency,
    soh.enterprise_currency,
    soh.reporting_conversion_rate,
    TRY_TO_TIMESTAMP(soh.reporting_conversion_date,'YYYYMMDDHHMISS'),
    soh.payment_status,
    TRY_TO_TIMESTAMP(soh.authorization_expiration_date,'YYYYMMDDHHMISS'),
    soh.search_criteria_1,
    soh.search_criteria_2,
    soh.fob,
    soh.other_charges,
    soh.price_program_key,
    soh.taxpayer_id,
    soh.tax_jurisdiction,
    soh.tax_exemption_certificate,
    soh.purpose,
    soh.invoice_complete,
    soh.order_closed,
    soh.next_alert_ts,
    soh.do_not_consolidate,
    soh.chain_type,
    soh.adjustment_invoice_pending,
    TRY_TO_TIMESTAMP(soh.auto_cancel_date,'YYYYMMDDHHMISS'),
    soh.sale_voided,
    soh.is_ship_complete,
    soh.is_line_ship_complete,
    soh.is_ship_single_node,
    soh.is_line_ship_single_node,
    soh.cancel_order_on_excp_flag,
    soh.optimization_type,
    TRY_TO_TIMESTAMP(soh.purge_history_date,'YYYYMMDDHHMISS'),
    soh.pricing_classification_code,
    soh.source_type,
    soh.source_key,
    soh.linked_source_key,
    soh.original_container_key,
    soh.sold_to_key,
    soh.team_code,
    soh.next_iter_seq_no,
    TRY_TO_TIMESTAMP(soh.next_iter_date,'YYYYMMDDHHMISS'),
    soh.hrs_before_next_iter,
    soh.createuserid,
    soh.modifyuserid,
    soh.createprogid,
    soh.modifyprogid,
    soh.lockid,
    soh.department_code,
    soh.buyer_user_id,
    soh.recreate_authorizations,
    soh.customer_contact_id,
    soh.opportunity_key,
    soh.is_expiration_date_overridden,
    TRY_TO_TIMESTAMP(soh.expiration_date,'YYYYMMDDHHMISS'),
    soh.approval_cycle,
    soh.in_store_payment_required,
    soh.immediate_settlement_value,
    soh.customer_age,
    soh.cart_id,
    soh.rollout_version,
    soh.all_addresses_verified,
    soh.compl_gift_box_qty,
    soh.no_of_auth_strikes,
    soh.source_ip_address,
    soh.customer_first_name,
    soh.customer_last_name,
    soh.customer_phone_no,
    soh.customer_zip_code,
    soh.index_version,
    soh.extn_customer_type,
    soh.extn_customer_id,
    soh.extn_cba_ship_label,
    soh.extn_amazon_tfm,
    soh.extn_tfm_ship_status,
    soh.extn_financed_by_affirm,
    soh.extn_risk_status,
    soh.extn_sales_rep_cust_id,
    TRY_TO_TIMESTAMP(soh.extn_latest_ship_date,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(soh.extn_latest_delivery_date,'YYYYMMDDHHMISS'),
    soh.extn_market_place_id,
    soh.extn_order_status,
    soh.extn_is_prime,
    soh.extn_giftee_full_name,
    soh.extn_giftee_email_id,
    soh.extn_sms_opt_in,
    soh.extn_ga_tag_id,
    soh.extn_fraud_status,
    soh.extn_order_locale_code,
    soh.extn_shipto_firstname,
    soh.extn_shipto_lastname,
    soh.extn_shipto_zipcode,
    soh.extn_return_confirmed_by,
    soh.extn_edi_gcn,
    soh.extn_pk_header_key,
    soh.extn_merchant_id,
    soh.extn_is_avalara,
    TRY_TO_TIMESTAMP(soh.extn_req_cancel_date,'YYYYMMDDHHMISS'),
    soh.extn_is_email_sent,
    soh.extn_is_txn_committed,
    TO_date(soh.extn_tax_txn_date),
    soh.extn_last_refund_txn_code,
    soh.extn_refund_txn_code,
   soh.extn_min_estimated_delivery_date,
    soh.extn_max_estimated_delivery_date,
    soh.extn_apply_migration_hold,
    soh.extn_signifyd_order_id,
    soh.extn_primary_reason,
    soh.extn_secondary_reason,
    soh.extn_sales_entry_type,
    soh.extn_sales_order_type,
    soh.extn_warranty_order_no,
    soh.extn_seller_payment_type,
    TRY_TO_TIMESTAMP(soh.createts,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(soh.modifyts,'YYYYMMDDHHMISS'),
    CURRENT_TIMESTAMP()
  );

INSERT INTO TempExtOrderHeader(
order_header_key  
    ,sourcing_classification  
    ,buyer_organization_code  
    ,seller_organization_code  
    ,document_type  
    ,bill_to_id  
    ,customer_rewards_no  
    ,vendor_id  
    ,ship_to_id  
    ,ship_node  
    ,receiving_node  
    ,buyer_receiving_node_id  
    ,mark_for_key  
    ,buyer_mark_for_node_id  
    ,req_delivery_date  
    ,req_cancel_date  
    ,req_ship_date  
    ,default_template  
    ,division  
    ,draft_order_flag  
    ,order_purpose  
    ,return_oh_key_for_exchange  
    ,exchange_type  
    ,pending_transfer_in  
    ,return_by_gift_recipient  
    ,allocation_rule_id  
    ,priority_code  
    ,priority_number  
    ,contact_key  
    ,scac  
    ,carrier_service_code  
    ,custcarrier_account_no  
    ,notify_after_shipment_flag  
    ,created_at_node  
    ,has_derived_child  
    ,has_derived_parent  
    ,notification_type  
    ,notification_reference  
    ,entry_type  
    ,authorized_client  
    ,entered_by  
    ,personalize_code  
    ,hold_flag  
    ,hold_reason_code  
    ,customer_po_no  
    ,customer_customer_po_no  
    ,order_name  
    ,payment_rule_id  
    ,terms_code  
    ,delivery_code  
    ,charge_actual_freight  
    ,original_tax  
    ,currency  
    ,enterprise_currency  
    ,reporting_conversion_rate  
    ,reporting_conversion_date  
    ,payment_status  
    ,authorization_expiration_date  
    ,search_criteria_1  
    ,search_criteria_2  
    ,fob  
    ,other_charges  
    ,price_program_key  
    ,taxpayer_id  
    ,tax_jurisdiction  
    ,tax_exemption_certificate  
    ,purpose  
    ,invoice_complete  
    ,order_closed  
    ,next_alert_ts  
    ,do_not_consolidate  
    ,chain_type  
    ,adjustment_invoice_pending  
    ,auto_cancel_date  
    ,sale_voided  
    ,is_ship_complete  
    ,is_line_ship_complete  
    ,is_ship_single_node  
    ,is_line_ship_single_node  
    ,cancel_order_on_excp_flag  
    ,optimization_type  
    ,purge_history_date  
    ,pricing_classification_code  
    ,source_type  
    ,source_key  
    ,linked_source_key  
    ,original_container_key  
    ,sold_to_key  
    ,team_code  
    ,next_iter_seq_no  
    ,next_iter_date  
    ,hrs_before_next_iter  
    ,createuserid  
    ,modifyuserid  
    ,createprogid  
    ,modifyprogid  
    ,lockid  
    ,department_code  
    ,buyer_user_id  
    ,recreate_authorizations  
    ,customer_contact_id  
    ,opportunity_key  
    ,is_expiration_date_overridden  
    ,expiration_date  
    ,approval_cycle  
    ,in_store_payment_required  
    ,immediate_settlement_value  
    ,customer_age  
    ,cart_id  
    ,rollout_version  
    ,all_addresses_verified  
    ,compl_gift_box_qty  
    ,no_of_auth_strikes  
    ,source_ip_address  
    ,customer_first_name  
    ,customer_last_name  
    ,customer_phone_no  
    ,customer_zip_code  
    ,index_version  
    ,extn_customer_type  
    ,extn_customer_id  
    ,extn_cba_ship_label  
    ,extn_amazon_tfm  
    ,extn_tfm_ship_status  
    ,extn_financed_by_affirm  
    ,extn_risk_status  
    ,extn_sales_rep_cust_id  
    ,extn_latest_ship_date  
    ,extn_latest_delivery_date  
    ,extn_market_place_id  
    ,extn_order_status  
    ,extn_is_prime  
    ,extn_giftee_full_name  
    ,extn_giftee_email_id  
    ,extn_sms_opt_in  
    ,extn_ga_tag_id  
    ,extn_fraud_status  
    ,extn_order_locale_code  
    ,extn_shipto_firstname  
    ,extn_shipto_lastname  
    ,extn_shipto_zipcode
	,extn_return_confirmed_by
    ,extn_edi_gcn
    ,extn_pk_header_key
    ,extn_merchant_id
    ,extn_is_avalara
    ,extn_req_cancel_date
    ,extn_is_email_sent
    ,extn_is_txn_committed
    ,extn_tax_txn_date
    ,extn_last_refund_txn_code
    ,extn_refund_txn_code
    ,extn_min_estimated_delivery_date
    ,extn_max_estimated_delivery_date
    ,extn_apply_migration_hold
    ,extn_signifyd_order_id
    ,extn_primary_reason
    ,extn_secondary_reason
    ,extn_sales_entry_type
    ,extn_sales_order_type
    ,extn_warranty_order_no
    ,extn_seller_payment_type
	,createts
	,modifyts
    ,Revision  
)
SELECT DISTINCT
    stg.order_header_key,
    stg.sourcing_classification,
    stg.buyer_organization_code,
    stg.seller_organization_code,
    stg.document_type,
    stg.bill_to_id,
    stg.customer_rewards_no,
    stg.vendor_id,
    stg.ship_to_id,
    stg.ship_node,
    stg.receiving_node,
    stg.buyer_receiving_node_id,
    stg.mark_for_key,
    stg.buyer_mark_for_node_id,
    stg.req_delivery_date,
    stg.req_cancel_date,
    stg.req_ship_date,
    stg.default_template,
    stg.division,
    stg.draft_order_flag,
    stg.order_purpose,
    stg.return_oh_key_for_exchange,
    stg.exchange_type,
    stg.pending_transfer_in,
    stg.return_by_gift_recipient,
    stg.allocation_rule_id,
    stg.priority_code,
    stg.priority_number,
    stg.contact_key,
    stg.scac,
    stg.carrier_service_code,
    stg.custcarrier_account_no,
    stg.notify_after_shipment_flag,
    stg.created_at_node,
    stg.has_derived_child,
    stg.has_derived_parent,
    stg.notification_type,
    stg.notification_reference,
    stg.entry_type,
    stg.authorized_client,
    stg.entered_by,
    stg.personalize_code,
    stg.hold_flag,
    stg.hold_reason_code,
    stg.customer_po_no,
    stg.customer_customer_po_no,
    stg.order_name,
    stg.payment_rule_id,
    stg.terms_code,
    stg.delivery_code,
    stg.charge_actual_freight,
    stg.original_tax,
    stg.currency,
    stg.enterprise_currency,
    stg.reporting_conversion_rate,
    stg.reporting_conversion_date,
    stg.payment_status,
    stg.authorization_expiration_date,
    stg.search_criteria_1,
    stg.search_criteria_2,
    stg.fob,
    stg.other_charges,
    stg.price_program_key,
    stg.taxpayer_id,
    stg.tax_jurisdiction,
    stg.tax_exemption_certificate,
    stg.purpose,
    stg.invoice_complete,
    stg.order_closed,
    stg.next_alert_ts,
    stg.do_not_consolidate,
    stg.chain_type,
    stg.adjustment_invoice_pending,
    stg.auto_cancel_date,
    stg.sale_voided,
    stg.is_ship_complete,
    stg.is_line_ship_complete,
    stg.is_ship_single_node,
    stg.is_line_ship_single_node,
    stg.cancel_order_on_excp_flag,
    stg.optimization_type,
    stg.purge_history_date,
    stg.pricing_classification_code,
    stg.source_type,
    stg.source_key,
    stg.linked_source_key,
    stg.original_container_key,
    stg.sold_to_key,
    stg.team_code,
    stg.next_iter_seq_no,
    stg.next_iter_date,
    stg.hrs_before_next_iter,
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    stg.department_code,
    stg.buyer_user_id,
    stg.recreate_authorizations,
    stg.customer_contact_id,
    stg.opportunity_key,
    stg.is_expiration_date_overridden,
    stg.expiration_date,
    stg.approval_cycle,
    stg.in_store_payment_required,
    stg.immediate_settlement_value,
    stg.customer_age,
    stg.cart_id,
    stg.rollout_version,
    stg.all_addresses_verified,
    stg.compl_gift_box_qty,
    stg.no_of_auth_strikes,
    stg.source_ip_address,
    stg.customer_first_name,
    stg.customer_last_name,
    stg.customer_phone_no,
    stg.customer_zip_code,
    stg.index_version,
    stg.extn_customer_type,
    stg.extn_customer_id,
    stg.extn_cba_ship_label,
    stg.extn_amazon_tfm,
    stg.extn_tfm_ship_status,
    stg.extn_financed_by_affirm,
    stg.extn_risk_status,
    stg.extn_sales_rep_cust_id,
    stg.extn_latest_ship_date,
    stg.extn_latest_delivery_date,
    stg.extn_market_place_id,
    stg.extn_order_status,
    stg.extn_is_prime,
    stg.extn_giftee_full_name,
    stg.extn_giftee_email_id,
    stg.extn_sms_opt_in,
    stg.extn_ga_tag_id,
    stg.extn_fraud_status,
    stg.extn_order_locale_code,
    stg.extn_shipto_firstname,
    stg.extn_shipto_lastname,
    stg.extn_shipto_zipcode,
    stg.extn_return_confirmed_by,
    stg.extn_edi_gcn,
    stg.extn_pk_header_key,
    stg.extn_merchant_id,
    stg.extn_is_avalara,
    stg.extn_req_cancel_date,
    stg.extn_is_email_sent,
    stg.extn_is_txn_committed,
    stg.extn_tax_txn_date,
    stg.extn_last_refund_txn_code,
    stg.extn_refund_txn_code,
    stg.extn_min_estimated_delivery_date,
    stg.extn_max_estimated_delivery_date,
    stg.extn_apply_migration_hold,
    stg.extn_signifyd_order_id,
    stg.extn_primary_reason,
    stg.extn_secondary_reason,
    stg.extn_sales_entry_type,
    stg.extn_sales_order_type,
    stg.extn_warranty_order_no,
    stg.extn_seller_payment_type,
    stg.createts,
    stg.modifyts,
    1 as revision
  FROM TRANSFORMED.stg_order_header stg
  INNER JOIN RAW.raw_order_header r
    ON r.order_header_key = stg.order_header_key
    AND r.modifyts = stg.modifyts
    AND r.processing_status = 'Processed';

CREATE OR REPLACE TEMPORARY TABLE TempAuditRevisions AS
SELECT  
    MAX(aot.revision) AS revision,  
    aot.order_header_key  
FROM  
    ANALYTICS.audit_ext_order_header AS aot  
    INNER JOIN TempExtOrderHeader AS ttd 
    ON ttd.order_header_key = aot.order_header_key  
GROUP BY  
    aot.order_header_key;

UPDATE TempExtOrderHeader ttd
SET ttd.Revision = NVL(aot.revision, 0) + 1
FROM TempAuditRevisions aot
WHERE ttd.order_header_key = aot.order_header_key;

DROP TABLE IF EXISTS TempAuditRevisions;

INSERT INTO ANALYTICS.audit_ext_order_header (
    order_header_key
    ,sourcing_classification
    ,buyer_organization_code
    ,seller_organization_code
    ,document_type
    ,bill_to_id
    ,customer_rewards_no
    ,vendor_id
    ,ship_to_id
    ,ship_node
    ,receiving_node
    ,buyer_receiving_node_id
    ,mark_for_key
    ,buyer_mark_for_node_id
    ,req_delivery_date
    ,req_cancel_date
    ,req_ship_date
    ,default_template
    ,division
    ,draft_order_flag
    ,order_purpose
    ,return_oh_key_for_exchange
    ,exchange_type
    ,pending_transfer_in
    ,return_by_gift_recipient
    ,allocation_rule_id
    ,priority_code
    ,priority_number
    ,contact_key
    ,scac
    ,carrier_service_code
    ,custcarrier_account_no
    ,notify_after_shipment_flag
    ,created_at_node
    ,has_derived_child
    ,has_derived_parent
    ,notification_type
    ,notification_reference
    ,entry_type
    ,authorized_client
    ,entered_by
    ,personalize_code
    ,hold_flag
    ,hold_reason_code
    ,customer_po_no
    ,customer_customer_po_no
    ,order_name
    ,payment_rule_id
    ,terms_code
    ,delivery_code
    ,charge_actual_freight
    ,original_tax
    ,currency
    ,enterprise_currency
    ,reporting_conversion_rate
    ,reporting_conversion_date
    ,payment_status
    ,authorization_expiration_date
    ,search_criteria_1
    ,search_criteria_2
    ,fob
    ,other_charges
    ,price_program_key
    ,taxpayer_id
    ,tax_jurisdiction
    ,tax_exemption_certificate
    ,purpose
    ,invoice_complete
    ,order_closed
    ,next_alert_ts
    ,do_not_consolidate
    ,chain_type
    ,adjustment_invoice_pending
    ,auto_cancel_date
    ,sale_voided
    ,is_ship_complete
    ,is_line_ship_complete
    ,is_ship_single_node
    ,is_line_ship_single_node
    ,cancel_order_on_excp_flag
    ,optimization_type
    ,purge_history_date
    ,pricing_classification_code
    ,source_type
    ,source_key
    ,linked_source_key
    ,original_container_key
    ,sold_to_key
    ,team_code
    ,next_iter_seq_no
    ,next_iter_date
    ,hrs_before_next_iter
    ,createuserid
    ,modifyuserid
    ,createprogid
    ,modifyprogid
    ,lockid
    ,department_code
    ,buyer_user_id
    ,recreate_authorizations
    ,customer_contact_id
    ,opportunity_key
    ,is_expiration_date_overridden
    ,expiration_date
    ,approval_cycle
    ,in_store_payment_required
    ,immediate_settlement_value
    ,customer_age
    ,cart_id
    ,rollout_version
    ,all_addresses_verified
    ,compl_gift_box_qty
    ,no_of_auth_strikes
    ,source_ip_address
    ,customer_first_name
    ,customer_last_name
    ,customer_phone_no
    ,customer_zip_code
    ,index_version
    ,extn_customer_type
    ,extn_customer_id
    ,extn_cba_ship_label
    ,extn_amazon_tfm
    ,extn_tfm_ship_status
    ,extn_financed_by_affirm
    ,extn_risk_status
    ,extn_sales_rep_cust_id
    ,extn_latest_ship_date
    ,extn_latest_delivery_date
    ,extn_market_place_id
    ,extn_order_status
    ,extn_is_prime
    ,extn_giftee_full_name
    ,extn_giftee_email_id
    ,extn_sms_opt_in
    ,extn_ga_tag_id
    ,extn_fraud_status
    ,extn_order_locale_code
    ,extn_shipto_firstname
    ,extn_shipto_lastname
    ,extn_shipto_zipcode
    ,extn_return_confirmed_by
    ,extn_edi_gcn
    ,extn_pk_header_key
    ,extn_merchant_id
    ,extn_is_avalara
    ,extn_req_cancel_date
    ,extn_is_email_sent
    ,extn_is_txn_committed
    ,extn_tax_txn_date
    ,extn_last_refund_txn_code
    ,extn_refund_txn_code
    ,extn_min_estimated_delivery_date
    ,extn_max_estimated_delivery_date
    ,extn_apply_migration_hold
    ,extn_signifyd_order_id
    ,extn_primary_reason
    ,extn_secondary_reason
    ,extn_sales_entry_type
    ,extn_sales_order_type
    ,extn_warranty_order_no
    ,extn_seller_payment_type
    ,createts
    ,modifyts
    ,inserted_date  -- Equivalent to GETDATE() in Snowflake
    ,Revision
)
SELECT
    stg.order_header_key
    ,stg.sourcing_classification
    ,stg.buyer_organization_code
    ,stg.seller_organization_code
    ,stg.document_type
    ,stg.bill_to_id
    ,stg.customer_rewards_no
    ,stg.vendor_id
    ,stg.ship_to_id
    ,stg.ship_node
    ,stg.receiving_node
    ,stg.buyer_receiving_node_id
    ,stg.mark_for_key
    ,stg.buyer_mark_for_node_id
    ,TRY_TO_TIMESTAMP(stg.req_delivery_date,'YYYYMMDDHHMISS')
    ,TRY_TO_TIMESTAMP(stg.req_cancel_date,'YYYYMMDDHHMISS')
    ,TRY_TO_TIMESTAMP(stg.req_ship_date,'YYYYMMDDHHMISS')
    ,stg.default_template
    ,stg.division
    ,stg.draft_order_flag
    ,stg.order_purpose
    ,stg.return_oh_key_for_exchange
    ,stg.exchange_type
    ,stg.pending_transfer_in
    ,stg.return_by_gift_recipient
    ,stg.allocation_rule_id
    ,stg.priority_code
    ,stg.priority_number
    ,stg.contact_key
    ,stg.scac
    ,stg.carrier_service_code
    ,stg.custcarrier_account_no
    ,stg.notify_after_shipment_flag
    ,stg.created_at_node
    ,stg.has_derived_child
    ,stg.has_derived_parent
    ,stg.notification_type
    ,stg.notification_reference
    ,stg.entry_type
    ,stg.authorized_client
    ,stg.entered_by
    ,stg.personalize_code
    ,stg.hold_flag
    ,stg.hold_reason_code
    ,stg.customer_po_no
    ,stg.customer_customer_po_no
    ,stg.order_name
    ,stg.payment_rule_id
    ,stg.terms_code
    ,stg.delivery_code
    ,stg.charge_actual_freight
    ,stg.original_tax
    ,stg.currency
    ,stg.enterprise_currency
    ,stg.reporting_conversion_rate
    ,TRY_TO_TIMESTAMP(stg.reporting_conversion_date,'YYYYMMDDHHMISS')
    ,stg.payment_status
    ,TRY_TO_TIMESTAMP(stg.authorization_expiration_date,'YYYYMMDDHHMISS')
    ,stg.search_criteria_1
    ,stg.search_criteria_2
    ,stg.fob
    ,stg.other_charges
    ,stg.price_program_key
    ,stg.taxpayer_id
    ,stg.tax_jurisdiction
    ,stg.tax_exemption_certificate
    ,stg.purpose
    ,stg.invoice_complete
    ,stg.order_closed
    ,stg.next_alert_ts
    ,stg.do_not_consolidate
    ,stg.chain_type
    ,stg.adjustment_invoice_pending
    ,TRY_TO_TIMESTAMP(stg.auto_cancel_date,'YYYYMMDDHHMISS')
    ,stg.sale_voided
    ,stg.is_ship_complete
    ,stg.is_line_ship_complete
    ,stg.is_ship_single_node
    ,stg.is_line_ship_single_node
    ,stg.cancel_order_on_excp_flag
    ,stg.optimization_type
    ,TRY_TO_TIMESTAMP(stg.purge_history_date,'YYYYMMDDHHMISS')
    ,stg.pricing_classification_code
    ,stg.source_type
    ,stg.source_key
    ,stg.linked_source_key
    ,stg.original_container_key
    ,stg.sold_to_key
    ,stg.team_code
    ,stg.next_iter_seq_no
    ,TRY_TO_TIMESTAMP(stg.next_iter_date,'YYYYMMDDHHMISS')
    ,stg.hrs_before_next_iter
    ,stg.createuserid
    ,stg.modifyuserid
    ,stg.createprogid
    ,stg.modifyprogid
    ,stg.lockid
    ,stg.department_code
    ,stg.buyer_user_id
    ,stg.recreate_authorizations
    ,stg.customer_contact_id
    ,stg.opportunity_key
    ,stg.is_expiration_date_overridden
    ,TRY_TO_TIMESTAMP(stg.expiration_date,'YYYYMMDDHHMISS')
    ,stg.approval_cycle
    ,stg.in_store_payment_required
    ,stg.immediate_settlement_value
    ,stg.customer_age
    ,stg.cart_id
    ,stg.rollout_version
    ,stg.all_addresses_verified
    ,stg.compl_gift_box_qty
    ,stg.no_of_auth_strikes
    ,stg.source_ip_address
    ,stg.customer_first_name
    ,stg.customer_last_name
    ,stg.customer_phone_no
    ,stg.customer_zip_code
    ,stg.index_version
    ,stg.extn_customer_type
    ,stg.extn_customer_id
    ,stg.extn_cba_ship_label
    ,stg.extn_amazon_tfm
    ,stg.extn_tfm_ship_status
    ,stg.extn_financed_by_affirm
    ,stg.extn_risk_status
    ,stg.extn_sales_rep_cust_id
    ,TRY_TO_TIMESTAMP(stg.extn_latest_ship_date,'YYYYMMDDHHMISS')
    ,TRY_TO_TIMESTAMP(stg.extn_latest_delivery_date,'YYYYMMDDHHMISS')
    ,stg.extn_market_place_id
    ,stg.extn_order_status
    ,stg.extn_is_prime
    ,stg.extn_giftee_full_name
    ,stg.extn_giftee_email_id
    ,stg.extn_sms_opt_in
    ,stg.extn_ga_tag_id
    ,stg.extn_fraud_status
    ,stg.extn_order_locale_code
    ,stg.extn_shipto_firstname
    ,stg.extn_shipto_lastname
    ,stg.extn_shipto_zipcode
    ,stg.extn_return_confirmed_by
    ,stg.extn_edi_gcn
    ,stg.extn_pk_header_key
    ,stg.extn_merchant_id
    ,stg.extn_is_avalara
    ,TRY_TO_TIMESTAMP(stg.extn_req_cancel_date,'YYYYMMDDHHMISS')
    ,stg.extn_is_email_sent
    ,stg.extn_is_txn_committed
    ,TO_DATE(stg.extn_tax_txn_date)
    ,stg.extn_last_refund_txn_code
    ,stg.extn_refund_txn_code
    ,stg.extn_min_estimated_delivery_date
    ,stg.extn_max_estimated_delivery_date
    ,stg.extn_apply_migration_hold
    ,stg.extn_signifyd_order_id
    ,stg.extn_primary_reason
    ,stg.extn_secondary_reason
    ,stg.extn_sales_entry_type
    ,stg.extn_sales_order_type
    ,stg.extn_warranty_order_no
    ,stg.extn_seller_payment_type
    ,TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS')
    ,TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS')
    ,CURRENT_TIMESTAMP()  -- Equivalent to GETDATE() in Snowflake
    ,ord.Revision
FROM TRANSFORMED.stg_order_header stg
INNER JOIN RAW.raw_order_header r
    ON r.order_header_key = stg.order_header_key
    AND r.modifyts = stg.modifyts
    AND r.processing_status = 'Processed'
INNER JOIN TempExtOrderHeader ord
    ON ord.order_header_key = stg.order_header_key;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);



DROP TABLE IF EXISTS TempExtOrderHeader;

RETURN 'Success';
EXCEPTION 
WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
            
    RETURN sqlerrm;
END;

CREATE PROCEDURE "USP_EXT_ORDER_LINE_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    createdby NUMBER DEFAULT 1;
    action STRING DEFAULT ''CREATE'';
    productTaxType STRING DEFAULT ''PRODUCT'';
    personalizationFeeType STRING DEFAULT ''FEE-PERSONALIZE'';
    domesticSource STRING DEFAULT ''domestic'';
    internationalSource STRING DEFAULT ''international'';
    processedRecordCount BIGINT DEFAULT 0;
    processedDate TIMESTAMP_NTZ(9);
    start_time_proc TIMESTAMP_NTZ(9);
    error_object VARIANT;
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
		CREATE OR REPLACE TEMP TABLE TempExtOrderDEtail (
    order_line_key STRING,
    order_header_key STRING,
    prime_line_no STRING,
    sub_line_no STRING,
    line_type STRING,
    order_class STRING,
    alternate_item_id STRING,
    uom STRING,
    product_class STRING,
    cost_currency STRING,
    basic_capacity_required STRING,
    option_capacity_required STRING,
    dependent_on_line_key STRING,
    current_work_order_key STRING,
    dependency_shipping_rule STRING,
    fill_quantity STRING,
    committed_quantity STRING,
    dependency_ratio STRING,
    maintain_ratio STRING,
    merge_node STRING,
    parent_of_dependent_group STRING,
    source_from_organization STRING,
    chained_from_order_line_key STRING,
    chained_from_order_header_key STRING,
    derived_from_order_line_key STRING,
    derived_from_order_header_key STRING,
    derived_from_order_release_key STRING,
    distribution_rule_id STRING,
    invoiced_quantity STRING,
    over_receipt_quantity STRING,
    return_reason STRING,
    shipnode_key STRING,
    procure_from_node STRING,
    ship_to_key STRING,
    mark_for_key STRING,
    buyer_mark_for_node_id STRING,
    req_delivery_date STRING,
    req_cancel_date STRING,
    req_ship_date STRING,
    scac STRING,
    carrier_service_code STRING,
    carrier_account_no STRING,
    pickable_flag STRING,
    ship_together_no STRING,
    hold_flag STRING,
    kit_code STRING,
    hold_reason_code STRING,
    other_charges STRING,
    invoiced_line_total STRING,
    invoiced_extended_price STRING,
    settled_quantity STRING,
    settled_amount STRING,
    tax_exemption_certificate STRING,
    discount_type STRING,
    discount_reference STRING,
    gift_flag STRING,
    personalize_flag STRING,
    personalize_code STRING,
    department_code STRING,
    customer_item STRING,
    customer_item_description STRING,
    item_weight STRING,
    item_weight_uom STRING,
    item_description STRING,
    item_short_description STRING,
    reservation_id STRING,
    reservation_pool STRING,
    customer_po_no STRING,
    customer_po_line_no STRING,
    tax STRING,
    delivery_code STRING,
    original_ordered_qty STRING,
    list_price STRING,
    retail_price STRING,
    discount_percentage STRING,
    packlist_type STRING,
    supplier_item STRING,
    supplier_item_description STRING,
    unit_cost STRING,
    upc_code STRING,
    fob STRING,
    manufacturer_name STRING,
    manufacturer_item STRING,
    manufacturer_item_desc STRING,
    country_of_origin STRING,
    isbn STRING,
    harmonized_code STRING,
    ship_to_id STRING,
    product_line STRING,
    nmfc_code STRING,
    nmfc_class STRING,
    nmfc_description STRING,
    tax_product_code STRING,
    import_license_no STRING,
    import_license_exp_date STRING,
    eccn_no STRING,
    schedule_b_code STRING,
    supplier_code STRING,
    purpose STRING,
    receiving_node STRING,
    buyer_receiving_node_id STRING,
    shipment_consol_group_id STRING,
    orig_order_line_key STRING,
    line_seq_no STRING,
    split_qty STRING,
    pricing_date STRING,
    pipeline_key STRING,
    condition_variable_1 STRING,
    condition_variable_2 STRING,
    is_price_locked STRING,
    is_cost_overridden STRING,
    is_capacity_overridden STRING,
    invoice_complete STRING,
    delivery_method STRING,
    item_group_code STRING,
    cannot_complete_before_date STRING,
    cannot_complete_after_date STRING,
    appt_status STRING,
    can_add_service_lines STRING,
    pricing_uom STRING,
    capacity_uom STRING,
    pricing_quantity STRING,
    shipped_quantity STRING,
    fixed_capacity_qty_per_line STRING,
    fixed_pricing_qty_per_line STRING,
    wait_for_seq_line STRING,
    sched_failure_reason_code STRING,
    earliest_ship_date STRING,
    earliest_delivery_date STRING,
    cannot_meet_appt STRING,
    promised_appt_start_date STRING,
    promised_appt_end_date STRING,
    segment STRING,
    segment_type STRING,
    earliest_schedule_date STRING,
    timezone STRING,
    is_forwarding_allowed STRING,
    is_procurement_allowed STRING,
    reship_parent_line_key STRING,
    bundle_parent_order_line_key STRING,
    is_price_info_only STRING,
    level_of_service STRING,
    first_iter_seq_no STRING,
    last_iter_seq_no STRING,
    createts STRING,
    modifyts STRING,
    createuserid STRING,
    modifyuserid STRING,
    createprogid STRING,
    modifyprogid STRING,
    lockid STRING,
    ordering_uom STRING,
    pricing_quantity_conv_factor STRING,
    pricing_quantity_strategy STRING,
    invoiced_pricing_quantity STRING,
    is_standalone_service STRING,
    tran_discrepancy_qty STRING,
    received_quantity STRING,
    invoice_based_on_actuals STRING,
    actual_pricing_quantity STRING,
    fulfillment_type STRING,
    serial_no STRING,
    reservation_mandatory STRING,
    is_firm_predefined_node STRING,
    intentional_backorder STRING,
    future_avail_date STRING,
    repricing_quantity STRING,
    min_ship_by_date STRING,
    kit_qty STRING,
    bom_config_key STRING,
    bundle_fulfillment_mode STRING,
    is_gift_wrap STRING,
    group_sequence_num STRING,
    in_store_payment_required STRING,
    item_not_exist STRING,
    derived_from_ext_ord STRING,
    is_eligible_for_ship_disc STRING,
    backorder_notification_qty STRING,
    is_price_matched STRING,
    is_pick_up_now STRING,
    item_is_in_hand STRING,
    disposition_code STRING,
    extn_mod_reason_code STRING,
    extn_mod_reason_desc STRING,
    extn_asn STRING,
    extn_parent_order_no STRING,
    extn_item_id STRING,
    extn_order_item_id STRING,
    extn_price_type STRING,
    extn_secondary_return_reason STRING,
    extn_apply_label_fee STRING,
    extn_is_activation_complete STRING,
    extn_item_desc STRING,
    extn_return_carton_count STRING,
    extn_asn_quantity STRING,
    extn_light_color STRING,
    extn_light_type STRING,
    extn_number_of_sections STRING,
    extn_total_cartons STRING,
    extn_tree_height STRING,
    extn_tree_height_uom STRING,
    extn_apply_restocking_fee STRING,
    extn_return_pickup_date STRING,
    extn_pickup_confirmation_no STRING,
    extn_refund_shipping_cost STRING,
    extn_is_fulfilled_line STRING,
    extn_mfg_warranty_start_date STRING,
    extn_mfg_warranty_end_date STRING,
    extn_term STRING,
    extn_is_invoice_required STRING,
    extn_prem_guarantee_end_date STRING,
    extn_return_date STRING,
    extn_is_email_sent STRING,
    extn_return_required STRING,
    extn_parent_prime_line_no STRING,
    extn_parent_sub_line_no STRING,
    extn_prem_guarantee_start_date STRING,
    extn_reship_upcid STRING,
    extn_parent_order_line_sku STRING,
    unit_price DECIMAL(12, 6),
    line_total DECIMAL(12, 6),
    revision STRING
);

processedDate := CURRENT_TIMESTAMP();

ALTER TABLE analytics.ext_order_detail DROP COLUMN if exists inserted_date;

ALTER TABLE analytics.ext_order_detail ADD COLUMN INSERTED_DATE TIMESTAMP_NTZ;

		MERGE into analytics.ext_order_detail eod USING (
		SELECT stg.order_line_key
			,stg.order_header_key
			,stg.prime_line_no
			,stg.sub_line_no
			,stg.line_type
			,stg.order_class
			,stg.alternate_item_id
			,stg.uom
			,stg.product_class
			,stg.cost_currency
			,stg.basic_capacity_required
			,stg.option_capacity_required
			,stg.dependent_on_line_key
			,stg.current_work_order_key
			,stg.dependency_shipping_rule
			,stg.fill_quantity
			,stg.committed_quantity
			,stg.dependency_ratio
			,stg.maintain_ratio
			,stg.merge_node
			,stg.parent_of_dependent_group
			,stg.source_from_organization
			,stg.chained_from_order_line_key
			,stg.chained_from_order_header_key
			,stg.derived_from_order_line_key
			,stg.derived_from_order_header_key
			,stg.derived_from_order_release_key
			,stg.distribution_rule_id
			,stg.invoiced_quantity
			,stg.over_receipt_quantity
			,stg.return_reason
			,stg.shipnode_key
			,stg.procure_from_node
			,stg.ship_to_key
			,stg.mark_for_key
			,stg.buyer_mark_for_node_id
			,stg.req_delivery_date
			,stg.req_cancel_date
			,stg.req_ship_date
			,stg.scac
			,stg.carrier_service_code
			,stg.carrier_account_no
			,stg.pickable_flag
			,stg.ship_together_no
			,stg.hold_flag
			,stg.kit_code
			,stg.hold_reason_code
			,stg.other_charges
			,stg.invoiced_line_total
			,stg.invoiced_extended_price
			,stg.settled_quantity
			,stg.settled_amount
			,stg.tax_exemption_certificate
			,stg.discount_type
			,stg.discount_reference
			,stg.gift_flag
			,stg.personalize_flag
			,stg.personalize_code
			,stg.department_code
			,stg.customer_item
			,stg.customer_item_description
			,stg.item_weight
			,stg.item_weight_uom
			,stg.item_description
			,stg.item_short_description
			,stg.reservation_id
			,stg.reservation_pool
			,stg.customer_po_no
			,stg.customer_po_line_no
			,stg.tax
			,stg.delivery_code
			,stg.original_ordered_qty
			,stg.list_price
			,stg.retail_price
			,stg.discount_percentage
			,stg.packlist_type
			,stg.supplier_item
			,stg.supplier_item_description
			,stg.unit_cost
			,stg.upc_code
			,stg.fob
			,stg.manufacturer_name
			,stg.manufacturer_item
			,stg.manufacturer_item_desc
			,stg.country_of_origin
			,stg.isbn
			,stg.harmonized_code
			,stg.ship_to_id
			,stg.product_line
			,stg.nmfc_code
			,stg.nmfc_class
			,stg.nmfc_description
			,stg.tax_product_code
			,stg.import_license_no
			,stg.import_license_exp_date
			,stg.eccn_no
			,stg.schedule_b_code
			,stg.supplier_code
			,stg.purpose
			,stg.receiving_node
			,stg.buyer_receiving_node_id
			,stg.shipment_consol_group_id
			,stg.orig_order_line_key
			,stg.line_seq_no
			,stg.split_qty
			,stg.pricing_date
			,stg.pipeline_key
			,stg.condition_variable_1
			,stg.condition_variable_2
			,stg.is_price_locked
			,stg.is_cost_overridden
			,stg.is_capacity_overridden
			,stg.invoice_complete
			,stg.delivery_method
			,stg.item_group_code
			,stg.cannot_complete_before_date
			,stg.cannot_complete_after_date
			,stg.appt_status
			,stg.can_add_service_lines
			,stg.pricing_uom
			,stg.capacity_uom
			,stg.pricing_quantity
			,stg.shipped_quantity
			,stg.fixed_capacity_qty_per_line
			,stg.fixed_pricing_qty_per_line
			,stg.wait_for_seq_line
			,stg.sched_failure_reason_code
			,stg.earliest_ship_date
			,stg.earliest_delivery_date
			,stg.cannot_meet_appt
			,stg.promised_appt_start_date
			,stg.promised_appt_end_date
			,stg.segment
			,stg.segment_type
			,stg.earliest_schedule_date
			,stg.timezone
			,stg.is_forwarding_allowed
			,stg.is_procurement_allowed
			,stg.reship_parent_line_key
			,stg.bundle_parent_order_line_key
			,stg.is_price_info_only
			,stg.level_of_service
			,stg.first_iter_seq_no
			,stg.last_iter_seq_no
			,stg.createts
			,stg.modifyts
			,stg.createuserid
			,stg.modifyuserid
			,stg.createprogid
			,stg.modifyprogid
			,stg.lockid
			,stg.ordering_uom
			,stg.pricing_quantity_conv_factor
			,stg.pricing_quantity_strategy
			,stg.invoiced_pricing_quantity
			,stg.is_standalone_service
			,stg.tran_discrepancy_qty
			,stg.received_quantity
			,stg.invoice_based_on_actuals
			,stg.actual_pricing_quantity
			,stg.fulfillment_type
			,stg.serial_no
			,stg.reservation_mandatory
			,stg.is_firm_predefined_node
			,stg.intentional_backorder
			,stg.future_avail_date
			,stg.repricing_quantity
			,stg.min_ship_by_date
			,stg.kit_qty
			,stg.bom_config_key
			,stg.bundle_fulfillment_mode
			,stg.is_gift_wrap
			,stg.group_sequence_num
			,stg.in_store_payment_required
			,stg.item_not_exist
			,stg.derived_from_ext_ord
			,stg.is_eligible_for_ship_disc
			,stg.backorder_notification_qty
			,stg.is_price_matched
			,stg.is_pick_up_now
			,stg.item_is_in_hand
			,stg.disposition_code
			,stg.extn_mod_reason_code
			,stg.extn_mod_reason_desc
			,stg.extn_asn
			,stg.extn_parent_order_no
			,stg.extn_item_id
			,stg.extn_order_item_id
			,stg.extn_price_type
		    ,stg.extn_secondary_return_reason
			,stg.extn_apply_label_fee
			,stg.extn_is_activation_complete
			,stg.extn_item_desc
			,stg.extn_return_carton_count
			,stg.extn_asn_quantity
			,stg.extn_light_color
			,stg.extn_light_type
			,stg.extn_number_of_sections
			,stg.extn_total_cartons
			,stg.extn_tree_height
			,stg.extn_tree_height_uom
			,stg.extn_apply_restocking_fee
			,stg.extn_return_pickup_date
			,stg.extn_pickup_confirmation_no
			,stg.extn_refund_shipping_cost
			,stg.extn_is_fulfilled_line
			,stg.extn_mfg_warranty_start_date
			,stg.extn_mfg_warranty_end_date
			,stg.extn_term
			,stg.extn_is_invoice_required
			,stg.extn_prem_guarantee_end_date
			,stg.extn_return_date
			,stg.extn_is_email_sent
			,stg.extn_return_required
			,stg.extn_parent_prime_line_no
			,stg.extn_parent_sub_line_no
			,stg.extn_prem_guarantee_start_date
			,stg.extn_reship_upcid
			,stg.extn_parent_order_line_sku 
			,stg.unit_price
			,stg.line_total
			,CURRENT_TIMESTAMP()
			from transformed.stg_order_line stg	
			inner join raw.raw_order_line r
				on stg.order_header_key = r.order_header_key AND
					stg.order_line_key = r.order_line_key AND
					r.modifyts = stg.modifyts and
					r.processing_status = ''Processed''
		 ) sod
		 ON (
			eod.order_header_key = sod.order_header_key AND
			eod.order_line_key = sod.order_line_key
		 )
		 WHEN MATCHED THEN
		UPDATE
		SET 
			eod.order_line_key=sod.order_line_key
			,eod.order_header_key=sod.order_header_key
			,eod.prime_line_no=sod.prime_line_no
			,eod.sub_line_no=sod.sub_line_no
			,eod.line_type=sod.line_type
			,eod.order_class=sod.order_class
			,eod.alternate_item_id=sod.alternate_item_id
			,eod.uom=sod.uom
			,eod.product_class=sod.product_class
			,eod.cost_currency=sod.cost_currency
			,eod.basic_capacity_required=sod.basic_capacity_required
			,eod.option_capacity_required=sod.option_capacity_required
			,eod.dependent_on_line_key=sod.dependent_on_line_key
			,eod.current_work_order_key=sod.current_work_order_key
			,eod.dependency_shipping_rule=sod.dependency_shipping_rule
			,eod.fill_quantity=sod.fill_quantity
			,eod.committed_quantity=sod.committed_quantity
			,eod.dependency_ratio=sod.dependency_ratio
			,eod.maintain_ratio=sod.maintain_ratio
			,eod.merge_node=sod.merge_node
			,eod.parent_of_dependent_group=sod.parent_of_dependent_group
			,eod.source_from_organization=sod.source_from_organization
			,eod.chained_from_order_line_key=sod.chained_from_order_line_key
			,eod.chained_from_order_header_key=sod.chained_from_order_header_key
			,eod.derived_from_order_line_key=sod.derived_from_order_line_key
			,eod.derived_from_order_header_key=sod.derived_from_order_header_key
			,eod.derived_from_order_release_key=sod.derived_from_order_release_key
			,eod.distribution_rule_id=sod.distribution_rule_id
			,eod.invoiced_quantity=sod.invoiced_quantity
			,eod.over_receipt_quantity=sod.over_receipt_quantity
			,eod.return_reason=sod.return_reason
			,eod.shipnode_key=sod.shipnode_key
			,eod.procure_from_node=sod.procure_from_node
			,eod.ship_to_key=sod.ship_to_key
			,eod.mark_for_key=sod.mark_for_key
			,eod.buyer_mark_for_node_id=sod.buyer_mark_for_node_id
			,eod.req_delivery_date= TRY_TO_TIMESTAMP(sod.req_delivery_date,''YYYYMMDDHHMISS'')
			,eod.req_cancel_date=TRY_TO_TIMESTAMP(sod.req_cancel_date,''YYYYMMDDHHMISS'')
			,eod.req_ship_date=TRY_TO_TIMESTAMP(sod.req_ship_date,''YYYYMMDDHHMISS'')
			,eod.scac=sod.scac
			,eod.carrier_service_code=sod.carrier_service_code
			,eod.carrier_account_no=sod.carrier_account_no
			,eod.pickable_flag=sod.pickable_flag
			,eod.ship_together_no=sod.ship_together_no
			,eod.hold_flag=sod.hold_flag
			,eod.kit_code=sod.kit_code
			,eod.hold_reason_code=sod.hold_reason_code
			,eod.other_charges=sod.other_charges
			,eod.invoiced_line_total= try_cast( sod.invoiced_line_total as float)  
			,eod.invoiced_extended_price= try_cast( sod.invoiced_extended_price as float)  
			,eod.settled_quantity=sod.settled_quantity
			,eod.settled_amount=sod.settled_amount
			,eod.tax_exemption_certificate=sod.tax_exemption_certificate
			,eod.discount_type=sod.discount_type
			,eod.discount_reference=sod.discount_reference
			,eod.gift_flag=sod.gift_flag
			,eod.personalize_flag=sod.personalize_flag
			,eod.personalize_code=sod.personalize_code
			,eod.department_code=sod.department_code
			,eod.customer_item=sod.customer_item
			,eod.customer_item_description=sod.customer_item_description
			,eod.item_weight=sod.item_weight
			,eod.item_weight_uom=sod.item_weight_uom
			,eod.item_description=sod.item_description
			,eod.item_short_description=sod.item_short_description
			,eod.reservation_id=sod.reservation_id
			,eod.reservation_pool=sod.reservation_pool
			,eod.customer_po_no=sod.customer_po_no
			,eod.customer_po_line_no=sod.customer_po_line_no
			,eod.tax=sod.tax
			,eod.delivery_code=sod.delivery_code
			,eod.original_ordered_qty=sod.original_ordered_qty
			,eod.list_price= try_cast(sod.list_price as float)  
			,eod.retail_price= try_cast(sod.retail_price as float)  
			,eod.discount_percentage=sod.discount_percentage
			,eod.packlist_type=sod.packlist_type
			,eod.supplier_item=sod.supplier_item
			,eod.supplier_item_description=sod.supplier_item_description
			,eod.unit_cost=sod.unit_cost
			,eod.upc_code=sod.upc_code
			,eod.fob=sod.fob
			,eod.manufacturer_name=sod.manufacturer_name
			,eod.manufacturer_item=sod.manufacturer_item
			,eod.manufacturer_item_desc=sod.manufacturer_item_desc
			,eod.country_of_origin=sod.country_of_origin
			,eod.isbn=sod.isbn
			,eod.harmonized_code=sod.harmonized_code
			,eod.ship_to_id=sod.ship_to_id
			,eod.product_line=sod.product_line
			,eod.nmfc_code=sod.nmfc_code
			,eod.nmfc_class=sod.nmfc_class
			,eod.nmfc_description=sod.nmfc_description
			,eod.tax_product_code=sod.tax_product_code
			,eod.import_license_no=sod.import_license_no
			,eod.import_license_exp_date=TRY_TO_TIMESTAMP(sod.import_license_exp_date,''YYYYMMDDHHMISS'')
			,eod.eccn_no=sod.eccn_no
			,eod.schedule_b_code=sod.schedule_b_code
			,eod.supplier_code=sod.supplier_code
			,eod.purpose=sod.purpose
			,eod.receiving_node=sod.receiving_node
			,eod.buyer_receiving_node_id=sod.buyer_receiving_node_id
			,eod.shipment_consol_group_id=sod.shipment_consol_group_id
			,eod.orig_order_line_key=sod.orig_order_line_key
			,eod.line_seq_no=sod.line_seq_no
			,eod.split_qty=sod.split_qty
			,eod.pricing_date=TRY_TO_TIMESTAMP(sod.pricing_date,''YYYYMMDDHHMISS'')
			,eod.pipeline_key=sod.pipeline_key
			,eod.condition_variable_1=sod.condition_variable_1
			,eod.condition_variable_2=sod.condition_variable_2
			,eod.is_price_locked=sod.is_price_locked
			,eod.is_cost_overridden=sod.is_cost_overridden
			,eod.is_capacity_overridden=sod.is_capacity_overridden
			,eod.invoice_complete=sod.invoice_complete
			,eod.delivery_method=sod.delivery_method
			,eod.item_group_code=sod.item_group_code
			,eod.cannot_complete_before_date=TRY_TO_TIMESTAMP(sod.cannot_complete_before_date,''YYYYMMDDHHMISS'')
			,eod.cannot_complete_after_date=TRY_TO_TIMESTAMP(sod.cannot_complete_after_date,''YYYYMMDDHHMISS'')
			,eod.appt_status=sod.appt_status
			,eod.can_add_service_lines=sod.can_add_service_lines
			,eod.pricing_uom=sod.pricing_uom
			,eod.capacity_uom=sod.capacity_uom
			,eod.pricing_quantity=sod.pricing_quantity
			,eod.shipped_quantity=sod.shipped_quantity
			,eod.fixed_capacity_qty_per_line=sod.fixed_capacity_qty_per_line
			,eod.fixed_pricing_qty_per_line=sod.fixed_pricing_qty_per_line
			,eod.wait_for_seq_line=sod.wait_for_seq_line
			,eod.sched_failure_reason_code=sod.sched_failure_reason_code
			,eod.earliest_ship_date=TRY_TO_TIMESTAMP(sod.earliest_ship_date,''YYYYMMDDHHMISS'')
			,eod.earliest_delivery_date=TRY_TO_TIMESTAMP(sod.earliest_delivery_date,''YYYYMMDDHHMISS'')
			,eod.cannot_meet_appt=sod.cannot_meet_appt
			,eod.promised_appt_start_date=TRY_TO_TIMESTAMP(sod.promised_appt_start_date,''YYYYMMDDHHMISS'')
			,eod.promised_appt_end_date=TRY_TO_TIMESTAMP(sod.promised_appt_end_date,''YYYYMMDDHHMISS'')
			,eod.segment=sod.segment
			,eod.segment_type=sod.segment_type
			,eod.earliest_schedule_date=TRY_TO_TIMESTAMP(sod.earliest_schedule_date,''YYYYMMDDHHMISS'')
			,eod.timezone=sod.timezone
			,eod.is_forwarding_allowed=sod.is_forwarding_allowed
			,eod.is_procurement_allowed=sod.is_procurement_allowed
			,eod.reship_parent_line_key=sod.reship_parent_line_key
			,eod.bundle_parent_order_line_key=sod.bundle_parent_order_line_key
			,eod.is_price_info_only=sod.is_price_info_only
			,eod.level_of_service=sod.level_of_service
			,eod.first_iter_seq_no=sod.first_iter_seq_no
			,eod.last_iter_seq_no=sod.last_iter_seq_no
			,eod.createts=TRY_TO_TIMESTAMP(sod.createts,''YYYYMMDDHHMISS'')
			,eod.modifyts=TRY_TO_TIMESTAMP(sod.modifyts,''YYYYMMDDHHMISS'')
			,eod.createuserid=sod.createuserid
			,eod.modifyuserid=sod.modifyuserid
			,eod.createprogid=sod.createprogid
			,eod.modifyprogid=sod.modifyprogid
			,eod.lockid=sod.lockid
			,eod.ordering_uom=sod.ordering_uom
			,eod.pricing_quantity_conv_factor=sod.pricing_quantity_conv_factor
			,eod.pricing_quantity_strategy=sod.pricing_quantity_strategy
			,eod.invoiced_pricing_quantity=sod.invoiced_pricing_quantity
			,eod.is_standalone_service=sod.is_standalone_service
			,eod.tran_discrepancy_qty=sod.tran_discrepancy_qty
			,eod.received_quantity=sod.received_quantity
			,eod.invoice_based_on_actuals=sod.invoice_based_on_actuals
			,eod.actual_pricing_quantity=sod.actual_pricing_quantity
			,eod.fulfillment_type=sod.fulfillment_type
			,eod.serial_no=sod.serial_no
			,eod.reservation_mandatory=sod.reservation_mandatory
			,eod.is_firm_predefined_node=sod.is_firm_predefined_node
			,eod.intentional_backorder=sod.intentional_backorder
			,eod.future_avail_date=TRY_TO_TIMESTAMP(sod.future_avail_date,''YYYYMMDDHHMISS'')
			,eod.repricing_quantity=sod.repricing_quantity
			,eod.min_ship_by_date=TRY_TO_TIMESTAMP(sod.min_ship_by_date,''YYYYMMDDHHMISS'')
			,eod.kit_qty=sod.kit_qty
			,eod.bom_config_key=sod.bom_config_key
			,eod.bundle_fulfillment_mode=sod.bundle_fulfillment_mode
			,eod.is_gift_wrap=sod.is_gift_wrap
			,eod.group_sequence_num=sod.group_sequence_num
			,eod.in_store_payment_required=sod.in_store_payment_required
			,eod.item_not_exist=sod.item_not_exist
			,eod.derived_from_ext_ord=sod.derived_from_ext_ord
			,eod.is_eligible_for_ship_disc=sod.is_eligible_for_ship_disc
			,eod.backorder_notification_qty=sod.backorder_notification_qty
			,eod.is_price_matched=sod.is_price_matched
			,eod.is_pick_up_now=sod.is_pick_up_now
			,eod.item_is_in_hand=sod.item_is_in_hand
			,eod.disposition_code=sod.disposition_code
			,eod.extn_mod_reason_code=sod.extn_mod_reason_code
			,eod.extn_mod_reason_desc=sod.extn_mod_reason_desc
			,eod.extn_asn=sod.extn_asn
			,eod.extn_parent_order_no=sod.extn_parent_order_no
			,eod.extn_item_id=sod.extn_item_id
			,eod.extn_order_item_id=sod.extn_order_item_id
			,eod.extn_price_type=sod.extn_price_type
			,eod.extn_secondary_return_reason=sod.extn_secondary_return_reason
			,eod.extn_apply_label_fee=sod.extn_apply_label_fee
			,eod.extn_is_activation_complete=sod.extn_is_activation_complete
			,eod.extn_item_desc=sod.extn_item_desc
			,eod.extn_return_carton_count=sod.extn_return_carton_count
			,eod.extn_asn_quantity=sod.extn_asn_quantity
			,eod.extn_light_color=sod.extn_light_color
			,eod.extn_light_type=sod.extn_light_type
			,eod.extn_number_of_sections=sod.extn_number_of_sections
			,eod.extn_total_cartons=sod.extn_total_cartons
			,eod.extn_tree_height=sod.extn_tree_height
			,eod.extn_tree_height_uom=sod.extn_tree_height_uom
			,eod.extn_apply_restocking_fee=sod.extn_apply_restocking_fee
			,eod.extn_return_pickup_date=TRY_TO_TIMESTAMP(sod.extn_return_pickup_date,''YYYYMMDDHHMISS'')
			,eod.extn_pickup_confirmation_no=sod.extn_pickup_confirmation_no
			,eod.extn_refund_shipping_cost=sod.extn_refund_shipping_cost
			,eod.extn_is_fulfilled_line=sod.extn_is_fulfilled_line
			,eod.extn_mfg_warranty_start_date=TRY_TO_TIMESTAMP(sod.extn_mfg_warranty_start_date,''YYYYMMDDHHMISS'')
			,eod.extn_mfg_warranty_end_date=TRY_TO_TIMESTAMP(sod.extn_mfg_warranty_end_date,''YYYYMMDDHHMISS'')
			,eod.extn_term=sod.extn_term
			,eod.extn_is_invoice_required=sod.extn_is_invoice_required
			,eod.extn_prem_guarantee_end_date=TRY_TO_TIMESTAMP(sod.extn_prem_guarantee_end_date,''YYYYMMDDHHMISS'')
			,eod.extn_return_date=TRY_TO_TIMESTAMP(sod.extn_return_date,''YYYYMMDDHHMISS'')
			,eod.extn_is_email_sent=sod.extn_is_email_sent
			,eod.extn_return_required=sod.extn_return_required
			,eod.extn_parent_prime_line_no=sod.extn_parent_prime_line_no
			,eod.extn_parent_sub_line_no=sod.extn_parent_sub_line_no
			,eod.extn_prem_guarantee_start_date=TRY_TO_TIMESTAMP(sod.extn_prem_guarantee_start_date,''YYYYMMDDHHMISS'')
			,eod.extn_reship_upcid=sod.extn_reship_upcid
            ,eod.extn_parent_order_line_sku=sod.extn_parent_order_line_sku
			,eod.unit_price=sod.unit_price
            ,eod.line_total=sod.line_total
			,eod.INSERTED_DATE= current_timestamp()

		WHEN NOT MATCHED 
		THEN
			INSERT              
			(
				order_line_key
				,order_header_key
				,prime_line_no
				,sub_line_no
				,line_type
				,order_class
				,alternate_item_id
				,uom
				,product_class
				,cost_currency
				,basic_capacity_required
				,option_capacity_required
				,dependent_on_line_key
				,current_work_order_key
				,dependency_shipping_rule
				,fill_quantity
				,committed_quantity
				,dependency_ratio
				,maintain_ratio
				,merge_node
				,parent_of_dependent_group
				,source_from_organization
				,chained_from_order_line_key
				,chained_from_order_header_key
				,derived_from_order_line_key
				,derived_from_order_header_key
				,derived_from_order_release_key
				,distribution_rule_id
				,invoiced_quantity
				,over_receipt_quantity
				,return_reason
				,shipnode_key
				,procure_from_node
				,ship_to_key
				,mark_for_key
				,buyer_mark_for_node_id
				,req_delivery_date
				,req_cancel_date
				,req_ship_date
				,scac
				,carrier_service_code
				,carrier_account_no
				,pickable_flag
				,ship_together_no
				,hold_flag
				,kit_code
				,hold_reason_code
				,other_charges
				,invoiced_line_total
				,invoiced_extended_price
				,settled_quantity
				,settled_amount
				,tax_exemption_certificate
				,discount_type
				,discount_reference
				,gift_flag
				,personalize_flag
				,personalize_code
				,department_code
				,customer_item
				,customer_item_description
				,item_weight
				,item_weight_uom
				,item_description
				,item_short_description
				,reservation_id
				,reservation_pool
				,customer_po_no
				,customer_po_line_no
				,tax
				,delivery_code
				,original_ordered_qty
				,list_price
				,retail_price
				,discount_percentage
				,packlist_type
				,supplier_item
				,supplier_item_description
				,unit_cost
				,upc_code
				,fob
				,manufacturer_name
				,manufacturer_item
				,manufacturer_item_desc
				,country_of_origin
				,isbn
				,harmonized_code
				,ship_to_id
				,product_line
				,nmfc_code
				,nmfc_class
				,nmfc_description
				,tax_product_code
				,import_license_no
				,import_license_exp_date
				,eccn_no
				,schedule_b_code
				,supplier_code
				,purpose
				,receiving_node
				,buyer_receiving_node_id
				,shipment_consol_group_id
				,orig_order_line_key
				,line_seq_no
				,split_qty
				,pricing_date
				,pipeline_key
				,condition_variable_1
				,condition_variable_2
				,is_price_locked
				,is_cost_overridden
				,is_capacity_overridden
				,invoice_complete
				,delivery_method
				,item_group_code
				,cannot_complete_before_date
				,cannot_complete_after_date
				,appt_status
				,can_add_service_lines
				,pricing_uom
				,capacity_uom
				,pricing_quantity
				,shipped_quantity
				,fixed_capacity_qty_per_line
				,fixed_pricing_qty_per_line
				,wait_for_seq_line
				,sched_failure_reason_code
				,earliest_ship_date
				,earliest_delivery_date
				,cannot_meet_appt
				,promised_appt_start_date
				,promised_appt_end_date
				,segment
				,segment_type
				,earliest_schedule_date
				,timezone
				,is_forwarding_allowed
				,is_procurement_allowed
				,reship_parent_line_key
				,bundle_parent_order_line_key
				,is_price_info_only
				,level_of_service
				,first_iter_seq_no
				,last_iter_seq_no
				,createts
				,modifyts
				,createuserid
				,modifyuserid
				,createprogid
				,modifyprogid
				,lockid
				,ordering_uom
				,pricing_quantity_conv_factor
				,pricing_quantity_strategy
				,invoiced_pricing_quantity
				,is_standalone_service
				,tran_discrepancy_qty
				,received_quantity
				,invoice_based_on_actuals
				,actual_pricing_quantity
				,fulfillment_type
				,serial_no
				,reservation_mandatory
				,is_firm_predefined_node
				,intentional_backorder
				,future_avail_date
				,repricing_quantity
				,min_ship_by_date
				,kit_qty
				,bom_config_key
				,bundle_fulfillment_mode
				,is_gift_wrap
				,group_sequence_num
				,in_store_payment_required
				,item_not_exist
				,derived_from_ext_ord
				,is_eligible_for_ship_disc
				,backorder_notification_qty
				,is_price_matched
				,is_pick_up_now
				,item_is_in_hand
				,disposition_code
				,extn_mod_reason_code
				,extn_mod_reason_desc
				,extn_asn
				,extn_parent_order_no
				,extn_item_id
				,extn_order_item_id
				,extn_price_type
				,extn_secondary_return_reason
				,extn_apply_label_fee
				,extn_is_activation_complete
				,extn_item_desc
				,extn_return_carton_count
				,extn_asn_quantity
				,extn_light_color
				,extn_light_type
				,extn_number_of_sections
				,extn_total_cartons
				,extn_tree_height
				,extn_tree_height_uom
				,extn_apply_restocking_fee
				,extn_return_pickup_date
				,extn_pickup_confirmation_no
				,extn_refund_shipping_cost
				,extn_is_fulfilled_line
				,extn_mfg_warranty_start_date
				,extn_mfg_warranty_end_date
				,extn_term
				,extn_is_invoice_required
				,extn_prem_guarantee_end_date
				,extn_return_date
				,extn_is_email_sent
				,extn_return_required
				,extn_parent_prime_line_no
				,extn_parent_sub_line_no
				,extn_prem_guarantee_start_date
				,extn_reship_upcid
				,extn_parent_order_line_sku
				,unit_price
				,line_total
				,INSERTED_DATE

				)
			VALUES
			(
				order_line_key
				,order_header_key
				,prime_line_no
				,sub_line_no
				,line_type
				,order_class
				,alternate_item_id
				,uom
				,product_class
				,cost_currency
				,basic_capacity_required
				,option_capacity_required
				,dependent_on_line_key
				,current_work_order_key
				,dependency_shipping_rule
				,fill_quantity
				,committed_quantity
				,dependency_ratio
				,maintain_ratio
				,merge_node
				,parent_of_dependent_group
				,source_from_organization
				,chained_from_order_line_key
				,chained_from_order_header_key
				,derived_from_order_line_key
				,derived_from_order_header_key
				,derived_from_order_release_key
				,distribution_rule_id
				,invoiced_quantity
				,over_receipt_quantity
				,return_reason
				,shipnode_key
				,procure_from_node
				,ship_to_key
				,mark_for_key
				,buyer_mark_for_node_id
				,TRY_TO_TIMESTAMP(req_delivery_date,''YYYYMMDDHHMISS'')
				,TRY_TO_TIMESTAMP(req_cancel_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(req_ship_date,''YYYYMMDDHHMISS'')
				,scac
				,carrier_service_code
				,carrier_account_no
				,pickable_flag
				,ship_together_no
				,hold_flag
				,kit_code
				,hold_reason_code
				,other_charges
				, try_cast(invoiced_line_total as float)
				, try_cast(invoiced_extended_price as float)
				,settled_quantity
				,settled_amount
				,tax_exemption_certificate
				,discount_type
				,discount_reference
				,gift_flag
				,personalize_flag
				,personalize_code
				,department_code
				,customer_item
				,customer_item_description
				,item_weight
				,item_weight_uom
				,item_description
				,item_short_description
				,reservation_id
				,reservation_pool
				,customer_po_no
				,customer_po_line_no
				,tax
				,delivery_code
				,original_ordered_qty
				, try_cast(list_price as float)
				, try_cast(retail_price as float)
				,discount_percentage
				,packlist_type
				,supplier_item
				,supplier_item_description
				,unit_cost
				,upc_code
				,fob
				,manufacturer_name
				,manufacturer_item
				,manufacturer_item_desc
				,country_of_origin
				,isbn
				,harmonized_code
				,ship_to_id
				,product_line
				,nmfc_code
				,nmfc_class
				,nmfc_description
				,tax_product_code
				,import_license_no
				, TRY_TO_TIMESTAMP(import_license_exp_date,''YYYYMMDDHHMISS'')
				,eccn_no
				,schedule_b_code
				,supplier_code
				,purpose
				,receiving_node
				,buyer_receiving_node_id
				,shipment_consol_group_id
				,orig_order_line_key
				,line_seq_no
				,split_qty
				, TRY_TO_TIMESTAMP(pricing_date,''YYYYMMDDHHMISS'')
				,pipeline_key
				,condition_variable_1
				,condition_variable_2
				,is_price_locked
				,is_cost_overridden
				,is_capacity_overridden
				,invoice_complete
				,delivery_method
				,item_group_code
				, TRY_TO_TIMESTAMP(cannot_complete_before_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(cannot_complete_after_date,''YYYYMMDDHHMISS'')
				,appt_status
				,can_add_service_lines
				,pricing_uom
				,capacity_uom
				,pricing_quantity
				,shipped_quantity
				,fixed_capacity_qty_per_line
				,fixed_pricing_qty_per_line
				,wait_for_seq_line
				,sched_failure_reason_code
				, TRY_TO_TIMESTAMP(earliest_ship_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(earliest_delivery_date,''YYYYMMDDHHMISS'')
				,cannot_meet_appt
				, TRY_TO_TIMESTAMP(promised_appt_start_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(promised_appt_end_date,''YYYYMMDDHHMISS'')
				,segment
				,segment_type
				, TRY_TO_TIMESTAMP(earliest_schedule_date,''YYYYMMDDHHMISS'')
				,timezone
				,is_forwarding_allowed
				,is_procurement_allowed
				,reship_parent_line_key
				,bundle_parent_order_line_key
				,is_price_info_only
				,level_of_service
				,first_iter_seq_no
				,last_iter_seq_no
				, TRY_TO_TIMESTAMP(createts,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(modifyts,''YYYYMMDDHHMISS'')
				,createuserid
				,modifyuserid
				,createprogid
				,modifyprogid
				,lockid
				,ordering_uom
				,pricing_quantity_conv_factor
				,pricing_quantity_strategy
				,invoiced_pricing_quantity
				,is_standalone_service
				,tran_discrepancy_qty
				,received_quantity
				,invoice_based_on_actuals
				,actual_pricing_quantity
				,fulfillment_type
				,serial_no
				,reservation_mandatory
				,is_firm_predefined_node
				,intentional_backorder
				, TRY_TO_TIMESTAMP(future_avail_date,''YYYYMMDDHHMISS'')
				,repricing_quantity
				, TRY_TO_TIMESTAMP(min_ship_by_date,''YYYYMMDDHHMISS'')
				,kit_qty
				,bom_config_key
				,bundle_fulfillment_mode
				,is_gift_wrap
				,group_sequence_num
				,in_store_payment_required
				,item_not_exist
				,derived_from_ext_ord
				,is_eligible_for_ship_disc
				,backorder_notification_qty
				,is_price_matched
				,is_pick_up_now
				,item_is_in_hand
				,disposition_code
				,extn_mod_reason_code
				,extn_mod_reason_desc
				,extn_asn
				,extn_parent_order_no
				,extn_item_id
				,extn_order_item_id
				,extn_price_type
				,extn_secondary_return_reason
				,extn_apply_label_fee
				,extn_is_activation_complete
				,extn_item_desc
				,extn_return_carton_count
				,extn_asn_quantity
				,extn_light_color
				,extn_light_type
				,extn_number_of_sections
				,extn_total_cartons
				,extn_tree_height
				,extn_tree_height_uom
				,extn_apply_restocking_fee
				, TRY_TO_TIMESTAMP(extn_return_pickup_date,''YYYYMMDDHHMISS'')
				,extn_pickup_confirmation_no
				,extn_refund_shipping_cost
				,extn_is_fulfilled_line
				, TRY_TO_TIMESTAMP(extn_mfg_warranty_start_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(extn_mfg_warranty_end_date,''YYYYMMDDHHMISS'')
				,extn_term
				,extn_is_invoice_required
				, TRY_TO_TIMESTAMP(extn_prem_guarantee_end_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(extn_return_date,''YYYYMMDDHHMISS'')
				,extn_is_email_sent
				,extn_return_required
				,extn_parent_prime_line_no
				,extn_parent_sub_line_no
				, TRY_TO_TIMESTAMP(extn_prem_guarantee_start_date,''YYYYMMDDHHMISS'')
				,extn_reship_upcid
				,extn_parent_order_line_sku
				,unit_price
				,line_total
				,current_timestamp()

			);
			
			
			INSERT INTO TempExtOrderDEtail(
				order_line_key
				,order_header_key
				,prime_line_no
				,sub_line_no
				,line_type
				,order_class
				,alternate_item_id
				,uom
				,product_class
				,cost_currency
				,basic_capacity_required
				,option_capacity_required
				,dependent_on_line_key
				,current_work_order_key
				,dependency_shipping_rule
				,fill_quantity
				,committed_quantity
				,dependency_ratio
				,maintain_ratio
				,merge_node
				,parent_of_dependent_group
				,source_from_organization
				,chained_from_order_line_key
				,chained_from_order_header_key
				,derived_from_order_line_key
				,derived_from_order_header_key
				,derived_from_order_release_key
				,distribution_rule_id
				,invoiced_quantity
				,over_receipt_quantity
				,return_reason
				,shipnode_key
				,procure_from_node
				,ship_to_key
				,mark_for_key
				,buyer_mark_for_node_id
				,req_delivery_date
				,req_cancel_date
				,req_ship_date
				,scac
				,carrier_service_code
				,carrier_account_no
				,pickable_flag
				,ship_together_no
				,hold_flag
				,kit_code
				,hold_reason_code
				,other_charges
				,invoiced_line_total
				,invoiced_extended_price
				,settled_quantity
				,settled_amount
				,tax_exemption_certificate
				,discount_type
				,discount_reference
				,gift_flag
				,personalize_flag
				,personalize_code
				,department_code
				,customer_item
				,customer_item_description
				,item_weight
				,item_weight_uom
				,item_description
				,item_short_description
				,reservation_id
				,reservation_pool
				,customer_po_no
				,customer_po_line_no
				,tax
				,delivery_code
				,original_ordered_qty
				,list_price
				,retail_price
				,discount_percentage
				,packlist_type
				,supplier_item
				,supplier_item_description
				,unit_cost
				,upc_code
				,fob
				,manufacturer_name
				,manufacturer_item
				,manufacturer_item_desc
				,country_of_origin
				,isbn
				,harmonized_code
				,ship_to_id
				,product_line
				,nmfc_code
				,nmfc_class
				,nmfc_description
				,tax_product_code
				,import_license_no
				,import_license_exp_date
				,eccn_no
				,schedule_b_code
				,supplier_code
				,purpose
				,receiving_node
				,buyer_receiving_node_id
				,shipment_consol_group_id
				,orig_order_line_key
				,line_seq_no
				,split_qty
				,pricing_date
				,pipeline_key
				,condition_variable_1
				,condition_variable_2
				,is_price_locked
				,is_cost_overridden
				,is_capacity_overridden
				,invoice_complete
				,delivery_method
				,item_group_code
				,cannot_complete_before_date
				,cannot_complete_after_date
				,appt_status
				,can_add_service_lines
				,pricing_uom
				,capacity_uom
				,pricing_quantity
				,shipped_quantity
				,fixed_capacity_qty_per_line
				,fixed_pricing_qty_per_line
				,wait_for_seq_line
				,sched_failure_reason_code
				,earliest_ship_date
				,earliest_delivery_date
				,cannot_meet_appt
				,promised_appt_start_date
				,promised_appt_end_date
				,segment
				,segment_type
				,earliest_schedule_date
				,timezone
				,is_forwarding_allowed
				,is_procurement_allowed
				,reship_parent_line_key
				,bundle_parent_order_line_key
				,is_price_info_only
				,level_of_service
				,first_iter_seq_no
				,last_iter_seq_no
				,createts
				,modifyts
				,createuserid
				,modifyuserid
				,createprogid
				,modifyprogid
				,lockid
				,ordering_uom
				,pricing_quantity_conv_factor
				,pricing_quantity_strategy
				,invoiced_pricing_quantity
				,is_standalone_service
				,tran_discrepancy_qty
				,received_quantity
				,invoice_based_on_actuals
				,actual_pricing_quantity
				,fulfillment_type
				,serial_no
				,reservation_mandatory
				,is_firm_predefined_node
				,intentional_backorder
				,future_avail_date
				,repricing_quantity
				,min_ship_by_date
				,kit_qty
				,bom_config_key
				,bundle_fulfillment_mode
				,is_gift_wrap
				,group_sequence_num
				,in_store_payment_required
				,item_not_exist
				,derived_from_ext_ord
				,is_eligible_for_ship_disc
				,backorder_notification_qty
				,is_price_matched
				,is_pick_up_now
				,item_is_in_hand
				,disposition_code
				,extn_mod_reason_code
				,extn_mod_reason_desc
				,extn_asn
				,extn_parent_order_no
				,extn_item_id
				,extn_order_item_id
				,extn_price_type
				,extn_secondary_return_reason
				,extn_apply_label_fee
				,extn_is_activation_complete
				,extn_item_desc
				,extn_return_carton_count
				,extn_asn_quantity
				,extn_light_color
				,extn_light_type
				,extn_number_of_sections
				,extn_total_cartons
				,extn_tree_height
				,extn_tree_height_uom
				,extn_apply_restocking_fee
				,extn_return_pickup_date
				,extn_pickup_confirmation_no
				,extn_refund_shipping_cost
				,extn_is_fulfilled_line
				,extn_mfg_warranty_start_date
				,extn_mfg_warranty_end_date
				,extn_term
				,extn_is_invoice_required
				,extn_prem_guarantee_end_date
				,extn_return_date
				,extn_is_email_sent
				,extn_return_required
				,extn_parent_prime_line_no
				,extn_parent_sub_line_no
				,extn_prem_guarantee_start_date
				,extn_reship_upcid
				,extn_parent_order_line_sku
				,unit_price
				,line_total
				,revision
			)
			SELECT 
			
			inserted.order_line_key,
			inserted.order_header_key,
			inserted.prime_line_no,
			inserted.sub_line_no,
			inserted.line_type,
			inserted.order_class,
			inserted.alternate_item_id,
			inserted.uom,
			inserted.product_class,
			inserted.cost_currency,
			inserted.basic_capacity_required,
			inserted.option_capacity_required,
			inserted.dependent_on_line_key,
			inserted.current_work_order_key,
			inserted.dependency_shipping_rule,
			inserted.fill_quantity,
			inserted.committed_quantity,
			inserted.dependency_ratio,
			inserted.maintain_ratio,
			inserted.merge_node,
			inserted.parent_of_dependent_group,
			inserted.source_from_organization,
			inserted.chained_from_order_line_key,
			inserted.chained_from_order_header_key,
			inserted.derived_from_order_line_key,
			inserted.derived_from_order_header_key,
			inserted.derived_from_order_release_key,
			inserted.distribution_rule_id,
			inserted.invoiced_quantity,
			inserted.over_receipt_quantity,
			inserted.return_reason,
			inserted.shipnode_key,
			inserted.procure_from_node,
			inserted.ship_to_key,
			inserted.mark_for_key,
			inserted.buyer_mark_for_node_id,
			inserted.req_delivery_date,
			inserted.req_cancel_date,
			inserted.req_ship_date,
			inserted.scac,
			inserted.carrier_service_code,
			inserted.carrier_account_no,
			inserted.pickable_flag,
			inserted.ship_together_no,
			inserted.hold_flag,
			inserted.kit_code,
			inserted.hold_reason_code,
			inserted.other_charges,
			inserted.invoiced_line_total,
			inserted.invoiced_extended_price,
			inserted.settled_quantity,
			inserted.settled_amount,
			inserted.tax_exemption_certificate,
			inserted.discount_type,
			inserted.discount_reference,
			inserted.gift_flag,
			inserted.personalize_flag,
			inserted.personalize_code,
			inserted.department_code,
			inserted.customer_item,
			inserted.customer_item_description,
			inserted.item_weight,
			inserted.item_weight_uom,
			inserted.item_description,
			inserted.item_short_description,
			inserted.reservation_id,
			inserted.reservation_pool,
			inserted.customer_po_no,
			inserted.customer_po_line_no,
			inserted.tax,
			inserted.delivery_code,
			inserted.original_ordered_qty,
			inserted.list_price,
			inserted.retail_price,
			inserted.discount_percentage,
			inserted.packlist_type,
			inserted.supplier_item,
			inserted.supplier_item_description,
			inserted.unit_cost,
			inserted.upc_code,
			inserted.fob,
			inserted.manufacturer_name,
			inserted.manufacturer_item,
			inserted.manufacturer_item_desc,
			inserted.country_of_origin,
			inserted.isbn,
			inserted.harmonized_code,
			inserted.ship_to_id,
			inserted.product_line,
			inserted.nmfc_code,
			inserted.nmfc_class,
			inserted.nmfc_description,
			inserted.tax_product_code,
			inserted.import_license_no,
			inserted.import_license_exp_date,
			inserted.eccn_no,
			inserted.schedule_b_code,
			inserted.supplier_code,
			inserted.purpose,
			inserted.receiving_node,
			inserted.buyer_receiving_node_id,
			inserted.shipment_consol_group_id,
			inserted.orig_order_line_key,
			inserted.line_seq_no,
			inserted.split_qty,
			inserted.pricing_date,
			inserted.pipeline_key,
			inserted.condition_variable_1,
			inserted.condition_variable_2,
			inserted.is_price_locked,
			inserted.is_cost_overridden,
			inserted.is_capacity_overridden,
			inserted.invoice_complete,
			inserted.delivery_method,
			inserted.item_group_code,
			inserted.cannot_complete_before_date,
			inserted.cannot_complete_after_date,
			inserted.appt_status,
			inserted.can_add_service_lines,
			inserted.pricing_uom,
			inserted.capacity_uom,
			inserted.pricing_quantity,
			inserted.shipped_quantity,
			inserted.fixed_capacity_qty_per_line,
			inserted.fixed_pricing_qty_per_line,
			inserted.wait_for_seq_line,
			inserted.sched_failure_reason_code,
			inserted.earliest_ship_date,
			inserted.earliest_delivery_date,
			inserted.cannot_meet_appt,
			inserted.promised_appt_start_date,
			inserted.promised_appt_end_date,
			inserted.segment,
			inserted.segment_type,
			inserted.earliest_schedule_date,
			inserted.timezone,
			inserted.is_forwarding_allowed,
			inserted.is_procurement_allowed,
			inserted.reship_parent_line_key,
			inserted.bundle_parent_order_line_key,
			inserted.is_price_info_only,
			inserted.level_of_service,
			inserted.first_iter_seq_no,
			inserted.last_iter_seq_no,
			inserted.createts,
			inserted.modifyts,
			inserted.createuserid,
			inserted.modifyuserid,
			inserted.createprogid,
			inserted.modifyprogid,
			inserted.lockid,
			inserted.ordering_uom,
			inserted.pricing_quantity_conv_factor,
			inserted.pricing_quantity_strategy,
			inserted.invoiced_pricing_quantity,
			inserted.is_standalone_service,
			inserted.tran_discrepancy_qty,
			inserted.received_quantity,
			inserted.invoice_based_on_actuals,
			inserted.actual_pricing_quantity,
			inserted.fulfillment_type,
			inserted.serial_no,
			inserted.reservation_mandatory,
			inserted.is_firm_predefined_node,
			inserted.intentional_backorder,
			inserted.future_avail_date,
			inserted.repricing_quantity,
			inserted.min_ship_by_date,
			inserted.kit_qty,
			inserted.bom_config_key,
			inserted.bundle_fulfillment_mode,
			inserted.is_gift_wrap,
			inserted.group_sequence_num,
			inserted.in_store_payment_required,
			inserted.item_not_exist,
			inserted.derived_from_ext_ord,
			inserted.is_eligible_for_ship_disc,
			inserted.backorder_notification_qty,
			inserted.is_price_matched,
			inserted.is_pick_up_now,
			inserted.item_is_in_hand,
			inserted.disposition_code,
			inserted.extn_mod_reason_code,
			inserted.extn_mod_reason_desc,
			inserted.extn_asn,
			inserted.extn_parent_order_no,
			inserted.extn_item_id,
			inserted.extn_order_item_id,
			inserted.extn_price_type,
			inserted.extn_secondary_return_reason,
			inserted.extn_apply_label_fee,
			inserted.extn_is_activation_complete,
			inserted.extn_item_desc,
			inserted.extn_return_carton_count,
			inserted.extn_asn_quantity,
			inserted.extn_light_color,
			inserted.extn_light_type,
			inserted.extn_number_of_sections,
			inserted.extn_total_cartons,
			inserted.extn_tree_height,
			inserted.extn_tree_height_uom,
			inserted.extn_apply_restocking_fee,
			inserted.extn_return_pickup_date,
			inserted.extn_pickup_confirmation_no,
			inserted.extn_refund_shipping_cost,
			inserted.extn_is_fulfilled_line,
			inserted.extn_mfg_warranty_start_date,
			inserted.extn_mfg_warranty_end_date,
			inserted.extn_term,
			inserted.extn_is_invoice_required,
			inserted.extn_prem_guarantee_end_date,
			inserted.extn_return_date,
			inserted.extn_is_email_sent,
			inserted.extn_return_required,
			inserted.extn_parent_prime_line_no,
			inserted.extn_parent_sub_line_no,
			inserted.extn_prem_guarantee_start_date,
			inserted.extn_reship_upcid,
			inserted.extn_parent_order_line_sku,
			inserted.unit_price,
			inserted.line_total,
			1
			FROM analytics.ext_order_detail inserted
			where  inserted.inserted_date >= :processedDate
			;
		
		  ALTER TABLE analytics.ext_order_detail DROP COLUMN if exists inserted_date;

				
			MERGE INTO TempExtOrderDetail ttd
				USING (
					SELECT 
						MAX(aot.revision) as revision,
						aot.order_header_key,
						aot.order_line_key
					FROM analytics.audit_ext_order_detail aot
					INNER JOIN TempExtOrderDetail ttd 
						ON ttd.order_header_key = aot.order_header_key
						AND ttd.order_line_key = aot.order_line_key
					GROUP BY 
						aot.order_header_key,
						aot.order_line_key
				) aot
				ON ttd.order_header_key = aot.order_header_key
				AND ttd.order_line_key = aot.order_line_key
				WHEN MATCHED THEN
					UPDATE SET 
						ttd.Revision = COALESCE(aot.revision, 0) + 1;

			
			--Insert audit data    

		  --Insert into audit table 

	INSERT INTO analytics.audit_ext_order_detail(
		order_line_key
				,order_header_key
				,prime_line_no
				,sub_line_no
				,line_type
				,order_class
				,alternate_item_id
				,uom
				,product_class
				,cost_currency
				,basic_capacity_required
				,option_capacity_required
				,dependent_on_line_key
				,current_work_order_key
				,dependency_shipping_rule
				,fill_quantity
				,committed_quantity
				,dependency_ratio
				,maintain_ratio
				,merge_node
				,parent_of_dependent_group
				,source_from_organization
				,chained_from_order_line_key
				,chained_from_order_header_key
				,derived_from_order_line_key
				,derived_from_order_header_key
				,derived_from_order_release_key
				,distribution_rule_id
				,invoiced_quantity
				,over_receipt_quantity
				,return_reason
				,shipnode_key
				,procure_from_node
				,ship_to_key
				,mark_for_key
				,buyer_mark_for_node_id
				,req_delivery_date
				,req_cancel_date
				,req_ship_date
				,scac
				,carrier_service_code
				,carrier_account_no
				,pickable_flag
				,ship_together_no
				,hold_flag
				,kit_code
				,hold_reason_code
				,other_charges
				,invoiced_line_total
				,invoiced_extended_price 
				,settled_quantity
				,settled_amount
				,tax_exemption_certificate
				,discount_type
				,discount_reference
				,gift_flag
				,personalize_flag
				,personalize_code
				,department_code
				,customer_item
				,customer_item_description
				,item_weight
				,item_weight_uom
				,item_description
				,item_short_description
				,reservation_id
				,reservation_pool
				,customer_po_no
				,customer_po_line_no
				,tax
				,delivery_code
				,original_ordered_qty
				,list_price
				,retail_price
				,discount_percentage
				,packlist_type
				,supplier_item
				,supplier_item_description
				,unit_cost
				,upc_code
				,fob
				,manufacturer_name
				,manufacturer_item
				,manufacturer_item_desc
				,country_of_origin
				,isbn
				,harmonized_code
				,ship_to_id
				,product_line
				,nmfc_code
				,nmfc_class
				,nmfc_description
				,tax_product_code
				,import_license_no
				,import_license_exp_date
				,eccn_no
				,schedule_b_code
				,supplier_code
				,purpose
				,receiving_node
				,buyer_receiving_node_id
				,shipment_consol_group_id
				,orig_order_line_key
				,line_seq_no
				,split_qty
				,pricing_date
				,pipeline_key
				,condition_variable_1
				,condition_variable_2
				,is_price_locked
				,is_cost_overridden
				,is_capacity_overridden
				,invoice_complete
				,delivery_method
				,item_group_code
				,cannot_complete_before_date
				,cannot_complete_after_date
				,appt_status
				,can_add_service_lines
				,pricing_uom
				,capacity_uom
				,pricing_quantity
				,shipped_quantity
				,fixed_capacity_qty_per_line
				,fixed_pricing_qty_per_line
				,wait_for_seq_line
				,sched_failure_reason_code
				,earliest_ship_date
				,earliest_delivery_date
				,cannot_meet_appt
				,promised_appt_start_date
				,promised_appt_end_date
				,segment
				,segment_type
				,earliest_schedule_date
				,timezone
				,is_forwarding_allowed
				,is_procurement_allowed
				,reship_parent_line_key
				,bundle_parent_order_line_key
				,is_price_info_only
				,level_of_service
				,first_iter_seq_no
				,last_iter_seq_no
				,createts
				,modifyts
				,createuserid
				,modifyuserid
				,createprogid
				,modifyprogid
				,lockid
				,ordering_uom
				,pricing_quantity_conv_factor
				,pricing_quantity_strategy
				,invoiced_pricing_quantity
				,is_standalone_service
				,tran_discrepancy_qty
				,received_quantity
				,invoice_based_on_actuals
				,actual_pricing_quantity
				,fulfillment_type
				,serial_no
				,reservation_mandatory
				,is_firm_predefined_node
				,intentional_backorder
				,future_avail_date
				,repricing_quantity
				,min_ship_by_date
				,kit_qty
				,bom_config_key
				,bundle_fulfillment_mode
				,is_gift_wrap
				,group_sequence_num
				,in_store_payment_required
				,item_not_exist
				,derived_from_ext_ord
				,is_eligible_for_ship_disc
				,backorder_notification_qty
				,is_price_matched
				,is_pick_up_now
				,item_is_in_hand
				,disposition_code
				,extn_mod_reason_code
				,extn_mod_reason_desc
				,extn_asn
				,extn_parent_order_no
				,extn_item_id
				,extn_order_item_id
				,extn_price_type
				,extn_secondary_return_reason
				,extn_apply_label_fee
				,extn_is_activation_complete
				,extn_item_desc
				,extn_return_carton_count
				,extn_asn_quantity
				,extn_light_color
				,extn_light_type
				,extn_number_of_sections
				,extn_total_cartons
				,extn_tree_height
				,extn_tree_height_uom
				,extn_apply_restocking_fee
				,extn_return_pickup_date
				,extn_pickup_confirmation_no
				,extn_refund_shipping_cost
				,extn_is_fulfilled_line
				,extn_mfg_warranty_start_date
				,extn_mfg_warranty_end_date
				,extn_term
				,extn_is_invoice_required
				,extn_prem_guarantee_end_date
				,extn_return_date
				,extn_is_email_sent
				,extn_return_required
				,extn_parent_prime_line_no
				,extn_parent_sub_line_no
				,extn_prem_guarantee_start_date
				,extn_reship_upcid
				,extn_parent_order_line_sku
				,unit_price
				,line_total
				,revision
			)
			SELECT
				stg.order_line_key,
				stg.order_header_key,
				stg.prime_line_no,
				stg.sub_line_no,
				stg.line_type,
				stg.order_class,
				stg.alternate_item_id,
				stg.uom,
				stg.product_class,
				stg.cost_currency,
				stg.basic_capacity_required,
				stg.option_capacity_required,
				stg.dependent_on_line_key,
				stg.current_work_order_key,
				stg.dependency_shipping_rule,
				stg.fill_quantity,
				stg.committed_quantity,
				stg.dependency_ratio,
				stg.maintain_ratio,
				stg.merge_node,
				stg.parent_of_dependent_group,
				stg.source_from_organization,
				stg.chained_from_order_line_key,
				stg.chained_from_order_header_key,
				stg.derived_from_order_line_key,
				stg.derived_from_order_header_key,
				stg.derived_from_order_release_key,
				stg.distribution_rule_id,
				stg.invoiced_quantity,
				stg.over_receipt_quantity,
				stg.return_reason,
				stg.shipnode_key,
				stg.procure_from_node,
				stg.ship_to_key,
				stg.mark_for_key,
				stg.buyer_mark_for_node_id,
				TRY_TO_TIMESTAMP(stg.req_delivery_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.req_cancel_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.req_ship_date,''YYYYMMDDHHMISS''),
				stg.scac,
				stg.carrier_service_code,
				stg.carrier_account_no,
				stg.pickable_flag,
				stg.ship_together_no,
				stg.hold_flag,
				stg.kit_code,
				stg.hold_reason_code,
				stg.other_charges,
				try_cast(stg.invoiced_line_total as float),
				try_cast(stg.invoiced_extended_price as float),
				stg.settled_quantity,
				stg.settled_amount,
				stg.tax_exemption_certificate,
				stg.discount_type,
				stg.discount_reference,
				stg.gift_flag,
				stg.personalize_flag,
				stg.personalize_code,
				stg.department_code,
				stg.customer_item,
				stg.customer_item_description,
				stg.item_weight,
				stg.item_weight_uom,
				stg.item_description,
				stg.item_short_description,
				stg.reservation_id,
				stg.reservation_pool,
				stg.customer_po_no,
				stg.customer_po_line_no,
				stg.tax,
				stg.delivery_code,
				stg.original_ordered_qty,
				try_cast(stg.list_price as float),
				try_cast(stg.retail_price as float),
				stg.discount_percentage,
				stg.packlist_type,
				stg.supplier_item,
				stg.supplier_item_description,
				stg.unit_cost,
				stg.upc_code,
				stg.fob,
				stg.manufacturer_name,
				stg.manufacturer_item,
				stg.manufacturer_item_desc,
				stg.country_of_origin,
				stg.isbn,
				stg.harmonized_code,
				stg.ship_to_id,
				stg.product_line,
				stg.nmfc_code,
				stg.nmfc_class,
				stg.nmfc_description,
				stg.tax_product_code,
				stg.import_license_no,
				TRY_TO_TIMESTAMP(stg.import_license_exp_date,''YYYYMMDDHHMISS''),
				stg.eccn_no,
				stg.schedule_b_code,
				stg.supplier_code,
				stg.purpose,
				stg.receiving_node,
				stg.buyer_receiving_node_id,
				stg.shipment_consol_group_id,
				stg.orig_order_line_key,
				stg.line_seq_no,
				stg.split_qty,
				TRY_TO_TIMESTAMP(stg.pricing_date,''YYYYMMDDHHMISS''),
				stg.pipeline_key,
				stg.condition_variable_1,
				stg.condition_variable_2,
				stg.is_price_locked,
				stg.is_cost_overridden,
				stg.is_capacity_overridden,
				stg.invoice_complete,
				stg.delivery_method,
				stg.item_group_code,
				TRY_TO_TIMESTAMP(stg.cannot_complete_before_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.cannot_complete_after_date,''YYYYMMDDHHMISS''),
				stg.appt_status,
				stg.can_add_service_lines,
				stg.pricing_uom,
				stg.capacity_uom,
				stg.pricing_quantity,
				stg.shipped_quantity,
				stg.fixed_capacity_qty_per_line,
				stg.fixed_pricing_qty_per_line,
				stg.wait_for_seq_line,
				stg.sched_failure_reason_code,
				TRY_TO_TIMESTAMP(stg.earliest_ship_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.earliest_delivery_date,''YYYYMMDDHHMISS''),
				stg.cannot_meet_appt,
				TRY_TO_TIMESTAMP(stg.promised_appt_start_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.promised_appt_end_date,''YYYYMMDDHHMISS''),
				stg.segment,
				stg.segment_type,
				TRY_TO_TIMESTAMP(stg.earliest_schedule_date,''YYYYMMDDHHMISS''),
				stg.timezone,
				stg.is_forwarding_allowed,
				stg.is_procurement_allowed,
				stg.reship_parent_line_key,
				stg.bundle_parent_order_line_key,
				stg.is_price_info_only,
				stg.level_of_service,
				stg.first_iter_seq_no,
				stg.last_iter_seq_no,
				TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
				stg.createuserid,
				stg.modifyuserid,
				stg.createprogid,
				stg.modifyprogid,
				stg.lockid,
				stg.ordering_uom,
				stg.pricing_quantity_conv_factor,
				stg.pricing_quantity_strategy,
				stg.invoiced_pricing_quantity,
				stg.is_standalone_service,
				stg.tran_discrepancy_qty,
				stg.received_quantity,
				stg.invoice_based_on_actuals,
				stg.actual_pricing_quantity,
				stg.fulfillment_type,
				stg.serial_no,
				stg.reservation_mandatory,
				stg.is_firm_predefined_node,
				stg.intentional_backorder,
				TRY_TO_TIMESTAMP(stg.future_avail_date,''YYYYMMDDHHMISS''),
				stg.repricing_quantity,
				TRY_TO_TIMESTAMP(stg.min_ship_by_date,''YYYYMMDDHHMISS''),
				stg.kit_qty,
				stg.bom_config_key,
				stg.bundle_fulfillment_mode,
				stg.is_gift_wrap,
				stg.group_sequence_num,
				stg.in_store_payment_required,
				stg.item_not_exist,
				stg.derived_from_ext_ord,
				stg.is_eligible_for_ship_disc,
				stg.backorder_notification_qty,
				stg.is_price_matched,
				stg.is_pick_up_now,
				stg.item_is_in_hand,
				stg.disposition_code,
				stg.extn_mod_reason_code,
				stg.extn_mod_reason_desc,
				stg.extn_asn,
				stg.extn_parent_order_no,
				stg.extn_item_id,
				stg.extn_order_item_id,
				stg.extn_price_type,
				stg.extn_secondary_return_reason,
				stg.extn_apply_label_fee,
				stg.extn_is_activation_complete,
				stg.extn_item_desc,
				stg.extn_return_carton_count,
				stg.extn_asn_quantity,
				stg.extn_light_color,
				stg.extn_light_type,
				stg.extn_number_of_sections,
				stg.extn_total_cartons,
				stg.extn_tree_height,
				stg.extn_tree_height_uom,
				stg.extn_apply_restocking_fee,
				TRY_TO_TIMESTAMP(stg.extn_return_pickup_date,''YYYYMMDDHHMISS''),
				stg.extn_pickup_confirmation_no,
				stg.extn_refund_shipping_cost,
				stg.extn_is_fulfilled_line,
				TRY_TO_TIMESTAMP(stg.extn_mfg_warranty_start_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.extn_mfg_warranty_end_date,''YYYYMMDDHHMISS''),
				stg.extn_term,
				stg.extn_is_invoice_required,
				TRY_TO_TIMESTAMP(stg.extn_prem_guarantee_end_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.extn_return_date,''YYYYMMDDHHMISS''),
				stg.extn_is_email_sent,
				stg.extn_return_required,
				stg.extn_parent_prime_line_no,
				stg.extn_parent_sub_line_no,
				TRY_TO_TIMESTAMP(stg.extn_prem_guarantee_start_date,''YYYYMMDDHHMISS''),
				stg.extn_reship_upcid,
				stg.extn_parent_order_line_sku,
				stg.unit_price,
				stg.line_total,
				stg.Revision
			FROM TempExtOrderDEtail stg;

		
 CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);



DROP TABLE IF EXISTS TempExtOrderDEtail;

RETURN ''Success'';
EXCEPTION 
WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
            
    RETURN sqlerrm;
END';
CREATE PROCEDURE "USP_EXT_PAYMENT_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    processedDate TIMESTAMP_NTZ(9);
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE TempExtPayment (
    ext_paymentid VARCHAR(16777216),
    order_header_key VARCHAR(16777216),
    payment_type VARCHAR(16777216),
    bill_to_key VARCHAR(16777216),
    charge_sequence VARCHAR(16777216),
    customer_account_no VARCHAR(16777216),
    display_cust_acct_no VARCHAR(16777216),
    customer_po_no VARCHAR(16777216),
    credit_card_type VARCHAR(16777216),
    credit_card_name VARCHAR(16777216),
    first_name VARCHAR(16777216),
    middle_name VARCHAR(16777216),
    last_name VARCHAR(16777216),
    credit_card_no VARCHAR(16777216),
    display_credit_card_no VARCHAR(16777216),
    credit_card_exp_date varchar,
    svc_no VARCHAR(16777216),
    display_svc_no VARCHAR(16777216),
    debit_card_no VARCHAR(16777216),
    display_debit_card_no VARCHAR(16777216),
    payment_reference1 VARCHAR(16777216),
    payment_reference2 VARCHAR(16777216),
    payment_reference3 VARCHAR(16777216),
    display_payment_ref1 VARCHAR(16777216),
    cheque_no VARCHAR(16777216),
    cheque_reference VARCHAR(16777216),
    extended_flag VARCHAR(16777216),
    pay_method_override VARCHAR(16777216),
    max_charge_limit VARCHAR(16777216),
    total_authorized float,
    total_charged float,
    requested_auth_amount float,
    requested_charge_amount float,
    requested_refund_amount float,
    total_refunded_amount float,
    total_alt_refunded_amount float,
    incomplete_payment_type VARCHAR(16777216),
    suspend_any_more_charges VARCHAR(16777216),
    suspend_exp_auth_reversal VARCHAR(16777216),
    planned_refund_amount float,
    unlimited_charges VARCHAR(16777216),
    cash_back_amount float,
    payment_reference4 VARCHAR(16777216),
    payment_reference5 VARCHAR(16777216),
    payment_reference6 VARCHAR(16777216),
    payment_reference7 VARCHAR(16777216),
    payment_reference8 VARCHAR(16777216),
    payment_reference9 VARCHAR(16777216),
    reason_code VARCHAR(16777216),
    createts TIMESTAMP,
    modifyts TIMESTAMP,
    createuserid VARCHAR(16777216),
    modifyuserid VARCHAR(16777216),
    createprogid VARCHAR(16777216),
    modifyprogid VARCHAR(16777216),
    lockid VARCHAR(16777216),
    last_updated_date TIMESTAMP,
    revision INT NOT NULL
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.EXT_PAYMENT tgt
USING (
    SELECT DISTINCT 
        stg.payment_key,
        stg.order_header_key,
        stg.payment_type,
        stg.bill_to_key,
        stg.charge_sequence,
        stg.customer_account_no,
        stg.display_cust_acct_no,
        stg.customer_po_no,
        stg.credit_card_type,
        stg.credit_card_name,
        stg.first_name,
        stg.middle_name,
        stg.last_name,
        stg.credit_card_no,
        stg.display_credit_card_no,
        stg.credit_card_exp_date,
        stg.svc_no,
        stg.display_svc_no,
        stg.debit_card_no,
        stg.display_debit_card_no,
        stg.payment_reference1,
        stg.payment_reference2,
        stg.payment_reference3,
        stg.display_payment_ref1,
        stg.cheque_no,
        stg.cheque_reference,
        stg.extended_flag,
        stg.pay_method_override,
        stg.max_charge_limit,
        TRY_CAST(stg.total_authorized AS FLOAT) as total_authorized,
        TRY_CAST(stg.total_charged AS FLOAT) as total_charged,
        TRY_CAST(stg.requested_auth_amount AS FLOAT) as requested_auth_amount,
        TRY_CAST(stg.requested_charge_amount AS FLOAT) as requested_charge_amount,
        TRY_CAST(stg.requested_refund_amount AS FLOAT) as requested_refund_amount,
        TRY_CAST(stg.total_refunded_amount AS FLOAT) as total_refunded_amount,
        TRY_CAST(stg.total_alt_refunded_amount AS FLOAT) as total_alt_refunded_amount,
        stg.incomplete_payment_type,
        stg.suspend_any_more_charges,
        stg.suspend_exp_auth_reversal,
        TRY_CAST(stg.planned_refund_amount AS FLOAT) as planned_refund_amount,
        stg.unlimited_charges,
        TRY_CAST(stg.cash_back_amount AS FLOAT) as cash_back_amount,
        stg.payment_reference4,
        stg.payment_reference5,
        stg.payment_reference6,
        stg.payment_reference7,
        stg.payment_reference8,
        stg.payment_reference9,
        stg.reason_code,
         TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'') as createts,
         TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'') as modifyts,
        stg.createuserid,
        stg.modifyuserid,
        stg.createprogid,
        stg.modifyprogid,
        stg.lockid
    FROM TRANSFORMED.STG_ORDER_PAYMENT stg
    INNER JOIN RAW.RAW_ORDER_PAYMENT r
        ON stg.payment_key = r.payment_key 
        AND stg.modifyts = r.modifyts 
        AND r.processing_status = ''Processed''
) src
ON tgt.ext_paymentid = src.payment_key
WHEN MATCHED THEN
    UPDATE SET
        tgt.ext_paymentid = src.payment_key,
        tgt.order_header_key = src.order_header_key,
        tgt.payment_type = src.payment_type,
        tgt.bill_to_key = src.bill_to_key,
        tgt.charge_sequence = src.charge_sequence,
        tgt.customer_account_no = src.customer_account_no,
        tgt.display_cust_acct_no = src.display_cust_acct_no,
        tgt.customer_po_no = src.customer_po_no,
        tgt.credit_card_type = src.credit_card_type,
        tgt.credit_card_name = src.credit_card_name,
        tgt.first_name = src.first_name,
        tgt.middle_name = src.middle_name,
        tgt.last_name = src.last_name,
        tgt.credit_card_no = src.credit_card_no,
        tgt.display_credit_card_no = src.display_credit_card_no,
        tgt.credit_card_exp_date = src.credit_card_exp_date,
        tgt.svc_no = src.svc_no,
        tgt.display_svc_no = src.display_svc_no,
        tgt.debit_card_no = src.debit_card_no,
        tgt.display_debit_card_no = src.display_debit_card_no,
        tgt.payment_reference1 = src.payment_reference1,
        tgt.payment_reference2 = src.payment_reference2,
        tgt.payment_reference3 = src.payment_reference3,
        tgt.display_payment_ref1 = src.display_payment_ref1,
        tgt.cheque_no = src.cheque_no,
        tgt.cheque_reference = src.cheque_reference,
        tgt.extended_flag = src.extended_flag,
        tgt.pay_method_override = src.pay_method_override,
        tgt.max_charge_limit = src.max_charge_limit,
        tgt.total_authorized = src.total_authorized,
        tgt.total_charged = src.total_charged,
        tgt.requested_auth_amount = src.requested_auth_amount,
        tgt.requested_charge_amount = src.requested_charge_amount,
        tgt.requested_refund_amount = src.requested_refund_amount,
        tgt.total_refunded_amount = src.total_refunded_amount,
        tgt.total_alt_refunded_amount = src.total_alt_refunded_amount,
        tgt.incomplete_payment_type = src.incomplete_payment_type,
        tgt.suspend_any_more_charges = src.suspend_any_more_charges,
        tgt.suspend_exp_auth_reversal = src.suspend_exp_auth_reversal,
        tgt.planned_refund_amount = src.planned_refund_amount,
        tgt.unlimited_charges = src.unlimited_charges,
        tgt.cash_back_amount = src.cash_back_amount,
        tgt.payment_reference4 = src.payment_reference4,
        tgt.payment_reference5 = src.payment_reference5,
        tgt.payment_reference6 = src.payment_reference6,
        tgt.payment_reference7 = src.payment_reference7,
        tgt.payment_reference8 = src.payment_reference8,
        tgt.payment_reference9 = src.payment_reference9,
        tgt.reason_code = src.reason_code,
        tgt.createts = src.createts,
        tgt.modifyts = src.modifyts,
        tgt.createuserid = src.createuserid,
        tgt.modifyuserid = src.modifyuserid,
        tgt.createprogid = src.createprogid,
        tgt.modifyprogid = src.modifyprogid,
        tgt.lockid = src.lockid,
        tgt.last_updated_date = :processedDate
WHEN NOT MATCHED THEN
    INSERT (
        ext_paymentid, order_header_key, payment_type, bill_to_key, charge_sequence, 
        customer_account_no, display_cust_acct_no, customer_po_no, credit_card_type, 
        credit_card_name, first_name, middle_name, last_name, credit_card_no, 
        display_credit_card_no, credit_card_exp_date, svc_no, display_svc_no, 
        debit_card_no, display_debit_card_no, payment_reference1, payment_reference2, 
        payment_reference3, display_payment_ref1, cheque_no, cheque_reference, 
        extended_flag, pay_method_override, max_charge_limit, total_authorized, 
        total_charged, requested_auth_amount, requested_charge_amount, 
        requested_refund_amount, total_refunded_amount, total_alt_refunded_amount, 
        incomplete_payment_type, suspend_any_more_charges, suspend_exp_auth_reversal, 
        planned_refund_amount, unlimited_charges, cash_back_amount, payment_reference4, 
        payment_reference5, payment_reference6, payment_reference7, payment_reference8, 
        payment_reference9, reason_code, createts, modifyts, createuserid, modifyuserid, 
        createprogid, modifyprogid, lockid, last_updated_date
    ) 
    VALUES (
        src.payment_key, src.order_header_key, src.payment_type, src.bill_to_key, 
        src.charge_sequence, src.customer_account_no, src.display_cust_acct_no, 
        src.customer_po_no, src.credit_card_type, src.credit_card_name, src.first_name, 
        src.middle_name, src.last_name, src.credit_card_no, src.display_credit_card_no, 
        src.credit_card_exp_date, src.svc_no, src.display_svc_no, src.debit_card_no, 
        src.display_debit_card_no, src.payment_reference1, src.payment_reference2, 
        src.payment_reference3, src.display_payment_ref1, src.cheque_no, src.cheque_reference, 
        src.extended_flag, src.pay_method_override, src.max_charge_limit, src.total_authorized, 
        src.total_charged, src.requested_auth_amount, src.requested_charge_amount, 
        src.requested_refund_amount, src.total_refunded_amount, src.total_alt_refunded_amount, 
        src.incomplete_payment_type, src.suspend_any_more_charges, 
        src.suspend_exp_auth_reversal, src.planned_refund_amount, src.unlimited_charges, 
        src.cash_back_amount, src.payment_reference4, src.payment_reference5, 
        src.payment_reference6, src.payment_reference7, src.payment_reference8, 
        src.payment_reference9, src.reason_code, src.createts, src.modifyts, src.createuserid, 
        src.modifyuserid, src.createprogid, src.modifyprogid, src.lockid, :processedDate
    );

INSERT INTO  TempExtPayment(
    ext_paymentid,
    order_header_key,
    payment_type,
    bill_to_key,
    charge_sequence,
    customer_account_no,
    display_cust_acct_no,
    customer_po_no,
    credit_card_type,
    credit_card_name,
    first_name,
    middle_name,
    last_name,
    credit_card_no,
    display_credit_card_no,
    credit_card_exp_date,
    svc_no,
    display_svc_no,
    debit_card_no,
    display_debit_card_no,
    payment_reference1,
    payment_reference2,
    payment_reference3,
    display_payment_ref1,
    cheque_no,
    cheque_reference,
    extended_flag,
    pay_method_override,
    max_charge_limit,
    total_authorized,
    total_charged,
    requested_auth_amount,
    requested_charge_amount,
    requested_refund_amount,
    total_refunded_amount,
    total_alt_refunded_amount,
    incomplete_payment_type,
    suspend_any_more_charges,
    suspend_exp_auth_reversal,
    planned_refund_amount,
    unlimited_charges,
    cash_back_amount,
    payment_reference4,
    payment_reference5,
    payment_reference6,
    payment_reference7,
    payment_reference8,
    payment_reference9,
    reason_code,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    last_updated_date,
    revision
)
SELECT 
    stg.payment_key AS ext_paymentid,
    stg.order_header_key,
    stg.payment_type,
    stg.bill_to_key,
    stg.charge_sequence,
    stg.customer_account_no,
    stg.display_cust_acct_no,
    stg.customer_po_no,
    stg.credit_card_type,
    stg.credit_card_name,
    stg.first_name,
    stg.middle_name,
    stg.last_name,
    stg.credit_card_no,
    stg.display_credit_card_no,
    stg.credit_card_exp_date,
    stg.svc_no,
    stg.display_svc_no,
    stg.debit_card_no,
    stg.display_debit_card_no,
    stg.payment_reference1,
    stg.payment_reference2,
    stg.payment_reference3,
    stg.display_payment_ref1,
    stg.cheque_no,
    stg.cheque_reference,
    stg.extended_flag,
    stg.pay_method_override,
    stg.max_charge_limit,
    TRY_CAST(stg.total_authorized AS FLOAT) as total_authorized,
    TRY_CAST(stg.total_charged AS FLOAT) as total_charged,
    TRY_CAST(stg.requested_auth_amount AS FLOAT) as requested_auth_amount,
    TRY_CAST(stg.requested_charge_amount AS FLOAT) as requested_charge_amount,
    TRY_CAST(stg.requested_refund_amount AS FLOAT) as requested_refund_amount,
    TRY_CAST(stg.total_refunded_amount AS FLOAT) as total_refunded_amount,
    TRY_CAST(stg.total_alt_refunded_amount AS FLOAT) as total_alt_refunded_amount,
    stg.incomplete_payment_type,
    stg.suspend_any_more_charges,
    stg.suspend_exp_auth_reversal,
    TRY_CAST(stg.planned_refund_amount AS FLOAT) as planned_refund_amount, 
    stg.unlimited_charges,
    TRY_CAST(stg.cash_back_amount AS FLOAT) as cash_back_amount,
    stg.payment_reference4,
    stg.payment_reference5,
    stg.payment_reference6,
    stg.payment_reference7,
    stg.payment_reference8,
    stg.payment_reference9,
    stg.reason_code,
    TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    :processedDate,
    1 AS revision
FROM 
    TRANSFORMED.STG_ORDER_PAYMENT stg
    INNER JOIN RAW.RAW_ORDER_PAYMENT r 
        ON stg.payment_key = r.payment_key
        AND stg.modifyts = r.modifyts
WHERE
    r.processing_status = ''Processed'';

CREATE OR REPLACE TEMPORARY TABLE TempExtPaymentRevision AS
SELECT
    MAX(aot.revision) AS revision,
    aot.ext_paymentid
FROM
    ANALYTICS.AUDIT_EXT_PAYMENT aot
INNER JOIN TempExtPayment ttd
    ON ttd.ext_paymentid = aot.ext_paymentid
GROUP BY
    aot.ext_paymentid;
   
UPDATE TempExtPayment ttd
SET ttd.Revision = COALESCE(aot.revision, 0) + 1
FROM TempExtPaymentRevision aot
WHERE ttd.ext_paymentid = aot.ext_paymentid;

INSERT INTO ANALYTICS.audit_ext_payment
(
    ext_paymentid,
    order_header_key,
    payment_type,
    bill_to_key,
    charge_sequence,
    customer_account_no,
    display_cust_acct_no,
    customer_po_no,
    credit_card_type,
    credit_card_name,
    first_name,
    middle_name,
    last_name,
    credit_card_no,
    display_credit_card_no,
    credit_card_exp_date,
    svc_no,
    display_svc_no,
    debit_card_no,
    display_debit_card_no,
    payment_reference1,
    payment_reference2,
    payment_reference3,
    display_payment_ref1,
    cheque_no,
    cheque_reference,
    extended_flag,
    pay_method_override,
    max_charge_limit,
    total_authorized,
    total_charged,
    requested_auth_amount,
    requested_charge_amount,
    requested_refund_amount,
    total_refunded_amount,
    total_alt_refunded_amount,
    incomplete_payment_type,
    suspend_any_more_charges,
    suspend_exp_auth_reversal,
    planned_refund_amount,
    unlimited_charges,
    cash_back_amount,
    payment_reference4,
    payment_reference5,
    payment_reference6,
    payment_reference7,
    payment_reference8,
    payment_reference9,
    reason_code,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    last_updated_date,
    revision
)
SELECT
    stg.payment_key,
    stg.order_header_key,
    stg.payment_type,
    stg.bill_to_key,
    stg.charge_sequence,
    stg.customer_account_no,
    stg.display_cust_acct_no,
    stg.customer_po_no,
    stg.credit_card_type,
    stg.credit_card_name,
    stg.first_name,
    stg.middle_name,
    stg.last_name,
    stg.credit_card_no,
    stg.display_credit_card_no,
    stg.credit_card_exp_date,
    stg.svc_no,
    stg.display_svc_no,
    stg.debit_card_no,
    stg.display_debit_card_no,
    stg.payment_reference1,
    stg.payment_reference2,
    stg.payment_reference3,
    stg.display_payment_ref1,
    stg.cheque_no,
    stg.cheque_reference,
    stg.extended_flag,
    stg.pay_method_override,
    stg.max_charge_limit,
    TRY_CAST(stg.total_authorized AS FLOAT) as total_authorized,
    TRY_CAST(stg.total_charged AS FLOAT) as total_charged,
    TRY_CAST(stg.requested_auth_amount AS FLOAT) as requested_auth_amount,
    TRY_CAST(stg.requested_charge_amount AS FLOAT) as requested_charge_amount,
    TRY_CAST(stg.requested_refund_amount AS FLOAT) as requested_refund_amount,
    TRY_CAST(stg.total_refunded_amount AS FLOAT) as total_refunded_amount,
    TRY_CAST(stg.total_alt_refunded_amount AS FLOAT) as total_alt_refunded_amount,
    stg.incomplete_payment_type,
    stg.suspend_any_more_charges,
    stg.suspend_exp_auth_reversal,
    TRY_CAST(stg.planned_refund_amount AS FLOAT) as planned_refund_amount, 
    stg.unlimited_charges,
    TRY_CAST(stg.cash_back_amount AS FLOAT) as cash_back_amount,
    stg.payment_reference4,
    stg.payment_reference5,
    stg.payment_reference6,
    stg.payment_reference7,
    stg.payment_reference8,
    stg.payment_reference9,
    stg.reason_code,
    TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    :processedDate, -- Replaces GETDATE() in SQL Server
    ord.revision
FROM
    TRANSFORMED.STG_ORDER_PAYMENT stg
INNER JOIN
    RAW.RAW_ORDER_PAYMENT r
    ON stg.payment_key = r.payment_key
    AND stg.modifyts = r.modifyts
    AND processing_status = ''Processed''
INNER JOIN
    TempExtPayment ord 
    ON ord.ext_paymentid = stg.payment_key;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

        error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';

CREATE PROCEDURE "USP_GTIN_DATA_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE log_files_import_status
SET processed = :processedRecordCount,
    raw_table = ''raw_order_gtin_data''
WHERE file_name = ''EXTN_GTIN_DATA'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE insertedGtinRecords
(
    GTIN_KEY STRING, 
    txn_id STRING,
    revision INT
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO   ANALYTICS.txn_gtin_data ts
USING (
    SELECT DISTINCT 
        GTIN_KEY,
        RESERVATION_REFERENCE,
        SKU_ITEM_ID,
        SHIP_NODE,
        UPC_ITEM_ID,
        TRY_TO_NUMBER(QUANTITY) AS QUANTITY,
        SCHEDULED_ORDER_LINE_KEY,
        ORDER_NO,
        ORDERLINE_RELEASE_KEY,
        PRIME_LINE_NO,
        SUB_LINE_NO,
        UNIT_OF_MEASURE,
        PRODUCT_CLASS,
        SEGMENT_TYPE,
        TRY_TO_TIMESTAMP(LEFT(RESERVATION_EXPIRY_TIME,14),''YYYYMMDDHHMISS'') AS RESERVATION_EXPIRY_TIME,
        INTERNAL_STATUS,
        TRY_TO_TIMESTAMP(CREATETS,''YYYYMMDDHHMISS'') AS CREATETS,
        TRY_TO_TIMESTAMP(MODIFYTS,''YYYYMMDDHHMISS'') AS MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID,
        txn_id
    FROM TRANSFORMED.stg_order_gtin_data
) ss
ON ts.GTIN_KEY = ss.GTIN_KEY
WHEN MATCHED THEN
    UPDATE SET
        ts.GTIN_KEY = ss.GTIN_KEY,
        ts.RESERVATION_REFERENCE = ss.RESERVATION_REFERENCE,
        ts.SKU_ITEM_ID = ss.SKU_ITEM_ID,
        ts.SHIP_NODE = ss.SHIP_NODE,
        ts.UPC_ITEM_ID = ss.UPC_ITEM_ID,
        ts.QUANTITY = ss.QUANTITY,
        ts.SCHEDULED_ORDER_LINE_KEY = ss.SCHEDULED_ORDER_LINE_KEY,
        ts.ORDER_NO = ss.ORDER_NO,
        ts.ORDERLINE_RELEASE_KEY = ss.ORDERLINE_RELEASE_KEY,
        ts.PRIME_LINE_NO = ss.PRIME_LINE_NO,
        ts.SUB_LINE_NO = ss.SUB_LINE_NO,
        ts.UNIT_OF_MEASURE = ss.UNIT_OF_MEASURE,
        ts.PRODUCT_CLASS = ss.PRODUCT_CLASS,
        ts.SEGMENT_TYPE = ss.SEGMENT_TYPE,
        ts.RESERVATION_EXPIRY_TIME = ss.RESERVATION_EXPIRY_TIME,
        ts.INTERNAL_STATUS = ss.INTERNAL_STATUS,
        ts.CREATETS = ss.CREATETS,
        ts.MODIFYTS = ss.MODIFYTS,
        ts.CREATEUSERID = ss.CREATEUSERID,
        ts.MODIFYUSERID = ss.MODIFYUSERID,
        ts.CREATEPROGID = ss.CREATEPROGID,
        ts.MODIFYPROGID = ss.MODIFYPROGID,
        ts.LOCKID = ss.LOCKID,
        ts.modified_date = CURRENT_TIMESTAMP
WHEN NOT MATCHED THEN
    INSERT (
        GTIN_KEY,
        RESERVATION_REFERENCE,
        SKU_ITEM_ID,
        SHIP_NODE,
        UPC_ITEM_ID,
        QUANTITY,
        SCHEDULED_ORDER_LINE_KEY,
        ORDER_NO,
        ORDERLINE_RELEASE_KEY,
        PRIME_LINE_NO,
        SUB_LINE_NO,
        UNIT_OF_MEASURE,
        PRODUCT_CLASS,
        SEGMENT_TYPE,
        RESERVATION_EXPIRY_TIME,
        INTERNAL_STATUS,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID,
        inserted_date
    ) 
    VALUES (
        ss.GTIN_KEY,
        ss.RESERVATION_REFERENCE,
        ss.SKU_ITEM_ID,
        ss.SHIP_NODE,
        ss.UPC_ITEM_ID,
        ss.QUANTITY,
        ss.SCHEDULED_ORDER_LINE_KEY,
        ss.ORDER_NO,
        ss.ORDERLINE_RELEASE_KEY,
        ss.PRIME_LINE_NO,
        ss.SUB_LINE_NO,
        ss.UNIT_OF_MEASURE,
        ss.PRODUCT_CLASS,
        ss.SEGMENT_TYPE,
        ss.RESERVATION_EXPIRY_TIME,
        ss.INTERNAL_STATUS,
        ss.CREATETS,
        ss.MODIFYTS,
        ss.CREATEUSERID,
        ss.MODIFYUSERID,
        ss.CREATEPROGID,
        ss.MODIFYPROGID,
        ss.LOCKID,
        CURRENT_TIMESTAMP
    );

INSERT INTO insertedGtinRecords
SELECT 
    t.GTIN_KEY,
    s.txn_id,
    1
FROM ANALYTICS.txn_gtin_data t
    INNER JOIN TRANSFORMED.stg_order_gtin_data s
        on t.GTIN_KEY = s.GTIN_KEY
WHERE t.inserted_date >= :processedDate or t.modified_date >= :processedDate;


-- UPDATE insertedGtinRecords AS ttd
-- SET ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS INT)
-- FROM (
--     SELECT
--         MAX(aot.revision) AS revision,
--         aot.GTIN_KEY
--     FROM
--         ANALYTICS.audit_gtin_data AS aot
--         INNER JOIN insertedGtinRecords AS ttd ON ttd.GTIN_KEY = aot.GTIN_KEY
--     GROUP BY
--         aot.GTIN_KEY
-- ) AS aot
-- WHERE ttd.GTIN_KEY = aot.GTIN_KEY;


CREATE OR REPLACE TEMPORARY TABLE temp_max_revisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.GTIN_KEY
FROM
    ANALYTICS.audit_gtin_data AS aot
GROUP BY
    aot.GTIN_KEY;

UPDATE insertedGtinRecords AS ttd
SET
    ttd.revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM
    temp_max_revisions AS aot
WHERE
    ttd.GTIN_KEY = aot.GTIN_KEY;

DROP TABLE IF EXISTS temp_max_revisions;

INSERT INTO ANALYTICS.audit_gtin_data (
    GTIN_KEY,
    RESERVATION_REFERENCE,
    SKU_ITEM_ID,
    SHIP_NODE,
    UPC_ITEM_ID,
    QUANTITY,
    SCHEDULED_ORDER_LINE_KEY,
    ORDER_NO,
    ORDERLINE_RELEASE_KEY,
    PRIME_LINE_NO,
    SUB_LINE_NO,
    UNIT_OF_MEASURE,
    PRODUCT_CLASS,
    SEGMENT_TYPE,
    RESERVATION_EXPIRY_TIME,
    INTERNAL_STATUS,
    CREATETS,
    MODIFYTS,
    CREATEUSERID,
    MODIFYUSERID,
    CREATEPROGID,
    MODIFYPROGID,
    LOCKID,
    inserted_date,
    revision
)
SELECT 
    ss.GTIN_KEY,
    ss.RESERVATION_REFERENCE,
    ss.SKU_ITEM_ID,
    ss.SHIP_NODE,
    ss.UPC_ITEM_ID,
    TRY_TO_NUMBER(ss.QUANTITY),
    ss.SCHEDULED_ORDER_LINE_KEY,
    ss.ORDER_NO,
    ss.ORDERLINE_RELEASE_KEY,
    ss.PRIME_LINE_NO,
    ss.SUB_LINE_NO,
    ss.UNIT_OF_MEASURE,
    ss.PRODUCT_CLASS,
    ss.SEGMENT_TYPE,
    TRY_TO_TIMESTAMP(LEFT(SS.RESERVATION_EXPIRY_TIME,14),''YYYYMMDDHHMISS'') AS RESERVATION_EXPIRY_TIME,
        SS.INTERNAL_STATUS,
        TRY_TO_TIMESTAMP(SS.CREATETS,''YYYYMMDDHHMISS'') AS CREATETS,
        TRY_TO_TIMESTAMP(SS.MODIFYTS,''YYYYMMDDHHMISS'') AS MODIFYTS,
    ss.CREATEUSERID,
    ss.MODIFYUSERID,
    ss.CREATEPROGID,
    ss.MODIFYPROGID,
    ss.LOCKID,
    CURRENT_TIMESTAMP,
    ord.Revision
FROM TRANSFORMED.stg_order_gtin_data ss
INNER JOIN insertedGtinRecords ord ON ord.GTIN_KEY = ss.GTIN_KEY;

UPDATE RAW.raw_order_gtin_data AS ros
SET
    ros.processing_status = ''Processed'',
    ros.processing_comment = '''',
    ros.processing_errortype = ''''
FROM insertedGtinRecords AS tos
WHERE tos.GTIN_KEY = ros.GTIN_KEY
  AND tos.txn_id = ros.txn_id;


SELECT COUNT(*)
INTO :processedRecordCount
FROM insertedGtinRecords;


SELECT COUNT(*)
INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_order_gtin_data;

UPDATE log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
WHERE
    file_name = ''EXTN_GTIN_DATA'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;

RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''EXTN_GTIN_DATA'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';

CREATE PROCEDURE "USP_ORDERS_ALLOCATION_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE tempOrderAllocation (
pk_order_allocationid BIGINT
, fk_sourceid SMALLINT 
, source_ref_num TEXT 
, fk_skuproductid INT 
, fk_warehouseid INT 
, upc_code TEXT 
, fk_upcid INT 
, quantity INT 
, external_dateentered  TIMESTAMP_NTZ(9) 
, external_orderid INT 
, fk_order_headerid BIGINT 
, inserted_date TIMESTAMP 
, modified_date TIMESTAMP 
);

CREATE OR REPLACE TEMPORARY TABLE ORDERALLOCATION AS 
    SELECT distinct stg.order_release_key
    ,toh.pk_order_headerid as fk_order_headerid
    ,toh.fk_sourceid as fk_sourceid
    ,toh.source_ref_num as source_ref_num
    ,oegd.sku_item_id as sku_code
    ,sku.pk_skuproductid as fk_skuproductid
    ,upc.pk_upcid as fk_upcid
    ,oegd.upc_item_id  as upc_code
    ,oegd.quantity as quantity
    ,stg.shipnode_key as fk_warehouseid
    ,getdate() as external_dateentered 
    ,stg.order_release_key as external_orderid
FROM ANALYTICS.txn_order_release stg 
    INNER JOIN ANALYTICS.txn_order_header as toh 
		on stg.order_header_key = toh.ext_order_id --and stg.txn_id = roh.txn_id
	INNER JOIN MASTER.source_brand_platform_map AS src 
		ON src.BrandCodeForWHM = ANALYTICS.fun_get_edw_brand_by_order_sellerorgcode(toh.seller_organization_code) AND src.platformname = COALESCE(ANALYTICS.fun_get_edw_platform_by_order_entrytype(toh.ENTRY_TYPE), '''')
	INNER JOIN ANALYTICS.txn_gtin_data oegd 
		ON oegd.orderline_release_key = stg.order_release_key
	INNER JOIN ANALYTICS.sku_product sku 
		ON sku.sku_code = oegd.sku_item_id 
	INNER JOIN ANALYTICS.upc upc 
		ON upc.upc_code = oegd.upc_item_id 
;

processedDate := CURRENT_TIMESTAMP();  

MERGE INTO   ANALYTICS.txn_order_allocation AS toa
USING (
    SELECT DISTINCT
        fk_sourceid,
        sku_code,
        fk_warehouseid,
        source_ref_num,
        CAST(CAST(quantity AS NUMERIC) AS INT) AS quantity,
        upc_code,
        fk_order_headerid,
        external_dateentered,
        external_orderid,
        fk_skuproductid,
        fk_upcid
    FROM 
        ORDERALLOCATION AS ordallocation
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM ANALYTICS.txn_order_allocation toa
            WHERE 
                ordallocation.fk_sourceid = toa.fk_sourceid
                AND ordallocation.source_ref_num = toa.source_ref_num
                AND ordallocation.fk_skuproductid = toa.fk_skuproductid
                AND ordallocation.fk_upcid = toa.fk_upcid
        )
) AS oa
ON 
    toa.fk_sourceid = oa.fk_sourceid
    AND toa.source_ref_num = oa.source_ref_num
    AND toa.fk_skuproductid = oa.fk_skuproductid
    AND toa.fk_upcid = oa.fk_upcid
WHEN NOT MATCHED THEN
    INSERT (
        fk_sourceid,
        source_ref_num,
        sku_code,
        fk_skuproductid,
        fk_warehouseid,
        upc_code,
        fk_upcid,
        quantity,
        external_dateentered,
        external_orderid,
        fk_order_headerid,
        inserted_date,
        modified_date
    )
    VALUES (
        oa.fk_sourceid,
        oa.source_ref_num,
        oa.sku_code,
        oa.fk_skuproductid,
        oa.fk_warehouseid,
        oa.upc_code,
        oa.fk_upcid,
        oa.quantity,
        TO_TIMESTAMP_NTZ(oa.external_dateentered),
        TRY_TO_NUMBER(oa.external_orderid),
        oa.fk_order_headerid,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );

INSERT INTO  ANALYTICS.audit_order_allocation (
    pk_order_allocationid,
    fk_sourceid,
    source_ref_num,
    sku_code,
    fk_skuproductid,
    fk_warehouseid,
    upc_code,
    fk_upcid,
    quantity,
    external_dateentered,
    external_orderid,
    fk_order_headerid,
    inserted_date,
    modified_date
)
SELECT 
    pk_order_allocationid,
    fk_sourceid,
    source_ref_num,
    sku_code,
    fk_skuproductid,
    fk_warehouseid,
    upc_code,
    fk_upcid,
    quantity,
    external_dateentered,
    external_orderid,
    fk_order_headerid,
    inserted_date,
    modified_date
FROM ANALYTICS.txn_order_allocation
WHERE inserted_date >= :processedDate
OR modified_date >= :processedDate;

SELECT COUNT(*)
INTO :processedRecordCount
FROM orderAllocation;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''upsert completed successfully''
    );
    
RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

            error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);
                                     
        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDERS_DELIVERED_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE error_object VARIANT;
start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

MERGE into  analytics.txn_order_delivered AS tod
				USING (
						SELECT distinct tos.shipment_key as shipment_key 
						   ,tos.order_no as SourceRefNum
						   ,tos.pickticket_no as OrderIDForWarehouse 
						   ,line.item_id as sku_code
						   ,line.item_id as fk_skuproductid
						   ,containerdetails.extn_upc_item_id as upc_code
						   ,dup.pk_upcid as fk_upcid
						   ,85 as fk_warehouseid
						   ,tos.total_quantity as Qty
						   ,tos.actual_delivery_date as DateDelivered
						   ,tos.pickticket_no as WarehouseReferenceNumber
						   ,NULL as IsResend
						   ,NULL as IsReroute
						   ,NULL as IsSuccessful
						   ,tos.carrier_service_code as ShippingMethodID
						   ,src.PlatformId as fk_platformID
						   ,tos.order_header_key as external_orderid
						   ,toh.fk_sourceid as fk_sourceid 
						   ,soopi.address1 as ShipAddress1 
						   ,soopi.address2 as ShipAddress2
						   ,soopi.city as ShipCity
						   ,soopi.state  as ShipState
						   ,soopi.postal_code as ShipPostalCode	 
						   ,soopi.first_name as ShipFirstName
						   ,soopi.last_name as ShipLastName 
						   ,soopi.company_name as ShipCompanyName
						   ,toh.order_date as OrderDate
						   ,toh.pk_order_headerid as fk_order_headerid
						   ,tos.carrier_service_code as WarehouseShippingMethodID
						   ,tos.scac as CarrierCode
						   ,tos.order_type as Ordertype
                           
						from  analytics.txn_order_shipment tos 
						INNER JOIN analytics.txn_order_header as toh 
							ON tos.order_header_key = toh.ext_order_id
						INNER JOIN analytics.txn_order_shipment_line line 
							ON line.shipment_key = tos.shipment_key
						INNER JOIN  MASTER.source_brand_platform_map AS src 
							ON src.BrandCodeForWHM = analytics.fun_get_edw_brand_by_order_sellerorgcode(toh.seller_organization_code) AND src.platformname = nvl(analytics.fun_get_edw_platform_by_order_entrytype(toh.ENTRY_TYPE), '''')
	  					INNER JOIN  analytics.txn_order_shipment_container container 
							ON container.shipment_key = tos.shipment_key
						INNER JOIN analytics.txn_address soopi 
							ON  CAST(soopi.ext_address_id AS VARCHAR) = CAST(tos.to_address_key AS VARCHAR)  
						INNER JOIN analytics.txn_order_detail as tod 
							ON tod.fk_order_headerid = toh.pk_order_headerid and 
								tod.ext_line_id = line.order_line_key
						INNER JOIN analytics.txn_order_container_details containerdetails 
							ON line.order_line_key = containerdetails.order_line_key  AND 
								tos.order_header_key = containerdetails.order_line_key
						INNER JOIN ANALYTICS.upc as dup 
							ON  dup.upc_code = containerdetails.extn_upc_item_id
					)AS orddetail
						ON orddetail.SourceRefNum = tod.SourceRefNum
						AND orddetail.Sku_code = tod.Sku_code
						AND orddetail.Upc_code = tod.Upc
						AND orddetail.fk_order_headerid = tod.fk_order_headerid
					WHEN MATCHED 
					THEN 
					UPDATE SET
						tod.external_Id = orddetail.shipment_key
						,tod.OrderIDForWarehouse = orddetail.OrderIDForWarehouse
						,tod.fk_skuproductid= orddetail.fk_skuproductid
						,tod.fk_upcid= orddetail.fk_upcid
						,tod.fk_WarehouseID =orddetail.fk_WarehouseID
						,tod.Qty            = orddetail.Qty
						,tod.DateDelivered         = orddetail.DateDelivered
						,tod.WarehouseReferenceNumber =orddetail.WarehouseReferenceNumber
						,tod.IsResend = orddetail.IsResend
						,tod.IsReroute = orddetail.IsReroute
						,tod.IsSuccessful = orddetail.IsSuccessful
						,tod.ShippingMethodID = orddetail.ShippingMethodID
						,tod.external_orderid = orddetail.external_orderid
						,tod.fk_platformID = orddetail.fk_platformID
						,tod.OrderType = orddetail.ordertype
						,tod.ShipAddress1 = orddetail.ShipAddress1
						,tod.ShipAddress2 = orddetail.ShipAddress2
						,tod.ShipCity = orddetail.ShipCity
						,tod.ShipState = orddetail.ShipState
						,tod.ShipPostalCode = orddetail.ShipPostalCode
						,tod.ShipFirstName = orddetail.ShipFirstName
						,tod.ShipLastName = orddetail.ShipLastName
						,tod.ShipCompanyName = orddetail.ShipCompanyName
						,tod.OrderDate = orddetail.OrderDate
						,tod.fk_sourceid = orddetail.fk_sourceid
						,tod.WarehouseShippingMethodID = orddetail.WarehouseShippingMethodID
						,tod.CarrierCode = orddetail.CarrierCode
						,tod.modified_date = current_date()
				WHEN NOT MATCHED
					THEN
						INSERT (
						 external_Id
						,SourceRefNum
						,OrderIDForWarehouse
						,Sku_code
						,fk_skuproductid
						,Upc
						,fk_upcid
						,fk_WarehouseID
						,Qty
						,DateDelivered
						,WarehouseReferenceNumber
						,IsResend
						,IsReroute
						,IsSuccessful
						,ShippingMethodID
						,external_orderid
						,fk_platformID
						,OrderType
						,ShipAddress1
						,ShipAddress2
						,ShipCity
						,ShipState
						,ShipPostalCode
						,ShipFirstName
						,ShipLastName
						,ShipCompanyName
						,OrderDate
						,fk_sourceid
						,WarehouseShippingMethodID
						,CarrierCode
						,fk_order_headerid
						,inserted_date
						,modified_date
							)
						VALUES (
						orddetail.shipment_key
						,orddetail.SourceRefNum
						,orddetail.OrderIDForWarehouse
						,orddetail.Sku_code
						,orddetail.fk_skuproductid
						,orddetail.Upc_code
						,orddetail.fk_upcid
						,orddetail.fk_WarehouseID
						,orddetail.Qty
						,orddetail.DateDelivered
						,orddetail.WarehouseReferenceNumber
						,orddetail.IsResend
						,orddetail.IsReroute
						,orddetail.IsSuccessful
						,orddetail.ShippingMethodID
						,orddetail.external_orderid
						,orddetail.fk_platformID
						,orddetail.ordertype
						,orddetail.ShipAddress1
						,orddetail.ShipAddress2
						,orddetail.ShipCity
						,orddetail.ShipState
						,orddetail.ShipPostalCode
						,orddetail.ShipFirstName
						,orddetail.ShipLastName
						,orddetail.ShipCompanyName
						,orddetail.OrderDate
						,orddetail.fk_sourceid
						,orddetail.WarehouseShippingMethodID
						,orddetail.CarrierCode
						,orddetail.fk_order_headerid
						,current_date
						,current_date);
CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDERS_PAYMENTS_INSERT"("CURRENTDATETIME" TIMESTAMP_NTZ(9))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    createdby NUMBER DEFAULT 1;
    shipAddressType NUMBER;
    InitialRevision NUMBER DEFAULT 1;
    prcessedRecordCount NUMBER DEFAULT 0;
    maxPaymentId NUMBER;
    maxPaymentMethodId NUMBER;  
    toBeProcessedRecordCount NUMBER;

BEGIN

SELECT COALESCE(MAX(pk_payment_typeid)+1, 0)  INTO :maxPaymentId FROM  master.dim_PAYMENT_TYPE;

  
  --CREATE or replace SEQUENCE analytics.payment_seq STARTswith ((:maxPaymentId)+1) INCREMENT BY 1 ;
  
execute immediate ''CREATE or replace SEQUENCE analytics.payment_seq start with '' ||:maxPaymentId ||'' INCREMENT BY 1'';


  INSERT INTO master.dim_PAYMENT_TYPE(pk_payment_typeid, payment_type_name)
  SELECT  analytics.payment_Seq.NEXTVAL+ 1, LOWER(temp.payment_type)
  FROM (
    SELECT DISTINCT stg.payment_type
    FROM transformed.stg_order_payment stg
    LEFT JOIN analytics.txn_order_header ord ON stg.order_header_key = ord.order_header_key
    LEFT JOIN master.dim_PAYMENT_TYPE AS ptype ON LOWER(ptype.payment_type_name) = LOWER(stg.payment_type)
    WHERE pk_order_headerid IS NOT NULL AND ptype.pk_payment_typeid IS NULL
  ) AS temp;

  

  SELECT COALESCE(MAX(pk_payment_method_id)+1,0) INTO :maxPaymentMethodId FROM master.dim_PAYMENT_METHOD;

   --CREATE or replace SEQUENCE analytics.payment_seq START WITH :maxPaymentMethodId+1 INCREMENT BY 1 ;

   execute immediate ''CREATE or replace SEQUENCE analytics.payment_seq start with '' ||:maxPaymentMethodId ||'' INCREMENT BY 1'';

  INSERT INTO master.dim_PAYMENT_METHOD(pk_payment_method_id, payment_method_name)
  SELECT analytics.payment_Seq.NEXTVAL+ 1, LOWER(temp.payment_method)
  FROM (
    SELECT DISTINCT stg.credit_card_type AS payment_method
    FROM transformed.stg_order_payment stg
    LEFT JOIN analytics.txn_order_header ord ON stg.order_header_key = ord.order_header_key
    LEFT JOIN master.dim_PAYMENT_METHOD AS pmethod ON LOWER(pmethod.payment_method_name) = LOWER(stg.credit_card_type)
    WHERE pk_order_headerid IS NOT NULL AND pmethod.pk_payment_method_id IS NULL AND stg.credit_card_type IS NOT NULL
  ) AS temp;


  
create or replace temporary table analytics.orderpaymentdetails as 
  SELECT
    ptype.pk_payment_typeid AS fk_payment_typeid,
    NULL AS authorization_id,
    pmethod.pk_payment_method_id AS fk_payment_method_id,
    ord.fk_sourceid,
    ord.pk_order_headerid,
    stg.payment_key AS ext_paymentid,
    NULL AS auth_code,
    NULL AS cvv2_response,
    ord.fk_currencyid,
    stg.total_charged AS payment_amount,
    CONCAT(''xxx-xxx-'', RIGHT(stg.credit_card_no, 4)) AS payment_Details,
    0 AS is_deleted,
    1 AS seq_no,
    stg.createts AS order_payment_date,
    stg.display_credit_card_no
  FROM
     transformed.stg_order_payment stg
  LEFT JOIN analytics.txn_order_header ord ON stg.order_header_key = ord.order_header_key
  LEFT JOIN master.dim_PAYMENT_TYPE AS ptype ON LOWER(ptype.payment_type_name) = LOWER(stg.payment_type)
  LEFT JOIN master.dim_PAYMENT_METHOD AS pmethod ON LOWER(pmethod.payment_method_name) = LOWER(stg.credit_card_type)
  WHERE
    pk_order_headerid IS NOT NULL AND ptype.pk_payment_typeid IS NOT NULL;


CREATE OR REPLACE temporary TABLE analytics.paymentseqno AS
  SELECT
    paydetails.ext_paymentid,
    COALESCE(MAX(txnpay.seq_no) + 1, 1) AS calc_seq_no
  FROM
    analytics.orderpaymentdetails paydetails
  LEFT JOIN analytics.txn_payment txnpay ON paydetails.pk_order_headerid = txnpay.fk_order_headerid AND paydetails.ext_paymentid <> txnpay.ext_paymentid
  GROUP BY
    paydetails.ext_paymentid;

    create or replace temporary table analytics.VALID_charge_transaction as 
SELECT DISTINCT * FROM analytics.txn_charge_transaction as r where r.status =''CHECKED''  ;


   MERGE INTO  analytics.txn_payment AS pay
USING (
    SELECT 
        pd.*, 
        ps.calc_seq_no,
        tct.authorization_id AS auth_id
    FROM 
        analytics.orderpaymentdetails AS pd
    JOIN 
        analytics.paymentseqno AS ps 
    ON 
        pd.ext_paymentid = ps.ext_paymentid
    LEFT JOIN 
        analytics.VALID_charge_transaction AS tct 
    ON 
        tct.payment_key = pd.ext_paymentid
) AS paydetail ON paydetail.ext_paymentid = pay.ext_paymentid
WHEN NOT MATCHED THEN
    INSERT (
      transactionid,
      ext_paymentid,
      fk_sourceid,
      fk_payment_methodid,
      fk_payment_typeid,
      authorization_code,
      avs_response,
      cvv2_response,
      payment_amount,
      fk_currencyid,
      payment_details,
      isdeleted,
      payment_date,
      cc_last4,
      fk_parent_paymentid,
      fk_order_headerid,
      seq_no,
      CreatedDate,
      modified_date
    )
    VALUES (
      COALESCE(paydetail.auth_id, ''0''),
      paydetail.ext_paymentid,
      paydetail.fk_sourceid,
      COALESCE(paydetail.fk_payment_method_id, 23),
      paydetail.fk_payment_typeid,
      NULL,
      NULL,
      paydetail.cvv2_response,
      paydetail.payment_amount,
      paydetail.fk_currencyid,
      paydetail.payment_details,
      0,
      -- TO_TIMESTAMP(CONCAT(SUBSTRING(paydetail.order_payment_date, 1, 8), '' '', STUFF(STUFF(RIGHT(paydetail.order_payment_date, 6), 5, 0, '':''), 3, 0, '':''))),
      TO_TIMESTAMP(order_payment_date,''yyyymmddhhmiss''),
      REPLACE(paydetail.display_credit_card_no, ''.0'', ''''),
      NULL,
      paydetail.pk_order_headerid,
      paydetail.calc_seq_no,
      current_timestamp(),
      current_timestamp()
      
    );

    UPDATE raw.raw_order_payment raw
  SET
    raw.processing_status = ''Processed'',
    raw.processing_comment = ''Inserted into Payments'',
    raw.processing_errortype = NULL,
    raw.imported_date = current_timestamp()
  where raw.payment_key in 
  (select raw.payment_key from 
    raw.raw_order_payment raw
  JOIN analytics.orderpaymentdetails paydetails ON paydetails.ext_paymentid = raw.payment_key
  JOIN analytics.txn_payment txn ON txn.ext_paymentid = raw.payment_key);

  SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM transformed.stg_order_payment;

  
  SELECT COUNT(*) INTO :prcessedRecordCount  from analytics.orderpaymentdetails;

  UPDATE analytics.log_files_import_status lofis
  SET
    lofis.processed = :prcessedRecordCount,
    lofis.to_be_processed = :toBeProcessedRecordCount,
    lofis.status = ''Success''
  WHERE
    lofis.file_name = ''YFS_PAYMENT'';

  COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDERS_PAYMENTS_INSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    createdby NUMBER DEFAULT 1;
    shipAddressType NUMBER;
    InitialRevision NUMBER DEFAULT 1;
    prcessedRecordCount NUMBER DEFAULT 0;
    maxPaymentId NUMBER;
    maxPaymentMethodId NUMBER;  
    toBeProcessedRecordCount NUMBER;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);

BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

SELECT COALESCE(MAX(pk_payment_typeid)+1, 0)  INTO :maxPaymentId FROM  master.dim_PAYMENT_TYPE;

  
  --CREATE or replace SEQUENCE analytics.payment_seq STARTswith ((:maxPaymentId)+1) INCREMENT BY 1 ;
  
execute immediate ''CREATE or replace SEQUENCE analytics.payment_seq start with '' ||:maxPaymentId ||'' INCREMENT BY 1'';


  INSERT INTO master.dim_PAYMENT_TYPE(pk_payment_typeid, payment_type_name)
  SELECT  analytics.payment_Seq.NEXTVAL+ 1, LOWER(temp.payment_type)
  FROM (
    SELECT DISTINCT stg.payment_type
    FROM transformed.stg_order_payment stg
    LEFT JOIN analytics.txn_order_header ord ON stg.order_header_key = ord.order_header_key
    LEFT JOIN master.dim_PAYMENT_TYPE AS ptype ON LOWER(ptype.payment_type_name) = LOWER(stg.payment_type)
    WHERE pk_order_headerid IS NOT NULL AND ptype.pk_payment_typeid IS NULL
  ) AS temp;

  

  SELECT COALESCE(MAX(pk_payment_method_id)+1,0) INTO :maxPaymentMethodId FROM master.dim_PAYMENT_METHOD;

   --CREATE or replace SEQUENCE analytics.payment_seq START WITH :maxPaymentMethodId+1 INCREMENT BY 1 ;

   execute immediate ''CREATE or replace SEQUENCE analytics.payment_seq start with '' ||:maxPaymentMethodId ||'' INCREMENT BY 1'';

  INSERT INTO master.dim_PAYMENT_METHOD(pk_payment_method_id, payment_method_name)
  SELECT analytics.payment_Seq.NEXTVAL+ 1, LOWER(temp.payment_method)
  FROM (
    SELECT DISTINCT stg.credit_card_type AS payment_method
    FROM transformed.stg_order_payment stg
    LEFT JOIN analytics.txn_order_header ord ON stg.order_header_key = ord.order_header_key
    LEFT JOIN master.dim_PAYMENT_METHOD AS pmethod ON LOWER(pmethod.payment_method_name) = LOWER(stg.credit_card_type)
    WHERE pk_order_headerid IS NOT NULL AND pmethod.pk_payment_method_id IS NULL AND stg.credit_card_type IS NOT NULL
  ) AS temp;


  
create or replace temporary table analytics.orderpaymentdetails as 
  SELECT
    ptype.pk_payment_typeid AS fk_payment_typeid,
    NULL AS authorization_id,
    pmethod.pk_payment_method_id AS fk_payment_method_id,
    ord.fk_sourceid,
    ord.pk_order_headerid,
    stg.payment_key AS ext_paymentid,
    NULL AS auth_code,
    NULL AS cvv2_response,
    ord.fk_currencyid,
    stg.total_charged AS payment_amount,
    CONCAT(''xxx-xxx-'', RIGHT(stg.credit_card_no, 4)) AS payment_Details,
    0 AS is_deleted,
    1 AS seq_no,
    stg.createts AS order_payment_date,
    stg.display_credit_card_no
  FROM
     transformed.stg_order_payment stg
  LEFT JOIN analytics.txn_order_header ord ON stg.order_header_key = ord.order_header_key
  LEFT JOIN master.dim_PAYMENT_TYPE AS ptype ON LOWER(ptype.payment_type_name) = LOWER(stg.payment_type)
  LEFT JOIN master.dim_PAYMENT_METHOD AS pmethod ON LOWER(pmethod.payment_method_name) = LOWER(stg.credit_card_type)
  WHERE
    pk_order_headerid IS NOT NULL AND ptype.pk_payment_typeid IS NOT NULL;


CREATE OR REPLACE temporary TABLE analytics.paymentseqno AS
  SELECT
    paydetails.ext_paymentid,
    COALESCE(MAX(txnpay.seq_no) + 1, 1) AS calc_seq_no
  FROM
    analytics.orderpaymentdetails paydetails
  LEFT JOIN analytics.txn_payment txnpay ON paydetails.pk_order_headerid = txnpay.fk_order_headerid AND paydetails.ext_paymentid <> txnpay.ext_paymentid
  GROUP BY
    paydetails.ext_paymentid;

    create or replace temporary table analytics.VALID_charge_transaction as 
SELECT DISTINCT * FROM analytics.txn_charge_transaction as r where r.status =''CHECKED''  ;


   MERGE INTO  analytics.txn_payment AS pay
USING (
    SELECT 
        pd.*, 
        ps.calc_seq_no,
        tct.authorization_id AS auth_id
    FROM 
        analytics.orderpaymentdetails AS pd
    JOIN 
        analytics.paymentseqno AS ps 
    ON 
        pd.ext_paymentid = ps.ext_paymentid
    LEFT JOIN 
        analytics.VALID_charge_transaction AS tct 
    ON 
        tct.payment_key = pd.ext_paymentid
) AS paydetail ON paydetail.ext_paymentid = pay.ext_paymentid
WHEN NOT MATCHED THEN
    INSERT (
      transactionid,
      ext_paymentid,
      fk_sourceid,
      fk_payment_methodid,
      fk_payment_typeid,
      authorization_code,
      avs_response,
      cvv2_response,
      payment_amount,
      fk_currencyid,
      payment_details,
      isdeleted,
      payment_date,
      cc_last4,
      fk_parent_paymentid,
      fk_order_headerid,
      seq_no,
      CreatedDate,
      modified_date
    )
    VALUES (
      COALESCE(paydetail.auth_id, ''0''),
      paydetail.ext_paymentid,
      paydetail.fk_sourceid,
      COALESCE(paydetail.fk_payment_method_id, 23),
      paydetail.fk_payment_typeid,
      NULL,
      NULL,
      paydetail.cvv2_response,
      paydetail.payment_amount,
      paydetail.fk_currencyid,
      paydetail.payment_details,
      0,
      -- TO_TIMESTAMP(CONCAT(SUBSTRING(paydetail.order_payment_date, 1, 8), '' '', STUFF(STUFF(RIGHT(paydetail.order_payment_date, 6), 5, 0, '':''), 3, 0, '':''))),
      try_to_timestamp(order_payment_date,''yyyymmddhhmiss''),
      REPLACE(paydetail.display_credit_card_no, ''.0'', ''''),
      NULL,
      paydetail.pk_order_headerid,
      paydetail.calc_seq_no,
      current_timestamp(),
      current_timestamp()
      
    );

    UPDATE raw.raw_order_payment raw
  SET
    raw.processing_status = ''Processed'',
    raw.processing_comment = ''Inserted into Payments'',
    raw.processing_errortype = NULL,
    raw.imported_date = current_timestamp()
  where raw.payment_key in 
  (select raw.payment_key from 
    raw.raw_order_payment raw
  JOIN analytics.orderpaymentdetails paydetails ON paydetails.ext_paymentid = raw.payment_key
  JOIN analytics.txn_payment txn ON txn.ext_paymentid = raw.payment_key);

  SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM transformed.stg_order_payment;

  
  SELECT COUNT(*) INTO :prcessedRecordCount  from analytics.orderpaymentdetails;

  UPDATE analytics.log_files_import_status lofis
  SET
    lofis.processed = :prcessedRecordCount,
    lofis.to_be_processed = :toBeProcessedRecordCount,
    lofis.status = ''Success''
  WHERE
    lofis.file_name = ''YFS_PAYMENT'';
CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;

RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_PAYMENT'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
CREATE PROCEDURE "USP_ORDER_ADDRESS_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    shipAddressType SMALLINT DEFAULT 0;
    billAddressType SMALLINT DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 
start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status
SET 
    processed = :processedRecordCount
WHERE file_name = ''YFS_PERSON_INFO'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

SELECT pk_address_typeid 
INTO :shipAddressType
FROM MASTER.DIM_ADDRESS_TYPE
WHERE address_type_name = ''Shipping'';

SELECT pk_address_typeid 
INTO :billAddressType
FROM MASTER.DIM_ADDRESS_TYPE
WHERE address_type_name = ''Billing'';

processedDate := CURRENT_TIMESTAMP();  

CREATE OR REPLACE TEMPORARY TABLE temp_audit_address (
    first_name STRING(255), 
    last_name STRING(100), 
    company_name STRING(100), 
    phone_number STRING(255), 
    address1 STRING(255), 
    address2 STRING(255), 
    city STRING(255), 
    state STRING(255), 
    country STRING(255), 
    postal_code STRING(255), 
    fk_address_typeid SMALLINT NOT NULL, 
    inserted_date TIMESTAMP_NTZ NOT NULL, 
    created_by INT, 
    modified_date TIMESTAMP_NTZ, 
    pk_addressid BIGINT NOT NULL, 
    Revision INT, 
    ext_address_id STRING(510), 
    txn_id STRING
);

MERGE INTO   ANALYTICS.txn_address AS ta
USING (
    SELECT  
        person_info_key,  
        first_name,  
        middle_name,  
        last_name,  
        company,  
        address_line1,  
        address_line2,  
        address_line3,  
        address_line4,  
        address_line5,  
        address_line6,  
        city,  
        state,  
        zip_code,  
        country,  
        day_phone,  
        evening_phone,  
        mobile_phone,  
        other_phone,  
        txn_id  
    FROM  
        TRANSFORMED.stg_order_person_info
) AS src
ON src.person_info_key = ta.ext_address_id
AND ta.fk_address_typeid = :shipAddressType
WHEN NOT MATCHED THEN
INSERT
(
    ext_address_id,  
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    address3,  
    address4,  
    address5,  
    address6,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date
)
VALUES
(
    src.person_info_key,  
    src.first_name,  
    TRIM(CONCAT(src.middle_name, '' '', src.last_name)),  
    src.company,  
    COALESCE(src.mobile_phone, src.other_phone),  
    src.address_line1,  
    src.address_line2,  
    src.address_line3,  
    src.address_line4,  
    src.address_line5,  
    src.address_line6,  
    src.city,  
    src.state,  
    src.country,  
    src.zip_code,  
    :shipAddressType,  
    CURRENT_TIMESTAMP(),  
    CURRENT_TIMESTAMP()
)
WHEN MATCHED THEN
UPDATE SET
    ta.first_name = src.first_name,  
    ta.last_name = TRIM(CONCAT(src.middle_name, '' '', src.last_name)),  
    ta.company_name = src.company,  
    ta.phone_number = COALESCE(src.mobile_phone, src.other_phone),  
    ta.address1 = src.address_line1,  
    ta.address2 = src.address_line2,  
    ta.address3 = src.address_line3,  
    ta.address4 = src.address_line4,  
    ta.address5 = src.address_line5,  
    ta.address6 = src.address_line6,  
    ta.city = src.city,  
    ta.state = src.state,  
    ta.country = src.country,  
    ta.postal_code = src.zip_code,  
    ta.modified_date = CURRENT_TIMESTAMP();

INSERT INTO temp_audit_address
(
    first_name,
    last_name,
    company_name,
    phone_number,
    address1,
    address2,
    city,
    state,
    country,
    postal_code,
    fk_address_typeid,
    inserted_date,
    modified_date,
    pk_addressid,
    Revision,
    ext_address_id,
    txn_id
)
SELECT
    ta.first_name,
    ta.last_name,
    ta.company_name,
    ta.phone_number,
    ta.address1,
    ta.address2,
    ta.city,
    ta.state,
    ta.country,
    ta.postal_code,
    ta.fk_address_typeid,
    ta.inserted_date,
    ta.modified_date,
    ta.pk_addressid,
    1 AS Revision,
    ta.ext_address_id,
    src.txn_id
FROM ANALYTICS.txn_address ta
    INNER JOIN TRANSFORMED.stg_order_person_info src 
        ON src.person_info_key = ta.ext_address_id
            AND ta.fk_address_typeid = :shipAddressType
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;

-- UPDATE 
--     temp_audit_address
-- SET 
--     Revision = CAST((aot.revision + 1) AS int)
-- FROM 
--     temp_audit_address AS ttd
-- INNER JOIN 
--     (
--         SELECT 
--             MAX(aot.revision) AS revision, 
--             aot.pk_addressid, 
--             aot.fk_address_typeid
--         FROM 
--             ANALYTICS.AUDIT_ADDRESS AS aot
--         INNER JOIN 
--             temP_audit_address AS ttd ON ttd.pk_addressid = aot.pk_addressid 
--             AND ttd.fk_address_typeid = aot.fk_address_typeid
--         GROUP BY 
--             aot.pk_addressid, 
--             aot.fk_address_typeid
--     ) AS aot ON ttd.pk_addressid = aot.pk_addressid 
--     AND ttd.fk_address_typeid = aot.fk_address_typeid;

CREATE OR REPLACE TEMPORARY TABLE temp_max_revisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.pk_addressid,
    aot.fk_address_typeid
FROM
    ANALYTICS.AUDIT_ADDRESS AS aot
GROUP BY
    aot.pk_addressid, 
    aot.fk_address_typeid;

UPDATE temp_audit_address AS ttd
SET
    ttd.revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM
    temp_max_revisions AS aot
WHERE
    ttd.pk_addressid = aot.pk_addressid AND
    ttd.fk_address_typeid = aot.fk_address_typeid ;

DROP TABLE IF EXISTS temp_max_revisions;

INSERT INTO  ANALYTICS.audit_address (
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date,  
    pk_addressid,  
    Revision,
    ext_address_id  
)
SELECT 
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date,  
    pk_addressid,  
    Revision,
    ext_address_id
FROM temp_audit_address;

TRUNCATE TABLE IF EXISTS temp_audit_address;

MERGE INTO  ANALYTICS.txn_address AS ta
USING (
    SELECT  
        person_info_key,  
        first_name,  
        middle_name,  
        last_name,  
        company,  
        address_line1,  
        address_line2,  
        address_line3,  
        address_line4,  
        address_line5,  
        address_line6,  
        city,  
        state,  
        zip_code,  
        country,  
        day_phone,  
        evening_phone,  
        mobile_phone,  
        other_phone,  
        txn_id  
    FROM  
        TRANSFORMED.stg_order_person_info
) AS src
ON src.person_info_key = ta.ext_address_id
AND ta.fk_address_typeid = :billAddressType
WHEN NOT MATCHED THEN
INSERT
(
    ext_address_id,  
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    address3,  
    address4,  
    address5,  
    address6,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date
)
VALUES
(
    src.person_info_key,  
    src.first_name,  
    TRIM(CONCAT(src.middle_name, '' '', src.last_name)),  
    src.company,  
    COALESCE(src.mobile_phone, src.other_phone),  
    src.address_line1,  
    src.address_line2,  
    src.address_line3,  
    src.address_line4,  
    src.address_line5,  
    src.address_line6,  
    src.city,  
    src.state,  
    src.country,  
    src.zip_code,  
    :billAddressType,  
    CURRENT_TIMESTAMP(),  
    CURRENT_TIMESTAMP()
)
WHEN MATCHED THEN
UPDATE SET
    ta.first_name = src.first_name,  
    ta.last_name = TRIM(CONCAT(src.middle_name, '' '', src.last_name)),  
    ta.company_name = src.company,  
    ta.phone_number = COALESCE(src.mobile_phone, src.other_phone),  
    ta.address1 = src.address_line1,  
    ta.address2 = src.address_line2,  
    ta.address3 = src.address_line3,  
    ta.address4 = src.address_line4,  
    ta.address5 = src.address_line5,  
    ta.address6 = src.address_line6,  
    ta.city = src.city,  
    ta.state = src.state,  
    ta.country = src.country,  
    ta.postal_code = src.zip_code,  
    ta.modified_date = CURRENT_TIMESTAMP();

INSERT INTO temp_audit_address
(
    first_name,
    last_name,
    company_name,
    phone_number,
    address1,
    address2,
    city,
    state,
    country,
    postal_code,
    fk_address_typeid,
    inserted_date,
    modified_date,
    pk_addressid,
    Revision,
    ext_address_id,
    txn_id
)
SELECT
    ta.first_name,
    ta.last_name,
    ta.company_name,
    ta.phone_number,
    ta.address1,
    ta.address2,
    ta.city,
    ta.state,
    ta.country,
    ta.postal_code,
    ta.fk_address_typeid,
    ta.inserted_date,
    ta.modified_date,
    ta.pk_addressid,
    1 AS Revision,
    ta.ext_address_id,
    src.txn_id
FROM ANALYTICS.txn_address ta
    INNER JOIN TRANSFORMED.stg_order_person_info src 
        ON src.person_info_key = ta.ext_address_id
            AND ta.fk_address_typeid = :billAddressType
;

-- UPDATE 
--     temp_audit_address
-- SET 
--     Revision = CAST((aot.revision + 1) AS int)
-- FROM 
--     temp_audit_address AS ttd
-- INNER JOIN 
--     (
--         SELECT 
--             MAX(aot.revision) AS revision, 
--             aot.pk_addressid, 
--             aot.fk_address_typeid
--         FROM 
--             ANALYTICS.AUDIT_ADDRESS AS aot
--         INNER JOIN 
--             temP_audit_address AS ttd ON ttd.pk_addressid = aot.pk_addressid 
--             AND ttd.fk_address_typeid = aot.fk_address_typeid
--         GROUP BY 
--             aot.pk_addressid, 
--             aot.fk_address_typeid
--     ) AS aot ON ttd.pk_addressid = aot.pk_addressid 
--     AND ttd.fk_address_typeid = aot.fk_address_typeid;

CREATE OR REPLACE TEMPORARY TABLE temp_max_revisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.pk_addressid,
    aot.fk_address_typeid
FROM
    ANALYTICS.AUDIT_ADDRESS AS aot
GROUP BY
    aot.pk_addressid, 
    aot.fk_address_typeid;

UPDATE temp_audit_address AS ttd
SET
    ttd.revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM
    temp_max_revisions AS aot
WHERE
    ttd.pk_addressid = aot.pk_addressid AND
    ttd.fk_address_typeid = aot.fk_address_typeid ;

INSERT INTO   ANALYTICS.audit_address (
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date,  
    pk_addressid,  
    Revision,
    ext_address_id
)
SELECT 
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date,  
    pk_addressid,  
    Revision,
    ext_address_id
FROM temp_audit_address;

-- UPDATE RAW.raw_order_person_info
-- SET
--     processing_status = ''Processed'',
--     processing_comment = '''',
--     processing_errortype = ''''
-- FROM RAW.raw_order_person_info AS roh
-- INNER JOIN TRANSFORMED.stg_order_person_info AS stg
--     ON stg.person_info_key = roh.person_info_key 
--     AND stg.modifyts = roh.modifyts 
--     AND stg.txn_id = roh.txn_id
-- INNER JOIN TEMP_audit_address AS toh
--     ON toh.ext_address_id = roh.person_info_key 
--     AND toh.txn_id = roh.txn_id
-- INNER JOIN temp_audit_address AS tsoh
--     ON tsoh.ext_address_id = roh.person_info_key 
--     AND tsoh.txn_id = roh.txn_id
-- WHERE roh.processing_status IN (''Pending'', ''Failed'');

MERGE INTO RAW.raw_order_person_info AS roh
USING (
    SELECT stg.person_info_key, stg.modifyts, stg.txn_id
    FROM TRANSFORMED.stg_order_person_info AS stg
    INNER JOIN TEMP_audit_address AS toh
        ON toh.ext_address_id = stg.person_info_key 
        AND toh.txn_id = stg.txn_id
    INNER JOIN TEMP_audit_address AS tsoh
        ON tsoh.ext_address_id = stg.person_info_key 
        AND tsoh.txn_id = stg.txn_id
) AS source
ON roh.person_info_key = source.person_info_key
   AND roh.modifyts = source.modifyts
   AND roh.txn_id = source.txn_id
   AND roh.processing_status IN (''Pending'', ''Failed'')
WHEN MATCHED THEN 
    UPDATE SET 
        roh.processing_status = ''Processed'',
        roh.processing_comment = '''',
        roh.processing_errortype = '''';


SELECT  
    :toBeProcessedRecordCount = COUNT(*)  
FROM  
    TRANSFORMED.stg_order_person_info;

SELECT  
    :processedRecordCount = COUNT(*)  
FROM  
    temp_audit_address;

UPDATE  
    ANALYTICS.log_files_import_status  
SET  
    processed = :processedRecordCount,  
    to_be_processed = :toBeProcessedRecordCount,  
    status = ''Success''  
FROM  
    ANALYTICS.log_files_import_status  AS lofis
WHERE  
    lofis.file_name = ''YFS_PERSON_INFO'';

DROP TABLE IF EXISTS temp_audit_address;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;

RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_PERSON_INFO'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';

CREATE  PROCEDURE ANALYTICS.USP_ORDER_ALL_HEADER_AND_LINE_STATUS_GENERATION()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    message TEXT;
    invalidRecordCount NUMBER DEFAULT 0;
BEGIN 

CREATE OR REPLACE TEMPORARY TABLE TempAPI_order_line_status(
order_release_status_key STRING not null
, order_line_key STRING not null 
, order_header_key STRING NOT NULL 
, status_quantity INT
, total_quantity INT 
, status STRING 
, priority INT NOT NULL 
, txn_id STRING  NULL 
);

CREATE OR REPLACE TEMPORARY TABLE TempAPI_order_header_status(
order_header_key STRING not null 
, status_quantity INT 
, total_quantity INT 
, status STRING
, header_priority INT NOT NULL 
, txn_id STRING  null
);


INSERT INTO   TempAPI_order_line_status (
  order_release_status_key,
  order_line_key,
  order_header_key,
  status_quantity,
  total_quantity,
  status,
  priority
  ,txn_id
)
SELECT distinct 
  order_release_status_key,
  order_line_key,
  order_header_key,
  status_quantity,
  total_quantity,
  status,
  priority
  ,txn_id
FROM (
  SELECT
    order_release_status_key,
    order_header_key,
    order_line_key,
    CAST(status_quantity AS NUMERIC(19, 0)) AS status_quantity,
    CAST(total_quantity AS NUMERIC(19, 0)) AS total_quantity,
    status,
    txn_id,
    ROW_NUMBER() OVER (PARTITION BY txn_id, 
    order_line_key ORDER BY CAST(ANALYTICS.CleanAndTrimString(COALESCE(order_release_status_key, '0')) AS DECIMAL(38, 0)) DESC) AS priority
  FROM RAW.raw_order_release_status
  WHERE CAST(status_quantity AS NUMERIC(19, 0)) > 0
  
AND processing_status IN ('Pending', 'Failed')
) AS processed
WHERE priority = 1;

MERGE INTO RAW.raw_order_line AS sool
USING (
  SELECT distinct 
    MAX(order_release_status_key) AS order_release_status_key,
    order_line_key,
    order_header_key,
    status,
    txn_id
  FROM TempAPI_order_line_status
  GROUP BY order_line_key, order_header_key, status , txn_id
) AS ls
ON sool.ORDER_HEADER_KEY = ls.order_header_key
AND sool.ORDER_LINE_KEY = ls.order_line_key
AND sool.txn_id = ls.txn_id
AND sool.processing_status IN ('Pending', 'Failed')
WHEN MATCHED THEN
UPDATE SET
  sool.order_line_status = analytics.CleanAndTrimString(coalesce(ls.status, ''));

INSERT INTO TempAPI_order_header_status (
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority,
    txn_id
)
SELECT distinct 
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority
    ,txn_id
FROM (
    SELECT
        order_header_key,
        status_quantity,
        total_quantity,
        status,
        txn_id,
        ROW_NUMBER() OVER (
            PARTITION BY txn_id, 
            order_header_key
            ORDER BY CAST(analytics.CleanAndTrimString(COALESCE(status_quantity, '0')) AS NUMBER(38, 0)) ASC
        ) AS header_priority
    FROM (
        SELECT
            order_header_key,
            SUM(status_quantity) AS status_quantity,
            SUM(total_quantity) AS total_quantity,
            status,
            txn_id
        FROM
            TempAPI_order_line_status
        GROUP BY order_header_key, status , txn_id
    ) AS processed_line
) AS processed;

UPDATE raw.raw_order_header AS roh
SET roh.order_status = 
    CASE 
        WHEN ls.header_priority > 1 THEN '_' || analytics.CleanAndTrimString(COALESCE(ls.status, '')) 
        WHEN ls.header_priority = 1 THEN analytics.CleanAndTrimString(COALESCE(ls.status, '')) 
        ELSE NULL 
    END
FROM (
    SELECT 
        MAX(status_quantity) AS status_quantity,
        order_header_key,
        status,
        header_priority,
        txn_id
    FROM TempAPI_order_header_status 
    GROUP BY order_header_key, status, header_priority, txn_id
) AS ls
WHERE ls.order_header_key = roh.order_header_key
AND roh.txn_id = ls.txn_id
AND analytics.CleanAndTrimString(COALESCE(ls.status, '')) IS NOT NULL
AND roh.processing_status IN ('Pending', 'Failed');


SELECT 
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority,
    txn_id
FROM (
    SELECT 
        order_header_key,
        status_quantity,
        total_quantity,
        status,
        txn_id,
        ROW_NUMBER() OVER (
            PARTITION BY txn_id, order_header_key 
            ORDER BY 
                CAST(analytics.CleanAndTrimString(COALESCE(status_quantity, 0)) AS DECIMAL(38, 0)) ASC
        ) AS header_priority
    FROM (
        SELECT 
            order_header_key,
            SUM(status_quantity) AS status_quantity,
            SUM(total_quantity) AS total_quantity,
            status,
            txn_id
        FROM TempAPI_order_line_status 
        GROUP BY order_header_key, status, txn_id
    ) AS processed_line
) AS processed;



DROP TABLE IF EXISTS TempAPI_order_header_status;
DROP TABLE IF EXISTS TempAPI_order_line_status;

RETURN 'Success'; 
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    RETURN OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
END;


CREATE PROCEDURE "USP_ORDER_CLEAN_DUPLICATE_RAW_ENTRIES"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN

---raw_ORDER_gtin_data

create or replace temporary table raw.raw_ORDER_gtin_data_temp as 
select *  FROM raw.raw_ORDER_gtin_data
WHERE (gtin_key, modifyts) IN (
    SELECT gtin_key, modifyts
    FROM (
        SELECT 
            gtin_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY gtin_key, modifyts ORDER BY gtin_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_gtin_data
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed'');

DELETE FROM raw.raw_ORDER_gtin_data
WHERE (gtin_key, modifyts) IN (
    SELECT gtin_key, modifyts
    FROM (
        SELECT 
            gtin_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY gtin_key, modifyts ORDER BY gtin_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_gtin_data
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed'');

    insert into raw.raw_ORDER_gtin_data
    select * from  raw.raw_ORDER_gtin_data_temp
    qualify ROW_NUMBER() OVER (PARTITION BY gtin_key, modifyts ORDER BY gtin_key, modifyts, processing_status DESC)=1;
    

    --raw_ORDER_header_charges

    create or replace temporary table  raw.raw_ORDER_header_charges_temp as 
    select * from raw.raw_ORDER_header_charges 
WHERE (header_charges_key, modifyts) IN (
    SELECT header_charges_key, modifyts
    FROM (
        SELECT 
            header_charges_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY header_charges_key, modifyts ORDER BY header_charges_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_header_charges
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);
    
DELETE FROM raw.raw_ORDER_header_charges
WHERE (header_charges_key, modifyts) IN (
    SELECT header_charges_key, modifyts
    FROM (
        SELECT 
            header_charges_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY header_charges_key, modifyts ORDER BY header_charges_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_header_charges
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_header_charges
select * from raw.raw_ORDER_header_charges_temp
qualify ROW_NUMBER() OVER (PARTITION BY header_charges_key, modifyts ORDER BY header_charges_key, modifyts, processing_status DESC)=1;

--raw_ORDER_inbox
create or replace temporary table raw.raw_ORDER_inbox_temp as 
select * from raw.raw_ORDER_inbox
WHERE (INBOX_KEY, modifyts) IN (
    SELECT INBOX_KEY, modifyts
    FROM (
        SELECT 
            INBOX_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY INBOX_KEY, modifyts ORDER BY INBOX_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_inbox
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_inbox
WHERE (INBOX_KEY, modifyts) IN (
    SELECT INBOX_KEY, modifyts
    FROM (
        SELECT 
            INBOX_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY INBOX_KEY, modifyts ORDER BY INBOX_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_inbox
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_inbox
select * from raw.raw_ORDER_inbox_temp
qualify ROW_NUMBER() OVER (PARTITION BY INBOX_KEY, modifyts ORDER BY INBOX_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_line_charges 
create or replace temporary table raw.raw_ORDER_line_charges_temp as 
select *  FROM raw.raw_ORDER_line_charges
WHERE (line_charges_key, modifyts) IN (
    SELECT line_charges_key, modifyts
    FROM (
        SELECT 
            line_charges_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY line_charges_key, modifyts ORDER BY line_charges_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_line_charges
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_line_charges
WHERE (line_charges_key, modifyts) IN (
    SELECT line_charges_key, modifyts
    FROM (
        SELECT 
            line_charges_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY line_charges_key, modifyts ORDER BY line_charges_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_line_charges
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_line_charges
select * from raw.raw_ORDER_line_charges_temp
qualify ROW_NUMBER() OVER (PARTITION BY line_charges_key, modifyts ORDER BY line_charges_key, modifyts, processing_status DESC)=1;

--raw_ORDER_header

create or replace temporary table raw.raw_ORDER_header_temp as 
select * from  raw.raw_ORDER_header
WHERE (ORDER_HEADER_KEY, modifyts) IN (
    SELECT ORDER_HEADER_KEY, modifyts
    FROM (
        SELECT 
            ORDER_HEADER_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_HEADER_KEY, modifyts ORDER BY ORDER_HEADER_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_header
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_header
WHERE (ORDER_HEADER_KEY, modifyts) IN (
    SELECT ORDER_HEADER_KEY, modifyts
    FROM (
        SELECT 
            ORDER_HEADER_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_HEADER_KEY, modifyts ORDER BY ORDER_HEADER_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_header
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_header
select * from raw.raw_ORDER_header_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_HEADER_KEY, modifyts ORDER BY ORDER_HEADER_KEY, modifyts, processing_status DESC)=1;


--raw_ORDER_line
create or replace temporary table raw.raw_ORDER_line_temp as 
select * FROM raw.raw_ORDER_line
WHERE (ORDER_LINE_KEY, modifyts) IN (
    SELECT ORDER_LINE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_LINE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_LINE_KEY, modifyts ORDER BY ORDER_LINE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_line
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_line
WHERE (ORDER_LINE_KEY, modifyts) IN (
    SELECT ORDER_LINE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_LINE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_LINE_KEY, modifyts ORDER BY ORDER_LINE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_line
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_line
select * from raw.raw_ORDER_line_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_LINE_KEY, modifyts ORDER BY ORDER_LINE_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_release_status

create or replace temporary table raw.raw_ORDER_release_status_temp
 as select * FROM raw.raw_ORDER_release_status
WHERE (ORDER_RELEASE_STATUS_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_STATUS_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_STATUS_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release_status
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_release_status
WHERE (ORDER_RELEASE_STATUS_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_STATUS_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_STATUS_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release_status
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);


insert into raw.raw_ORDER_release_status
select * from raw.raw_ORDER_release_status_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_release_status_part2

create or replace temporary table raw.raw_ORDER_release_status_part2_temp
 as select * FROM raw.raw_ORDER_release_status_part2
WHERE (ORDER_RELEASE_STATUS_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_STATUS_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_STATUS_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release_status_part2
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_release_status_part2
WHERE (ORDER_RELEASE_STATUS_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_STATUS_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_STATUS_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release_status_part2
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_release_status_part2
select * from raw.raw_ORDER_release_status_part2_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_release

create or replace temporary table raw.raw_ORDER_release_temp
 as select * FROM raw.raw_ORDER_release
WHERE (ORDER_RELEASE_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_KEY, modifyts ORDER BY ORDER_RELEASE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_release
WHERE (ORDER_RELEASE_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_KEY, modifyts ORDER BY ORDER_RELEASE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_release
select * from raw.raw_ORDER_release_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_KEY, modifyts ORDER BY ORDER_RELEASE_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_payment

create or replace temporary table raw.raw_ORDER_payment_temp 
 as select * FROM raw.raw_ORDER_payment
WHERE (payment_key, modifyts) IN (
    SELECT payment_key, modifyts
    FROM (
        SELECT 
            payment_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY payment_key, modifyts ORDER BY payment_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_payment
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_payment
WHERE (payment_key, modifyts) IN (
    SELECT payment_key, modifyts
    FROM (
        SELECT 
            payment_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY payment_key, modifyts ORDER BY payment_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_payment
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_payment
select * from raw.raw_ORDER_payment_temp
qualify ROW_NUMBER() OVER (PARTITION BY payment_key, modifyts ORDER BY payment_key, modifyts, processing_status DESC)=1;

--raw_ORDER_person_info

create or replace temporary table raw.raw_ORDER_person_info_temp 
 as select * FROM raw.raw_ORDER_person_info
WHERE (person_info_key, modifyts) IN (
    SELECT person_info_key, modifyts
    FROM (
        SELECT 
            person_info_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_person_info
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_person_info
WHERE (person_info_key, modifyts) IN (
    SELECT person_info_key, modifyts
    FROM (
        SELECT 
            person_info_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_person_info
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_person_info
select * from raw.raw_ORDER_person_info_temp 
qualify ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC)=1;

--raw_ORDER_shipment_container

create or replace temporary table raw.raw_ORDER_shipment_container_temp 
 as select * FROM raw.raw_ORDER_shipment_container
WHERE (shipment_container_key, modifyts) IN (
    SELECT shipment_container_key, modifyts
    FROM (
        SELECT 
            shipment_container_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_container_key, modifyts ORDER BY shipment_container_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment_container
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_shipment_container
WHERE (shipment_container_key, modifyts) IN (
    SELECT shipment_container_key, modifyts
    FROM (
        SELECT 
            shipment_container_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_container_key, modifyts ORDER BY shipment_container_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment_container
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_shipment_container
select * from raw.raw_ORDER_shipment_container_temp
qualify ROW_NUMBER() OVER (PARTITION BY shipment_container_key, modifyts ORDER BY shipment_container_key, modifyts, processing_status DESC)=1;

--raw_ORDER_shipment_line

create or replace temporary table raw.raw_ORDER_shipment_line_temp
 as select * FROM raw.raw_ORDER_shipment_line
WHERE (shipment_line_key, modifyts) IN (
    SELECT shipment_line_key, modifyts
    FROM (
        SELECT 
            shipment_line_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_line_key, modifyts ORDER BY shipment_line_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment_line
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_shipment_line
WHERE (shipment_line_key, modifyts) IN (
    SELECT shipment_line_key, modifyts
    FROM (
        SELECT 
            shipment_line_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_line_key, modifyts ORDER BY shipment_line_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment_line
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_shipment_line
select * from raw.raw_ORDER_shipment_line_temp
qualify ROW_NUMBER() OVER (PARTITION BY shipment_line_key, modifyts ORDER BY shipment_line_key, modifyts, processing_status DESC)=1;

--raw_ORDER_shipment

create or replace temporary table raw.raw_ORDER_shipment_temp 
 as select * FROM raw.raw_ORDER_shipment
WHERE (shipment_key, modifyts) IN (
    SELECT shipment_key, modifyts
    FROM (
        SELECT 
            shipment_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_key, modifyts ORDER BY shipment_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_shipment
WHERE (shipment_key, modifyts) IN (
    SELECT shipment_key, modifyts
    FROM (
        SELECT 
            shipment_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_key, modifyts ORDER BY shipment_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);


insert into raw.raw_ORDER_shipment
select * from raw.raw_ORDER_shipment_temp
qualify ROW_NUMBER() OVER (PARTITION BY shipment_key, modifyts ORDER BY shipment_key, modifyts, processing_status DESC)=1;

--raw_ORDER_audit

create or replace temporary table raw.raw_ORDER_audit_temp
 as select * FROM raw.raw_ORDER_audit
WHERE (ORDER_AUDIT_KEY, modifyts) IN (
    SELECT ORDER_AUDIT_KEY, modifyts
    FROM (
        SELECT 
            ORDER_AUDIT_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_KEY, modifyts ORDER BY ORDER_AUDIT_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_audit
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

delete FROM raw.raw_ORDER_audit
WHERE (ORDER_AUDIT_KEY, modifyts) IN (
    SELECT ORDER_AUDIT_KEY, modifyts
    FROM (
        SELECT 
            ORDER_AUDIT_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_KEY, modifyts ORDER BY ORDER_AUDIT_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_audit
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_audit
select * from raw.raw_ORDER_audit_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_KEY, modifyts ORDER BY ORDER_AUDIT_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_audit_level


create or replace temporary table raw.raw_ORDER_audit_level_temp 
 as select * FROM raw.raw_ORDER_audit_level
WHERE (ORDER_AUDIT_LEVEL_KEY, modifyts) IN (
    SELECT ORDER_AUDIT_LEVEL_KEY, modifyts
    FROM (
        SELECT 
            ORDER_AUDIT_LEVEL_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_LEVEL_KEY, modifyts ORDER BY ORDER_AUDIT_LEVEL_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_audit_level
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_audit_level
WHERE (ORDER_AUDIT_LEVEL_KEY, modifyts) IN (
    SELECT ORDER_AUDIT_LEVEL_KEY, modifyts
    FROM (
        SELECT 
            ORDER_AUDIT_LEVEL_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_LEVEL_KEY, modifyts ORDER BY ORDER_AUDIT_LEVEL_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_audit_level
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_audit_level
select * from raw.raw_ORDER_audit_level_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_LEVEL_KEY, modifyts ORDER BY ORDER_AUDIT_LEVEL_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_hold_type

create or replace temporary table raw.raw_ORDER_hold_type_temp
 as select * FROM raw.raw_ORDER_hold_type
WHERE (ORDER_HOLD_TYPE_KEY, modifyts) IN (
    SELECT ORDER_HOLD_TYPE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_HOLD_TYPE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_HOLD_TYPE_KEY, modifyts ORDER BY ORDER_HOLD_TYPE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_hold_type
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_hold_type
WHERE (ORDER_HOLD_TYPE_KEY, modifyts) IN (
    SELECT ORDER_HOLD_TYPE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_HOLD_TYPE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_HOLD_TYPE_KEY, modifyts ORDER BY ORDER_HOLD_TYPE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_hold_type
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);
insert into raw.raw_ORDER_hold_type
select distinct * from raw.raw_ORDER_hold_type_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_HOLD_TYPE_KEY, modifyts ORDER BY ORDER_HOLD_TYPE_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_invoice

create or replace temporary table raw.raw_ORDER_invoice_temp
 as select * FROM raw.raw_ORDER_invoice
WHERE (ORDER_INVOICE_KEY, modifyts) IN (
    SELECT ORDER_INVOICE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_INVOICE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_INVOICE_KEY, modifyts ORDER BY ORDER_INVOICE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_invoice
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_invoice
WHERE (ORDER_INVOICE_KEY, modifyts) IN (
    SELECT ORDER_INVOICE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_INVOICE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_INVOICE_KEY, modifyts ORDER BY ORDER_INVOICE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_invoice
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_invoice
select distinct * from raw.raw_ORDER_invoice_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_INVOICE_KEY, modifyts ORDER BY ORDER_INVOICE_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_notes

create or replace temporary table raw.raw_ORDER_notes_temp
 as select * FROM raw.raw_ORDER_notes
WHERE (NOTES_KEY, modifyts) IN (
    SELECT NOTES_KEY, modifyts
    FROM (
        SELECT 
            NOTES_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY NOTES_KEY, modifyts ORDER BY NOTES_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_notes
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_notes
WHERE (NOTES_KEY, modifyts) IN (
    SELECT NOTES_KEY, modifyts
    FROM (
        SELECT 
            NOTES_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY NOTES_KEY, modifyts ORDER BY NOTES_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_notes
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_notes
select distinct * from raw.raw_ORDER_notes_temp
qualify ROW_NUMBER() OVER (PARTITION BY NOTES_KEY, modifyts ORDER BY NOTES_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_tax_breakup

create or replace temporary table raw.raw_ORDER_tax_breakup_temp
 as select * FROM raw.raw_ORDER_tax_breakup
WHERE (TAX_BREAKUP_KEY, modifyts) IN (
    SELECT TAX_BREAKUP_KEY, modifyts
    FROM (
        SELECT 
            TAX_BREAKUP_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY TAX_BREAKUP_KEY, modifyts ORDER BY TAX_BREAKUP_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_tax_breakup
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_tax_breakup
WHERE (TAX_BREAKUP_KEY, modifyts) IN (
    SELECT TAX_BREAKUP_KEY, modifyts
    FROM (
        SELECT 
            TAX_BREAKUP_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY TAX_BREAKUP_KEY, modifyts ORDER BY TAX_BREAKUP_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_tax_breakup
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_tax_breakup
select  * from raw.raw_ORDER_tax_breakup_temp
qualify  ROW_NUMBER() OVER (PARTITION BY TAX_BREAKUP_KEY, modifyts ORDER BY TAX_BREAKUP_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_customer_person_info

create or replace temporary table raw.raw_ORDER_customer_person_info_temp
 as select * FROM raw.raw_ORDER_customer_person_info
WHERE (person_info_key, modifyts) IN (
    SELECT person_info_key, modifyts
    FROM (
        SELECT 
            person_info_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_customer_person_info
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

delete FROM raw.raw_ORDER_customer_person_info
WHERE (person_info_key, modifyts) IN (
    SELECT person_info_key, modifyts
    FROM (
        SELECT 
            person_info_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_customer_person_info
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_customer_person_info
select  * from raw.raw_ORDER_customer_person_info_temp
qualify ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC)=1;

--raw_ORDER_charge_transaction

create or replace temporary table raw.raw_ORDER_charge_transaction_temp
 as select * FROM raw.raw_ORDER_charge_transaction
WHERE (charge_transaction_key, modifyts) IN (
    SELECT charge_transaction_key, modifyts
    FROM (
        SELECT 
            charge_transaction_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY charge_transaction_key, modifyts ORDER BY charge_transaction_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_charge_transaction
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_charge_transaction
WHERE (charge_transaction_key, modifyts) IN (
    SELECT charge_transaction_key, modifyts
    FROM (
        SELECT 
            charge_transaction_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY charge_transaction_key, modifyts ORDER BY charge_transaction_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_charge_transaction
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_charge_transaction
select * from raw.raw_ORDER_charge_transaction_temp
qualify ROW_NUMBER() OVER (PARTITION BY charge_transaction_key, modifyts ORDER BY charge_transaction_key, modifyts, processing_status DESC)=1;


 RETURN ''usp_ORDER_clean_duplicate_raw_entries executed successfully'';
END';
CREATE PROCEDURE "USP_ORDER_CONTAINER_DETAILS_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE analytics.log_files_import_status
SET processed = :processedRecordCount,
    raw_table = ''raw_ORDER_container_details''
WHERE file_name = ''YFS_CONTAINER_DETAILS'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE insertedContainerDetailsRecords (
    container_details_key STRING,
    order_release_key STRING,
    order_release_status_key STRING,
    shipment_container_key STRING,
    order_line_key STRING,
    order_header_key STRING,
    shipment_key STRING,
    shipment_line_key STRING,
    country_of_origin STRING,
    item_id STRING,
    uom STRING,
    product_class STRING,
    quantity NUMBER,
    quantity_placed NUMBER,
    enterprise_key STRING,
    orig_order_line_schedule_key STRING,
    fifo_no STRING,
    lockid STRING,
    createts TIMESTAMP_NTZ(9),
    modifyts TIMESTAMP_NTZ(9),
    createuserid STRING,
    modifyuserid STRING,
    createprogid STRING,
    modifyprogid STRING,
    extn_upc_item_id STRING,
    imported_date TIMESTAMP_NTZ(9),
    txn_id STRING,
    inserted_date TIMESTAMP_NTZ(9),
    modified_date TIMESTAMP_NTZ(9),
    revision INT
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO   ANALYTICS.txn_order_container_details tcd
USING (
  SELECT DISTINCT 
    container_details_key,
    order_release_key,
    order_release_status_key,
    shipment_container_key,
    order_line_key,
    order_header_key,
    shipment_key,
    shipment_line_key,
    country_of_origin,
    item_id,
    uom,
    product_class,
    TRY_TO_NUMBER(quantity) AS quantity,
    TRY_TO_NUMBER(quantity_placed) AS quantity_placed,
    enterprise_key,
    orig_order_line_schedule_key,
    fifo_no,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    extn_upc_item_id,
    txn_id
  FROM TRANSFORMED.stg_ORDER_container_details
) scd
ON (
  tcd.container_details_key = scd.container_details_key AND
  tcd.shipment_container_key = scd.shipment_container_key AND
  tcd.shipment_key = scd.shipment_key AND
  tcd.shipment_line_key = scd.shipment_line_key AND
  tcd.order_header_key = scd.order_header_key AND
  tcd.order_line_key = scd.order_line_key
)
WHEN MATCHED THEN
  UPDATE 
    SET tcd.container_details_key  = scd.container_details_key    
   ,tcd.order_release_key  = scd.order_release_key    
   ,tcd.order_release_status_key  = scd.order_release_status_key    
   ,tcd.shipment_container_key  = scd.shipment_container_key    
   ,tcd.order_line_key  = scd.order_line_key    
   ,tcd.order_header_key  = scd.order_header_key    
   ,tcd.shipment_key  = scd.shipment_key    
   ,tcd.shipment_line_key  = scd.shipment_line_key    
   ,tcd.country_of_origin  = scd.country_of_origin    
   ,tcd.item_id  = scd.item_id    
   ,tcd.uom  = scd.uom    
   ,tcd.product_class  = scd.product_class    
   ,tcd.quantity  = scd.quantity    
   ,tcd.quantity_placed  = scd.quantity_placed    
   ,tcd.enterprise_key  = scd.enterprise_key    
   ,tcd.orig_order_line_schedule_key  = scd.orig_order_line_schedule_key    
   ,tcd.fifo_no  = scd.fifo_no    
   ,tcd.lockid  = scd.lockid    
   ,tcd.createts  = TRY_TO_TIMESTAMP(scd.createts,''YYYYMMDDHHMISS'')
   ,tcd.modifyts  = TRY_TO_TIMESTAMP(scd.modifyts,''YYYYMMDDHHMISS'')    
   ,tcd.createuserid  = scd.createuserid    
   ,tcd.modifyuserid  = scd.modifyuserid    
   ,tcd.createprogid  = scd.createprogid    
   ,tcd.modifyprogid  = scd.modifyprogid    
   ,tcd.extn_upc_item_id = scd.extn_upc_item_id,  
    tcd.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
  INSERT (
    container_details_key,
    order_release_key,
    order_release_status_key,
    shipment_container_key,
    order_line_key,
    order_header_key,
    shipment_key,
    shipment_line_key,
    country_of_origin,
    item_id,
    uom,
    product_class,
    quantity,
    quantity_placed,
    enterprise_key,
    orig_order_line_schedule_key,
    fifo_no,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    extn_upc_item_id,
    inserted_date
  )
  VALUES (
    scd.container_details_key,
    scd.order_release_key,
    scd.order_release_status_key,
    scd.shipment_container_key,
    scd.order_line_key,
    scd.order_header_key,
    scd.shipment_key,
    scd.shipment_line_key,
    scd.country_of_origin,
    scd.item_id,
    scd.uom,
    scd.product_class,
    scd.quantity,
    scd.quantity_placed,
    scd.enterprise_key,
    scd.orig_order_line_schedule_key,
    scd.fifo_no,
    scd.lockid,
    TRY_TO_TIMESTAMP(scd.createts,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(scd.modifyts,''YYYYMMDDHHMISS''),
    scd.createuserid,
    scd.modifyuserid,
    scd.createprogid,
    scd.modifyprogid,
    scd.extn_upc_item_id,
    CURRENT_TIMESTAMP()
);

INSERT INTO insertedContainerDetailsRecords (
    container_details_key,
    order_release_key,
    order_release_status_key,
    shipment_container_key,
    order_line_key,
    order_header_key,
    shipment_key,
    shipment_line_key,
    country_of_origin,
    item_id,
    uom,
    product_class,
    quantity,
    quantity_placed,
    enterprise_key,
    orig_order_line_schedule_key,
    fifo_no,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    extn_upc_item_id,
    imported_date,
    txn_id,
    inserted_date,
    modified_date,
    revision
)
SELECT DISTINCT 
    tcd.container_details_key,
    tcd.order_release_key,
    tcd.order_release_status_key,
    tcd.shipment_container_key,
    tcd.order_line_key,
    tcd.order_header_key,
    tcd.shipment_key,
    tcd.shipment_line_key,
    tcd.country_of_origin,
    tcd.item_id,
    tcd.uom,
    tcd.product_class,
    tcd.quantity,
    tcd.quantity_placed,
    tcd.enterprise_key,
    tcd.orig_order_line_schedule_key,
    tcd.fifo_no,
    tcd.lockid,
    TRY_TO_TIMESTAMP(scd.createts,''YYYYMMDDHHMISS'') AS createts,
    TRY_TO_TIMESTAMP(scd.modifyts,''YYYYMMDDHHMISS'') AS modifyts,
    tcd.createuserid,
    tcd.modifyuserid,
    tcd.createprogid,
    tcd.modifyprogid,
    tcd.extn_upc_item_id,
    scd.imported_date,
    scd.txn_id,
    tcd.inserted_date,
    tcd.modified_date,
    1 as revision
FROM ANALYTICS.txn_order_container_details tcd
    INNER JOIN TRANSFORMED.stg_ORDER_container_details scd
        on   tcd.container_details_key = scd.container_details_key AND
      tcd.shipment_container_key = scd.shipment_container_key AND
      tcd.shipment_key = scd.shipment_key AND
      tcd.shipment_line_key = scd.shipment_line_key AND
      tcd.order_header_key = scd.order_header_key AND
      tcd.order_line_key = scd.order_line_key
WHERE tcd.inserted_date >= :processedDate or tcd.modified_date >= :processedDate
;

MERGE INTO insertedContainerDetailsRecords AS ttd
USING (
    SELECT
        MAX(aot.revision) AS revision,
        aot.container_details_key,
        aot.shipment_key,
        aot.shipment_line_key,
        aot.shipment_container_key,
        aot.order_header_key,
        aot.order_line_key
    FROM ANALYTICS.audit_order_container_details AS aot
    GROUP BY
        aot.container_details_key,
        aot.shipment_key,
        aot.shipment_line_key,
        aot.shipment_container_key,
        aot.order_header_key,
        aot.order_line_key
) AS aot
ON ttd.container_details_key = aot.container_details_key
AND ttd.shipment_key = aot.shipment_key
AND ttd.shipment_line_key = aot.shipment_line_key
AND ttd.shipment_container_key = aot.shipment_container_key
AND ttd.order_header_key = aot.order_header_key
AND ttd.order_line_key = aot.order_line_key
WHEN MATCHED THEN
UPDATE SET ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS int);

INSERT INTO  ANALYTICS.audit_order_container_details (
  container_details_key,
  order_release_key,
  order_release_status_key,
  shipment_container_key,
  order_line_key,
  order_header_key,
  shipment_key,
  shipment_line_key,
  country_of_origin,
  item_id,
  uom,
  product_class,
  quantity,
  quantity_placed,
  enterprise_key,
  orig_order_line_schedule_key,
  fifo_no,
  lockid,
  createts,
  modifyts,
  createuserid,
  modifyuserid,
  createprogid,
  modifyprogid,
  extn_upc_item_id,
  inserted_date,
  revision
)
SELECT
  scd.container_details_key,
  scd.order_release_key,
  scd.order_release_status_key,
  scd.shipment_container_key,
  scd.order_line_key,
  scd.order_header_key,
  scd.shipment_key,
  scd.shipment_line_key,
  scd.country_of_origin,
  scd.item_id,
  scd.uom,
  scd.product_class,
  scd.quantity,
  scd.quantity_placed,
  scd.enterprise_key,
  scd.orig_order_line_schedule_key,
  scd.fifo_no,
  scd.lockid,
  scd.createts,
  scd.modifyts,
  scd.createuserid,
  scd.modifyuserid,
  scd.createprogid,
  scd.modifyprogid,
  scd.extn_upc_item_id,
  CURRENT_TIMESTAMP, -- GETDATE() equivalent in Snowflake
  scd.revision
FROM insertedContainerDetailsRecords scd;

-- UPDATE table  RAW.raw_ORDER_container_details
-- SET 
--     processing_status = ''Processed'',
--     processing_comment = '''',
--     processing_errortype = ''''
-- WHERE EXISTS (
--     SELECT 1
--     FROM insertedContainerDetailsRecords tocd
--     WHERE 
--         tocd.container_details_key = RAW.raw_ORDER_container_details.container_details_key AND
--         tocd.shipment_key = RAW.raw_ORDER_container_details.shipment_key AND
--         tocd.shipment_line_key = RAW.raw_ORDER_container_details.shipment_line_key AND
--         tocd.shipment_container_key = RAW.raw_ORDER_container_details.shipment_container_key AND
--         tocd.order_header_key = RAW.raw_ORDER_container_details.order_header_key AND
--         tocd.order_line_key = RAW.raw_ORDER_container_details.order_line_key AND
--         tocd.modifyts = RAW.raw_ORDER_container_details.modifyts
-- );

MERGE INTO RAW.raw_ORDER_container_details AS target
USING insertedContainerDetailsRecords AS source
ON target.container_details_key = source.container_details_key 
    AND target.shipment_key = source.shipment_key
    AND target.shipment_line_key = source.shipment_line_key
    AND target.shipment_container_key = source.shipment_container_key
    AND target.order_header_key = source.order_header_key
    AND target.order_line_key = source.order_line_key
    AND TRY_TO_TIMESTAMP(target.modifyts,''YYYYMMDDHHMISS'') = source.modifyts
WHEN MATCHED THEN 
    UPDATE SET 
        target.processing_status = ''Processed'',
        target.processing_comment = '''',
        target.processing_errortype = '''';



SELECT COUNT(*)
INTO :processedRecordCount
FROM insertedContainerDetailsRecords;

UPDATE ANALYTICS.log_files_import_status
SET 
  processed = :processedRecordCount,
  status = ''Success''
WHERE 
  file_name = ''YFS_CONTAINER_DETAILS'';

DROP TABLE IF EXISTS insertedContainerDetailsRecords;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;
RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_CONTAINER_DETAILS'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
CREATE PROCEDURE "USP_ORDER_CUSTOMER_INFO_POPULATE"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
 error_object VARIANT;
 start_time_proc TIMESTAMP_NTZ(9);
 
BEGIN

start_time_proc := CURRENT_TIMESTAMP();

SYSTEM$LOG(''TRACE'','' USP_ORDER_CUSTOMER_INFO_POPULATE has been Started'');
CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        CURRENT_TIMESTAMP(),
        NULL,
        ''upsert started''
    );

create or replace temporary table analytics.CreateCustomerPersonInfoMatch
(
order_no varchar(200) not null,
order_header_key varchar(500) not null,
order_type varchar(100) not null,
entry_type varchar(100) not null,
ship_to_key varchar not null,
fk_sourceid int not null,
source varchar(100) null
);

insert into analytics.CreateCustomerPersonInfoMatch
(
order_no ,
order_header_key ,
order_type ,
entry_type ,
ship_to_key ,
fk_sourceid,
source
)
select 
distinct 
ord.order_no,
ord.order_header_key,
ord.order_type ,
ord.entry_type,
ord.ship_to_key ,
src.pk_sourceid,
case WHEN src.BrandId = 1
     then ''domestic''
	 else null
	 end
from raw.raw_order_header as ord
INNER JOIN  MASTER.entrytype_platform_map as pl on pl.entry_type = ord.ENTRY_TYPE and pl.Order_Type = ord.Order_Type
INNER JOIN MASTER.source_brand_platform_map AS src ON src.BrandCodeForWHM = analytics.fun_get_edw_brand_by_order_sellerorgcode(ord.SELLER_ORGANIZATION_CODE) AND src.PlatformName = nvl(pl.customer_platform_name,pl.platform_name)
       where  extn_customer_id is null   and  (order_name is null or order_name =''EXTEND_CANCEL'') and pl.customer_source = ''Person Info'';

insert into raw.raw_order_customer_person_info (
person_info_key	,
person_id	,
title	,
first_name	,
middle_name	,
last_name	,
suffix	,
department	,
company	,
job_title	,
address_line1	,
address_line2	,
address_line3	,
address_line4	,
address_line5	,
address_line6	,
city	,
state	,
zip_code	,
country	,
day_phone	,
evening_phone	,
mobile_phone	,
beeper	,
other_phone	,
day_fax_no	,
evening_fax_no	,
emailid	,
alternate_emailid	,
preferred_ship_address	,
http_url	,
use_count	,
verification_status	,
is_address_verified	,
latitude	,
longitude	,
tax_geo_code	,
error_txt	,
is_commercial_address	,
time_zone	,
lockid	,
createts	,
modifyts	,
createuserid	,
modifyuserid	,
createprogid	,
modifyprogid	,
address_id	,
short_zip_code	,
imported_date	,
txn_id	,
processing_status	,
processing_errortype	,
processing_comment	,
fk_sourceid,
source

)
select distinct

rpi.person_info_key	,
rpi.person_id	,
rpi.title	,
rpi.first_name	,
rpi.middle_name	,
rpi.last_name	,
rpi.suffix	,
rpi.department	,
rpi.company	,
rpi.job_title	,
rpi.address_line1	,
rpi.address_line2	,
rpi.address_line3	,
rpi.address_line4	,
rpi.address_line5	,
rpi.address_line6	,
rpi.city	,
rpi.state	,
rpi.zip_code	,
rpi.country	,
rpi.day_phone	,
rpi.evening_phone	,
rpi.mobile_phone	,
rpi.beeper	,
rpi.other_phone	,
rpi.day_fax_no	,
rpi.evening_fax_no	,
rpi.emailid	,
rpi.alternate_emailid	,
rpi.preferred_ship_address	,
rpi.http_url	,
rpi.use_count	,
rpi.verification_status	,
rpi.is_address_verified	,
rpi.latitude	,
rpi.longitude	,
rpi.tax_geo_code	,
rpi.error_txt	,
rpi.is_commercial_address	,
rpi.time_zone	,
rpi.lockid	,
rpi.createts	,
rpi.modifyts	,
rpi.createuserid	,
rpi.modifyuserid	,
rpi.createprogid	,
rpi.modifyprogid	,
rpi.address_id	,
rpi.short_zip_code	,
current_date,
''call-back-load-from-person-info-for-3rd-party''	,
''Pending''	,
null	,
null	,
tmp.fk_sourceid,
tmp.source

from raw.raw_order_person_info as rpi
INNER JOIN analytics.CreateCustomerPersonInfoMatch as tmp on tmp.ship_to_key = rpi.person_info_key;

insert into raw.raw_order_customer_person_info (
person_info_key	,
person_id	,
title	,
first_name	,
middle_name	,
last_name	,
suffix	,
department	,
company	,
job_title	,
address_line1	,
address_line2	,
address_line3	,
address_line4	,
address_line5	,
address_line6	,
city	,
state	,
zip_code	,
country	,
day_phone	,
evening_phone	,
mobile_phone	,
beeper	,
other_phone	,
day_fax_no	,
evening_fax_no	,
emailid	,
alternate_emailid	,
preferred_ship_address	,
http_url	,
use_count	,
verification_status	,
is_address_verified	,
latitude	,
longitude	,
tax_geo_code	,
error_txt	,
is_commercial_address	,
time_zone	,
lockid	,
createts	,
modifyts	,
createuserid	,
modifyuserid	,
createprogid	,
modifyprogid	,
address_id	,
short_zip_code	,
imported_date	,
txn_id	,
processing_status	,
processing_errortype	,
processing_comment	,
fk_sourceid,
source

)
select distinct

rpi.person_info_key	,
rpi.person_id	,
rpi.title	,
rpi.first_name	,
rpi.middle_name	,
rpi.last_name	,
rpi.suffix	,
rpi.department	,
rpi.company	,
rpi.job_title	,
rpi.address_line1	,
rpi.address_line2	,
rpi.address_line3	,
rpi.address_line4	,
rpi.address_line5	,
rpi.address_line6	,
rpi.city	,
rpi.state	,
rpi.zip_code	,
rpi.country	,
rpi.day_phone	,
rpi.evening_phone	,
rpi.mobile_phone	,
rpi.beeper	,
rpi.other_phone	,
rpi.day_fax_no	,
rpi.evening_fax_no	,
rpi.emailid	,
rpi.alternate_emailid	,
rpi.preferred_ship_address	,
rpi.http_url	,
rpi.use_count	,
rpi.verification_status	,
rpi.is_address_verified	,
rpi.latitude	,
rpi.longitude	,
rpi.tax_geo_code	,
rpi.error_txt	,
rpi.is_commercial_address	,
rpi.time_zone	,
rpi.lockid	,
rpi.createts	,
rpi.modifyts	,
rpi.createuserid	,
rpi.modifyuserid	,
rpi.createprogid	,
rpi.modifyprogid	,
rpi.address_id	,
rpi.short_zip_code	,
current_date,
''call-back-load-from-person-info-for-3rd-party''	,
''Pending''	,
null	,
null	,
tmp.fk_sourceid,
tmp.source

from archive.arc_raw_order_person_info as rpi
INNER JOIN analytics.CreateCustomerPersonInfoMatch as tmp on tmp.ship_to_key = rpi.person_info_key;

drop table analytics.CreateCustomerPersonInfoMatch;

COMMIT;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''upsert completed successfully''
    );
    SYSTEM$LOG(''TRACE'','' USP_ORDER_CUSTOMER_INFO_POPULATE has been Completed'');
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);
    
        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_LINE has Failed'');
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDER_CUSTOMER_PERSON_INFO_INSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    warningCount NUMBER DEFAULT 0;
    customerCount NUMBER DEFAULT 0;
    customerParentID TEXT;
    customerID TEXT;
    domesticSource TEXT DEFAULT ''domestic'';
    internationalSource TEXT DEFAULT ''international'';
    processedRecordCount NUMBER DEFAULT 0;
    finalStatus INT DEFAULT 0;
    currentDate TIMESTAMP;
    message TEXT;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 
start_time_proc := CURRENT_TIMESTAMP();
SYSTEM$LOG(''TRACE'','' USP_ORDER_CUSTOMER_PERSON_INFO_INSERT has been Started'');
CREATE OR REPLACE TEMPORARY TABLE DuplicateResultToLog (
    stagesourceref STRING,    
    custid STRING
);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''insert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );


UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount
WHERE file_name = ''INTR_CUSTOMER_INFO'';

SELECT COUNT(*) INTO :CustomerCount FROM TRANSFORMED.stg_customer_person_info;

IF (CustomerCount > 0) THEN
    INSERT INTO DuplicateResultToLog (stagesourceref, custid)
    SELECT stg.SourceRefNum, cust.pk_customerid
    FROM TRANSFORMED.stg_customer_person_info AS stg
    LEFT JOIN ANALYTICS.customer AS cust ON stg.SourceRefNum = cust.source_ref_num
        AND stg.SourceID = cust.fk_sourceid;
END IF;

SELECT COUNT(*)
INTO :WarningCount
FROM DuplicateResultToLog
WHERE stagesourceref IS NOT NULL AND custid IS NOT NULL; 

IF (WarningCount > 0) THEN
    -- Update records
    MERGE INTO RAW.raw_order_customer_person_info roh
            USING (
                SELECT roh.person_info_key, roh.fk_sourceid
                FROM RAW.raw_order_customer_person_info roh
                INNER JOIN TRANSFORMED.stg_order_customer_person_info stg 
                    ON stg.person_info_key = roh.person_info_key
                INNER JOIN DuplicateResultToLog toh 
                    ON toh.stagesourceref = roh.person_info_key 
                    AND stg.fk_sourceid = roh.fk_sourceid
                WHERE roh.processing_status IN (''Pending'', ''Failed'') 
                    AND toh.stagesourceref IS NOT NULL 
                    AND toh.custid IS NOT NULL
            ) src
            ON roh.person_info_key = src.person_info_key
            AND roh.fk_sourceid = src.fk_sourceid
            WHEN MATCHED THEN
                UPDATE SET 
                    roh.processing_status = ''Rejected'',
                    roh.processing_comment = ''Customer already exist'',
                    roh.processing_errortype = '''';

    
    message := ''WARNING: '' || WarningCount::STRING || '' Customer already exist'';
    RETURN message;
ELSE
    BEGIN
        CREATE OR REPLACE TEMPORARY TABLE CustomerApiCount (
            pk_customerid INT,
            source_ref_num STRING NOT NULL,
            fk_sourceid INT NOT NULL
        );

        

        CREATE OR REPLACE TEMPORARY TABLE tempBPApiCustomer AS
        SELECT
            cust.*, src.pk_sourceid, custtype.pk_customer_typeid
        FROM TRANSFORMED.stg_customer_person_info AS cust
        INNER JOIN master.dim_SOURCE AS src
            ON cust.SourceID = src.pk_sourceid
        INNER JOIN  master.dim_customer_type AS custtype
            ON cust.CustomerType = custtype.customer_type
        LEFT JOIN ANALYTICS.customer AS dimcust
            ON dimcust.source_ref_num = cust.SourceRefNum
            AND dimcust.fk_sourceid = src.pk_sourceid
        WHERE dimcust.pk_customerid IS NULL
            AND src.pk_sourceid IS NOT NULL
            AND validation_Status = 1;

INSERT INTO ANALYTICS.audit_customer (
    fk_sourceid,
    source_ref_num,
    ext_customer_id,
    is_domestic,
    fk_customer_typeid,
    inserted_date,
    city,
    first_name,
    last_name,
    company_name,
    address1,
    address2,
    state,
    country,
    postal_code,
    email_address,
    phone,
    is_tax_exempt,
    email_subscriber,
    catalog_subscriber
)
SELECT 
    bpcust.pk_sourceid,
    bpcust.SourceRefNum,
    bpcust.ID,
    CASE 
        WHEN source = :domesticSource THEN 1
        ELSE 0
    END,
    bpcust.pk_customer_typeid,
    :currentdate,
    '''',
    bpcust.FirstName,
    bpcust.LastName,
    bpcust.CompanyName,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    bpcust.EmailAddress,
    bpcust.PhoneNumber,
    CASE 
        WHEN LOWER(bpcust.TaxExemptAccount) = ''true'' THEN 1
        ELSE 0
    END AS is_tax_exempt,
    CASE 
        WHEN LOWER(bpcust.EmailSubscriber) = ''true'' THEN 1
        ELSE 0
    END AS email_subscriber,
    CASE 
        WHEN LOWER(bpcust.CatalogSubscriber) = ''true'' THEN 1
        ELSE 0
    END AS catalog_subscriber
FROM tempBPApiCustomer AS bpcust
LEFT JOIN ANALYTICS.audit_customer AS audcust 
    ON bpcust.SourceRefNum = audcust.source_ref_num 
    AND bpcust.pk_sourceid = audcust.fk_sourceid
WHERE audcust.source_ref_num IS NULL 
    AND audcust.fk_sourceid IS NULL;

CREATE OR REPLACE TEMPORARY TABLE tempApiCustomers AS
SELECT
    cust.*,
    0 AS IsBP
FROM
    tempBPApiCustomer cust;

-- Create a temporary table to hold deduplicated results
CREATE TEMPORARY TABLE tempDedupedApiCustomers AS
SELECT * 
FROM (
    SELECT 
        *,
        ROW_NUMBER() OVER (PARTITION BY SourceRefNum, pk_sourceid, pk_customer_typeid ORDER BY SourceRefNum, pk_sourceid, pk_customer_typeid) AS rn
    FROM tempApiCustomers
)
WHERE rn = 1;



DROP TABLE tempApiCustomers;

ALTER TABLE tempDedupedApiCustomers RENAME TO tempApiCustomers;

MERGE INTO ANALYTICS.customer AS tgt
USING (
    SELECT DISTINCT 
        cust.pk_sourceid,
        cust.SourceRefNum,
        cust.ID,
        CASE 
            WHEN source = :domesticSource THEN 1
            ELSE 0
        END AS is_domestic,
        cust.pk_customer_typeid
    FROM tempApiCustomers AS cust
    LEFT JOIN ANALYTICS.customer AS dimcust 
        ON dimcust.source_ref_num = cust.SourceRefNum
        AND dimcust.fk_sourceid = cust.pk_sourceid
    WHERE dimcust.pk_customerid IS NULL
) AS src 
ON src.pk_sourceid = tgt.fk_sourceid 
    AND src.SourceRefNum = tgt.source_ref_num
WHEN MATCHED THEN 
    UPDATE SET 
        tgt.fk_customer_typeid = src.pk_customer_typeid,
        tgt.is_domestic = src.is_domestic
WHEN NOT MATCHED THEN 
    INSERT (
        fk_sourceid,
        source_ref_num,
        ext_customer_id,
        is_domestic,
        fk_customer_typeid
    )
    VALUES (
        src.pk_sourceid,
        src.SourceRefNum,
        src.ID,
        src.is_domestic,
        src.pk_customer_typeid
    );
    
INSERT INTO CustomerApiCount (
    pk_customerid,
    source_ref_num,
    fk_sourceid
)
SELECT 
    cust.pk_sourceid,
    cust.SourceRefNum,
    cust.ID
FROM 
    tempApiCustomers AS cust
LEFT JOIN 
    ANALYTICS.customer AS dimcust 
    ON dimcust.source_ref_num = cust.SourceRefNum
    AND dimcust.fk_sourceid = cust.pk_sourceid
WHERE 
    dimcust.pk_customerid IS NULL;
    
-- Added as part phone conversion by Divya Nalam - START

-- Add columns to the temporary table
ALTER TABLE tempApiCustomers ADD COLUMN PhoneNumber_E164 STRING;
ALTER TABLE tempApiCustomers ADD COLUMN Phone1_E164 STRING;
ALTER TABLE tempApiCustomers ADD COLUMN Phone2_E164 STRING;
ALTER TABLE tempApiCustomers ADD COLUMN Phone4_E164 STRING;

-- Update PhoneNumber_E164
UPDATE tempApiCustomers
SET PhoneNumber_E164 = ''+1'' || REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')) = 10
AND PhoneNumber NOT LIKE ''1%''
AND PhoneNumber NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET PhoneNumber_E164 = ''+'' || REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')) = 11
AND PhoneNumber LIKE ''1%''
AND PhoneNumber NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET PhoneNumber_E164 = REGEXP_REPLACE(SUBSTRING(PhoneNumber, 1, POSITION(''ext.'' IN PhoneNumber) - 1), ''[^0-9]'', '''')
WHERE LOWER(PhoneNumber) LIKE ''%ext.%''
AND PhoneNumber LIKE ''+1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(PhoneNumber, 1, POSITION(''ext.'' IN PhoneNumber) - 1), ''[^0-9]'', '''')) = 12
AND PhoneNumber IS NOT NULL;

UPDATE tempApiCustomers
SET PhoneNumber_E164 = ''+'' || REGEXP_REPLACE(SUBSTRING(PhoneNumber, 1, POSITION(''ext.'' IN PhoneNumber) - 1), ''[^0-9]'', '''')
WHERE LOWER(PhoneNumber) LIKE ''%ext.%''
AND PhoneNumber LIKE ''1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(PhoneNumber, 1, POSITION(''ext.'' IN PhoneNumber) - 1), ''[^0-9]'', '''')) = 12
AND PhoneNumber IS NOT NULL;

UPDATE tempApiCustomers
SET PhoneNumber_E164 = NULL
WHERE PhoneNumber LIKE ''11%'';

UPDATE tempApiCustomers
SET PhoneNumber_E164 = REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')
WHERE PhoneNumber LIKE ''+001%''
AND LENGTH(REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')) = 12;

UPDATE tempApiCustomers
SET Phone1_E164 = ''+1'' || REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')) = 10
AND Phone1Input NOT LIKE ''1%''
AND Phone1Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone1_E164 = ''+'' || REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')) = 11
AND Phone1Input LIKE ''1%''
AND Phone1Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone1_E164 = REGEXP_REPLACE(SUBSTRING(Phone1Input, 1, POSITION(''ext.'' IN Phone1Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone1Input) LIKE ''%ext.%''
AND Phone1Input LIKE ''+1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone1Input, 1, POSITION(''ext.'' IN Phone1Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone1Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone1_E164 = ''+'' || REGEXP_REPLACE(SUBSTRING(Phone1Input, 1, POSITION(''ext.'' IN Phone1Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone1Input) LIKE ''%ext.%''
AND Phone1Input LIKE ''1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone1Input, 1, POSITION(''ext.'' IN Phone1Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone1Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone1_E164 = NULL
WHERE Phone1Input LIKE ''11%'';

UPDATE tempApiCustomers
SET Phone1_E164 = REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')
WHERE Phone1Input LIKE ''+001%''
AND LENGTH(REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')) = 12;

UPDATE tempApiCustomers
SET Phone2_E164 = ''+1'' || REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')) = 10
AND Phone2Input NOT LIKE ''1%''
AND Phone2Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone2_E164 = ''+'' || REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')) = 11
AND Phone2Input LIKE ''1%''
AND Phone2Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone2_E164 = REGEXP_REPLACE(SUBSTRING(Phone2Input, 1, POSITION(''ext.'' IN Phone2Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone2Input) LIKE ''%ext.%''
AND Phone2Input LIKE ''+1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone2Input, 1, POSITION(''ext.'' IN Phone2Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone2Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone2_E164 = ''+'' || REGEXP_REPLACE(SUBSTRING(Phone2Input, 1, POSITION(''ext.'' IN Phone2Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone2Input) LIKE ''%ext.%''
AND Phone2Input LIKE ''1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone2Input, 1, POSITION(''ext.'' IN Phone2Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone2Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone2_E164 = NULL
WHERE Phone2Input LIKE ''11%'';

UPDATE tempApiCustomers
SET Phone2_E164 = REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')
WHERE Phone2Input LIKE ''+001%''
AND LENGTH(REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')) = 12;

UPDATE tempApiCustomers
SET Phone4_E164 = ''+1'' || REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')) = 10
AND Phone4Input NOT LIKE ''1%''
AND Phone4Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone4_E164 = ''+'' || REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')) = 11
AND Phone4Input LIKE ''1%''
AND Phone4Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone4_E164 = REGEXP_REPLACE(SUBSTRING(Phone4Input, 1, POSITION(''ext.'' IN Phone4Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone4Input) LIKE ''%ext.%''
AND Phone4Input LIKE ''+1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone4Input, 1, POSITION(''ext.'' IN Phone4Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone4Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone4_E164 = ''+'' || REGEXP_REPLACE(SUBSTRING(Phone4Input, 1, POSITION(''ext.'' IN Phone4Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone4Input) LIKE ''%ext.%''
AND Phone4Input LIKE ''1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone4Input, 1, POSITION(''ext.'' IN Phone4Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone4Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone4_E164 = NULL
WHERE Phone4Input LIKE ''11%'';

UPDATE tempApiCustomers
SET Phone4_E164 = REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')
WHERE Phone4Input LIKE ''+001%''
AND LENGTH(REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')) = 12;
-- End of phone conversion by Divya Nalam
--Inserting Customer Info data  
INSERT INTO ANALYTICS.customer_info (
    FK_CUSTOMERID,
    STATUS,
    PREFERRED_LANG,
    REGD_DATE,
    TITLE,
    FIRST_NAME,
    LAST_NAME,
    DOB,
    GENDER_CODE,
    GENDER,
    MARITAL_STATUS_CODE,
    MARITAL_STATUS,
    EMAIL_PRIMARY,
    EMAIL_SECONDARY,
    PHONE1_INPUT,
    PHONE2_INPUT,
    PHONE3_INPUT,
    PHONE4_INPUT,
    COMPANY_NAME,
    CATALOG_SUBSCRIBER,
    CUSTOMER_IS_ANONYMOUS,
    IS_ANONYMOUS_DATE_UPDATED,
    CUST_TYPE,
    NEW_CUSTOMER,
    CUST_NOTES,
    TAX_EXEMPT_ACCOUNT,
    ORDER_PLACED,
    CREATED_BY,
    CREATED_DATE,
    MODIFIED_BY,
    MODIFIED_DATE,
    LAST_LOGIN_DATE,
    EXTERNAL_ID,
    EXTERNAL_ACCOUNTID,
    EXTERNAL_EMAIL2,
    EXTERNAL_EMAIL1,
    MASTERCONTACT,
    LEGAL_NAME,
    EMAIL_OPT_IN_STATUS,
    FK_MASTERCUSTOMERID,
    DEDUP_TYPE,
    cust_tier,
    tax_id,
    email_subscriber,
    IsNordstromCustomer,
    IsWilliamsonomaCustomer,
    business_cust,
    business_category,
    "BUSINESS_#_OF_LOCATIONS",
    DesignTradeFlag,
    social_handle_facebook,
    social_handle_instagram,
    social_handle_twitter,
    phone1_sms,
    phone1_pref,
    phone1_region,
    phone2_sms,
    phone2_pref,
    phone2_region,
    phone3_sms,
    phone3_pref,
    phone3_region,
    phone4_sms,
    phone4_pref,
    phone4_region,
    phone1_E164,
    phone2_E164,
    phone3_E164,
    phone4_E164,
    HashedId
)
SELECT DISTINCT 
    dimcust.pk_customerid,
    cust.Status, -- Initial value
    cust.Preferred_Lang, -- demo value
    cust.Regd_Date, -- REGD_Date
    NULL AS Title,
    cust.FirstName,
    cust.LastName,
    cust.Dob, -- DOB
    cust.GenderCode, -- gender_code
    cust.Gender, -- gender
    cust.MaritalStatusCode, -- marital_status_code
    cust.MaritalStatus, -- marital_status
    cust.EmailAddress,
    cust.EmailSecondary, -- EMAIL_SECONDARY
    cust.Phone1Input, -- Phone1Input
    cust.Phone2Input, -- Phone2Input
    cust.PhoneNumber AS Phone3Input,
    cust.Phone4Input, -- Phone4Input
    cust.CompanyName,
    cust.CatalogSubscriber,
    cust.Customer_IsAnonymous,
    NULL AS IS_ANONYMOUS_DATE_UPDATED,
    cust.CustomerType, -- custtype.pk_customer_typeid
    cust.Checkbox_For_New_Customers,
    cust.Customer_Notes,
    cust.TaxExemptAccount,
    cust.OrderPlaced,
    cust.CreatedBy,
    CURRENT_DATE, -- @currentdate
    cust.CreatedBy,
    CURRENT_DATE, -- @currentdate
    IFNULL(cust.LastLogin, NULL),
    cust.EXTERNAL_ID,
    cust.EXTERNAL_ACCOUNTID,
    cust.ExternalEmail2,
    cust.ExternalEmail1,
    cust.MASTERCONTACT,
    cust.LegalName,
    cust.EMAIL_OPT_IN_STATUS,
    cust.MASTERCUSTOMERID,
    NULL,
    cust.cust_tier,
    cust.tax_id,
    CASE
        WHEN LOWER(cust.EmailSubscriber) = ''true''
        THEN 1
        ELSE 0
    END AS email_subscriber,
    cust.IsNordstromCustomer,
    cust.IsWilliamsonomaCustomer,
    cust.business_cust,
    cust.business_category,
    cust.BusinessLocations,
    cust.DesignTradeFlag,
    cust.social_handle_facebook,
    cust.social_handle_instagram,
    cust.social_handle_twitter,
    cust.phone1_sms,
    cust.phone1_pref,
    cust.phone1_region,
    cust.phone2_sms,
    cust.phone2_pref,
    cust.phone2_region,
    cust.phone3_sms,
    cust.phone3_pref,
    cust.phone3_region,
    cust.phone4_sms,
    cust.phone4_pref,
    cust.phone4_region,
    cust.Phone1_E164, -- phone1_E164
    cust.Phone2_E164, -- phone2_E164
    cust.PhoneNumber_E164,
    cust.Phone4_E164,
    cust.HashedId 
    from
    tempApiCustomers AS cust
INNER JOIN ANALYTICS.customer AS dimcust ON dimcust.source_ref_num = cust.SourceRefNum
    AND dimcust.fk_sourceid = cust.pk_sourceid;

   
MERGE INTO RAW.raw_ORDER_customer_person_info roh
USING (
    SELECT roh.person_info_key, roh.fk_sourceid
    FROM RAW.raw_ORDER_customer_person_info roh
    INNER JOIN TRANSFORMED.stg_ORDER_customer_person_info stg 
        ON stg.person_info_key = roh.person_info_key
    INNER JOIN CustomerApiCount toh 
        ON toh.source_ref_num = roh.person_info_key 
        AND toh.fk_sourceid = roh.fk_sourceid
    WHERE roh.processing_status IN (''Pending'', ''Failed'')
) src
ON roh.person_info_key = src.person_info_key
AND roh.fk_sourceid = src.fk_sourceid
WHEN MATCHED THEN
    UPDATE SET 
        roh.processing_status = ''Processed'',
        roh.processing_comment = '''',
        roh.processing_errortype = '''';



SELECT COUNT(*) INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_customer_person_info;

SELECT COUNT(*) INTO :processedRecordCount
FROM CustomerApiCount;

UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
WHERE
    ANALYTICS.log_files_import_status.file_name = ''INTR_CUSTOMER_INFO'';
    
    END;
END IF;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''insert'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''upsert completed successfully''
    );

SYSTEM$LOG(''TRACE'','' USP_ORDER_CUSTOMER_PERSON_INFO_INSERT has been Completed'');
RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

        error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''insert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );
    SYSTEM$LOG(''ERROR'','' USP_ORDER_CUSTOMER_PERSON_INFO_INSERT has Failed'');
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDER_HEADER_AND_LINE_STATUS_GENERATION"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN 

CREATE OR REPLACE TEMPORARY TABLE DimInventoryErrorToLog (
    input STRING, 
    message STRING, 
    snapshotId STRING, 
    productID STRING
);

CREATE OR REPLACE TEMPORARY TABLE TempAPI_ORDER_line_status (
    order_release_status_key STRING NOT NULL, 
    order_line_key STRING NOT NULL, 
    order_header_key STRING NOT NULL, 
    status_quantity INT, 
    total_quantity INT, 
    status STRING(254),
    priority INT NOT NULL,
    txn_id STRING NOT NULL
);

CREATE OR REPLACE TEMPORARY TABLE TempAPI_ORDER_header_status (
    order_header_key STRING NOT NULL, 
    status_quantity INT, 
    total_quantity INT, 
    status STRING(254),
    header_priority INT NOT NULL,
    txn_id STRING NOT NULL
);

INSERT INTO TempAPI_ORDER_line_status (
    order_release_status_key,
    order_line_key,
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    priority,
    txn_id
)
SELECT
    order_release_status_key,
    order_line_key,
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    priority,
    txn_id
FROM (
    SELECT 
        order_release_status_key,
        order_header_key,
        order_line_key,
        status_quantity,
        total_quantity,
        status,
        txn_id,
        ROW_NUMBER() OVER (PARTITION BY txn_id, order_line_key ORDER BY TO_NUMBER(COALESCE(order_release_status_key, ''0'')) DESC) AS priority
    FROM RAW.raw_ORDER_release_status
    WHERE status_quantity > 0 AND processing_status IN (''Pending'', ''Failed'')
) AS processed
WHERE priority = 1;

UPDATE RAW.raw_ORDER_line
SET order_line_status = LTRIM(RTRIM(COALESCE(ls.status, '''')))
FROM (
    SELECT 
        MAX(order_release_status_key) AS order_release_status_key,
        order_line_key,
        order_header_key,
        status,
        txn_id
    FROM TempAPI_ORDER_line_status
    GROUP BY order_line_key, order_header_key, status, txn_id
) AS ls
WHERE ls.order_header_key = RAW.raw_ORDER_line.ORDER_HEADER_KEY
  AND ls.order_line_key = RAW.raw_ORDER_line.ORDER_LINE_KEY
  AND RAW.raw_ORDER_line.txn_id = ls.txn_id;

INSERT INTO TempAPI_ORDER_header_status (
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority,
    txn_id
)
SELECT 
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority,
    txn_id
FROM (
    SELECT 
        order_header_key,
        status_quantity,
        total_quantity,
        status,
        txn_id,
        ROW_NUMBER() OVER (
            PARTITION BY txn_id, order_header_key 
            ORDER BY CAST(LTRIM(RTRIM(COALESCE(status_quantity, 0))) AS DECIMAL(38, 0)) ASC
        ) AS header_priority
    FROM (
        SELECT 
            order_header_key,
            SUM(status_quantity) AS status_quantity,
            SUM(total_quantity) AS total_quantity,
            status,
            txn_id
        FROM TempAPI_ORDER_line_status
        GROUP BY order_header_key, status, txn_id
    ) AS processed_line
) AS processed
WHERE header_priority = 1;
  
UPDATE RAW.raw_ORDER_header
SET order_status = CASE 
    WHEN ls.header_priority > 1 THEN 
        ''_'' || LTRIM(RTRIM(COALESCE(ls.status, '''')))
    WHEN ls.header_priority = 1 THEN 
        LTRIM(RTRIM(COALESCE(ls.status, '''')))
    ELSE NULL
END
FROM (
    SELECT 
        MAX(status_quantity) AS status_quantity,
        order_header_key,
        status,
        header_priority,
        txn_id
    FROM TempAPI_ORDER_header_status
    GROUP BY order_header_key, status, header_priority, txn_id
) AS ls
WHERE ls.order_header_key = RAW.raw_ORDER_header.ORDER_HEADER_KEY 
  AND RAW.raw_ORDER_header.txn_id = ls.txn_id 
  AND LTRIM(RTRIM(COALESCE(ls.status, ''''))) IS NOT NULL;

SELECT 
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority,
    txn_id
FROM (
    SELECT 
        order_header_key,
        status_quantity,
        total_quantity,
        status,
        txn_id,
        ROW_NUMBER() OVER (
            PARTITION BY txn_id, order_header_key 
            ORDER BY CAST(LTRIM(RTRIM(COALESCE(status_quantity::string, ''0''))) AS DECIMAL(38, 0)) ASC
        ) AS header_priority
    FROM (
        SELECT 
            order_header_key,
            SUM(status_quantity) AS status_quantity,
            SUM(total_quantity) AS total_quantity,
            status,
            txn_id
        FROM TempAPI_ORDER_line_status
        GROUP BY order_header_key, status, txn_id
    ) AS processed_line
) AS processed;

COMMIT;
RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE   PROCEDURE "USP_ORDER_HEADER_CHARGES_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    createdby NUMBER DEFAULT 1;
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedFeeDetails NUMBER DEFAULT 0;
    processedDiscountDetails NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
    

CREATE OR REPLACE TEMPORARY TABLE OrderDiscountDetails AS
SELECT 
    stg.header_charges_key,
    stg.header_key,
    toh.pk_order_headerid AS fk_order_headerid,
    stg.charge_name AS discount_name,
    CAST(stg.charge AS DECIMAL(38, 2)) AS discount_amount,
    stg.extn_charge_description AS discount_code,
    stg.extn_coupon_code AS coupon_code,
    stg.charge_category AS charge_type,
    stg.txn_id AS txn_id
FROM 
    TRANSFORMED.stg_ORDER_header_charges stg
INNER JOIN 
     ANALYTICS.txn_order_header AS toh ON toh.ext_order_id = stg.header_key AND toh.entry_type IS NOT NULL
INNER JOIN 
      master.dim_CHARGECATEGORY AS dc ON dc.charge_category = stg.charge_category AND dc.charge = ''DISCOUNT''
WHERE 
    toh.pk_order_headerid IS NOT NULL
    AND UPPER(dc.charge) IN (''DISCOUNT'');


    
CREATE OR REPLACE TEMPORARY TABLE TempDiscountDetails(  
  pk_order_discountid BIGINT NOT NULL,  
   ext_charge_id TEXT NOT NULL, 
   fk_order_headerid BIGINT  NOT NULL  
  ,discount_name  TEXT NOT NULL  
  ,discount_amount  DECIMAL(38, 2) NOT NULL  
  ,discount_code TEXT NULL  
  ,coupon_code TEXT NULL  
  ,createdby NUMBER NULL  
  ,created_date TIMESTAMP NULL  
  ,modified_date TIMESTAMP NULL  
  ,Revision NUMBER NULL);

processedDate := CURRENT_TIMESTAMP();  

MERGE INTO  ANALYTICS.txn_order_discount AS tod
USING (
    SELECT DISTINCT
        orddisc.fk_order_headerid,
        orddisc.discount_name,
        orddisc.header_charges_key,
        orddisc.discount_code,
        orddisc.coupon_code,
        orddisc.discount_amount,
        CURRENT_TIMESTAMP() AS created_date,
        CURRENT_TIMESTAMP() AS modified_date
    FROM
        OrderDiscountDetails AS orddisc
) AS ohd
ON (
    tod.fk_order_headerid = ohd.fk_order_headerid
    AND tod.ext_charge_id = ohd.header_charges_key
    AND tod.discount_name = ohd.discount_name
)
WHEN MATCHED THEN
    UPDATE SET
        tod.discount_name = ohd.discount_name,
        tod.discount_code = ohd.discount_code,
        tod.coupon_code = ohd.coupon_code,
        tod.discount_amount = ohd.discount_amount,
        tod.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        fk_order_headerid,
        discount_name,
        discount_code,
        coupon_code,
        discount_amount,
        ext_charge_id,
        inserted_date,
        modified_date
    ) VALUES (
        ohd.fk_order_headerid,
        ohd.discount_name,
        ohd.discount_code,
        ohd.coupon_code,
        ohd.discount_amount,
        ohd.header_charges_key,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );


INSERT INTO TempDiscountDetails (
    pk_order_discountid,
    fk_order_headerid,
    discount_name,
    discount_code,
    coupon_code,
    discount_amount,
    ext_charge_id,
    createdby,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_discountid,
    fk_order_headerid,
    discount_name,
    discount_code,
    coupon_code,
    discount_amount,
    ext_charge_id,
    :createdby,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    :InitialRevision
FROM  ANALYTICS.txn_order_discount
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;



MERGE INTO TempDiscountDetails tdd
USING (
    SELECT
        MAX(aod.revision) AS revision,
        aod.pk_order_discountid,
        aod.fk_order_headerid
    FROM ANALYTICS.audit_order_discount AS aod
    INNER JOIN TempDiscountDetails AS tdd
        ON tdd.pk_order_discountid = aod.pk_order_discountid
        AND tdd.fk_order_headerid = aod.fk_order_headerid
    GROUP BY
        aod.pk_order_discountid,
        aod.fk_order_headerid
) AS src
ON tdd.pk_order_discountid = src.pk_order_discountid
AND tdd.fk_order_headerid = src.fk_order_headerid
WHEN MATCHED THEN
    UPDATE SET tdd.Revision = CAST((src.revision + 1) AS INT);

INSERT INTO  ANALYTICS.audit_order_discount (
    pk_order_discountid,
    fk_order_headerid,
    discount_name,
    discount_code,
    coupon_code,
    discount_amount,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_discountid,
    fk_order_headerid,
    discount_name,
    discount_code,
    coupon_code,
    discount_amount,
    createdby,
    created_date,
    modified_date,
    revision
FROM TempDiscountDetails;

CREATE OR REPLACE TEMPORARY TABLE TempFeeDetails(  
  pk_order_Feeid BIGINT NOT NULL,  
  ext_charge_id TEXT NOT NULL  
  ,fk_order_headerid BIGINT NOT NULL  
  ,fee_type  TEXT NOT NULL  
  ,fee_amount  DECIMAL(38, 2) NOT NULL  
  ,createdby NUMBER NULL  
  ,created_date TIMESTAMP NULL  
  ,modified_date TIMESTAMP NULL  
  ,Revision NUMBER NULL);  

CREATE OR REPLACE TEMPORARY TABLE OrderFeeDetails AS
SELECT 
    stg.header_charges_key,
    stg.header_key,
    toh.pk_order_headerid AS fk_order_headerid,
    stg.charge_name AS fee_type,
    CAST(stg.charge AS DECIMAL(38,2)) AS fee_amount,
    stg.charge_category AS charge_type,
    stg.txn_id AS txn_id
FROM 
    TRANSFORMED.stg_ORDER_header_charges stg
    INNER JOIN analytics.txn_order_header toh 
        ON toh.ext_order_id = stg.header_key 
        AND toh.entry_type IS NOT NULL
    INNER JOIN master.dim_CHARGECATEGORY dc 
        ON dc.charge_category = stg.charge_category 
        AND dc.charge = ''FEE''
WHERE
    toh.pk_order_headerid IS NOT NULL  
    AND UPPER(dc.charge) IN (''FEE'');

    

MERGE INTO  ANALYTICS.txn_order_fee AS tod
USING OrderFeeDetails AS ohd
ON 
    tod.fk_order_headerid = ohd.fk_order_headerid  
    AND tod.ext_charge_id = ohd.header_charges_key  
    AND tod.fee_type = ohd.fee_type
WHEN MATCHED THEN
    UPDATE SET
        tod.fee_type = ohd.fee_type,
        tod.fee_amount = ohd.fee_amount,
        tod.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        fk_order_headerid,
        fee_type,
        fee_amount,
        ext_charge_id,
        inserted_date,
        modified_date
    )
    VALUES (
        ohd.fk_order_headerid,
        ohd.fee_type,
        ohd.fee_amount,
        ohd.header_charges_key,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempFeeDetails (
    pk_order_feeid,
    fk_order_headerid,
    fee_type,
    fee_amount,
    ext_charge_id,
    createdby,
    created_date,
    modified_date,
    revision
)
SELECT
    t.pk_order_feeid,
    t.fk_order_headerid,
    t.fee_type,
    t.fee_amount,
    t.ext_charge_id,
    :createdby, -- Replace with actual value if needed
    t.inserted_date,
    t.modified_date,
    1 AS revision -- Replace with @InitialRevision if needed
FROM analytics.txn_order_fee t
JOIN (
    SELECT 
        fk_order_headerid,
        fee_type,
        fee_amount,
        header_charges_key
    FROM OrderFeeDetails
) AS ohd
ON (
    t.fk_order_headerid = ohd.fk_order_headerid
    AND t.ext_charge_id = ohd.header_charges_key
    AND t.fee_type = ohd.fee_type
)
;

MERGE INTO TempFeeDetails tdd
USING (
    SELECT 
        MAX(aod.revision) AS max_revision,
        aod.pk_order_feeid,
        aod.fk_order_headerid
    FROM analytics.audit_order_fee AS aod
    INNER JOIN TempFeeDetails AS tdd 
        ON tdd.pk_order_feeid = aod.pk_order_feeid 
        AND tdd.fk_order_headerid = aod.fk_order_headerid
    GROUP BY 
        aod.pk_order_feeid,
        aod.fk_order_headerid
) AS src
ON tdd.pk_order_feeid = src.pk_order_feeid
AND tdd.fk_order_headerid = src.fk_order_headerid
WHEN MATCHED THEN
    UPDATE SET tdd.Revision = (src.max_revision + 1)::number ;


INSERT INTO  analytics.audit_order_fee (  
    pk_order_feeid,  
    fk_order_headerid,  
    fee_type,  
    fee_amount,  
    created_by,  
    created_date,  
    modified_date,  
    revision,
    ext_charge_id
)  
SELECT  
    pk_order_feeid,  
    fk_order_headerid,  
    fee_type,  
    fee_amount,  
    createdby,  
    created_date,  
    modified_date,  
    revision,
    ext_charge_id
FROM TempFeeDetails;

MERGE INTO RAW.raw_ORDER_header_charges AS rohc
USING (
    SELECT 
        sohc.header_charges_key, 
        sohc.header_key, 
        sohc.txn_id, 
        sohc.modifyts,
        odd.fk_order_headerid, 
        odd.discount_name
    FROM TRANSFORMED.stg_ORDER_header_charges AS sohc
    INNER JOIN OrderDiscountDetails AS odd 
        ON odd.header_charges_key = sohc.header_charges_key
        AND odd.header_key = sohc.header_key
        AND odd.txn_id = sohc.txn_id
    INNER JOIN TempDiscountDetails AS tdd 
        ON tdd.fk_order_headerid = odd.fk_order_headerid
        AND tdd.discount_name = odd.discount_name
) AS matched
ON rohc.header_charges_key = matched.header_charges_key
    AND rohc.header_key = matched.header_key
    AND rohc.txn_id = matched.txn_id
    AND rohc.modifyts = matched.modifyts
WHEN MATCHED THEN
UPDATE SET 
    rohc.processing_status = ''Processed'',  
    rohc.processing_comment = '''',  
    rohc.processing_errortype = '''';

MERGE INTO RAW.raw_ORDER_header_charges rohc
USING (
    SELECT 
        sohc.header_charges_key, 
        sohc.header_key, 
        sohc.txn_id, 
        sohc.modifyts, 
        odd.header_charges_key AS odd_header_charges_key, 
        tdd.fk_order_headerid, 
        tdd.fee_type
    FROM 
        TRANSFORMED.stg_ORDER_header_charges AS sohc
    INNER JOIN OrderFeeDetails AS odd 
        ON odd.header_charges_key = sohc.header_charges_key 
        AND odd.header_key = sohc.header_key 
        AND odd.txn_id = sohc.txn_id
    INNER JOIN TempFeeDetails AS tdd 
        ON tdd.fk_order_headerid = odd.fk_order_headerid 
        AND tdd.fee_type = odd.fee_type
) AS src
ON rohc.header_charges_key = src.header_charges_key
AND rohc.header_key = src.header_key
AND rohc.txn_id = src.txn_id
AND rohc.modifyts = src.modifyts
WHEN MATCHED THEN
    UPDATE SET 
        rohc.processing_status = ''Processed'',
        rohc.processing_comment = '''',
        rohc.processing_errortype = '''';



SELECT
    COUNT(*)
INTO
    :processedFeeDetails
FROM
    TempFeeDetails;


SELECT
    COUNT(*)
INTO
    :processedDiscountDetails
FROM
    TempDiscountDetails;
    
processedRecordCount := processedFeeDetails + processedDiscountDetails
;

SELECT
    COUNT(*)
INTO
    :toBeProcessedRecordCount
FROM
    TRANSFORMED.stg_ORDER_header_charges;


UPDATE ANALYTICS.log_files_import_status AS lofis
SET   
   lofis.processed = :processedRecordCount,
   lofis.status = ''Success''
WHERE lofis.file_name = ''YFS_HEADER_CHARGES'';


    
  DROP TABLE IF EXISTS OrderFeeDetails;  
  DROP TABLE IF EXISTS TempFeeDetails;  
  
  DROP TABLE IF EXISTS OrderDiscountDetails;  
  DROP TABLE IF EXISTS TempDiscountDetails; 

    update analytics.txn_order_header h  
    set h.SHPPING_FEE_AMOUNT= f.fee_amount
    from analytics.txn_order_fee f 
    where f.fk_order_headerid= h.pk_order_headerid and 
    f.FEE_TYPE =''Order Shipping'' and f.fee_amount>0;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_HEADER_CHARGES'';

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDER_HEADER_CHARGES_UPSERT_"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
        processedRecordCount NUMBER DEFAULT 0;
        processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
		

		CREATE OR REPLACE TEMPORARY TABLE TempHeaderCharges (
    header_charges_key VARCHAR ,
    header_key VARCHAR ,
    record_type VARCHAR ,
    charge_category VARCHAR ,
    charge_name VARCHAR ,
    reference VARCHAR ,
    charge FLOAT ,
    invoiced_charge FLOAT ,
    original_charge FLOAT ,
    is_manual VARCHAR ,
    createts TIMESTAMP ,
    modifyts TIMESTAMP ,
    createuserid VARCHAR ,
    modifyuserid VARCHAR ,
    createprogid VARCHAR ,
    modifyprogid VARCHAR ,
    lockid VARCHAR ,
    extn_charge_description VARCHAR ,
    extn_coupon_code VARCHAR ,
    inserted_date TIMESTAMP ,
    modified_date TIMESTAMP ,
    revision INT
);

processedDate := CURRENT_TIMESTAMP();  

		MERGE INTO analytics.txn_order_header_charges AS thc
USING (
    SELECT 
        stg.header_charges_key,
        stg.header_key,
        stg.record_type,
        stg.charge_category,
        stg.charge_name,
        stg.reference,
        TRY_CAST(stg.charge AS FLOAT) AS charge,
        TRY_CAST(stg.invoiced_charge AS FLOAT) AS invoiced_charge,
        TRY_CAST(stg.original_charge AS FLOAT) AS original_charge,
        stg.is_manual,
        TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'') AS createts,
        TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'') AS modifyts,
        stg.createuserid,
        stg.modifyuserid,
        stg.createprogid,
        stg.modifyprogid,
        stg.lockid,
        stg.extn_charge_description,
        stg.extn_coupon_code
    FROM   transformed.stg_order_header_charges AS stg
    INNER JOIN raw.raw_order_header_charges AS r
        ON r.header_charges_key = stg.header_charges_key 
        AND r.modifyts = stg.modifyts 
        AND r.processing_status = ''Processed''
) AS shc
ON 
    thc.header_charges_key = shc.header_charges_key
    AND thc.header_key = shc.header_key
WHEN MATCHED THEN
    UPDATE SET 
        thc.header_charges_key = shc.header_charges_key,
        thc.header_key = shc.header_key,
        thc.record_type = shc.record_type,
        thc.charge_category = shc.charge_category,
        thc.charge_name = shc.charge_name,
        thc.reference = shc.reference,
        thc.charge = shc.charge,
        thc.invoiced_charge = shc.invoiced_charge,
        thc.original_charge = shc.original_charge,
        thc.is_manual = shc.is_manual,
        thc.createts = shc.createts,
        thc.modifyts = shc.modifyts,
        thc.createuserid = shc.createuserid,
        thc.modifyuserid = shc.modifyuserid,
        thc.createprogid = shc.createprogid,
        thc.modifyprogid = shc.modifyprogid,
        thc.lockid = shc.lockid,
        thc.extn_charge_description = shc.extn_charge_description,
        thc.extn_coupon_code = shc.extn_coupon_code,
        thc.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        header_charges_key,
        header_key,
        record_type,
        charge_category,
        charge_name,
        reference,
        charge,
        invoiced_charge,
        original_charge,
        is_manual,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        extn_charge_description,
        extn_coupon_code,
        inserted_date
    )
    VALUES (
        shc.header_charges_key,
        shc.header_key,
        shc.record_type,
        shc.charge_category,
        shc.charge_name,
        shc.reference,
        shc.charge,
        shc.invoiced_charge,
        shc.original_charge,
        shc.is_manual,
        shc.createts,
        shc.modifyts,
        shc.createuserid,
        shc.modifyuserid,
        shc.createprogid,
        shc.modifyprogid,
        shc.lockid,
        shc.extn_charge_description,
        shc.extn_coupon_code,
        CURRENT_TIMESTAMP()
    );

			
			INSERT INTO TempHeaderCharges (
    header_charges_key,
    header_key,
    record_type,
    charge_category,
    charge_name,
    reference,
    charge,
    invoiced_charge,
    original_charge,
    is_manual,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    extn_charge_description,
    extn_coupon_code,
    inserted_date,
    Revision
)
SELECT 
    inserted.header_charges_key,
    inserted.header_key,
    inserted.record_type,
    inserted.charge_category,
    inserted.charge_name,
    inserted.reference,
    inserted.charge,
    inserted.invoiced_charge,
    inserted.original_charge,
    inserted.is_manual,
    inserted.createts,
    inserted.modifyts,
    inserted.createuserid,
    inserted.modifyuserid,
    inserted.createprogid,
    inserted.modifyprogid,
    inserted.lockid,
    inserted.extn_charge_description,
    inserted.extn_coupon_code,
    CURRENT_TIMESTAMP(),
    1
FROM analytics.txn_order_header_charges inserted
WHERE inserted_date >= :processedDate OR modified_date >= :processedDate;

MERGE INTO TempHeaderCharges ttd
USING (
    SELECT
        MAX(aot.revision) AS revision,
        aot.header_charges_key,
        aot.header_key
    FROM analytics.audit_order_header_charges aot
    INNER JOIN TempHeaderCharges ttd
        ON ttd.header_charges_key = aot.header_charges_key
        AND ttd.header_key = aot.header_key
    GROUP BY aot.header_charges_key, aot.header_key
) aot
ON ttd.header_charges_key = aot.header_charges_key
AND ttd.header_key = aot.header_key
WHEN MATCHED THEN
    UPDATE SET
        ttd.Revision = CAST(COALESCE(aot.revision, 0) + 1 AS INT);

			
		  

		--Insert into audit tables

		INSERT INTO analytics.audit_order_header_charges (
    header_charges_key,
    header_key,
    record_type,
    charge_category,
    charge_name,
    reference,
    charge,
    invoiced_charge,
    original_charge,
    is_manual,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    extn_charge_description,
    extn_coupon_code,
    inserted_date,
    Revision
)
SELECT
    stg.header_charges_key,
    stg.header_key,
    stg.record_type,
    stg.charge_category,
    stg.charge_name,
    stg.reference,
    TRY_CAST(stg.charge AS FLOAT) AS charge,
        TRY_CAST(stg.invoiced_charge AS FLOAT) AS invoiced_charge,
        TRY_CAST(stg.original_charge AS FLOAT) AS original_charge,
        stg.is_manual,
        TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'') AS createts,
        TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'') AS modifyts,
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    stg.extn_charge_description,
    stg.extn_coupon_code,
    CURRENT_TIMESTAMP(),
    ord.Revision
FROM transformed.stg_order_header_charges stg
INNER JOIN raw.raw_order_header_charges r
    ON r.header_charges_key = stg.header_charges_key
    AND r.modifyts = stg.modifyts
    AND r.processing_status = ''Processed''
INNER JOIN TempHeaderCharges ord 
    ON ord.header_charges_key = stg.header_charges_key
    AND ord.header_key = stg.header_key;



			SELECT COUNT(*) into :processedRecordCount FROM TempHeaderCharges;

		UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,  -- Replace with the actual value or bind variable
    status = ''Success''
WHERE
    file_name = ''YFS_ORDER_HEADER_CHARGES'';

	
		DROP TABLE if exists TempHeaderCharges;
		
	CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_HEADER_CHARGES'';

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDER_HOLD_TYPE_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status 
SET processed = :processedRecordCount,
    raw_table = ''raw_order_hold_type''    
WHERE file_name = ''YFS_ORDER_HOLD_TYPE'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE TempOrderHoldType (
    ORDER_HOLD_TYPE_KEY STRING,
    ORDER_HEADER_KEY STRING,
    ORDER_LINE_KEY STRING,
    HOLD_TYPE STRING,
    LAST_HOLD_TYPE_DATE TIMESTAMP_NTZ(9),
    REASON_TEXT STRING,
    TRANSACTION_ID STRING,
    ORDER_AUDIT_KEY STRING,
    STATUS STRING,
    RESOLVER_USER_ID STRING,
    CREATETS TIMESTAMP_NTZ(9),
    MODIFYTS TIMESTAMP_NTZ(9),
    CREATEUSERID STRING,
    MODIFYUSERID STRING,
    CREATEPROGID STRING,
    MODIFYPROGID STRING,
    LOCKID STRING,
    inserted_date TIMESTAMP_NTZ(9),
    modified_date TIMESTAMP_NTZ(9),
    revision INT
);

processedDate := CURRENT_TIMESTAMP();

-- Using MERGE in Snowflake
MERGE INTO ANALYTICS.txn_order_hold_type AS tht
USING (
    SELECT
        ORDER_HOLD_TYPE_KEY,
        ORDER_HEADER_KEY,
        ORDER_LINE_KEY,
        HOLD_TYPE,
        LAST_HOLD_TYPE_DATE,
        REASON_TEXT,
        TRANSACTION_ID,
        ORDER_AUDIT_KEY,
        STATUS,
        RESOLVER_USER_ID,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID
    FROM TRANSFORMED.stg_order_hold_type AS stg
) AS sht
ON tht.ORDER_HOLD_TYPE_KEY = sht.ORDER_HOLD_TYPE_KEY
AND tht.ORDER_HEADER_KEY = sht.ORDER_HEADER_KEY
--AND tht.ORDER_LINE_KEY = sht.ORDER_LINE_KEY
WHEN MATCHED THEN
    UPDATE SET
        tht.ORDER_HOLD_TYPE_KEY = sht.ORDER_HOLD_TYPE_KEY,
        tht.ORDER_HEADER_KEY = sht.ORDER_HEADER_KEY,
        tht.ORDER_LINE_KEY = sht.ORDER_LINE_KEY,
        tht.HOLD_TYPE = sht.HOLD_TYPE,
        tht.LAST_HOLD_TYPE_DATE = TRY_TO_TIMESTAMP(sht.LAST_HOLD_TYPE_DATE,''YYYYMMDDHHMISS''),
        tht.REASON_TEXT = sht.REASON_TEXT,
        tht.TRANSACTION_ID = sht.TRANSACTION_ID,
        tht.ORDER_AUDIT_KEY = sht.ORDER_AUDIT_KEY,
        tht.STATUS = sht.STATUS,
        tht.RESOLVER_USER_ID = sht.RESOLVER_USER_ID,
        tht.CREATETS = TRY_TO_TIMESTAMP(sht.createts,''YYYYMMDDHHMISS''),
        tht.MODIFYTS = TRY_TO_TIMESTAMP(sht.modifyts,''YYYYMMDDHHMISS''),
        tht.CREATEUSERID = sht.CREATEUSERID,
        tht.MODIFYUSERID = sht.MODIFYUSERID,
        tht.CREATEPROGID = sht.CREATEPROGID,
        tht.MODIFYPROGID = sht.MODIFYPROGID,
        tht.LOCKID = sht.LOCKID,
        tht.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        ORDER_HOLD_TYPE_KEY,
        ORDER_HEADER_KEY,
        ORDER_LINE_KEY,
        HOLD_TYPE,
        LAST_HOLD_TYPE_DATE,
        REASON_TEXT,
        TRANSACTION_ID,
        ORDER_AUDIT_KEY,
        STATUS,
        RESOLVER_USER_ID,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID,
        inserted_date
    )
    VALUES (
        sht.ORDER_HOLD_TYPE_KEY,
        sht.ORDER_HEADER_KEY,
        sht.ORDER_LINE_KEY,
        sht.HOLD_TYPE,
        TRY_TO_TIMESTAMP(sht.LAST_HOLD_TYPE_DATE,''YYYYMMDDHHMISS''),
        sht.REASON_TEXT,
        sht.TRANSACTION_ID,
        sht.ORDER_AUDIT_KEY,
        sht.STATUS,
        sht.RESOLVER_USER_ID,
        TRY_TO_TIMESTAMP(sht.createts,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(sht.modifyts,''YYYYMMDDHHMISS''),
        sht.CREATEUSERID,
        sht.MODIFYUSERID,
        sht.CREATEPROGID,
        sht.MODIFYPROGID,
        sht.LOCKID,
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempOrderHoldType (
    ORDER_HOLD_TYPE_KEY,
    ORDER_HEADER_KEY,
    ORDER_LINE_KEY,
    HOLD_TYPE,
    LAST_HOLD_TYPE_DATE,
    REASON_TEXT,
    TRANSACTION_ID,
    ORDER_AUDIT_KEY,
    STATUS,
    RESOLVER_USER_ID,
    CREATETS,
    MODIFYTS,
    CREATEUSERID,
    MODIFYUSERID,
    CREATEPROGID,
    MODIFYPROGID,
    LOCKID,
    inserted_date,
    Revision
)
SELECT
    ORDER_HOLD_TYPE_KEY,
    ORDER_HEADER_KEY,
    ORDER_LINE_KEY,
    HOLD_TYPE,
    LAST_HOLD_TYPE_DATE,
    REASON_TEXT,
    TRANSACTION_ID,
    ORDER_AUDIT_KEY,
    STATUS,
    RESOLVER_USER_ID,
    CREATETS,
    MODIFYTS,
    CREATEUSERID,
    MODIFYUSERID,
    CREATEPROGID,
    MODIFYPROGID,
    LOCKID,
    CURRENT_TIMESTAMP(), -- Replacing GETDATE() with CURRENT_TIMESTAMP() for Snowflake
    1
FROM
    ANALYTICS.txn_order_hold_type tcd
WHERE tcd.inserted_date >= :processedDate or tcd.modified_date >= :processedDate
    -- Add conditions if needed, otherwise, this will insert all records
;

CREATE OR REPLACE TEMPORARY TABLE TempMaxRevisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.ORDER_HOLD_TYPE_KEY,
    aot.ORDER_HEADER_KEY,
    aot.ORDER_LINE_KEY
FROM ANALYTICS.audit_order_hold_type AS aot
INNER JOIN TempOrderHoldType AS ttd
ON ttd.ORDER_HOLD_TYPE_KEY = aot.ORDER_HOLD_TYPE_KEY
AND ttd.ORDER_HEADER_KEY = aot.ORDER_HEADER_KEY
--AND ttd.ORDER_LINE_KEY = aot.ORDER_LINE_KEY
GROUP BY
    aot.ORDER_HOLD_TYPE_KEY, aot.ORDER_HEADER_KEY, aot.ORDER_LINE_KEY;

UPDATE TempOrderHoldType AS ttd
SET ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM TempMaxRevisions AS aot
WHERE  ttd.ORDER_HOLD_TYPE_KEY = aot.ORDER_HOLD_TYPE_KEY
AND ttd.ORDER_HEADER_KEY = aot.ORDER_HEADER_KEY
--AND ttd.ORDER_LINE_KEY = aot.ORDER_LINE_KEY
;

-- UPDATE RAW.raw_order_hold_type AS roh
-- SET
--     processing_status = ''Processed'',
--     processing_comment = '''',
--     processing_errortype = ''''
-- FROM (
--     SELECT
--         roh.ORDER_HOLD_TYPE_KEY,
--         roh.ORDER_HEADER_KEY
--     FROM
--         RAW.raw_order_hold_type AS roh
--     INNER JOIN
--         TRANSFORMED.stg_order_hold_type AS stg ON stg.ORDER_HOLD_TYPE_KEY = roh.ORDER_HOLD_TYPE_KEY
--         AND stg.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY
--         --AND stg.ORDER_LINE_KEY = roh.ORDER_LINE_KEY
--     INNER JOIN
--         ANALYTICS.txn_order_hold_type AS toh ON toh.ORDER_HOLD_TYPE_KEY = stg.ORDER_HOLD_TYPE_KEY
--         AND toh.ORDER_HEADER_KEY = stg.ORDER_HEADER_KEY
--         --AND toh.ORDER_LINE_KEY = stg.ORDER_LINE_KEY
-- ) AS subquery
-- WHERE
--     roh.ORDER_HOLD_TYPE_KEY = subquery.ORDER_HOLD_TYPE_KEY
--     AND roh.ORDER_HEADER_KEY = subquery.ORDER_HEADER_KEY;


UPDATE RAW.raw_order_hold_type AS roh
SET
    processing_status = ''Processed'',
    processing_comment = '''',
    processing_errortype = ''''
FROM TRANSFORMED.stg_order_hold_type AS stg
INNER JOIN ANALYTICS.txn_order_hold_type AS toh
    ON toh.ORDER_HOLD_TYPE_KEY = stg.ORDER_HOLD_TYPE_KEY
    AND toh.ORDER_HEADER_KEY = stg.ORDER_HEADER_KEY
WHERE roh.ORDER_HOLD_TYPE_KEY = stg.ORDER_HOLD_TYPE_KEY
    AND roh.ORDER_HEADER_KEY = stg.ORDER_HEADER_KEY;


INSERT INTO ANALYTICS.audit_order_hold_type (
    ORDER_HOLD_TYPE_KEY,
    ORDER_HEADER_KEY,
    ORDER_LINE_KEY,
    HOLD_TYPE,
    LAST_HOLD_TYPE_DATE,
    REASON_TEXT,
    TRANSACTION_ID,
    ORDER_AUDIT_KEY,
    STATUS,
    RESOLVER_USER_ID,
    CREATETS,
    MODIFYTS,
    CREATEUSERID,
    MODIFYUSERID,
    CREATEPROGID,
    MODIFYPROGID,
    LOCKID,
    inserted_date,
    Revision
)
SELECT
    stg.ORDER_HOLD_TYPE_KEY,
    stg.ORDER_HEADER_KEY,
    stg.ORDER_LINE_KEY,
    stg.HOLD_TYPE,
    TRY_TO_TIMESTAMP(stg.LAST_HOLD_TYPE_DATE,''YYYYMMDDHHMISS''),
    stg.REASON_TEXT,
    stg.TRANSACTION_ID,
    stg.ORDER_AUDIT_KEY,
    stg.STATUS,
    stg.RESOLVER_USER_ID,
    TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
    stg.CREATEUSERID,
    stg.MODIFYUSERID,
    stg.CREATEPROGID,
    stg.MODIFYPROGID,
    stg.LOCKID,
    CURRENT_TIMESTAMP(),
    ord.Revision
FROM TRANSFORMED.stg_order_hold_type stg
INNER JOIN TempOrderHoldType ord ON ord.ORDER_HOLD_TYPE_KEY = stg.ORDER_HOLD_TYPE_KEY
    AND ord.ORDER_HEADER_KEY = stg.ORDER_HEADER_KEY
    --AND ord.ORDER_LINE_KEY = stg.ORDER_LINE_KEY
    ;

SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM TRANSFORMED.stg_order_hold_type;
SELECT COUNT(*) INTO :processedRecordCount FROM TempOrderHoldType;

UPDATE analytics.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
WHERE
    file_name = ''YFS_ORDER_HOLD_TYPE'';

-- Dropping the temporary table
DROP TABLE IF EXISTS TempOrderHoldType;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;
RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_HOLD_TYPE'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
CREATE PROCEDURE "USP_ORDER_INBOX_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
    
CREATE OR REPLACE TEMPORARY TABLE insertedInboxRecords (
    inbox_key TEXT NOT NULL,
    inbox_type TEXT,
    description TEXT,
    generated_on TIMESTAMP,
    queue_key TEXT,
    enterprise_key TEXT,
    shipnode_key TEXT,
    exception_type TEXT,
    auto_resolved_flag TEXT,
    resolution_date TIMESTAMP,
    priority TEXT,
    resolve_by TIMESTAMP,
    last_unassign_alert TEXT,
    last_unresolve_alert TEXT,
    locked_flag TEXT,
    locked_by_user_key TEXT,
    locked_on TIMESTAMP,
    parent_inbox_key TEXT,
    detail_description TEXT,
    list_description TEXT,
    status TEXT,
    active_flag TEXT,
    closed_on TIMESTAMP,
    followup_date TIMESTAMP,
    last_exceed_alert TIMESTAMP,
    exception_escalated_flag TEXT,
    owner_type TEXT,
    owner_key TEXT,
    assigned_to_user_key TEXT,
    consolidation_count TEXT,
    last_occurred_on TEXT,
    flow_name TEXT,
    api_name TEXT,
    sub_flow_name TEXT,
    view_id TEXT,
    error_reason TEXT,
    error_type TEXT,
    expiration_days TEXT,
    inbox_addnl_data TEXT,
    resolved_by_user_id TEXT,
    unresolve_realert_count TEXT,
    unassign_realert_count TEXT,
    lockid TEXT,
    createts TIMESTAMP,
    modifyts TIMESTAMP,
    createuserid TEXT,
    modifyuserid TEXT,
    createprogid TEXT,
    modifyprogid TEXT,
    count_request_key TEXT,
    count_program_name TEXT,
    wave_key TEXT,
    wave_no TEXT,
    supplier_key TEXT,
    order_header_key TEXT,
    order_no TEXT,
    shipment_key TEXT,
    shipment_no TEXT,
    load_no TEXT,
    item_id TEXT,
    order_line_key TEXT,
    work_order_key TEXT,
    work_order_no TEXT,
    move_request_key TEXT,
    location_id TEXT,
    bill_to_id TEXT,
    team_code TEXT,
    inserted_date TIMESTAMP,
    modified_date TIMESTAMP,
    revision TEXT,
    txn_id TEXT,
    createts_utc TIMESTAMP_NTZ(9),
    modifyts_utc TIMESTAMP_NTZ(9)
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.TXN_ORDER_INBOX ti
USING (
    SELECT DISTINCT 
        inbox_key,
        inbox_type,
        description,
        TRY_TO_TIMESTAMP_NTZ(generated_on, ''YYYYMMDDHH24MISS'') AS generated_on,
        queue_key,
        enterprise_key,
        shipnode_key,
        exception_type,
        auto_resolved_flag,
        TRY_TO_TIMESTAMP_NTZ(resolution_date, ''YYYYMMDDHH24MISS'') AS resolution_date,
        priority,
        TRY_TO_TIMESTAMP_NTZ(resolve_by, ''YYYYMMDDHH24MISS'') AS resolve_by,
        last_unassign_alert,
        last_unresolve_alert,
        locked_flag,
        locked_by_user_key,
        TRY_TO_TIMESTAMP_NTZ(locked_on, ''YYYYMMDDHH24MISS'') AS locked_on,
        parent_inbox_key,
        detail_description,
        list_description,
        status,
        active_flag,
        TRY_TO_TIMESTAMP_NTZ(closed_on, ''YYYYMMDDHH24MISS'') AS closed_on,
        TRY_TO_TIMESTAMP_NTZ(followup_date, ''YYYYMMDDHH24MISS'') AS followup_date,
        TRY_TO_TIMESTAMP_NTZ(last_exceed_alert, ''YYYYMMDDHH24MISS'') AS last_exceed_alert,
        exception_escalated_flag,
        owner_type,
        owner_key,
        assigned_to_user_key,
        consolidation_count,
        TRY_TO_TIMESTAMP_NTZ(last_occurred_on, ''YYYYMMDDHH24MISS'') AS last_occurred_on,
        flow_name,
        api_name,
        sub_flow_name,
        view_id,
        error_reason,
        error_type,
        expiration_days,
        inbox_addnl_data,
        resolved_by_user_id,
        unresolve_realert_count,
        unassign_realert_count,
        lockid,
        TRY_TO_TIMESTAMP_NTZ(createts, ''YYYYMMDDHH24MISS'') AS createts,
                         
        TRY_TO_TIMESTAMP_NTZ(modifyts, ''YYYYMMDDHH24MISS'') AS modifyts,               
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        count_request_key,
        count_program_name,
        wave_key,
        wave_no,
        supplier_key,
        order_header_key,
        order_no,
        shipment_key,
        shipment_no,
        load_no,
        item_id,
        order_line_key,
        work_order_key,
        work_order_no,
        move_request_key,
        location_id,
        bill_to_id,
        team_code,
        txn_id
    FROM TRANSFORMED.STG_ORDER_INBOX
) si
ON ti.inbox_key = si.inbox_key
WHEN MATCHED THEN
    UPDATE SET
        ti.inbox_key = si.inbox_key,
        ti.inbox_type = si.inbox_type,
        ti.description = si.description,
        ti.generated_on = si.generated_on,
        ti.queue_key = si.queue_key,
        ti.enterprise_key = si.enterprise_key,
        ti.shipnode_key = si.shipnode_key,
        ti.exception_type = si.exception_type,
        ti.auto_resolved_flag = si.auto_resolved_flag,
        ti.resolution_date = si.resolution_date,
        ti.priority = si.priority,
        ti.resolve_by = si.resolve_by,
        ti.last_unassign_alert = si.last_unassign_alert,
        ti.last_unresolve_alert = si.last_unresolve_alert,
        ti.locked_flag = si.locked_flag,
        ti.locked_by_user_key = si.locked_by_user_key,
        ti.locked_on = si.locked_on,
        ti.parent_inbox_key = si.parent_inbox_key,
        ti.detail_description = si.detail_description,
        ti.list_description = si.list_description,
        ti.status = si.status,
        ti.active_flag = si.active_flag,
        ti.closed_on = si.closed_on,
        ti.followup_date = si.followup_date,
        ti.last_exceed_alert = si.last_exceed_alert,
        ti.exception_escalated_flag = si.exception_escalated_flag,
        ti.owner_type = si.owner_type,
        ti.owner_key = si.owner_key,
        ti.assigned_to_user_key = si.assigned_to_user_key,
        ti.consolidation_count = si.consolidation_count,
        ti.last_occurred_on = si.last_occurred_on,
        ti.flow_name = si.flow_name,
        ti.api_name = si.api_name,
        ti.sub_flow_name = si.sub_flow_name,
        ti.view_id = si.view_id,
        ti.error_reason = si.error_reason,
        ti.error_type = si.error_type,
        ti.expiration_days = si.expiration_days,
        ti.inbox_addnl_data = si.inbox_addnl_data,
        ti.resolved_by_user_id = si.resolved_by_user_id,
        ti.unresolve_realert_count = si.unresolve_realert_count,
        ti.unassign_realert_count = si.unassign_realert_count,
        ti.lockid = si.lockid,
        ti.createts = si.createts,
        ti.modifyts = si.modifyts,
        ti.createuserid = si.createuserid,
        ti.modifyuserid = si.modifyuserid,
        ti.createprogid = si.createprogid,
        ti.modifyprogid = si.modifyprogid,
        ti.count_request_key = si.count_request_key,
        ti.count_program_name = si.count_program_name,
        ti.wave_key = si.wave_key,
        ti.wave_no = si.wave_no,
        ti.supplier_key = si.supplier_key,
        ti.order_header_key = si.order_header_key,
        ti.order_no = si.order_no,
        ti.shipment_key = si.shipment_key,
        ti.shipment_no = si.shipment_no,
        ti.load_no = si.load_no,
        ti.item_id = si.item_id,
        ti.order_line_key = si.order_line_key,
        ti.work_order_key = si.work_order_key,
        ti.work_order_no = si.work_order_no,
        ti.move_request_key = si.move_request_key,
        ti.location_id = si.location_id,
        ti.bill_to_id = si.bill_to_id,
        ti.team_code = si.team_code,
        ti.modified_date = CURRENT_TIMESTAMP(),
        ti.txn_id = si.txn_id,
        ti.createts_utc =  si.createts,
        ti.modifyts_utc =  si.modifyts
WHEN NOT MATCHED THEN
    INSERT (
        inbox_key,
        inbox_type,
        description,
        generated_on,
        queue_key,
        enterprise_key,
        shipnode_key,
        exception_type,
        auto_resolved_flag,
        resolution_date,
        priority,
        resolve_by,
        last_unassign_alert,
        last_unresolve_alert,
        locked_flag,
        locked_by_user_key,
        locked_on,
        parent_inbox_key,
        detail_description,
        list_description,
        status,
        active_flag,
        closed_on,
        followup_date,
        last_exceed_alert,
        exception_escalated_flag,
        owner_type,
        owner_key,
        assigned_to_user_key,
        consolidation_count,
        last_occurred_on,
        flow_name,
        api_name,
        sub_flow_name,
        view_id,
        error_reason,
        error_type,
        expiration_days,
        inbox_addnl_data,
        resolved_by_user_id,
        unresolve_realert_count,
        unassign_realert_count,
        lockid,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        count_request_key,
        count_program_name,
        wave_key,
        wave_no,
        supplier_key,
        order_header_key,
        order_no,
        shipment_key,
        shipment_no,
        load_no,
        item_id,
        order_line_key,
        work_order_key,
        work_order_no,
        move_request_key,
        location_id,
        bill_to_id,
        team_code,
        inserted_date,
        modified_date,
        txn_id,
        createts_utc,
        modifyts_utc
    )
    VALUES (
        si.inbox_key,
        si.inbox_type,
        si.description,
        si.generated_on,
        si.queue_key,
        si.enterprise_key,
        si.shipnode_key,
        si.exception_type,
        si.auto_resolved_flag,
        si.resolution_date,
        si.priority,
        si.resolve_by,
        si.last_unassign_alert,
        si.last_unresolve_alert,
        si.locked_flag,
        si.locked_by_user_key,
        si.locked_on,
        si.parent_inbox_key,
        si.detail_description,
        si.list_description,
        si.status,
        si.active_flag,
        si.closed_on,
        si.followup_date,
        si.last_exceed_alert,
        si.exception_escalated_flag,
        si.owner_type,
        si.owner_key,
        si.assigned_to_user_key,
        si.consolidation_count,
        si.last_occurred_on,
        si.flow_name,
        si.api_name,
        si.sub_flow_name,
        si.view_id,
        si.error_reason,
        si.error_type,
        si.expiration_days,
        si.inbox_addnl_data,
        si.resolved_by_user_id,
        si.unresolve_realert_count,
        si.unassign_realert_count,
        si.lockid,
        si.createts,
        si.modifyts,
        si.createuserid,
        si.modifyuserid,
        si.createprogid,
        si.modifyprogid,
        si.count_request_key,
        si.count_program_name,
        si.wave_key,
        si.wave_no,
        si.supplier_key,
        si.order_header_key,
        si.order_no,
        si.shipment_key,
        si.shipment_no,
        si.load_no,
        si.item_id,
        si.order_line_key,
        si.work_order_key,
        si.work_order_no,
        si.move_request_key,
        si.location_id,
        si.bill_to_id,
        si.team_code,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        si.txn_id,
        si.modifyts,
        si.createts
    );


INSERT INTO insertedInboxRecords (
    inbox_key,
    inbox_type,
    description,
    generated_on,
    queue_key,
    enterprise_key,
    shipnode_key,
    exception_type,
    auto_resolved_flag,
    resolution_date,
    priority,
    resolve_by,
    last_unassign_alert,
    last_unresolve_alert,
    locked_flag,
    locked_by_user_key,
    locked_on,
    parent_inbox_key,
    detail_description,
    list_description,
    status,
    active_flag,
    closed_on,
    followup_date,
    last_exceed_alert,
    exception_escalated_flag,
    owner_type,
    owner_key,
    assigned_to_user_key,
    consolidation_count,
    last_occurred_on,
    flow_name,
    api_name,
    sub_flow_name,
    view_id,
    error_reason,
    error_type,
    expiration_days,
    inbox_addnl_data,
    resolved_by_user_id,
    unresolve_realert_count,
    unassign_realert_count,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    count_request_key,
    count_program_name,
    wave_key,
    wave_no,
    supplier_key,
    order_header_key,
    order_no,
    shipment_key,
    shipment_no,
    load_no,
    item_id,
    order_line_key,
    work_order_key,
    work_order_no,
    move_request_key,
    location_id,
    bill_to_id,
    team_code,
    inserted_date,
    modified_date,
    txn_id,
    revision,
    createts_utc,
    modifyts_utc
)
SELECT DISTINCT 
    si.inbox_key,
    ti.inbox_type,
    ti.description,
    ti.generated_on,
    ti.queue_key,
    ti.enterprise_key,
    ti.shipnode_key,
    ti.exception_type,
    ti.auto_resolved_flag,
    ti.resolution_date,
    ti.priority,
    ti.resolve_by,
    ti.last_unassign_alert,
    ti.last_unresolve_alert,
    ti.locked_flag,
    ti.locked_by_user_key,
    ti.locked_on,
    ti.parent_inbox_key,
    ti.detail_description,
    ti.list_description,
    ti.status,
    ti.active_flag,
    ti.closed_on,
    ti.followup_date,
    ti.last_exceed_alert,
    ti.exception_escalated_flag,
    ti.owner_type,
    ti.owner_key,
    ti.assigned_to_user_key,
    ti.consolidation_count,
    ti.last_occurred_on,
    ti.flow_name,
    ti.api_name,
    ti.sub_flow_name,
    ti.view_id,
    ti.error_reason,
    ti.error_type,
    ti.expiration_days,
    ti.inbox_addnl_data,
    ti.resolved_by_user_id,
    ti.unresolve_realert_count,
    ti.unassign_realert_count,
    ti.lockid,
    ti.createts,
    ti.modifyts,
    ti.createuserid,
    ti.modifyuserid,
    ti.createprogid,
    ti.modifyprogid,
    ti.count_request_key,
    ti.count_program_name,
    ti.wave_key,
    ti.wave_no,
    ti.supplier_key,
    ti.order_header_key,
    ti.order_no,
    ti.shipment_key,
    ti.shipment_no,
    ti.load_no,
    ti.item_id,
    ti.order_line_key,
    ti.work_order_key,
    ti.work_order_no,
    ti.move_request_key,
    ti.location_id,
    ti.bill_to_id,
    ti.team_code,
    ti.inserted_date,
    ti.modified_date,
    si.txn_id,
    :initialRevision,
    ti.createts_utc,
    ti.modifyts_utc
FROM ANALYTICS.TXN_ORDER_INBOX ti
        INNER JOIN TRANSFORMED.STG_ORDER_INBOX si 
            ON ti.inbox_key = si.inbox_key
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;

    
CREATE OR REPLACE TEMPORARY TABLE temp_max_revisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.inbox_key
FROM
    ANALYTICS.audit_ORDER_inbox AS aot
GROUP BY
    aot.inbox_key;

UPDATE insertedInboxRecords AS ttd
SET
    ttd.revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM
    temp_max_revisions AS aot
WHERE
    ttd.inbox_key = aot.inbox_key;

DROP TABLE IF EXISTS temp_max_revisions;


INSERT INTO ANALYTICS.audit_ORDER_inbox (
    inbox_key,
    inbox_type,
    description,
    generated_on,
    queue_key,
    enterprise_key,
    shipnode_key,
    exception_type,
    auto_resolved_flag,
    resolution_date,
    priority,
    resolve_by,
    last_unassign_alert,
    last_unresolve_alert,
    locked_flag,
    locked_by_user_key,
    locked_on,
    parent_inbox_key,
    detail_description,
    list_description,
    status,
    active_flag,
    closed_on,
    followup_date,
    last_exceed_alert,
    exception_escalated_flag,
    owner_type,
    owner_key,
    assigned_to_user_key,
    consolidation_count,
    last_occurred_on,
    flow_name,
    api_name,
    sub_flow_name,
    view_id,
    error_reason,
    error_type,
    expiration_days,
    inbox_addnl_data,
    resolved_by_user_id,
    unresolve_realert_count,
    unassign_realert_count,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    count_request_key,
    count_program_name,
    wave_key,
    wave_no,
    supplier_key,
    order_header_key,
    order_no,
    shipment_key,
    shipment_no,
    load_no,
    item_id,
    order_line_key,
    work_order_key,
    work_order_no,
    move_request_key,
    location_id,
    bill_to_id,
    team_code,
    inserted_date,
    modified_date,
    revision,
    txn_id,
    createts_utc,
    modifyts_utc
)
SELECT
    si.inbox_key,
    si.inbox_type,
    si.description,
    si.generated_on,
    si.queue_key,
    si.enterprise_key,
    si.shipnode_key,
    si.exception_type,
    si.auto_resolved_flag,
    si.resolution_date,
    si.priority,
    si.resolve_by,
    si.last_unassign_alert,
    si.last_unresolve_alert,
    si.locked_flag,
    si.locked_by_user_key,
    si.locked_on,
    si.parent_inbox_key,
    si.detail_description,
    si.list_description,
    si.status,
    si.active_flag,
    si.closed_on,
    si.followup_date,
    si.last_exceed_alert,
    si.exception_escalated_flag,
    si.owner_type,
    si.owner_key,
    si.assigned_to_user_key,
    si.consolidation_count,
    si.last_occurred_on,
    si.flow_name,
    si.api_name,
    si.sub_flow_name,
    si.view_id,
    si.error_reason,
    si.error_type,
    si.expiration_days,
    si.inbox_addnl_data,
    si.resolved_by_user_id,
    si.unresolve_realert_count,
    si.unassign_realert_count,
    si.lockid,
    si.createts,
    si.modifyts,
    si.createuserid,
    si.modifyuserid,
    si.createprogid,
    si.modifyprogid,
    si.count_request_key,
    si.count_program_name,
    si.wave_key,
    si.wave_no,
    si.supplier_key,
    si.order_header_key,
    si.order_no,
    si.shipment_key,
    si.shipment_no,
    si.load_no,
    si.item_id,
    si.order_line_key,
    si.work_order_key,
    si.work_order_no,
    si.move_request_key,
    si.location_id,
    si.bill_to_id,
    si.team_code,
    si.inserted_date,
    si.modified_date,
    si.revision,
    si.txn_id,
    si.createts_utc,
    si.modifyts_utc
FROM insertedInboxRecords AS si;

UPDATE RAW.raw_ORDER_inbox roi
SET 
    roi.processing_status = ''Processed'',
    roi.processing_comment = '''',
    roi.processing_errortype = ''''
from insertedInboxRecords toi 
    where toi.inbox_key = roi.inbox_key 
    AND toi.txn_id = roi.txn_id 
    AND roi.modifyts = TO_CHAR(CAST(toi.modifyts AS TIMESTAMP), ''YYYYMMDDHH24MISS'');

SELECT
    COUNT(*)
INTO
    :processedRecordCount
FROM
    insertedInboxRecords;

UPDATE ANALYTICS.log_files_import_status AS lofis
SET
    lofis.processed = :processedRecordCount,
    lofis.status = ''Success''
WHERE
    lofis.file_name = ''YFS_INBOX'';

DROP TABLE IF EXISTS insertedInboxRecords;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;

RETURN ''Success'';

EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_INBOX'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

     CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';

CREATE PROCEDURE "USP_ORDER_LASTRUN_STATUS_UPDATE"("LASTRUN" TIMESTAMP_NTZ(9))
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    FinalStatus BOOLEAN DEFAULT TRUE;
BEGIN
    UPDATE log_files_import_status 
    SET since_ = :lastrun;
    
    RETURN FinalStatus;
END';
CREATE PROCEDURE "USP_ORDER_LINE_CHARGES_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    createdby NUMBER DEFAULT 1;
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    Counter NUMBER DEFAULT 0;
    processedFeeDetails NUMBER DEFAULT 0;
    processedDiscountDetails NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status
SET processed = :Counter
FROM analytics.log_files_import_status AS lofis
WHERE lofis.file_name = ''YFS_LINE_CHARGES'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
    

CREATE OR REPLACE TEMPORARY TABLE OrderDetailDiscount (
    line_charges_key VARCHAR(255),
    order_header_key VARCHAR(255),
    ext_line_id VARCHAR(255),
    fk_order_headerid BIGINT,
    fk_order_detailid BIGINT,
    discount_name VARCHAR(255),
    discount_amount DECIMAL(38, 2),
    discount_code VARCHAR(255),
    coupon_code VARCHAR(255),
    charge_type VARCHAR(255),
    discount_rate DECIMAL(38, 2),
    txn_id VARCHAR(255)
);

INSERT INTO OrderDetailDiscount (line_charges_key, order_header_key, ext_line_id, fk_order_headerid, fk_order_detailid, discount_name, discount_amount, discount_code, coupon_code, charge_type, discount_rate, txn_id)
SELECT DISTINCT
    stg.line_charges_key,
    toh.order_header_key,
    tod.ext_line_id,
    toh.pk_order_headerid,
    tod.pk_order_detailid,
    stg.charge_name AS discount_name,
    CAST(stg.chargeamount AS DECIMAL(38, 2)) AS discount_amount,
    stg.extn_charge_description AS discount_code,
    stg.extn_coupon_code AS coupon_code,
    stg.charge_category AS charge_type,
    NULL AS discount_rate,
    stg.txn_id
FROM
    TRANSFORMED.stg_ORDER_line_charges stg
INNER JOIN ANALYTICS.txn_order_header AS toh ON toh.order_header_key = stg.header_key AND toh.entry_type IS NOT NULL
INNER JOIN ANALYTICS.txn_order_detail AS tod ON tod.ext_line_id = stg.line_key AND toh.pk_order_headerid = tod.fk_order_headerid
INNER JOIN master.dim_CHARGECATEGORY AS dc ON dc.charge_category = stg.charge_category AND dc.charge = ''DISCOUNT''
WHERE
    UPPER(dc.charge) = ''DISCOUNT'';

CREATE OR REPLACE TEMPORARY TABLE TempDetailDiscounts (
    pk_order_detail_discountid BIGINT NOT NULL,
    fk_order_detailid BIGINT NOT NULL,
    ext_charge_id VARCHAR(510) NOT NULL,
    discount_name VARCHAR,
    discount_amount VARCHAR,
    discount_code VARCHAR,
    coupon_code VARCHAR,
    created_by INT,
    created_date TIMESTAMP,
    modified_date TIMESTAMP,
    Revision INT
);

processedDate := CURRENT_TIMESTAMP();  

MERGE INTO  ANALYTICS.txn_order_detail_discount AS todd
USING (
    SELECT DISTINCT
        orddetaildisc.fk_order_detailid,
        orddetaildisc.discount_name,
        orddetaildisc.discount_code,
        orddetaildisc.discount_amount,
        orddetaildisc.coupon_code,
        orddetaildisc.line_charges_key,
        CURRENT_TIMESTAMP() AS created_date,
        CURRENT_TIMESTAMP() AS modified_date
    FROM OrderDetailDiscount AS orddetaildisc
) AS odd
ON ( todd.fk_order_detailid = odd.fk_order_detailid
AND todd.ext_charge_id = odd.line_charges_key)
WHEN MATCHED THEN
    UPDATE SET
        discount_name = odd.discount_name,
        discount_code = odd.discount_code,
        coupon_code = odd.coupon_code,
        discount_amount = odd.discount_amount,
        modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        fk_order_detailid,
        discount_name,
        discount_code,
        discount_amount,
        coupon_code,
        ext_charge_id,
        inserted_date,
        modified_date
    )
    VALUES (
        odd.fk_order_detailid,
        odd.discount_name,
        odd.discount_code,
        odd.discount_amount,
        odd.coupon_code,
        odd.line_charges_key,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempDetailDiscounts (
    pk_order_detail_discountid,
    fk_order_detailid,
    discount_name,
    discount_code,
    discount_amount,
    coupon_code,
    ext_charge_id,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_detail_discountid,
    fk_order_detailid,
    discount_name,
    discount_code,
    discount_amount,
    coupon_code,
    ext_charge_id,
    :createdby, 
    inserted_date, 
    modified_date, 
    :InitialRevision 
FROM ANALYTICS.txn_order_detail_discount todd 
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;

    
-- Populate revision
-- UPDATE TempDetailDiscounts
-- SET Revision = CAST((aodd.revision + 1 ) AS INT)
-- FROM TempDetailDiscounts AS tdd
-- INNER JOIN (
--     SELECT MAX(aodd.revision) AS revision,
--            aodd.pk_order_detail_discountid,
--            aodd.fk_order_detailid
--     FROM ANALYTICS.audit_order_detail_discount AS aodd
--     INNER JOIN TempDetailDiscounts AS tdd ON tdd.pk_order_detail_discountid = aodd.pk_order_detail_discountid AND tdd.fk_order_detailid = aodd.fk_order_detailid
--     GROUP BY aodd.pk_order_detail_discountid,
--              aodd.fk_order_detailid
-- ) AS aodd ON tdd.pk_order_detail_discountid = aodd.pk_order_detail_discountid AND tdd.fk_order_detailid = aodd.fk_order_detailid;

MERGE INTO TempDetailDiscounts tdd
USING (
    SELECT MAX(aodd.revision) AS revision,
           aodd.pk_order_detail_discountid,
           aodd.fk_order_detailid
    FROM ANALYTICS.audit_order_detail_discount AS aodd
    INNER JOIN TempDetailDiscounts AS tdd 
    ON tdd.pk_order_detail_discountid = aodd.pk_order_detail_discountid 
       AND tdd.fk_order_detailid = aodd.fk_order_detailid
    GROUP BY aodd.pk_order_detail_discountid,
             aodd.fk_order_detailid
) AS aodd
ON tdd.pk_order_detail_discountid = aodd.pk_order_detail_discountid 
   AND tdd.fk_order_detailid = aodd.fk_order_detailid
WHEN MATCHED THEN
    UPDATE SET tdd.Revision = CAST((aodd.revision + 1) AS INT);

INSERT INTO   ANALYTICS.AUDIT_ORDER_DETAIL_DISCOUNT(
    pk_order_detail_discountid,
    fk_order_detailid,
    discount_name,
    discount_code,
    discount_amount,
    created_by,
    created_date,
    modified_date,
    revision,
    coupon_code
)
SELECT
    pk_order_detail_discountid,
    fk_order_detailid,
    discount_name,
    discount_code,
    discount_amount,
    created_by,
    created_date,
    modified_date,
    revision,
    coupon_code
FROM TempDetailDiscounts;

CREATE OR REPLACE TEMPORARY TABLE TempDetailFees(
    pk_order_detail_feeid BIGINT NOT NULL,
    fk_order_detailid BIGINT NOT NULL,
    fee_type STRING NOT NULL,
    ext_charge_id STRING NOT NULL,
    fee_amount FLOAT NULL,
    created_by INT NULL,
    created_date TIMESTAMP NULL,
    modified_date TIMESTAMP NULL,
    Revision INT NULL
);


CREATE OR REPLACE TEMPORARY TABLE OrderDetailFee AS
SELECT DISTINCT
    stg.line_charges_key,
    toh.pk_order_headerid AS fk_order_headerid,
    tod.pk_order_detailid AS fk_order_detailid,
    toh.order_header_key,
    tod.ext_line_id AS ext_line_id,
    CAST(stg.chargeamount AS DECIMAL(38,2)) AS fee_amount,
    stg.charge_name AS fee_type,
    stg.txn_id
FROM
    TRANSFORMED.stg_ORDER_line_charges stg
INNER JOIN
    ANALYTICS.txn_order_header AS toh ON toh.order_header_key = stg.header_key AND toh.entry_type IS NOT NULL
INNER JOIN
    ANALYTICS.txn_order_detail AS tod ON tod.ext_line_id = stg.line_key AND toh.pk_order_headerid = tod.fk_order_headerid
INNER JOIN
    master.dim_CHARGECATEGORY AS dc ON dc.charge_category = stg.charge_category AND dc.charge = ''FEE''
WHERE
    UPPER(dc.charge) IN (''FEE'');

 

processedDate := CURRENT_TIMESTAMP();  
    
MERGE INTO ANALYTICS.txn_order_detail_fee AS todf
USING (
    SELECT DISTINCT
        orddetailfee.fk_order_detailid,
        orddetailfee.fee_type,
        orddetailfee.line_charges_key,
        orddetailfee.fee_amount
    FROM OrderDetailFee AS orddetailfee
) AS odf
ON 
    todf.fk_order_detailid = odf.fk_order_detailid
    AND todf.ext_charge_id = odf.line_charges_key

WHEN MATCHED THEN
    UPDATE SET
        fee_type = odf.fee_type,
        fee_amount = odf.fee_amount,
        modified_date = CURRENT_TIMESTAMP()

WHEN NOT MATCHED THEN
    INSERT (
        fk_order_detailid,
        fee_type,
        fee_amount,
        ext_charge_id,
        inserted_date,
        modified_date
    )
    VALUES (
        odf.fk_order_detailid,
        odf.fee_type,
        odf.fee_amount,
        odf.line_charges_key,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempDetailFees (
    pk_order_detail_feeid,
    fk_order_detailid,
    fee_type,
    fee_amount,
    ext_charge_id,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_detail_feeid,
    fk_order_detailid,
    fee_type,
    fee_amount,
    ext_charge_id,
    :createdby, -- Replace :createdby with the appropriate value for created_by
    inserted_date, -- Gets the current UTC date and time
    modified_date, -- Gets the current UTC date and time
    :InitialRevision -- Replace :InitialRevision with the appropriate value for revision
FROM ANALYTICS.txn_order_detail_fee
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;


--Populate revision
-- UPDATE TempDetailFees
-- SET TempDetailFees.Revision = CAST((aodd.revision + 1 ) as int)
-- FROM TempDetailFees as tdd
-- inner join (SELECT MAX(aodd.revision) as revision,aodd.pk_order_detail_feeid,
-- aodd.fk_order_detailid from  ANALYTICS.audit_order_detail_fee as aodd
-- inner join TempDetailFees as tdd on tdd.pk_order_detail_feeid = aodd.pk_order_detail_feeid and tdd.fk_order_detailid = aodd.fk_order_detailid
-- group by aodd.pk_order_Detail_feeid,
-- aodd.fk_order_detailid) as aodd  on tdd.pk_order_detail_feeid = aodd.pk_order_detail_feeid and tdd.fk_order_detailid = aodd.fk_order_detailid
-- ;

MERGE INTO TempDetailFees tdd
USING (
    SELECT MAX(aodd.revision) AS revision,
           aodd.pk_order_detail_feeid,
           aodd.fk_order_detailid
    FROM ANALYTICS.audit_order_detail_fee AS aodd
    INNER JOIN TempDetailFees AS tdd 
    ON tdd.pk_order_detail_feeid = aodd.pk_order_detail_feeid 
       AND tdd.fk_order_detailid = aodd.fk_order_detailid
    GROUP BY aodd.pk_order_detail_feeid,
             aodd.fk_order_detailid
) AS aodd
ON tdd.pk_order_detail_feeid = aodd.pk_order_detail_feeid 
   AND tdd.fk_order_detailid = aodd.fk_order_detailid
WHEN MATCHED THEN
    UPDATE SET tdd.Revision = CAST((aodd.revision + 1) AS INT);


INSERT INTO  audit_order_detail_fee (
    pk_order_detail_feeid,
    fk_order_detailid,
    fee_type,
    fee_amount,
    created_by,
    created_date,
    modified_date,
    revision,
    ext_charge_id
)
SELECT
    pk_order_detail_feeid,
    fk_order_detailid,
    fee_type,
    fee_amount,
    created_by,
    created_date,
    modified_date,
    revision,
    ext_charge_id
FROM TempDetailFees;

-- UPDATE RAW.raw_ORDER_line_charges rolc
-- SET 
--     processing_status = ''Processed'',
--     processing_comment = '''',
--     processing_errortype = ''''
-- WHERE EXISTS (
--     SELECT 1
--     FROM TRANSFORMED.stg_ORDER_line_charges solc
--     JOIN OrderDetailFee otd ON solc.line_charges_key = otd.line_charges_key AND solc.line_key = otd.ext_line_id AND solc.txn_id = otd.txn_id
--     JOIN TempDetailFees tod ON tod.fk_order_detailid = otd.fk_order_detailid AND tod.fee_type = otd.fee_type
--     WHERE 
--         rolc.line_charges_key = solc.line_charges_key 
--         AND rolc.line_key = solc.line_key 
--         AND rolc.txn_id = solc.txn_id 
--         AND solc.modifyts = rolc.modifyts
-- );

MERGE INTO RAW.raw_ORDER_line_charges rolc
USING (
    SELECT solc.line_charges_key, solc.line_key, solc.txn_id, solc.modifyts
    FROM TRANSFORMED.stg_ORDER_line_charges solc
    JOIN OrderDetailFee otd 
        ON solc.line_charges_key = otd.line_charges_key 
        AND solc.line_key = otd.ext_line_id 
        AND solc.txn_id = otd.txn_id
    JOIN TempDetailFees tod 
        ON tod.fk_order_detailid = otd.fk_order_detailid 
        AND tod.fee_type = otd.fee_type
) matched_rows
ON rolc.line_charges_key = matched_rows.line_charges_key 
   AND rolc.line_key = matched_rows.line_key 
   AND rolc.txn_id = matched_rows.txn_id 
   AND rolc.modifyts = matched_rows.modifyts
WHEN MATCHED THEN
    UPDATE SET 
        rolc.processing_status = ''Processed'',
        rolc.processing_comment = '''',
        rolc.processing_errortype = '''';


-- UPDATE RAW.raw_ORDER_line_charges rolc
-- SET 
--     rolc.processing_status = ''Processed'',
--     rolc.processing_comment = '''',
--     rolc.processing_errortype = ''''
-- WHERE EXISTS (
--     SELECT 1
--     FROM TRANSFORMED.stg_ORDER_line_charges solc
--     JOIN OrderDetailDiscount otd ON solc.line_charges_key = otd.line_charges_key AND solc.line_key = otd.ext_line_id AND solc.txn_id = otd.txn_id
--     JOIN TempDetailDiscounts tod ON tod.fk_order_detailid = otd.fk_order_detailid AND tod.ext_charge_id = otd.line_charges_key
--     WHERE 
--         rolc.line_charges_key = solc.line_charges_key 
--         AND rolc.line_key = solc.line_key 
--         AND rolc.txn_id = solc.txn_id 
--         AND solc.modifyts = rolc.modifyts
-- );

MERGE INTO RAW.raw_ORDER_line_charges rolc
USING (
    SELECT solc.line_charges_key, solc.line_key, solc.txn_id, solc.modifyts
    FROM TRANSFORMED.stg_ORDER_line_charges solc
    JOIN OrderDetailDiscount otd 
        ON solc.line_charges_key = otd.line_charges_key 
        AND solc.line_key = otd.ext_line_id 
        AND solc.txn_id = otd.txn_id
    JOIN TempDetailDiscounts tod 
        ON tod.fk_order_detailid = otd.fk_order_detailid 
        AND tod.ext_charge_id = otd.line_charges_key
) matched_rows
ON rolc.line_charges_key = matched_rows.line_charges_key 
   AND rolc.line_key = matched_rows.line_key 
   AND rolc.txn_id = matched_rows.txn_id 
   AND rolc.modifyts = matched_rows.modifyts
WHEN MATCHED THEN
    UPDATE SET 
        rolc.processing_status = ''Processed'',
        rolc.processing_comment = '''',
        rolc.processing_errortype = '''';



SELECT
    COUNT(*)
INTO
    :processedFeeDetails
FROM
    TempDetailFees;


SELECT
    COUNT(*)
INTO
    :processedDiscountDetails
FROM
    TempDetailDiscounts;
    
processedRecordCount := processedFeeDetails + processedDiscountDetails
;

UPDATE ANALYTICS.log_files_import_status
SET 
    processed = :processedRecordCount,
    status = ''Success''
FROM ANALYTICS.log_files_import_status AS lofis
WHERE lofis.file_name = ''YFS_LINE_CHARGES'';

DROP TABLE IF EXISTS TempDetailFees;
DROP TABLE IF EXISTS TempDetailDiscounts;
DROP TABLE IF EXISTS OrderDetailDiscount;
DROP TABLE IF EXISTS OrderDetailFee;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;

RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_LINE_CHARGES'';

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
        
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDER_LINE_CHARGES_UPSERT_"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
        processedRecordCount NUMBER DEFAULT 0;
        processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
    -- Create temp table
    CREATE OR REPLACE TEMP TABLE TempLineCharges(
        line_charges_key VARCHAR,
        header_key VARCHAR,
        line_key VARCHAR,
        record_type VARCHAR,
        charge_category VARCHAR,
        charge_name VARCHAR,
        reference VARCHAR,
        CHARGEPERUNIT FLOAT,
	    CHARGEPERLINE FLOAT,
	    CHARGEAMOUNT FLOAT,
	    INVOICED_CHARGE_PER_LINE FLOAT,
	    INVOICED_EXTENDED_CHARGE FLOAT,
	    ORIGINAL_CHARGEPERUNIT FLOAT,
	    ORIGINAL_CHARGEPERLINE FLOAT,
        is_manual VARCHAR,
        createts TIMESTAMP,
        modifyts TIMESTAMP,
        createuserid VARCHAR,
        modifyuserid VARCHAR,
        createprogid VARCHAR,
        modifyprogid VARCHAR,
        lockid VARCHAR,
        extn_charge_description VARCHAR,
        extn_coupon_code VARCHAR,
        inserted_date TIMESTAMP,
        modified_date TIMESTAMP,
        revision INT
    );
processedDate := CURRENT_TIMESTAMP(); 

    -- MERGE statement
    MERGE INTO  ANALYTICS.txn_order_line_charges tlc
    USING (
        SELECT 
            stg.line_charges_key,
            stg.header_key,
            stg.line_key,
            stg.record_type,
            stg.charge_category,
            stg.charge_name,
            stg.reference,
            TRY_CAST(stg.chargeperunit AS FLOAT) AS chargeperunit,
            TRY_CAST(stg.chargeperline AS FLOAT) AS chargeperline,
            TRY_CAST(stg.chargeamount AS FLOAT) AS chargeamount,
            TRY_CAST(stg.invoiced_charge_per_line AS FLOAT) AS invoiced_charge_per_line,
            TRY_CAST(stg.invoiced_extended_charge AS FLOAT) AS invoiced_extended_charge,
            TRY_CAST(stg.original_chargeperunit AS FLOAT) AS original_chargeperunit,
            TRY_CAST(stg.original_chargeperline AS FLOAT) AS original_chargeperline,
            stg.is_manual,
            TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'') AS createts,
            TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'') AS modifyts,
            stg.createuserid,
            stg.modifyuserid,
            stg.createprogid,
            stg.modifyprogid,
            stg.lockid,
            stg.extn_charge_description,
            stg.extn_coupon_code
        FROM  Transformed.stg_order_line_charges stg
        INNER JOIN raw.raw_order_line_charges r
            ON r.line_charges_key = stg.line_charges_key
            AND r.modifyts = stg.modifyts
            AND r.processing_status = ''Processed''
    ) slc
    ON tlc.line_charges_key = slc.line_charges_key
    WHEN MATCHED THEN
        UPDATE SET
            tlc.line_charges_key = slc.line_charges_key,
            tlc.header_key = slc.header_key,
            tlc.line_key = slc.line_key,
            tlc.record_type = slc.record_type,
            tlc.charge_category = slc.charge_category,
            tlc.charge_name = slc.charge_name,
            tlc.reference = slc.reference,
            tlc.chargeperunit = slc.chargeperunit,
            tlc.chargeperline = slc.chargeperline,
            tlc.chargeamount = slc.chargeamount,
            tlc.invoiced_charge_per_line = slc.invoiced_charge_per_line,
            tlc.invoiced_extended_charge = slc.invoiced_extended_charge,
            tlc.original_chargeperunit = slc.original_chargeperunit,
            tlc.original_chargeperline = slc.original_chargeperline,
            tlc.is_manual = slc.is_manual,
            tlc.createts = slc.createts,
            tlc.modifyts = slc.modifyts,
            tlc.createuserid = slc.createuserid,
            tlc.modifyuserid = slc.modifyuserid,
            tlc.createprogid = slc.createprogid,
            tlc.modifyprogid = slc.modifyprogid,
            tlc.lockid = slc.lockid,
            tlc.extn_charge_description = slc.extn_charge_description,
            tlc.extn_coupon_code = slc.extn_coupon_code,
            tlc.modified_date = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
            line_charges_key, header_key, line_key, record_type, charge_category, charge_name, reference, 
            chargeperunit, chargeperline, chargeamount, invoiced_charge_per_line, invoiced_extended_charge, 
            original_chargeperunit, original_chargeperline, is_manual, createts, modifyts, createuserid, 
            modifyuserid, createprogid, modifyprogid, lockid, extn_charge_description, extn_coupon_code, inserted_date
        ) VALUES (
            slc.line_charges_key, slc.header_key, slc.line_key, slc.record_type, slc.charge_category, slc.charge_name, 
            slc.reference, slc.chargeperunit, slc.chargeperline, slc.chargeamount, slc.invoiced_charge_per_line, 
            slc.invoiced_extended_charge, slc.original_chargeperunit, slc.original_chargeperline, slc.is_manual, 
            slc.createts, slc.modifyts, slc.createuserid, slc.modifyuserid, slc.createprogid, slc.modifyprogid, 
            slc.lockid, slc.extn_charge_description, slc.extn_coupon_code, CURRENT_TIMESTAMP()
        );

  INSERT INTO TempLineCharges( 
    line_charges_key,
    header_key,
    line_key,
    record_type,
    charge_category,
    charge_name,
    reference,
    chargeperunit,
    chargeperline,
    chargeamount,
    invoiced_charge_per_line,
    invoiced_extended_charge,
    original_chargeperunit,
    original_chargeperline,
    is_manual,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    extn_charge_description,
    extn_coupon_code,
    inserted_date,
    Revision
)
SELECT 
    inserted.line_charges_key,
    inserted.header_key,
    inserted.line_key,
    inserted.record_type,
    inserted.charge_category,
    inserted.charge_name,
    inserted.reference,
    inserted.chargeperunit,
    inserted.chargeperline,
    inserted.chargeamount,
    inserted.invoiced_charge_per_line,
    inserted.invoiced_extended_charge,
    inserted.original_chargeperunit,
    inserted.original_chargeperline,
    inserted.is_manual,
    inserted.createts,
    inserted.modifyts,
    inserted.createuserid,
    inserted.modifyuserid,
    inserted.createprogid,
    inserted.modifyprogid,
    inserted.lockid,
    inserted.extn_charge_description,
    inserted.extn_coupon_code,
    CURRENT_TIMESTAMP(),
    1
FROM ANALYTICS.txn_order_line_charges inserted
where  inserted_date >= :processedDate OR modified_date >= :processedDate;

   MERGE INTO TempLineCharges AS ttd
USING (
    SELECT
        MAX(aot.revision) AS revision,
        aot.line_charges_key,
        aot.header_key,
        aot.line_key
    FROM
        audit_order_line_charges AS aot
    INNER JOIN TempLineCharges AS ttd
        ON ttd.line_charges_key = aot.line_charges_key
        AND ttd.header_key = aot.header_key
        AND ttd.line_key = aot.line_key
    GROUP BY
        aot.line_charges_key,
        aot.header_key,
        aot.line_key
) AS aot
ON ttd.line_charges_key = aot.line_charges_key
AND ttd.header_key = aot.header_key
AND ttd.line_key = aot.line_key
WHEN MATCHED THEN
UPDATE SET
    ttd.Revision = CAST(COALESCE(aot.revision, 0) + 1 AS INT);


    

    -- Insert into audit tables
   INSERT INTO analytics.audit_order_line_charges (
    line_charges_key,
    header_key,
    line_key,
    record_type,
    charge_category,
    charge_name,
    reference,
    chargeperunit,
    chargeperline,
    chargeamount,
    invoiced_charge_per_line,
    invoiced_extended_charge,
    original_chargeperunit,
    original_chargeperline,
    is_manual,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    extn_charge_description,
    extn_coupon_code,
    inserted_date,
    Revision
)
SELECT
    stg.line_charges_key,
    stg.header_key,
    stg.line_key,
    stg.record_type,
    stg.charge_category,
    stg.charge_name,
    stg.reference,
    TRY_CAST(stg.chargeperunit AS FLOAT) AS chargeperunit,
    TRY_CAST(stg.chargeperline AS FLOAT) AS chargeperline,
    TRY_CAST(stg.chargeamount AS FLOAT) AS chargeamount,
    TRY_CAST(stg.invoiced_charge_per_line AS FLOAT) AS invoiced_charge_per_line,
    TRY_CAST(stg.invoiced_extended_charge AS FLOAT) AS invoiced_extended_charge,
    TRY_CAST(stg.original_chargeperunit AS FLOAT) AS original_chargeperunit,
    TRY_CAST(stg.original_chargeperline AS FLOAT) AS original_chargeperline,
    stg.is_manual,
    TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'') AS createts,
    TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'') AS modifyts,
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    stg.extn_charge_description,
    stg.extn_coupon_code,
    CURRENT_TIMESTAMP(),
    ord.Revision
FROM transformed.stg_order_line_charges stg
INNER JOIN raw.raw_order_line_charges r
    ON r.line_charges_key = stg.line_charges_key
    AND r.modifyts = stg.modifyts
    AND r.processing_status = ''Processed''
INNER JOIN TempLineCharges ord
    ON ord.line_charges_key = stg.line_charges_key
    AND ord.header_key = stg.header_key
    AND ord.line_key = stg.line_key;
    
-- Count processed records
      SELECT COUNT(*) into :processedRecordCount FROM TempLineCharges;
      
UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,  -- Replace with the actual value or bind variable
    status = ''Success''
WHERE
    file_name = ''YFS_LINE_CHARGES'';

	
		DROP TABLE if exists TempHeaderCharges;
		
	CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_LINE_CHARGES'';

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDER_NOTES_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount,
    raw_table = ''raw_ORDER_notes''
WHERE file_name = ''YFS_NOTES'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE TempOrderNotes (
    notes_key STRING,
    table_key STRING,
    sequence_no STRING,
    table_name STRING,
    tranid STRING,
    audit_transaction_id STRING,
    customer_sat_indicator STRING,
    priority STRING,
    reason_code STRING,
    note_text STRING,
    contact_type STRING,
    contact_reference STRING,
    contact_time TIMESTAMP_NTZ(9),
    contact_user STRING,
    lockid STRING,
    createts  TIMESTAMP_NTZ(9),
    modifyts TIMESTAMP_NTZ(9),
    createuserid STRING,
    modifyuserid STRING,
    createprogid STRING,
    modifyprogid STRING,
    visible_to_all STRING,
    inserted_date TIMESTAMP_NTZ(9),
    modified_date TIMESTAMP_NTZ(9),
    revision INT
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.txn_order_notes AS ton
USING (
    SELECT 
        notes_key,
        table_key,
        sequence_no,
        table_name,
        tranid,
        audit_transaction_id,
        customer_sat_indicator,
        priority,
        reason_code,
        note_text,
        contact_type,
        contact_reference,
        contact_time,
        contact_user,
        lockid,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        visible_to_all
    FROM TRANSFORMED.stg_ORDER_notes AS stg
) AS son
ON ton.notes_key = son.notes_key
WHEN MATCHED THEN
    UPDATE SET 
        ton.notes_key = son.notes_key,
        ton.table_key = son.table_key,
        ton.sequence_no = son.sequence_no,
        ton.table_name = son.table_name,
        ton.tranid = son.tranid,
        ton.audit_transaction_id = son.audit_transaction_id,
        ton.customer_sat_indicator = son.customer_sat_indicator,
        ton.priority = son.priority,
        ton.reason_code = son.reason_code,
        ton.note_text = son.note_text,
        ton.contact_type = son.contact_type,
        ton.contact_reference = son.contact_reference,
        ton.contact_time = TRY_TO_TIMESTAMP(son.contact_time,''YYYYMMDDHHMISS''),
        ton.contact_user = son.contact_user,
        ton.lockid = son.lockid,
        ton.createts = TRY_TO_TIMESTAMP(son.createts,''YYYYMMDDHHMISS''),
        ton.modifyts = TRY_TO_TIMESTAMP(son.modifyts,''YYYYMMDDHHMISS''),
        ton.createuserid = son.createuserid,
        ton.modifyuserid = son.modifyuserid,
        ton.createprogid = son.createprogid,
        ton.modifyprogid = son.modifyprogid,
        ton.visible_to_all = son.visible_to_all,
        ton.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        notes_key,
        table_key,
        sequence_no,
        table_name,
        tranid,
        audit_transaction_id,
        customer_sat_indicator,
        priority,
        reason_code,
        note_text,
        contact_type,
        contact_reference,
        contact_time,
        contact_user,
        lockid,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        visible_to_all,
        inserted_date
    )
    VALUES (
        son.notes_key,
        son.table_key,
        son.sequence_no,
        son.table_name,
        son.tranid,
        son.audit_transaction_id,
        son.customer_sat_indicator,
        son.priority,
        son.reason_code,
        son.note_text,
        son.contact_type,
        son.contact_reference,
        TRY_TO_TIMESTAMP(son.contact_time,''YYYYMMDDHHMISS''),
        son.contact_user,
        son.lockid,
        TRY_TO_TIMESTAMP(son.createts,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(son.modifyts,''YYYYMMDDHHMISS''),
        son.createuserid,
        son.modifyuserid,
        son.createprogid,
        son.modifyprogid,
        son.visible_to_all,
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempOrderNotes(
    notes_key,
    table_key,
    sequence_no,
    table_name,
    tranid,
    audit_transaction_id,
    customer_sat_indicator,
    priority,
    reason_code,
    note_text,
    contact_type,
    contact_reference,
    contact_time,
    contact_user,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    visible_to_all,
    inserted_date,
    Revision
)
SELECT
    ton.notes_key,
    ton.table_key,
    ton.sequence_no,
    ton.table_name,
    ton.tranid,
    ton.audit_transaction_id,
    ton.customer_sat_indicator,
    ton.priority,
    ton.reason_code,
    ton.note_text,
    ton.contact_type,
    ton.contact_reference,
    ton.contact_time,
    ton.contact_user,
    ton.lockid,
    ton.createts,
    ton.modifyts,
    ton.createuserid,
    ton.modifyuserid,
    ton.createprogid,
    ton.modifyprogid,
    ton.visible_to_all,
    CURRENT_TIMESTAMP(),  -- For inserted_date
    1  -- For Revision
FROM ANALYTICS.txn_order_notes AS ton
where inserted_date >= :processedDate or modified_date >= :processedDate;


-- UPDATE TempOrderNotes AS ttd
-- SET ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS INT)
-- FROM (
--     SELECT
--         MAX(aot.revision) AS revision,
--         aot.notes_key
--     FROM ANALYTICS.audit_order_notes AS aot
--     INNER JOIN TempOrderNotes AS ttd_temp ON ttd_temp.notes_key = aot.notes_key
--     GROUP BY aot.notes_key
-- ) AS aot
-- WHERE ttd.notes_key = aot.notes_key;


 
CREATE OR REPLACE TEMPORARY TABLE temp_max_revisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.notes_key
FROM
    ANALYTICS.audit_order_notes AS aot
GROUP BY
    aot.notes_key;

UPDATE TempOrderNotes AS ttd
SET
    ttd.revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM
    temp_max_revisions AS aot
WHERE
    ttd.notes_key = aot.notes_key;

DROP TABLE IF EXISTS temp_max_revisions;

-- UPDATE RAW.raw_ORDER_notes as roh
-- SET 
--     roh.processing_status = ''Processed'',
--     roh.processing_comment = '''',
--     roh.processing_errortype = ''''
-- FROM  (SELECT DISTINCT stg.notes_key FROM TRANSFORMED.stg_ORDER_notes AS stg 
-- INNER JOIN ANALYTICS.txn_order_notes AS toh ON toh.notes_key = stg.notes_key) stgt
-- WHERE  stgt.notes_key = roh.notes_key ;

UPDATE RAW.raw_ORDER_notes AS roh
SET 
    roh.processing_status = ''Processed'',
    roh.processing_comment = '''',
    roh.processing_errortype = ''''
FROM TRANSFORMED.stg_ORDER_notes AS stg
INNER JOIN ANALYTICS.txn_order_notes AS toh
    ON toh.notes_key = stg.notes_key
WHERE roh.notes_key = stg.notes_key;


INSERT INTO ANALYTICS.audit_order_notes(
    notes_key,
    table_key,
    sequence_no,
    table_name,
    tranid,
    audit_transaction_id,
    customer_sat_indicator,
    priority,
    reason_code,
    note_text,
    contact_type,
    contact_reference,
    contact_time,
    contact_user,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    visible_to_all,
    inserted_date,
    Revision
)
SELECT
    stg.notes_key,
    stg.table_key,
    stg.sequence_no,
    stg.table_name,
    stg.tranid,
    stg.audit_transaction_id,
    stg.customer_sat_indicator,
    stg.priority,
    stg.reason_code,
    stg.note_text,
    stg.contact_type,
    stg.contact_reference,
    TRY_TO_TIMESTAMP(stg.contact_time,''YYYYMMDDHHMISS''),
    stg.contact_user,
    stg.lockid,
    TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.visible_to_all,
    CURRENT_TIMESTAMP(),
    ord.Revision
FROM TRANSFORMED.stg_ORDER_notes stg
INNER JOIN TempOrderNotes ord ON ord.notes_key = stg.notes_key;

-- Count the number of records to be processed
SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM TRANSFORMED.stg_ORDER_notes;

-- Count the number of processed records
SELECT COUNT(*) INTO :processedRecordCount FROM TempOrderNotes;

-- Update log_files_import_status with processed counts
UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
WHERE file_name = ''YFS_NOTES'';

DROP TABLE IF EXISTS TempOrderNotes;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;
RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_NOTES'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
CREATE PROCEDURE "USP_ORDER_RAW_TABLE_CLEANUP"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN

call analytics.usp_ORDER_raw_table_invalid_nord_order_cleanup();

create or replace temporary table analytics.INVALID_ORDER_HEADER_KEY as 
SELECT ORDER_HEADER_KEY,ORDER_NO  FROM raw.raw_ORDER_header 
WHERE DOCUMENT_TYPE in (5) OR  ENTERPRISE_KEY in (''DEFAULT'');


create or replace temporary table analytics.INVALID_ORDER_LINE_KEY as 
SELECT ORDER_LINE_KEY  from raw.raw_ORDER_line  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);




delete  from raw.raw_ORDER_container_details  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY );
delete  from raw.raw_ORDER_payment  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
delete  from raw.raw_ORDER_release  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
delete  from raw.raw_ORDER_release_status  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
delete  from raw.raw_ORDER_shipment  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
delete  from raw.raw_ORDER_shipment_container  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
delete  from raw.raw_ORDER_shipment_line  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
delete  from raw.raw_ORDER_header_charges  where header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
delete  from raw.raw_ORDER_line_charges  where header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
delete  from raw.raw_ORDER_tax_breakup  where header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);


delete  from raw.raw_ORDER_audit_level  where ORDER_LINE_KEY IN (SELECT ORDER_LINE_KEY FROM analytics.INVALID_ORDER_LINE_KEY);
delete  from raw.raw_ORDER_audit  where ORDER_HEADER_KEY IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
delete  from raw.raw_ORDER_hold_type  where ORDER_HEADER_KEY IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
delete  from raw.raw_ORDER_invoice  where ORDER_HEADER_KEY IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

delete  from raw.raw_ORDER_line  where ORDER_LINE_KEY IN (SELECT ORDER_LINE_KEY FROM analytics.INVALID_ORDER_LINE_KEY);



--THIS LINE NEEDS TO BE AT THE END

delete  from raw.raw_ORDER_header  where ORDER_HEADER_KEY IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDER_RAW_TABLE_INVALID_NORD_ORDER_CLEANUP"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN

CREATE or replace temporary TABLE  analytics.INVALID_ORDER_HEADER_KEY  as  
SELECT DISTINCT r.ORDER_HEADER_KEY, ORDER_NO
      FROM raw.raw_ORDER_header r
      INNER JOIN analytics.txn_order_header t ON t.source_ref_num = r.CUSTOMER_PO_NO 
      WHERE t.fk_sourceid IN (38, 39, 40);

-- Deletion statements
 DELETE FROM raw.raw_ORDER_container_details
 WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_payment 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_release 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_release_status 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_shipment 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_shipment_container
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_shipment_line
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_header_charges 
WHERE header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_line_charges 
WHERE header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_tax_breakup 
WHERE header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_line 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
    
    -- THIS LINE NEEDS TO BE AT THE END
DELETE FROM raw.raw_ORDER_header 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
  
COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDER_RAW_TABLE_INVALID_ORDER_CLEANUP"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    message STRING;

BEGIN
    -- Start transaction
    BEGIN TRANSACTION;

    -- Create a temporary table for invalid order headers
    CREATE or REPLACE TEMPORARY TABLE analytics.INVALID_ORDER_HEADER_KEY AS
    SELECT DISTINCT ORDER_HEADER_KEY, ORDER_NO 
    FROM RAW.raw_order_header 
    WHERE DOCUMENT_TYPE = 5 
    OR ENTERPRISE_KEY = ''DEFAULT'' 
    OR DRAFT_ORDER_FLAG = ''Y'';

    -- Perform delete operations on related tables
    DELETE FROM RAW.raw_order_container_details 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_payment 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_release 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_release_status 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_shipment 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_shipment_container 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_shipment_line 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_header_charges 
    WHERE header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_line_charges 
    WHERE header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_tax_breakup 
    WHERE header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_hold_type 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_inbox 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

 --   DELETE FROM RAW.raw_order_audit_level 
--    WHERE order_audit_key IN (SELECT order_audit_key FROM raw_order_audit WHERE --order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY));

    --DELETE FROM RAW.raw_order_audit 
    --WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_line 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    -- This line needs to be at the end
    DELETE FROM RAW.raw_order_header 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_header_charges 
    WHERE record_type = ''INV'';

    DELETE FROM RAW.raw_order_line_charges 
    WHERE record_type = ''INV'';

    DELETE FROM RAW.raw_order_tax_breakup 
    WHERE record_type = ''INV'';

    -- Reject status with quantity
    UPDATE RAW.raw_order_release_status 
    SET processing_status = ''Rejected'', processing_comment = ''Quantity is zero'' 
    WHERE status_quantity = '''' 
    OR status_quantity = ''0.0'' 
    OR status_quantity = ''0'' 
    OR status_quantity IS NULL;

    -- Drop the temporary table
    DROP TABLE analytics.INVALID_ORDER_HEADER_KEY;

    -- Commit transaction
    COMMIT;

    RETURN ''Procedure executed successfully'';
    
EXCEPTION
    WHEN statement_error THEN
        -- Rollback transaction in case of an error
        ROLLBACK;

        -- Get the error message
        message := SQLERRM;
        
        -- Return the error message
        RETURN message;
END';
CREATE PROCEDURE "USP_ORDER_RELEASE_STATUS_PART2_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE analytics.log_files_import_status
SET processed = :processedRecordCount
WHERE file_name = ''YFS_ORDER_RELEASE_STATUS_PART2'' 
AND raw_table = ''raw_ORDER_release_status_part2'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
    

processedDate := CURRENT_TIMESTAMP();  

CREATE OR REPLACE TEMPORARY TABLE TempOrderReleaseStatus (
    order_release_status_key VARCHAR(16777216),
    order_release_key VARCHAR(16777216),
    order_line_key VARCHAR(16777216),
    order_header_key VARCHAR(16777216),
    status VARCHAR(16777216),
    status_date TIMESTAMP,
    status_quantity INT,
    pipeline_key VARCHAR(16777216),
    order_line_schedule_key VARCHAR(16777216),
    total_quantity INT,
    expected_shipment_date TIMESTAMP,
    chained_to_order_line_key VARCHAR(16777216),
    chained_to_order_header_key VARCHAR(16777216),
    createts TIMESTAMP,
    modifyts TIMESTAMP,
    createuserid VARCHAR(16777216),
    modifyuserid VARCHAR(16777216),
    createprogid VARCHAR(16777216),
    modifyprogid VARCHAR(16777216),
    lockid VARCHAR(16777216),
    inserted_date TIMESTAMP,
    modified_date TIMESTAMP,
    revision INT
);

MERGE INTO ANALYTICS.txn_order_release_status tors
USING (
    SELECT 
        stg.order_release_status_key,
        stg.order_release_key,
        stg.order_line_key,
        stg.order_header_key,
        stg.status,
        TRY_TO_TIMESTAMP(stg.status_date,''YYYYMMDDHHMISS'') AS status_date,    
        try_to_number(stg.status_quantity)  as status_quantity,  
        stg.pipeline_key,
        stg.order_line_schedule_key,
       try_to_number(stg.total_quantity) as total_quantity,
        TRY_TO_TIMESTAMP(stg.expected_shipment_date,''YYYYMMDDHHMISS'') as expected_shipment_date,
        stg.chained_to_order_line_key,
        stg.chained_to_order_header_key,
        TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'') as createts,    
        TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'') as modifyts,
        stg.createuserid,
        stg.modifyuserid,
        stg.createprogid,
        stg.modifyprogid,
        stg.lockid
    FROM TRANSFORMED.stg_ORDER_release_status_part2 stg
) sors
ON 
    tors.order_release_status_key = sors.order_release_status_key
    AND tors.order_line_key = sors.order_line_key
    AND tors.order_header_key = sors.order_header_key
WHEN MATCHED THEN
    UPDATE SET 
        tors.order_release_status_key = sors.order_release_status_key,
        tors.order_release_key = sors.order_release_key,
        tors.order_line_key = sors.order_line_key,
        tors.order_header_key = sors.order_header_key,
        tors.status = sors.status,
        tors.status_date = sors.status_date,
        tors.status_quantity = sors.status_quantity,
        tors.pipeline_key = sors.pipeline_key,
        tors.order_line_schedule_key = sors.order_line_schedule_key,
        tors.total_quantity = sors.total_quantity,
        tors.expected_shipment_date = sors.expected_shipment_date,
        tors.chained_to_order_line_key = sors.chained_to_order_line_key,
        tors.chained_to_order_header_key = sors.chained_to_order_header_key,
        tors.createts = sors.createts,
        tors.modifyts = sors.modifyts,
        tors.createuserid = sors.createuserid,
        tors.modifyuserid = sors.modifyuserid,
        tors.createprogid = sors.createprogid,
        tors.modifyprogid = sors.modifyprogid,
        tors.lockid = sors.lockid,
        tors.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        order_release_status_key,
        order_release_key,
        order_line_key,
        order_header_key,
        status,
        status_date,
        status_quantity,
        pipeline_key,
        order_line_schedule_key,
        total_quantity,
        expected_shipment_date,
        chained_to_order_line_key,
        chained_to_order_header_key,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        inserted_date
    )
    VALUES (
        sors.order_release_status_key,
        sors.order_release_key,
        sors.order_line_key,
        sors.order_header_key,
        sors.status,
        sors.status_date,
        sors.status_quantity,
        sors.pipeline_key,
        sors.order_line_schedule_key,
        sors.total_quantity,
        sors.expected_shipment_date,
        sors.chained_to_order_line_key,
        sors.chained_to_order_header_key,
        sors.createts,
        sors.modifyts,
        sors.createuserid,
        sors.modifyuserid,
        sors.createprogid,
        sors.modifyprogid,
        sors.lockid,
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempOrderReleaseStatus(
    order_release_status_key,
    order_release_key,
    order_line_key,
    order_header_key,
    status,
    status_date,
    status_quantity,
    pipeline_key,
    order_line_schedule_key,
    total_quantity,
    expected_shipment_date,
    chained_to_order_line_key,
    chained_to_order_header_key,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    Revision
)
SELECT 
    tors.order_release_status_key,
    tors.order_release_key,
    tors.order_line_key,
    tors.order_header_key,
    tors.status,
    tors.status_date,
    tors.status_quantity,
    tors.pipeline_key,
    tors.order_line_schedule_key,
    tors.total_quantity,
    tors.expected_shipment_date,
    tors.chained_to_order_line_key,
    tors.chained_to_order_header_key,
    tors.createts,
    tors.modifyts,
    tors.createuserid,
    tors.modifyuserid,
    tors.createprogid,
    tors.modifyprogid,
    tors.lockid,
    CURRENT_TIMESTAMP,
    1
FROM analytics.txn_order_release_status tors
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;

-- UPDATE TempOrderReleaseStatus
-- SET Revision = COALESCE(aot.revision, 0) + 1
-- FROM (
--     SELECT
--         MAX(aot.revision) AS revision,
--         aot.order_release_status_key,
--         aot.order_line_key,
--         aot.order_header_key
--     FROM ANALYTICS.audit_order_release_status AS aot
--     INNER JOIN TempOrderReleaseStatus AS ttd
--     ON ttd.order_release_status_key = aot.order_release_status_key
--     AND ttd.order_line_key = aot.order_line_key
--     AND ttd.order_header_key = aot.order_header_key
--     GROUP BY
--         aot.order_release_status_key,
--         aot.order_line_key,
--         aot.order_header_key
-- ) AS aot
-- WHERE TempOrderReleaseStatus.order_release_status_key = aot.order_release_status_key
-- AND TempOrderReleaseStatus.order_line_key = aot.order_line_key
-- AND TempOrderReleaseStatus.order_header_key = aot.order_header_key;


    
CREATE OR REPLACE TEMPORARY TABLE temp_max_revisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.order_release_status_key,         
    aot.order_line_key,
    aot.order_header_key
FROM
    ANALYTICS.audit_order_release_status AS aot
GROUP BY
    aot.order_release_status_key,         
    aot.order_line_key,
    aot.order_header_key;

UPDATE TempOrderReleaseStatus AS ttd
SET
    ttd.revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM
    temp_max_revisions AS aot
WHERE
    ttd.order_release_status_key = aot.order_release_status_key AND
    ttd.order_line_key = aot.order_line_key AND
    ttd.order_header_key = aot.order_header_key;

DROP TABLE IF EXISTS temp_max_revisions;

INSERT INTO ANALYTICS.audit_order_release_status (
    order_release_status_key,
    order_release_key,
    order_line_key,
    order_header_key,
    status,
    status_date,
    status_quantity,
    pipeline_key,
    order_line_schedule_key,
    total_quantity,
    expected_shipment_date,
    chained_to_order_line_key,
    chained_to_order_header_key,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    Revision
)
SELECT
    stg.order_release_status_key,
    stg.order_release_key,
    stg.order_line_key,
    stg.order_header_key,
    stg.status,
    TRY_TO_TIMESTAMP(stg.status_date,''YYYYMMDDHHMISS'') AS status_date,    
    try_to_number(stg.status_quantity)  as status_quantity, 
    stg.pipeline_key,
    stg.order_line_schedule_key,
    try_to_number(stg.total_quantity) as total_quantity,    
   TRY_TO_TIMESTAMP(stg.expected_shipment_date,''YYYYMMDDHHMISS'') as expected_shipment_date,
    stg.chained_to_order_line_key,
    stg.chained_to_order_header_key,
   TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'') as createts,    
   TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'') as modifyts, 
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    CURRENT_TIMESTAMP(),
    ord.Revision
FROM TRANSFORMED.stg_ORDER_release_status_part2 stg
INNER JOIN TempOrderReleaseStatus ord
ON ord.order_release_status_key = stg.order_release_status_key
AND ord.order_line_key = stg.order_line_key
AND ord.order_header_key = stg.order_header_key;

SELECT COUNT(*) INTO :processedRecordCount
FROM TempOrderReleaseStatus;

-- UPDATE RAW.raw_ORDER_release_status_part2 
-- SET
--     processing_status = ''Processed'',
--     processing_comment = '''',
--     processing_errortype = ''''
-- FROM RAW.raw_ORDER_release_status_part2 roh
-- INNER JOIN TRANSFORMED.stg_ORDER_release_status_part2 rod 
--     ON rod.ORDER_RELEASE_STATUS_KEY = roh.ORDER_RELEASE_STATUS_KEY
--     AND roh.modifyts = rod.modifyts
-- INNER JOIN TempOrderReleaseStatus tol 
--     ON tol.order_release_status_key = rod.ORDER_RELEASE_STATUS_KEY 
--     AND roh.modifyts = tol.modifyts
-- WHERE roh.processing_status IN (''Pending'', ''Failed'');

MERGE INTO RAW.raw_ORDER_release_status_part2 AS roh
USING (
    SELECT rod.ORDER_RELEASE_STATUS_KEY, rod.modifyts
    FROM TRANSFORMED.stg_ORDER_release_status_part2 AS rod
    INNER JOIN  TempOrderReleaseStatus AS tol 
        ON tol.order_release_status_key = rod.ORDER_RELEASE_STATUS_KEY 
        AND TO_TIMESTAMP(rod.modifyts,''YYYYMMDDHHMISS'') = tol.modifyts
) AS src
ON roh.ORDER_RELEASE_STATUS_KEY = src.ORDER_RELEASE_STATUS_KEY
AND roh.modifyts = src.modifyts
AND roh.processing_status IN (''Pending'', ''Failed'')
WHEN MATCHED THEN 
    UPDATE SET 
        roh.processing_status = ''Processed'',
        roh.processing_comment = '''',
        roh.processing_errortype = '''';


UPDATE ANALYTICS.log_files_import_status lofis
SET
    processed = :processedRecordCount,
    status = ''Success''
WHERE file_name = ''YFS_ORDER_RELEASE_STATUS_PART2''
AND raw_table = ''raw_ORDER_release_status_part2'';

DROP TABLE IF EXISTS TempOrderReleaseStatus;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;

COMMIT;
RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_RELEASE_STATUS_PART2'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	RETURN error_object;
END';
CREATE PROCEDURE "USP_ORDER_RELEASE_STATUS_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE TempOrderReleaseStatus (
   order_release_status_key STRING,
   order_release_key STRING,
   order_line_key STRING,
   order_header_key STRING,
   status STRING,
   status_date TIMESTAMP,
   status_quantity STRING,
   pipeline_key STRING,
   order_line_schedule_key STRING,
   total_quantity NUMBER,
   expected_shipment_date TIMESTAMP,
   chained_to_order_line_key STRING,
   chained_to_order_header_key STRING,
   createts TIMESTAMP,
   modifyts TIMESTAMP,
   createuserid STRING,
   modifyuserid STRING,
   createprogid STRING,
   modifyprogid STRING,
   lockid STRING,
   inserted_date TIMESTAMP,
   modified_date TIMESTAMP,
   revision INT
);

processedDate := CURRENT_TIMESTAMP();


MERGE INTO  ANALYTICS.txn_order_release_status tors
USING (
  SELECT 
   stg.order_release_status_key,    
   stg.order_release_key,    
   stg.order_line_key,    
   stg.order_header_key,    
   stg.status,    
   TRY_TO_TIMESTAMP(stg.status_date,''YYYYMMDDHHMISS'') AS status_date,    
   try_to_number(stg.status_quantity)  as status_quantity,    
   stg.pipeline_key,    
   stg.order_line_schedule_key,    
   try_to_number(stg.total_quantity) as total_quantity,    
   TRY_TO_TIMESTAMP(stg.expected_shipment_date,''YYYYMMDDHHMISS'') as expected_shipment_date,    
   stg.chained_to_order_line_key,    
   stg.chained_to_order_header_key,    
   TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'') as createts,    
   TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'') as modifyts,    
   stg.createuserid,    
   stg.modifyuserid,    
   stg.createprogid,    
   stg.modifyprogid,    
   stg.lockid  
  FROM TRANSFORMED.stg_order_release_status stg    
  INNER JOIN RAW.raw_order_release_status r  
    ON stg.order_release_status_key = r.order_release_status_key 
    AND stg.modifyts = r.modifyts 
    AND r.processing_status = ''Processed''
) sors    
ON 
  tors.order_release_status_key = sors.order_release_status_key
  AND tors.order_line_key = sors.order_line_key
  AND tors.order_header_key = sors.order_header_key
WHEN MATCHED THEN    
UPDATE SET     
  tors.order_release_status_key = sors.order_release_status_key,    
  tors.order_release_key = sors.order_release_key,    
  tors.order_line_key = sors.order_line_key,    
  tors.order_header_key = sors.order_header_key,    
  tors.status = sors.status,    
  tors.status_date = sors.status_date,    
  tors.status_quantity = sors.status_quantity,    
  tors.pipeline_key = sors.pipeline_key,    
  tors.order_line_schedule_key = sors.order_line_schedule_key,    
  tors.total_quantity = sors.total_quantity,    
  tors.expected_shipment_date = sors.expected_shipment_date,    
  tors.chained_to_order_line_key = sors.chained_to_order_line_key,    
  tors.chained_to_order_header_key = sors.chained_to_order_header_key,    
  tors.createts = sors.createts,    
  tors.modifyts = sors.modifyts,    
  tors.createuserid = sors.createuserid,    
  tors.modifyuserid = sors.modifyuserid,    
  tors.createprogid = sors.createprogid,    
  tors.modifyprogid = sors.modifyprogid,    
  tors.lockid = sors.lockid,    
  tors.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN    
INSERT (    
  order_release_status_key,    
  order_release_key,    
  order_line_key,    
  order_header_key,    
  status,    
  status_date,    
  status_quantity,    
  pipeline_key,    
  order_line_schedule_key,    
  total_quantity,    
  expected_shipment_date,    
  chained_to_order_line_key,    
  chained_to_order_header_key,    
  createts,    
  modifyts,    
  createuserid,    
  modifyuserid,    
  createprogid,    
  modifyprogid,    
  lockid,    
  inserted_date
)    
VALUES (    
  sors.order_release_status_key,    
  sors.order_release_key,    
  sors.order_line_key,    
  sors.order_header_key,    
  sors.status,    
  sors.status_date,    
  sors.status_quantity,    
  sors.pipeline_key,    
  sors.order_line_schedule_key,    
  sors.total_quantity,    
  sors.expected_shipment_date,    
  sors.chained_to_order_line_key,    
  sors.chained_to_order_header_key,    
  sors.createts,    
  sors.modifyts,    
  sors.createuserid,    
  sors.modifyuserid,    
  sors.createprogid,    
  sors.modifyprogid,    
  sors.lockid,    
  CURRENT_TIMESTAMP()
);

INSERT INTO TempOrderReleaseStatus (
  order_release_status_key,    
  order_release_key,    
  order_line_key,    
  order_header_key,    
  status,    
  status_date,    
  status_quantity,    
  pipeline_key,    
  order_line_schedule_key,    
  total_quantity,    
  expected_shipment_date,    
  chained_to_order_line_key,    
  chained_to_order_header_key,    
  createts,    
  modifyts,    
  createuserid,    
  modifyuserid,    
  createprogid,    
  modifyprogid,    
  lockid,    
  inserted_date,    
  Revision
)
SELECT 
  ins.order_release_status_key,    
  ins.order_release_key,    
  ins.order_line_key,    
  ins.order_header_key,    
  ins.status,    
  ins.status_date,    
  ins.status_quantity,    
  ins.pipeline_key,    
  ins.order_line_schedule_key,    
  ins.total_quantity,    
  ins.expected_shipment_date,    
  ins.chained_to_order_line_key,    
  ins.chained_to_order_header_key,    
  ins.createts,    
  ins.modifyts,    
  ins.createuserid,    
  ins.modifyuserid,    
  ins.createprogid,    
  ins.modifyprogid,    
  ins.lockid,    
  CURRENT_TIMESTAMP(),    
  1
FROM analytics.txn_order_release_status ins    
-- INNER JOIN RAW.raw_order_release_status r  
--   ON stg.order_release_status_key = r.order_release_status_key 
--   AND stg.modifyts = r.modifyts 
--   AND r.processing_status = ''Processed'';
where inserted_date >= :processedDate or modified_date >= :processedDate;


CREATE OR REPLACE TEMPORARY TABLE TempMaxRevisions AS 
SELECT
  MAX(aot.revision) AS revision,
  aot.order_release_status_key,
  aot.order_line_key,
  aot.order_header_key
FROM
    ANALYTICS.audit_order_release_status aot
  INNER JOIN TempOrderReleaseStatus ttd 
  ON ttd.order_release_status_key = aot.order_release_status_key
  AND ttd.order_line_key = aot.order_line_key
  AND ttd.order_header_key = aot.order_header_key
GROUP BY
  aot.order_release_status_key,
  aot.order_line_key,
  aot.order_header_key;


UPDATE TempOrderReleaseStatus ttd
SET
  ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS INT)
FROM
   TempMaxRevisions aot 
  where ttd.order_release_status_key = aot.order_release_status_key
  AND ttd.order_line_key = aot.order_line_key
  AND ttd.order_header_key = aot.order_header_key;

INSERT INTO  ANALYTICS.audit_order_release_status(
  order_release_status_key,    
  order_release_key,    
  order_line_key,    
  order_header_key,    
  status,    
  status_date,    
  status_quantity,    
  pipeline_key,    
  order_line_schedule_key,    
  total_quantity,    
  expected_shipment_date,    
  chained_to_order_line_key,    
  chained_to_order_header_key,    
  createts,    
  modifyts,    
  createuserid,    
  modifyuserid,    
  createprogid,    
  modifyprogid,    
  lockid,    
  inserted_date,    
  Revision    
)    
SELECT    
  stg.order_release_status_key,    
  stg.order_release_key,    
  stg.order_line_key,    
  stg.order_header_key,    
  stg.status,    
  TRY_TO_TIMESTAMP(stg.status_date,''YYYYMMDDHHMISS'') as status_date,    
  try_to_number(stg.status_quantity),    
  stg.pipeline_key,    
  stg.order_line_schedule_key,    
  try_to_number(stg.total_quantity),    
  TRY_TO_TIMESTAMP(stg.expected_shipment_date,''YYYYMMDDHHMISS'') as expected_shipment_date,    
  stg.chained_to_order_line_key,    
  stg.chained_to_order_header_key,    
  TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'') as createts,    
  TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'') as modifyts,    
  stg.createuserid,    
  stg.modifyuserid,    
  stg.createprogid,    
  stg.modifyprogid,    
  stg.lockid,    
  CURRENT_TIMESTAMP(),  
  ord.Revision    
FROM  TRANSFORMED.stg_order_release_status stg    
INNER JOIN RAW.raw_order_release_status r  
  ON stg.order_release_status_key = r.order_release_status_key  
  AND stg.modifyts = r.modifyts  
  AND r.processing_status = ''Processed''  
INNER JOIN TempOrderReleaseStatus ord     
  ON ord.order_release_status_key = stg.order_release_status_key  
  AND ord.order_line_key = stg.order_line_key  
  AND ord.order_header_key = stg.order_header_key;

MERGE INTO RAW.raw_order_release_status AS roh
USING (
    SELECT
        stg.order_release_status_key,
        stg.order_line_key,
        stg.order_header_key
    FROM TRANSFORMED.stg_order_release_status AS stg
    INNER JOIN ANALYTICS.txn_order_release_status AS toh
        ON stg.order_release_status_key = toh.order_release_status_key
        AND stg.order_line_key = toh.order_line_key
        AND stg.order_header_key = toh.order_header_key
) AS joined_data
ON roh.order_release_status_key = joined_data.order_release_status_key
   AND roh.order_line_key = joined_data.order_line_key
   AND roh.order_header_key = joined_data.order_header_key
WHEN MATCHED THEN
    UPDATE SET
        roh.processing_status = ''Processed'',
        roh.processing_comment = '''',
        roh.processing_errortype = '''';


DROP TABLE IF EXISTS TempOrderReleaseStatus;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);


COMMIT;

RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_RELEASE_STATUS'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
CREATE PROCEDURE "USP_ORDER_RELEASE_STATUS_UPSERT_MULTIPART"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
    -- Temporary table creation in Snowflake (Snowflake uses CTE or TEMP TABLE for temp storage)
    CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.TempOrderReleaseStatus(
        order_release_status_key STRING,    
        order_release_key STRING,    
        order_line_key STRING,    
        order_header_key STRING,    
        status STRING,    
        status_date TIMESTAMP,    
        status_quantity STRING,    
        pipeline_key STRING,    
        order_line_schedule_key STRING,    
        total_quantity STRING,    
        expected_shipment_date TIMESTAMP,    
        chained_to_order_line_key STRING,    
        chained_to_order_header_key STRING,    
        createts TIMESTAMP,    
        modifyts TIMESTAMP,    
        createuserid STRING,    
        modifyuserid STRING,    
        createprogid STRING,    
        modifyprogid STRING,    
        lockid STRING,    
        inserted_date TIMESTAMP,    
        modified_date TIMESTAMP,    
        revision NUMBER
    );

   processedDate := CURRENT_TIMESTAMP();

    -- MERGE statement in Snowflake
    MERGE INTO ANALYTICS.txn_order_release_status_multipart AS tors
    USING (
        SELECT 
            order_release_status_key,    
            order_release_key,    
            order_line_key,    
            order_header_key,    
            status,    
            TRY_TO_TIMESTAMP(status_date,''YYYYMMDDHHMISS'') as status_date,    
            try_to_number(status_quantity) as status_quantity,    
            pipeline_key,    
            order_line_schedule_key,    
            try_to_number(total_quantity) as total_quantity,    
            TRY_TO_TIMESTAMP(expected_shipment_date,''YYYYMMDDHHMISS'') as expected_shipment_date,    
            chained_to_order_line_key,    
            chained_to_order_header_key,    
            TRY_TO_TIMESTAMP(createts,''YYYYMMDDHHMISS'') as createts,    
            TRY_TO_TIMESTAMP(modifyts,''YYYYMMDDHHMISS'') as modifyts,    
            createuserid,    
            modifyuserid,    
            createprogid,    
            modifyprogid,    
            lockid
        FROM  transformed.stg_order_release_status_multipart
    ) AS sors
    ON tors.order_release_status_key = sors.order_release_status_key
    AND tors.order_line_key = sors.order_line_key
    AND tors.order_header_key = sors.order_header_key
    WHEN MATCHED THEN
        UPDATE SET
            tors.order_release_status_key = sors.order_release_status_key,    
            tors.order_release_key = sors.order_release_key,    
            tors.order_line_key = sors.order_line_key,    
            tors.order_header_key = sors.order_header_key,    
            tors.status = sors.status,    
            tors.status_date = sors.status_date,    
            tors.status_quantity = sors.status_quantity,    
            tors.pipeline_key = sors.pipeline_key,    
            tors.order_line_schedule_key = sors.order_line_schedule_key,    
            tors.total_quantity = sors.total_quantity,    
            tors.expected_shipment_date = sors.expected_shipment_date,    
            tors.chained_to_order_line_key = sors.chained_to_order_line_key,    
            tors.chained_to_order_header_key = sors.chained_to_order_header_key,    
            tors.createts = sors.createts,    
            tors.modifyts = sors.modifyts,    
            tors.createuserid = sors.createuserid,    
            tors.modifyuserid = sors.modifyuserid,    
            tors.createprogid = sors.createprogid,    
            tors.modifyprogid = sors.modifyprogid,    
            tors.lockid = sors.lockid,    
            tors.modified_date = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
            order_release_status_key,    
            order_release_key,    
            order_line_key,    
            order_header_key,    
            status,    
            status_date,    
            status_quantity,    
            pipeline_key,    
            order_line_schedule_key,    
            total_quantity,    
            expected_shipment_date,    
            chained_to_order_line_key,    
            chained_to_order_header_key,    
            createts,    
            modifyts,    
            createuserid,    
            modifyuserid,    
            createprogid,    
            modifyprogid,    
            lockid,    
            inserted_date
        )
        VALUES (
            sors.order_release_status_key,    
            sors.order_release_key,    
            sors.order_line_key,    
            sors.order_header_key,    
            sors.status,    
            sors.status_date,    
            sors.status_quantity,    
            sors.pipeline_key,    
            sors.order_line_schedule_key,    
            sors.total_quantity,    
            sors.expected_shipment_date,    
            sors.chained_to_order_line_key,    
            sors.chained_to_order_header_key,    
            sors.createts,    
            sors.modifyts,    
            sors.createuserid,    
            sors.modifyuserid,    
            sors.createprogid,    
            sors.modifyprogid,    
            sors.lockid,    
            CURRENT_TIMESTAMP()
        );
  insert into analytics.TempOrderReleaseStatus (    
    order_release_status_key,    
    order_release_key,    
    order_line_key,    
    order_header_key,    
    status,    
    status_date,    
    status_quantity,    
    pipeline_key,    
    order_line_schedule_key,    
    total_quantity,    
    expected_shipment_date,    
    chained_to_order_line_key,    
    chained_to_order_header_key,    
    createts,    
    modifyts,    
    createuserid,    
    modifyuserid,    
    createprogid,    
    modifyprogid,    
    lockid,    
    inserted_date,    
    Revision    
   )    
  select
    inserted.order_release_status_key,    
   inserted.order_release_key,    
   inserted.order_line_key,    
   inserted.order_header_key,    
   inserted.status,    
   inserted.status_date,    
   inserted.status_quantity,    
   inserted.pipeline_key,    
   inserted.order_line_schedule_key,    
   inserted.total_quantity,    
   inserted.expected_shipment_date,    
   inserted.chained_to_order_line_key,    
   inserted.chained_to_order_header_key,    
   inserted.createts,    
   inserted.modifyts,    
   inserted.createuserid,    
   inserted.modifyuserid,    
   inserted.createprogid,    
   inserted.modifyprogid,    
   inserted.lockid,    
   current_timestamp(),    
   1 
   from ANALYTICS.txn_order_release_status_multipart inserted
   where inserted_date >= :processedDate or modified_date >= :processedDate ;
    

    -- Updating the Temp table with revision info
   UPDATE analytics.TempOrderReleaseStatus ttd
SET 
    Revision = COALESCE((
        SELECT MAX(aot.revision)
        FROM analytics.audit_order_release_status_multipart aot
        WHERE ttd.order_release_status_key = aot.order_release_status_key
          AND ttd.order_line_key = aot.order_line_key
          AND ttd.order_header_key = aot.order_header_key
    ), 0) + 1
WHERE EXISTS (
    SELECT 1
    FROM analytics.audit_order_release_status_multipart aot
    WHERE ttd.order_release_status_key = aot.order_release_status_key
      AND ttd.order_line_key = aot.order_line_key
      AND ttd.order_header_key = aot.order_header_key
);


    -- Process update in raw_oms_order_release_status
   UPDATE raw.raw_order_release_status
SET 
    processing_status = ''Processed'',
    processing_comment = '''',
    processing_errortype = ''''
WHERE EXISTS (
    SELECT 1
    FROM transformed.stg_order_release_status_multipart stg
    WHERE stg.order_release_status_key = raw.raw_order_release_status.order_release_status_key
      AND stg.order_line_key = raw.raw_order_release_status.order_line_key
      AND stg.order_header_key = raw.raw_order_release_status.order_header_key
);


    -- Insert into audit_order_release_status_multipart
    INSERT INTO analytics.audit_order_release_status_multipart(
        order_release_status_key,    
        order_release_key,    
        order_line_key,    
        order_header_key,    
        status,    
        status_date,    
        status_quantity,    
        pipeline_key,    
        order_line_schedule_key,    
        total_quantity,    
        expected_shipment_date,    
        chained_to_order_line_key,    
        chained_to_order_header_key,    
        createts,    
        modifyts,    
        createuserid,    
        modifyuserid,    
        createprogid,    
        modifyprogid,    
        lockid,    
        inserted_date,    
        Revision
    )
    SELECT
        ord.order_release_status_key,    
        ord.order_release_key,    
        ord.order_line_key,    
        ord.order_header_key,    
        stg.status,    
        stg.status_date,    
        stg.status_quantity,    
        stg.pipeline_key,    
        stg.order_line_schedule_key,    
        stg.total_quantity,    
        stg.expected_shipment_date,    
        stg.chained_to_order_line_key,    
        stg.chained_to_order_header_key,    
        stg.createts,    
        stg.modifyts,    
        stg.createuserid,    
        stg.modifyuserid,    
        stg.createprogid,    
        stg.modifyprogid,    
        stg.lockid,    
        CURRENT_TIMESTAMP(),    
        ord.Revision
    FROM analytics.txn_order_release_status_multipart stg
    INNER JOIN analytics.TempOrderReleaseStatus ord
    ON ord.order_release_status_key = stg.order_release_status_key
    AND ord.order_line_key = stg.order_line_key
    AND ord.order_header_key = stg.order_header_key;

    -- Count processed records
    SELECT COUNT(*) INTO :processedRecordCount
    FROM analytics.TempOrderReleaseStatus;

    -- Drop the temp table
    DROP TABLE IF EXISTS analytics.TempOrderReleaseStatus;
CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);


COMMIT;

RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_RELEASE_STATUS_MULTIPART'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
CREATE PROCEDURE "USP_ORDER_RELEASE_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 
start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status 
SET 
    processed = :processedRecordCount,
    raw_table = ''raw_order_release''  -- Change to appropriate table name
WHERE file_name = ''YFS_ORDER_RELEASE'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );


MERGE INTO ANALYTICS.txn_order_release AS tor
USING (
    SELECT DISTINCT
        order_release_key,
        order_header_key,
        work_order_key,
        work_order_appt_key,
        release_no,
        merge_node,
        ship_to_key,
        shipnode_key,
        enterprise_key,
        buyer_organization_code,
        seller_organization_code,
        document_type,
        bill_to_id,
        ship_to_id,
        pick_list_no,
        scac,
        carrier_service_code,
        custcarrier_account_no,
        delivery_code,
        ship_advice_no,
        shipment_consol_group_id,
        packlist_type,
        sales_order_no,
        order_name,
        order_date,
        order_type,
        customer_po_no,
        mark_for_key,
        buyer_mark_for_node_id,
        cust_req_delivery_date,
        cust_req_ship_date,
        req_delivery_date,
        req_cancel_date,
        req_ship_date,
        priority_code,
        personalize_code,
        currency,
        hold_flag,
        hold_reason_code,
        fob,
        aor_flag,
        division,
        notify_after_shipment_flag,
        notification_type,
        notification_reference,
        ship_complete_flag,
        ship_node_class,
        supplier_code,
        supplier_name,
        release_seq_no,
        ship_order_complete,
        ship_line_complete,
        taxpayer_id,
        purpose,
        gift_flag,
        TRY_CAST(other_charges AS FLOAT) AS other_charges,
        receiving_node,
        buyer_receiving_node_id,
        delivery_method,
        pack_and_hold,
        department_code,
        item_classification,
        level_of_service,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        txn_id
    FROM TRANSFORMED.stg_order_release
) AS sor
ON (
    tor.order_release_key = sor.order_release_key
    AND tor.order_header_key = sor.order_header_key
)
WHEN MATCHED THEN
    UPDATE SET
        tor.order_release_key = sor.order_release_key,
        tor.order_header_key = sor.order_header_key,
        tor.work_order_key = sor.work_order_key,
        tor.work_order_appt_key = sor.work_order_appt_key,
        tor.release_no = sor.release_no,
        tor.merge_node = sor.merge_node,
        tor.ship_to_key = sor.ship_to_key,
        tor.shipnode_key = sor.shipnode_key,
        tor.enterprise_key = sor.enterprise_key,
        tor.buyer_organization_code = sor.buyer_organization_code,
        tor.seller_organization_code = sor.seller_organization_code,
        tor.document_type = sor.document_type,
        tor.bill_to_id = sor.bill_to_id,
        tor.ship_to_id = sor.ship_to_id,
        tor.pick_list_no = sor.pick_list_no,
        tor.scac = sor.scac,
        tor.carrier_service_code = sor.carrier_service_code,
        tor.custcarrier_account_no = sor.custcarrier_account_no,
        tor.delivery_code = sor.delivery_code,
        tor.ship_advice_no = sor.ship_advice_no,
        tor.shipment_consol_group_id = sor.shipment_consol_group_id,
        tor.packlist_type = sor.packlist_type,
        tor.sales_order_no = sor.sales_order_no,
        tor.order_name = sor.order_name,
        tor.order_date = TRY_TO_TIMESTAMP(sor.order_date,''YYYYMMDDHHMISS''),
        tor.order_type = sor.order_type,
        tor.customer_po_no = sor.customer_po_no,
        tor.mark_for_key = sor.mark_for_key,
        tor.buyer_mark_for_node_id = sor.buyer_mark_for_node_id,
        tor.cust_req_delivery_date = TRY_TO_TIMESTAMP(sor.cust_req_delivery_date,''YYYYMMDDHHMISS''),
        tor.cust_req_ship_date = TRY_TO_TIMESTAMP(sor.cust_req_ship_date,''YYYYMMDDHHMISS''),
        tor.req_delivery_date = TRY_TO_TIMESTAMP(sor.req_delivery_date,''YYYYMMDDHHMISS''),
        tor.req_cancel_date = TRY_TO_TIMESTAMP(sor.req_cancel_date,''YYYYMMDDHHMISS''),
        tor.req_ship_date = TRY_TO_TIMESTAMP(sor.req_ship_date,''YYYYMMDDHHMISS''),
        tor.priority_code = sor.priority_code,
        tor.personalize_code = sor.personalize_code,
        tor.currency = sor.currency,
        tor.hold_flag = sor.hold_flag,
        tor.hold_reason_code = sor.hold_reason_code,
        tor.fob = sor.fob,
        tor.aor_flag = sor.aor_flag,
        tor.division = sor.division,
        tor.notify_after_shipment_flag = sor.notify_after_shipment_flag,
        tor.notification_type = sor.notification_type,
        tor.notification_reference = sor.notification_reference,
        tor.ship_complete_flag = sor.ship_complete_flag,
        tor.ship_node_class = sor.ship_node_class,
        tor.supplier_code = sor.supplier_code,
        tor.supplier_name = sor.supplier_name,
        tor.release_seq_no = sor.release_seq_no,
        tor.ship_order_complete = sor.ship_order_complete,
        tor.ship_line_complete = sor.ship_line_complete,
        tor.taxpayer_id = sor.taxpayer_id,
        tor.purpose = sor.purpose,
        tor.gift_flag = sor.gift_flag,
        tor.other_charges = sor.other_charges,
        tor.receiving_node = sor.receiving_node,
        tor.buyer_receiving_node_id = sor.buyer_receiving_node_id,
        tor.delivery_method = sor.delivery_method,
        tor.pack_and_hold = sor.pack_and_hold,
        tor.department_code = sor.department_code,
        tor.item_classification = sor.item_classification,
        tor.level_of_service = sor.level_of_service,
        tor.createts = TRY_TO_TIMESTAMP(sor.createts,''YYYYMMDDHHMISS''),
        tor.modifyts = TRY_TO_TIMESTAMP(sor.modifyts,''YYYYMMDDHHMISS''),
        tor.createuserid = sor.createuserid,
        tor.modifyuserid = sor.modifyuserid,
        tor.createprogid = sor.createprogid,
        tor.modifyprogid = sor.modifyprogid,
        tor.lockid = sor.lockid,
        tor.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        order_release_key,
        order_header_key,
        work_order_key,
        work_order_appt_key,
        release_no,
        merge_node,
        ship_to_key,
        shipnode_key,
        enterprise_key,
        buyer_organization_code,
        seller_organization_code,
        document_type,
        bill_to_id,
        ship_to_id,
        pick_list_no,
        scac,
        carrier_service_code,
        custcarrier_account_no,
        delivery_code,
        ship_advice_no,
        shipment_consol_group_id,
        packlist_type,
        sales_order_no,
        order_name,
        order_date,
        order_type,
        customer_po_no,
        mark_for_key,
        buyer_mark_for_node_id,
        cust_req_delivery_date,
        cust_req_ship_date,
        req_delivery_date,
        req_cancel_date,
        req_ship_date,
        priority_code,
        personalize_code,
        currency,
        hold_flag,
        hold_reason_code,
        fob,
        aor_flag,
        division,
        notify_after_shipment_flag,
        notification_type,
        notification_reference,
        ship_complete_flag,
        ship_node_class,
        supplier_code,
        supplier_name,
        release_seq_no,
        ship_order_complete,
        ship_line_complete,
        taxpayer_id,
        purpose,
        gift_flag,
        other_charges,
        receiving_node,
        buyer_receiving_node_id,
        delivery_method,
        pack_and_hold,
        department_code,
        item_classification,
        level_of_service,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        inserted_date
    ) VALUES (
        sor.order_release_key,
        sor.order_header_key,
        sor.work_order_key,
        sor.work_order_appt_key,
        sor.release_no,
        sor.merge_node,
        sor.ship_to_key,
        sor.shipnode_key,
        sor.enterprise_key,
        sor.buyer_organization_code,
        sor.seller_organization_code,
        sor.document_type,
        sor.bill_to_id,
        sor.ship_to_id,
        sor.pick_list_no,
        sor.scac,
        sor.carrier_service_code,
        sor.custcarrier_account_no,
        sor.delivery_code,
        sor.ship_advice_no,
        sor.shipment_consol_group_id,
        sor.packlist_type,
        sor.sales_order_no,
        sor.order_name,
        TRY_TO_TIMESTAMP(sor.order_date,''YYYYMMDDHHMISS''),
        sor.order_type,
        sor.customer_po_no,
        sor.mark_for_key,
        sor.buyer_mark_for_node_id,
        TRY_TO_TIMESTAMP(sor.cust_req_delivery_date,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(sor.cust_req_ship_date,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(sor.req_delivery_date,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(sor.req_cancel_date,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(sor.req_ship_date,''YYYYMMDDHHMISS''),
        sor.priority_code,
        sor.personalize_code,
        sor.currency,
        sor.hold_flag,
        sor.hold_reason_code,
        sor.fob,
        sor.aor_flag,
        sor.division,
        sor.notify_after_shipment_flag,
        sor.notification_type,
        sor.notification_reference,
        sor.ship_complete_flag,
        sor.ship_node_class,
        sor.supplier_code,
        sor.supplier_name,
        sor.release_seq_no,
        sor.ship_order_complete,
        sor.ship_line_complete,
        sor.taxpayer_id,
        sor.purpose,
        sor.gift_flag,
        sor.other_charges,
        sor.receiving_node,
        sor.buyer_receiving_node_id,
        sor.delivery_method,
        sor.pack_and_hold,
        sor.department_code,
        sor.item_classification,
        sor.level_of_service,
        TRY_TO_TIMESTAMP(sor.createts,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(sor.modifyts,''YYYYMMDDHHMISS''),
        sor.createuserid,
        sor.modifyuserid,
        sor.createprogid,
        sor.modifyprogid,
        sor.lockid,
        CURRENT_TIMESTAMP()
    );

CREATE OR REPLACE TEMPORARY TABLE insertedOrderReleaseRecords AS
SELECT order_release_key
    , order_header_key
    , txn_id 
    , CAST(1 AS INT)  as revision
FROM TRANSFORMED.stg_order_release
;

-- Create a temporary table to hold the revisions
CREATE OR REPLACE TEMPORARY TABLE temp_revisions AS
SELECT
    MAX(aot.revision) as revision,
    aot.order_release_key,
    aot.order_header_key
FROM
    ANALYTICS.audit_order_release aot
    INNER JOIN insertedOrderReleaseRecords ttd
    ON ttd.order_release_key = aot.order_release_key
    AND ttd.order_header_key = aot.order_header_key 
GROUP BY
    aot.order_release_key, aot.order_header_key;

-- Update the temporary table with new revisions
UPDATE insertedOrderReleaseRecords ttd
SET ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS INT)
FROM temp_revisions aot
WHERE ttd.order_release_key = aot.order_release_key
AND ttd.order_header_key = aot.order_header_key;

INSERT INTO ANALYTICS.audit_order_release (
    order_release_key,
    order_header_key,
    work_order_key,
    work_order_appt_key,
    release_no,
    merge_node,
    ship_to_key,
    shipnode_key,
    enterprise_key,
    buyer_organization_code,
    seller_organization_code,
    document_type,
    bill_to_id,
    ship_to_id,
    pick_list_no,
    scac,
    carrier_service_code,
    custcarrier_account_no,
    delivery_code,
    ship_advice_no,
    shipment_consol_group_id,
    packlist_type,
    sales_order_no,
    order_name,
    order_date,
    order_type,
    customer_po_no,
    mark_for_key,
    buyer_mark_for_node_id,
    cust_req_delivery_date,
    cust_req_ship_date,
    req_delivery_date,
    req_cancel_date,
    req_ship_date,
    priority_code,
    personalize_code,
    currency,
    hold_flag,
    hold_reason_code,
    fob,
    aor_flag,
    division,
    notify_after_shipment_flag,
    notification_type,
    notification_reference,
    ship_complete_flag,
    ship_node_class,
    supplier_code,
    supplier_name,
    release_seq_no,
    ship_order_complete,
    ship_line_complete,
    taxpayer_id,
    purpose,
    gift_flag,
    other_charges,
    receiving_node,
    buyer_receiving_node_id,
    delivery_method,
    pack_and_hold,
    department_code,
    item_classification,
    level_of_service,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    revision
)
SELECT
    sor.order_release_key,
    sor.order_header_key,
    sor.work_order_key,
    sor.work_order_appt_key,
    sor.release_no,
    sor.merge_node,
    sor.ship_to_key,
    sor.shipnode_key,
    sor.enterprise_key,
    sor.buyer_organization_code,
    sor.seller_organization_code,
    sor.document_type,
    sor.bill_to_id,
    sor.ship_to_id,
    sor.pick_list_no,
    sor.scac,
    sor.carrier_service_code,
    sor.custcarrier_account_no,
    sor.delivery_code,
    sor.ship_advice_no,
    sor.shipment_consol_group_id,
    sor.packlist_type,
    sor.sales_order_no,
    sor.order_name,
    TRY_TO_TIMESTAMP(sor.order_date,''YYYYMMDDHHMISS''),
    sor.order_type,
    sor.customer_po_no,
    sor.mark_for_key,
    sor.buyer_mark_for_node_id,
    TRY_TO_TIMESTAMP(sor.cust_req_delivery_date,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(sor.cust_req_ship_date,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(sor.req_delivery_date,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(sor.req_cancel_date,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(sor.req_ship_date,''YYYYMMDDHHMISS''),
    sor.priority_code,
    sor.personalize_code,
    sor.currency,
    sor.hold_flag,
    sor.hold_reason_code,
    sor.fob,
    sor.aor_flag,
    sor.division,
    sor.notify_after_shipment_flag,
    sor.notification_type,
    sor.notification_reference,
    sor.ship_complete_flag,
    sor.ship_node_class,
    sor.supplier_code,
    sor.supplier_name,
    sor.release_seq_no,
    sor.ship_order_complete,
    sor.ship_line_complete,
    sor.taxpayer_id,
    sor.purpose,
    sor.gift_flag,
    try_cast(sor.other_charges as float),
    sor.receiving_node,
    sor.buyer_receiving_node_id,
    sor.delivery_method,
    sor.pack_and_hold,
    sor.department_code,
    sor.item_classification,
    sor.level_of_service,
    TRY_TO_TIMESTAMP(sor.createts,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(sor.modifyts,''YYYYMMDDHHMISS''),
    sor.createuserid,
    sor.modifyuserid,
    sor.createprogid,
    sor.modifyprogid,
    sor.lockid,
    CURRENT_TIMESTAMP(), -- Snowflake function to get current timestamp
    ord.revision
FROM TRANSFORMED.stg_order_release sor
INNER JOIN insertedOrderReleaseRecords ord ON ord.order_release_key = sor.order_release_key
AND ord.order_header_key = sor.order_header_key;

MERGE INTO RAW.raw_order_release roor
USING insertedOrderReleaseRecords torr
ON roor.order_release_key = torr.order_release_key 
    AND roor.order_header_key = torr.order_header_key 
    AND roor.txn_id = torr.txn_id
WHEN MATCHED THEN 
UPDATE SET 
    roor.processing_status = ''Processed'',
    roor.processing_comment = '''',
    roor.processing_errortype = '''';

SELECT COUNT(*) INTO :processedRecordCount
FROM insertedOrderReleaseRecords;

SELECT COUNT(*) INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_order_release;

UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
WHERE
    file_name = ''YFS_ORDER_RELEASE'';

DROP TABLE IF EXISTS insertedOrderReleaseRecords;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);


COMMIT;

RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_RELEASE'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
CREATE or replace PROCEDURE "USP_ORDER_SHIPMENT_CONTAINER_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE analytics.log_files_import_status
SET processed = :processedRecordCount,
    raw_table = ''raw_order_shipment_container''
WHERE file_name = ''YFS_SHIPMENT_CONTAINER'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );


CREATE OR REPLACE TEMPORARY TABLE insertedShipmentContainerRecords
(
    shipment_key STRING, 
    shipment_container_key STRING, 
    order_header_key STRING, 
    txn_id STRING,
    revision INT
);

MERGE INTO  ANALYTICS.txn_order_shipment_container AS tsc
USING (
    SELECT DISTINCT
        shipment_container_key,
        manifest_key,
        shipment_key,
        load_key,
        pipeline_key,
        status,
        document_type,
        order_header_key,
        order_release_key,
        ship_to_key,
        container_seq_no,
        tracking_no,
        cod_return_tracking_no,
        TRY_CAST(cod_amount AS FLOAT) AS cod_amount,
        ucc128code,
        manifest_no,
        container_scm,
        container_epc,
        container_type,
        corrugation_item_key,
        TRY_CAST(container_length AS FLOAT) AS container_length,
        TRY_CAST(container_width AS FLOAT) AS container_width,
        TRY_CAST(container_height AS FLOAT) AS container_height,
        TRY_CAST(container_gross_weight AS FLOAT) AS container_gross_weight,
        TRY_CAST(container_net_weight AS FLOAT) AS container_net_weight,
        container_length_uom,
        container_height_uom,
        container_width_uom,
        container_gross_weight_uom,
        container_net_weight_uom,
        applied_weight_uom,
        has_other_containers,
        master_container_no,
        TRY_CAST(actual_freight_charge AS FLOAT) AS  actual_freight_charge,
        scac,
        ship_date,
        ship_mode,
        zone,
        oversized_flag,
        dimmed_flag,
        carrier_bill_account,
        carrier_payment_type,
        astra_code,
        routing_code,
        service_type,
        carrier_location_id,
        carrier_service_code,
        TRY_CAST(applied_weight AS FLOAT) AS  applied_weight,
        TRY_CAST(actual_weight AS FLOAT) AS  actual_weight,
        actual_weight_uom,
        commitment_code,
        delivery_day,
        deliver_by,
        form_id,
        TRY_CAST(basic_freight_charge AS FLOAT) AS basic_freight_charge,
        TRY_CAST(special_services_surcharge AS FLOAT) AS special_services_surcharge,
        delivery_code,
        TRY_CAST(barcode_discount AS FLOAT) AS barcode_discount,
        TRY_CAST(discount_amount AS FLOAT) AS discount_amount,
        TRY_CAST(customs_value AS FLOAT) AS customs_value,
        TRY_CAST(carriage_value AS FLOAT) AS carriage_value,
        TRY_CAST(declared_value AS FLOAT) AS declared_value,
        export_license_no,
        export_license_exp_date,
        freight_terms,
        custcarrier_account_no,
        container_no,
        parent_container_key,
        parent_container_no,
        container_group,
        parent_container_group,
        is_received,
        is_pack_process_complete,
        status_date,
        used_during_pick,
        system_suggested,
        contains_std_qty,
        task_type,
        service_item_id,
        is_hazmat,
        required_no_of_return_labels,
        actual_no_of_return_labels,
        external_reference_1,
        is_manifested,
        lockid,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        wave_key,
        extn_return_label,
        extn_return_bol,
        txn_id
    FROM TRANSFORMED.stg_order_shipment_container
) AS ssc
ON (
    tsc.shipment_container_key = ssc.shipment_container_key
)
WHEN MATCHED THEN
    UPDATE SET
        tsc.shipment_container_key = ssc.shipment_container_key,
        tsc.manifest_key = ssc.manifest_key,
        tsc.shipment_key = ssc.shipment_key,
        tsc.load_key = ssc.load_key,
        tsc.pipeline_key = ssc.pipeline_key,
        tsc.status = ssc.status,
        tsc.document_type = ssc.document_type,
        tsc.order_header_key = ssc.order_header_key,
        tsc.order_release_key = ssc.order_release_key,
        tsc.ship_to_key = ssc.ship_to_key,
        tsc.container_seq_no = ssc.container_seq_no,
        tsc.tracking_no = ssc.tracking_no,
        tsc.cod_return_tracking_no = ssc.cod_return_tracking_no,
        tsc.cod_amount = ssc.cod_amount,
        tsc.ucc128code = ssc.ucc128code,
        tsc.manifest_no = ssc.manifest_no,
        tsc.container_scm = ssc.container_scm,
        tsc.container_epc = ssc.container_epc,
        tsc.container_type = ssc.container_type,
        tsc.corrugation_item_key = ssc.corrugation_item_key,
        tsc.container_length = ssc.container_length,
        tsc.container_width = ssc.container_width,
        tsc.container_height = ssc.container_height,
        tsc.container_gross_weight = ssc.container_gross_weight,
        tsc.container_net_weight = ssc.container_net_weight,
        tsc.container_length_uom = ssc.container_length_uom,
        tsc.container_height_uom = ssc.container_height_uom,
        tsc.container_width_uom = ssc.container_width_uom,
        tsc.container_gross_weight_uom = ssc.container_gross_weight_uom,
        tsc.container_net_weight_uom = ssc.container_net_weight_uom,
        tsc.applied_weight_uom = ssc.applied_weight_uom,
        tsc.has_other_containers = ssc.has_other_containers,
        tsc.master_container_no = ssc.master_container_no,
        tsc.actual_freight_charge = ssc.actual_freight_charge,
        tsc.scac = ssc.scac,
        tsc.ship_date = TRY_TO_TIMESTAMP(ssc.ship_date,''YYYYMMDDHHMISS''),
        tsc.ship_mode = ssc.ship_mode,
        tsc.zone = ssc.zone,
        tsc.oversized_flag = ssc.oversized_flag,
        tsc.dimmed_flag = ssc.dimmed_flag,
        tsc.carrier_bill_account = ssc.carrier_bill_account,
        tsc.carrier_payment_type = ssc.carrier_payment_type,
        tsc.astra_code = ssc.astra_code,
        tsc.routing_code = ssc.routing_code,
        tsc.service_type = ssc.service_type,
        tsc.carrier_location_id = ssc.carrier_location_id,
        tsc.carrier_service_code = ssc.carrier_service_code,
        tsc.applied_weight = ssc.applied_weight,
        tsc.actual_weight = ssc.actual_weight,
        tsc.actual_weight_uom = ssc.actual_weight_uom,
        tsc.commitment_code = ssc.commitment_code,
        tsc.delivery_day = ssc.delivery_day,
        tsc.deliver_by = ssc.deliver_by,
        tsc.form_id = ssc.form_id,
        tsc.basic_freight_charge = ssc.basic_freight_charge,
        tsc.special_services_surcharge = ssc.special_services_surcharge,
        tsc.delivery_code = ssc.delivery_code,
        tsc.barcode_discount = ssc.barcode_discount,
        tsc.discount_amount = ssc.discount_amount,
        tsc.customs_value = ssc.customs_value,
        tsc.carriage_value = ssc.carriage_value,
        tsc.declared_value = ssc.declared_value,
        tsc.export_license_no = ssc.export_license_no,
        tsc.export_license_exp_date = TRY_TO_TIMESTAMP(ssc.export_license_exp_date,''YYYYMMDDHHMISS''),
        tsc.freight_terms = ssc.freight_terms,
        tsc.custcarrier_account_no = ssc.custcarrier_account_no,
        tsc.container_no = ssc.container_no,
        tsc.parent_container_key = ssc.parent_container_key,
        tsc.parent_container_no = ssc.parent_container_no,
        tsc.container_group = ssc.container_group,
        tsc.parent_container_group = ssc.parent_container_group,
        tsc.is_received = ssc.is_received,
        tsc.is_pack_process_complete = ssc.is_pack_process_complete,
        tsc.status_date = TRY_TO_TIMESTAMP(ssc.status_date,''YYYYMMDDHHMISS''),
        tsc.used_during_pick = ssc.used_during_pick,
        tsc.system_suggested = ssc.system_suggested,
        tsc.contains_std_qty = ssc.contains_std_qty,
        tsc.task_type = ssc.task_type,
        tsc.service_item_id = ssc.service_item_id,
        tsc.is_hazmat = ssc.is_hazmat,
        tsc.required_no_of_return_labels = ssc.required_no_of_return_labels,
        tsc.actual_no_of_return_labels = ssc.actual_no_of_return_labels,
        tsc.external_reference_1 = ssc.external_reference_1,
        tsc.is_manifested = ssc.is_manifested,
        tsc.lockid = ssc.lockid,
        tsc.createts = TRY_TO_TIMESTAMP(ssc.createts,''YYYYMMDDHHMISS''),
        tsc.modifyts = TRY_TO_TIMESTAMP(ssc.modifyts,''YYYYMMDDHHMISS''),
        tsc.createuserid = ssc.createuserid,
        tsc.modifyuserid = ssc.modifyuserid,
        tsc.createprogid = ssc.createprogid,
        tsc.modifyprogid = ssc.modifyprogid,
        tsc.wave_key = ssc.wave_key,
        tsc.extn_return_label = ssc.extn_return_label,
        tsc.extn_return_bol = ssc.extn_return_bol,
        tsc.modified_date = CURRENT_TIMESTAMP
WHEN NOT MATCHED
THEN
    INSERT (
        shipment_container_key,
        manifest_key,
        shipment_key,
        load_key,
        pipeline_key,
        status,
        document_type,
        order_header_key,
        order_release_key,
        ship_to_key,
        container_seq_no,
        tracking_no,
        cod_return_tracking_no,
        cod_amount,
        ucc128code,
        manifest_no,
        container_scm,
        container_epc,
        container_type,
        corrugation_item_key,
        container_length,
        container_width,
        container_height,
        container_gross_weight,
        container_net_weight,
        container_length_uom,
        container_height_uom,
        container_width_uom,
        container_gross_weight_uom,
        container_net_weight_uom,
        applied_weight_uom,
        has_other_containers,
        master_container_no,
        actual_freight_charge,
        scac,
        ship_date,
        ship_mode,
        zone,
        oversized_flag,
        dimmed_flag,
        carrier_bill_account,
        carrier_payment_type,
        astra_code,
        routing_code,
        service_type,
        carrier_location_id,
        carrier_service_code,
        applied_weight,
        actual_weight,
        actual_weight_uom,
        commitment_code,
        delivery_day,
        deliver_by,
        form_id,
        basic_freight_charge,
        special_services_surcharge,
        delivery_code,
        barcode_discount,
        discount_amount,
        customs_value,
        carriage_value,
        declared_value,
        export_license_no,
        export_license_exp_date,
        freight_terms,
        custcarrier_account_no,
        container_no,
        parent_container_key,
        parent_container_no,
        container_group,
        parent_container_group,
        is_received,
        is_pack_process_complete,
        status_date,
        used_during_pick,
        system_suggested,
        contains_std_qty,
        task_type,
        service_item_id,
        is_hazmat,
        required_no_of_return_labels,
        actual_no_of_return_labels,
        external_reference_1,
        is_manifested,
        lockid,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        wave_key,
        extn_return_label,
        extn_return_bol,
        inserted_date
    )
    VALUES (
        ssc.shipment_container_key,
        ssc.manifest_key,
        ssc.shipment_key,
        ssc.load_key,
        ssc.pipeline_key,
        ssc.status,
        ssc.document_type,
        ssc.order_header_key,
        ssc.order_release_key,
        ssc.ship_to_key,
        ssc.container_seq_no,
        ssc.tracking_no,
        ssc.cod_return_tracking_no,
        ssc.cod_amount,
        ssc.ucc128code,
        ssc.manifest_no,
        ssc.container_scm,
        ssc.container_epc,
        ssc.container_type,
        ssc.corrugation_item_key,
        ssc.container_length,
        ssc.container_width,
        ssc.container_height,
        ssc.container_gross_weight,
        ssc.container_net_weight,
        ssc.container_length_uom,
        ssc.container_height_uom,
        ssc.container_width_uom,
        ssc.container_gross_weight_uom,
        ssc.container_net_weight_uom,
        ssc.applied_weight_uom,
        ssc.has_other_containers,
        ssc.master_container_no,
        ssc.actual_freight_charge,
        ssc.scac,
        TRY_TO_TIMESTAMP(ssc.ship_date,''YYYYMMDDHHMISS''),
        ssc.ship_mode,
        ssc.zone,
        ssc.oversized_flag,
        ssc.dimmed_flag,
        ssc.carrier_bill_account,
        ssc.carrier_payment_type,
        ssc.astra_code,
        ssc.routing_code,
        ssc.service_type,
        ssc.carrier_location_id,
        ssc.carrier_service_code,
        ssc.applied_weight,
        ssc.actual_weight,
        ssc.actual_weight_uom,
        ssc.commitment_code,
        ssc.delivery_day,
        ssc.deliver_by,
        ssc.form_id,
        ssc.basic_freight_charge,
        ssc.special_services_surcharge,
        ssc.delivery_code,
        ssc.barcode_discount,
        ssc.discount_amount,
        ssc.customs_value,
        ssc.carriage_value,
        ssc.declared_value,
        ssc.export_license_no,
        TRY_TO_TIMESTAMP(ssc.export_license_exp_date,''YYYYMMDDHHMISS''),
        ssc.freight_terms,
        ssc.custcarrier_account_no,
        ssc.container_no,
        ssc.parent_container_key,
        ssc.parent_container_no,
        ssc.container_group,
        ssc.parent_container_group,
        ssc.is_received,
        ssc.is_pack_process_complete,
        TRY_TO_TIMESTAMP(ssc.status_date,''YYYYMMDDHHMISS''),
        ssc.used_during_pick,
        ssc.system_suggested,
        ssc.contains_std_qty,
        ssc.task_type,
        ssc.service_item_id,
        ssc.is_hazmat,
        ssc.required_no_of_return_labels,
        ssc.actual_no_of_return_labels,
        ssc.external_reference_1,
        ssc.is_manifested,
        ssc.lockid,
        TRY_TO_TIMESTAMP(ssc.createts,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(ssc.modifyts,''YYYYMMDDHHMISS''),
        ssc.createuserid,
        ssc.modifyuserid,
        ssc.createprogid,
        ssc.modifyprogid,
        ssc.wave_key,
        ssc.extn_return_label,
        ssc.extn_return_bol,
        CURRENT_TIMESTAMP
    );


INSERT INTO insertedShipmentContainerRecords
SELECT inserted.shipment_key,
		inserted.shipment_container_key,
		inserted.order_header_key,
		inserted.txn_id,
		1
FROM TRANSFORMED.STG_order_SHIPMENT_CONTAINER inserted;

CREATE OR REPLACE TEMPORARY TABLE temp_max_revision AS
SELECT
    aot.shipment_container_key,
    MAX(aot.revision) AS max_revision
FROM
    analytics.audit_order_shipment_container aot
INNER JOIN
    insertedShipmentContainerRecords ttd
    ON ttd.shipment_container_key = aot.shipment_container_key
GROUP BY
    aot.shipment_container_key;


UPDATE insertedShipmentContainerRecords ttd
SET ttd.Revision = CAST((COALESCE(tmr.max_revision, 0) + 1) AS INT)
FROM temp_max_revision tmr
WHERE ttd.shipment_container_key = tmr.shipment_container_key;

-- Insert data into audit_order_shipment_container
INSERT INTO ANALYTICS.audit_order_shipment_container (
    shipment_container_key,
    manifest_key,
    shipment_key,
    load_key,
    pipeline_key,
    status,
    document_type,
    order_header_key,
    order_release_key,
    ship_to_key,
    container_seq_no,
    tracking_no,
    cod_return_tracking_no,
    cod_amount,
    ucc128code,
    manifest_no,
    container_scm,
    container_epc,
    container_type,
    corrugation_item_key,
    container_length,
    container_width,
    container_height,
    container_gross_weight,
    container_net_weight,
    container_length_uom,
    container_height_uom,
    container_width_uom,
    container_gross_weight_uom,
    container_net_weight_uom,
    applied_weight_uom,
    has_other_containers,
    master_container_no,
    actual_freight_charge,
    scac,
    ship_date,
    ship_mode,
    zone,
    oversized_flag,
    dimmed_flag,
    carrier_bill_account,
    carrier_payment_type,
    astra_code,
    routing_code,
    service_type,
    carrier_location_id,
    carrier_service_code,
    applied_weight,
    actual_weight,
    actual_weight_uom,
    commitment_code,
    delivery_day,
    deliver_by,
    form_id,
    basic_freight_charge,
    special_services_surcharge,
    delivery_code,
    barcode_discount,
    discount_amount,
    customs_value,
    carriage_value,
    declared_value,
    export_license_no,
    export_license_exp_date,
    freight_terms,
    custcarrier_account_no,
    container_no,
    parent_container_key,
    parent_container_no,
    container_group,
    parent_container_group,
    is_received,
    is_pack_process_complete,
    status_date,
    used_during_pick,
    system_suggested,
    contains_std_qty,
    task_type,
    service_item_id,
    is_hazmat,
    required_no_of_return_labels,
    actual_no_of_return_labels,
    external_reference_1,
    is_manifested,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    wave_key,
    extn_return_label,
    extn_return_bol,
    inserted_date,
    revision
)
SELECT
    ssc.shipment_container_key,
    ssc.manifest_key,
    ssc.shipment_key,
    ssc.load_key,
    ssc.pipeline_key,
    ssc.status,
    ssc.document_type,
    ssc.order_header_key,
    ssc.order_release_key,
    ssc.ship_to_key,
    ssc.container_seq_no,
    ssc.tracking_no,
    ssc.cod_return_tracking_no,
    TRY_CAST(ssc.cod_amount AS FLOAT) AS cod_amount,
    ssc.ucc128code,
    ssc.manifest_no,
    ssc.container_scm,
    ssc.container_epc,
    ssc.container_type,
    ssc.corrugation_item_key,
    TRY_CAST(ssc.container_length AS FLOAT) AS container_length,
    TRY_CAST(ssc.container_width AS FLOAT) AS container_width,
    TRY_CAST(ssc.container_height AS FLOAT) AS container_height,
    TRY_CAST(ssc.container_gross_weight AS FLOAT) AS container_gross_weight,
    TRY_CAST(ssc.container_net_weight AS FLOAT) AS container_net_weight,
    ssc.container_length_uom,
    ssc.container_height_uom,
    ssc.container_width_uom,
    ssc.container_gross_weight_uom,
    ssc.container_net_weight_uom,
    ssc.applied_weight_uom,
    ssc.has_other_containers,
    ssc.master_container_no,
    TRY_CAST(ssc.actual_freight_charge AS FLOAT) AS  actual_freight_charge,
    ssc.scac,
    TRY_TO_TIMESTAMP(ssc.ship_date,''YYYYMMDDHHMISS''),
    ssc.ship_mode,
    ssc.zone,
    ssc.oversized_flag,
    ssc.dimmed_flag,
    ssc.carrier_bill_account,
    ssc.carrier_payment_type,
    ssc.astra_code,
    ssc.routing_code,
    ssc.service_type,
    ssc.carrier_location_id,
    ssc.carrier_service_code,
    TRY_CAST(ssc.applied_weight AS FLOAT) AS  applied_weight,
    TRY_CAST(ssc.actual_weight AS FLOAT) AS  actual_weight,
    ssc.actual_weight_uom,
    ssc.commitment_code,
    ssc.delivery_day,
    ssc.deliver_by,
    ssc.form_id,
    TRY_CAST(ssc.basic_freight_charge AS FLOAT) AS basic_freight_charge,
    TRY_CAST(ssc.special_services_surcharge AS FLOAT) AS special_services_surcharge,
    delivery_code,
    TRY_CAST(ssc.barcode_discount AS FLOAT) AS barcode_discount,
    TRY_CAST(ssc.discount_amount AS FLOAT) AS discount_amount,
    TRY_CAST(ssc.customs_value AS FLOAT) AS customs_value,
    TRY_CAST(ssc.carriage_value AS FLOAT) AS carriage_value,
    TRY_CAST(ssc.declared_value AS FLOAT) AS declared_value,
    ssc.export_license_no,
    TRY_TO_TIMESTAMP(ssc.export_license_exp_date,''YYYYMMDDHHMISS''),
    ssc.freight_terms,
    ssc.custcarrier_account_no,
    ssc.container_no,
    ssc.parent_container_key,
    ssc.parent_container_no,
    ssc.container_group,
    ssc.parent_container_group,
    ssc.is_received,
    ssc.is_pack_process_complete,
    TRY_TO_TIMESTAMP(ssc.status_date,''YYYYMMDDHHMISS''),
    ssc.used_during_pick,
    ssc.system_suggested,
    ssc.contains_std_qty,
    ssc.task_type,
    ssc.service_item_id,
    ssc.is_hazmat,
    ssc.required_no_of_return_labels,
    ssc.actual_no_of_return_labels,
    ssc.external_reference_1,
    ssc.is_manifested,
    ssc.lockid,
    TRY_TO_TIMESTAMP(ssc.createts,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(ssc.modifyts,''YYYYMMDDHHMISS''),
    ssc.createuserid,
    ssc.modifyuserid,
    ssc.createprogid,
    ssc.modifyprogid,
    ssc.wave_key,
    ssc.extn_return_label,
    ssc.extn_return_bol,
    CURRENT_TIMESTAMP(),  -- Replacing GETDATE() with CURRENT_TIMESTAMP()
    ord.revision
FROM
    TRANSFORMED.stg_order_shipment_container ssc
INNER JOIN
    insertedShipmentContainerRecords ord
    ON ord.shipment_container_key = ssc.shipment_container_key;

-- Use MERGE statement to update records
MERGE INTO RAW.raw_order_shipment_container AS rosc
USING (
    SELECT 
        shipment_key, 
        shipment_container_key, 
        txn_id
    FROM 
        insertedShipmentContainerRecords
) AS tosc
ON (
    rosc.shipment_key = tosc.shipment_key 
    AND rosc.shipment_container_key = tosc.shipment_container_key
    AND rosc.txn_id = tosc.txn_id
)
WHEN MATCHED THEN
    UPDATE SET
        rosc.processing_status = ''Processed'',
        rosc.processing_comment = '''',
        rosc.processing_errortype = '''';

SELECT COUNT(*)
INTO :processedRecordCount
FROM insertedShipmentContainerRecords;

SELECT COUNT(*)
INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_order_shipment_container;

-- Update the log_files_import_status table with the processed and to-be-processed counts
UPDATE analytics.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
WHERE
    file_name = ''YFS_SHIPMENT_CONTAINER'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_SHIPMENT_CONTAINER'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
CREATE PROCEDURE "USP_ORDER_SHIPMENT_LINE_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE analytics.log_files_import_status
SET processed = :processedRecordCount,
    raw_table = ''raw_ORDER_shipment''
WHERE file_name = ''YFS_SHIPMENT_LINE'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE insertedShipmentLineRecords
(
    shipment_key STRING, 
    shipment_line_key STRING, 
    order_header_key STRING, 
    txn_id STRING,
    revision INT
);

processedDate := current_timestamp();

MERGE INTO ANALYTICS.txn_order_shipment_line tsl
USING (
SELECT DISTINCT shipment_line_key
			,shipment_key
			,shipment_line_no
			,shipment_sub_line_no
			,parent_shipment_line_key
			,order_header_key
			,order_release_key
			,order_line_key
			,order_no
			,release_no
			,prime_line_no
			,sub_line_no
			,item_id
			,product_class
			,uom
			,TRY_CAST(net_weight AS FLOAT) AS net_weight
			,net_weight_uom
			,country_of_origin
			,fifo_no
			,TRY_TO_NUMBER(quantity) AS quantity
			,TRY_TO_NUMBER(over_ship_quantity) AS over_ship_quantity
			,TRY_TO_NUMBER(original_quantity) AS original_quantity
			,TRY_TO_NUMBER(kit_qty) AS kit_qty
			,requested_tag_number
			,requested_serial_no
			,item_description
			,segment
			,segment_type
			,shortage_qty
			,customer_po_no
			,customer_po_line_no
			,mark_for_key
			,buyer_mark_for_node_id
			,order_type
			,shipment_consol_group_id
			,ship_to_customer_id
			,kit_code
			,is_pickable
			,department_code
			,gift_flag
			,external_release_identifier
			,is_hazmat
			,return_shipping_label_level
			,level_of_service
			,pick_location
			,pick_location_seq
			,group_sequence_num
			,lockid
			,createts
			,modifyts
			,createuserid
			,modifyuserid
			,createprogid
			,modifyprogid
			,wave_no
			,TRY_TO_NUMBER(backroom_picked_qty) AS backroom_picked_qty
			,TRY_TO_NUMBER(customer_picked_qty) AS customer_picked_qty
			,shortage_resolution_reason
			,cancel_reason
			,is_pack_complete
			,backroom_pick_complete
			,is_customer_pick_complete
			,staging_complete
			,TRY_TO_NUMBER(staged_qty) AS staged_qty
			,store_batch_key
			,batch_pick_priority
			,store_batch_location_key
			,txn_id
FROM TRANSFORMED.stg_ORDER_shipment_line
) ssl
ON
	tsl.shipment_line_key = ssl.shipment_line_key AND
	tsl.shipment_key = ssl.shipment_key
WHEN MATCHED THEN
    UPDATE SET
tsl.shipment_line_key=ssl.shipment_line_key
			,tsl.shipment_key=ssl.shipment_key
			,tsl.shipment_line_no=ssl.shipment_line_no
			,tsl.shipment_sub_line_no=ssl.shipment_sub_line_no
			,tsl.parent_shipment_line_key=ssl.parent_shipment_line_key
			,tsl.order_header_key=ssl.order_header_key
			,tsl.order_release_key=ssl.order_release_key
			,tsl.order_line_key=ssl.order_line_key
			,tsl.order_no=ssl.order_no
			,tsl.release_no=ssl.release_no
			,tsl.prime_line_no=ssl.prime_line_no
			,tsl.sub_line_no=ssl.sub_line_no
			,tsl.item_id=ssl.item_id
			,tsl.product_class=ssl.product_class
			,tsl.uom=ssl.uom
			,tsl.net_weight=ssl.net_weight
			,tsl.net_weight_uom=ssl.net_weight_uom
			,tsl.country_of_origin=ssl.country_of_origin
			,tsl.fifo_no=ssl.fifo_no
			,tsl.quantity=ssl.quantity
			,tsl.over_ship_quantity=ssl.over_ship_quantity
			,tsl.original_quantity=ssl.original_quantity
			,tsl.kit_qty=ssl.kit_qty
			,tsl.requested_tag_number=ssl.requested_tag_number
			,tsl.requested_serial_no=ssl.requested_serial_no
			,tsl.item_description=ssl.item_description
			,tsl.segment=ssl.segment
			,tsl.segment_type=ssl.segment_type
			,tsl.shortage_qty=ssl.shortage_qty
			,tsl.customer_po_no=ssl.customer_po_no
			,tsl.customer_po_line_no=ssl.customer_po_line_no
			,tsl.mark_for_key=ssl.mark_for_key
			,tsl.buyer_mark_for_node_id=ssl.buyer_mark_for_node_id
			,tsl.order_type=ssl.order_type
			,tsl.shipment_consol_group_id=ssl.shipment_consol_group_id
			,tsl.ship_to_customer_id=ssl.ship_to_customer_id
			,tsl.kit_code=ssl.kit_code
			,tsl.is_pickable=ssl.is_pickable
			,tsl.department_code=ssl.department_code
			,tsl.gift_flag=ssl.gift_flag
			,tsl.external_release_identifier=ssl.external_release_identifier
			,tsl.is_hazmat=ssl.is_hazmat
			,tsl.return_shipping_label_level=ssl.return_shipping_label_level
			,tsl.level_of_service=ssl.level_of_service
			,tsl.pick_location=ssl.pick_location
			,tsl.pick_location_seq=ssl.pick_location_seq
			,tsl.group_sequence_num=ssl.group_sequence_num
			,tsl.lockid=ssl.lockid
			,tsl.createts=TRY_TO_TIMESTAMP(ssl.createts,''YYYYMMDDHHMISS'') 
			,tsl.modifyts=TRY_TO_TIMESTAMP(ssl.modifyts,''YYYYMMDDHHMISS'') 
			,tsl.createuserid=ssl.createuserid
			,tsl.modifyuserid=ssl.modifyuserid
			,tsl.createprogid=ssl.createprogid
			,tsl.modifyprogid=ssl.modifyprogid
			,tsl.wave_no=ssl.wave_no
			,tsl.backroom_picked_qty=ssl.backroom_picked_qty
			,tsl.customer_picked_qty=ssl.customer_picked_qty
			,tsl.shortage_resolution_reason=ssl.shortage_resolution_reason
			,tsl.cancel_reason=ssl.cancel_reason
			,tsl.is_pack_complete=ssl.is_pack_complete
			,tsl.backroom_pick_complete=ssl.backroom_pick_complete
			,tsl.is_customer_pick_complete=ssl.is_customer_pick_complete
			,tsl.staging_complete=ssl.staging_complete
			,tsl.staged_qty=ssl.staged_qty
			,tsl.store_batch_key=ssl.store_batch_key
			,tsl.batch_pick_priority=ssl.batch_pick_priority
			,tsl.store_batch_location_key=ssl.store_batch_location_key
			,tsl.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
shipment_line_key
		,shipment_key
		,shipment_line_no
		,shipment_sub_line_no
		,parent_shipment_line_key
		,order_header_key
		,order_release_key
		,order_line_key
		,order_no
		,release_no
		,prime_line_no
		,sub_line_no
		,item_id
		,product_class
		,uom
		,net_weight
		,net_weight_uom
		,country_of_origin
		,fifo_no
		,quantity
		,over_ship_quantity
		,original_quantity
		,kit_qty
		,requested_tag_number
		,requested_serial_no
		,item_description
		,segment
		,segment_type
		,shortage_qty
		,customer_po_no
		,customer_po_line_no
		,mark_for_key
		,buyer_mark_for_node_id
		,order_type
		,shipment_consol_group_id
		,ship_to_customer_id
		,kit_code
		,is_pickable
		,department_code
		,gift_flag
		,external_release_identifier
		,is_hazmat
		,return_shipping_label_level
		,level_of_service
		,pick_location
		,pick_location_seq
		,group_sequence_num
		,lockid
		,createts
		,modifyts
		,createuserid
		,modifyuserid
		,createprogid
		,modifyprogid
		,wave_no
		,backroom_picked_qty
		,customer_picked_qty
		,shortage_resolution_reason
		,cancel_reason
		,is_pack_complete
		,backroom_pick_complete
		,is_customer_pick_complete
		,staging_complete
		,staged_qty
		,store_batch_key
		,batch_pick_priority
		,store_batch_location_key
		,inserted_date
    )
VALUES (
ssl.shipment_line_key
		,ssl.shipment_key
		,ssl.shipment_line_no
		,ssl.shipment_sub_line_no
		,ssl.parent_shipment_line_key
		,ssl.order_header_key
		,ssl.order_release_key
		,ssl.order_line_key
		,ssl.order_no
		,ssl.release_no
		,ssl.prime_line_no
		,ssl.sub_line_no
		,ssl.item_id
		,ssl.product_class
		,ssl.uom
		,ssl.net_weight
		,ssl.net_weight_uom
		,ssl.country_of_origin
		,ssl.fifo_no
		,ssl.quantity
		,ssl.over_ship_quantity
		,ssl.original_quantity
		,ssl.kit_qty
		,ssl.requested_tag_number
		,ssl.requested_serial_no
		,ssl.item_description
		,ssl.segment
		,ssl.segment_type
		,ssl.shortage_qty
		,ssl.customer_po_no
		,ssl.customer_po_line_no
		,ssl.mark_for_key
		,ssl.buyer_mark_for_node_id
		,ssl.order_type
		,ssl.shipment_consol_group_id
		,ssl.ship_to_customer_id
		,ssl.kit_code
		,ssl.is_pickable
		,ssl.department_code
		,ssl.gift_flag
		,ssl.external_release_identifier
		,ssl.is_hazmat
		,ssl.return_shipping_label_level
		,ssl.level_of_service
		,ssl.pick_location
		,ssl.pick_location_seq
		,ssl.group_sequence_num
		,ssl.lockid
		,TRY_TO_TIMESTAMP(ssl.createts,''YYYYMMDDHHMISS'') 
		,TRY_TO_TIMESTAMP(ssl.modifyts,''YYYYMMDDHHMISS'')
		,ssl.createuserid
		,ssl.modifyuserid
		,ssl.createprogid
		,ssl.modifyprogid
		,ssl.wave_no
		,ssl.backroom_picked_qty
		,ssl.customer_picked_qty
		,ssl.shortage_resolution_reason
		,ssl.cancel_reason
		,ssl.is_pack_complete
		,ssl.backroom_pick_complete
		,ssl.is_customer_pick_complete
		,ssl.staging_complete
		,ssl.staged_qty
		,ssl.store_batch_key
		,ssl.batch_pick_priority
		,ssl.store_batch_location_key
		,CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TEMPORARY TABLE insertedShipmentLineRecords AS 
SELECT inserted.shipment_key,
		inserted.shipment_line_key,
		inserted.order_header_key,
		ssl.txn_id,
		1 as revision
FROM ANALYTICS.txn_order_shipment_line inserted 
    INNER JOIN TRANSFORMED.STG_ORDER_SHIPMENT_LINE ssl 
        ON inserted.shipment_line_key = ssl.shipment_line_key AND
    	inserted.shipment_key = ssl.shipment_key
WHERE inserted.inserted_date > :processedDate or inserted.modified_date > :processedDate
;

-- UPDATE insertedShipmentLineRecords
-- SET Revision = CAST((IFNULL(aot.revision, 0) + 1) AS INTEGER)
-- FROM insertedShipmentLineRecords ttd
-- INNER JOIN (
--     SELECT
--         MAX(aot.revision) AS revision,
--         aot.shipment_line_key,
--         aot.shipment_key
--     FROM audit_order_shipment_line aot
--     INNER JOIN insertedShipmentLineRecords ttd 
--     ON ttd.shipment_line_key = aot.shipment_line_key 
--     AND ttd.shipment_key = aot.shipment_key 
--     GROUP BY aot.shipment_line_key, aot.shipment_key
-- ) aot 
-- ON ttd.shipment_line_key = aot.shipment_line_key 
-- AND ttd.shipment_key = aot.shipment_key;

CREATE OR REPLACE TEMPORARY TABLE temp_max_revisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.shipment_line_key,
    aot.shipment_key
FROM
    ANALYTICS.audit_order_shipment_line AS aot
GROUP BY
    aot.shipment_line_key,
    aot.shipment_key;

UPDATE insertedShipmentLineRecords AS ttd
SET
    ttd.revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM
    temp_max_revisions AS aot
WHERE
    ttd.shipment_line_key = aot.shipment_line_key AND
    ttd.shipment_key = aot.shipment_key;

DROP TABLE IF EXISTS temp_max_revisions;

INSERT INTO ANALYTICS.audit_order_shipment_line (
    shipment_line_key,
    shipment_key,
    shipment_line_no,
    shipment_sub_line_no,
    parent_shipment_line_key,
    order_header_key,
    order_release_key,
    order_line_key,
    order_no,
    release_no,
    prime_line_no,
    sub_line_no,
    item_id,
    product_class,
    uom,
    net_weight,
    net_weight_uom,
    country_of_origin,
    fifo_no,
    quantity,
    over_ship_quantity,
    original_quantity,
    kit_qty,
    requested_tag_number,
    requested_serial_no,
    item_description,
    segment,
    segment_type,
    shortage_qty,
    customer_po_no,
    customer_po_line_no,
    mark_for_key,
    buyer_mark_for_node_id,
    order_type,
    shipment_consol_group_id,
    ship_to_customer_id,
    kit_code,
    is_pickable,
    department_code,
    gift_flag,
    external_release_identifier,
    is_hazmat,
    return_shipping_label_level,
    level_of_service,
    pick_location,
    pick_location_seq,
    group_sequence_num,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    wave_no,
    backroom_picked_qty,
    customer_picked_qty,
    shortage_resolution_reason,
    cancel_reason,
    is_pack_complete,
    backroom_pick_complete,
    is_customer_pick_complete,
    staging_complete,
    staged_qty,
    store_batch_key,
    batch_pick_priority,
    store_batch_location_key,
    inserted_date,
    revision
)
SELECT
    ssl.shipment_line_key,
    ssl.shipment_key,
    ssl.shipment_line_no,
    ssl.shipment_sub_line_no,
    ssl.parent_shipment_line_key,
    ssl.order_header_key,
    ssl.order_release_key,
    ssl.order_line_key,
    ssl.order_no,
    ssl.release_no,
    ssl.prime_line_no,
    ssl.sub_line_no,
    ssl.item_id,
    ssl.product_class,
    ssl.uom,
    TRY_CAST(ssl.net_weight AS FLOAT),
    ssl.net_weight_uom,
    ssl.country_of_origin,
    ssl.fifo_no,
    TRY_TO_NUMBER(ssl.quantity),
    TRY_TO_NUMBER(ssl.over_ship_quantity),
    TRY_TO_NUMBER(ssl.original_quantity),
    TRY_TO_NUMBER(ssl.kit_qty),
    ssl.requested_tag_number,
    ssl.requested_serial_no,
    ssl.item_description,
    ssl.segment,
    ssl.segment_type,
    TRY_TO_NUMBER(ssl.shortage_qty),
    ssl.customer_po_no,
    ssl.customer_po_line_no,
    ssl.mark_for_key,
    ssl.buyer_mark_for_node_id,
    ssl.order_type,
    ssl.shipment_consol_group_id,
    ssl.ship_to_customer_id,
    ssl.kit_code,
    ssl.is_pickable,
    ssl.department_code,
    ssl.gift_flag,
    ssl.external_release_identifier,
    ssl.is_hazmat,
    ssl.return_shipping_label_level,
    ssl.level_of_service,
    ssl.pick_location,
    ssl.pick_location_seq,
    ssl.group_sequence_num,
    ssl.lockid,
    TRY_TO_TIMESTAMP(ssl.createts,''YYYYMMDDHHMISS'') ,
    TRY_TO_TIMESTAMP(ssl.modifyts,''YYYYMMDDHHMISS'') ,
    ssl.createuserid,
    ssl.modifyuserid,
    ssl.createprogid,
    ssl.modifyprogid,
    ssl.wave_no,
    TRY_TO_NUMBER(ssl.backroom_picked_qty),
    TRY_TO_NUMBER(ssl.customer_picked_qty),
    ssl.shortage_resolution_reason,
    ssl.cancel_reason,
    ssl.is_pack_complete,
    ssl.backroom_pick_complete,
    ssl.is_customer_pick_complete,
    ssl.staging_complete,
    TRY_TO_NUMBER(ssl.staged_qty),
    ssl.store_batch_key,
    ssl.batch_pick_priority,
    ssl.store_batch_location_key,
    CURRENT_TIMESTAMP,
    ord.revision
FROM TRANSFORMED.stg_ORDER_shipment_line ssl
INNER JOIN insertedShipmentLineRecords ord 
ON ord.shipment_line_key = ssl.shipment_line_key 
AND ord.shipment_key = ssl.shipment_key;

UPDATE RAW.raw_ORDER_shipment_line
SET 
    processing_status = ''Processed'',
    processing_comment = '''',
    processing_errortype = ''''
FROM insertedShipmentLineRecords AS tosl
WHERE 
    tosl.shipment_key = RAW.raw_ORDER_shipment_line.shipment_key 
    AND tosl.shipment_line_key = RAW.raw_ORDER_shipment_line.shipment_line_key 
    AND tosl.order_header_key = RAW.raw_ORDER_shipment_line.order_header_key 
    AND tosl.txn_id = RAW.raw_ORDER_shipment_line.txn_id;

SELECT COUNT(*) INTO :processedRecordCount FROM insertedShipmentLineRecords;

SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM TRANSFORMED.stg_ORDER_shipment_line;

UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
WHERE
    file_name = ''YFS_SHIPMENT_LINE'';

DROP TABLE IF EXISTS insertedShipmentLineRecords;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_SHIPMENT_LINE'';
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
CREATE PROCEDURE "USP_ORDER_SHIPMENT_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE analytics.log_files_import_status
SET processed = :processedRecordCount,
    raw_table = ''raw_ORDER_shipment''
WHERE file_name = ''YFS_SHIPMENT'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.txn_order_shipment ts
USING (
    SELECT DISTINCT
        shipment_key,
        pick_list_no,
        original_shipment_key,
        merge_node,
        pickticket_no,
        ship_date,
        TRY_TO_NUMBER(unplaced_quantity) AS unplaced_quantity,
        shipnode_key,
        receiving_node,
        buyer_receiving_node_id,
        shipment_consol_group_id,
        ship_mode,
        from_address_key,
        to_address_key,
        bill_to_address_key,
        ship_to_customer_id,
        bill_to_customer_id,
        has_other_shipments,
        parent_shipment_key,
        ship_via,
        seal_no,
        tracking_no,
        trailer_no,
        manifest_no,
        pro_no,
        scac,
        TRY_CAST(actual_freight_charge AS FLOAT) AS actual_freight_charge,
        carrier_service_code,
        requested_carrier_service_code,
        status,
        pod_no,
        bol_no,
        TRY_CAST(total_weight AS FLOAT) AS total_weight,
        total_weight_uom,
        TRY_CAST(total_volume AS FLOAT ) AS total_volume,
        total_volume_uom,
        TRY_TO_NUMBER(total_quantity) AS total_quantity,
        TRY_TO_NUMBER(containerized_quantity) AS containerized_quantity,
        TRY_TO_NUMBER(placed_quantity) AS placed_quantity,
        is_product_placing_complete,
        is_pack_process_complete,
        is_revised,
        hold_flag,
        it_no,
        it_date,
        appointment_no,
        from_appointment,
        to_appointment,
        delivery_ts,
        code,
        TRY_TO_NUMBER(num_of_pallets) AS num_of_pallets,
        TRY_TO_NUMBER(num_of_cartons) AS num_of_cartons,
        export_taxpayer_id,
        freight_terms,
        delivery_code,
        carrier_type,
        download_count,
        currency,
        delivery_plan_key,
        shipment_no,
        pipeline_key,
        gift_flag,
        shipment_planned_flag,
        shipment_closed_flag,
        seller_organization_code,
        buyer_organization_code,
        enterprise_code,
        requested_shipment_date,
        expected_shipment_date,
        actual_shipment_date,
        requested_delivery_date,
        expected_delivery_date,
        actual_delivery_date,
        return_by_date,
        return_authorization_number,
        document_type,
        origin_zone,
        destination_zone,
        status_date,
        shipment_type,
        commercial_value,
        hazardous_material_flag,
        total_estimated_charge,
        total_actual_charge,
        next_alert_ts,
        shipment_confirm_updates_done,
        shipment_deliver_updates_done,
        shipment_containerized_flag,
        scac_integration_required,
        packlist_type,
        custcarrier_account_no,
        manifest_key,
        is_single_order,
        lines_entered,
        order_available_on_system,
        override_manual_shipment_entry,
        do_not_verify_pallet_content,
        do_not_verify_case_content,
        allow_overage,
        manually_entered,
        allow_new_item_receipt,
        order_no,
        order_header_key,
        release_no,
        order_release_key,
        export_license_no,
        export_license_exp_date,
        delivery_method,
        requires_appt_confirmation,
        work_order_key,
        work_order_appt_key,
        order_type,
        do_not_consolidate,
        department_code,
        item_classification,
        mark_for_key,
        buyer_mark_for_node_id,
        routing_contact_info,
        customer_po_no,
        TRY_TO_TIMESTAMP(carrier_pickup_time,''YYYYMMDDHHMISS'') AS carrier_pickup_time,
        pack_and_hold,
        esp_check_required,
        is_appointment_reqd,
        routing_source,
        routing_error_code,
        routing_guide_maintained,
        must_ship_before_date,
        priority_code,
        estimated_price,
        has_node_exceptions,
        cod_pay_method,
        airway_bill_no,
        invoice_complete,
        expected_pick_date,
        return_carrier_service,
        return_freight_terms,
        return_billing_account,
        break_bulk_node,
        TRY_CAST(bbn_min_weight AS FLOAT) AS bbn_min_weight,
        TRY_CAST(bbn_min_volume AS FLOAT) AS bbn_min_volume,
        fedx_open_ship_index,
        itn_no,
        email_return_label,
        profile_id,
        profileid_provided_by_sterling,
        level_of_service,
        hold_location,
        assigned_to_user_id,
        lockid,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        shipment_sort_location_id,
        carrier_sort_location_id,
        shipment_group_id,
        notification_sent,
        pickticket_printed,
        backroom_pick_required,
        included_in_batch,
        is_receiving_complete,
        received_damaged,
        index_version,
        extn_narvar_url,
        extn_is_sent,
        extn_is_email_sent,
        txn_id
    FROM TRANSFORMED.stg_ORDER_shipment
) ss
ON ts.shipment_key = ss.shipment_key
WHEN MATCHED THEN
    UPDATE SET
        ts.shipment_key = ss.shipment_key,
        ts.pick_list_no = ss.pick_list_no,
        ts.original_shipment_key = ss.original_shipment_key,
        ts.merge_node = ss.merge_node,
        ts.pickticket_no = ss.pickticket_no,
        ts.ship_date = TRY_TO_TIMESTAMP(ss.ship_date,''YYYYMMDDHHMISS''),
        ts.unplaced_quantity = ss.unplaced_quantity,
        ts.shipnode_key = ss.shipnode_key,
        ts.receiving_node = ss.receiving_node,
        ts.buyer_receiving_node_id = ss.buyer_receiving_node_id,
        ts.shipment_consol_group_id = ss.shipment_consol_group_id,
        ts.ship_mode = ss.ship_mode,
        ts.from_address_key = ss.from_address_key,
        ts.to_address_key = ss.to_address_key,
        ts.bill_to_address_key = ss.bill_to_address_key,
        ts.ship_to_customer_id = ss.ship_to_customer_id,
        ts.bill_to_customer_id = ss.bill_to_customer_id,
        ts.has_other_shipments = ss.has_other_shipments,
        ts.parent_shipment_key = ss.parent_shipment_key,
        ts.ship_via = ss.ship_via,
        ts.seal_no = ss.seal_no,
        ts.tracking_no = ss.tracking_no,
        ts.trailer_no = ss.trailer_no,
        ts.manifest_no = ss.manifest_no,
        ts.pro_no = ss.pro_no,
        ts.scac = ss.scac,
        ts.actual_freight_charge = ss.actual_freight_charge,
        ts.carrier_service_code = ss.carrier_service_code,
        ts.requested_carrier_service_code = ss.requested_carrier_service_code,
        ts.status = ss.status,
        ts.pod_no = ss.pod_no,
        ts.bol_no = ss.bol_no,
        ts.total_weight = ss.total_weight,
        ts.total_weight_uom = ss.total_weight_uom,
        ts.total_volume = ss.total_volume,
        ts.total_volume_uom = ss.total_volume_uom,
        ts.total_quantity = ss.total_quantity,
        ts.containerized_quantity = ss.containerized_quantity,
        ts.placed_quantity = ss.placed_quantity,
        ts.is_product_placing_complete = ss.is_product_placing_complete,
        ts.is_pack_process_complete = ss.is_pack_process_complete,
        ts.is_revised = ss.is_revised,
        ts.hold_flag = ss.hold_flag,
        ts.it_no = ss.it_no,
        ts.it_date = TRY_TO_TIMESTAMP(ss.it_date,''YYYYMMDDHHMISS''),
        ts.appointment_no = ss.appointment_no,
        ts.from_appointment = ss.from_appointment,
        ts.to_appointment = ss.to_appointment,
        ts.delivery_ts = TRY_TO_TIMESTAMP(ss.delivery_ts,''YYYYMMDDHHMISS''),
        ts.code = ss.code,
        ts.num_of_pallets = ss.num_of_pallets,
        ts.num_of_cartons = ss.num_of_cartons,
        ts.export_taxpayer_id = ss.export_taxpayer_id,
        ts.freight_terms = ss.freight_terms,
        ts.delivery_code = ss.delivery_code,
        ts.carrier_type = ss.carrier_type,
        ts.download_count = ss.download_count,
        ts.currency = ss.currency,
        ts.delivery_plan_key = ss.delivery_plan_key,
        ts.shipment_no = ss.shipment_no,
        ts.pipeline_key = ss.pipeline_key,
        ts.gift_flag = ss.gift_flag,
        ts.shipment_planned_flag = ss.shipment_planned_flag,
        ts.shipment_closed_flag = ss.shipment_closed_flag,
        ts.seller_organization_code = ss.seller_organization_code,
        ts.buyer_organization_code = ss.buyer_organization_code,
        ts.enterprise_code = ss.enterprise_code,
        ts.requested_shipment_date = TRY_TO_TIMESTAMP(ss.requested_shipment_date,''YYYYMMDDHHMISS''),
        ts.expected_shipment_date = TRY_TO_TIMESTAMP(ss.expected_shipment_date,''YYYYMMDDHHMISS''),
        ts.actual_shipment_date = TRY_TO_TIMESTAMP(ss.actual_shipment_date,''YYYYMMDDHHMISS''),
        ts.requested_delivery_date = TRY_TO_TIMESTAMP(ss.requested_delivery_date,''YYYYMMDDHHMISS''),
        ts.expected_delivery_date = TRY_TO_TIMESTAMP(ss.expected_delivery_date,''YYYYMMDDHHMISS''),
        ts.actual_delivery_date = TRY_TO_TIMESTAMP(ss.actual_delivery_date,''YYYYMMDDHHMISS''),
        ts.return_by_date = TRY_TO_TIMESTAMP(ss.return_by_date,''YYYYMMDDHHMISS''),
        ts.return_authorization_number = ss.return_authorization_number,
        ts.document_type = ss.document_type,
        ts.origin_zone = ss.origin_zone,
        ts.destination_zone = ss.destination_zone,
        ts.status_date = TRY_TO_TIMESTAMP(ss.status_date,''YYYYMMDDHHMISS''),
        ts.shipment_type = ss.shipment_type,
        ts.commercial_value = ss.commercial_value,
        ts.hazardous_material_flag = ss.hazardous_material_flag,
        ts.total_estimated_charge = TRY_CAST(ss.total_estimated_charge AS FLOAT),
        ts.total_actual_charge = TRY_CAST(ss.total_actual_charge AS FLOAT),
        ts.next_alert_ts = TRY_TO_TIMESTAMP(ss.next_alert_ts,''YYYYMMDDHHMISS''),
        ts.shipment_confirm_updates_done = ss.shipment_confirm_updates_done,
        ts.shipment_deliver_updates_done = ss.shipment_deliver_updates_done,
        ts.shipment_containerized_flag = ss.shipment_containerized_flag,
        ts.scac_integration_required = ss.scac_integration_required,
        ts.packlist_type = ss.packlist_type,
        ts.custcarrier_account_no = ss.custcarrier_account_no,
        ts.manifest_key = ss.manifest_key,
        ts.is_single_order = ss.is_single_order,
        ts.lines_entered = ss.lines_entered,
        ts.order_available_on_system = ss.order_available_on_system,
        ts.override_manual_shipment_entry = ss.override_manual_shipment_entry,
        ts.do_not_verify_pallet_content = ss.do_not_verify_pallet_content,
        ts.do_not_verify_case_content = ss.do_not_verify_case_content,
        ts.allow_overage = ss.allow_overage,
        ts.manually_entered = ss.manually_entered,
        ts.allow_new_item_receipt = ss.allow_new_item_receipt,
        ts.order_no = ss.order_no,
        ts.order_header_key = ss.order_header_key,
        ts.release_no = ss.release_no,
        ts.order_release_key = ss.order_release_key,
        ts.export_license_no = ss.export_license_no,
        ts.export_license_exp_date = TRY_TO_TIMESTAMP(ss.export_license_exp_date,''YYYYMMDDHHMISS''),
        ts.delivery_method = ss.delivery_method,
        ts.requires_appt_confirmation = ss.requires_appt_confirmation,
        ts.work_order_key = ss.work_order_key,
        ts.work_order_appt_key = ss.work_order_appt_key,
        ts.order_type = ss.order_type,
        ts.do_not_consolidate = ss.do_not_consolidate,
        ts.department_code = ss.department_code,
        ts.item_classification = ss.item_classification,
        ts.mark_for_key = ss.mark_for_key,
        ts.buyer_mark_for_node_id = ss.buyer_mark_for_node_id,
        ts.routing_contact_info = ss.routing_contact_info,
        ts.customer_po_no = ss.customer_po_no,
        ts.carrier_pickup_time = ss.carrier_pickup_time,
        ts.pack_and_hold = ss.pack_and_hold,
        ts.esp_check_required = ss.esp_check_required,
        ts.is_appointment_reqd = ss.is_appointment_reqd,
        ts.routing_source = ss.routing_source,
        ts.routing_error_code = ss.routing_error_code,
        ts.routing_guide_maintained = ss.routing_guide_maintained,
        ts.must_ship_before_date = TRY_TO_TIMESTAMP(ss.must_ship_before_date,''YYYYMMDDHHMISS''),
        ts.priority_code = ss.priority_code,
        ts.estimated_price = TRY_CAST(ss.estimated_price AS FLOAT),
        ts.has_node_exceptions = ss.has_node_exceptions,
        ts.cod_pay_method = ss.cod_pay_method,
        ts.airway_bill_no = ss.airway_bill_no,
        ts.invoice_complete = ss.invoice_complete,
        ts.expected_pick_date = TRY_TO_TIMESTAMP(ss.expected_pick_date,''YYYYMMDDHHMISS''),
        ts.return_carrier_service = ss.return_carrier_service,
        ts.return_freight_terms = ss.return_freight_terms,
        ts.return_billing_account = ss.return_billing_account,
        ts.break_bulk_node = ss.break_bulk_node,
        ts.bbn_min_weight = ss.bbn_min_weight,
        ts.bbn_min_volume = ss.bbn_min_volume,
        ts.fedx_open_ship_index = ss.fedx_open_ship_index,
        ts.itn_no = ss.itn_no,
        ts.email_return_label = ss.email_return_label,
        ts.profile_id = ss.profile_id,
        ts.profileid_provided_by_sterling = ss.profileid_provided_by_sterling,
        ts.level_of_service = ss.level_of_service,
        ts.hold_location = ss.hold_location,
        ts.assigned_to_user_id = ss.assigned_to_user_id,
        ts.lockid = ss.lockid,
        ts.createts = TRY_TO_TIMESTAMP(ss.createts,''YYYYMMDDHHMISS'') ,
        ts.modifyts = TRY_TO_TIMESTAMP(ss.modifyts,''YYYYMMDDHHMISS'') ,
        ts.createuserid = ss.createuserid,
        ts.modifyuserid = ss.modifyuserid,
        ts.createprogid = ss.createprogid,
        ts.modifyprogid = ss.modifyprogid,
        ts.shipment_sort_location_id = ss.shipment_sort_location_id,
        ts.carrier_sort_location_id = ss.carrier_sort_location_id,
        ts.shipment_group_id = ss.shipment_group_id,
        ts.notification_sent = ss.notification_sent,
        ts.pickticket_printed = ss.pickticket_printed,
        ts.backroom_pick_required = ss.backroom_pick_required,
        ts.included_in_batch = ss.included_in_batch,
        ts.is_receiving_complete = ss.is_receiving_complete,
        ts.received_damaged = ss.received_damaged,
        ts.index_version = ss.index_version,
        ts.extn_narvar_url = ss.extn_narvar_url,
        ts.extn_is_sent = ss.extn_is_sent,
        ts.extn_is_email_sent = ss.extn_is_email_sent,
        ts.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        shipment_key,
        pick_list_no,
        original_shipment_key,
        merge_node,
        pickticket_no,
        ship_date,
        unplaced_quantity,
        shipnode_key,
        receiving_node,
        buyer_receiving_node_id,
        shipment_consol_group_id,
        ship_mode,
        from_address_key,
        to_address_key,
        bill_to_address_key,
        ship_to_customer_id,
        bill_to_customer_id,
        has_other_shipments,
        parent_shipment_key,
        ship_via,
        seal_no,
        tracking_no,
        trailer_no,
        manifest_no,
        pro_no,
        scac,
        actual_freight_charge,
        carrier_service_code,
        requested_carrier_service_code,
        status,
        pod_no,
        bol_no,
        total_weight,
        total_weight_uom,
        total_volume,
        total_volume_uom,
        total_quantity,
        containerized_quantity,
        placed_quantity,
        is_product_placing_complete,
        is_pack_process_complete,
        is_revised,
        hold_flag,
        it_no,
        it_date,
        appointment_no,
        from_appointment,
        to_appointment,
        delivery_ts,
        code,
        num_of_pallets,
        num_of_cartons,
        export_taxpayer_id,
        freight_terms,
        delivery_code,
        carrier_type,
        download_count,
        currency,
        delivery_plan_key,
        shipment_no,
        pipeline_key,
        gift_flag,
        shipment_planned_flag,
        shipment_closed_flag,
        seller_organization_code,
        buyer_organization_code,
        enterprise_code,
        requested_shipment_date,
        expected_shipment_date,
        actual_shipment_date,
        requested_delivery_date,
        expected_delivery_date,
        actual_delivery_date,
        return_by_date,
        return_authorization_number,
        document_type,
        origin_zone,
        destination_zone,
        status_date,
        shipment_type,
        commercial_value,
        hazardous_material_flag,
        total_estimated_charge,
        total_actual_charge,
        next_alert_ts,
        shipment_confirm_updates_done,
        shipment_deliver_updates_done,
        shipment_containerized_flag,
        scac_integration_required,
        packlist_type,
        custcarrier_account_no,
        manifest_key,
        is_single_order,
        lines_entered,
        order_available_on_system,
        override_manual_shipment_entry,
        do_not_verify_pallet_content,
        do_not_verify_case_content,
        allow_overage,
        manually_entered,
        allow_new_item_receipt,
        order_no,
        order_header_key,
        release_no,
        order_release_key,
        export_license_no,
        export_license_exp_date,
        delivery_method,
        requires_appt_confirmation,
        work_order_key,
        work_order_appt_key,
        order_type,
        do_not_consolidate,
        department_code,
        item_classification,
        mark_for_key,
        buyer_mark_for_node_id,
        routing_contact_info,
        customer_po_no,
        carrier_pickup_time,
        pack_and_hold,
        esp_check_required,
        is_appointment_reqd,
        routing_source,
        routing_error_code,
        routing_guide_maintained,
        must_ship_before_date,
        priority_code,
        estimated_price,
        has_node_exceptions,
        cod_pay_method,
        airway_bill_no,
        invoice_complete,
        expected_pick_date,
        return_carrier_service,
        return_freight_terms,
        return_billing_account,
        break_bulk_node,
        bbn_min_weight,
        bbn_min_volume,
        fedx_open_ship_index,
        itn_no,
        email_return_label,
        profile_id,
        profileid_provided_by_sterling,
        level_of_service,
        hold_location,
        assigned_to_user_id,
        lockid,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        shipment_sort_location_id,
        carrier_sort_location_id,
        shipment_group_id,
        notification_sent,
        pickticket_printed,
        backroom_pick_required,
        included_in_batch,
        is_receiving_complete,
        received_damaged,
        index_version,
        extn_narvar_url,
        extn_is_sent,
        extn_is_email_sent,
        inserted_date
    )
    VALUES (  
        ss.shipment_key,
        ss.pick_list_no,
        ss.original_shipment_key,
        ss.merge_node,
        ss.pickticket_no,
        TRY_TO_TIMESTAMP(ss.ship_date,''YYYYMMDDHHMISS''),
        ss.unplaced_quantity,
        ss.shipnode_key,
        ss.receiving_node,
        ss.buyer_receiving_node_id,
        ss.shipment_consol_group_id,
        ss.ship_mode,
        ss.from_address_key,
        ss.to_address_key,
        ss.bill_to_address_key,
        ss.ship_to_customer_id,
        ss.bill_to_customer_id,
        ss.has_other_shipments,
        ss.parent_shipment_key,
        ss.ship_via,
        ss.seal_no,
        ss.tracking_no,
        ss.trailer_no,
        ss.manifest_no,
        ss.pro_no,
        ss.scac,
        ss.actual_freight_charge,
        ss.carrier_service_code,
        ss.requested_carrier_service_code,
        ss.status,
        ss.pod_no,
        ss.bol_no,
        ss.total_weight,
        ss.total_weight_uom,
        ss.total_volume,
        ss.total_volume_uom,
        ss.total_quantity,
        ss.containerized_quantity,
        ss.placed_quantity,
        ss.is_product_placing_complete,
        ss.is_pack_process_complete,
        ss.is_revised,
        ss.hold_flag,
        ss.it_no,
        TRY_TO_TIMESTAMP(ss.it_date,''YYYYMMDDHHMISS''),
        ss.appointment_no,
        ss.from_appointment,
        ss.to_appointment,
        TRY_TO_TIMESTAMP(ss.delivery_ts,''YYYYMMDDHHMISS''),
        ss.code,
        ss.num_of_pallets,
        ss.num_of_cartons,
        ss.export_taxpayer_id,
        ss.freight_terms,
        ss.delivery_code,
        ss.carrier_type,
        ss.download_count,
        ss.currency,
        ss.delivery_plan_key,
        ss.shipment_no,
        ss.pipeline_key,
        ss.gift_flag,
        ss.shipment_planned_flag,
        ss.shipment_closed_flag,
        ss.seller_organization_code,
        ss.buyer_organization_code,
        ss.enterprise_code,
        TRY_TO_TIMESTAMP(ss.requested_shipment_date,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(ss.expected_shipment_date,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(ss.actual_shipment_date,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(ss.requested_delivery_date,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(ss.expected_delivery_date,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(ss.actual_delivery_date,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(ss.return_by_date,''YYYYMMDDHHMISS''),
        ss.return_authorization_number,
        ss.document_type,
        ss.origin_zone,
        ss.destination_zone,
        TRY_TO_TIMESTAMP(ss.status_date,''YYYYMMDDHHMISS''),
        ss.shipment_type,
        ss.commercial_value,
        ss.hazardous_material_flag,
        TRY_CAST(ss.total_estimated_charge AS FLOAT),
        TRY_CAST(ss.total_actual_charge AS FLOAT),
        TRY_TO_TIMESTAMP(ss.next_alert_ts,''YYYYMMDDHHMISS''),
        ss.shipment_confirm_updates_done,
        ss.shipment_deliver_updates_done,
        ss.shipment_containerized_flag,
        ss.scac_integration_required,
        ss.packlist_type,
        ss.custcarrier_account_no,
        ss.manifest_key,
        ss.is_single_order,
        ss.lines_entered,
        ss.order_available_on_system,
        ss.override_manual_shipment_entry,
        ss.do_not_verify_pallet_content,
        ss.do_not_verify_case_content,
        ss.allow_overage,
        ss.manually_entered,
        ss.allow_new_item_receipt,
        ss.order_no,
        ss.order_header_key,
        ss.release_no,
        ss.order_release_key,
        ss.export_license_no,
        TRY_TO_TIMESTAMP(ss.export_license_exp_date,''YYYYMMDDHHMISS''),
        ss.delivery_method,
        ss.requires_appt_confirmation,
        ss.work_order_key,
        ss.work_order_appt_key,
        ss.order_type,
        ss.do_not_consolidate,
        ss.department_code,
        ss.item_classification,
        ss.mark_for_key,
        ss.buyer_mark_for_node_id,
        ss.routing_contact_info,
        ss.customer_po_no,
        ss.carrier_pickup_time,
        ss.pack_and_hold,
        ss.esp_check_required,
        ss.is_appointment_reqd,
        ss.routing_source,
        ss.routing_error_code,
        ss.routing_guide_maintained,
        TRY_TO_TIMESTAMP(ss.must_ship_before_date,''YYYYMMDDHHMISS''),
        ss.priority_code,
        TRY_CAST(ss.estimated_price AS FLOAT),
        ss.has_node_exceptions,
        ss.cod_pay_method,
        ss.airway_bill_no,
        ss.invoice_complete,
        TRY_TO_TIMESTAMP(ss.expected_pick_date,''YYYYMMDDHHMISS''),
        ss.return_carrier_service,
        ss.return_freight_terms,
        ss.return_billing_account,
        ss.break_bulk_node,
        ss.bbn_min_weight,
        ss.bbn_min_volume,
        ss.fedx_open_ship_index,
        ss.itn_no,
        ss.email_return_label,
        ss.profile_id,
        ss.profileid_provided_by_sterling,
        ss.level_of_service,
        ss.hold_location,
        ss.assigned_to_user_id,
        ss.lockid,
        TRY_TO_TIMESTAMP(ss.createts,''YYYYMMDDHHMISS''),
        TRY_TO_TIMESTAMP(ss.modifyts,''YYYYMMDDHHMISS''),
        ss.createuserid,
        ss.modifyuserid,
        ss.createprogid,
        ss.modifyprogid,
        ss.shipment_sort_location_id,
        ss.carrier_sort_location_id,
        ss.shipment_group_id,
        ss.notification_sent,
        ss.pickticket_printed,
        ss.backroom_pick_required,
        ss.included_in_batch,
        ss.is_receiving_complete,
        ss.received_damaged,
        ss.index_version,
        ss.extn_narvar_url,
        ss.extn_is_sent,
        ss.extn_is_email_sent,
        CURRENT_TIMESTAMP() 
    );

    CREATE OR REPLACE TEMPORARY TABLE insertedShipmentRecords (
    txn_id varchar ,
    shipment_key varchar,
    revision number)
;

insert into  insertedShipmentRecords
SELECT ss.txn_id as txn_id,
    ss.shipment_key as shipment_key,
    1 as revision
FROM TRANSFORMED.stg_ORDER_shipment ss
;

MERGE INTO insertedShipmentRecords ttd
USING (
    SELECT
        aot.shipment_key,
        COALESCE(MAX(aot.revision), 0) + 1 AS new_revision
    FROM
        analytics.audit_order_shipment aot
    INNER JOIN
        insertedShipmentRecords ttd
    ON
        ttd.shipment_key = aot.shipment_key
    GROUP BY
        aot.shipment_key
) as src
ON ttd.shipment_key = src.shipment_key
WHEN MATCHED THEN
    UPDATE SET ttd.Revision = src.new_revision;

INSERT INTO  ANALYTICS.audit_order_shipment (
    shipment_key, pick_list_no, original_shipment_key, merge_node, pickticket_no, ship_date,
    unplaced_quantity, shipnode_key, receiving_node, buyer_receiving_node_id, shipment_consol_group_id,
    ship_mode, from_address_key, to_address_key, bill_to_address_key, ship_to_customer_id,
    bill_to_customer_id, has_other_shipments, parent_shipment_key, ship_via, seal_no, tracking_no,
    trailer_no, manifest_no, pro_no, scac, actual_freight_charge, carrier_service_code,
    requested_carrier_service_code, status, pod_no, bol_no, total_weight, total_weight_uom,
    total_volume, total_volume_uom, total_quantity, containerized_quantity, placed_quantity,
    is_product_placing_complete, is_pack_process_complete, is_revised, hold_flag, it_no, it_date,
    appointment_no, from_appointment, to_appointment, delivery_ts, code, num_of_pallets, num_of_cartons,
    export_taxpayer_id, freight_terms, delivery_code, carrier_type, download_count, currency,
    delivery_plan_key, shipment_no, pipeline_key, gift_flag, shipment_planned_flag, shipment_closed_flag,
    seller_organization_code, buyer_organization_code, enterprise_code, requested_shipment_date,
    expected_shipment_date, actual_shipment_date, requested_delivery_date, expected_delivery_date,
    actual_delivery_date, return_by_date, return_authorization_number, document_type, origin_zone,
    destination_zone, status_date, shipment_type, commercial_value, hazardous_material_flag,
    total_estimated_charge, total_actual_charge, next_alert_ts, shipment_confirm_updates_done,
    shipment_deliver_updates_done, shipment_containerized_flag, scac_integration_required, packlist_type,
    custcarrier_account_no, manifest_key, is_single_order, lines_entered, order_available_on_system,
    override_manual_shipment_entry, do_not_verify_pallet_content, do_not_verify_case_content,
    allow_overage, manually_entered, allow_new_item_receipt, order_no, order_header_key, release_no,
    order_release_key, export_license_no, export_license_exp_date, delivery_method, requires_appt_confirmation,
    work_order_key, work_order_appt_key, order_type, do_not_consolidate, department_code, item_classification,
    mark_for_key, buyer_mark_for_node_id, routing_contact_info, customer_po_no, carrier_pickup_time,
    pack_and_hold, esp_check_required, is_appointment_reqd, routing_source, routing_error_code,
    routing_guide_maintained, must_ship_before_date, priority_code, estimated_price, has_node_exceptions,
    cod_pay_method, airway_bill_no, invoice_complete, expected_pick_date, return_carrier_service,
    return_freight_terms, return_billing_account, break_bulk_node, bbn_min_weight, bbn_min_volume,
    fedx_open_ship_index, itn_no, email_return_label, profile_id, profileid_provided_by_sterling,
    level_of_service, hold_location, assigned_to_user_id, lockid, createts, modifyts, createuserid,
    modifyuserid, createprogid, modifyprogid, shipment_sort_location_id, carrier_sort_location_id,
    shipment_group_id, notification_sent, pickticket_printed, backroom_pick_required, included_in_batch,
    is_receiving_complete, received_damaged, index_version, extn_narvar_url, extn_is_sent, extn_is_email_sent,
    inserted_date, revision
)
SELECT 
    ss.shipment_key, ss.pick_list_no, ss.original_shipment_key, ss.merge_node, ss.pickticket_no, TRY_TO_TIMESTAMP(ss.ship_date,''YYYYMMDDHHMISS''),
    TRY_TO_NUMBER(ss.unplaced_quantity), ss.shipnode_key, ss.receiving_node, ss.buyer_receiving_node_id, ss.shipment_consol_group_id,
    ss.ship_mode, ss.from_address_key, ss.to_address_key, ss.bill_to_address_key, ss.ship_to_customer_id,
    ss.bill_to_customer_id, ss.has_other_shipments, ss.parent_shipment_key, ss.ship_via, ss.seal_no, ss.tracking_no,
    ss.trailer_no, ss.manifest_no, ss.pro_no, ss.scac, TRY_CAST(ss.actual_freight_charge AS FLOAT), ss.carrier_service_code,
    ss.requested_carrier_service_code, ss.status, ss.pod_no, ss.bol_no, TRY_CAST(ss.total_weight AS FLOAT), ss.total_weight_uom,
    TRY_CAST(ss.total_volume AS FLOAT), ss.total_volume_uom, TRY_TO_NUMBER(ss.total_quantity), TRY_TO_NUMBER(ss.containerized_quantity), TRY_TO_NUMBER(ss.placed_quantity),
    ss.is_product_placing_complete, ss.is_pack_process_complete, ss.is_revised, ss.hold_flag, ss.it_no, TRY_TO_TIMESTAMP(ss.it_date,''YYYYMMDDHHMISS''),
    ss.appointment_no, ss.from_appointment, ss.to_appointment, TRY_TO_TIMESTAMP(ss.delivery_ts,''YYYYMMDDHHMISS''), ss.code, TRY_TO_NUMBER(ss.num_of_pallets), TRY_TO_NUMBER(ss.num_of_cartons),
    ss.export_taxpayer_id, ss.freight_terms, ss.delivery_code, ss.carrier_type, ss.download_count, ss.currency,
    ss.delivery_plan_key, ss.shipment_no, ss.pipeline_key, ss.gift_flag, ss.shipment_planned_flag, ss.shipment_closed_flag,
    ss.seller_organization_code, ss.buyer_organization_code, ss.enterprise_code, TRY_TO_TIMESTAMP(ss.requested_shipment_date,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(ss.expected_shipment_date,''YYYYMMDDHHMISS''), TRY_TO_TIMESTAMP(ss.actual_shipment_date,''YYYYMMDDHHMISS''), TRY_TO_TIMESTAMP(ss.requested_delivery_date,''YYYYMMDDHHMISS''), TRY_TO_TIMESTAMP(ss.expected_delivery_date,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(ss.actual_delivery_date,''YYYYMMDDHHMISS''), TRY_TO_TIMESTAMP(ss.return_by_date,''YYYYMMDDHHMISS''), ss.return_authorization_number, ss.document_type, ss.origin_zone,
    ss.destination_zone, TRY_TO_TIMESTAMP(ss.status_date,''YYYYMMDDHHMISS''), ss.shipment_type, ss.commercial_value, ss.hazardous_material_flag,
    TRY_CAST(ss.total_estimated_charge AS FLOAT), TRY_CAST(ss.total_actual_charge AS FLOAT), TRY_TO_TIMESTAMP(ss.next_alert_ts,''YYYYMMDDHHMISS''), ss.shipment_confirm_updates_done,
    ss.shipment_deliver_updates_done, ss.shipment_containerized_flag, ss.scac_integration_required, ss.packlist_type,
    ss.custcarrier_account_no, ss.manifest_key, ss.is_single_order, ss.lines_entered, ss.order_available_on_system,
    ss.override_manual_shipment_entry, ss.do_not_verify_pallet_content, ss.do_not_verify_case_content,
    ss.allow_overage, ss.manually_entered, ss.allow_new_item_receipt, ss.order_no, ss.order_header_key, ss.release_no,
    ss.order_release_key, ss.export_license_no, TRY_TO_TIMESTAMP(ss.export_license_exp_date,''YYYYMMDDHHMISS''), ss.delivery_method, ss.requires_appt_confirmation,
    ss.work_order_key, ss.work_order_appt_key, ss.order_type, ss.do_not_consolidate, ss.department_code, ss.item_classification,
    ss.mark_for_key, ss.buyer_mark_for_node_id, ss.routing_contact_info, ss.customer_po_no, TRY_TO_TIMESTAMP(ss.carrier_pickup_time,''YYYYMMDDHHMISS''),
    ss.pack_and_hold, ss.esp_check_required, ss.is_appointment_reqd, ss.routing_source, ss.routing_error_code,
    ss.routing_guide_maintained, TRY_TO_TIMESTAMP(ss.must_ship_before_date,''YYYYMMDDHHMISS''), ss.priority_code, TRY_CAST(ss.estimated_price AS FLOAT), ss.has_node_exceptions,
    ss.cod_pay_method, ss.airway_bill_no, ss.invoice_complete, TRY_TO_TIMESTAMP(ss.expected_pick_date,''YYYYMMDDHHMISS''), ss.return_carrier_service,
    ss.return_freight_terms, ss.return_billing_account, ss.break_bulk_node, TRY_CAST(ss.bbn_min_weight AS FLOAT), TRY_CAST(ss.bbn_min_volume  AS FLOAT),
    ss.fedx_open_ship_index, ss.itn_no, ss.email_return_label, ss.profile_id, ss.profileid_provided_by_sterling,
    ss.level_of_service, ss.hold_location, ss.assigned_to_user_id, ss.lockid, TRY_TO_TIMESTAMP(ss.createts,''YYYYMMDDHHMISS''), 
    TRY_TO_TIMESTAMP(ss.modifyts,''YYYYMMDDHHMISS''), ss.createuserid,
    ss.modifyuserid, ss.createprogid, ss.modifyprogid, ss.shipment_sort_location_id, ss.carrier_sort_location_id,
    ss.shipment_group_id, ss.notification_sent, ss.pickticket_printed, ss.backroom_pick_required, ss.included_in_batch,
    ss.is_receiving_complete, ss.received_damaged, ss.index_version, ss.extn_narvar_url, ss.extn_is_sent, ss.extn_is_email_sent,
    CURRENT_TIMESTAMP, ord.revision
FROM TRANSFORMED.stg_ORDER_shipment ss
INNER JOIN insertedShipmentRecords ord ON ord.shipment_key = ss.shipment_key;

-- Update the raw_ORDER_shipment table
UPDATE RAW.raw_ORDER_shipment AS ros
SET
    processing_status = ''Processed'',
    processing_comment = '''',
    processing_errortype = ''''
FROM insertedShipmentRecords AS tos
WHERE ros.shipment_key = tos.shipment_key
  AND ros.txn_id = tos.txn_id;


SELECT COUNT(*) INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_ORDER_shipment;

SELECT COUNT(*) INTO :processedRecordCount
FROM insertedShipmentRecords;

UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
FROM ANALYTICS.log_files_import_status lofis 
WHERE
    lofis.file_name = ''YFS_SHIPMENT'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

DROP TABLE IF EXISTS insertedShipmentRecords;

COMMIT;
    
RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_SHIPMENT'';
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
CREATE PROCEDURE "USP_ORDER_STATUS_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    initialRevision NUMBER DEFAULT 1;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount
WHERE file_name = ''YFS_ORDER_RELEASE_STATUS'';

CREATE OR REPLACE TEMPORARY TABLE TempCreatedLineStatus (
    fk_order_headerid BIGINT NOT NULL,
    pk_order_detailid BIGINT NOT NULL,
    fk_order_detail_statusid INT NULL
);

CREATE OR REPLACE TEMPORARY TABLE TempLineStatus (
    fk_order_headerid BIGINT NOT NULL,
    pk_order_detailid BIGINT NOT NULL,
    fk_order_detail_statusid INT NULL,
    order_release_status_key VARCHAR NOT NULL
);

CREATE OR REPLACE TEMPORARY TABLE TempHeaderStatus (
    fk_order_headerid BIGINT NOT NULL,
    fk_order_statusid INT NULL
);

INSERT INTO TempHeaderStatus (
    fk_order_headerid,
    fk_order_statusid
)
SELECT 
    pk_order_headerid,
    max(pk_order_statusid) 
FROM 
     TRANSFORMED.stg_ORDER_header_status AS stg
INNER JOIN 
    RAW.raw_ORDER_header AS r ON r.ORDER_HEADER_KEY = stg.order_header_key
INNER JOIN 
    ANALYTICS.txn_order_header  AS toh ON toh.source_ref_num = r.ORDER_NO AND toh.ext_order_id = stg.order_header_key
    and to_timestamp(r.modifyts,''yyyymmddhhmiss'')= toh.modifyts
INNER JOIN 
      MASTER.DIM_ORDER_STATUS AS dods ON dods.OMS_ORDER_status_code = stg.status
      group by all;

MERGE INTO ANALYTICS.txn_order_status AS tgt
USING (
  SELECT DISTINCT
    fk_order_headerid,
    fk_order_statusid
  FROM
    TempHeaderStatus AS stg
) AS src
ON src.fk_order_headerid = tgt.fk_order_headerid
-- WHEN NOT MATCHED THEN
--   INSERT (
--     fk_order_headerid,
--     fk_order_statusid,
--     inserted_date,
--     modified_date
--   )
--   VALUES (
--     src.fk_order_headerid,
--     src.fk_order_statusid,
--     CURRENT_TIMESTAMP(),
--     CURRENT_TIMESTAMP()
--   )
WHEN MATCHED THEN
  UPDATE SET
    tgt.fk_order_statusid = src.fk_order_statusid,
    tgt.modified_date = CURRENT_TIMESTAMP();

INSERT INTO TempLineStatus (
    fk_order_headerid,
    pk_order_detailid,
    fk_order_detail_statusid,
    order_release_status_key
)
SELECT
    pk_order_headerid,
    tod.pk_order_detailid,
    pk_order_statusid,
    stg.order_release_status_key
FROM  TRANSFORMED.stg_ORDER_line_status AS stg
INNER JOIN RAW.raw_ORDER_header AS r ON r.ORDER_HEADER_KEY = stg.order_header_key
INNER JOIN ANALYTICS.txn_order_header AS toh ON toh.source_ref_num = r.ORDER_NO AND toh.ext_order_id = stg.order_header_key
INNER JOIN ANALYTICS.txn_order_detail AS tod ON tod.fk_order_headerid = toh.pk_order_headerid AND tod.ext_line_id = stg.order_line_key
INNER JOIN MASTER.DIM_ORDER_STATUS AS dods ON dods.OMS_ORDER_status_code = stg.status;

MERGE INTO ANALYTICS.txn_order_detail_status AS Target
USING (
    SELECT DISTINCT
        fk_order_headerid,
        pk_order_detailid,
        fk_order_detail_statusid,
        order_release_status_key
    FROM TempLineStatus AS stg
) AS Source
ON Source.fk_order_headerid = Target.pk_order_headerid
AND Source.pk_order_detailid = Target.pk_order_detailid
WHEN MATCHED THEN
    UPDATE SET
        Target.fk_order__detail_statusid = Source.fk_order_detail_statusid
WHEN NOT MATCHED THEN
    INSERT (
        pk_order_headerid,
        pk_order_detailid,
        fk_order__detail_statusid
    )
    VALUES (
        Source.fk_order_headerid,
        Source.pk_order_detailid,
        Source.fk_order_detail_statusid
    );

INSERT INTO TempCreatedLineStatus(
    fk_order_headerid,
    pk_order_detailid,
    fk_order_detail_statusid
)
SELECT pk_order_headerid,
        pk_order_detailid,
        fk_order__detail_statusid
FROM ANALYTICS.txn_order_detail_status
;

UPDATE RAW.raw_ORDER_release_status
SET 
    processing_status = ''Processed'',
    processing_comment = '''',
    processing_errortype = ''''
WHERE 
    processing_status IN (''Pending'', ''Failed'')
    AND EXISTS (
        SELECT 1
        FROM TRANSFORMED.stg_ORDER_line_status AS rod
        INNER JOIN TempLineStatus AS tol 
            ON tol.order_release_status_key = rod.ORDER_RELEASE_STATUS_KEY
        INNER JOIN TempCreatedLineStatus AS tod 
            ON tod.pk_order_detailid = tol.pk_order_detailid
            AND tod.fk_order_headerid = tol.fk_order_headerid
        WHERE rod.ORDER_RELEASE_STATUS_KEY = RAW.raw_ORDER_release_status.ORDER_RELEASE_STATUS_KEY
          AND rod.txn_id = RAW.raw_ORDER_release_status.txn_id
    );


SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM TRANSFORMED.stg_ORDER_line_status;

SELECT COUNT(*) INTO :processedRecordCount FROM TempCreatedLineStatus;

UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount,
    status = ''Success''
WHERE file_name = ''YFS_ORDER_RELEASE_STATUS'';

DROP TABLE IF EXISTS TempCreatedLineStatus;
DROP TABLE IF EXISTS TempHeaderStatus;
DROP TABLE IF EXISTS TempLineStatus;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;
    
RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

        error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDER_TAX_BREAKUP_ADDITIONAL_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE insertedTaxBreakupRecords (
    pk_ORDER_tax_breakupid BIGINT NOT NULL,
    tax_breakup_key STRING NOT NULL,
    header_key STRING NOT NULL,
    line_key STRING,
    record_type STRING,
    charge_category STRING,
    charge_name STRING,
    tax_name STRING,
    taxable_flag STRING,
    tax_percentage float,
    tax float,
    invoiced_tax float,
    reference1 STRING,
    reference2 STRING,
    reference3 STRING,
    createts TIMESTAMP_NTZ,
    modifyts TIMESTAMP_NTZ,
    createuserid STRING,
    modifyuserid STRING,
    createprogid STRING,
    modifyprogid STRING,
    lockid STRING,
    inserted_date TIMESTAMP_NTZ ,
    modified_date TIMESTAMP_NTZ  ,
    revision INT NOT NULL
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.txn_order_tax_breakup ti
USING (
    SELECT DISTINCT 
        tax_breakup_key,
        header_key,
        line_key,
        record_type,
        charge_category,
        charge_name,
        tax_name,
        taxable_flag,
        TRY_CAST(tax_percentage AS FLOAT) AS tax_percentage,
        TRY_CAST(tax AS FLOAT) AS tax,
        TRY_CAST(invoiced_tax AS FLOAT) AS invoiced_tax,
        reference1,
        reference2,
        reference3,
        TRY_TO_TIMESTAMP(createts,''YYYYMMDDHHMISS'') AS createts,
        TRY_TO_TIMESTAMP(modifyts,''YYYYMMDDHHMISS'') AS modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid
    FROM TRANSFORMED.stg_ORDER_tax_breakup
) si
ON ti.tax_breakup_key = si.tax_breakup_key
WHEN MATCHED THEN
    UPDATE SET 
        ti.line_key = si.line_key,
        ti.record_type = si.record_type,
        ti.charge_category = si.charge_category,
        ti.charge_name = si.charge_name,
        ti.tax_name = si.tax_name,
        ti.taxable_flag = si.taxable_flag,
        ti.tax_percentage = si.tax_percentage,
        ti.tax = si.tax,
        ti.invoiced_tax = si.invoiced_tax,
        ti.reference1 = si.reference1,
        ti.reference2 = si.reference2,
        ti.reference3 = si.reference3,
        ti.createts = si.createts,
        ti.modifyts = si.modifyts,
        ti.createuserid = si.createuserid,
        ti.modifyuserid = si.modifyuserid,
        ti.createprogid = si.createprogid,
        ti.modifyprogid = si.modifyprogid,
        ti.lockid = si.lockid,
        ti.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        tax_breakup_key,
        header_key,
        line_key,
        record_type,
        charge_category,
        charge_name,
        tax_name,
        taxable_flag,
        tax_percentage,
        tax,
        invoiced_tax,
        reference1,
        reference2,
        reference3,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        inserted_date,
        modified_date
    ) 
    VALUES (
        si.tax_breakup_key,
        si.header_key,
        si.line_key,
        si.record_type,
        si.charge_category,
        si.charge_name,
        si.tax_name,
        si.taxable_flag,
        si.tax_percentage,
        si.tax,
        si.invoiced_tax,
        si.reference1,
        si.reference2,
        si.reference3,
        si.createts,
        si.modifyts,
        si.createuserid,
        si.modifyuserid,
        si.createprogid,
        si.modifyprogid,
        si.lockid,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );

INSERT INTO insertedTaxBreakupRecords (
    pk_ORDER_tax_breakupid,
    tax_breakup_key,
    header_key,
    line_key,
    record_type,
    charge_category,
    charge_name,
    tax_name,
    taxable_flag,
    tax_percentage,
    tax,
    invoiced_tax,
    reference1,
    reference2,
    reference3,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    modified_date,
    revision
)
SELECT
    pk_OMS_tax_breakupid,
    tax_breakup_key,
    header_key,
    line_key,
    record_type,
    charge_category,
    charge_name,
    tax_name,
    taxable_flag,
    tax_percentage,
    tax,
    invoiced_tax,
    reference1,
    reference2,
    reference3,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    modified_date,
    1  
FROM ANALYTICS.txn_order_tax_breakup
WHERE inserted_date >= :processedDate or modified_date >= :processedDate  ;

MERGE INTO insertedTaxBreakupRecords ttd
USING (
    SELECT tax_breakup_key, MAX(revision) AS max_revision
    FROM audit_order_tax_breakup
    GROUP BY tax_breakup_key
) aot
ON ttd.tax_breakup_key = aot.tax_breakup_key
WHEN MATCHED THEN 
    UPDATE SET ttd.revision = COALESCE(aot.max_revision, 0) + 1;


    
INSERT INTO ANALYTICS.audit_order_tax_breakup (
    pk_OMS_tax_breakupid,
    tax_breakup_key,
    header_key,
    line_key,
    record_type,
    charge_category,
    charge_name,
    tax_name,
    taxable_flag,
    tax_percentage,
    tax,
    invoiced_tax,
    reference1,
    reference2,
    reference3,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    modified_date,
    revision
)
SELECT DISTINCT
    si.pk_ORDER_tax_breakupid,
    si.tax_breakup_key,
    si.header_key,
    si.line_key,
    si.record_type,
    si.charge_category,
    si.charge_name,
    si.tax_name,
    si.taxable_flag,
    si.tax_percentage,
    si.tax,
    si.invoiced_tax,
    si.reference1,
    si.reference2,
    si.reference3,
    si.createts,
    si.modifyts,
    si.createuserid,
    si.modifyuserid,
    si.createprogid,
    si.modifyprogid,
    si.lockid,
    si.inserted_date,
    si.modified_date,
    si.revision
FROM insertedTaxBreakupRecords si;

DROP TABLE IF EXISTS insertedTaxBreakupRecords;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;
RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

        error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_ORDER_TAX_BREAKUP_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    createdby NUMBER DEFAULT 1;
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    Counter NUMBER DEFAULT 0;
    processedLineTaxDetails NUMBER DEFAULT 0;
    processedTaxDetails NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE TempTaxDetails (
    pk_order_taxid BIGINT,
    fk_order_headerid BIGINT,
    tax_name VARCHAR,
    tax_type VARCHAR,
    tax_rate FLOAT,
    tax_amount FLOAT,
    ext_tax_id VARCHAR,
    created_by INT,
    created_date TIMESTAMP_NTZ,
    modified_date TIMESTAMP_NTZ,
    Revision INT
);

CREATE OR REPLACE TEMPORARY TABLE ordertaxdetails AS
SELECT DISTINCT  
    stg.TAX_BREAKUP_KEY,  
    stg.header_key,  
    toh.pk_order_headerid AS fk_order_headerid,  
    stg.tax_name AS tax_name,  
    TRY_CAST(stg.tax  AS FLOAT) AS tax_amount,  
    stg.charge_category AS tax_type,  
    TRY_CAST(STG.TAX_PERCENTAGE AS FLOAT) AS tax_rate,  
    stg.txn_id
FROM  
    TRANSFORMED.stg_ORDER_tax_breakup stg  
INNER JOIN 
    ANALYTICS.txn_order_header AS toh ON toh.order_header_key = stg.header_key AND toh.entry_type IS NOT NULL  
INNER JOIN 
    master.dim_chargecategory AS dc ON dc.charge_category = stg.charge_category AND dc.charge = ''TAX''  
WHERE 
    stg.line_key IS NULL;

processedDate := CURRENT_TIMESTAMP(); 
    
MERGE INTO ANALYTICS.txn_order_tax AS tot 
USING (
    SELECT  
        DISTINCT ordtax.fk_order_headerid,  
        ordtax.TAX_BREAKUP_KEY,  
        ordtax.tax_name,  
        ordtax.tax_type,  
        ordtax.tax_rate,  
        ordtax.tax_amount,  
        CURRENT_TIMESTAMP() AS inserted_date,  
        CURRENT_TIMESTAMP() AS modified_date  
    FROM  
        ordertaxdetails AS ordtax  
) AS otd  
ON (  
    tot.fk_order_headerid = otd.fk_order_headerid  
    AND tot.ext_tax_id = otd.TAX_BREAKUP_KEY  
)  
WHEN MATCHED THEN  
    UPDATE  
    SET   
        tot.tax_name = otd.tax_name,  
        tot.tax_type = otd.tax_type,  
        tot.tax_rate = otd.tax_rate,  
        tot.tax_amount = otd.tax_amount,  
        tot.modified_date = CURRENT_TIMESTAMP()  
WHEN NOT MATCHED THEN  
    INSERT                
    (  
        fk_order_headerid,  
        ext_tax_id,  
        tax_name,  
        tax_type,  
        tax_rate,  
        tax_amount,  
        inserted_date,  
        modified_date  
    )              
    VALUES                
    (                
        otd.fk_order_headerid,  
        otd.TAX_BREAKUP_KEY,  
        otd.tax_name,  
        otd.tax_type,  
        otd.tax_rate,  
        otd.tax_amount,  
        CURRENT_TIMESTAMP(),  
        CURRENT_TIMESTAMP()             
    );

INSERT INTO TempTaxDetails (
    pk_order_taxid,
    fk_order_headerid,
    tax_name,
    tax_amount,
    tax_type,
    ext_tax_id,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_taxid,
    fk_order_headerid,
    tax_name,
    tax_amount,
    tax_type,
    ext_tax_id,
    :createdby,
    inserted_date,
    modified_date,
    :InitialRevision
FROM ANALYTICS.txn_order_tax
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;

create or replace temp table analytics.MaxRevisions as 
    SELECT 
        MAX(aot.revision) AS revision,
        aot.pk_order_taxid,
        aot.fk_order_headerid
    FROM analytics.audit_order_tax AS aot
    JOIN TempTaxDetails AS ttd 
        ON ttd.pk_order_taxid = aot.pk_order_taxid 
        AND ttd.fk_order_headerid = aot.fk_order_headerid
    GROUP BY aot.pk_order_taxid, aot.fk_order_headerid;
    
MERGE INTO TempTaxDetails ttd
USING analytics.MaxRevisions aot
ON ttd.pk_order_taxid = aot.pk_order_taxid 
AND ttd.fk_order_headerid = aot.fk_order_headerid
WHEN MATCHED THEN 
    UPDATE SET 
        ttd.Revision = CAST((aot.revision + 1) AS INT);



INSERT INTO ANALYTICS.audit_order_tax (
    pk_order_taxid,
    fk_order_headerid,
    tax_name,
    tax_amount,
    tax_type,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_taxid,
    fk_order_headerid,
    tax_name,
    tax_amount,
    tax_type,
    created_by,
    created_date,
    modified_date,
    revision
FROM TempTaxDetails;

-- MERGE INTO RAW.raw_ORDER_tax_breakup rohc
-- USING (
--     SELECT 
--         sohc.TAX_BREAKUP_KEY, 
--         sohc.header_key, 
--         sohc.txn_id, 
--         sohc.modifyts 
--     FROM TRANSFORMED.stg_ORDER_tax_breakup sohc
--     JOIN ordertaxdetails otd 
--         ON otd.TAX_BREAKUP_KEY = sohc.TAX_BREAKUP_KEY
--         AND otd.header_key = sohc.header_key
--         AND otd.txn_id = sohc.txn_id
--     JOIN TempTaxDetails tod 
--         ON tod.fk_order_headerid = otd.fk_order_headerid
--         AND tod.ext_tax_id = otd.TAX_BREAKUP_KEY
--         AND tod.tax_type = otd.tax_type
--     WHERE sohc.modifyts = rohc.modifyts
-- ) matching_data
-- ON rohc.TAX_BREAKUP_KEY = matching_data.TAX_BREAKUP_KEY
-- AND rohc.header_key = matching_data.header_key
-- AND rohc.txn_id = matching_data.txn_id
-- AND rohc.line_key IS NULL
-- WHEN MATCHED THEN
--     UPDATE SET 
--         rohc.processing_status = ''Processed'',
--         rohc.processing_comment = '''',
--         rohc.processing_errortype = '''';

MERGE INTO  raw.raw_order_tax_breakup rohc
USING (
    SELECT sohc.TAX_BREAKUP_KEY, sohc.header_key, sohc.txn_id, sohc.modifyts
    FROM  transformed.stg_order_tax_breakup sohc
    INNER JOIN ordertaxdetails otd
        ON otd.TAX_BREAKUP_KEY = sohc.TAX_BREAKUP_KEY
        AND otd.header_key = sohc.header_key
        AND otd.txn_id = sohc.txn_id
    INNER JOIN TempTaxDetails tod
        ON tod.fk_order_headerid = otd.fk_order_headerid
        AND tod.ext_tax_id = otd.TAX_BREAKUP_KEY
        AND tod.tax_type = otd.tax_type
) AS source
ON rohc.TAX_BREAKUP_KEY = source.TAX_BREAKUP_KEY
   AND rohc.header_key = source.header_key
   AND rohc.txn_id = source.txn_id
   AND rohc.modifyts = source.modifyts
and rohc.line_key IS NULL
WHEN MATCHED THEN
    UPDATE SET
        rohc.processing_status = ''Processed'',
        rohc.processing_comment = '''',
        rohc.processing_errortype = '''';



CREATE OR REPLACE TEMPORARY TABLE OrderLineDetailTaxes AS
SELECT DISTINCT
    stg.TAX_BREAKUP_KEY,
    toh.order_header_key AS order_header_key,
    tod.ext_line_id AS ext_line_id,
    toh.pk_order_headerid AS fk_order_headerid,
    tod.pk_order_detailid AS fk_order_detailid,
    stg.tax_name AS tax_name,
    TRY_CAST(stg.tax AS FLOAT) AS tax_amount,
    stg.charge_category AS tax_type,
    TRY_CAST(tax_percentage AS FLOAT) AS tax_rate,
    stg.txn_id
FROM
    TRANSFORMED.stg_ORDER_tax_breakup stg
INNER JOIN ANALYTICS.txn_order_header toh ON toh.order_header_key = stg.header_key AND toh.entry_type IS NOT NULL
INNER JOIN master.dim_chargecategory dc ON dc.charge_category = stg.charge_category AND dc.charge = ''TAX''
INNER JOIN ANALYTICS.txn_order_detail tod ON tod.fk_order_headerid = toh.pk_order_headerid AND tod.ext_line_id = stg.line_key
WHERE stg.line_key IS NOT NULL;

CREATE OR REPLACE TEMPORARY TABLE TempLineTaxDetails (
    pk_order_detail_taxid BIGINT,
    fk_order_detailid BIGINT,
    tax_name VARCHAR,
    tax_type VARCHAR,
    tax_rate FLOAT,
    tax_amount FLOAT,
    ext_tax_id VARCHAR,
    created_by INT,
    created_date TIMESTAMP,
    modified_date TIMESTAMP,
    Revision INT
);

processedDate := CURRENT_TIMESTAMP(); 


MERGE INTO ANALYTICS.txn_order_detail_tax AS todt
USING (
    SELECT DISTINCT
        orddetailtaxes.fk_order_detailid,
        orddetailtaxes.tax_name,
        orddetailtaxes.tax_amount,
        orddetailtaxes.tax_type,
        orddetailtaxes.tax_rate,
        orddetailtaxes.TAX_BREAKUP_KEY
    FROM OrderLineDetailTaxes AS orddetailtaxes
) AS odt
ON (
    todt.fk_order_detailid = odt.fk_order_detailid
    AND todt.tax_name = odt.tax_name
    AND todt.tax_type = odt.tax_type
    AND odt.TAX_BREAKUP_KEY = todt.ext_tax_id
)
WHEN MATCHED THEN
UPDATE SET
    todt.tax_name = odt.tax_name,
    todt.tax_type = odt.tax_type,
    todt.tax_rate = odt.tax_rate,
    todt.tax_amount = odt.tax_amount,
    todt.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
INSERT (
    fk_order_detailid,
    ext_tax_id,
    tax_name,
    tax_type,
    tax_rate,
    tax_amount,
    inserted_date,
    modified_date
)
VALUES (
    odt.fk_order_detailid,
    odt.TAX_BREAKUP_KEY,
    odt.tax_name,
    odt.tax_type,
    odt.tax_rate,
    odt.tax_amount,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP()
);

INSERT INTO TempLineTaxDetails (
    pk_order_detail_taxid,
    fk_order_detailid,
    tax_name,
    tax_amount,
    tax_type,
    tax_rate,
    ext_tax_id,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT 
    pk_order_detail_taxid,
    fk_order_detailid,
    tax_name,
    tax_amount,
    tax_type,
    tax_rate,
    ext_tax_id,
    :createdby,
    inserted_date,
    modified_date,
    :InitialRevision
FROM ANALYTICS.txn_order_detail_tax
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;

MERGE INTO TempLineTaxDetails ttd
USING (
    SELECT 
        MAX(aot.revision) AS revision, 
        aot.pk_order_detail_taxid, 
        aot.fk_order_detailid
    FROM ANALYTICS.audit_order_detail_tax aot
    JOIN TempLineTaxDetails ttd 
        ON ttd.pk_order_detail_taxid = aot.pk_order_detail_taxid
        AND ttd.fk_order_detailid = aot.fk_order_detailid
    GROUP BY aot.pk_order_detail_taxid, aot.fk_order_detailid
) aot
ON ttd.pk_order_detail_taxid = aot.pk_order_detail_taxid
AND ttd.fk_order_detailid = aot.fk_order_detailid
WHEN MATCHED THEN
    UPDATE SET 
        ttd.Revision = CAST((aot.revision + 1) AS INT);


INSERT INTO ANALYTICS.audit_order_detail_tax (
   pk_order_detail_taxid,  
   fk_order_detailid,   
   tax_name,   
   tax_amount,    
   created_by,   
   created_date,   
   modified_date,   
   ext_tax_id,  
   revision
)      
SELECT DISTINCT  
   pk_order_detail_taxid,  
   fk_order_detailid,  
   tax_name,  
   tax_amount,  
   created_by,  
   created_date,  
   modified_date,  
   ext_tax_id,  
   revision  
FROM TempLineTaxDetails;


MERGE INTO raw.raw_order_tax_breakup rohc
USING (
    SELECT sohc.TAX_BREAKUP_KEY, sohc.line_key, sohc.txn_id, sohc.modifyts
    FROM transformed.stg_order_tax_breakup sohc
    INNER JOIN OrderLineDetailTaxes otd
        ON otd.TAX_BREAKUP_KEY = sohc.TAX_BREAKUP_KEY
        AND otd.ext_line_id = sohc.line_key
        AND otd.txn_id = sohc.txn_id
    INNER JOIN TempLineTaxDetails tod
        ON tod.fk_order_detailid = otd.fk_order_detailid
        AND tod.ext_tax_id = otd.TAX_BREAKUP_KEY
        AND tod.tax_type = otd.tax_type
) AS source
ON rohc.TAX_BREAKUP_KEY = source.TAX_BREAKUP_KEY
   AND rohc.line_key = source.line_key
   AND rohc.txn_id = source.txn_id
   AND rohc.modifyts = source.modifyts
and rohc.line_key IS NOT NULL
WHEN MATCHED THEN
    UPDATE SET
        rohc.processing_status = ''Processed'',
        rohc.processing_comment = '''',
        rohc.processing_errortype = '''';



SELECT
    COUNT(*)
INTO
    :processedLineTaxDetails
FROM
    TempLineTaxDetails;


SELECT
    COUNT(*)
INTO
    :processedTaxDetails
FROM
    TempTaxDetails;
    
processedRecordCount := processedLineTaxDetails + processedTaxDetails
;

SELECT  
    :toBeProcessedRecordCount = COUNT(*)  
FROM  
    TRANSFORMED.stg_ORDER_tax_breakup;

UPDATE ANALYTICS.log_files_import_status  
SET 
    processed = :processedRecordCount,  
    to_be_processed = :toBeProcessedRecordCount,  
    status = ''Success''  
FROM 
    ANALYTICS.log_files_import_status AS lofis  
WHERE 
    lofis.file_name = ''YFS_TAX_BREAKUP'';

DROP TABLE IF EXISTS OrderTaxDetails;
DROP TABLE IF EXISTS TempTaxDetails;
DROP TABLE IF EXISTS OrderLineDetailTaxes;
DROP TABLE IF EXISTS TempLineTaxDetails;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;

RETURN ''Success'';

EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_INBOX'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
CREATE PROCEDURE "USP_ORDER_UPSERT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    createdby INT;
    prcessedHeaderRecordCount INT;
    prcessedLineRecordCount INT;
    toBeProcessedLineRecordCount INT;
    toBeProcessedRecordCount INT;
    detailprocesseddate TIMESTAMP_NTZ(9);
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
    processedDate TIMESTAMP;
BEGIN
processedDate := CURRENT_TIMESTAMP();
start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

SET createdby := 1;

--BEGIN
-- New orders start
TRUNCATE TABLE  TRANSFORMED.stg_ORDER_processed_order_header;
--END;

-- Use session variables for processed record counts
SET prcessedHeaderRecordCount := 0;
SET prcessedLineRecordCount := 0;
--END;

-- Update statements
UPDATE analytics.log_files_import_status lofis
SET lofis.processed = :prcessedHeaderRecordCount 
WHERE lofis.file_name = ''YFS_ORDER_HEADER'';

UPDATE analytics.log_files_import_status lofis
SET lofis.processed = :prcessedLineRecordCount
WHERE lofis.file_name = ''YFS_ORDER_LINE'';

-- Populating order line keys start
CREATE OR REPLACE TEMPORARY TABLE analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS (
    order_header_key STRING,
    order_line_key STRING,
    ITEM_ID STRING,
    PRIME_LINE_NO STRING,
    pk_skuproductid INT
);

INSERT INTO analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS
SELECT DISTINCT sol.order_header_key,
       sol.order_line_key,
       sol.ITEM_ID,
       sol.PRIME_LINE_NO,
       dsl.pk_skuproductid
FROM TRANSFORMED.stg_ORDER_line sol
INNER JOIN analytics.ext_order_header eoh ON eoh.order_header_key = sol.order_header_key AND eoh.order_name = ''MIGRATED''
INNER JOIN analytics.sku_product dsl ON dsl.sku_code = sol.ITEM_ID
WHERE eoh.order_name = ''MIGRATED'';

INSERT INTO analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS
SELECT DISTINCT sol.order_header_key,
       sol.order_line_key,
       sol.ITEM_ID,
       sol.PRIME_LINE_NO,
       dsl.pk_skuproductid
FROM   TRANSFORMED.stg_ORDER_line sol
INNER JOIN   RAW.raw_ORDER_header eoh ON eoh.order_header_key = sol.order_header_key AND eoh.order_name = ''MIGRATED''
INNER JOIN analytics.sku_product dsl ON dsl.sku_code = sol.ITEM_ID
WHERE eoh.order_name = ''MIGRATED'';

INSERT INTO analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS
SELECT DISTINCT sol.order_header_key,
       sol.order_line_key,
       sol.ITEM_ID,
       sol.PRIME_LINE_NO,
       dsl.pk_skuproductid
FROM TRANSFORMED.stg_ORDER_line sol
INNER JOIN ARCHIVE.arc_raw_ORDER_header eoh ON eoh.order_header_key = sol.order_header_key AND eoh.order_name = ''MIGRATED''
INNER JOIN analytics.sku_product dsl ON dsl.sku_code = sol.ITEM_ID
WHERE eoh.order_name = ''MIGRATED'';

-- Delete duplicate
DELETE FROM  analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS
USING (
    SELECT order_line_key,
           ROW_NUMBER() OVER (PARTITION BY order_line_key ORDER BY order_line_key) AS revision
    FROM analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS
) h
WHERE analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS.order_line_key = h.order_line_key
AND h.revision > 1;

-- Delete already populated
DELETE FROM analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS stg
USING analytics.txn_order_detail tod
WHERE tod.order_line_key = stg.order_line_key;

-- Update txn_order_detail
UPDATE analytics.txn_order_detail tod
SET tod.order_header_key = t1.order_header_key,
    tod.order_line_key = t1.order_line_key,
    tod.ext_line_id = t1.order_line_key
FROM analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS t1
INNER JOIN analytics.txn_order_header toh ON toh.order_header_key = t1.order_header_key
WHERE toh.pk_order_headerid = tod.fk_order_headerid
AND t1.PRIME_LINE_NO = tod.prime_line_num
AND t1.pk_skuproductid = tod.fk_skuproductid
AND tod.order_header_key IS NULL
AND tod.order_line_key IS NULL
AND tod.ext_line_id IS NULL
AND t1.order_line_key IS NOT NULL
AND t1.order_header_key IS NOT NULL
AND t1.PRIME_LINE_NO IS NOT NULL
AND t1.pk_skuproductid IS NOT NULL;

-- Drop temporary table
DROP TABLE analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS;



-- END

-- Creating temporary tables
CREATE OR REPLACE TEMPORARY TABLE analytics.TempORDER_Orders (
    pk_order_headerid BIGINT,
    fk_sourceid SMALLINT,
    source_ref_num STRING,
    ext_order_id STRING,
    is_domestic BOOLEAN,
    fk_shipping_addressid BIGINT,
    fk_billing_addressid BIGINT,
    fk_customerid BIGINT,
    fk_currencyid INT,
    fk_shipping_methodid SMALLINT,
    payment_amount NUMBER(9, 2),
    gross_amount NUMBER(9, 2),
    discount_amount NUMBER(9, 2),
    fee_amount NUMBER(9, 2),
    tax_amount NUMBER(9, 2),
    shpping_fee_amount NUMBER(9, 2),
    personalization_fee_amount NUMBER(9, 2),
    net_amount NUMBER(9, 2),
    fk_order_typeid SMALLINT,
    fk_order_statusid SMALLINT,
    fk_parent_order_headerid BIGINT,
    inserted_date TIMESTAMP_NTZ,
    modified_date TIMESTAMP_NTZ,
    order_date TIMESTAMP_NTZ,
    email_address STRING,
    order_comments STRING,
    order_notes STRING,
    tax_exempt BOOLEAN,
    salesrep_customerid STRING,
    risk_status STRING,
    ship_residential BOOLEAN,
    revision NUMBER(10),
    txn_id STRING,
    extn_order_locale_code STRING,
    seller_organization_code STRING,
    customer_first_name STRING,
    customer_last_name STRING,
    modifyuserid STRING,
    createuserid STRING,
    createts TIMESTAMP,
    entered_by STRING,
    is_bfy17 BOOLEAN DEFAULT FALSE,
    entry_type STRING,
    order_header_key STRING,
    extn_brand STRING,
    extn_sub_order_type STRING,
    EXTN_ORDER_TOTAL STRING,
    modifyts STRING
);

CREATE OR REPLACE TEMPORARY TABLE analytics.TempOrderDetails (
    fk_order_headerid BIGINT NOT NULL,
    fk_skuproductid INT NOT NULL,
    quantity INT NOT NULL,
    product_price NUMBER(9, 2) NOT NULL,
    total_price NUMBER(9, 2) NOT NULL,
    is_taxable BOOLEAN,
    options STRING,
    personalization_fee NUMBER(9, 2),
    product_name STRING,
    created_by INT,
    created_date TIMESTAMP_NTZ,
    modified_date TIMESTAMP_NTZ,
    pk_order_detailid BIGINT NOT NULL,
    Revision INT,
    prime_line_num INT,
    txn_id STRING,
    ext_line_id STRING,
    order_header_key STRING,
    order_line_key STRING,
    createts STRING,
    modifyts STRING
);

CREATE OR REPLACE TEMPORARY TABLE analytics.createdOrders (
    order_header_key VARCHAR,
    enterprise_key VARCHAR,
    order_no VARCHAR,
    sourcing_classification VARCHAR,
    buyer_organization_code VARCHAR,
    seller_organization_code VARCHAR,
    document_type VARCHAR,
    bill_to_key VARCHAR,
    bill_to_id VARCHAR,
    customer_rewards_no VARCHAR,
    vendor_id VARCHAR,
    ship_to_key VARCHAR,
    ship_to_id VARCHAR,
    ship_node VARCHAR,
    receiving_node VARCHAR,
    buyer_receiving_node_id VARCHAR,
    mark_for_key VARCHAR,
    buyer_mark_for_node_id VARCHAR,
    req_delivery_date VARCHAR,
    req_cancel_date VARCHAR,
    req_ship_date VARCHAR,
    default_template VARCHAR,
    division VARCHAR,
    order_date VARCHAR,
    order_type VARCHAR,
    draft_order_flag VARCHAR,
    order_purpose VARCHAR,
    return_oh_key_for_exchange VARCHAR,
    exchange_type VARCHAR,
    pending_transfer_in VARCHAR,
    return_by_gift_recipient VARCHAR,
    allocation_rule_id VARCHAR,
    priority_code VARCHAR,
    priority_number VARCHAR,
    contact_key VARCHAR,
    scac VARCHAR,
    carrier_service_code VARCHAR,
    custcarrier_account_no VARCHAR,
    notify_after_shipment_flag VARCHAR,
    created_at_node VARCHAR,
    has_derived_child VARCHAR,
    has_derived_parent VARCHAR,
    notification_type VARCHAR,
    notification_reference VARCHAR,
    entry_type VARCHAR,
    authorized_client VARCHAR,
    entered_by VARCHAR,
    personalize_code VARCHAR,
    hold_flag VARCHAR,
    hold_reason_code VARCHAR,
    customer_po_no VARCHAR,
    customer_customer_po_no VARCHAR,
    order_name VARCHAR,
    payment_rule_id VARCHAR,
    terms_code VARCHAR,
    delivery_code VARCHAR,
    charge_actual_freight VARCHAR,
    tax VARCHAR,
    total_amount VARCHAR,
    original_total_amount VARCHAR,
    original_tax VARCHAR,
    currency VARCHAR,
    enterprise_currency VARCHAR,
    reporting_conversion_rate VARCHAR,
    reporting_conversion_date VARCHAR,
    payment_status VARCHAR,
    authorization_expiration_date VARCHAR,
    search_criteria_1 VARCHAR,
    search_criteria_2 VARCHAR,
    customer_emailid VARCHAR,
    fob VARCHAR,
    total_adjustment_amount VARCHAR,
    other_charges VARCHAR,
    price_program_key VARCHAR,
    taxpayer_id VARCHAR,
    tax_jurisdiction VARCHAR,
    tax_exempt_flag VARCHAR,
    tax_exemption_certificate VARCHAR,
    purpose VARCHAR,
    invoice_complete VARCHAR,
    order_closed VARCHAR,
    next_alert_ts VARCHAR,
    do_not_consolidate VARCHAR,
    chain_type VARCHAR,
    adjustment_invoice_pending VARCHAR,
    auto_cancel_date VARCHAR,
    sale_voided VARCHAR,
    is_ship_complete VARCHAR,
    is_line_ship_complete VARCHAR,
    is_ship_single_node VARCHAR,
    is_line_ship_single_node VARCHAR,
    cancel_order_on_excp_flag VARCHAR,
    optimization_type VARCHAR,
    purge_history_date VARCHAR,
    pricing_classification_code VARCHAR,
    source_type VARCHAR,
    source_key VARCHAR,
    linked_source_key VARCHAR,
    original_container_key VARCHAR,
    sold_to_key VARCHAR,
    team_code VARCHAR,
    level_of_service VARCHAR,
    next_iter_seq_no VARCHAR,
    next_iter_date VARCHAR,
    hrs_before_next_iter VARCHAR,
    createts VARCHAR,
    modifyts VARCHAR,
    createuserid VARCHAR,
    modifyuserid VARCHAR,
    createprogid VARCHAR,
    modifyprogid VARCHAR,
    lockid VARCHAR,
    department_code VARCHAR,
    buyer_user_id VARCHAR,
    recreate_authorizations VARCHAR,
    customer_contact_id VARCHAR,
    opportunity_key VARCHAR,
    is_expiration_date_overridden VARCHAR,
    expiration_date VARCHAR,
    approval_cycle VARCHAR,
    in_store_payment_required VARCHAR,
    immediate_settlement_value VARCHAR,
    customer_age VARCHAR,
    cart_id VARCHAR,
    rollout_version VARCHAR,
    all_addresses_verified VARCHAR,
    compl_gift_box_qty VARCHAR,
    no_of_auth_strikes VARCHAR,
    source_ip_address VARCHAR,
    customer_first_name VARCHAR,
    customer_last_name VARCHAR,
    customer_phone_no VARCHAR,
    customer_zip_code VARCHAR,
    index_version VARCHAR,
    extn_customer_type VARCHAR,
    extn_customer_id VARCHAR,
    extn_cba_ship_label VARCHAR,
    extn_amazon_tfm VARCHAR,
    extn_tfm_ship_status VARCHAR,
    extn_financed_by_affirm VARCHAR,
    extn_risk_status VARCHAR,
    extn_sales_rep_cust_id VARCHAR,
    extn_latest_ship_date VARCHAR,
    extn_latest_delivery_date VARCHAR,
    extn_market_place_id VARCHAR,
    extn_order_status VARCHAR,
    extn_is_prime VARCHAR,
    extn_ga_tag_id VARCHAR,
    extn_fraud_status VARCHAR,
    extn_order_locale_code VARCHAR,
    extn_shipto_firstname VARCHAR,
    extn_shipto_lastname VARCHAR,
    extn_shipto_zipcode VARCHAR,
    extn_giftee_full_name VARCHAR,
    extn_giftee_email_id VARCHAR,
    extn_sms_opt_in VARCHAR,
    imported_date VARCHAR,
    txn_id VARCHAR,
    order_status VARCHAR,
    extn_brand VARCHAR,
    extn_sub_order_type VARCHAR,
    extn_order_total VARCHAR,
    extn_return_confirmed_by VARCHAR,
    extn_edi_gcn VARCHAR,
    extn_pk_header_key VARCHAR,
    extn_merchant_id VARCHAR,
    extn_is_avalara VARCHAR,
    extn_req_cancel_date VARCHAR,
    extn_is_email_sent VARCHAR,
    extn_is_txn_committed VARCHAR,
    extn_tax_txn_date VARCHAR,
    extn_last_refund_txn_code VARCHAR,
    extn_refund_txn_code VARCHAR,
    extn_min_estimated_delivery_date VARCHAR,
    extn_max_estimated_delivery_date VARCHAR,
    extn_apply_migration_hold VARCHAR,
    extn_signifyd_order_id VARCHAR,
    extn_primary_reason VARCHAR,
    extn_secondary_reason VARCHAR,
    extn_sales_entry_type VARCHAR,
    extn_sales_order_type VARCHAR,
    extn_warranty_order_no VARCHAR,
    extn_seller_payment_type VARCHAR
);

-- Create temporary tables
CREATE OR REPLACE TEMPORARY TABLE analytics.CREATEDORDERCUSTOMER (
    pk_customerid BIGINT NOT NULL,
    EXTN_CUSTOMER_ID VARCHAR NULL,
    ship_to_key VARCHAR NOT NULL,
    pk_sourceid INT NOT NULL
);

CREATE OR REPLACE TEMPORARY TABLE analytics.CREATEDORDERADDRESSTABLE (
    shipid VARCHAR NOT NULL,
    billid VARCHAR NOT NULL,
    BILL_TO_KEY VARCHAR NOT NULL,
    SHIP_TO_KEY VARCHAR NOT NULL
);



truncate table TRANSFORMED.stg_ORDER_processed_order_header;
INSERT INTO analytics.createdOrders
SELECT DISTINCT 
    ord.*
FROM
    TRANSFORMED.stg_ORDER_header AS ord
    LEFT JOIN analytics.txn_order_header AS ordheadrer ON ordheadrer.source_ref_num = ord.ORDER_NO
WHERE
    ordheadrer.pk_order_headerid IS NULL AND (order_name IS NULL OR order_name = ''EXTEND_CANCEL'' OR order_name = ''GLADLY_RETURN'');

UPDATE analytics.createdOrders
SET order_status = ''1100''
WHERE order_status IS NULL OR order_status = '''';

-- Creating customer ID order create table
CREATE OR REPLACE TEMPORARY TABLE analytics.CUSTOMER_IDS_ORDER_CREATE_ORDER_ (
    customer_id VARCHAR NOT NULL
);

INSERT INTO analytics.CUSTOMER_IDS_ORDER_CREATE_ORDER_
SELECT DISTINCT EXTN_CUSTOMER_ID 
FROM analytics.createdOrders
WHERE EXTN_CUSTOMER_ID IS NOT NULL;

INSERT INTO analytics.CUSTOMER_IDS_ORDER_CREATE_ORDER_
SELECT DISTINCT ship_to_key 
FROM analytics.createdOrders;

-- Creating DIM customer data table
CREATE OR REPLACE TEMPORARY TABLE analytics.DIMCUSTOMERDATA_FOR_ORDER_CREATE_ORDER_ (
    pk_customerid BIGINT NOT NULL,
    fk_sourceid SMALLINT NOT NULL,
    source_ref_num VARCHAR(50) NOT NULL
);

INSERT INTO analytics.DIMCUSTOMERDATA_FOR_ORDER_CREATE_ORDER_
SELECT DISTINCT 
    pk_customerid,
    fk_sourceid,
    source_ref_num
FROM analytics.customer AS d
INNER JOIN analytics.CUSTOMER_IDS_ORDER_CREATE_ORDER_ AS t ON t.customer_id = d.source_ref_num;



INSERT INTO analytics.CREATEDORDERCUSTOMER
WITH DistinctCustomerInfo1 AS (
    SELECT
        MIN(cus.pk_customerid) AS pk_customerid,
        ord.EXTN_CUSTOMER_ID,
        ord.ship_to_key,
        src.pk_sourceid
    FROM
        analytics.createdOrders AS ord
    INNER JOIN
        master.entrytype_platform_map AS pl
        ON pl.entry_type = ord.ENTRY_TYPE AND pl.Order_Type = ord.Order_Type
    INNER JOIN
        master.source_brand_platform_map AS src
        ON src.BrandCodeForWHM = ANALYTICS.fun_get_edw_brand_by_ORDER_sellerorgcode(ord.SELLER_ORGANIZATION_CODE)
        AND src.PlatformName = COALESCE(pl.customer_platform_name, pl.platform_name)
    INNER JOIN
        analytics.DIMCUSTOMERDATA_FOR_ORDER_CREATE_ORDER_ AS cus
        ON (cus.source_ref_num = ord.EXTN_CUSTOMER_ID AND cus.fk_sourceid = src.pk_sourceid)
        OR (cus.source_ref_num = ord.EXTN_CUSTOMER_ID AND ord.Order_Type = ''WARRANTY'')
        OR (ord.EXTN_CUSTOMER_ID IS NULL AND cus.source_ref_num = ord.ship_to_key AND cus.fk_sourceid = src.pk_sourceid)
    GROUP BY
        ord.EXTN_CUSTOMER_ID,
        ord.ship_to_key,
        src.pk_sourceid
)
SELECT DISTINCT
    pk_customerid,
    EXTN_CUSTOMER_ID,
    ship_to_key,
    pk_sourceid
FROM
    DistinctCustomerInfo1;


-- Dropping temporary tables
DROP TABLE IF EXISTS ANALYTICS.CUSTOMER_IDS_ORDER_CREATE_ORDER_;
DROP TABLE IF EXISTS ANALYTICS.DIMCUSTOMERDATA_FOR_ORDER_CREATE_ORDER_;

-- Uncomment and adjust the following lines if needed
--INSERT INTO CREATEDORDERADDRESSTABLE
--SELECT DISTINCT
--    shipaddr.pk_addressid AS shipid,
--    billaddr.pk_addressid AS billid,
--    ord.BILL_TO_KEY,
--    ord.SHIP_TO_KEY
--FROM
--    createdOrders AS ord
--INNER JOIN txn_address AS shipaddr ON CAST(shipaddr.ext_address_id AS VARCHAR) = CAST(ord.SHIP_TO_KEY AS VARCHAR) AND shipaddr.fk_address_typeid = 1
--INNER JOIN txn_address AS billaddr ON CAST(billaddr.ext_address_id AS VARCHAR) = CAST(ord.BILL_TO_KEY AS VARCHAR) AND billaddr.fk_address_typeid = 2
--WHERE shipaddr.pk_addressid IS NOT NULL AND billaddr.pk_addressid IS NOT NULL;

INSERT INTO ANALYTICS.CREATEDORDERADDRESSTABLE
WITH DistinctAddresses1 AS (
    SELECT DISTINCT
        shipaddr.pk_addressid AS shipid,
        billaddr.pk_addressid AS billid,
        ord.BILL_TO_KEY,
        ord.SHIP_TO_KEY
    FROM
        ANALYTICS.createdOrders AS ord
    INNER JOIN
        ANALYTICS.txn_address AS shipaddr
        ON CAST(shipaddr.ext_address_id AS VARCHAR) = CAST(ord.SHIP_TO_KEY AS VARCHAR) AND shipaddr.fk_address_typeid = 1
    INNER JOIN
        ANALYTICS.txn_address AS billaddr
        ON CAST(billaddr.ext_address_id AS VARCHAR) = CAST(ord.BILL_TO_KEY AS VARCHAR) AND billaddr.fk_address_typeid = 2
    WHERE
        shipaddr.pk_addressid IS NOT NULL AND billaddr.pk_addressid IS NOT NULL
)
SELECT shipid, billid, BILL_TO_KEY, SHIP_TO_KEY
FROM DistinctAddresses1;


--BEGIN 
-- Insert into stg_ORDER_processed_order_header
INSERT INTO TRANSFORMED.stg_ORDER_processed_order_header (
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    salesrep_customerid,
    inserted_date,
    modified_date,
    order_date,
    email_address,
    order_comments,
    order_notes,
    tax_exempt,
    risk_status,
    ship_residential,
    is_bfy17,
    txn_id,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    entry_type,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total,
    modifyts
)
SELECT DISTINCT
    src.pk_sourceid,
    ord.order_no,
    ord.ORDER_HEADER_KEY,
    CASE
        WHEN ord.SELLER_ORGANIZATION_CODE = ''BH_US'' THEN 1
        ELSE 0
    END,
    addr.shipid,
    addr.billid,
    cus.pk_customerid,
    curr.pk_currencyid,
    ship.pk_shipping_methodid,
    TO_DOUBLE(COALESCE(ord.TOTAL_AMOUNT, ''0'')),
    TO_DOUBLE(COALESCE(ord.ORIGINAL_TOTAL_AMOUNT, ''0'')),
    TO_DOUBLE(COALESCE(ord.TOTAL_ADJUSTMENT_AMOUNT, ''0'')),
    0,
    TO_DOUBLE(COALESCE(ord.tax, ''0'')),
    0,
    0,
    TO_DOUBLE(COALESCE(ord.TOTAL_AMOUNT, ''0'')),
    ordtype.pk_order_typeid,
    ordsts.pk_order_statusid,
    NULL,
    CASE
        WHEN ord.ENTRY_TYPE = ''Call Center'' THEN ord.ENTERED_BY
        ELSE ord.EXTN_SALES_REP_CUST_ID
    END,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    TO_TIMESTAMP_NTZ(
        SUBSTRING(order_date, 1, 4) || ''-'' || 
        SUBSTRING(order_date, 5, 2) || ''-'' || 
        SUBSTRING(order_date, 7, 2) || '' '' || 
        SUBSTRING(order_date, 9, 2) || '':'' || 
        SUBSTRING(order_date, 11, 2) || '':'' || 
        SUBSTRING(order_date, 13, 2)
    ),
    CASE
        WHEN ord.CUSTOMER_EMAILID LIKE ''________-____-____-____-____________|%'' THEN SUBSTRING(
            ord.CUSTOMER_EMAILID,
            CHARINDEX(''|'', ord.CUSTOMER_EMAILID) + 1,
            LEN(ord.CUSTOMER_EMAILID)
        )
        ELSE ord.CUSTOMER_EMAILID
    END,
    NULL,
    NULL,
    CASE
        WHEN ord.TAX_EXEMPT_FLAG = ''True'' OR ord.TAX_EXEMPT_FLAG = ''Y'' THEN 1
        ELSE 0
    END,
    ord.EXTN_RISK_STATUS,
    NULL,
    1,
    txn_id,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    ord.ENTRY_TYPE,
    ord.order_header_key,
    ord.extn_brand,
    ord.extn_sub_order_type,
    ord.extn_order_total,
    modifyts
FROM
    ANALYTICS.createdOrders AS ord
INNER JOIN master.entrytype_platform_map AS pl ON pl.entry_type = ord.ENTRY_TYPE AND pl.Order_Type = ord.Order_Type
INNER JOIN master.source_brand_platform_map AS src ON src.BrandCodeForWHM = ANALYTICS.fun_get_edw_brand_by_ORDER_sellerorgcode(ord.SELLER_ORGANIZATION_CODE) AND src.PlatformName = COALESCE(pl.customer_platform_name, pl.platform_name)
INNER JOIN ANALYTICS.CREATEDORDERADDRESSTABLE AS addr ON addr.SHIP_TO_KEY = ord.SHIP_TO_KEY AND addr.BILL_TO_KEY = ord.BILL_TO_KEY
INNER JOIN MASTER.dim_order_type AS ordtype ON ord.ORDER_TYPE = ordtype.order_type_name
INNER JOIN MASTER.dim_currency AS curr ON curr.currency_code = ord.currency
INNER JOIN MASTER.dim_shipping_method AS ship ON (
    UPPER(ship.shipping_method_name) = UPPER(ord.LEVEL_OF_SERVICE) OR 
    (UPPER(ship.shipping_method_name) = UPPER(''CC_Return_Order'') AND ord.document_type = 3) OR 
    (ord.LEVEL_OF_SERVICE IS NULL AND UPPER(ship.shipping_method_name) = ''NA'' AND ord.Order_Type = ''WARRANTY'' AND ord.entry_type = ''Call Center'' AND ord.document_type = 1)
)
INNER JOIN MASTER.dim_order_status AS ordsts ON ordsts.oms_ORDER_status_code = ord.order_status
INNER JOIN ANALYTICS.CREATEDORDERCUSTOMER AS cus ON (
    (ord.EXTN_CUSTOMER_ID IS NOT NULL AND cus.extn_customer_id IS NOT NULL AND cus.EXTN_CUSTOMER_ID = ord.EXTN_CUSTOMER_ID AND cus.pk_sourceid = src.pk_sourceid) OR 
    (ord.EXTN_CUSTOMER_ID IS NULL AND cus.extn_customer_id IS NULL AND cus.ship_to_key = ord.ship_to_key AND cus.pk_sourceid = src.pk_sourceid)
)
WHERE ord.ENTRY_TYPE IS NOT NULL;

--END;



--BEGIN 
-- Insert into txn_order_header
INSERT INTO ANALYTICS.txn_order_header (
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    salesrep_customerid,
    inserted_date,
    modified_date,
    order_date,
    email_address,
    order_comments,
    order_notes,
    tax_exempt,
    risk_status,
    ship_residential,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    entry_type,
    is_bfy17,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total,
    modifyts
)
SELECT DISTINCT
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    salesrep_customerid,
    CURRENT_TIMESTAMP() AS inserted_date,
    CURRENT_TIMESTAMP() AS modified_date,
    -- TO_TIMESTAMP_NTZ(
    --     SUBSTRING(order_date, 1, 4) || ''-'' || 
    --     SUBSTRING(order_date, 5, 2) || ''-'' || 
    --     SUBSTRING(order_date, 7, 2) || '' '' || 
    --     SUBSTRING(order_date, 9, 2) || '':'' || 
    --     SUBSTRING(order_date, 11, 2) || '':'' || 
    --     SUBSTRING(order_date, 13, 2)
    -- ) AS order_date,
    TO_TIMESTAMP_NTZ(order_date) as order_date,
    email_address,
    order_comments,
    order_notes,
    CASE
        WHEN tax_exempt = ''True'' OR tax_exempt = ''Y'' THEN 1
        ELSE 0
    END AS tax_exempt,
    risk_status,
    ship_residential,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    TRY_TO_TIMESTAMP(CREATETS,''YYYYMMDDHHMISS''),
    entered_by,
    entry_type,
    is_bfy17,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    try_cast(extn_order_total as float),
    TRY_TO_TIMESTAMP(modifyts,''YYYYMMDDHHMISS'')
FROM
     TRANSFORMED.stg_ORDER_processed_order_header;

MERGE INTO ANALYTICS.txn_order_status tgt
USING (
    SELECT DISTINCT
        toh.pk_order_headerid,
        toh.fk_sourceid,
        toh.source_ref_num,
        toh.fk_order_statusid,
        toh.inserted_date,
        toh.modified_date
    FROM TRANSFORMED.stg_ORDER_processed_order_header stg
    INNER JOIN ANALYTICS.txn_order_header toh ON toh.source_ref_num = stg.source_ref_num
        AND stg.fk_sourceid = toh.fk_sourceid
) src
ON tgt.fk_order_headerid = src.pk_order_headerid
    AND tgt.source_ref_num = src.source_ref_num
    AND tgt.fk_sourceid = src.fk_sourceid
WHEN NOT MATCHED THEN
    INSERT (
        fk_order_headerid,
        fk_sourceid,
        source_ref_num,
        fk_order_statusid,
        inserted_date,
        modified_date
    )
    VALUES (
        src.pk_order_headerid,
        src.fk_sourceid,
        src.source_ref_num,
        src.fk_order_statusid,
        src.inserted_date,
        src.modified_date
    )
WHEN MATCHED THEN
    UPDATE SET
        tgt.fk_order_statusid = src.fk_order_statusid,
        tgt.modified_date = src.modified_date;

--END;      



--BEGIN
INSERT INTO ANALYTICS.TempORDER_Orders (
    pk_order_headerid,
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    inserted_date,
    modified_date,
    order_date,
    email_address,
    order_comments,
    order_notes,
    tax_exempt,
    risk_status,
    ship_residential,
    salesrep_customerid,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    entry_type,
    is_bfy17,
    revision,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total,
    modifyts
)
SELECT DISTINCT 
    toh.pk_order_headerid,
    toh.fk_sourceid,
    toh.source_ref_num,
    toh.ext_order_id,
    toh.is_domestic,
    toh.fk_shipping_addressid,
    toh.fk_billing_addressid,
    toh.fk_customerid,
    toh.fk_currencyid,
    toh.fk_shipping_methodid,
    toh.payment_amount,
    toh.gross_amount,
    toh.discount_amount,
    toh.fee_amount,
    toh.tax_amount,
    toh.shpping_fee_amount,
    toh.personalization_fee_amount,
    toh.net_amount,
    toh.fk_order_typeid,
    toh.fk_order_statusid,
    toh.fk_parent_order_headerid,
    toh.inserted_date,
    toh.modified_date,
    toh.order_date,
    toh.email_address,
    toh.order_comments,
    toh.order_notes,
    toh.tax_exempt,
    toh.risk_status,
    toh.ship_residential,
    toh.salesrep_customerid,
    toh.extn_order_locale_code,
    toh.seller_organization_code,
    toh.customer_first_name,
    toh.customer_last_name,
    toh.modifyuserid,
    toh.createuserid,
    toh.createts,
    toh.entered_by,
    toh.entry_type,
    toh.is_bfy17,
    cast(1 as NUMBER(10, 0)) AS revision, -- Ensure default value is set
    toh.order_header_key,
    toh.extn_brand,
    toh.extn_sub_order_type,
    toh.extn_order_total,
    toh.modifyts
FROM
    ANALYTICS.txn_order_header toh
INNER JOIN TRANSFORMED.stg_ORDER_processed_order_header stg
    on toh.order_header_key = stg.order_header_key 
    and TO_CHAR(CAST(toh.modifyts AS TIMESTAMP), ''YYYYMMDDHH24MISS'') = stg.modifyts;
-- WHERE
--     order_header_key IN (
--         SELECT order_header_key
--         FROM TRANSFORMED.stg_ORDER_processed_order_header
--     );

-- Create a temporary table to hold the maximum revision values
CREATE OR REPLACE TEMPORARY TABLE TempMaxRevision AS
SELECT
    MAX(aot.revision) AS max_revision,
    aot.pk_order_headerid
FROM
    ANALYTICS.audit_order_header AS aot
INNER JOIN
    ANALYTICS.TempORDER_Orders AS ttd
    ON ttd.pk_order_headerid = aot.pk_order_headerid
GROUP BY
    aot.pk_order_headerid;

-- Update TempORDER_Orders using the temporary table
UPDATE ANALYTICS.TempORDER_Orders AS ttd
SET
    Revision = CAST((tm.max_revision + 1) AS NUMBER(10, 0))
FROM
    TempMaxRevision AS tm
WHERE
    ttd.pk_order_headerid = tm.pk_order_headerid;

--END;

--BEGIN
INSERT INTO ANALYTICS.audit_order_header (
    pk_order_headerid,
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    inserted_date,
    modified_date,
    created_by,
    order_date,
    email_address,
    order_comments,
    order_notes,
    tax_exempt,
    salesrep_customerid,
    risk_status,
    ship_residential,
    revision,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    entry_type,
    is_bfy17,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total,
    modifyts
)
SELECT DISTINCT
    insord.pk_order_headerid,
    insord.fk_sourceid,
    insord.source_ref_num,
    insord.ext_order_id,
    insord.is_domestic,
    insord.fk_shipping_addressid,
    insord.fk_billing_addressid,
    insord.fk_customerid,
    insord.fk_currencyid,
    insord.fk_shipping_methodid,
    insord.payment_amount,
    insord.gross_amount,
    insord.discount_amount,
    insord.fee_amount,
    insord.tax_amount,
    insord.shpping_fee_amount,
    insord.personalization_fee_amount,
    insord.net_amount,
    insord.fk_order_typeid,
    insord.fk_order_statusid,
    insord.fk_parent_order_headerid,
    insord.inserted_date,
    insord.modified_date,
    1 AS created_by,
    insord.order_date,
    insord.email_address,
    insord.order_comments,
    insord.order_notes,
    insord.tax_exempt,
    insord.salesrep_customerid,
    insord.risk_status,
    insord.ship_residential,
    ord.Revision,
    insord.extn_order_locale_code,
    insord.seller_organization_code,
    insord.customer_first_name,
    insord.customer_last_name,
    insord.modifyuserid,
    insord.createuserid,
    insord.createts,
    insord.entered_by,
    insord.entry_type,
    insord.is_bfy17,
    insord.order_header_key,
    insord.extn_brand,
    insord.extn_sub_order_type,
    insord.extn_order_total,
    insord.modifyts
FROM ANALYTICS.txn_order_header insord
INNER JOIN ANALYTICS.TempORDER_Orders ord ON ord.source_ref_num = insord.source_ref_num;
--END;

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.createdOrderDetails (
    pk_order_headerid STRING,
    pk_skuproductid STRING,
    ORDERED_QTY STRING,
    UNIT_PRICE STRING,
    LINE_TOTAL STRING,
    is_taxable STRING,
    options STRING,
    ITEM_SHORT_DESCRIPTION STRING,
    txn_id STRING,
    PRIME_LINE_NO STRING,
    source_ref_num STRING,
    order_line_status STRING,
    bh_product_name STRING,
    personalization_fee STRING,
    order_header_key STRING,
    order_line_key STRING,
    createts STRING,
    modifyts STRING
);


INSERT INTO ANALYTICS.createdOrderDetails
SELECT DISTINCT
    toh.pk_order_headerid,
    dsl.pk_skuproductid,
    ord.ORDERED_QTY,
    ord.UNIT_PRICE,
    ord.LINE_TOTAL,
    CASE
        WHEN ord.TAXABLE_FLAG = ''N'' THEN 0
        WHEN ord.TAXABLE_FLAG = ''Y'' THEN 1
    END AS is_taxable,
    ord.PERSONALIZE_CODE AS options,
    ord.ITEM_SHORT_DESCRIPTION,
    ord.txn_id,
    ord.PRIME_LINE_NO AS PRIME_LINE_NO,
    stgpoh.source_ref_num,
    ord.order_line_status,
    dsl.bh_product_name,
    0 AS personalization_fee,
    ord.order_header_key,
    ord.order_line_key,
    ord.createts,
    ord.modifyts
FROM
    TRANSFORMED.stg_ORDER_line AS ord
    INNER JOIN TRANSFORMED.stg_ORDER_processed_order_header AS stgpoh ON stgpoh.order_header_key = ord.ORDER_HEADER_KEY
    INNER JOIN ANALYTICS.TempORDER_Orders AS toh ON toh.order_header_key = ord.order_header_key AND stgpoh.fk_sourceid = toh.fk_sourceid
    INNER JOIN MASTER.dim_source AS src ON src.pk_sourceid = stgpoh.fk_sourceid
    INNER JOIN analytics.sku_product_locale AS dsl ON dsl.sku_code = ord.ITEM_ID AND dsl.locale = src.locale
WHERE
    toh.pk_order_headerid IS NOT NULL AND ord.BUNDLE_PARENT_ORDER_LINE_KEY IS NULL;


TRUNCATE TABLE TRANSFORMED.stg_ORDER_processed_order_line;

-- Create temporary table for intermediate results (createdOrderDetails)
detailprocesseddate := current_timestamp();

-- Insert data into stg_ORDER_processed_order_line
INSERT INTO TRANSFORMED.stg_ORDER_processed_order_line (
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    inserted_date,
    modified_date,
    txn_id,
    order_line_status,
    prime_line_num,
    ext_line_id,
    order_header_key,
    order_line_key,
    createts,
    modifyts
)
SELECT DISTINCT 
    ord.pk_order_headerid,
    ord.pk_skuproductid,
    SUM(TRY_CAST(COALESCE(ord.ORDERED_QTY, 0) AS NUMBER(18,5))),
    ord.UNIT_PRICE,
    SUM(TRY_CAST(COALESCE(ord.LINE_TOTAL, 0) AS NUMBER(18,5))),
    ord.is_taxable,
    ord.options,
    SUM(TRY_CAST(COALESCE(ord.personalization_fee, 0) AS NUMBER(18,5))),
    ord.bh_product_name,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    ord.txn_id,
    ord.order_line_status,
    ord.PRIME_LINE_NO,
    ord.ORDER_LINE_KEY,
    ord.order_header_key,
    ord.order_line_key,
    ord.createts,
    ord.modifyts
FROM
    ANALYTICS.createdOrderDetails AS ord
GROUP BY
    ord.pk_skuproductid,
    ord.UNIT_PRICE,
    ord.is_taxable,
    ord.source_ref_num,
    ord.order_line_status,
    ord.bh_product_name,
    ord.options,
    ord.pk_order_headerid,
    ord.txn_id,
    ord.PRIME_LINE_NO,
    ord.ORDER_LINE_KEY,
    ord.order_header_key,
    ord.order_line_key,
    ord.createts,
    ord.modifyts;



-- Insert into txn_order_detail and capture inserted records
INSERT INTO  ANALYTICS.txn_order_detail (
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    inserted_date,
    modified_date,
    prime_line_num,
    ext_line_id,
    order_header_key,
    order_line_key,
    createts,
    modifyts
)
SELECT DISTINCT 
    sol.fk_order_headerid,
    sol.fk_skuproductid,
    sol.quantity,
    sol.product_price,
    sol.total_price,
    sol.is_taxable,
    sol.options,
    sol.personalization_fee,
    sol.product_name,
    sol.inserted_date,
    sol.modified_date,
    sol.prime_line_num,
    sol.ext_line_id,
    sol.order_header_key,
    sol.order_line_key,
    TRY_TO_TIMESTAMP(sol.createts,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(sol.modifyts,''YYYYMMDDHHMISS'')
FROM
    TRANSFORMED.stg_ORDER_processed_order_line AS sol
    LEFT JOIN ANALYTICS.txn_order_detail AS tod ON tod.fk_order_headerid = sol.fk_order_headerid
        AND tod.fk_skuproductid = sol.fk_skuproductid
        AND tod.prime_line_num = sol.prime_line_num
WHERE
    tod.pk_order_detailid IS NULL;


INSERT INTO ANALYTICS.TempOrderDetails(
    pk_order_detailid, 
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    created_by, 
    CREATED_DATE,
    MODIFIED_DATE,
    revision,
    prime_line_num,
    ext_line_id,
    order_header_key,
    order_line_key,
    createts,
    modifyts
)
SELECT DISTINCT 
     pk_order_detailid,
    tod.fk_order_headerid,
    tod.fk_skuproductid,
    tod.quantity,
    tod.product_price,
    tod.total_price,
    tod.is_taxable,
    tod.options,
    tod.personalization_fee,
    tod.product_name,
    1 AS created_by, -- Replace with the appropriate user or system
    tod.inserted_date,
    tod.modified_date,
    CAST(1 AS NUMBER(10, 0)) AS revision,
    tod.prime_line_num,
    tod.ext_line_id,
    tod.order_header_key,
    tod.order_line_key,
    tod.createts,
    tod.modifyts
    from ANALYTICS.txn_order_detail tod
    inner join TRANSFORMED.stg_ORDER_processed_order_line sol
        on sol.order_line_key = tod.order_line_key 
    and sol.modifyts = TO_CHAR(CAST(tod.modifyts AS TIMESTAMP), ''YYYYMMDDHH24MISS'')
    AND tod.fk_skuproductid = sol.fk_skuproductid
        AND tod.prime_line_num = sol.prime_line_num;


    
-- SELECT DISTINCT 
--      pk_order_detailid
--     sol.fk_order_headerid,
--     sol.fk_skuproductid,
--     sol.quantity,
--     sol.product_price,
--     sol.total_price,
--     sol.is_taxable,
--     sol.options,
--     sol.personalization_fee,
--     sol.product_name,
--     ''system'' AS created_by, -- Replace with the appropriate user or system
--     CURRENT_TIMESTAMP(),
--     CURRENT_TIMESTAMP(),
--     CAST(1 AS NUMBER(10, 0)) AS revision,
--     sol.prime_line_num,
--     sol.ext_line_id,
--     sol.order_header_key,
--     sol.order_line_key
-- FROM
--     TRANSFORMED.stg_ORDER_processed_order_line AS sol
--     LEFT JOIN   ANALYTICS.txn_order_detail AS tod ON tod.fk_order_headerid = sol.fk_order_headerid
--         AND tod.fk_skuproductid = sol.fk_skuproductid
--         AND tod.prime_line_num = sol.prime_line_num
-- where
--     tod.pk_order_detailid IS NULL;




-- UPDATE
-- 	ANALYTICS.TempOrderDetails
-- SET
-- 	Revision = CAST((aot.revision + 1) as int)
-- FROM
--         ANALYTICS.TempOrderDetails as ttd
--         inner join (
-- 		SELECT
--             MAX(aot.revision) as revision,
--             aot.pk_order_detailid,
--             aot.fk_order_headerid
--         from
--             ANALYTICS.audit_order_detail as aot
--             inner join ANALYTICS.TempOrderDetails as ttd on ttd.pk_order_detailid = aot.pk_order_detailid and ttd.fk_order_headerid = aot.fk_order_headerid
--         group by
-- 			aot.pk_order_detailid,
-- 			aot.fk_order_headerid
-- 	) as aot on ttd.pk_order_detailid = aot.pk_order_detailid
--             and ttd.fk_order_headerid = aot.fk_order_headerid;            

                 MERGE INTO ANALYTICS.TempOrderDetails AS ttd
USING (
    SELECT
        MAX(aot.revision) AS revision,
        aot.pk_order_detailid,
        aot.fk_order_headerid
    FROM
        ANALYTICS.audit_order_detail AS aot
    GROUP BY
        aot.pk_order_detailid,
        aot.fk_order_headerid
) AS src
ON ttd.pk_order_detailid = src.pk_order_detailid
   AND ttd.fk_order_headerid = src.fk_order_headerid
WHEN MATCHED THEN
    UPDATE SET
        ttd.Revision = CAST((src.revision + 1) AS INT);
 


INSERT INTO ANALYTICS.audit_order_detail (
    pk_order_detailid,
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    created_by,
    created_date,
    modified_date,
    revision,
    order_header_key,
    order_line_key,
    createts,
    modifyts
)
SELECT
    pk_order_detailid,
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    created_by,
    created_date,
    modified_date,
    revision,
    order_header_key,
    order_line_key,
    createts,
    modifyts
FROM
    ANALYTICS.TempOrderDetails;


MERGE INTO ANALYTICS.txn_order_detail_status AS Target
USING (
    SELECT DISTINCT
        stg.fk_order_headerid,
        tod.pk_order_detailid,
        pk_order_statusid,
        stg.fk_skuproductid
    FROM
        TRANSFORMED.stg_ORDER_processed_order_line AS stg
    INNER JOIN ANALYTICS.TempOrderDetails AS tod ON tod.fk_order_headerid = stg.fk_order_headerid
        AND stg.fk_skuproductid = tod.fk_skuproductid
    INNER JOIN MASTER.dim_order_status AS dods ON dods.oms_ORDER_status_code = stg.order_line_status
) AS Source ON Source.fk_order_headerid = Target.pk_order_headerid
    AND Source.fk_skuproductid = Target.fk_skuproductid
    AND Source.pk_order_detailid = Target.pk_order_detailid
WHEN NOT MATCHED THEN
INSERT (pk_order_headerid, pk_order_detailid, fk_ORDER__detail_statusid, fk_skuproductid)
VALUES (Source.fk_order_headerid, Source.pk_order_detailid, Source.pk_order_statusid, Source.fk_skuproductid);

-- Update transaction record count and status
SELECT
    COUNT(*) INTO :prcessedHeaderRecordCount
FROM
    ANALYTICS.TempORDER_Orders;

SELECT
    COUNT(*) INTO :prcessedLineRecordCount
FROM
    ANALYTICS.TempOrderDetails;


MERGE INTO RAW.raw_ORDER_header AS target
USING (
    SELECT DISTINCT
        roh.ORDER_NO,
        roh.ORDER_HEADER_KEY,
        roh.modifyts,
        ''Processed'' AS processing_status,
        '''' AS processing_comment,
        '''' AS processing_errortype
    FROM RAW.raw_ORDER_header AS roh
    INNER JOIN TRANSFORMED.stg_ORDER_header AS rod 
        ON rod.ORDER_NO = roh.ORDER_NO 
        AND rod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY 
        AND roh.modifyts = rod.modifyts
    LEFT JOIN ANALYTICS.TempORDER_Orders AS tod 
        ON tod.source_ref_num = roh.ORDER_NO 
        AND tod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY
        AND TO_CHAR(CAST(tod.modifyts AS TIMESTAMP), ''YYYYMMDDHH24MISS'') = roh.modifyts
    WHERE 
        roh.processing_status IN (''Pending'', ''Failed'')
        AND tod.source_ref_num IS NOT NULL
) AS source
ON (target.ORDER_NO = source.ORDER_NO AND target.ORDER_HEADER_KEY = source.ORDER_HEADER_KEY AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;

MERGE INTO RAW.raw_ORDER_line AS target
USING (
    SELECT DISTINCT 
        roh.ORDER_LINE_KEY,
        roh.PRIME_LINE_NO,
        roh.modifyts,
        ''Processed'' AS processing_status,
        '''' AS processing_comment,
        '''' AS processing_errortype
    FROM RAW.raw_ORDER_line AS roh
    INNER JOIN TRANSFORMED.stg_ORDER_line AS rod 
        ON rod.ORDER_LINE_KEY = roh.ORDER_LINE_KEY
        AND rod.PRIME_LINE_NO = roh.PRIME_LINE_NO 
        AND roh.modifyts = rod.modifyts
    INNER JOIN ANALYTICS.TempOrderDetails AS tod 
        ON tod.ext_line_id = roh.ORDER_LINE_KEY 
        AND tod.prime_line_num = rod.PRIME_LINE_NO
        AND TO_CHAR(CAST(tod.modifyts AS TIMESTAMP), ''YYYYMMDDHH24MISS'') = rod.modifyts
    WHERE 
        roh.processing_status IN (''Pending'', ''Failed'')
) AS source
ON (target.ORDER_LINE_KEY = source.ORDER_LINE_KEY 
    AND target.PRIME_LINE_NO = source.PRIME_LINE_NO 
    AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;




CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.TempAmendOrders (
    pk_order_headerid BIGINT,
    fk_sourceid SMALLINT,
    source_ref_num VARCHAR(100),
    ext_order_id VARCHAR(255),
    is_domestic BOOLEAN,
    fk_shipping_addressid BIGINT,
    fk_billing_addressid BIGINT,
    fk_customerid BIGINT,
    fk_currencyid INT,
    fk_shipping_methodid SMALLINT,
    payment_amount DECIMAL(9, 2),
    gross_amount DECIMAL(9, 2),
    discount_amount DECIMAL(9, 2),
    fee_amount DECIMAL(9, 2),
    tax_amount DECIMAL(9, 2),
    shpping_fee_amount DECIMAL(9, 2),
    personalization_fee_amount DECIMAL(9, 2),
    net_amount DECIMAL(9, 2),
    fk_order_typeid SMALLINT,
    fk_order_statusid SMALLINT,
    fk_parent_order_headerid BIGINT,
    inserted_date TIMESTAMP,
    modified_date TIMESTAMP,
    order_date TIMESTAMP,
    email_address VARCHAR(255),
    order_comments VARCHAR,
    order_notes VARCHAR,
    tax_exempt BOOLEAN,
    salesrep_customerid VARCHAR,
    risk_status VARCHAR,
    ship_residential BOOLEAN,
    revision VARCHAR(255),
    txn_id VARCHAR,
    extn_order_locale_code VARCHAR,
    seller_organization_code VARCHAR,
    customer_first_name VARCHAR,
    customer_last_name VARCHAR,
    modifyuserid VARCHAR,
    createuserid VARCHAR,
    createts VARCHAR,
    entered_by VARCHAR,
    is_bfy17 BOOLEAN DEFAULT FALSE,
    entry_type VARCHAR(255),
    order_header_key VARCHAR(255),
	extn_brand VARCHAR(255),
	extn_sub_order_type VARCHAR(255),
	extn_order_total VARCHAR(255),
    modifyts VARCHAR(255)
);

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.TempAmendOrderDetails (
    fk_order_headerid BIGINT NOT NULL,
    fk_skuproductid INT NOT NULL,
    quantity INT NOT NULL,
    product_price DECIMAL(9, 2) NOT NULL,
    total_price DECIMAL(9, 2) NOT NULL,
    is_taxable BOOLEAN,
    options VARCHAR(255),
    personalization_fee DECIMAL(9, 2),
    product_name VARCHAR(255),
    created_by INT,
    created_date TIMESTAMP,
    modified_date TIMESTAMP,
    pk_order_detailid BIGINT NOT NULL,
    Revision INT,
    prime_line_num INT,
    txn_id VARCHAR,
    ext_line_id VARCHAR,
    order_header_key VARCHAR,
    order_line_key VARCHAR,
    extn_return_confirmed_by VARCHAR,
    extn_edi_gcn VARCHAR,
    extn_pk_header_key VARCHAR,
    extn_merchant_id VARCHAR,
    extn_is_avalara VARCHAR,
    extn_req_cancel_date VARCHAR,
    extn_is_email_sent VARCHAR,
    extn_is_txn_committed VARCHAR,
    extn_tax_txn_date VARCHAR,
    extn_last_refund_txn_code VARCHAR,
    extn_refund_txn_code VARCHAR,
    extn_min_estimated_delivery_date VARCHAR,
    extn_max_estimated_delivery_date VARCHAR,
    extn_apply_migration_hold VARCHAR,
    extn_signifyd_order_id VARCHAR,
    extn_primary_reason VARCHAR,
    extn_secondary_reason VARCHAR,
    extn_sales_entry_type VARCHAR,
    extn_sales_order_type VARCHAR,
    extn_warranty_order_no VARCHAR,
    extn_seller_payment_type VARCHAR,
    createts VARCHAR,
    modifyts VARCHAR
);

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.updatedOrders(
    order_header_key VARCHAR,
    enterprise_key VARCHAR,
    order_no VARCHAR,
    sourcing_classification VARCHAR,
    buyer_organization_code VARCHAR,
    seller_organization_code VARCHAR,
    document_type VARCHAR,
    bill_to_key VARCHAR,
    bill_to_id VARCHAR,
    customer_rewards_no VARCHAR,
    vendor_id VARCHAR,
    ship_to_key VARCHAR,
    ship_to_id VARCHAR,
    ship_node VARCHAR,
    receiving_node VARCHAR,
    buyer_receiving_node_id VARCHAR,
    mark_for_key VARCHAR,
    buyer_mark_for_node_id VARCHAR,
    req_delivery_date VARCHAR,
    req_cancel_date VARCHAR,
    req_ship_date VARCHAR,
    default_template VARCHAR,
    division VARCHAR,
    order_date VARCHAR,
    order_type VARCHAR,
    draft_order_flag VARCHAR,
    order_purpose VARCHAR,
    return_oh_key_for_exchange VARCHAR,
    exchange_type VARCHAR,
    pending_transfer_in VARCHAR,
    return_by_gift_recipient VARCHAR,
    allocation_rule_id VARCHAR,
    priority_code VARCHAR,
    priority_number VARCHAR,
    contact_key VARCHAR,
    scac VARCHAR,
    carrier_service_code VARCHAR,
    custcarrier_account_no VARCHAR,
    notify_after_shipment_flag VARCHAR,
    created_at_node VARCHAR,
    has_derived_child VARCHAR,
    has_derived_parent VARCHAR,
    notification_type VARCHAR,
    notification_reference VARCHAR,
    entry_type VARCHAR,
    authorized_client VARCHAR,
    entered_by VARCHAR,
    personalize_code VARCHAR,
    hold_flag VARCHAR,
    hold_reason_code VARCHAR,
    customer_po_no VARCHAR,
    customer_customer_po_no VARCHAR,
    order_name VARCHAR,
    payment_rule_id VARCHAR,
    terms_code VARCHAR,
    delivery_code VARCHAR,
    charge_actual_freight VARCHAR,
    tax VARCHAR,
    total_amount VARCHAR,
    original_total_amount VARCHAR,
    original_tax VARCHAR,
    currency VARCHAR,
    enterprise_currency VARCHAR,
    reporting_conversion_rate VARCHAR,
    reporting_conversion_date VARCHAR,
    payment_status VARCHAR,
    authorization_expiration_date VARCHAR,
    search_criteria_1 VARCHAR,
    search_criteria_2 VARCHAR,
    customer_emailid VARCHAR,
    fob VARCHAR,
    total_adjustment_amount VARCHAR,
    other_charges VARCHAR,
    price_program_key VARCHAR,
    taxpayer_id VARCHAR,
    tax_jurisdiction VARCHAR,
    tax_exempt_flag VARCHAR,
    tax_exemption_certificate VARCHAR,
    purpose VARCHAR,
    invoice_complete VARCHAR,
    order_closed VARCHAR,
    next_alert_ts VARCHAR,
    do_not_consolidate VARCHAR,
    chain_type VARCHAR,
    adjustment_invoice_pending VARCHAR,
    auto_cancel_date VARCHAR,
    sale_voided VARCHAR,
    is_ship_complete VARCHAR,
    is_line_ship_complete VARCHAR,
    is_ship_single_node VARCHAR,
    is_line_ship_single_node VARCHAR,
    cancel_order_on_excp_flag VARCHAR,
    optimization_type VARCHAR,
    purge_history_date VARCHAR,
    pricing_classification_code VARCHAR,
    source_type VARCHAR,
    source_key VARCHAR,
    linked_source_key VARCHAR,
    original_container_key VARCHAR,
    sold_to_key VARCHAR,
    team_code VARCHAR,
    level_of_service VARCHAR,
    next_iter_seq_no VARCHAR,
    next_iter_date VARCHAR,
    hrs_before_next_iter VARCHAR,
    createts VARCHAR,
    modifyts VARCHAR,
    createuserid VARCHAR,
    modifyuserid VARCHAR,
    createprogid VARCHAR,
    modifyprogid VARCHAR,
    lockid VARCHAR,
    department_code VARCHAR,
    buyer_user_id VARCHAR,
    recreate_authorizations VARCHAR,
    customer_contact_id VARCHAR,
    opportunity_key VARCHAR,
    is_expiration_date_overridden VARCHAR,
    expiration_date VARCHAR,
    approval_cycle VARCHAR,
    in_store_payment_required VARCHAR,
    immediate_settlement_value VARCHAR,
    customer_age VARCHAR,
    cart_id VARCHAR,
    rollout_version VARCHAR,
    all_addresses_verified VARCHAR,
    compl_gift_box_qty VARCHAR,
    no_of_auth_strikes VARCHAR,
    source_ip_address VARCHAR,
    customer_first_name VARCHAR,
    customer_last_name VARCHAR,
    customer_phone_no VARCHAR,
    customer_zip_code VARCHAR,
    index_version VARCHAR,
    extn_customer_type VARCHAR,
    extn_customer_id VARCHAR,
    extn_cba_ship_label VARCHAR,
    extn_amazon_tfm VARCHAR,
    extn_tfm_ship_status VARCHAR,
    extn_financed_by_affirm VARCHAR,
    extn_risk_status VARCHAR,
    extn_sales_rep_cust_id VARCHAR,
    extn_latest_ship_date VARCHAR,
    extn_latest_delivery_date VARCHAR,
    extn_market_place_id VARCHAR,
    extn_order_status VARCHAR,
    extn_is_prime VARCHAR,
    extn_ga_tag_id VARCHAR,
    extn_fraud_status VARCHAR,
    extn_order_locale_code VARCHAR,
    extn_shipto_firstname VARCHAR,
    extn_shipto_lastname VARCHAR,
    extn_shipto_zipcode VARCHAR,
    extn_giftee_full_name VARCHAR,
    extn_giftee_email_id VARCHAR,
    extn_sms_opt_in VARCHAR,
    imported_date VARCHAR,
    txn_id VARCHAR,
    order_status VARCHAR,
    extn_brand VARCHAR,
    extn_sub_order_type VARCHAR,
    extn_order_total VARCHAR,
    extn_return_confirmed_by VARCHAR,
    extn_edi_gcn VARCHAR,
    extn_pk_header_key VARCHAR,
    extn_merchant_id VARCHAR,
    extn_is_avalara VARCHAR,
    extn_req_cancel_date VARCHAR,
    extn_is_email_sent VARCHAR,
    extn_is_txn_committed VARCHAR,
    extn_tax_txn_date VARCHAR,
    extn_last_refund_txn_code VARCHAR,
    extn_refund_txn_code VARCHAR,
    extn_min_estimated_delivery_date VARCHAR,
    extn_max_estimated_delivery_date VARCHAR,
    extn_apply_migration_hold VARCHAR,
    extn_signifyd_order_id VARCHAR,
    extn_primary_reason VARCHAR,
    extn_secondary_reason VARCHAR,
    extn_sales_entry_type VARCHAR,
    extn_sales_order_type VARCHAR,
    extn_warranty_order_no VARCHAR,
    extn_seller_payment_type VARCHAR,
    pk_order_headerid VARCHAR not NULL
);

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.UPDATEDORDERCUSTOMER(
    pk_customerid BIGINT not null,
    EXTN_CUSTOMER_ID VARCHAR,
    ship_to_key VARCHAR not null,
    pk_sourceid INT not null
);

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.UPDATEDORDERADDRESSTABLE(
    shipid VARCHAR not null,
    billid VARCHAR not null,
    BILL_TO_KEY VARCHAR not null,
    SHIP_TO_KEY VARCHAR not null
);



truncate table TRANSFORMED.stg_ORDER_processed_order_header;


-- Update txn_order_header with ORDER_HEADER_KEY from raw_ORDER_header
-- UPDATE ANALYTICS.txn_order_header
-- SET ORDER_HEADER_KEY = (
--     SELECT r.ORDER_HEADER_KEY
--     FROM RAW.raw_ORDER_header r
--     WHERE ANALYTICS.txn_order_header.source_ref_num = r.order_no
--       AND r.processing_status <> ''Processed''
-- )
-- WHERE ORDER_HEADER_KEY IS NULL
--   AND EXISTS (
--     SELECT 1
--     FROM RAW.raw_ORDER_header r
--     WHERE ANALYTICS.txn_order_header.source_ref_num = r.order_no
--       AND r.processing_status <> ''Processed''
-- );

UPDATE ANALYTICS.txn_order_header AS t
SET ORDER_HEADER_KEY = r.ORDER_HEADER_KEY
FROM RAW.raw_ORDER_header AS r
WHERE t.source_ref_num = r.order_no
  AND r.processing_status <> ''Processed''
  AND t.ORDER_HEADER_KEY IS NULL;



-- Insert into #updatedOrders
INSERT INTO ANALYTICS.updatedOrders
SELECT DISTINCT 
    ord.*,
    ordheadrer.pk_order_headerid
FROM TRANSFORMED.stg_ORDER_header AS ord 
INNER JOIN ANALYTICS.txn_order_header AS ordheadrer ON ordheadrer.source_ref_num = ord.ORDER_NO
    AND ordheadrer.ORDER_HEADER_KEY = ord.ORDER_HEADER_KEY 
LEFT JOIN ANALYTICS.createdOrders AS crorder ON crorder.order_no = ord.order_no
    AND crorder.ORDER_HEADER_KEY = ord.ORDER_HEADER_KEY
    AND crorder.modifyts = ord.modifyts
WHERE ordheadrer.pk_order_headerid IS NOT NULL AND crorder.order_no IS NULL ;

-- Update txn_order_header based on conditions
-- MERGE INTO ANALYTICS.txn_order_header AS ordheadrer
-- USING (
--     SELECT 
--         ord.order_header_key,
--         ord.customer_po_no,
--         ord.extn_brand,
--         o.pk_order_typeid,
--         s.pk_sourceid,
--         b.BrandCodeForWHM
--         --ordheadrer.pk_order_headerid
--     FROM TRANSFORMED.stg_ORDER_header AS ord
--     INNER JOIN MASTER.dim_order_type o ON o.pk_order_typeid = ordheadrer.fk_order_typeid
--     INNER JOIN MASTER.dim_source s ON s.pk_sourceid = ordheadrer.fk_sourceid
--     INNER JOIN MASTER.dim_brand b ON b.pk_brandid = s.fk_brandid AND b.BrandCodeForWHM = ord.extn_brand
--     WHERE ord.order_name = ''MIGRATED''
-- ) AS updates
-- ON ordheadrer.source_ref_num = updates.customer_po_no
--    AND ordheadrer.ORDER_HEADER_KEY = updates.order_header_key
--    --AND ordheadrer.pk_order_headerid IS NOT NULL
--    AND ordheadrer.order_header_key IS NULL
-- WHEN MATCHED THEN
-- UPDATE SET 
--     ordheadrer.order_header_key = updates.order_header_key;


INSERT INTO ANALYTICS.updatedOrders
SELECT DISTINCT 
    ord.*,
    ordheadrer.pk_order_headerid
FROM
    TRANSFORMED.stg_ORDER_header AS ord
INNER JOIN ANALYTICS.txn_order_header AS ordheadrer ON ordheadrer.source_ref_num = ord.customer_po_no
    AND ordheadrer.ORDER_HEADER_KEY = ord.ORDER_HEADER_KEY
INNER JOIN MASTER.dim_order_type o ON o.pk_order_typeid = ordheadrer.fk_order_typeid 
INNER JOIN MASTER.dim_source s ON s.pk_sourceid = ordheadrer.fk_sourceid
INNER JOIN MASTER.dim_brand b ON b.pk_brandid = s.fk_brandid AND b.BrandCodeForWHM = ord.extn_brand
WHERE ordheadrer.pk_order_headerid IS NOT NULL AND ord.order_name = ''MIGRATED'';


CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.CUSTOMER_IDS_ORDER_ORDER_ (
    customer_id VARCHAR NOT NULL
);

INSERT INTO ANALYTICS.CUSTOMER_IDS_ORDER_ORDER_
SELECT DISTINCT EXTN_CUSTOMER_ID 
FROM ANALYTICS.updatedOrders
WHERE EXTN_CUSTOMER_ID IS NOT NULL;

INSERT INTO ANALYTICS.CUSTOMER_IDS_ORDER_ORDER_
SELECT DISTINCT ship_to_key 
FROM ANALYTICS.updatedOrders;

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.DIMCUSTOMERDATA_FOR_ORDER_ORDER_ (
    pk_customerid BIGINT NOT NULL,
    fk_sourceid SMALLINT NOT NULL,
    source_ref_num NVARCHAR(50) NOT NULL
);

INSERT INTO ANALYTICS.DIMCUSTOMERDATA_FOR_ORDER_ORDER_
SELECT DISTINCT 
    pk_customerid,
    fk_sourceid,
    source_ref_num 
FROM analytics.customer AS d
INNER JOIN ANALYTICS.CUSTOMER_IDS_ORDER_ORDER_ AS t ON t.customer_id = d.source_ref_num;


INSERT INTO ANALYTICS.UPDATEDORDERCUSTOMER 
WITH DistinctCustomerInfo AS (
    SELECT
        MIN(cus.pk_customerid) AS pk_customerid,
        ord.EXTN_CUSTOMER_ID,
        ord.ship_to_key,
        src.pk_sourceid
    FROM ANALYTICS.updatedOrders AS ord
    INNER JOIN master.entrytype_platform_map AS pl
        ON pl.entry_type = ord.ENTRY_TYPE AND pl.Order_Type = ord.Order_Type
    INNER JOIN master.source_brand_platform_map AS src
        ON src.BrandCodeForWHM = ANALYTICS.fun_get_edw_brand_by_ORDER_sellerorgcode(ord.SELLER_ORGANIZATION_CODE)
        AND src.PlatformName = COALESCE(pl.customer_platform_name, pl.platform_name)
    INNER JOIN
        ANALYTICS.DIMCUSTOMERDATA_FOR_ORDER_ORDER_ AS cus
        ON (cus.source_ref_num = ord.EXTN_CUSTOMER_ID AND cus.fk_sourceid = src.pk_sourceid)
        OR (cus.source_ref_num = ord.EXTN_CUSTOMER_ID AND ord.Order_Type = ''WARRANTY'')
        OR (cus.source_ref_num = ord.ship_to_key AND cus.fk_sourceid = src.pk_sourceid)
    GROUP BY
        ord.EXTN_CUSTOMER_ID,
        ord.ship_to_key,
        src.pk_sourceid
)
SELECT DISTINCT
        pk_customerid,
        EXTN_CUSTOMER_ID,
        ship_to_key,
        pk_sourceid
 FROM DistinctCustomerInfo;

 

	drop table ANALYTICS.CUSTOMER_IDS_ORDER_ORDER_;
	drop table ANALYTICS.DIMCUSTOMERDATA_FOR_ORDER_ORDER_;

    INSERT INTO ANALYTICS.UPDATEDORDERADDRESSTABLE
WITH DistinctAddresses AS (
    SELECT DISTINCT
        shipaddr.pk_addressid AS shipid,
        billaddr.pk_addressid AS billid,
        ord.BILL_TO_KEY,
        ord.SHIP_TO_KEY
    FROM
        ANALYTICS.updatedOrders AS ord
    INNER JOIN
        ANALYTICS.txn_address AS shipaddr
        ON CAST(shipaddr.ext_address_id AS VARCHAR) = CAST(ord.SHIP_TO_KEY AS VARCHAR) AND shipaddr.fk_address_typeid = 1
    INNER JOIN
        ANALYTICS.txn_address AS billaddr
        ON CAST(billaddr.ext_address_id AS VARCHAR) = CAST(ord.BILL_TO_KEY AS VARCHAR) AND billaddr.fk_address_typeid = 2
    WHERE
        shipaddr.pk_addressid IS NOT NULL AND billaddr.pk_addressid IS NOT NULL
)
 SELECT shipid, billid, BILL_TO_KEY, SHIP_TO_KEY
FROM DistinctAddresses;


-- 1818 Originally
INSERT INTO TRANSFORMED.stg_ORDER_processed_order_header
(
    pk_order_headerid,
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    salesrep_customerid,
    inserted_date,
    modified_date,
    order_date,
    email_address,
    order_comments,
    order_notes,
    tax_exempt,
    risk_status,
    ship_residential,
    is_bfy17,
    txn_id,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    entry_type,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total,
    modifyts
)
SELECT DISTINCT
    ord.pk_order_headerid,
    src.pk_sourceid,
    ord.order_no,
    ord.ORDER_HEADER_KEY,
    CASE
        WHEN ord.SELLER_ORGANIZATION_CODE = ''BH_US'' THEN 1
        ELSE 0
    END AS is_domestic,
    NULL AS fk_shipping_addressid,
    NULL AS fk_billing_addressid,
    cus.pk_customerid,
    curr.pk_currencyid,
    NULL AS fk_shipping_methodid,
    TRY_CAST(ord.TOTAL_AMOUNT AS FLOAT),
    TRY_CAST(ord.ORIGINAL_TOTAL_AMOUNT AS FLOAT),
    TRY_CAST(ord.TOTAL_ADJUSTMENT_AMOUNT AS FLOAT),
    0 AS fee_amount,
    TRY_CAST(ord.tax AS FLOAT),
    0 AS shpping_fee_amount,
    0 AS personalization_fee_amount,
    TRY_CAST(ord.TOTAL_AMOUNT AS FLOAT),
    ordtype.pk_order_typeid,
    CASE WHEN ord.order_status IS NULL OR ord.order_status = '''' THEN -1 ELSE -2 END AS fk_order_statusid,
    NULL AS fk_parent_order_headerid,
    CASE
        WHEN ord.ENTRY_TYPE = ''Call Center'' THEN ord.ENTERED_BY
        ELSE ord.EXTN_SALES_REP_CUST_ID
    END AS salesrep_customerid,
    CURRENT_TIMESTAMP() AS inserted_date,
    CURRENT_TIMESTAMP() AS modified_date,
    TO_TIMESTAMP(SUBSTRING(order_date, 1, 4) || ''-'' || SUBSTRING(order_date, 5, 2) || ''-'' || SUBSTRING(order_date, 7, 2) || '' '' || SUBSTRING(order_date, 9, 2) || '':'' || SUBSTRING(order_date, 11, 2) || '':'' || SUBSTRING(order_date, 13, 2), ''YYYY-MM-DD HH24:MI:SS'') AS order_date,
    CASE 
        WHEN ord.CUSTOMER_EMAILID LIKE ''________-____-____-____-____________|%'' THEN SUBSTRING(ord.CUSTOMER_EMAILID, CHARINDEX(''|'', ord.CUSTOMER_EMAILID) + 1, LEN(ord.CUSTOMER_EMAILID))
        ELSE ord.CUSTOMER_EMAILID
    END AS email_address,
    NULL AS order_comments,
    NULL AS order_notes,
    CASE
        WHEN ord.TAX_EXEMPT_FLAG = ''True'' OR ord.TAX_EXEMPT_FLAG = ''Y'' THEN 1
        ELSE 0
    END AS tax_exempt,
    ord.EXTN_RISK_STATUS AS risk_status,
    1 AS ship_residential,
    1 AS is_bfy17,
    txn_id,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    ord.entry_type,
    ord.order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total,
    modifyts
FROM
    ANALYTICS.updatedOrders AS ord
INNER JOIN
    master.entrytype_platform_map AS pl ON pl.entry_type = ord.ENTRY_TYPE AND pl.Order_Type = ord.Order_Type
INNER JOIN
    master.source_brand_platform_map AS src ON src.BrandCodeForWHM = ANALYTICS.fun_get_edw_brand_by_ORDER_sellerorgcode(ord.SELLER_ORGANIZATION_CODE) AND src.PlatformName = COALESCE(pl.customer_platform_name, pl.platform_name)
INNER JOIN
    MASTER.dim_order_type AS ordtype ON ord.ORDER_TYPE = ordtype.order_type_name
INNER JOIN
    MASTER.dim_currency AS curr ON curr.currency_code = ord.currency
LEFT JOIN
    ANALYTICS.updatedOrderCustomer AS cus ON 
    (ord.EXTN_CUSTOMER_ID IS NOT NULL AND cus.extn_customer_id IS NOT NULL AND cus.EXTN_CUSTOMER_ID = ord.EXTN_CUSTOMER_ID AND cus.pk_sourceid = src.pk_sourceid AND cus.ship_to_key = ord.ship_to_key)
    OR 
    (ord.EXTN_CUSTOMER_ID IS NULL AND cus.extn_customer_id IS NULL AND cus.ship_to_key = ord.ship_to_key AND cus.pk_sourceid = src.pk_sourceid)
WHERE
    ord.ENTRY_TYPE IS NOT NULL ;


MERGE INTO TRANSFORMED.stg_ORDER_processed_order_header AS sh
USING (
    SELECT distinct ord.order_no, ord.order_header_key, ordsts.pk_order_statusid
    FROM ANALYTICS.updatedOrders AS ord
    JOIN MASTER.dim_order_status AS ordsts
    ON ordsts.oms_ORDER_status_code = ord.order_status
) AS src
ON sh.source_ref_num = src.order_no 
   AND sh.order_header_key = src.order_header_key
WHEN MATCHED AND sh.fk_order_statusid != src.pk_order_statusid
THEN UPDATE SET fk_order_statusid = src.pk_order_statusid;


-- Update TRANSFORMED.stg_ORDER_processed_order_header 
-- set fk_order_statusid = ordsts.pk_order_statusid
-- from  TRANSFORMED.stg_ORDER_processed_order_header as sh
-- inner join ANALYTICS.updatedOrders as ord on ord.order_no = sh.source_ref_num and ord.order_header_key = sh.order_header_key
-- inner join  MASTER.dim_order_status AS ordsts ON ordsts.oms_ORDER_status_code = ord.order_status;

--RETURN ''here'';

MERGE INTO ANALYTICS.txn_order_header AS tgt
USING (
    SELECT DISTINCT
        pk_order_headerid,
        fk_sourceid,
        source_ref_num,
        ext_order_id,
        is_domestic,
        fk_shipping_addressid,
        fk_billing_addressid,
        fk_customerid,
        fk_currencyid,
        fk_shipping_methodid,
        payment_amount,
        gross_amount,
        discount_amount,
        fee_amount,
        tax_amount,
        shpping_fee_amount,
        personalization_fee_amount,
        net_amount,
        fk_order_typeid,
        fk_order_statusid,
        fk_parent_order_headerid,
        salesrep_customerid,
        inserted_date,
        modified_date,
        order_date,
        email_address,
        order_comments,
        order_notes,
        tax_exempt,
        risk_status,
        ship_residential,
        txn_id,
        extn_order_locale_code,
        seller_organization_code,
        customer_first_name,
        customer_last_name,
        modifyuserid ,
        createuserid ,
        createts,
        entered_by,
        entry_type,
        is_bfy17,
        order_header_key,
        extn_brand,
        extn_sub_order_type,
        try_cast(extn_order_total as float) extn_order_total,
        modifyts
    FROM
        TRANSFORMED.stg_ORDER_processed_order_header
    WHERE
        fk_order_statusid <> -2
) AS src ON src.pk_order_headerid = tgt.pk_order_headerid
WHEN MATCHED THEN
    UPDATE SET
        tgt.is_domestic = src.is_domestic,
        tgt.fk_shipping_addressid = tgt.fk_shipping_addressid,
        tgt.fk_billing_addressid = tgt.fk_billing_addressid,
        tgt.fk_customerid = src.fk_customerid,
        tgt.fk_currencyid = src.fk_currencyid,
        tgt.fk_shipping_methodid = src.fk_shipping_methodid,
        tgt.payment_amount = src.payment_amount,
        tgt.gross_amount = src.gross_amount,
        tgt.discount_amount = src.discount_amount,
        tgt.fee_amount = src.fee_amount,
        tgt.tax_amount = src.tax_amount,
        tgt.shpping_fee_amount = src.shpping_fee_amount,
        tgt.personalization_fee_amount = src.personalization_fee_amount,
        tgt.net_amount = src.net_amount,
        tgt.fk_order_typeid = src.fk_order_typeid,
        tgt.fk_order_statusid = CASE 
                                     WHEN src.fk_order_statusid = -1 THEN tgt.fk_order_statusid
                                     ELSE src.fk_order_statusid
                                 END,
        tgt.fk_parent_order_headerid = src.fk_parent_order_headerid,
        tgt.salesrep_customerid = src.salesrep_customerid,
        tgt.modified_date = src.modified_date,
        tgt.email_address = src.email_address,
        tgt.order_comments = src.order_comments,
        tgt.order_notes = src.order_notes,
        tgt.tax_exempt = src.tax_exempt,
        tgt.risk_status = src.risk_status,
        tgt.ship_residential = src.ship_residential,
        tgt.extn_order_locale_code = src.extn_order_locale_code, 
        tgt.seller_organization_code = src.seller_organization_code, 
        tgt.customer_first_name = src.customer_first_name,
        tgt.customer_last_name = src.customer_last_name, 
        tgt.modifyuserid = src.modifyuserid,
        tgt.createuserid = src.createuserid,
        tgt.createts =  TRY_TO_TIMESTAMP(src.createts,''YYYYMMDDHHMISS''),
        tgt.entered_by = src.entered_by,
        tgt.is_bfy17 = src.is_bfy17,
        tgt.order_header_key = src.order_header_key,
        tgt.extn_brand = src.extn_brand,
        tgt.extn_sub_order_type = src.extn_sub_order_type,
        tgt.extn_order_total = src.extn_order_total,
        tgt.modifyts =  TRY_TO_TIMESTAMP(src.modifyts,''YYYYMMDDHHMISS'')
 ;


 
------------------------------------------------------------------------------

CREATE OR REPLACE TEMPORARY TABLE  ANALYTICS.TempAmendOrders AS
SELECT DISTINCT pk_order_headerid, 
    fk_sourceid, 
    source_ref_num,
    ext_order_id, 
    is_domestic, 
    fk_shipping_addressid, 
    fk_billing_addressid, 
    fk_customerid, 
    fk_currencyid,
    fk_shipping_methodid, 
    payment_amount, 
    gross_amount,
    discount_amount, 
    fee_amount, 
    tax_amount, 
    shpping_fee_amount,
    personalization_fee_amount, 
    net_amount, 
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid, 
    inserted_date, 
    modified_date, 
    order_date, 
    email_address, 
    order_comments, 
    order_notes, 
    tax_exempt, 
    risk_status, 
    ship_residential, 
    salesrep_customerid,
    txn_id,
    extn_order_locale_code, 
    seller_organization_code, 
    customer_first_name,
    customer_last_name, 
    modifyuserid ,
    createuserid ,
    createts, 
    entered_by,
    entry_type,
    is_bfy17,
    CAST(1 AS NUMBER(10, 0)) as revision,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total,
    modifyts
FROM TRANSFORMED.stg_ORDER_processed_order_header
    WHERE
        fk_order_statusid <> -2;
------------------------------------------------------------------------------



-- UPDATE
-- 	ANALYTICS.TempAmendOrders
-- SET
-- 	Revision = CAST((aot.revision + 1) as int)
-- FROM
--         ANALYTICS.TempAmendOrders as ttd
--         inner join (
-- 		SELECT
--             MAX(aot.revision) as revision,
--             aot.pk_order_headerid,
--             aot.order_header_key
--         from
--             ANALYTICS.audit_order_header as aot
--             inner join ANALYTICS.TempAmendOrders as ttd on ttd.pk_order_headerid = aot.pk_order_headerid
--         group by
-- 			aot.pk_order_headerid, aot.order_header_key
-- 	) as aot on ttd.pk_order_headerid = aot.pk_order_headerid; --Insert audit data    

UPDATE ANALYTICS.TempAmendOrders ttd
SET Revision = CAST((
    SELECT MAX(aot.revision) + 1
    FROM ANALYTICS.audit_order_header aot
    WHERE ttd.pk_order_headerid = aot.pk_order_headerid
) AS INT)
WHERE EXISTS (
    SELECT 1
    FROM ANALYTICS.audit_order_header aot
    WHERE ttd.pk_order_headerid = aot.pk_order_headerid
);

	
		
INSERT INTO
    ANALYTICS.audit_order_header
        (
        pk_order_headerid,
        fk_sourceid,
        source_ref_num,
        ext_order_id,
        is_domestic,
        fk_shipping_addressid,
        fk_billing_addressid,
        fk_customerid,
        fk_currencyid,
        fk_shipping_methodid,
        payment_amount,
        gross_amount,
        discount_amount,
        fee_amount,
        tax_amount,
        shpping_fee_amount,
        personalization_fee_amount,
        net_amount,
        fk_order_typeid,
        fk_order_statusid,
        fk_parent_order_headerid,
        inserted_date,
        modified_date,
        created_by,
        order_date,
        email_address,
        order_comments,
        order_notes,
        tax_exempt,
        salesrep_customerid,
        risk_status,
        ship_residential,
        Revision,
        extn_order_locale_code,
        seller_organization_code,
        customer_first_name,
        customer_last_name,
        modifyuserid ,
        createuserid ,
        createts,
        entered_by,
        entry_type,
        is_bfy17,
        order_header_key,
        extn_brand,
        extn_sub_order_type,
        extn_order_total,
        modifyts
        )
    SELECT
        DISTINCT insord.pk_order_headerid,
        insord.fk_sourceid,
        insord.source_ref_num,
        insord.ext_order_id,
        insord.is_domestic,
        insord.fk_shipping_addressid,
        insord.fk_billing_addressid,
        insord.fk_customerid,
        insord.fk_currencyid,
        insord.fk_shipping_methodid,
        insord.payment_amount,
        insord.gross_amount,
        insord.discount_amount,
        insord.fee_amount,
        insord.tax_amount,
        insord.shpping_fee_amount,
        insord.personalization_fee_amount,
        insord.net_amount,
        insord.fk_order_typeid,
        insord.fk_order_statusid,
        insord.fk_parent_order_headerid,
        insord.inserted_date,
        insord.modified_date,
        1, -- Assuming stg.CREATEUSERID is always 1 (System)
        insord.order_date,
        insord.email_address,
        insord.order_comments,
        insord.order_notes,
        insord.tax_exempt,
        insord.salesrep_customerid,
        insord.risk_status,
        insord.ship_residential,
        ord.Revision,
        insord.extn_order_locale_code,
        insord.seller_organization_code,
        insord.customer_first_name,
        insord.customer_last_name,
        insord.modifyuserid ,
        insord.createuserid ,
        insord.createts,
        insord.entered_by,
        insord.entry_type,
        insord.is_bfy17,
        insord.order_header_key,
        insord.extn_brand,
        insord.extn_sub_order_type,
        insord.extn_order_total,
        insord.modifyts
    FROM 
        ANALYTICS.txn_order_header insord
        INNER JOIN ANALYTICS.TempAmendOrders ord ON ord.source_ref_num = insord.source_ref_num
        INNER JOIN TRANSFORMED.stg_ORDER_header AS stg ON stg.ORDER_NO = insord.source_ref_num ;
       -- AND insord.modifyts = TO_CHAR(CAST(stg.modifyts AS TIMESTAMP), ''YYYYMMDDHH24MISS'');



MERGE INTO ANALYTICS.txn_order_status AS tgt 
USING (
    SELECT DISTINCT
        toh.pk_order_headerid,
        toh.fk_sourceid,
        toh.source_ref_num,
        toh.fk_order_statusid,
        toh.inserted_date,
        toh.modified_date
    FROM
        TRANSFORMED.stg_ORDER_processed_order_header AS stg
        INNER JOIN ANALYTICS.txn_order_header AS toh ON toh.source_ref_num = stg.source_ref_num
            AND stg.fk_sourceid = toh.fk_sourceid
        INNER JOIN MASTER.dim_order_status AS dods ON dods.pk_order_statusid = stg.fk_order_statusid
) AS src ON src.pk_order_headerid = tgt.fk_order_headerid
        AND src.source_ref_num = tgt.source_ref_num
        AND src.fk_sourceid = tgt.fk_sourceid
WHEN NOT MATCHED THEN
    INSERT (
        fk_order_headerid,
        fk_sourceid,
        source_ref_num,
        fk_order_statusid,
        inserted_date,
        modified_date
    )
    VALUES (
        src.pk_order_headerid,
        src.fk_sourceid,
        src.source_ref_num,
        src.fk_order_statusid,
        src.inserted_date,
        src.modified_date
    )
WHEN MATCHED THEN
    UPDATE
    SET
        tgt.fk_order_statusid = src.fk_order_statusid,
        tgt.modified_date = src.modified_date;

-- Creating a temporary table
CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.updatedOrderDetails(
    pk_order_headerid STRING,
    pk_skuproductid STRING,
    ORDERED_QTY STRING,
    UNIT_PRICE STRING,
    LINE_TOTAL STRING,
    is_taxable STRING,
    options STRING,
    ITEM_SHORT_DESCRIPTION STRING,
    txn_id STRING,
    PRIME_LINE_NO STRING,
    source_ref_num STRING,
    order_line_status STRING,
    bh_product_name STRING,
    personalization_fee STRING,
    order_header_key STRING,
    order_line_key STRING,
    createts STRING,
    modifyts STRING
);


-- Creating a temporary table
INSERT INTO ANALYTICS.updatedOrderDetails 
SELECT DISTINCT
    toh.pk_order_headerid,
    dsl.pk_skuproductid,
    ORDERED_QTY,
    UNIT_PRICE,
    LINE_TOTAL,
    CASE
        WHEN ord.TAXABLE_FLAG = ''N'' THEN 0
        WHEN ord.TAXABLE_FLAG = ''Y'' THEN 1
    END AS is_taxable,
    ord.PERSONALIZE_CODE AS options,
    ITEM_SHORT_DESCRIPTION,
    ord.txn_id,
    ord.PRIME_LINE_NO,
    toh.source_ref_num,
    ord.order_line_status,
    dsl.bh_product_name,
    0 AS personalization_fee,
    ord.order_header_key,
    ord.ORDER_LINE_KEY,
    ord.createts,
    ord.modifyts
FROM
    TRANSFORMED.stg_ORDER_line AS ord
    INNER JOIN ANALYTICS.txn_order_header AS toh ON toh.ORDER_HEADER_KEY = ord.ORDER_HEADER_KEY
    INNER JOIN ANALYTICS.txn_order_detail AS tod ON tod.order_line_key = ord.order_line_key AND ord.modifyts <>  TO_CHAR(CAST(tod.modifyts AS TIMESTAMP), ''YYYYMMDDHH24MISS'')
    INNER JOIN MASTER.dim_source AS ds ON ds.pk_sourceid = toh.fk_sourceid
    INNER JOIN analytics.sku_product_locale AS dsl ON dsl.sku_code = ord.ITEM_ID
        AND dsl.locale = ds.locale
WHERE
    toh.pk_order_headerid IS NOT NULL
    AND ord.BUNDLE_PARENT_ORDER_LINE_KEY IS NULL; 

-- Truncating a table in Snowflake
TRUNCATE TABLE TRANSFORMED.stg_ORDER_processed_order_line;

-- Inserting into stg_ORDER_processed_order_line
INSERT INTO TRANSFORMED.stg_ORDER_processed_order_line (
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    inserted_date,
    modified_date,
    txn_id,
    order_line_status,
    prime_line_num,
    ext_line_id,
    order_header_key,
    order_line_key,
    createts,
    modifyts
)
SELECT DISTINCT 
    ord.pk_order_headerid,
    ord.pk_skuproductid,
    SUM(CAST(ord.ORDERED_QTY AS FLOAT)),
    ord.UNIT_PRICE,
    SUM(CAST(ord.LINE_TOTAL AS FLOAT)),
    ord.is_taxable,
    ord.options,
    SUM(CAST(ord.personalization_fee AS FLOAT)),
    ord.bh_product_name,
    CURRENT_TIMESTAMP() AS inserted_date,
    CURRENT_TIMESTAMP() AS modified_date,
    ord.txn_id,
    ord.order_line_status,
    ord.PRIME_LINE_NO,
    ord.ORDER_LINE_KEY,
    ord.order_header_key,
    ord.order_line_key,
    ord.createts,
    ord.modifyts
FROM
    (
        SELECT DISTINCT *
        FROM ANALYTICS.updatedOrderDetails
    ) AS ord
GROUP BY
    ord.pk_skuproductid,
    ord.UNIT_PRICE,
    ord.is_taxable,
    ord.order_line_status,
    ord.bh_product_name,
    ord.options,
    ord.pk_order_headerid,
    ord.txn_id,
    ord.PRIME_LINE_NO,
    ord.ORDER_LINE_KEY,
    ord.order_header_key,
    ord.order_line_key,
    ord.createts,
    ord.modifyts;

-- Creating a temporary table
-------------


	MERGE INTO ANALYTICS.txn_order_detail AS tgt USING (
		SELECT distinct
        sol.fk_order_headerid,
        sol.fk_skuproductid,
        sol.quantity,
        sol.product_price,
        sol.total_price,
        sol.is_taxable,
        sol.options,
        sol.personalization_fee,
        sol.product_name,
        sol.inserted_date,
        sol.modified_date,
        sol.prime_line_num,
        sol.ext_line_id,
        tod.pk_order_detailid,
		sol.order_header_key,
		sol.order_line_key,
        sol.createts,
        sol.modifyts
    FROM
        TRANSFORMED.stg_ORDER_processed_order_line as sol
        left join ANALYTICS.txn_order_detail as tod on tod.fk_order_headerid = sol.fk_order_headerid
            and tod.ext_line_id = sol.ext_line_id
            --and TO_CHAR(CAST(tod.modifyts AS TIMESTAMP), ''YYYYMMDDHH24MISS'') = sol.modifyts
	) AS src ON src.fk_order_headerid = tgt.fk_order_headerid
        and src.pk_order_detailid = tgt.pk_order_detailid
        and src.ext_line_id = tgt.ext_line_id
	WHEN NOT MATCHED  THEN
INSERT
	(
		fk_order_headerid,
		fk_skuproductid,
		quantity,
		product_price,
		total_price,
		is_taxable,
		options,
		personalization_fee,
		product_name,
		inserted_date,
		modified_date,
		prime_line_num,
		ext_line_id,
		order_header_key,
		order_line_key,
        createts,
        modifyts
	)
VALUES
	(
		src.fk_order_headerid,
		src.fk_skuproductid,
		src.quantity,
		src.product_price,
		src.total_price,
		src.is_taxable,
		src.options,
		src.personalization_fee,
		src.product_name,
		src.inserted_date,
		src.modified_date,
		src.prime_line_num,
		src.ext_line_id,
		src.order_header_key,
		src.order_line_key,
        TRY_TO_TIMESTAMP(src.createts,''YYYYMMDDHHMISS''), --src.createts,
        TRY_TO_TIMESTAMP(src.modifyts,''YYYYMMDDHHMISS'') --src.modifyts
	)
	WHEN MATCHED Then
UPDATE
SET
	tgt.fk_skuproductid = src.fk_skuproductid,
	tgt.quantity = src.quantity,
	tgt.product_price = src.product_price,
	tgt.total_price = src.total_price,
	tgt.is_taxable = src.is_taxable,
	tgt.options = src.options,
	tgt.personalization_fee = src.personalization_fee,
	tgt.product_name = src.product_name,
	tgt.modified_date = src.modified_date,
	tgt.prime_line_num = src.prime_line_num,
	tgt.order_header_key = src.order_header_key,
	tgt.order_line_key = src.order_line_key,
    tgt.createts = TRY_TO_TIMESTAMP(src.createts,''YYYYMMDDHHMISS''),
    tgt.modifyts = TRY_TO_TIMESTAMP(src.modifyts,''YYYYMMDDHHMISS'') ;
    

INSERT INTO ANALYTICS.TempAmendOrderDetails(
    pk_order_detailid, 
    fk_order_headerid, 
    fk_skuproductid, 
    quantity, 
    product_price, 
    total_price, 
    is_taxable, 
    options, 
    personalization_fee, 
    product_name, 
    created_by, 
    created_date, 
    modified_date, 
    revision,
    prime_line_num,
    ext_line_id,
    order_header_key,
    order_line_key,
    createts,
    modifyts
)
SELECT DISTINCT 
tod.pk_order_detailid,
    sol.fk_order_headerid,
    sol.fk_skuproductid,
    sol.quantity,
    sol.product_price,
    sol.total_price,
    sol.is_taxable,
    sol.options,
    sol.personalization_fee,
    sol.product_name,
    1 AS created_by, -- Replace @createdby with the actual value or variable
    CURRENT_TIMESTAMP() AS created_date,
    CURRENT_TIMESTAMP() AS modified_date,
    CAST(1 AS NUMBER(10, 0)) AS revision,
    sol.prime_line_num,
    sol.ext_line_id,
    sol.order_header_key,
    sol.order_line_key,
    sol.createts,
    sol.modifyts
FROM TRANSFORMED.stg_ORDER_processed_order_line sol
left join ANALYTICS.txn_order_detail as tod on tod.fk_order_headerid = sol.fk_order_headerid and tod.ext_line_id = sol.ext_line_id ;
--and TO_CHAR(CAST(tod.modifyts AS TIMESTAMP), ''YYYYMMDDHH24MISS'') = sol.modifyts;



-- Populate revision
UPDATE ANALYTICS.TempAmendOrderDetails
SET Revision = CAST((aot.revision + 1) AS INT)
FROM ANALYTICS.TempAmendOrderDetails ttd
INNER JOIN (
    SELECT
        MAX(aot.revision) AS revision,
        aot.pk_order_detailid,
        aot.fk_order_headerid
    FROM
        ANALYTICS.audit_order_detail aot
    INNER JOIN ANALYTICS.TempAmendOrderDetails ttd ON ttd.pk_order_detailid = aot.pk_order_detailid AND ttd.fk_order_headerid = aot.fk_order_headerid
    GROUP BY
        aot.pk_order_detailid,
        aot.fk_order_headerid
) AS aot ON ttd.pk_order_detailid = aot.pk_order_detailid AND ttd.fk_order_headerid = aot.fk_order_headerid;

-- Insert into audit_order_detail
INSERT INTO ANALYTICS.audit_order_detail (
    pk_order_detailid,
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    created_by,
    created_date,
    modified_date,
    revision,
    order_header_key,
    order_line_key,
    createts,
    modifyts
)
SELECT
    pk_order_detailid,
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    created_by,
    created_date,
    modified_date,
    revision,
    order_header_key,
    order_line_key,
    TRY_TO_TIMESTAMP(createts,''YYYYMMDDHHMISS''), --createts,
    TRY_TO_TIMESTAMP(modifyts,''YYYYMMDDHHMISS'') --modifyts
FROM
    ANALYTICS.TempAmendOrderDetails;



-- Populate txn_order_detail_status
MERGE INTO ANALYTICS.txn_order_detail_status AS Target
USING (
    SELECT DISTINCT
        stg.fk_order_headerid,
        tod.pk_order_detailid,
        pk_order_statusid,
        stg.fk_skuproductid
    FROM
        TRANSFORMED.stg_ORDER_processed_order_line AS stg
    INNER JOIN ANALYTICS.TempAmendOrderDetails AS tod ON tod.fk_order_headerid = stg.fk_order_headerid AND stg.fk_skuproductid = tod.fk_skuproductid AND tod.ext_line_id = stg.ext_line_id
    INNER JOIN MASTER.dim_order_status AS dods ON dods.oms_ORDER_status_code = stg.order_line_status
) AS Source ON Source.fk_order_headerid = Target.pk_order_headerid
    AND Source.fk_skuproductid = Target.fk_skuproductid
    AND Source.pk_order_detailid = Target.pk_order_detailid
WHEN NOT MATCHED THEN
INSERT (
    pk_order_headerid,
    pk_order_detailid,
    fk_ORDER__detail_statusid,
    fk_skuproductid
)
VALUES (
    Source.fk_order_headerid,
    Source.pk_order_detailid,
    Source.pk_order_statusid,
    Source.fk_skuproductid
);


CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.OrderDetailMultipartItems (
    pk_order_detail_multipartid BIGINT NOT NULL,
    fk_order_detailid BIGINT NOT NULL,
    order_line_key VARCHAR,
    order_header_key VARCHAR,
    prime_line_no VARCHAR NOT NULL,
    sub_line_no VARCHAR,
    line_type VARCHAR,
    order_class VARCHAR,
    item_id VARCHAR,
    alternate_item_id VARCHAR,
    uom VARCHAR,
    product_class VARCHAR,
    unit_price VARCHAR,
    cost_currency VARCHAR,
    ordered_qty VARCHAR,
    basic_capacity_required VARCHAR,
    option_capacity_required VARCHAR,
    dependent_on_line_key VARCHAR,
    current_work_order_key VARCHAR,
    dependency_shipping_rule VARCHAR,
    fill_quantity VARCHAR,
    committed_quantity VARCHAR,
    dependency_ratio VARCHAR,
    maintain_ratio VARCHAR,
    merge_node VARCHAR,
    parent_of_dependent_group VARCHAR,
    source_from_organization VARCHAR,
    chained_from_order_line_key VARCHAR,
    chained_from_order_header_key VARCHAR,
    derived_from_order_line_key VARCHAR,
    derived_from_order_header_key VARCHAR,
    derived_from_order_release_key VARCHAR,
    distribution_rule_id VARCHAR,
    invoiced_quantity VARCHAR,
    over_receipt_quantity VARCHAR,
    return_reason VARCHAR,
    shipnode_key VARCHAR,
    procure_from_node VARCHAR,
    ship_to_key VARCHAR,
    mark_for_key VARCHAR,
    buyer_mark_for_node_id VARCHAR,
    req_delivery_date VARCHAR,
    req_cancel_date VARCHAR,
    req_ship_date VARCHAR,
    scac VARCHAR,
    carrier_service_code VARCHAR,
    carrier_account_no VARCHAR,
    pickable_flag VARCHAR,
    ship_together_no VARCHAR,
    hold_flag VARCHAR,
    kit_code VARCHAR,
    hold_reason_code VARCHAR,
    other_charges VARCHAR,
    line_total VARCHAR,
    invoiced_line_total VARCHAR,
    invoiced_extended_price VARCHAR,
    settled_quantity VARCHAR,
    settled_amount VARCHAR,
    taxable_flag VARCHAR,
    tax_exemption_certificate VARCHAR,
    discount_type VARCHAR,
    discount_reference VARCHAR,
    gift_flag VARCHAR,
    personalize_flag VARCHAR,
    personalize_code VARCHAR,
    department_code VARCHAR,
    customer_item VARCHAR,
    customer_item_description VARCHAR,
    item_weight VARCHAR,
    item_weight_uom VARCHAR,
    item_description VARCHAR,
    item_short_description VARCHAR,
    reservation_id VARCHAR,
    reservation_pool VARCHAR,
    customer_po_no VARCHAR,
    customer_po_line_no VARCHAR,
    tax VARCHAR,
    delivery_code VARCHAR,
    original_ordered_qty VARCHAR,
    list_price VARCHAR,
    retail_price VARCHAR,
    discount_percentage VARCHAR,
    packlist_type VARCHAR,
    supplier_item VARCHAR,
    supplier_item_description VARCHAR,
    unit_cost VARCHAR,
    upc_code VARCHAR,
    fob VARCHAR,
    manufacturer_name VARCHAR,
    manufacturer_item VARCHAR,
    manufacturer_item_desc VARCHAR,
    country_of_origin VARCHAR,
    isbn VARCHAR,
    harmonized_code VARCHAR,
    ship_to_id VARCHAR,
    product_line VARCHAR,
    nmfc_code VARCHAR,
    nmfc_class VARCHAR,
    nmfc_description VARCHAR,
    tax_product_code VARCHAR,
    import_license_no VARCHAR,
    import_license_exp_date VARCHAR,
    eccn_no VARCHAR,
    schedule_b_code VARCHAR,
    supplier_code VARCHAR,
    purpose VARCHAR,
    receiving_node VARCHAR,
    buyer_receiving_node_id VARCHAR,
    shipment_consol_group_id VARCHAR,
    orig_order_line_key VARCHAR,
    line_seq_no VARCHAR,
    split_qty VARCHAR,
    pricing_date VARCHAR,
    pipeline_key VARCHAR,
    condition_variable_1 VARCHAR,
    condition_variable_2 VARCHAR,
    is_price_locked VARCHAR,
    is_cost_overridden VARCHAR,
    is_capacity_overridden VARCHAR,
    invoice_complete VARCHAR,
    delivery_method VARCHAR,
    item_group_code VARCHAR,
    cannot_complete_before_date VARCHAR,
    cannot_complete_after_date VARCHAR,
    appt_status VARCHAR,
    can_add_service_lines VARCHAR,
    pricing_uom VARCHAR,
    capacity_uom VARCHAR,
    pricing_quantity VARCHAR,
    shipped_quantity VARCHAR,
    fixed_capacity_qty_per_line VARCHAR,
    fixed_pricing_qty_per_line VARCHAR,
    wait_for_seq_line VARCHAR,
    sched_failure_reason_code VARCHAR,
    earliest_ship_date VARCHAR,
    earliest_delivery_date VARCHAR,
    cannot_meet_appt VARCHAR,
    promised_appt_start_date VARCHAR,
    promised_appt_end_date VARCHAR,
    segment VARCHAR,
    segment_type VARCHAR,
    earliest_schedule_date VARCHAR,
    timezone VARCHAR,
    is_forwarding_allowed VARCHAR,
    is_procurement_allowed VARCHAR,
    reship_parent_line_key VARCHAR,
    bundle_parent_order_line_key VARCHAR,
    is_price_info_only VARCHAR,
    level_of_service VARCHAR,
    first_iter_seq_no VARCHAR,
    last_iter_seq_no VARCHAR,
    createts VARCHAR,
    modifyts VARCHAR,
    createuserid VARCHAR,
    modifyuserid VARCHAR,
    createprogid VARCHAR,
    modifyprogid VARCHAR,
    lockid INT,
    ordering_uom VARCHAR,
    pricing_quantity_conv_factor VARCHAR,
    pricing_quantity_strategy VARCHAR,
    invoiced_pricing_quantity VARCHAR,
    is_standalone_service VARCHAR,
    tran_discrepancy_qty VARCHAR,
    received_quantity VARCHAR,
    invoice_based_on_actuals VARCHAR,
    actual_pricing_quantity VARCHAR,
    fulfillment_type VARCHAR,
    serial_no VARCHAR,
    reservation_mandatory VARCHAR,
    is_firm_predefined_node VARCHAR,
    intentional_backorder VARCHAR,
    future_avail_date VARCHAR,
    repricing_quantity VARCHAR,
    min_ship_by_date VARCHAR,
    kit_qty VARCHAR,
    bom_config_key VARCHAR,
    bundle_fulfillment_mode VARCHAR,
    is_gift_wrap VARCHAR,
    group_sequence_num VARCHAR,
    in_store_payment_required VARCHAR,
    item_not_exist VARCHAR,
    derived_from_ext_ord VARCHAR,
    is_eligible_for_ship_disc VARCHAR,
    backorder_notification_qty VARCHAR,
    is_price_matched VARCHAR,
    is_pick_up_now VARCHAR,
    item_is_in_hand VARCHAR,
    disposition_code VARCHAR,
    extn_mod_reason_code VARCHAR,
    extn_mod_reason_desc VARCHAR,
    extn_asn VARCHAR,
    extn_parent_order_no VARCHAR,
    extn_item_id VARCHAR,
    extn_order_item_id VARCHAR,
    extn_price_type VARCHAR,
    extn_secondary_return_reason VARCHAR,
    extn_apply_label_fee VARCHAR,
    extn_is_activation_complete VARCHAR,
    extn_item_desc VARCHAR,
    extn_return_carton_count VARCHAR,
    extn_asn_quantity VARCHAR,
    extn_light_color VARCHAR,
    extn_light_type VARCHAR,
    extn_number_of_sections VARCHAR,
    extn_total_cartons VARCHAR,
    extn_tree_height VARCHAR,
    extn_tree_height_uom VARCHAR,
    extn_apply_restocking_fee VARCHAR,
    extn_return_pickup_date VARCHAR,
    extn_pickup_confirmation_no VARCHAR,
    extn_refund_shipping_cost VARCHAR,
    extn_is_fulfilled_line VARCHAR,
    extn_mfg_warranty_start_date VARCHAR,
    extn_mfg_warranty_end_date VARCHAR,
    extn_term VARCHAR,
    extn_is_invoice_required VARCHAR,
    extn_prem_guarantee_end_date VARCHAR,
    extn_return_date VARCHAR,
    extn_is_email_sent VARCHAR,
    extn_return_required VARCHAR,
    extn_parent_prime_line_no VARCHAR,
    extn_parent_sub_line_no VARCHAR,
    extn_prem_guarantee_start_date VARCHAR,
    extn_reship_upcid VARCHAR,
    extn_parent_order_line_sku VARCHAR,
    revision INT NOT NULL
);



	MERGE INTO ANALYTICS.txn_order_detail_multipart
	AS TARGET USING( SELECT DISTINCT stg.*, tod.pk_order_detailid from 
	    TRANSFORMED.stg_ORDER_line_multipart AS stg
		INNER JOIN ANALYTICS.txn_order_header as toh on toh.order_header_key = stg.order_header_key and toh.entry_type is not null
        INNER JOIN ANALYTICS.txn_order_detail as tod on tod.fk_order_headerid = toh.pk_order_headerid 
		and	  stg.BUNDLE_PARENT_ORDER_LINE_KEY =tod.order_line_key
		where stg.BUNDLE_PARENT_ORDER_LINE_KEY is not null
	) as SOURCE on SOURCE.pk_order_detailid = TARGET.fk_order_detailid and SOURCE.order_line_key = TARGET.order_line_key  and SOURCE.BUNDLE_PARENT_ORDER_LINE_KEY = TARGET.BUNDLE_PARENT_ORDER_LINE_KEY AND TARGET.BUNDLE_PARENT_ORDER_LINE_KEY is not null AND SOURCE.BUNDLE_PARENT_ORDER_LINE_KEY is not null

	WHEN MATCHED 
	THEN 
	UPDATE 
	SET
	  
  TARGET.prime_line_no                  =SOURCE.prime_line_no                   
  ,TARGET.sub_line_no                    =SOURCE.sub_line_no                     
  ,TARGET.line_type                      =SOURCE.line_type                      
  ,TARGET.order_class                    =SOURCE.order_class                    
  ,TARGET.item_id                        =SOURCE.item_id  
  ,TARGET.alternate_item_id              =SOURCE.alternate_item_id             
  ,TARGET.uom                            =SOURCE.uom                            
  ,TARGET.product_class                  =SOURCE.product_class                  
  ,TARGET.unit_price                     =try_cast( SOURCE.unit_price as float)                    
  ,TARGET.cost_currency                  =SOURCE.cost_currency                 
  ,TARGET.ordered_qty                    =SOURCE.ordered_qty                    
  ,TARGET.basic_capacity_required        =SOURCE.basic_capacity_required        
  ,TARGET.option_capacity_required       =SOURCE.option_capacity_required       
  ,TARGET.dependent_on_line_key          =SOURCE.dependent_on_line_key         
  ,TARGET.current_work_order_key         =SOURCE.current_work_order_key        
  ,TARGET.dependency_shipping_rule       =SOURCE.dependency_shipping_rule      
  ,TARGET.fill_quantity                  =SOURCE.fill_quantity                  
  ,TARGET.committed_quantity             =SOURCE.committed_quantity            
  ,TARGET.dependency_ratio               =SOURCE.dependency_ratio               
  ,TARGET.maintain_ratio                 =SOURCE.maintain_ratio                
  ,TARGET.merge_node                     =SOURCE.merge_node                    
  ,TARGET.parent_of_dependent_group      =SOURCE.parent_of_dependent_group      
  ,TARGET.source_from_organization       =SOURCE.source_from_organization      
  ,TARGET.chained_from_order_line_key    =SOURCE.chained_from_order_line_key   
  ,TARGET.chained_from_order_header_key  =SOURCE.chained_from_order_header_key 
  ,TARGET.derived_from_order_line_key    =SOURCE.derived_from_order_line_key   
  ,TARGET.derived_from_order_header_key  =SOURCE.derived_from_order_header_key 
  ,TARGET.derived_from_order_release_key =SOURCE.derived_from_order_release_key
  ,TARGET.distribution_rule_id           =SOURCE.distribution_rule_id          
  ,TARGET.invoiced_quantity              =SOURCE.invoiced_quantity              
  ,TARGET.over_receipt_quantity          =SOURCE.over_receipt_quantity          
  ,TARGET.return_reason                  =SOURCE.return_reason                 
  ,TARGET.shipnode_key                   =SOURCE.shipnode_key                  
  ,TARGET.procure_from_node              =SOURCE.procure_from_node             
  ,TARGET.ship_to_key                    =SOURCE.ship_to_key                   
  ,TARGET.mark_for_key                   =SOURCE.mark_for_key                  
  ,TARGET.buyer_mark_for_node_id         =SOURCE.buyer_mark_for_node_id        
  ,TARGET.req_delivery_date              =TRY_TO_TIMESTAMP(SOURCE.req_delivery_date,''YYYYMMDDHHMISS'')          
  ,TARGET.req_cancel_date                =TRY_TO_TIMESTAMP(SOURCE.req_cancel_date,''YYYYMMDDHHMISS'')
  ,TARGET.req_ship_date                  =TRY_TO_TIMESTAMP(SOURCE.req_ship_date,''YYYYMMDDHHMISS'')
  ,TARGET.scac                           =SOURCE.scac                          
  ,TARGET.carrier_service_code           =SOURCE.carrier_service_code          
  ,TARGET.carrier_account_no             =SOURCE.carrier_account_no            
  ,TARGET.pickable_flag                  =SOURCE.pickable_flag                  
  ,TARGET.ship_together_no               =SOURCE.ship_together_no              
  ,TARGET.hold_flag                      =SOURCE.hold_flag                      
  ,TARGET.kit_code                       =SOURCE.kit_code                      
  ,TARGET.hold_reason_code               =SOURCE.hold_reason_code              
  ,TARGET.other_charges                  =SOURCE.other_charges                  
  ,TARGET.line_total                     =try_cast( SOURCE.line_total as float)                    
  ,TARGET.invoiced_line_total            =try_cast( SOURCE.invoiced_line_total as float)         
  ,TARGET.invoiced_extended_price        =try_cast( SOURCE.invoiced_extended_price as float)    
  ,TARGET.settled_quantity               =SOURCE.settled_quantity               
  ,TARGET.settled_amount                 =SOURCE.settled_amount                 
  ,TARGET.taxable_flag                   =SOURCE.taxable_flag                   
  ,TARGET.tax_exemption_certificate      =SOURCE.tax_exemption_certificate     
  ,TARGET.discount_type                  =SOURCE.discount_type                 
  ,TARGET.discount_reference             =SOURCE.discount_reference            
  ,TARGET.gift_flag                      =SOURCE.gift_flag                      
  ,TARGET.personalize_flag               =SOURCE.personalize_flag               
  ,TARGET.personalize_code               =SOURCE.personalize_code              
  ,TARGET.department_code                =SOURCE.department_code               
  ,TARGET.customer_item                  =SOURCE.customer_item  
  ,TARGET.customer_item_description      =SOURCE.customer_item_description      
  ,TARGET.item_weight                    =SOURCE.item_weight                    
  ,TARGET.item_weight_uom                =SOURCE.item_weight_uom                
  ,TARGET.item_description               =SOURCE.item_description               
  ,TARGET.item_short_description         =SOURCE.item_short_description         
  ,TARGET.reservation_id                 =SOURCE.reservation_id                
  ,TARGET.reservation_pool               =SOURCE.reservation_pool              
  ,TARGET.customer_po_no                 =SOURCE.customer_po_no                
  ,TARGET.customer_po_line_no            =SOURCE.customer_po_line_no           
  ,TARGET.tax                            =SOURCE.tax                            
  ,TARGET.delivery_code                  =SOURCE.delivery_code                 
  ,TARGET.original_ordered_qty           =SOURCE.original_ordered_qty           
  ,TARGET.list_price                     =try_cast( SOURCE.list_price as float)                    
  ,TARGET.retail_price                   =try_cast( SOURCE.retail_price as float)                   
  ,TARGET.discount_percentage            =SOURCE.discount_percentage            
  ,TARGET.packlist_type                  =SOURCE.packlist_type                 
  ,TARGET.supplier_item                  =SOURCE.supplier_item                 
  ,TARGET.supplier_item_description      =SOURCE.supplier_item_description     
  ,TARGET.unit_cost                      =SOURCE.unit_cost                      
  ,TARGET.upc_code                       =SOURCE.upc_code                      
  ,TARGET.fob                            =SOURCE.fob                           
  ,TARGET.manufacturer_name              =SOURCE.manufacturer_name             
  ,TARGET.manufacturer_item              =SOURCE.manufacturer_item             
  ,TARGET.manufacturer_item_desc         =SOURCE.manufacturer_item_desc        
  ,TARGET.country_of_origin              =SOURCE.country_of_origin             
  ,TARGET.isbn                           =SOURCE.isbn                          
  ,TARGET.harmonized_code                =SOURCE.harmonized_code               
  ,TARGET.ship_to_id                     =SOURCE.ship_to_id                    
  ,TARGET.product_line                   =SOURCE.product_line                  
  ,TARGET.nmfc_code                      =SOURCE.nmfc_code                     
  ,TARGET.nmfc_class                     =SOURCE.nmfc_class                    
  ,TARGET.nmfc_description               =SOURCE.nmfc_description              
  ,TARGET.tax_product_code               =SOURCE.tax_product_code               
  ,TARGET.import_license_no              =SOURCE.import_license_no             
  ,TARGET.import_license_exp_date        =TRY_TO_TIMESTAMP(SOURCE.import_license_exp_date,''YYYYMMDDHHMISS'')
  ,TARGET.eccn_no                        =SOURCE.eccn_no                       
  ,TARGET.schedule_b_code                =SOURCE.schedule_b_code               
  ,TARGET.supplier_code                  =SOURCE.supplier_code                 
  ,TARGET.purpose                        =SOURCE.purpose                       
  ,TARGET.receiving_node                 =SOURCE.receiving_node                
  ,TARGET.buyer_receiving_node_id        =SOURCE.buyer_receiving_node_id       
  ,TARGET.shipment_consol_group_id       =SOURCE.shipment_consol_group_id      
  ,TARGET.orig_order_line_key            =SOURCE.orig_order_line_key           
  ,TARGET.line_seq_no                    =SOURCE.line_seq_no                    
  ,TARGET.split_qty                      =SOURCE.split_qty                      
  ,TARGET.pricing_date                   =TRY_TO_TIMESTAMP(SOURCE.pricing_date,''YYYYMMDDHHMISS'')        
  ,TARGET.pipeline_key                   =SOURCE.pipeline_key                   
  ,TARGET.condition_variable_1           =SOURCE.condition_variable_1          
  ,TARGET.condition_variable_2           =SOURCE.condition_variable_2          
  ,TARGET.is_price_locked                =SOURCE.is_price_locked                
  ,TARGET.is_cost_overridden             =SOURCE.is_cost_overridden             
  ,TARGET.is_capacity_overridden         =SOURCE.is_capacity_overridden         
  ,TARGET.invoice_complete               =SOURCE.invoice_complete               
  ,TARGET.delivery_method                =SOURCE.delivery_method                
  ,TARGET.item_group_code                =SOURCE.item_group_code                
  ,TARGET.cannot_complete_before_date    =TRY_TO_TIMESTAMP(SOURCE.cannot_complete_before_date,''YYYYMMDDHHMISS'')
  ,TARGET.cannot_complete_after_date     =TRY_TO_TIMESTAMP(SOURCE.cannot_complete_after_date,''YYYYMMDDHHMISS'') 
  ,TARGET.appt_status                    =SOURCE.appt_status                   
  ,TARGET.can_add_service_lines          =SOURCE.can_add_service_lines          
  ,TARGET.pricing_uom                    =SOURCE.pricing_uom                    
  ,TARGET.capacity_uom                   =SOURCE.capacity_uom                  
  ,TARGET.pricing_quantity               =SOURCE.pricing_quantity               
  ,TARGET.shipped_quantity               =SOURCE.shipped_quantity               
  ,TARGET.fixed_capacity_qty_per_line    =SOURCE.fixed_capacity_qty_per_line    
  ,TARGET.fixed_pricing_qty_per_line     =SOURCE.fixed_pricing_qty_per_line     
  ,TARGET.wait_for_seq_line              =SOURCE.wait_for_seq_line              
  ,TARGET.sched_failure_reason_code      =SOURCE.sched_failure_reason_code     
  ,TARGET.earliest_ship_date             =TRY_TO_TIMESTAMP(SOURCE.earliest_ship_date,''YYYYMMDDHHMISS'')
  ,TARGET.earliest_delivery_date         =TRY_TO_TIMESTAMP(SOURCE.earliest_delivery_date,''YYYYMMDDHHMISS'')
  ,TARGET.cannot_meet_appt               =SOURCE.cannot_meet_appt              
  ,TARGET.promised_appt_start_date       =TRY_TO_TIMESTAMP(SOURCE.promised_appt_start_date,''YYYYMMDDHHMISS'')     
  ,TARGET.promised_appt_end_date         =TRY_TO_TIMESTAMP(SOURCE.promised_appt_end_date,''YYYYMMDDHHMISS'')       
  ,TARGET.segment                        =SOURCE.segment                        
  ,TARGET.segment_type                   =SOURCE.segment_type                   
  ,TARGET.earliest_schedule_date         =TRY_TO_TIMESTAMP(SOURCE.earliest_schedule_date,''YYYYMMDDHHMISS'')   
  ,TARGET.timezone                       =SOURCE.timezone                      
  ,TARGET.is_forwarding_allowed          =SOURCE.is_forwarding_allowed         
  ,TARGET.is_procurement_allowed         =SOURCE.is_procurement_allowed        
  ,TARGET.reship_parent_line_key         =SOURCE.reship_parent_line_key        
  ,TARGET.is_price_info_only             =SOURCE.is_price_info_only            
  ,TARGET.level_of_service               =SOURCE.level_of_service               
  ,TARGET.first_iter_seq_no              =SOURCE.first_iter_seq_no             
  ,TARGET.last_iter_seq_no               =SOURCE.last_iter_seq_no              
  ,TARGET.createts                       =TRY_TO_TIMESTAMP(SOURCE.createts,''YYYYMMDDHHMISS'')  
  ,TARGET.modifyts                       =TRY_TO_TIMESTAMP(SOURCE.modifyts,''YYYYMMDDHHMISS'')  
  ,TARGET.createuserid                   =SOURCE.createuserid                   
  ,TARGET.modifyuserid                   =SOURCE.modifyuserid                   
  ,TARGET.createprogid                   =SOURCE.createprogid                   
  ,TARGET.modifyprogid                   =SOURCE.modifyprogid                   
  ,TARGET.lockid                         =SOURCE.lockid  
  ,TARGET.ordering_uom                   =SOURCE.ordering_uom                   
  ,TARGET.pricing_quantity_conv_factor   =SOURCE.pricing_quantity_conv_factor   
  ,TARGET.pricing_quantity_strategy      =SOURCE.pricing_quantity_strategy      
  ,TARGET.invoiced_pricing_quantity      =SOURCE.invoiced_pricing_quantity      
  ,TARGET.is_standalone_service          =SOURCE.is_standalone_service         
  ,TARGET.tran_discrepancy_qty           =SOURCE.tran_discrepancy_qty           
  ,TARGET.received_quantity              =SOURCE.received_quantity              
  ,TARGET.invoice_based_on_actuals       =SOURCE.invoice_based_on_actuals       
  ,TARGET.actual_pricing_quantity        =SOURCE.actual_pricing_quantity        
  ,TARGET.fulfillment_type               =SOURCE.fulfillment_type               
  ,TARGET.serial_no                      =SOURCE.serial_no                     
  ,TARGET.reservation_mandatory          =SOURCE.reservation_mandatory          
  ,TARGET.is_firm_predefined_node        =SOURCE.is_firm_predefined_node        
  ,TARGET.intentional_backorder          =SOURCE.intentional_backorder          
  ,TARGET.future_avail_date              =TRY_TO_TIMESTAMP(SOURCE.future_avail_date,''YYYYMMDDHHMISS'')            
  ,TARGET.repricing_quantity             =SOURCE.repricing_quantity             
  ,TARGET.min_ship_by_date               =TRY_TO_TIMESTAMP(SOURCE.min_ship_by_date,''YYYYMMDDHHMISS'')           
  ,TARGET.kit_qty                        =SOURCE.kit_qty                       
  ,TARGET.bom_config_key                 =SOURCE.bom_config_key                
  ,TARGET.bundle_fulfillment_mode        =SOURCE.bundle_fulfillment_mode       
  ,TARGET.is_gift_wrap                   =SOURCE.is_gift_wrap                  
  ,TARGET.group_sequence_num             =SOURCE.group_sequence_num            
  ,TARGET.in_store_payment_required      =SOURCE.in_store_payment_required     
  ,TARGET.item_not_exist                 =SOURCE.item_not_exist                
  ,TARGET.derived_from_ext_ord           =SOURCE.derived_from_ext_ord          
  ,TARGET.is_eligible_for_ship_disc      =SOURCE.is_eligible_for_ship_disc      
  ,TARGET.backorder_notification_qty     =SOURCE.backorder_notification_qty     
  ,TARGET.is_price_matched               =SOURCE.is_price_matched               
  ,TARGET.is_pick_up_now                 =SOURCE.is_pick_up_now                
  ,TARGET.item_is_in_hand                =SOURCE.item_is_in_hand               
  ,TARGET.disposition_code               =SOURCE.disposition_code              
  ,TARGET.extn_mod_reason_code           =SOURCE.extn_mod_reason_code          
  ,TARGET.extn_mod_reason_desc           =SOURCE.extn_mod_reason_desc          
  ,TARGET.extn_asn                       =SOURCE.extn_asn                      
  ,TARGET.extn_parent_order_no           =SOURCE.extn_parent_order_no          
  ,TARGET.extn_item_id                   =SOURCE.extn_item_id                   
  ,TARGET.extn_order_item_id             =SOURCE.extn_order_item_id            
  ,TARGET.extn_price_type                =SOURCE.extn_price_type                  
  ,TARGET.extn_secondary_return_reason                =SOURCE.extn_secondary_return_reason
  ,TARGET.extn_apply_label_fee                =SOURCE.extn_apply_label_fee
  ,TARGET.extn_is_activation_complete                =SOURCE.extn_is_activation_complete
  ,TARGET.extn_item_desc                =SOURCE.extn_item_desc
  ,TARGET.extn_return_carton_count                =SOURCE.extn_return_carton_count
  ,TARGET.extn_asn_quantity                =SOURCE.extn_asn_quantity
  ,TARGET.extn_light_color                =SOURCE.extn_light_color
  ,TARGET.extn_light_type                =SOURCE.extn_light_type
  ,TARGET.extn_number_of_sections                =SOURCE.extn_number_of_sections
  ,TARGET.extn_total_cartons                =SOURCE.extn_total_cartons
  ,TARGET.extn_tree_height                =SOURCE.extn_tree_height
  ,TARGET.extn_tree_height_uom                =SOURCE.extn_tree_height_uom
  ,TARGET.extn_apply_restocking_fee                =SOURCE.extn_apply_restocking_fee
  ,TARGET.extn_return_pickup_date                =TRY_TO_TIMESTAMP(SOURCE.extn_return_pickup_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_pickup_confirmation_no                =SOURCE.extn_pickup_confirmation_no
  ,TARGET.extn_refund_shipping_cost                =SOURCE.extn_refund_shipping_cost
  ,TARGET.extn_is_fulfilled_line                =SOURCE.extn_is_fulfilled_line
  ,TARGET.extn_mfg_warranty_start_date                =TRY_TO_TIMESTAMP(SOURCE.extn_mfg_warranty_start_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_mfg_warranty_end_date                =TRY_TO_TIMESTAMP(SOURCE.extn_mfg_warranty_end_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_term                =SOURCE.extn_term
  ,TARGET.extn_is_invoice_required                =SOURCE.extn_is_invoice_required
  ,TARGET.extn_prem_guarantee_end_date                =TRY_TO_TIMESTAMP(SOURCE.extn_prem_guarantee_end_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_return_date                =TRY_TO_TIMESTAMP(SOURCE.extn_return_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_is_email_sent                =SOURCE.extn_is_email_sent
  ,TARGET.extn_return_required                =SOURCE.extn_return_required
  ,TARGET.extn_parent_prime_line_no                =SOURCE.extn_parent_prime_line_no
  ,TARGET.extn_parent_sub_line_no                =SOURCE.extn_parent_sub_line_no
  ,TARGET.extn_prem_guarantee_start_date     = TRY_TO_TIMESTAMP(SOURCE.extn_prem_guarantee_start_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_reship_upcid                =SOURCE.extn_reship_upcid
  ,TARGET.extn_parent_order_line_sku       =SOURCE.extn_parent_order_line_sku
WHEN NOT MATCHED THEN
INSERT (
fk_order_detailid
,order_line_key
,order_header_key
,prime_line_no                   
,sub_line_no                     
,line_type                      
,order_class                    
,item_id  
,alternate_item_id             
,uom                            
,product_class                  
,unit_price                     
,cost_currency                 
,ordered_qty                    
,basic_capacity_required        
,option_capacity_required       
,dependent_on_line_key         
,current_work_order_key        
,dependency_shipping_rule      
,fill_quantity                  
,committed_quantity            
,dependency_ratio               
,maintain_ratio                
,merge_node                    
,parent_of_dependent_group      
,source_from_organization      
,chained_from_order_line_key   
,chained_from_order_header_key 
,derived_from_order_line_key   
,derived_from_order_header_key 
,derived_from_order_release_key
,distribution_rule_id          
,invoiced_quantity              
,over_receipt_quantity          
,return_reason                 
,shipnode_key                  
,procure_from_node             
,ship_to_key                   
,mark_for_key                  
,buyer_mark_for_node_id        
,req_delivery_date             
,req_cancel_date   
,req_ship_date                 
,scac                          
,carrier_service_code          
,carrier_account_no            
,pickable_flag                  
,ship_together_no              
,hold_flag                      
,kit_code                      
,hold_reason_code              
,other_charges                  
,line_total                     
,invoiced_line_total            
,invoiced_extended_price        
,settled_quantity               
,settled_amount                 
,taxable_flag                   
,tax_exemption_certificate     
,discount_type                 
,discount_reference            
,gift_flag                      
,personalize_flag               
,personalize_code              
,department_code               
,customer_item  
,customer_item_description      
,item_weight                    
,item_weight_uom                
,item_description               
,item_short_description         
,reservation_id                
,reservation_pool              
,customer_po_no                
,customer_po_line_no           
,tax                            
,delivery_code                 
,original_ordered_qty           
,list_price                     
,retail_price                   
,discount_percentage            
,packlist_type                 
,supplier_item                 
,supplier_item_description     
,unit_cost                      
,upc_code                      
,fob                           
,manufacturer_name             
,manufacturer_item             
,manufacturer_item_desc        
,country_of_origin             
,isbn                          
,harmonized_code               
,ship_to_id                    
,product_line                  
,nmfc_code                     
,nmfc_class                    
,nmfc_description              
,tax_product_code               
,import_license_no             
,import_license_exp_date                 
,eccn_no                       
,schedule_b_code               
,supplier_code                 
,purpose                       
,receiving_node                
,buyer_receiving_node_id       
,shipment_consol_group_id      
,orig_order_line_key           
,line_seq_no                    
,split_qty                      
,pricing_date                            
,pipeline_key                   
,condition_variable_1          
,condition_variable_2          
,is_price_locked                
,is_cost_overridden             
,is_capacity_overridden         
,invoice_complete               
,delivery_method                
,item_group_code                
,cannot_complete_before_date   
,cannot_complete_after_date    
,appt_status                   
,can_add_service_lines          
,pricing_uom                    
,capacity_uom                  
,pricing_quantity               
,shipped_quantity               
,fixed_capacity_qty_per_line    
,fixed_pricing_qty_per_line     
,wait_for_seq_line              
,sched_failure_reason_code     
,earliest_ship_date  
,earliest_delivery_date  
,cannot_meet_appt              
,promised_appt_start_date      
,promised_appt_end_date        
,segment                        
,segment_type                   
,earliest_schedule_date        
,timezone                      
,is_forwarding_allowed         
,is_procurement_allowed        
,reship_parent_line_key        
,is_price_info_only            
,level_of_service               
,first_iter_seq_no             
,last_iter_seq_no              
,createts                                
,modifyts                                
,createuserid                   
,modifyuserid                   
,createprogid                   
,modifyprogid                   
,lockid  
,ordering_uom                   
,pricing_quantity_conv_factor   
,pricing_quantity_strategy      
,invoiced_pricing_quantity      
,is_standalone_service         
,tran_discrepancy_qty           
,received_quantity              
,invoice_based_on_actuals       
,actual_pricing_quantity        
,fulfillment_type               
,serial_no                     
,reservation_mandatory          
,is_firm_predefined_node        
,intentional_backorder          
,future_avail_date             
,repricing_quantity             
,min_ship_by_date              
,kit_qty                       
,bom_config_key                
,bundle_fulfillment_mode       
,is_gift_wrap                  
,group_sequence_num            
,in_store_payment_required     
,item_not_exist                
,derived_from_ext_ord          
,is_eligible_for_ship_disc      
,backorder_notification_qty     
,is_price_matched               
,is_pick_up_now                
,item_is_in_hand               
,disposition_code              
,extn_mod_reason_code          
,extn_mod_reason_desc          
,extn_asn                      
,extn_parent_order_no          
,extn_item_id                   
,extn_order_item_id            
,extn_price_type  
,bundle_parent_order_line_key
,extn_secondary_return_reason
,extn_apply_label_fee
,extn_is_activation_complete
,extn_item_desc
,extn_return_carton_count
,extn_asn_quantity
,extn_light_color
,extn_light_type
,extn_number_of_sections
,extn_total_cartons
,extn_tree_height
,extn_tree_height_uom
,extn_apply_restocking_fee
,extn_return_pickup_date
,extn_pickup_confirmation_no
,extn_refund_shipping_cost
,extn_is_fulfilled_line
,extn_mfg_warranty_start_date
,extn_mfg_warranty_end_date
,extn_term
,extn_is_invoice_required
,extn_prem_guarantee_end_date
,extn_return_date
,extn_is_email_sent
,extn_return_required
,extn_parent_prime_line_no
,extn_parent_sub_line_no
,extn_prem_guarantee_start_date
,extn_reship_upcid      
,extn_parent_order_line_sku    
)
VALUES(
SOURCE.pk_order_detailid
,SOURCE.order_line_key
,SOURCE.order_header_key
,SOURCE.prime_line_no                   
,SOURCE.sub_line_no                     
,SOURCE.line_type                      
,SOURCE.order_class                    
,SOURCE.item_id  
,SOURCE.alternate_item_id             
,SOURCE.uom                            
,SOURCE.product_class                  
,try_cast( SOURCE.unit_price as float)                     
,SOURCE.cost_currency                 
,SOURCE.ordered_qty                    
,SOURCE.basic_capacity_required        
,SOURCE.option_capacity_required       
,SOURCE.dependent_on_line_key         
,SOURCE.current_work_order_key        
,SOURCE.dependency_shipping_rule      
,SOURCE.fill_quantity                  
,SOURCE.committed_quantity            
,SOURCE.dependency_ratio               
,SOURCE.maintain_ratio                
,SOURCE.merge_node                    
,SOURCE.parent_of_dependent_group      
,SOURCE.source_from_organization      
,SOURCE.chained_from_order_line_key   
,SOURCE.chained_from_order_header_key 
,SOURCE.derived_from_order_line_key   
,SOURCE.derived_from_order_header_key 
,SOURCE.derived_from_order_release_key
,SOURCE.distribution_rule_id          
,SOURCE.invoiced_quantity              
,SOURCE.over_receipt_quantity          
,SOURCE.return_reason                 
,SOURCE.shipnode_key                  
,SOURCE.procure_from_node             
,SOURCE.ship_to_key                   
,SOURCE.mark_for_key                  
,SOURCE.buyer_mark_for_node_id        
,TRY_TO_TIMESTAMP(SOURCE.req_delivery_date,''YYYYMMDDHHMISS'')            
,TRY_TO_TIMESTAMP(SOURCE.req_cancel_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(SOURCE.req_ship_date,''YYYYMMDDHHMISS'')           
,SOURCE.scac                          
,SOURCE.carrier_service_code          
,SOURCE.carrier_account_no            
,SOURCE.pickable_flag                  
,SOURCE.ship_together_no              
,SOURCE.hold_flag                      
,SOURCE.kit_code                      
,SOURCE.hold_reason_code              
,SOURCE.other_charges                  
,try_cast( SOURCE.line_total as float)                   
,try_cast( SOURCE.invoiced_line_total as float)       
,try_cast( SOURCE.invoiced_extended_price as float)    
,SOURCE.settled_quantity               
,SOURCE.settled_amount                 
,SOURCE.taxable_flag                   
,SOURCE.tax_exemption_certificate     
,SOURCE.discount_type                 
,SOURCE.discount_reference            
,SOURCE.gift_flag                      
,SOURCE.personalize_flag               
,SOURCE.personalize_code              
,SOURCE.department_code               
,SOURCE.customer_item  
,SOURCE.customer_item_description      
,SOURCE.item_weight                    
,SOURCE.item_weight_uom                
,SOURCE.item_description               
,SOURCE.item_short_description         
,SOURCE.reservation_id                
,SOURCE.reservation_pool              
,SOURCE.customer_po_no                
,SOURCE.customer_po_line_no           
,SOURCE.tax                            
,SOURCE.delivery_code                 
,SOURCE.original_ordered_qty           
,try_cast( SOURCE.list_price as float)                      
,try_cast( SOURCE.retail_price as float)                 
,SOURCE.discount_percentage            
,SOURCE.packlist_type                 
,SOURCE.supplier_item                 
,SOURCE.supplier_item_description     
,SOURCE.unit_cost                      
,SOURCE.upc_code                      
,SOURCE.fob                           
,SOURCE.manufacturer_name             
,SOURCE.manufacturer_item             
,SOURCE.manufacturer_item_desc        
,SOURCE.country_of_origin             
,SOURCE.isbn                          
,SOURCE.harmonized_code               
,SOURCE.ship_to_id                    
,SOURCE.product_line                  
,SOURCE.nmfc_code                     
,SOURCE.nmfc_class                    
,SOURCE.nmfc_description              
,SOURCE.tax_product_code               
,SOURCE.import_license_no             
,TRY_TO_TIMESTAMP(SOURCE.import_license_exp_date,''YYYYMMDDHHMISS'')             
,SOURCE.eccn_no                       
,SOURCE.schedule_b_code               
,SOURCE.supplier_code                 
,SOURCE.purpose                       
,SOURCE.receiving_node                
,SOURCE.buyer_receiving_node_id       
,SOURCE.shipment_consol_group_id      
,SOURCE.orig_order_line_key           
,SOURCE.line_seq_no                    
,SOURCE.split_qty                      
,TRY_TO_TIMESTAMP(SOURCE.pricing_date,''YYYYMMDDHHMISS'')                          
,SOURCE.pipeline_key                   
,SOURCE.condition_variable_1          
,SOURCE.condition_variable_2          
,SOURCE.is_price_locked                
,SOURCE.is_cost_overridden             
,SOURCE.is_capacity_overridden         
,SOURCE.invoice_complete               
,SOURCE.delivery_method                
,SOURCE.item_group_code                
,TRY_TO_TIMESTAMP(SOURCE.cannot_complete_before_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(SOURCE.cannot_complete_after_date,''YYYYMMDDHHMISS'')
,SOURCE.appt_status                   
,SOURCE.can_add_service_lines          
,SOURCE.pricing_uom                    
,SOURCE.capacity_uom                  
,SOURCE.pricing_quantity               
,SOURCE.shipped_quantity               
,SOURCE.fixed_capacity_qty_per_line    
,SOURCE.fixed_pricing_qty_per_line     
,SOURCE.wait_for_seq_line              
,SOURCE.sched_failure_reason_code     
,TRY_TO_TIMESTAMP(SOURCE.earliest_ship_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(SOURCE.earliest_delivery_date,''YYYYMMDDHHMISS'')
,SOURCE.cannot_meet_appt              
,TRY_TO_TIMESTAMP(SOURCE.promised_appt_start_date,''YYYYMMDDHHMISS'')   
,TRY_TO_TIMESTAMP(SOURCE.promised_appt_end_date,''YYYYMMDDHHMISS'')   
,SOURCE.segment                        
,SOURCE.segment_type                   
,TRY_TO_TIMESTAMP(SOURCE.earliest_schedule_date,''YYYYMMDDHHMISS'')     
,SOURCE.timezone                      
,SOURCE.is_forwarding_allowed         
,SOURCE.is_procurement_allowed        
,SOURCE.reship_parent_line_key        
,SOURCE.is_price_info_only            
,SOURCE.level_of_service               
,SOURCE.first_iter_seq_no             
,SOURCE.last_iter_seq_no              
,TRY_TO_TIMESTAMP(SOURCE.createts,''YYYYMMDDHHMISS'')                             
,TRY_TO_TIMESTAMP(SOURCE.modifyts,''YYYYMMDDHHMISS'')                             
,SOURCE.createuserid                   
,SOURCE.modifyuserid                   
,SOURCE.createprogid                   
,SOURCE.modifyprogid                   
,SOURCE.lockid  
,SOURCE.ordering_uom                   
,SOURCE.pricing_quantity_conv_factor   
,SOURCE.pricing_quantity_strategy      
,SOURCE.invoiced_pricing_quantity      
,SOURCE.is_standalone_service         
,SOURCE.tran_discrepancy_qty           
,SOURCE.received_quantity              
,SOURCE.invoice_based_on_actuals       
,SOURCE.actual_pricing_quantity        
,SOURCE.fulfillment_type               
,SOURCE.serial_no                     
,SOURCE.reservation_mandatory          
,SOURCE.is_firm_predefined_node        
,SOURCE.intentional_backorder          
,TRY_TO_TIMESTAMP(SOURCE.future_avail_date,''YYYYMMDDHHMISS'')      
,SOURCE.repricing_quantity             
,TRY_TO_TIMESTAMP(SOURCE.min_ship_by_date,''YYYYMMDDHHMISS'')          
,SOURCE.kit_qty                       
,SOURCE.bom_config_key                
,SOURCE.bundle_fulfillment_mode       
,SOURCE.is_gift_wrap                  
,SOURCE.group_sequence_num            
,SOURCE.in_store_payment_required     
,SOURCE.item_not_exist                
,SOURCE.derived_from_ext_ord          
,SOURCE.is_eligible_for_ship_disc      
,SOURCE.backorder_notification_qty     
,SOURCE.is_price_matched               
,SOURCE.is_pick_up_now                
,SOURCE.item_is_in_hand               
,SOURCE.disposition_code              
,SOURCE.extn_mod_reason_code          
,SOURCE.extn_mod_reason_desc          
,SOURCE.extn_asn                      
,SOURCE.extn_parent_order_no          
,SOURCE.extn_item_id                   
,SOURCE.extn_order_item_id            
,SOURCE.extn_price_type   
,SOURCE.bundle_parent_order_line_key
,SOURCE.extn_secondary_return_reason
,SOURCE.extn_apply_label_fee
,SOURCE.extn_is_activation_complete
,SOURCE.extn_item_desc
,SOURCE.extn_return_carton_count
,SOURCE.extn_asn_quantity
,SOURCE.extn_light_color
,SOURCE.extn_light_type
,SOURCE.extn_number_of_sections
,SOURCE.extn_total_cartons
,SOURCE.extn_tree_height
,SOURCE.extn_tree_height_uom
,SOURCE.extn_apply_restocking_fee
,TRY_TO_TIMESTAMP(SOURCE.extn_return_pickup_date,''YYYYMMDDHHMISS'')
,SOURCE.extn_pickup_confirmation_no
,SOURCE.extn_refund_shipping_cost
,SOURCE.extn_is_fulfilled_line
,TRY_TO_TIMESTAMP(SOURCE.extn_mfg_warranty_start_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(SOURCE.extn_mfg_warranty_end_date,''YYYYMMDDHHMISS'')
,SOURCE.extn_term
,SOURCE.extn_is_invoice_required
,TRY_TO_TIMESTAMP(SOURCE.extn_prem_guarantee_end_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(SOURCE.extn_return_date,''YYYYMMDDHHMISS'')
,SOURCE.extn_is_email_sent
,SOURCE.extn_return_required
,SOURCE.extn_parent_prime_line_no
,SOURCE.extn_parent_sub_line_no
,TRY_TO_TIMESTAMP(SOURCE.extn_prem_guarantee_start_date,''YYYYMMDDHHMISS'')
,SOURCE.extn_reship_upcid         
,SOURCE.extn_parent_order_line_sku
);

--RETURN ''here'';

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.OrderDetailMultipartItems
AS
SELECT DISTINCT 
    toh.pk_order_headerid as fk_order_detailid
    ,stg.order_line_key
    ,stg.order_header_key
    ,stg.prime_line_no                   
    ,stg.sub_line_no                     
    ,stg.line_type                      
    ,stg.order_class                    
    ,stg.item_id  
    ,stg.alternate_item_id             
    ,stg.uom                            
    ,stg.product_class                  
    ,try_cast( stg.unit_price as float) as unit_price                     
    ,stg.cost_currency                 
    ,stg.ordered_qty                    
    ,stg.basic_capacity_required        
    ,stg.option_capacity_required       
    ,stg.dependent_on_line_key         
    ,stg.current_work_order_key        
    ,stg.dependency_shipping_rule      
    ,stg.fill_quantity                  
    ,stg.committed_quantity            
    ,stg.dependency_ratio               
    ,stg.maintain_ratio                
    ,stg.merge_node                    
    ,stg.parent_of_dependent_group      
    ,stg.source_from_organization      
    ,stg.chained_from_order_line_key   
    ,stg.chained_from_order_header_key 
    ,stg.derived_from_order_line_key   
    ,stg.derived_from_order_header_key 
    ,stg.derived_from_order_release_key
    ,stg.distribution_rule_id          
    ,stg.invoiced_quantity              
    ,stg.over_receipt_quantity          
    ,stg.return_reason                 
    ,stg.shipnode_key                  
    ,stg.procure_from_node             
    ,stg.ship_to_key                   
    ,stg.mark_for_key                  
    ,stg.buyer_mark_for_node_id        
    ,stg.req_delivery_date             
    ,stg.req_cancel_date   
    ,stg.req_ship_date                 
    ,stg.scac                          
    ,stg.carrier_service_code          
    ,stg.carrier_account_no            
    ,stg.pickable_flag                  
    ,stg.ship_together_no              
    ,stg.hold_flag                      
    ,stg.kit_code                      
    ,stg.hold_reason_code              
    ,stg.other_charges                  
    ,stg.line_total                     
    ,stg.invoiced_line_total            
    ,stg.invoiced_extended_price        
    ,stg.settled_quantity               
    ,stg.settled_amount                 
    ,stg.taxable_flag                   
    ,stg.tax_exemption_certificate     
    ,stg.discount_type                 
    ,stg.discount_reference            
    ,stg.gift_flag                      
    ,stg.personalize_flag               
    ,stg.personalize_code              
    ,stg.department_code               
    ,stg.customer_item  
    ,stg.customer_item_description      
    ,stg.item_weight                    
    ,stg.item_weight_uom                
    ,stg.item_description               
    ,stg.item_short_description         
    ,stg.reservation_id                
    ,stg.reservation_pool              
    ,stg.customer_po_no                
    ,stg.customer_po_line_no           
    ,stg.tax                            
    ,stg.delivery_code                 
    ,stg.original_ordered_qty           
    ,try_cast( stg.list_price as float) as list_price                 
    ,try_cast( stg.retail_price as float) as retail_price                
    ,stg.discount_percentage            
    ,stg.packlist_type                 
    ,stg.supplier_item                 
    ,stg.supplier_item_description     
    ,stg.unit_cost                      
    ,stg.upc_code                      
    ,stg.fob                           
    ,stg.manufacturer_name             
    ,stg.manufacturer_item             
    ,stg.manufacturer_item_desc        
    ,stg.country_of_origin             
    ,stg.isbn                          
    ,stg.harmonized_code               
    ,stg.ship_to_id                    
    ,stg.product_line                  
    ,stg.nmfc_code                     
    ,stg.nmfc_class                    
    ,stg.nmfc_description              
    ,stg.tax_product_code               
    ,stg.import_license_no             
    ,stg.import_license_exp_date                 
    ,stg.eccn_no                       
    ,stg.schedule_b_code               
    ,stg.supplier_code                 
    ,stg.purpose                       
    ,stg.receiving_node                
    ,stg.buyer_receiving_node_id       
    ,stg.shipment_consol_group_id      
    ,stg.orig_order_line_key           
    ,stg.line_seq_no                    
    ,stg.split_qty                      
    ,stg.pricing_date                            
    ,stg.pipeline_key                   
    ,stg.condition_variable_1          
    ,stg.condition_variable_2          
    ,stg.is_price_locked                
    ,stg.is_cost_overridden             
    ,stg.is_capacity_overridden         
    ,stg.invoice_complete               
    ,stg.delivery_method                
    ,stg.item_group_code                
    ,stg.cannot_complete_before_date   
    ,stg.cannot_complete_after_date    
    ,stg.appt_status                   
    ,stg.can_add_service_lines          
    ,stg.pricing_uom                    
    ,stg.capacity_uom                  
    ,stg.pricing_quantity               
    ,stg.shipped_quantity               
    ,stg.fixed_capacity_qty_per_line    
    ,stg.fixed_pricing_qty_per_line     
    ,stg.wait_for_seq_line              
    ,stg.sched_failure_reason_code     
    ,stg.earliest_ship_date  
    ,stg.earliest_delivery_date  
    ,stg.cannot_meet_appt              
    ,stg.promised_appt_start_date      
    ,stg.promised_appt_end_date        
    ,stg.segment                        
    ,stg.segment_type                   
    ,stg.earliest_schedule_date        
    ,stg.timezone                      
    ,stg.is_forwarding_allowed         
    ,stg.is_procurement_allowed        
    ,stg.reship_parent_line_key        
    ,stg.is_price_info_only            
    ,stg.level_of_service               
    ,stg.first_iter_seq_no             
    ,stg.last_iter_seq_no              
    ,stg.createts                                
    ,stg.modifyts                                
    ,stg.createuserid                   
    ,stg.modifyuserid                   
    ,stg.createprogid                   
    ,stg.modifyprogid                   
    ,stg.lockid  
    ,stg.ordering_uom                   
    ,stg.pricing_quantity_conv_factor   
    ,stg.pricing_quantity_strategy      
    ,stg.invoiced_pricing_quantity      
    ,stg.is_standalone_service         
    ,stg.tran_discrepancy_qty           
    ,stg.received_quantity              
    ,stg.invoice_based_on_actuals       
    ,stg.actual_pricing_quantity        
    ,stg.fulfillment_type               
    ,stg.serial_no                     
    ,stg.reservation_mandatory          
    ,stg.is_firm_predefined_node        
    ,stg.intentional_backorder          
    ,stg.future_avail_date             
    ,stg.repricing_quantity             
    ,stg.min_ship_by_date              
    ,stg.kit_qty                       
    ,stg.bom_config_key                
    ,stg.bundle_fulfillment_mode       
    ,stg.is_gift_wrap                  
    ,stg.group_sequence_num            
    ,stg.in_store_payment_required     
    ,stg.item_not_exist                
    ,stg.derived_from_ext_ord          
    ,stg.is_eligible_for_ship_disc      
    ,stg.backorder_notification_qty     
    ,stg.is_price_matched               
    ,stg.is_pick_up_now                
    ,stg.item_is_in_hand               
    ,stg.disposition_code              
    ,stg.extn_mod_reason_code          
    ,stg.extn_mod_reason_desc          
    ,stg.extn_asn                      
    ,stg.extn_parent_order_no          
    ,stg.extn_item_id                   
    ,stg.extn_order_item_id            
    ,stg.extn_price_type                
    ,stg.extn_secondary_return_reason  
    ,stg.extn_apply_label_fee           
    ,stg.extn_is_activation_complete   
    ,stg.extn_item_desc                
    ,stg.extn_return_carton_count       
    ,stg.extn_asn_quantity             
    ,stg.extn_light_color              
    ,stg.extn_light_type               
    ,stg.extn_number_of_sections       
    ,stg.extn_total_cartons            
    ,stg.extn_tree_height              
    ,stg.extn_tree_height_uom    
    ,mp.pk_order_detail_multipartid
    ,stg.bundle_parent_order_line_key
    ,stg.extn_apply_restocking_fee
    ,stg.extn_return_pickup_date
    ,stg.extn_pickup_confirmation_no
    ,stg.extn_refund_shipping_cost
    ,stg.extn_is_fulfilled_line
    ,stg.extn_mfg_warranty_start_date
    ,stg.extn_mfg_warranty_end_date
    ,stg.extn_term
    ,stg.extn_is_invoice_required
    ,stg.extn_prem_guarantee_end_date
    ,stg.extn_return_date
    ,stg.extn_is_email_sent
    ,stg.extn_return_required
    ,stg.extn_parent_prime_line_no
    ,stg.extn_parent_sub_line_no
    ,stg.extn_prem_guarantee_start_date
    ,stg.extn_reship_upcid
    ,stg.extn_parent_order_line_sku
    ,CAST(1 AS NUMBER(10, 0)) as revision
from 
	     TRANSFORMED.stg_ORDER_line_multipart AS stg
		INNER JOIN ANALYTICS.txn_order_header as toh on toh.order_header_key = stg.order_header_key and toh.entry_type is not null
        INNER JOIN ANALYTICS.txn_order_detail as tod on tod.fk_order_headerid = toh.pk_order_headerid 
		and	  stg.BUNDLE_PARENT_ORDER_LINE_KEY =tod.order_line_key
        INNER JOIN ANALYTICS.txn_order_detail_multipart mp on  stg.order_line_key = mp.order_line_key  and stg.BUNDLE_PARENT_ORDER_LINE_KEY = mp.BUNDLE_PARENT_ORDER_LINE_KEY 
		where stg.BUNDLE_PARENT_ORDER_LINE_KEY is not null;

        
 UPDATE
 	ANALYTICS.OrderDetailMultipartItems
SET
 	Revision = CAST((aot.revision + 1) as int)
 FROM
         ANALYTICS.OrderDetailMultipartItems as ttd
         inner join (
 		SELECT
             MAX(aot.revision) as revision,
             aot.fk_order_detailid,
             aot.pk_order_detail_multipartid
         from
             ANALYTICS.audit_order_detail_multipart as aot
             inner join ANALYTICS.OrderDetailMultipartItems as abc on abc.fk_order_detailid = aot.fk_order_detailid and 
             abc.pk_order_detail_multipartid = aot.pk_order_detail_multipartid
         group by
 			 aot.fk_order_detailid,
             aot.pk_order_detail_multipartid
 	) as aot on ttd.pk_order_detail_multipartid = aot.pk_order_detail_multipartid
             and ttd.fk_order_detailid = aot.fk_order_detailid;





				INSERT INTO ANALYTICS.audit_order_detail_multipart(
			pk_order_detail_multipartid
,fk_order_detailid
,order_line_key
,order_header_key
,prime_line_no                   
,sub_line_no                     
,line_type                      
,order_class                    
,item_id  
,alternate_item_id             
,uom                            
,product_class                  
,unit_price                     
,cost_currency                 
,ordered_qty                    
,basic_capacity_required        
,option_capacity_required       
,dependent_on_line_key         
,current_work_order_key        
,dependency_shipping_rule      
,fill_quantity                  
,committed_quantity            
,dependency_ratio               
,maintain_ratio                
,merge_node                    
,parent_of_dependent_group      
,source_from_organization      
,chained_from_order_line_key   
,chained_from_order_header_key 
,derived_from_order_line_key   
,derived_from_order_header_key 
,derived_from_order_release_key
,distribution_rule_id          
,invoiced_quantity              
,over_receipt_quantity          
,return_reason                 
,shipnode_key                  
,procure_from_node             
,ship_to_key                   
,mark_for_key                  
,buyer_mark_for_node_id        
,req_delivery_date             
,req_cancel_date   
,req_ship_date                 
,scac                          
,carrier_service_code          
,carrier_account_no            
,pickable_flag                  
,ship_together_no              
,hold_flag                      
,kit_code                      
,hold_reason_code              
,other_charges                  
,line_total                     
,invoiced_line_total            
,invoiced_extended_price        
,settled_quantity               
,settled_amount                 
,taxable_flag                   
,tax_exemption_certificate     
,discount_type                 
,discount_reference            
,gift_flag                      
,personalize_flag               
,personalize_code              
,department_code               
,customer_item  
,customer_item_description      
,item_weight                    
,item_weight_uom                
,item_description               
,item_short_description         
,reservation_id                
,reservation_pool              
,customer_po_no                
,customer_po_line_no           
,tax                            
,delivery_code                 
,original_ordered_qty           
,list_price                     
,retail_price                   
,discount_percentage            
,packlist_type                 
,supplier_item                 
,supplier_item_description     
,unit_cost                      
,upc_code                      
,fob                           
,manufacturer_name             
,manufacturer_item             
,manufacturer_item_desc        
,country_of_origin             
,isbn                          
,harmonized_code               
,ship_to_id                    
,product_line                  
,nmfc_code                     
,nmfc_class                    
,nmfc_description              
,tax_product_code               
,import_license_no             
,import_license_exp_date                 
,eccn_no                       
,schedule_b_code               
,supplier_code                 
,purpose                       
,receiving_node                
,buyer_receiving_node_id       
,shipment_consol_group_id      
,orig_order_line_key           
,line_seq_no                    
,split_qty                      
,pricing_date                            
,pipeline_key                   
,condition_variable_1          
,condition_variable_2          
,is_price_locked                
,is_cost_overridden             
,is_capacity_overridden         
,invoice_complete               
,delivery_method                
,item_group_code                
,cannot_complete_before_date   
,cannot_complete_after_date    
,appt_status                   
,can_add_service_lines          
,pricing_uom                    
,capacity_uom                  
,pricing_quantity               
,shipped_quantity               
,fixed_capacity_qty_per_line    
,fixed_pricing_qty_per_line     
,wait_for_seq_line              
,sched_failure_reason_code     
,earliest_ship_date  
,earliest_delivery_date  
,cannot_meet_appt              
,promised_appt_start_date      
,promised_appt_end_date        
,segment                        
,segment_type                   
,earliest_schedule_date        
,timezone                      
,is_forwarding_allowed         
,is_procurement_allowed        
,reship_parent_line_key        
,is_price_info_only            
,level_of_service               
,first_iter_seq_no             
,last_iter_seq_no              
,createts                                
,modifyts                                
,createuserid                   
,modifyuserid                   
,createprogid                   
,modifyprogid                   
,lockid  
,ordering_uom                   
,pricing_quantity_conv_factor   
,pricing_quantity_strategy      
,invoiced_pricing_quantity      
,is_standalone_service         
,tran_discrepancy_qty           
,received_quantity              
,invoice_based_on_actuals       
,actual_pricing_quantity        
,fulfillment_type               
,serial_no                     
,reservation_mandatory          
,is_firm_predefined_node        
,intentional_backorder          
,future_avail_date             
,repricing_quantity             
,min_ship_by_date              
,kit_qty                       
,bom_config_key                
,bundle_fulfillment_mode       
,is_gift_wrap                  
,group_sequence_num            
,in_store_payment_required     
,item_not_exist                
,derived_from_ext_ord          
,is_eligible_for_ship_disc      
,backorder_notification_qty     
,is_price_matched               
,is_pick_up_now                
,item_is_in_hand               
,disposition_code              
,extn_mod_reason_code          
,extn_mod_reason_desc          
,extn_asn                      
,extn_parent_order_no          
,extn_item_id                   
,extn_order_item_id            
,extn_price_type                
,extn_secondary_return_reason  
,extn_apply_label_fee           
,extn_is_activation_complete   
,extn_item_desc                
,extn_return_carton_count       
,extn_asn_quantity             
,extn_light_color              
,extn_light_type               
,extn_number_of_sections       
,extn_total_cartons            
,extn_tree_height              
,extn_tree_height_uom 
,bundle_parent_order_line_key
,extn_apply_restocking_fee
,extn_return_pickup_date
,extn_pickup_confirmation_no
,extn_refund_shipping_cost
,extn_is_fulfilled_line
,extn_mfg_warranty_start_date
,extn_mfg_warranty_end_date
,extn_term
,extn_is_invoice_required
,extn_prem_guarantee_end_date
,extn_return_date
,extn_is_email_sent
,extn_return_required
,extn_parent_prime_line_no
,extn_parent_sub_line_no
,extn_prem_guarantee_start_date
,extn_reship_upcid      
,extn_parent_order_line_sku
,revision)
select
odmi.pk_order_detail_multipartid
,odmi.fk_order_detailid
,odmi.order_line_key
,odmi.order_header_key
,odmi.prime_line_no                   
,odmi.sub_line_no                     
,odmi.line_type                      
,odmi.order_class                    
,odmi.item_id  
,odmi.alternate_item_id             
,odmi.uom                            
,odmi.product_class                  
,odmi.unit_price                     
,odmi.cost_currency                 
,odmi.ordered_qty                    
,odmi.basic_capacity_required        
,odmi.option_capacity_required       
,odmi.dependent_on_line_key         
,odmi.current_work_order_key        
,odmi.dependency_shipping_rule      
,odmi.fill_quantity                  
,odmi.committed_quantity            
,odmi.dependency_ratio               
,odmi.maintain_ratio                
,odmi.merge_node                    
,odmi.parent_of_dependent_group      
,odmi.source_from_organization      
,odmi.chained_from_order_line_key   
,odmi.chained_from_order_header_key 
,odmi.derived_from_order_line_key   
,odmi.derived_from_order_header_key 
,odmi.derived_from_order_release_key
,odmi.distribution_rule_id          
,odmi.invoiced_quantity              
,odmi.over_receipt_quantity          
,odmi.return_reason                 
,odmi.shipnode_key                  
,odmi.procure_from_node             
,odmi.ship_to_key                   
,odmi.mark_for_key                  
,odmi.buyer_mark_for_node_id        
,TRY_TO_TIMESTAMP(odmi.req_delivery_date,''YYYYMMDDHHMISS'')     
,TRY_TO_TIMESTAMP(odmi.req_cancel_date,''YYYYMMDDHHMISS'') 
,TRY_TO_TIMESTAMP(odmi.req_ship_date,''YYYYMMDDHHMISS'')             
,odmi.scac                          
,odmi.carrier_service_code          
,odmi.carrier_account_no            
,odmi.pickable_flag                  
,odmi.ship_together_no              
,odmi.hold_flag                      
,odmi.kit_code                      
,odmi.hold_reason_code              
,odmi.other_charges                  
,try_cast( odmi.line_total as float)                      
,try_cast( odmi.invoiced_line_total as float)        
,try_cast( odmi.invoiced_extended_price as float)      
,odmi.settled_quantity               
,odmi.settled_amount                 
,odmi.taxable_flag                   
,odmi.tax_exemption_certificate     
,odmi.discount_type                 
,odmi.discount_reference            
,odmi.gift_flag                      
,odmi.personalize_flag               
,odmi.personalize_code              
,odmi.department_code               
,odmi.customer_item  
,odmi.customer_item_description      
,odmi.item_weight                    
,odmi.item_weight_uom                
,odmi.item_description               
,odmi.item_short_description         
,odmi.reservation_id                
,odmi.reservation_pool              
,odmi.customer_po_no                
,odmi.customer_po_line_no           
,odmi.tax                            
,odmi.delivery_code                 
,odmi.original_ordered_qty           
,odmi.list_price                     
,odmi.retail_price                   
,odmi.discount_percentage            
,odmi.packlist_type                 
,odmi.supplier_item                 
,odmi.supplier_item_description     
,odmi.unit_cost                      
,odmi.upc_code                      
,odmi.fob                           
,odmi.manufacturer_name             
,odmi.manufacturer_item             
,odmi.manufacturer_item_desc        
,odmi.country_of_origin             
,odmi.isbn                          
,odmi.harmonized_code               
,odmi.ship_to_id                    
,odmi.product_line                  
,odmi.nmfc_code                     
,odmi.nmfc_class                    
,odmi.nmfc_description              
,odmi.tax_product_code               
,odmi.import_license_no             
,TRY_TO_TIMESTAMP(odmi.import_license_exp_date,''YYYYMMDDHHMISS'')             
,odmi.eccn_no                       
,odmi.schedule_b_code               
,odmi.supplier_code                 
,odmi.purpose                       
,odmi.receiving_node                
,odmi.buyer_receiving_node_id       
,odmi.shipment_consol_group_id      
,odmi.orig_order_line_key           
,odmi.line_seq_no                    
,odmi.split_qty                      
,TRY_TO_TIMESTAMP(odmi.pricing_date,''YYYYMMDDHHMISS'')                          
,odmi.pipeline_key                   
,odmi.condition_variable_1          
,odmi.condition_variable_2          
,odmi.is_price_locked                
,odmi.is_cost_overridden             
,odmi.is_capacity_overridden         
,odmi.invoice_complete               
,odmi.delivery_method                
,odmi.item_group_code                
,TRY_TO_TIMESTAMP(odmi.cannot_complete_before_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(odmi.cannot_complete_after_date,''YYYYMMDDHHMISS'')
,odmi.appt_status                   
,odmi.can_add_service_lines          
,odmi.pricing_uom                    
,odmi.capacity_uom                  
,odmi.pricing_quantity               
,odmi.shipped_quantity               
,odmi.fixed_capacity_qty_per_line    
,odmi.fixed_pricing_qty_per_line     
,odmi.wait_for_seq_line              
,odmi.sched_failure_reason_code     
,TRY_TO_TIMESTAMP(odmi.earliest_ship_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(odmi.earliest_delivery_date,''YYYYMMDDHHMISS'')
,odmi.cannot_meet_appt              
,TRY_TO_TIMESTAMP(odmi.promised_appt_start_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(odmi.promised_appt_end_date,''YYYYMMDDHHMISS'')  
,odmi.segment                        
,odmi.segment_type                   
,TRY_TO_TIMESTAMP(odmi.earliest_schedule_date,''YYYYMMDDHHMISS'')    
,odmi.timezone                      
,odmi.is_forwarding_allowed         
,odmi.is_procurement_allowed        
,odmi.reship_parent_line_key        
,odmi.is_price_info_only            
,odmi.level_of_service               
,odmi.first_iter_seq_no             
,odmi.last_iter_seq_no              
,TRY_TO_TIMESTAMP(odmi.createts,''YYYYMMDDHHMISS'')                             
,TRY_TO_TIMESTAMP(odmi.modifyts,''YYYYMMDDHHMISS'')                           
,odmi.createuserid                   
,odmi.modifyuserid                   
,odmi.createprogid                   
,odmi.modifyprogid                   
,odmi.lockid  
,odmi.ordering_uom                   
,odmi.pricing_quantity_conv_factor   
,odmi.pricing_quantity_strategy      
,odmi.invoiced_pricing_quantity      
,odmi.is_standalone_service         
,odmi.tran_discrepancy_qty           
,odmi.received_quantity              
,odmi.invoice_based_on_actuals       
,odmi.actual_pricing_quantity        
,odmi.fulfillment_type               
,odmi.serial_no                     
,odmi.reservation_mandatory          
,odmi.is_firm_predefined_node        
,odmi.intentional_backorder          
,TRY_TO_TIMESTAMP(odmi.future_avail_date,''YYYYMMDDHHMISS'')        
,odmi.repricing_quantity             
,TRY_TO_TIMESTAMP(odmi.min_ship_by_date,''YYYYMMDDHHMISS'')       
,odmi.kit_qty                       
,odmi.bom_config_key                
,odmi.bundle_fulfillment_mode       
,odmi.is_gift_wrap                  
,odmi.group_sequence_num            
,odmi.in_store_payment_required     
,odmi.item_not_exist                
,odmi.derived_from_ext_ord          
,odmi.is_eligible_for_ship_disc      
,odmi.backorder_notification_qty     
,odmi.is_price_matched               
,odmi.is_pick_up_now                
,odmi.item_is_in_hand               
,odmi.disposition_code              
,odmi.extn_mod_reason_code          
,odmi.extn_mod_reason_desc          
,odmi.extn_asn                      
,odmi.extn_parent_order_no          
,odmi.extn_item_id                   
,odmi.extn_order_item_id            
,odmi.extn_price_type                
,odmi.extn_secondary_return_reason  
,odmi.extn_apply_label_fee           
,odmi.extn_is_activation_complete   
,odmi.extn_item_desc                
,odmi.extn_return_carton_count       
,odmi.extn_asn_quantity             
,odmi.extn_light_color              
,odmi.extn_light_type               
,odmi.extn_number_of_sections       
,odmi.extn_total_cartons            
,odmi.extn_tree_height              
,odmi.extn_tree_height_uom    
,odmi.bundle_parent_order_line_key
,odmi.extn_apply_restocking_fee
,TRY_TO_TIMESTAMP(odmi.extn_return_pickup_date,''YYYYMMDDHHMISS'')
,odmi.extn_pickup_confirmation_no
,odmi.extn_refund_shipping_cost
,odmi.extn_is_fulfilled_line
,TRY_TO_TIMESTAMP(odmi.extn_mfg_warranty_start_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(odmi.extn_mfg_warranty_end_date,''YYYYMMDDHHMISS'')
,odmi.extn_term
,odmi.extn_is_invoice_required
,TRY_TO_TIMESTAMP(odmi.extn_prem_guarantee_end_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(odmi.extn_return_date,''YYYYMMDDHHMISS'')
,odmi.extn_is_email_sent
,odmi.extn_return_required
,odmi.extn_parent_prime_line_no
,odmi.extn_parent_sub_line_no
,TRY_TO_TIMESTAMP(odmi.extn_prem_guarantee_start_date,''YYYYMMDDHHMISS'')
,odmi.extn_reship_upcid
,odmi.extn_parent_order_line_sku
,odmi.revision
from 
ANALYTICS.OrderDetailMultipartItems as odmi;


	MERGE INTO RAW.raw_ORDER_header AS target
USING (
SELECT DISTINCT 
    roh.ORDER_NO,
    roh.ORDER_HEADER_KEY,
    roh.modifyts,
    -- Add other columns that need to be updated (use appropriate values)
    ''Processed'' AS processing_status,
    '''' AS processing_comment,
    '''' AS processing_errortype
FROM RAW.raw_ORDER_header AS roh
INNER JOIN TRANSFORMED.stg_ORDER_header AS rod 
    ON rod.ORDER_NO = roh.ORDER_NO
    AND rod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY 
    AND roh.modifyts = rod.modifyts
INNER JOIN ANALYTICS.TempAmendOrders AS tod 
    ON tod.source_ref_num = roh.ORDER_NO 
    AND tod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY 
    AND tod.txn_id = rod.txn_id
WHERE 
    roh.processing_status IN (''Pending'', ''Failed'')

) AS source
ON (target.ORDER_NO = source.ORDER_NO 
    AND target.ORDER_HEADER_KEY = source.ORDER_HEADER_KEY 
    AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;
		
		
MERGE INTO RAW.raw_ORDER_header AS target
USING (
SELECT DISTINCT 
    roh.ORDER_NO,
    roh.ORDER_HEADER_KEY,
    roh.modifyts,
    -- Add other columns that need to be updated (use appropriate values)
    ''Processed'' AS processing_status,
    '''' AS processing_comment,
    '''' AS processing_errortype
FROM RAW.raw_ORDER_header AS roh
INNER JOIN TRANSFORMED.stg_ORDER_header AS rod 
    ON rod.ORDER_NO = roh.ORDER_NO 
    AND rod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY 
    AND roh.modifyts = rod.modifyts
LEFT JOIN ANALYTICS.TempAmendOrders AS tod 
    ON tod.source_ref_num = roh.customer_po_no 
    AND tod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY
WHERE 
    roh.processing_status IN (''Pending'', ''Failed'')
    AND tod.source_ref_num IS NOT NULL
	AND roh.order_name = ''MIGRATED''

) AS source
ON (target.ORDER_NO = source.ORDER_NO AND target.ORDER_HEADER_KEY = source.ORDER_HEADER_KEY AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;




	MERGE INTO RAW.raw_ORDER_line AS target
USING (
SELECT DISTINCT 
    roh.ORDER_LINE_KEY,
    roh.PRIME_LINE_NO,
    roh.modifyts,
    -- Add other columns that need to be updated (use appropriate values)
    ''Processed'' AS processing_status,
    '''' AS processing_comment,
    '''' AS processing_errortype
FROM RAW.raw_ORDER_line AS roh
INNER JOIN TRANSFORMED.stg_ORDER_line AS rod 
    ON rod.ORDER_LINE_KEY = roh.ORDER_LINE_KEY
    AND rod.PRIME_LINE_NO = roh.PRIME_LINE_NO 
    AND roh.modifyts = rod.modifyts
INNER JOIN ANALYTICS.TempAmendOrderDetails AS tod 
    ON tod.ext_line_id = roh.ORDER_LINE_KEY 
    AND tod.prime_line_num = rod.PRIME_LINE_NO
WHERE 
    roh.processing_status IN (''Pending'', ''Failed'')

) AS source
ON (target.ORDER_LINE_KEY = source.ORDER_LINE_KEY 
    AND target.PRIME_LINE_NO = source.PRIME_LINE_NO 
    AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;





	MERGE INTO RAW.raw_ORDER_line AS target
USING (
SELECT DISTINCT 
    roh.ORDER_LINE_KEY,
    roh.PRIME_LINE_NO,
    roh.modifyts,
    -- Add other columns that need to be updated (use appropriate values)
    ''Processed'' AS processing_status,
    '''' AS processing_comment,
    '''' AS processing_errortype
FROM RAW.raw_ORDER_line AS roh
INNER JOIN TRANSFORMED.stg_ORDER_line_multipart AS rod 
    ON rod.ORDER_LINE_KEY = roh.ORDER_LINE_KEY
    AND rod.PRIME_LINE_NO = roh.PRIME_LINE_NO 
    AND roh.modifyts = rod.modifyts
INNER JOIN ANALYTICS.OrderDetailMultipartItems AS tod 
    ON tod.ORDER_LINE_KEY = roh.ORDER_LINE_KEY 
    AND tod.PRIME_LINE_NO = rod.PRIME_LINE_NO
WHERE 
    roh.processing_status IN (''Pending'', ''Failed'')

) AS source
ON (target.ORDER_LINE_KEY = source.ORDER_LINE_KEY 
    AND target.PRIME_LINE_NO = source.PRIME_LINE_NO 
    AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;

   
        
SELECT COUNT(*) INTO
        :toBeProcessedRecordCount 
    FROM
        TRANSFORMED.stg_ORDER_header;




SELECT
         COUNT(*) INTO :toBeProcessedLineRecordCount
    FROM
        TRANSFORMED.stg_ORDER_line;

		SELECT
        :toBeProcessedLineRecordCount =   :toBeProcessedLineRecordCount + COUNT(*)
    FROM
        TRANSFORMED.stg_ORDER_line_multipart;


SELECT
        :prcessedHeaderRecordCount = :prcessedHeaderRecordCount + COUNT(*)
    FROM
        ANALYTICS.TempAmendOrders;




UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    --SET to_be_processed = (SELECT COUNT(*) FROM transformed.stg_ORDER_inbox)
    WHERE file_name = ''YFS_ORDER_HEADER'';


SELECT
        :prcessedLineRecordCount = :prcessedLineRecordCount + COUNT(*)
    FROM
        ANALYTICS.OrderDetailMultipartItems;


SELECT
        :prcessedLineRecordCount = :prcessedLineRecordCount + COUNT(*)
    FROM
        ANALYTICS.TempAmendOrderDetails;
        

UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    --SET to_be_processed = (SELECT COUNT(*) FROM transformed.stg_ORDER_inbox)
    WHERE file_name = ''YFS_ORDER_LINE'';

--drop table #updatedOrderDetails;
DROP TABLE ANALYTICS.createdOrders;
DROP TABLE ANALYTICS.updatedOrders;
DROP TABLE ANALYTICS.OrderDetailMultipartItems;
DROP TABLE ANALYTICS.UPDATEDORDERCUSTOMER;
	--DROP TABLE #UPDATEDORDERADDRESSTABLE;
DROP TABLE ANALYTICS.updatedOrderDetails;
DROP TABLE ANALYTICS.TempAmendOrders;
DROP TABLE ANALYTICS.TempAmendOrderDetails;

-- Drop tables
DROP TABLE IF EXISTS ANALYTICS.CREATEDORDERCUSTOMER;
DROP TABLE IF EXISTS ANALYTICS.CREATEDORDERADDRESSTABLE;
DROP TABLE IF EXISTS ANALYTICS.createdOrderDetails;
DROP TABLE IF EXISTS ANALYTICS.TempORDER_Orders;
DROP TABLE IF EXISTS ANALYTICS.TempOrderDetails;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;

     UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_HEADER'';
            
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
    RETURN error_object;


END';
CREATE PROCEDURE "USP_RAW_ORDER_DATA_CLEANUP"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
  limitDate datetime DEFAULT DATEADD(day, -50,  getdate());
  BEGIN
  SYSTEM$LOG(''TRACE'','' USP_RAW_ORDER_DATA_CLEANUP has been Started'');

delete  from raw.raw_order_header where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_header_charges  where imported_date < :limitDate  and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_line  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_line_charges  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_tax_breakup  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_container_details  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_payment  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_payment_type  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_person_info  where (((case when IMPORTED_DATE ilike any (''%PM'',''%AM'') then left(to_timestamp(IMPORTED_DATE,''Mon DD YYYY HH12:MIAM''),16) else IMPORTED_DATE end ))) < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_release  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_release_status  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_shipment  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_shipment_container  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_shipment_line  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
SYSTEM$LOG(''TRACE'','' USP_RAW_ORDER_DATA_CLEANUP has been Completed'');

RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    SYSTEM$LOG(''ERROR'','' SP_INSERTCUSTOMERADDRESSDETAILS has Failed'');

	RETURN sqlerrm;
END';

CREATE PROCEDURE "USP_VALIDATE_ARCHIVE_TABLE"("RAWTABLENAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    tableExists NUMBER DEFAULT 0;
    archiveTableName STRING;
    rawCompleteName STRING;
    completeArchiveTableName STRING;
    schemaValid BOOLEAN;
BEGIN
    archiveTableName := ''ARC_'' || rawTableName;

    tableExists := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = UPPER(:archiveTableName));
    
    completeArchiveTableName := ''ARCHIVE.ARC_'' || rawTableName;

    rawCompleteName := ''RAW.'' || rawTableName;
    
    IF (tableExists = 0) THEN
        CREATE TABLE IDENTIFIER(:completeArchiveTableName) AS SELECT * FROM IDENTIFIER(:rawCompleteName) WHERE 1 = 0;
        ALTER TABLE IDENTIFIER(:completeArchiveTableName) ADD COLUMN archived_date TIMESTAMP;
    END IF;
    
RETURN UPPER(:archiveTableName);
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_VALIDATE_ARCHIVE_TABLE_SCHEMA"("SOURCETABLENAME" VARCHAR(16777216), "DESTINATIONTABLENAME" VARCHAR(16777216))
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    sourceColumnCount INT;
    destinationColumnCount INT;
    sourceColumns ARRAY;
    destinationColumns ARRAY;
    schemaMatch BOOLEAN;
BEGIN
    schemaMatch := FALSE;

    BEGIN
        sourceColumnCount := (SELECT COUNT(*)
                              FROM INFORMATION_SCHEMA.COLUMNS
                              WHERE TABLE_NAME = :sourceTableName);

        destinationColumnCount := (SELECT COUNT(*)
                                   FROM INFORMATION_SCHEMA.COLUMNS
                                    WHERE TABLE_NAME = :destinationTableName);
    IF (sourceColumnCount + 1 = destinationColumnCount) THEN
        IF (NOT EXISTS (
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = UPPER(:sourceTableName) AND COLUMN_NAME != UPPER(''archived_date'')
            MINUS
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = UPPER(:destinationTableName) AND COLUMN_NAME != UPPER(''archived_date'')
        ) AND NOT EXISTS (
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = UPPER(:destinationTableName) AND COLUMN_NAME != UPPER(''archived_date'')
            MINUS
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = UPPER(:sourceTableName) AND COLUMN_NAME != UPPER(''archived_date'')
        )) THEN
            schemaMatch := TRUE; -- Schemas match (excluding ''archived_date'')
        ELSE
            schemaMatch := FALSE; -- Schemas don''t match
        END IF;
    ELSE 
        schemaMatch := FALSE;
    END IF; 

    RETURN schemaMatch;
    EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
    END;
END';
CREATE PROCEDURE "USP_VALIDATE_ARCHIVE_TABLE_SCHEMA"("SOURCETABLENAME" VARCHAR(16777216), "DESTINATIONTABLENAME" VARCHAR(16777216), "SCHEMAMATCH" BOOLEAN)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    sourceColumnCount INT;
    destinationColumnCount INT;
    sourceColumns ARRAY;
    destinationColumns ARRAY;
BEGIN
    schemaMatch := FALSE;

    BEGIN
        sourceColumnCount := (SELECT COUNT(*)
                              FROM INFORMATION_SCHEMA.COLUMNS
                              WHERE TABLE_NAME = :sourceTableName);

        destinationColumnCount := (SELECT COUNT(*)
                                   FROM INFORMATION_SCHEMA.COLUMNS
                                    WHERE TABLE_NAME = :destinationTableName);
    IF (sourceColumnCount + 1 = destinationColumnCount) THEN
        schemaMatch := TRUE;
    END IF; 

    RETURN schemaMatch;
    EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
    END;
END';
CREATE PROCEDURE "USP_VALIDATE_RAW_TABLE_DATA_CLEANUP_BY_PRIMARY_KEY"("TABLE_NAME" VARCHAR(16777216), "PRIMARY_KEY_COLUMN" VARCHAR(16777216))
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    is_unique BOOLEAN DEFAULT TRUE;
    query_text STRING; 
    record_count INT;
    complete_raw_name STRING;
BEGIN
    complete_raw_name := ''RAW.'' || table_name;
    record_count := (
        SELECT COUNT(*)
        FROM (
            SELECT UPPER(IDENTIFIER(:primary_key_column)), modifyts, txn_id, COUNT(*)
            FROM IDENTIFIER(:complete_raw_name)
            GROUP BY UPPER(IDENTIFIER(:primary_key_column)), modifyts, txn_id
            HAVING COUNT(*) > 1
        ) AS T
    );

    IF (record_count > 0) THEN
        is_unique := FALSE;
    END IF;
    
    RETURN is_unique;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_VALIDATE_UPDATE_ORDER_RELEASE_STATUS"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1300'' WHERE STATUS = ''1300.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1500'' WHERE STATUS = ''1500.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3700.300'' WHERE STATUS = ''3700.3'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1100'' WHERE STATUS = ''1100.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''_1500'' WHERE STATUS = ''_1500.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3200'' WHERE STATUS = ''3200.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3700'' WHERE STATUS = ''3700.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3350'' WHERE STATUS = ''3350.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''9000'' WHERE STATUS = ''9000.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1400'' WHERE STATUS = ''1400.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''_1400'' WHERE STATUS = ''_1400.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3950'' WHERE STATUS = ''3950.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3350'' WHERE STATUS = ''3350.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''_3350'' WHERE STATUS = ''_3350.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1300.100'' WHERE STATUS = ''1300.1'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1310'' WHERE STATUS = ''1310.0'';

UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1300'' WHERE STATUS = ''1300.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1500'' WHERE STATUS = ''1500.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3700.300'' WHERE STATUS = ''3700.3'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1100'' WHERE STATUS = ''1100.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''_1500'' WHERE STATUS = ''_1500.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3200'' WHERE STATUS = ''3200.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3700'' WHERE STATUS = ''3700.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3350'' WHERE STATUS = ''3350.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''9000'' WHERE STATUS = ''9000.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1400'' WHERE STATUS = ''1400.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''_1400'' WHERE STATUS = ''_1400.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3950'' WHERE STATUS = ''3950.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3350'' WHERE STATUS = ''3350.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''_3350'' WHERE STATUS = ''_3350.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1300.100'' WHERE STATUS = ''1300.1'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1310'' WHERE STATUS = ''1310.0'';

UPDATE raw.raw_ORDER_header SET order_status = ''1300'' WHERE order_status = ''1300.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''1500'' WHERE order_status = ''1500.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3700.300'' WHERE order_status = ''3700.3'';
UPDATE raw.raw_ORDER_header SET order_status = ''1100'' WHERE order_status = ''1100.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''_1500'' WHERE order_status = ''_1500.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3200'' WHERE order_status = ''3200.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3700'' WHERE order_status = ''3700.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3350'' WHERE order_status = ''3350.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''9000'' WHERE order_status = ''9000.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''1400'' WHERE order_status = ''1400.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''_1400'' WHERE order_status = ''_1400.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3950'' WHERE order_status = ''3950.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3350'' WHERE order_status = ''3350.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''_3350'' WHERE order_status = ''_3350.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''1300.100'' WHERE order_status = ''1300.1'';
UPDATE raw.raw_ORDER_header SET order_status = ''1310'' WHERE order_status = ''1310.0'';

 RETURN ''Success'';
END';

