use schema TRANSFORMED;

CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_ALLOCATION"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    finalStatus TEXT DEFAULT ''0''; 
    errorCount NUMBER DEFAULT 0;
    omsCount NUMBER DEFAULT 0;
    omsErrorCount NUMBER DEFAULT 0;
    dimErrorCount NUMBER DEFAULT 0;
    txnErrorCount NUMBER DEFAULT 0;
    invalidOrderStatus TEXT DEFAULT ''CHECKED_INVALID'';
BEGIN 
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_ALLOCATION has been Started'');

CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog (
   orderheaderkey STRING,
   order_release_key STRING,  
   txn_id STRING,
   processing_errortype STRING,
   processing_status STRING,
   processing_comment STRING
);

CREATE OR REPLACE TEMPORARY TABLE DimResultToLog (
   order_header_key STRING,  
   order_release_key STRING,  
   pk_order_headerid STRING,  
   stgsource STRING,  
   sourceid STRING,   
   addressid STRING,
   txn_id STRING
);

SELECT COUNT(*)
INTO :omsCount 
FROM TRANSFORMED.stg_order_RELEASE;

LET orderErrorMsg := ''Order [ERRORITEM] not found in txn order'';
LET skuErrorMsg := ''Sku [ERRORITEM] not found'';
LET sourceErrorMsg := ''[ERRORITEM] for this brand and platform no source found'';
LET addressErrorMsg := ''Address [ERRORITEM] not found'';

IF (omsCount > 0) THEN 

BEGIN 

INSERT INTO DimResultToLog (order_header_key, order_release_key, pk_order_headerid, stgsource, sourceid, addressid, txn_id)
SELECT DISTINCT
    stg.order_header_key,
    stg.order_release_key,
    toh.pk_order_headerid,
    CAST(ANALYTICS.fun_get_edw_brand_by_order_sellerorgcode(roh.SELLER_ORGANIZATION_CODE) || ''&'' || COALESCE(ANALYTICS.fun_get_edw_platform_by_order_entrytype(roh.ENTRY_TYPE), '''') AS VARCHAR),
    src.pk_sourceid,
    ta.pk_addressid,
    stg.txn_id
FROM TRANSFORMED.stg_order_release AS stg
LEFT JOIN RAW.raw_order_header AS roh ON stg.order_header_key = roh.order_header_key AND stg.txn_id = roh.txn_id
LEFT JOIN (
    SELECT src.pk_sourceid, plt.platform_name, brd.BrandCodeForWHM, brd.context, src.locale
    FROM master.dim_source AS src
    INNER JOIN master.dim_platform AS plt ON plt.pk_platformid = src.fk_platformid
    INNER JOIN master.dim_brand AS brd ON brd.pk_brandid = src.fk_brandid
) AS src ON src.BrandCodeForWHM = ANALYTICS .fun_get_edw_brand_by_order_sellerorgcode(roh.SELLER_ORGANIZATION_CODE)
          AND src.platform_name = ANALYTICS.fun_get_edw_platform_by_order_entrytype(roh.ENTRY_TYPE)
LEFT JOIN ANALYTICS.txn_order_header AS toh ON toh.ext_order_id = stg.order_header_key
                                    AND src.pk_sourceid = toh.fk_sourceid
                                    AND toh.source_ref_num = roh.order_no
LEFT JOIN ANALYTICS.txn_address AS ta ON ta.ext_address_id = stg.ship_to_key;

-- First Insert Statement
INSERT INTO ErrorResultToLog 
  (orderheaderkey, order_release_key, txn_id, processing_errortype, processing_status, processing_comment)
SELECT DISTINCT
  roor.order_header_key,
  roor.order_release_key,
  dst.txn_id,
  ''Source'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:SourceErrorMsg,''[ERRORITEM]'',dst.stgsource) AS processing_comment
FROM RAW.raw_order_release AS roor
INNER JOIN DimResultToLog AS dst 
  ON roor.order_release_key = dst.order_release_key 
  AND roor.order_header_key = dst.order_header_key  
  AND roor.txn_id = dst.txn_id
WHERE dst.sourceid IS NULL 
  AND dst.stgsource IS NOT NULL 
  AND roor.processing_status IN (''Failed'', ''Pending'');

-- Second Insert Statement
INSERT INTO ErrorResultToLog 
  (orderheaderkey, order_release_key, txn_id, processing_errortype, processing_status, processing_comment)
SELECT DISTINCT
  roor.order_header_key,
  roor.order_release_key,
  roor.txn_id,
  ''Order'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:OrderErrorMsg,''[ERRORITEM]'',roor.order_header_key) AS processing_comment
FROM RAW.raw_order_release AS roor
INNER JOIN DimResultToLog AS dst 
  ON roor.order_release_key = dst.order_release_key 
  AND roor.order_header_key = dst.order_header_key  
  AND roor.txn_id = dst.txn_id
WHERE dst.pk_order_headerid IS NULL 
  AND dst.order_header_key IS NOT NULL 
  AND roor.processing_status IN (''Failed'', ''Pending'');

-- Third Insert Statement
INSERT INTO ErrorResultToLog 
  (orderheaderkey, order_release_key, txn_id, processing_errortype, processing_status, processing_comment)
SELECT DISTINCT
  roor.order_header_key,
  roor.order_release_key,
  roor.txn_id,
  ''ShiptoAddress'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:AddressErrorMsg,''[ERRORITEM]'',roor.ship_to_key) AS processing_comment
FROM RAW.raw_order_release AS roor
INNER JOIN DimResultToLog AS dst 
  ON roor.order_release_key = dst.order_release_key 
  AND roor.order_header_key = dst.order_header_key  
  AND roor.txn_id = dst.txn_id
WHERE dst.addressid IS NULL 
  AND dst.order_header_key IS NOT NULL 
  AND roor.processing_status IN (''Failed'', ''Pending'');

UPDATE RAW.raw_order_release raw
SET 
  raw.processing_errortype = (
    SELECT LISTAGG(temp2.processing_errortype, '','') WITHIN GROUP (ORDER BY temp2.processing_errortype)
    FROM ErrorResultToLog temp2
    WHERE temp2.txn_id = raw.txn_id 
      AND temp2.orderheaderkey = raw.order_HEADER_KEY 
      AND temp2.order_release_key = raw.order_release_key
      AND temp2.processing_status IN (''Failed'')
  ),
  raw.processing_comment = (
    SELECT LISTAGG(temp2.processing_comment, '','') WITHIN GROUP (ORDER BY temp2.processing_comment)
    FROM ErrorResultToLog temp2
    WHERE temp2.txn_id = raw.txn_id 
      AND temp2.orderheaderkey = raw.order_HEADER_KEY 
      AND temp2.order_release_key = raw.order_release_key
      AND temp2.processing_status IN (''Failed'')
  ),
  raw.processing_status = ''Failed''
WHERE EXISTS (
  SELECT 1
  FROM ErrorResultToLog temp2
  WHERE temp2.txn_id = raw.txn_id 
    AND temp2.orderheaderkey = raw.order_HEADER_KEY 
    AND temp2.order_release_key = raw.order_release_key
    AND temp2.processing_status IN (''Failed'')
)
AND raw.processing_status IN (''Failed'', ''Pending'');

MERGE INTO RAW.raw_order_release AS roor
USING (
    SELECT distinct order_header_key, order_release_key, txn_id
    FROM DimResultToLog
    WHERE sourceid IS NOT NULL
      AND stgsource IS NOT NULL
      AND pk_order_headerid IS NOT NULL
      AND order_header_key IS NOT NULL
      AND addressid IS NOT NULL
) AS dst
ON roor.order_release_key = dst.order_release_key
   AND roor.order_header_key = dst.order_header_key
   AND roor.txn_id = dst.txn_id
WHEN MATCHED AND roor.processing_status IN (''Failed'', ''Pending'') THEN
  UPDATE SET
    roor.processing_errortype = '''',
    roor.processing_comment = ''Ready For Processing'';

-- Delete rows from stg_order_release based on conditions in raw_order_release
DELETE FROM TRANSFORMED.stg_order_release
WHERE (order_header_key, order_release_key, txn_id) IN (
    SELECT soor.order_header_key, soor.order_release_key, soor.txn_id
    FROM TRANSFORMED.stg_order_release AS soor
    INNER JOIN (
        SELECT order_release_key, order_header_key, txn_id, processing_errortype
        FROM RAW.raw_order_release 
        WHERE processing_status IN (''Failed'', ''Pending'')
    ) AS dt 
    ON dt.order_header_key = soor.order_header_key 
    AND dt.order_release_key = soor.order_release_key 
    AND dt.txn_id = soor.txn_id
    WHERE dt.processing_errortype != '''' AND dt.processing_errortype IS NOT NULL
);

SELECT COUNT(*)
INTO :errorCount 
FROM RAW.raw_order_release
WHERE processing_status = ''Failed'';
;

IF(ErrorCount > 0) THEN
BEGIN 
    finalStatus := ''er_records'';
END;
ELSE 
    finalStatus := ''isSuccessful'';
END IF;

END; 
END IF;

IF (omsCount = 0) THEN 
BEGIN
finalStatus := ''no_records'';
END;
END IF;
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_ALLOCATION has been Completed'');
RETURN finalStatus;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_ALLOCATION has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_HEADER"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    OrderNoErrorMsg STRING;
    SourceRefErrorMsg STRING;
    OrderErrorMsg STRING;
    SkuErrorMsg STRING;
    PlatformErrorMsg STRING;
    BrandErrorMsg STRING;
    SourceErrorMsg STRING;
    CurrencyErrorMsg STRING;
    CustomerErrorMsg STRING;
    ShippingMethodErrorMsg STRING;
    OrderStatusErrorMsg STRING;
    PaymentMethodErrorMsg STRING;
    OrderTypeErrorMsg STRING;
    EditSourceRefErrorMsg STRING;
    PersonInfoErrorMsg STRING;
    message STRING(1000);       
    ErrorCount INT;
    StageErrorCount INT;       
    DimErrorCount INT;  
    TxnErrorCount INT;       
    action STRING;
    amendment_topic STRING;   
    amendment_note STRING;  
    domesticSource STRING DEFAULT ''domestic''; 
    internationalSource STRING DEFAULT ''international''; 
    OMSOrderCount INT;
    OMSErrorOrderCount INT;
    InvalidOrderStatus STRING DEFAULT ''CHECKED_INVALID'';  
    StagingRecordCount INT;      
    FinalStatus STRING;    
    DataValidationErrCount INT;   
    OrderTypeCount INT;  
BEGIN

SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_HEADER has been Started'');

action := ''CREATE'';

-- Create temporary table for ErrorResultToLog
CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog
(
    orderheaderkey STRING,
    orderno STRING,
    txn_id STRING,
    processing_errortype STRING,
    processing_status STRING,
    processing_comment STRING
);

-- Create temporary table for DimResultToLog
CREATE OR REPLACE TEMPORARY TABLE DimResultToLog
(
    modifieddate STRING,
    orderheaderkey STRING,
    orderno STRING,
    stg_enterprisekey STRING,
    stg_ENTRY_TYPE STRING,
    stgsource STRING,
    sourceid STRING,
    stgcurrency STRING,
    currencyid STRING,
    stgcustomer STRING,
    customerid STRING,
    stgshippingmethod STRING,
    shippingmethodid STRING,
    stgdoctype INT NOT NULL,
    stgorderstatus STRING,
    orderstatusid STRING,
    stgordertype STRING,
    ordertypeid STRING,
    stgshippid STRING,
    pk_shippid STRING,
    stgbillid STRING,
    pk_billid STRING,
    txn_id STRING
);

-- Create temporary table for TxnResultToLog
CREATE OR REPLACE TEMPORARY TABLE TxnResultToLog
(
    stgsourceref STRING,
    stgorderstaus STRING,
    stgjoinsourceref STRING,
    headsourceref STRING
);

-- Set value to FinalStatus
FinalStatus := ''val_records'';

SELECT COUNT(*)
INTO :omsOrderCount
FROM TRANSFORMED.STG_ORDER_header;

OrderNoErrorMsg := ''OrderNo for [ERRORSOURCE] Header_Key is not found'';
SourceErrorMsg := ''[ERRORITEM] for this brand and platform no source found'';
CurrencyErrorMsg := ''Currency [ERRORITEM] not found'';
CustomerErrorMsg := ''Customer [ERRORITEM] not found'';
PersonInfoErrorMsg := ''Person Info [ERRORITEM] not found'';
ShippingMethodErrorMsg := ''Shipping Method [ERRORITEM] not found'';
OrderStatusErrorMsg := ''Order Status [ERRORITEM] not found'';
OrderTypeErrorMsg := ''Order Type [ERRORITEM] not found'';
EditSourceRefErrorMsg := ''SourceRefNum [ERRORITEM] have no records for modification'';
PlatformErrorMsg := ''Platform [ERRORITEM] not found'';
BrandErrorMsg := ''Brand [ERRORITEM] not found'';
SourceRefErrorMsg := ''SourceRefNum [ERRORSOURCE] not found'';
OrderErrorMsg := ''OrderId [ERRORORDERID] not found'';
SkuErrorMsg := ''SKU [ERRORITEM] not found'';
PaymentMethodErrorMsg := ''Payment Method [ERRORITEM] not found'';

IF (omsOrderCount > 0) THEN 
BEGIN 

-- Inserting validation related to the dimension table
INSERT INTO DimResultToLog
SELECT DISTINCT
    stg.MODIFYTS,
    stg.ORDER_HEADER_KEY,
    stg.ORDER_NO,
    ANALYTICS.fun_get_edw_brand_by_order_sellerorgcode(stg.SELLER_ORGANIZATION_CODE),
    stg.ENTRY_TYPE,
    CONCAT_WS(''&'', 
              NVL(ANALYTICS.fun_get_edw_brand_by_order_sellerorgcode(stg.SELLER_ORGANIZATION_CODE), ''''), 
              NVL(pl.platform_name, '''')) AS stgsource,
    src.pk_sourceid,
    stg.currency,
    cur.pk_currencyid,
    stg.EXTN_CUSTOMER_ID,
    cus.pk_customerid,
    stg.LEVEL_OF_SERVICE,
    ship.pk_shipping_methodid,
    stg.document_type,
    stg.order_status,
    ordst.pk_order_statusid,
    stg.ORDER_TYPE,
    ordtype.pk_order_typeid,
    stg.SHIP_TO_KEY,
    shipaddr.pk_addressid,
    stg.BILL_TO_KEY,
    billaddr.pk_addressid,
    stg.txn_id
FROM TRANSFORMED.STG_ORDER_header AS stg
LEFT JOIN master.entrytype_platform_map AS pl 
    ON pl.entry_type = stg.ENTRY_TYPE 
    AND pl.Order_Type = stg.Order_Type
LEFT JOIN master.source_brand_platform_map AS src 
    ON src.BrandCodeForWHM =  ANALYTICS.fun_get_edw_brand_by_order_sellerorgcode(stg.SELLER_ORGANIZATION_CODE) 
    AND src.PlatformName = NVL(pl.customer_platform_name, pl.platform_name)
LEFT JOIN master.dim_currency AS cur 
    ON stg.currency = cur.currency_code
-- LEFT JOIN ANALYTICS.customer AS cus 
--     ON ((cus.source_ref_num = stg.EXTN_CUSTOMER_ID 
--         AND cus.fk_sourceid = src.pk_sourceid)
--     OR (cus.source_ref_num = stg.EXTN_CUSTOMER_ID 
--         AND stg.entry_type = ''Call Center'' 
--         AND stg.Order_Type = ''WARRANTY''))
LEFT JOIN ANALYTICS.customer AS cus 
    ON cus.source_ref_num = stg.EXTN_CUSTOMER_ID 
    AND (cus.fk_sourceid = src.pk_sourceid 
         OR (stg.entry_type = ''Call Center'' AND stg.Order_Type = ''WARRANTY''))

LEFT JOIN master.dim_shipping_method AS ship 
    ON ((UPPER(ship.shipping_method_name) = UPPER(stg.LEVEL_OF_SERVICE))
    OR (UPPER(ship.shipping_method_name) = UPPER(''CC_Return_Order'') 
        AND stg.document_type = 3)
    OR (stg.LEVEL_OF_SERVICE IS NULL 
        AND UPPER(ship.shipping_method_name) = ''NA'' 
        AND stg.Order_Type = ''WARRANTY'' 
        AND stg.entry_type = ''Call Center'' 
        AND stg.document_type = 1))
LEFT JOIN  master.dim_order_type AS ordtype 
    ON stg.ORDER_TYPE = ordtype.order_type_name
LEFT JOIN  master.dim_order_status AS ordst 
    ON stg.order_status = ordst.oms_order_status_code
LEFT JOIN ANALYTICS.txn_address AS shipaddr 
    ON CAST(shipaddr.ext_address_id AS STRING) = CAST(stg.SHIP_TO_KEY AS STRING)
LEFT JOIN ANALYTICS.txn_address AS billaddr 
    ON CAST(billaddr.ext_address_id AS STRING) = CAST(stg.BILL_TO_KEY AS STRING);

INSERT INTO ErrorResultToLog (
  orderheaderkey,  
  orderno, 
  txn_id,
  processing_errortype,
  processing_status,
  processing_comment
)
SELECT DISTINCT
  roh.ORDER_HEADER_KEY,
  roh.order_no,
  dst.txn_id,
  ''Source'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:SourceErrorMsg, ''[ERRORITEM]'', dst.stgsource) AS processing_comment
FROM RAW.RAW_ORDER_header AS roh
INNER JOIN DimResultToLog AS dst 
  ON roh.order_no = dst.orderno 
  AND roh.ORDER_HEADER_KEY = dst.orderheaderkey  
  AND roh.txn_id = dst.txn_id
WHERE dst.sourceid IS NULL 
  AND dst.stgsource IS NOT NULL 
  AND roh.processing_status IN (''Failed'', ''Pending'');

INSERT INTO ErrorResultToLog (
  orderheaderkey,  
  orderno, 
  txn_id,
  processing_errortype,
  processing_status,
  processing_comment
)
SELECT DISTINCT
  roh.ORDER_HEADER_KEY,
  roh.order_no,
  dst.txn_id,
  ''Currency'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:CurrencyErrorMsg, ''[ERRORITEM]'', dst.stgcurrency) AS processing_comment
FROM RAW.RAW_ORDER_header AS roh
INNER JOIN DimResultToLog AS dst 
  ON roh.order_no = dst.orderno 
  AND roh.ORDER_HEADER_KEY = dst.orderheaderkey  
  AND roh.txn_id = dst.txn_id
WHERE dst.currencyid IS NULL
  AND roh.processing_status IN (''Failed'', ''Pending'');

INSERT INTO ErrorResultToLog (
  orderheaderkey,  
  orderno, 
  txn_id,
  processing_errortype,
  processing_status,
  processing_comment
)
SELECT DISTINCT
  roh.ORDER_HEADER_KEY,
  roh.order_no,
  dst.txn_id,
  ''Customer'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:CustomerErrorMsg, ''[ERRORITEM]'', dst.stgcustomer) AS processing_comment
FROM RAW.RAW_ORDER_header AS roh
INNER JOIN DimResultToLog AS dst 
  ON roh.order_no = dst.orderno 
  AND roh.ORDER_HEADER_KEY = dst.orderheaderkey  
  AND roh.txn_id = dst.txn_id
WHERE dst.customerid IS NULL
  AND roh.processing_status IN (''Failed'', ''Pending'');

-- Define the ShippingMethodErrorMsg variable
ShippingMethodErrorMsg := ''Shipping Method [ERRORITEM] not found'';

-- Insert data into ErrorResultToLog
INSERT INTO ErrorResultToLog (
  orderheaderkey,  
  orderno, 
  txn_id,
  processing_errortype,
  processing_status,
  processing_comment
)
SELECT DISTINCT
  roh.ORDER_HEADER_KEY,
  roh.order_no,
  dst.txn_id,
  ''Shipping Method'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:ShippingMethodErrorMsg, ''[ERRORITEM]'', dst.stgshippingmethod) AS processing_comment
FROM RAW.RAW_ORDER_header AS roh
INNER JOIN DimResultToLog AS dst 
  ON roh.order_no = dst.orderno 
  AND roh.ORDER_HEADER_KEY = dst.orderheaderkey  
  AND roh.txn_id = dst.txn_id
WHERE dst.shippingmethodid IS NULL
  AND roh.processing_status IN (''Failed'', ''Pending'');

INSERT INTO ErrorResultToLog (
  orderheaderkey,  
  orderno, 
  txn_id,
  processing_errortype,
  processing_status,
  processing_comment
)
SELECT DISTINCT
  roh.ORDER_HEADER_KEY,
  roh.order_no,
  dst.txn_id,
  ''Order Status'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:OrderStatusErrorMsg, ''[ERRORITEM]'', dst.stgorderstatus) AS processing_comment
FROM RAW.RAW_ORDER_header AS roh
INNER JOIN DimResultToLog AS dst 
  ON roh.order_no = dst.orderno 
  AND roh.ORDER_HEADER_KEY = dst.orderheaderkey  
  AND roh.txn_id = dst.txn_id
WHERE dst.orderstatusid IS NULL 
  AND (dst.stgorderstatus IS NOT NULL OR dst.stgorderstatus <> '''')  
  AND roh.processing_status IN (''Failed'', ''Pending'');

-- Insert Order Type Errors
INSERT INTO ErrorResultToLog (
  orderheaderkey,  
  orderno, 
  txn_id,
  processing_errortype,
  processing_status,
  processing_comment
)
SELECT DISTINCT
  roh.ORDER_HEADER_KEY,
  roh.order_no,
  dst.txn_id,
  ''Order Type'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:OrderTypeErrorMsg, ''[ERRORITEM]'', dst.stgordertype) AS processing_comment
FROM RAW.RAW_ORDER_header AS roh
INNER JOIN DimResultToLog AS dst 
  ON roh.order_no = dst.orderno 
  AND roh.ORDER_HEADER_KEY = dst.orderheaderkey
  AND roh.txn_id = dst.txn_id
WHERE dst.ordertypeid IS NULL
  AND roh.processing_status IN (''Failed'', ''Pending'');

-- Insert Shipping Person Info Errors
INSERT INTO ErrorResultToLog (
  orderheaderkey,  
  orderno, 
  txn_id,
  processing_errortype,
  processing_status,
  processing_comment
)
SELECT DISTINCT
  roh.ORDER_HEADER_KEY,
  roh.order_no,
  dst.txn_id,
  ''Ship Person Info'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:PersonInfoErrorMsg, ''[ERRORITEM]'', dst.stgshippid) AS processing_comment
FROM RAW.RAW_ORDER_header AS roh
INNER JOIN DimResultToLog AS dst 
  ON roh.order_no = dst.orderno 
  AND roh.ORDER_HEADER_KEY = dst.orderheaderkey
  AND roh.txn_id = dst.txn_id
WHERE dst.pk_shippid IS NULL
  AND roh.processing_status IN (''Failed'', ''Pending'');

-- Insert Billing Person Info Errors
INSERT INTO ErrorResultToLog (
  orderheaderkey,  
  orderno, 
  txn_id,
  processing_errortype,
  processing_status,
  processing_comment
)
SELECT DISTINCT
  roh.ORDER_HEADER_KEY,
  roh.order_no,
  dst.txn_id,
  ''Bill Person Info'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:PersonInfoErrorMsg, ''[ERRORITEM]'', dst.stgbillid) AS processing_comment
FROM RAW.RAW_ORDER_header AS roh
INNER JOIN DimResultToLog AS dst 
  ON roh.order_no = dst.orderno 
  AND roh.ORDER_HEADER_KEY = dst.orderheaderkey
  AND roh.txn_id = dst.txn_id
WHERE dst.pk_billid IS NULL
  AND roh.processing_status IN (''Failed'', ''Pending'');

-- Insert Brand Errors
INSERT INTO ErrorResultToLog (
  orderheaderkey,  
  orderno, 
  txn_id,
  processing_errortype,
  processing_status,
  processing_comment
)
SELECT DISTINCT
  roh.ORDER_HEADER_KEY,
  roh.order_no,
  roh.txn_id,
  ''Brand'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:BrandErrorMsg, ''[ERRORITEM]'', ''Null/Blank'') AS processing_comment
FROM RAW.RAW_ORDER_header AS roh
WHERE roh.SELLER_ORGANIZATION_CODE IS NULL
  AND roh.processing_status IN (''Failed'', ''Pending'');

-- Insert Platform Errors
INSERT INTO ErrorResultToLog (
  orderheaderkey,  
  orderno, 
  txn_id,
  processing_errortype,
  processing_status,
  processing_comment
)
SELECT DISTINCT
  roh.ORDER_HEADER_KEY,
  roh.order_no,
  roh.txn_id,
  ''Platform'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:PlatformErrorMsg, ''[ERRORITEM]'', ''Null/Blank'') AS processing_comment
FROM RAW.RAW_ORDER_header AS roh
WHERE roh.ENTRY_TYPE IS NULL
  AND roh.processing_status IN (''Failed'', ''Pending'');

-- Insert Order Number Errors
INSERT INTO ErrorResultToLog (
  orderheaderkey,  
  orderno, 
  txn_id,
  processing_errortype,
  processing_status,
  processing_comment
)
SELECT DISTINCT
  roh.ORDER_HEADER_KEY,
  roh.order_no,
  roh.txn_id,
  ''Order_No'' AS processing_errortype,
  ''Failed'' AS processing_status,
  REPLACE(:OrderNoErrorMsg || '' in raw order header'', ''[ERRORSOURCE]'', roh.order_header_key) AS processing_comment
FROM RAW.RAW_ORDER_header AS roh
WHERE (roh.order_no IS NULL OR roh.order_no = '''')
  AND roh.processing_status IN (''Failed'', ''Pending'');

-- UPDATE RAW.RAW_ORDER_HEADER roh
-- SET processing_errortype = (
--     SELECT LISTAGG(temp2.processing_errortype, '','') WITHIN GROUP (ORDER BY temp2.processing_errortype)
--     FROM (
--         SELECT t2.processing_errortype
--         FROM ErrorResultToLog t2
--         WHERE t2.processing_status = ''Failed''
--           AND t2.txn_id = roh.txn_id
--           AND t2.orderheaderkey = roh.ORDER_HEADER_KEY
--           AND t2.orderno = roh.ORDER_NO
--     ) temp2
-- ),
-- processing_comment = (
--     SELECT LISTAGG(temp2.processing_comment, '','') WITHIN GROUP (ORDER BY temp2.processing_comment)
--     FROM (
--         SELECT t2.processing_comment
--         FROM ErrorResultToLog t2
--         WHERE t2.processing_status = ''Failed''
--           AND t2.txn_id = roh.txn_id
--           AND t2.orderheaderkey = roh.ORDER_HEADER_KEY
--           AND t2.orderno = roh.ORDER_NO
--     ) temp2
-- ),
-- processing_status = ''Failed''
-- FROM RAW.RAW_ORDER_HEADER
-- WHERE roh.processing_status IN (''Failed'', ''Pending'')
--   AND EXISTS (
--     SELECT 1
--     FROM ErrorResultToLog t1
--     WHERE t1.processing_status = ''Failed''
--       AND t1.txn_id = roh.txn_id
--       AND t1.orderheaderkey = roh.ORDER_HEADER_KEY
--       AND t1.orderno = roh.ORDER_NO
--   );

MERGE INTO RAW.RAW_ORDER_HEADER AS roh
USING (
    SELECT 
        t2.txn_id,
        t2.orderheaderkey,
        t2.orderno,
        LISTAGG(t2.processing_errortype, '','') WITHIN GROUP (ORDER BY t2.processing_errortype) AS aggregated_errortype,
        LISTAGG(t2.processing_comment, '','') WITHIN GROUP (ORDER BY t2.processing_comment) AS aggregated_comment
    FROM ErrorResultToLog t2
    WHERE t2.processing_status = ''Failed''
    GROUP BY t2.txn_id, t2.orderheaderkey, t2.orderno
) AS ed
ON roh.txn_id = ed.txn_id
   AND roh.ORDER_HEADER_KEY = ed.orderheaderkey
   AND roh.ORDER_NO = ed.orderno
   AND roh.processing_status IN (''Failed'', ''Pending'')
WHEN MATCHED THEN
    UPDATE SET 
        roh.processing_errortype = ed.aggregated_errortype,
        roh.processing_comment = ed.aggregated_comment,
        roh.processing_status = ''Failed'';


UPDATE RAW.RAW_ORDER_HEADER roh
SET roh.processing_errortype = '''',
    roh.processing_comment = ''Ready For Processing''

from  DimResultToLog dst where  roh.order_no = dst.orderno
                               AND roh.txn_id = dst.txn_id
                               AND roh.ORDER_HEADER_KEY = dst.orderheaderkey
and dst.sourceid IS NOT NULL
  AND dst.currencyid IS NOT NULL
  AND dst.customerid IS NOT NULL
  AND dst.shippingmethodid IS NOT NULL
  AND dst.orderstatusid IS NOT NULL
  AND (dst.stgorderstatus IS NOT NULL OR dst.stgorderstatus <> '''')
  AND dst.ordertypeid IS NOT NULL
  AND dst.pk_shippid IS NOT NULL
  AND dst.pk_billid IS NOT NULL
  AND roh.order_no IS NOT NULL
  AND roh.SELLER_ORGANIZATION_CODE IS NOT NULL
  AND roh.ENTRY_TYPE IS NOT NULL
  AND roh.processing_status IN (''Failed'', ''Pending'');


SELECT COUNT(*)
INTO :errorCount 
FROM RAW.RAW_ORDER_header
WHERE processing_status = ''Failed'';
;

IF(ErrorCount > 0) THEN
BEGIN 
    finalStatus := ''er_records'';
END;
ELSE 
    finalStatus := ''isSuccessful'';
END IF;

END;
END IF;

IF (omsOrderCount = 0) THEN 
BEGIN
finalStatus := ''no_records'';
END;
END IF;
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_HEADER has been Completed'');

RETURN finalStatus;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_HEADER has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_HEADER_CHARGES"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE

OrderErrorMsg STRING(100);
SkuErrorMsg STRING(100);
ChargeErrorMsg STRING(100);
SourceErrorMsg STRING(100);

message STRING(1000);
FinalStatus STRING(100) DEFAULT ''0'';
ErrorCount INT;
OMSCount INT;
OMSErrorCount INT;        
DimErrorCount INT;
TxnErrorCount INT;      
InvalidOrderStatus STRING DEFAULT ''CHECKED_INVALID'';

BEGIN
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_HEADER_CHARGES has been Started'');
CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog (
    orderheaderkey STRING,
    header_charges_key STRING,
    txn_id STRING,
    processing_errortype STRING,
    processing_status STRING,
    processing_comment STRING
);

CREATE OR REPLACE TEMPORARY TABLE DimResultToLog (
    header_key STRING,
    header_charges_key STRING,
    pk_order_headerid STRING,
    charge_category STRING,
    pk_chargecategory_typeid STRING,
    stgsource STRING,
    sourceid STRING,
    txn_id STRING
);

SELECT COUNT(*)
INTO :omsCount
FROM TRANSFORMED.STG_ORDER_header_charges;

OrderErrorMsg := ''Order [ERRORITEM] not found in txn order'';
SkuErrorMsg := ''Sku [ERRORITEM] not found'';
SourceErrorMsg := ''[ERRORITEM] for this brand and platform no source found'';
ChargeErrorMsg := ''Charge Category [ERRORITEM] not found'';


IF (omsCount > 0) THEN 
BEGIN 

INSERT INTO DimResultToLog (header_key ,
    header_charges_key ,
    pk_order_headerid ,
    charge_category ,
    pk_chargecategory_typeid ,
    stgsource ,
    sourceid ,
    txn_id )
SELECT DISTINCT
    stg.header_key,
    stg.header_charges_key,
    toh.pk_order_headerid,
    stg.charge_category,
    dc.pk_chargecategory_typeid,
    toh.entry_type,
    toh.fk_sourceid,
    stg.txn_id
FROM TRANSFORMED.STG_ORDER_header_charges AS stg
LEFT JOIN ANALYTICS.txn_order_header AS toh
    ON toh.order_header_key = stg.header_key
    AND toh.entry_type IS NOT NULL
LEFT JOIN master.dim_chargecategory AS dc
    ON dc.charge_category = stg.charge_category
    AND dc.charge IN (''FEE'', ''DISCOUNT'');

INSERT INTO ErrorResultToLog (orderheaderkey, header_charges_key, txn_id, processing_errortype, processing_status, processing_comment)
SELECT DISTINCT
    rolg.header_key,
    rolg.header_charges_key,
    rolg.txn_id,
    ''Order'' AS processing_errortype,
    ''Failed'' AS processing_status,
    REPLACE(:SourceErrorMsg, ''[ERRORITEM]'', rolg.header_key) AS processing_comment
FROM RAW.RAW_ORDER_header_charges AS rolg
INNER JOIN DimResultToLog AS dst
    ON rolg.header_charges_key = dst.header_charges_key
    AND rolg.header_key = dst.header_key
    AND rolg.txn_id = dst.txn_id
WHERE dst.pk_order_headerid IS NULL
    AND dst.header_key IS NOT NULL
    AND rolg.processing_status IN (''Failed'', ''Pending'');

INSERT INTO ErrorResultToLog (orderheaderkey, header_charges_key, txn_id, processing_errortype, processing_status, processing_comment)
SELECT DISTINCT
    rolg.header_key,
    rolg.header_charges_key,
    rolg.txn_id,
    ''Order'' AS processing_errortype,
    ''Failed'' AS processing_status,
    REPLACE(:OrderErrorMsg, ''[ERRORITEM]'', rolg.header_key) AS processing_comment
FROM RAW.RAW_ORDER_header_charges AS rolg
INNER JOIN DimResultToLog AS dst
    ON rolg.header_charges_key = dst.header_charges_key
    AND rolg.header_key = dst.header_key
    AND rolg.txn_id = dst.txn_id
WHERE dst.pk_order_headerid IS NULL
    AND dst.header_key IS NOT NULL
    AND rolg.processing_status IN (''Failed'', ''Pending'');

INSERT INTO ErrorResultToLog (orderheaderkey, header_charges_key, txn_id, processing_errortype, processing_status, processing_comment)
SELECT DISTINCT
    rolg.header_key,
    rolg.header_charges_key,
    rolg.txn_id,
    ''CHARGE CATEGORY'' AS processing_errortype,
    ''Failed'' AS processing_status,
    REPLACE(:ChargeErrorMsg, ''[ERRORITEM]'', rolg.charge_category) AS processing_comment
FROM RAW.RAW_ORDER_header_charges AS rolg
INNER JOIN DimResultToLog AS dst
    ON rolg.header_charges_key = dst.header_charges_key
    AND rolg.header_key = dst.header_key
    AND rolg.txn_id = dst.txn_id
WHERE dst.pk_chargecategory_typeid IS NULL
    AND dst.charge_category IS NOT NULL
    AND rolg.processing_status IN (''Failed'', ''Pending'');

-- Update the RAW_ORDER_header_charges table
MERGE INTO RAW.RAW_ORDER_header_charges AS raw
USING (
    SELECT
        temp1.orderheaderkey,
        temp1.header_charges_key,
        temp1.txn_id,
        LISTAGG(temp2.processing_errortype, '','') AS errortype,
        LISTAGG(temp2.processing_comment, '','') AS comment
    FROM (
        SELECT
            t1.header_charges_key,
            t1.orderheaderkey,
            t1.txn_id,
            t1.processing_comment,
            t1.processing_status
        FROM ErrorResultToLog t1
        WHERE t1.processing_status = ''Failed''
    ) temp1
    INNER JOIN ErrorResultToLog temp2 
        ON temp1.txn_id = temp2.txn_id
        AND temp1.orderheaderkey = temp2.orderheaderkey
        AND temp1.header_charges_key = temp2.header_charges_key
    GROUP BY temp1.orderheaderkey, temp1.header_charges_key, temp1.txn_id
) AS erlist
ON raw.txn_id = erlist.txn_id
   AND raw.header_key = erlist.orderheaderkey
   AND raw.header_charges_key = erlist.header_charges_key
   AND raw.processing_status IN (''Failed'', ''Pending'')
WHEN MATCHED THEN
UPDATE SET
    raw.processing_errortype = erlist.errortype,
    raw.processing_comment = erlist.comment,
    raw.processing_status = ''Failed'';


MERGE INTO RAW.RAW_ORDER_header_charges AS ROLG
USING DimResultToLog AS dst
ON ROLG.header_charges_key = dst.header_charges_key
   AND ROLG.header_key = dst.header_key
   AND ROLG.txn_id = dst.txn_id
   AND ROLG.processing_status IN (''Failed'', ''Pending'')
   AND dst.sourceid IS NOT NULL
   AND dst.stgsource IS NOT NULL
   AND dst.pk_order_headerid IS NOT NULL
   AND dst.header_key IS NOT NULL
   AND dst.pk_chargecategory_typeid IS NOT NULL
   AND dst.charge_category IS NOT NULL
WHEN MATCHED THEN
UPDATE SET
    ROLG.processing_errortype = '''',
    ROLG.processing_comment = ''Ready For Processing'';


DELETE FROM TRANSFORMED.STG_ORDER_header_charges AS sool
WHERE EXISTS (
    SELECT 1
    FROM RAW.RAW_ORDER_header_charges AS dt
    WHERE dt.HEADER_KEY = sool.HEADER_KEY
      AND dt.header_charges_key = sool.header_charges_key
      AND dt.txn_id = sool.txn_id
      AND dt.processing_status IN (''Failed'', ''Pending'')
      AND (dt.processing_errortype IS NOT NULL AND dt.processing_errortype != '''')
);

SELECT COUNT(*)
INTO :errorCount 
FROM RAW.RAW_ORDER_header_charges
WHERE processing_status = ''Failed'';
;

IF(ErrorCount > 0) THEN
BEGIN 
    finalStatus := ''er_records'';
END;
ELSE 
    finalStatus := ''isSuccessful'';
END IF;

END;
END IF;

IF (omsCount = 0) THEN 
BEGIN
finalStatus := ''no_records'';
END;
END IF;
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_HEADER_CHARGES has been Completed'');
RETURN finalStatus;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_HEADER_CHARGES has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_HEADER_TAX_BREAKUP"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
 OrderErrorMsg VARCHAR(100);
 ChargeErrorMsg VARCHAR(100);
 SourceErrorMsg VARCHAR(100);
 OrderLineErrorMsg VARCHAR(100);
 message VARCHAR(1000);
 FinalStatus VARCHAR(100) DEFAULT ''0'';
 ErrorCount INT;
 OMSCount INT;
 OMSErrorCount INT;
 DimErrorCount INT;
 TxnErrorCount INT;
BEGIN 
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_HEADER_TAX_BREAKUP has been Started'');
CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog (
    orderheaderkey STRING,
    TAX_BREAKUP_KEY STRING,
    txn_id STRING,
    processing_errortype STRING,
    processing_status STRING,
    processing_comment STRING
);

CREATE OR REPLACE TEMPORARY TABLE DimResultToLog (
    header_key STRING,
    TAX_BREAKUP_KEY STRING,
    pk_order_headerid STRING,
    charge_category STRING,
    pk_chargecategory_typeid STRING,
    stgsource STRING,
    sourceid STRING,
    txn_id STRING
);

SELECT COUNT(*)
INTO :omsCount
FROM TRANSFORMED.STG_ORDER_tax_breakup;

OrderErrorMsg := ''Order [ERRORITEM] not found in txn order'';
SourceErrorMsg := ''[ERRORITEM] for this brand and platform no source found'';
ChargeErrorMsg := ''Charge Category [ERRORITEM] not found'';

IF (omsCount > 0) THEN 
BEGIN 

INSERT INTO DimResultToLog
SELECT DISTINCT
    stg.header_key,
    stg.TAX_BREAKUP_KEY,
    toh.pk_order_headerid,
    stg.charge_category,
    dc.pk_chargecategory_typeid,
    toh.entry_type,
    toh.fk_sourceid,
    stg.txn_id
FROM TRANSFORMED.STG_ORDER_tax_breakup AS stg
LEFT JOIN ANALYTICS.txn_order_header AS toh
    ON toh.ext_order_id = stg.header_key
    AND toh.entry_type IS NOT NULL
LEFT JOIN master.dim_chargecategory AS dc
    ON dc.charge_category = stg.charge_category
    AND dc.charge = ''TAX''
WHERE stg.line_key IS NULL;

INSERT INTO ErrorResultToLog 
  (orderheaderkey,  
   TAX_BREAKUP_KEY, 
   txn_id,
   processing_errortype,
   processing_status,
   processing_comment)
SELECT DISTINCT
  rolg.header_key,
  rolg.TAX_BREAKUP_KEY,
  dst.txn_id,
  ''Source'',
  ''Failed'',
  REPLACE(:SourceErrorMsg, ''[ERRORITEM]'', stgsource)
FROM RAW.RAW_ORDER_tax_breakup AS rolg
INNER JOIN DimResultToLog AS dst
  ON rolg.TAX_BREAKUP_KEY = dst.TAX_BREAKUP_KEY
  AND rolg.header_key = dst.header_key
  AND rolg.txn_id = dst.txn_id
WHERE dst.sourceid IS NULL
  AND dst.stgsource IS NOT NULL
  AND processing_status IN (''Failed'', ''Pending'')
  AND rolg.line_key IS NULL;

INSERT INTO ErrorResultToLog 
  (orderheaderkey,  
   TAX_BREAKUP_KEY, 
   txn_id,
   processing_errortype,
   processing_status,
   processing_comment)
SELECT DISTINCT
  rolg.header_key,
  rolg.TAX_BREAKUP_KEY,
  rolg.txn_id,
  ''Order'',
  ''Failed'',
  REPLACE(:OrderErrorMsg, ''[ERRORITEM]'', rolg.header_key)
FROM RAW.RAW_ORDER_tax_breakup AS rolg
INNER JOIN DimResultToLog AS dst
  ON rolg.TAX_BREAKUP_KEY = dst.TAX_BREAKUP_KEY
  AND rolg.header_key = dst.header_key
  AND rolg.txn_id = dst.txn_id
WHERE dst.pk_order_headerid IS NULL
  AND dst.header_key IS NOT NULL
  AND processing_status IN (''Failed'', ''Pending'')
  AND rolg.line_key IS NULL;

INSERT INTO ErrorResultToLog 
  (orderheaderkey,  
   TAX_BREAKUP_KEY, 
   txn_id,
   processing_errortype,
   processing_status,
   processing_comment)
SELECT DISTINCT
  rolg.header_key,	
  rolg.TAX_BREAKUP_KEY,
  rolg.txn_id,
  ''CHARGE CATEGORY'',
  ''Failed'',
  REPLACE(:ChargeErrorMsg, ''[ERRORITEM]'', rolg.charge_category)
FROM RAW.RAW_ORDER_tax_breakup AS rolg
INNER JOIN DimResultToLog AS dst 
  ON rolg.TAX_BREAKUP_KEY = dst.TAX_BREAKUP_KEY 
  AND rolg.header_key = dst.header_key  
  AND rolg.txn_id = dst.txn_id
WHERE dst.pk_chargecategory_typeid IS NULL 
  AND dst.charge_category IS NOT NULL 
  AND processing_status IN (''Failed'', ''Pending'')  
  AND rolg.line_key IS NULL;

MERGE INTO RAW.RAW_ORDER_tax_breakup AS raw
USING (
    SELECT 
        t1.orderheaderkey, 
        t1.TAX_BREAKUP_KEY, 
        t1.txn_id, 
        LISTAGG(t2.processing_errortype, '','') WITHIN GROUP (ORDER BY t2.processing_errortype) AS errortype,
        LISTAGG(t2.processing_comment, '','') WITHIN GROUP (ORDER BY t2.processing_comment) AS comment
    FROM ErrorResultToLog t1
    INNER JOIN ErrorResultToLog t2 
        ON t1.txn_id = t2.txn_id 
        AND t1.orderheaderkey = t2.orderheaderkey 
        AND t1.TAX_BREAKUP_KEY = t2.TAX_BREAKUP_KEY
    WHERE t1.processing_status = ''Failed''
    GROUP BY t1.orderheaderkey, t1.TAX_BREAKUP_KEY, t1.txn_id
) AS erlist 
ON raw.txn_id = erlist.txn_id 
   AND raw.HEADER_KEY = erlist.orderheaderkey 
   AND raw.TAX_BREAKUP_KEY = erlist.TAX_BREAKUP_KEY
WHEN MATCHED AND raw.processing_status IN (''Failed'', ''Pending'')
  AND raw.line_key IS NULL THEN 
    UPDATE SET 
        raw.processing_errortype = erlist.errortype,
        raw.processing_comment = erlist.comment,
        raw.processing_status = ''Failed'';


MERGE INTO RAW.RAW_ORDER_tax_breakup AS rolg
USING DimResultToLog AS dst
ON rolg.TAX_BREAKUP_KEY = dst.TAX_BREAKUP_KEY
   AND rolg.header_key = dst.header_key
   AND rolg.txn_id = dst.txn_id
WHEN MATCHED 
  AND dst.sourceid IS NOT NULL 
  AND dst.stgsource IS NOT NULL
  AND dst.pk_order_headerid IS NOT NULL 
  AND dst.header_key IS NOT NULL
  AND rolg.processing_status IN (''Failed'', ''Pending'')
  AND rolg.LINE_KEY IS NULL
THEN UPDATE SET
    rolg.processing_errortype = '''',
    rolg.processing_comment = ''Ready For Processing'';


SELECT COUNT(*)
INTO :errorCount 
FROM RAW.RAW_ORDER_tax_breakup
WHERE processing_status = ''Failed'';
;

IF(ErrorCount > 0) THEN
BEGIN 
    finalStatus := ''er_records'';
END;
ELSE 
    finalStatus := ''isSuccessful'';
END IF;
  
END;
END IF;

IF (omsCount = 0) THEN 
BEGIN
finalStatus := ''no_records'';
END;
END IF;
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_HEADER_TAX_BREAKUP has been Completed'');
RETURN finalStatus;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_HEADER_TAX_BREAKUP has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_LINE"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    OrderNoErrorMsg STRING;
    SourceRefErrorMsg STRING;
    OrderErrorMsg STRING;
    SkuErrorMsg STRING;
    SourceErrorMsg STRING;
    CurrencyErrorMsg STRING;
    CustomerErrorMsg STRING;
    ShippingMethodErrorMsg STRING;
    OrderStatusErrorMsg STRING;
    PaymentMethodErrorMsg STRING;
    OrderTypeErrorMsg STRING;
    EditSourceRefErrorMsg STRING;
    OrderLineErrorMsg STRING;
    OrderShipErrorMsg STRING;
    OrderItemErrorMsg STRING;
    message STRING;
    ErrorCount INT;
    StageErrorCount INT;
    DimErrorCount INT;
    TxnErrorCount INT;
    amendment_topic STRING;
    amendment_note STRING;
    OMSOrderCount INT;
    OMSErrorOrderCount INT;
  
    StagingRecordCount INT;
    FinalStatus STRING;
    DataValidationErrCount INT;
    OrderTypeCount INT;

BEGIN
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_LINE has been Started'');
    CREATE OR REPLACE TEMPORARY TABLE DimResultToLog (
        orderheaderkey STRING,
        orderlinekey STRING,
        stgorderstatus STRING,
        orderstatusid STRING,
        stgitemid STRING,
        skuid STRING,
        txn_id STRING
    );

    CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog (
        orderheaderkey STRING,
        orderlinekey STRING,
        txn_id STRING,
        processing_errortype STRING,
        processing_status STRING,
        processing_comment STRING
    );

    CREATE OR REPLACE TEMPORARY TABLE TxnResultToLog (
        stgsourceref STRING,
        stgorderstaus STRING,
        stgjoinsourceref STRING,
        headsourceref STRING
    );

    FinalStatus := ''val_records'';

    SELECT COUNT(*) INTO OMSOrderCount FROM TRANSFORMED.STG_order_header;

    OrderNoErrorMsg := ''OrderNo for [ERRORSOURCE]   Header_Key is not found'';
    OrderLineErrorMsg := ''OrderLineKey for [ERRORSOURCE]   Line_Key is not found'';
    OrderShipErrorMsg := ''Ship_to_key for [ERRORSOURCE] Ship_to_Key is not found'';
    SourceErrorMsg := ''[ERRORITEM] for this brand and platform no source found'';
    CurrencyErrorMsg := ''Currency [ERRORITEM] not found'';
    CustomerErrorMsg := ''Customer [ERRORITEM] not found'';
    ShippingMethodErrorMsg := ''Shipping Method [ERRORITEM] not found'';
    OrderStatusErrorMsg := ''Order Line Status [ERRORITEM] not found'';
    OrderTypeErrorMsg := ''Order Type [ERRORITEM] not found'';
    EditSourceRefErrorMsg := ''SourceRefNum [ERRORITEM] have no records for modification'';
    OrderItemErrorMsg := ''ItemID [ERRORITEM] not found'';
    SourceRefErrorMsg := ''SourceRefNum [ERRORSOURCE] not found'';
    OrderErrorMsg := ''OrderId [ERRORORDERID] not found'';
    SkuErrorMsg := ''SKU [ERRORITEM] not found'';
    PaymentMethodErrorMsg := ''Payment Method [ERRORITEM] not found'';

    IF (OMSOrderCount > 0) THEN
        INSERT INTO DimResultToLog
        SELECT DISTINCT
            stg.ORDER_HEADER_KEY,
            stg.ORDER_LINE_KEY,
            stg.order_line_status,
            ordsts.pk_order_statusid,
            stg.ITEM_ID,
            dsl.pk_skuproductid,
            stg.txn_id
        FROM  TRANSFORMED.STG_order_line AS stg
        LEFT JOIN  master.dim_order_status AS ordsts ON ordsts.oms_order_status_code = stg.order_line_status
        LEFT JOIN analytics.txn_order_header AS toh ON toh.ext_order_id = stg.order_header_key AND toh.entry_type IS NOT NULL
        LEFT JOIN master.dim_source AS src ON src.pk_sourceid = toh.fk_sourceid
        LEFT JOIN ANALYTICS.sku_product_locale AS dsl ON dsl.sku_code = stg.ITEM_ID AND dsl.locale = src.locale;

        INSERT INTO ErrorResultToLog
        (orderheaderkey, orderlinekey, txn_id, processing_errortype, processing_status, processing_comment)
        SELECT DISTINCT
            rol.ORDER_HEADER_KEY,
            rol.ORDER_LINE_KEY,
            rol.txn_id,
            ''SKU'',
            ''Failed'',
            REPLACE(''ItemID [ERRORITEM] not found'', ''[ERRORITEM]'', rol.ITEM_ID)
        FROM RAW.RAW_order_line AS rol
        INNER JOIN DimResultToLog AS dst ON rol.ORDER_LINE_KEY = dst.orderlinekey AND rol.txn_id =      dst.txn_id
        WHERE dst.skuid IS NULL AND rol.processing_status IN (''Failed'', ''Pending'');


        -- Step 1: Create and populate the temporary table for aggregated error results
     CREATE or replace TEMPORARY TABLE temp_erlist AS
    SELECT 
        temp1.orderlinekey, 
        temp1.txn_id, 
        temp1.processing_status,  
       LISTAGG(temp2.processing_errortype, '','') AS errortype,
       LISTAGG(temp2.processing_comment, '','') AS comment
    FROM ErrorResultToLog temp1
    INNER JOIN ErrorResultToLog temp2 
        ON temp1.txn_id = temp2.txn_id 
        AND temp1.orderlinekey = temp2.orderlinekey
    WHERE temp1.processing_status IN (''Failed'')
    GROUP BY temp1.orderlinekey, temp1.txn_id, temp1.processing_status;
    
    -- Step 2: Create and populate the temporary table for rows to be updated
    CREATE or replace TEMPORARY TABLE temp_updated_rows AS
    SELECT 
        rol.ORDER_LINE_KEY, 
        erlist.errortype, 
        erlist.comment
    FROM RAW.RAW_order_line AS rol
    INNER JOIN temp_erlist AS erlist
        ON erlist.txn_id = rol.txn_id 
        AND erlist.orderlinekey = rol.ORDER_LINE_KEY
    WHERE rol.processing_status IN (''Failed'', ''Pending'');
    
    -- Step 3: Perform the update based on the temporary tables
    -- UPDATE RAW.RAW_order_line rol
    -- SET 
    --     processing_errortype = (
    --         SELECT errortype 
    --         FROM temp_updated_rows 
    --         WHERE temp_updated_rows.ORDER_LINE_KEY = rol.ORDER_LINE_KEY
    --     ),
    --     processing_comment = (
    --         SELECT comment 
    --         FROM temp_updated_rows 
    --         WHERE temp_updated_rows.ORDER_LINE_KEY = rol.ORDER_LINE_KEY
    --     ),
    --     processing_status = ''Failed''
    -- WHERE ORDER_LINE_KEY IN (SELECT ORDER_LINE_KEY FROM temp_updated_rows);
    MERGE INTO RAW.RAW_order_line AS rol
        USING (SELECT DISTINCT ORDER_LINE_KEY,errortype,comment FROM temp_updated_rows) AS temp
        ON rol.ORDER_LINE_KEY = temp.ORDER_LINE_KEY
        WHEN MATCHED THEN 
    UPDATE SET 
        rol.processing_errortype = temp.errortype,
        rol.processing_comment = temp.comment,
        rol.processing_status = ''Failed'';


-- Optional: Drop the temporary tables if no longer needed
    DROP TABLE IF EXISTS temp_erlist;
    DROP TABLE IF EXISTS temp_updated_rows;


        -- Use a CTE to identify the rows to update
    create or replace temp table tempupdated_rows as 
    WITH updated_rows AS (
        SELECT rol.ORDER_LINE_KEY
        FROM RAW.RAW_order_line AS rol
        INNER JOIN DimResultToLog AS dst 
            ON rol.txn_id = dst.txn_id 
            AND rol.ORDER_LINE_KEY = dst.orderlinekey
        WHERE 
            rol.ORDER_LINE_KEY IS NOT NULL 
            AND rol.ORDER_LINE_KEY != ''''
            AND rol.ORDER_HEADER_KEY IS NOT NULL 
            AND rol.ORDER_HEADER_KEY != '''' 
            AND rol.ITEM_ID IS NOT NULL 
            AND rol.ITEM_ID != '''' 
            AND rol.processing_status IN (''Failed'', ''Pending'')
    )
    select * from updated_rows;
    
    -- Perform the update based on the CTE results
    UPDATE RAW.RAW_order_line
    SET
        processing_errortype = '''',
        processing_comment = ''Ready For Processing''
    WHERE ORDER_LINE_KEY IN (SELECT distinct ORDER_LINE_KEY FROM tempupdated_rows);
    

        SELECT COUNT(*) INTO ErrorCount FROM RAW.RAW_order_line WHERE processing_status = ''Failed'';
        IF (ErrorCount > 0) THEN
            FinalStatus := ''er_records'';
        END IF;
    ELSE
        FinalStatus := ''no_records'';
    END IF;
    SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_LINE has been Completed'');

    RETURN FinalStatus;
    EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_LINE has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_LINE_CHARGES"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
 OrderErrorMsg VARCHAR(100);
 ChargeErrorMsg VARCHAR(100);
 SourceErrorMsg VARCHAR(100);
 OrderLineErrorMsg VARCHAR(100);
 message VARCHAR(1000);
 FinalStatus VARCHAR(100) DEFAULT ''1'';
 ErrorCount INT;
 OMSCount INT;
 OMSErrorCount INT;
 DimErrorCount INT;
 TxnErrorCount INT;
 InvalidOrderStatus VARCHAR := ''CHECKED_INVALID'';
BEGIN 
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_LINE_CHARGES has been Started'');
-- Create temporary table for ErrorResultToLog
CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog (
    order_header_key TEXT,
    order_line_key TEXT,
    line_charges_key TEXT,
    txn_id TEXT,
    processing_errortype TEXT,
    processing_status TEXT,
    processing_comment TEXT 
);

-- Create temporary table for DimResultToLog
CREATE OR REPLACE TEMPORARY TABLE DimResultToLog (
    header_key VARCHAR(250),
    line_key VARCHAR(250),
    line_charges_key TEXT,
    pk_order_headerid VARCHAR(250),
    pk_order_detailid VARCHAR(250),
    charge_category VARCHAR(250),
    pk_chargecategory_typeid VARCHAR(250),
    stgsource VARCHAR(250),
    sourceid VARCHAR(250),
    txn_id VARCHAR(250)
);

SELECT COUNT(*)
INTO :omsCount
FROM TRANSFORMED.STG_order_line_charges;

 OrderErrorMsg := ''Order [ERRORITEM] not found in txn order'';
 OrderLineErrorMsg := ''Order Detail [ERRORITEM] not found'';
 SourceErrorMsg := ''[ERRORITEM] for this brand and platform no source found'';
 ChargeErrorMsg := ''Charge Category [ERRORITEM] not found'';

IF (omsCount > 0) THEN 
BEGIN 

INSERT INTO DimResultToLog (header_key ,
    line_key ,
    line_charges_key ,
    pk_order_headerid ,
    pk_order_detailid ,
    charge_category ,
    pk_chargecategory_typeid ,
    stgsource ,
    sourceid,
    txn_id)
SELECT DISTINCT
    stg.header_key,
    stg.line_key,
    stg.line_charges_key,
    toh.pk_order_headerid,
    tod.pk_order_detailid,
    stg.charge_category,
    dc.pk_chargecategory_typeid,
    toh.entry_type,
    toh.fk_sourceid,
    stg.txn_id
FROM TRANSFORMED.STG_order_line_charges AS stg
LEFT JOIN ANALYTICS.txn_order_header AS toh ON toh.order_header_key = stg.header_key AND toh.entry_type IS NOT NULL
LEFT JOIN ANALYTICS.txn_order_detail AS tod ON tod.ext_line_id = stg.line_key AND toh.pk_order_headerid = tod.fk_order_headerid
LEFT JOIN master.dim_chargecategory AS dc ON dc.charge_category = stg.charge_category AND dc.charge IN (''FEE'', ''DISCOUNT'');

INSERT INTO ErrorResultToLog (order_header_key, order_line_key, line_charges_key, txn_id, processing_errortype, processing_status, processing_comment)
SELECT DISTINCT
    rolg.header_key,
    rolg.line_key,
    rolg.line_charges_key,
    dst.txn_id,
    ''Source'',
    ''Failed'',
    REPLACE(:SourceErrorMsg, ''[ERRORITEM]'', dst.stgsource) AS processing_comment
FROM RAW.RAW_order_line_charges AS rolg
INNER JOIN DimResultToLog AS dst ON rolg.line_key = dst.line_key 
                                  AND rolg.line_charges_key = dst.line_charges_key 
                                  AND rolg.txn_id = dst.txn_id
WHERE dst.sourceid IS NULL 
  AND dst.stgsource IS NOT NULL 
  AND processing_status IN (''Failed'', ''Pending'');

INSERT INTO ErrorResultToLog (order_header_key, order_line_key, line_charges_key, txn_id, processing_errortype, processing_status, processing_comment)
SELECT DISTINCT
    rolg.header_key,
    rolg.line_key,
    rolg.line_charges_key,
    rolg.txn_id,
    ''Order'',
    ''Failed'',
    REPLACE(:OrderErrorMsg, ''[ERRORITEM]'', rolg.header_key) AS processing_comment
FROM RAW.RAW_order_line_charges AS rolg
INNER JOIN DimResultToLog AS dst ON rolg.line_key = dst.line_key 
                                  AND rolg.line_charges_key = dst.line_charges_key 
                                  AND rolg.txn_id = dst.txn_id
WHERE dst.pk_order_headerid IS NULL 
  AND dst.header_key IS NOT NULL 
  AND processing_status IN (''Failed'', ''Pending'');

INSERT INTO ErrorResultToLog (order_header_key, order_line_key, line_charges_key, txn_id, processing_errortype, processing_status, processing_comment)
SELECT DISTINCT
    rolg.header_key,
    rolg.line_key,
    rolg.line_charges_key,
    rolg.txn_id,
    ''Order_Line'' AS processing_errortype,
    ''Failed'' AS processing_status,
    REPLACE(:OrderLineErrorMsg || '' in txn order line '', ''[ERRORSOURCE]'', rolg.line_key) AS processing_comment
FROM RAW.RAW_order_line_charges AS rolg
INNER JOIN DimResultToLog AS dst ON rolg.line_key = dst.line_key 
                                  AND rolg.line_charges_key = dst.line_charges_key 
                                  AND rolg.txn_id = dst.txn_id
WHERE dst.pk_order_detailid IS NULL 
  AND dst.line_key IS NOT NULL 
  AND processing_status IN (''Failed'', ''Pending'');


INSERT INTO ErrorResultToLog (order_header_key, order_line_key, line_charges_key, txn_id, processing_errortype, processing_status, processing_comment)
SELECT DISTINCT
    rolg.header_key,
    rolg.line_key,
    rolg.line_charges_key,
    rolg.txn_id,
    ''CHARGE CATEGORY'' AS processing_errortype,
    ''Failed'' AS processing_status,
    REPLACE(:ChargeErrorMsg, ''[ERRORITEM]'', rolg.charge_category) AS processing_comment
FROM RAW.RAW_order_line_charges AS rolg
INNER JOIN DimResultToLog AS dst ON rolg.line_key = dst.line_key 
                                  AND rolg.line_charges_key = dst.line_charges_key 
                                  AND rolg.txn_id = dst.txn_id
WHERE dst.pk_chargecategory_typeid IS NULL 
  AND dst.charge_category IS NOT NULL 
  AND processing_status IN (''Failed'', ''Pending'');


MERGE INTO RAW.RAW_order_line_charges AS raw
USING (
    SELECT DISTINCT
        temp1.order_line_key,
        temp1.line_charges_key,
        temp1.txn_id,
        temp1.processing_status,
        LISTAGG(temp2.processing_errortype, '','') WITHIN GROUP (ORDER BY temp2.processing_errortype) AS errortype,
        LISTAGG(temp2.processing_comment, '','') WITHIN GROUP (ORDER BY temp2.processing_comment) AS comment
    FROM (
        SELECT DISTINCT
            t1.processing_comment,
            t1.line_charges_key,
            t1.order_line_key,
            t1.txn_id,
            t1.processing_status
        FROM ErrorResultToLog t1
        WHERE processing_status IN (''Failed'')
    ) temp1
    INNER JOIN ErrorResultToLog temp2 ON temp2.txn_id = temp1.txn_id
                                       AND temp2.order_line_key = temp1.order_line_key
                                       AND temp2.line_charges_key = temp1.line_charges_key
    GROUP BY temp1.line_charges_key, temp1.order_line_key, temp1.txn_id, temp1.processing_status
) AS erlist
ON raw.txn_id = erlist.txn_id
AND raw.line_key = erlist.order_line_key
AND raw.line_charges_key = erlist.line_charges_key
AND raw.processing_status IN (''Failed'', ''Pending'')
WHEN MATCHED THEN 
    UPDATE SET 
        raw.processing_errortype = erlist.errortype,
        raw.processing_comment = erlist.comment,
        raw.processing_status = ''Failed'';




MERGE INTO RAW.RAW_order_line_charges AS rolg
USING (
    SELECT DISTINCT
        dst.line_key,
        dst.line_charges_key,
        dst.txn_id
    FROM DimResultToLog AS dst
    WHERE dst.sourceid IS NOT NULL
      AND dst.stgsource IS NOT NULL
      AND dst.pk_order_headerid IS NOT NULL
      AND dst.header_key IS NOT NULL
      AND dst.pk_order_detailid IS NOT NULL
      AND dst.line_key IS NOT NULL
      AND dst.pk_chargecategory_typeid IS NOT NULL
      AND dst.charge_category IS NOT NULL
) AS dst
ON rolg.line_charges_key = dst.line_charges_key
   AND rolg.line_key = dst.line_key
   AND rolg.txn_id = dst.txn_id
   AND rolg.processing_status IN (''Failed'', ''Pending'')
WHEN MATCHED THEN 
    UPDATE SET 
        rolg.processing_errortype = '''',
        rolg.processing_comment = ''Ready For Processing''
;


-- DELETE FROM TRANSFORMED.STG_order_line_charges AS sool
-- USING (
--     SELECT line_key, line_charges_key, txn_id, processing_errortype 
--     FROM RAW.RAW_order_line_charges
--     WHERE processing_status IN (''Failed'')
-- ) AS dt
-- WHERE dt.line_key = sool.line_key
--   AND dt.line_charges_key = sool.line_charges_key
--   AND dt.txn_id = sool.txn_id
--   AND (dt.processing_errortype != '''' OR dt.processing_errortype IS NOT NULL);

MERGE INTO TRANSFORMED.STG_order_line_charges AS sool
USING (
    SELECT line_key, line_charges_key, txn_id
    FROM RAW.RAW_order_line_charges
    WHERE processing_status = ''Failed''
      AND (processing_errortype IS NOT NULL AND processing_errortype != '''')
) AS dt 
ON sool.line_key = dt.line_key
AND sool.line_charges_key = dt.line_charges_key
AND sool.txn_id = dt.txn_id
WHEN MATCHED THEN
    DELETE;



SELECT COUNT(*)
INTO :errorCount 
FROM RAW.RAW_order_line_charges
WHERE processing_status = ''Failed'';
;

IF(ErrorCount > 0) THEN
BEGIN 
    finalStatus := ''er_records'';
END;
ELSE 
    finalStatus := ''isSuccessful'';
END IF;

END;
END IF;

IF (omsCount = 0) THEN 
BEGIN
finalStatus := ''no_records'';
END;
END IF;
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_LINE_CHARGES has been Completed'');
RETURN finalStatus;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_LINE_CHARGES has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_LINE_TAX_BREAKUP"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
 OrderErrorMsg VARCHAR(100);
 ChargeErrorMsg VARCHAR(100);
 SourceErrorMsg VARCHAR(100);
 LineErrorMsg VARCHAR(100);
 message VARCHAR(1000);
 FinalStatus VARCHAR(100) DEFAULT ''0'';
 ErrorCount INT;
 OMSCount INT;
 OMSErrorCount INT;
 DimErrorCount INT;
 TxnErrorCount INT;
BEGIN 
    SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_LINE_TAX_BREAKUP has been Started'');
    CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog 
    (  
       TAX_BREAKUP_KEY STRING,
       line_key STRING,  
       txn_id STRING,
       processing_errortype STRING,
       processing_status STRING,
       processing_comment STRING
    );

    CREATE OR REPLACE TEMPORARY TABLE DimResultToLog 
    (      
       TAX_BREAKUP_KEY STRING,  
       pk_order_headerid STRING, 
       line_key STRING,  
       pk_order_detailid STRING,  
       charge_category STRING,  
       pk_chargecategory_typeid STRING,  
       stgsource STRING,  
       sourceid STRING,   
       txn_id STRING
    );

SELECT COUNT(*) INTO OMSCount FROM transformed.STG_order_tax_breakup;

OrderErrorMsg := ''Order [ERRORITEM] not found in txn order'';
LineErrorMsg := ''Line [ERRORITEM] not found in txn order'';
ChargeErrorMsg := ''Charge Category [ERRORITEM] not found'';
SourceErrorMsg := ''[ERRORITEM] for this brand and platform no source found'';

IF (OMSCount > 0) THEN 
BEGIN

INSERT INTO DimResultToLog          
SELECT DISTINCT 
  stg.TAX_BREAKUP_KEY,  
  toh.pk_order_headerid,
  stg.line_key,
  tod.pk_order_detailid,
  stg.charge_category,  
  dc.pk_chargecategory_typeid,  
  toh.entry_type,
  toh.fk_sourceid,  
  stg.txn_id
FROM TRANSFORMED.STG_order_tax_breakup AS stg 
LEFT JOIN ANALYTICS.txn_order_header AS toh 
  ON toh.ext_order_id = stg.header_key AND toh.entry_type IS NOT NULL
LEFT JOIN ANALYTICS.txn_order_detail AS tod 
  ON tod.ext_line_id = stg.line_key AND toh.pk_order_headerid = tod.fk_order_headerid
LEFT JOIN master.dim_chargecategory AS dc 
  ON dc.charge_category = stg.charge_category AND dc.charge = ''TAX''
WHERE stg.line_key IS NOT NULL;

INSERT INTO DimResultToLog          
SELECT DISTINCT 
  stg.TAX_BREAKUP_KEY,  
  toh.pk_order_headerid,
  stg.line_key,
  tod.pk_order_detailid,
  stg.charge_category,  
  dc.pk_chargecategory_typeid,  
  toh.entry_type,
  toh.fk_sourceid,  
  stg.txn_id
FROM TRANSFORMED.STG_order_tax_breakup AS stg 
LEFT JOIN ANALYTICS.txn_order_header AS toh 
  ON toh.ext_order_id = stg.header_key AND toh.entry_type IS NOT NULL
LEFT JOIN ANALYTICS.txn_order_detail AS tod 
  ON tod.ext_line_id = stg.line_key AND toh.pk_order_headerid = tod.fk_order_headerid
LEFT JOIN master.dim_chargecategory AS dc 
  ON dc.charge_category = stg.charge_category AND dc.charge = ''TAX''
WHERE stg.line_key IS NOT NULL;

INSERT INTO ErrorResultToLog 
  ( 
   TAX_BREAKUP_KEY, 
   txn_id,
   line_key,
   processing_errortype,
   processing_status,
   processing_comment
  )
    SELECT DISTINCT
        rolg.TAX_BREAKUP_KEY,
        rolg.txn_id,
        rolg.LINE_KEY,
        ''Order'',
        ''Failed'',
        REPLACE(:OrderErrorMsg, ''[ERRORITEM]'', rolg.header_key)
    FROM RAW.RAW_order_tax_breakup AS rolg
    INNER JOIN DimResultToLog AS dst 
      ON rolg.TAX_BREAKUP_KEY = dst.TAX_BREAKUP_KEY AND rolg.txn_id = dst.txn_id
    WHERE dst.pk_order_headerid IS NULL 
      AND rolg.header_key IS NOT NULL 
      AND processing_status IN (''Failed'', ''Pending'')  
      AND rolg.line_key IS NOT NULL;

INSERT INTO ErrorResultToLog 
  (  
   TAX_BREAKUP_KEY, 
   txn_id,
   line_key,
   processing_errortype,
   processing_status,
   processing_comment
  )
    SELECT DISTINCT
        rolg.TAX_BREAKUP_KEY,
        rolg.txn_id,
        rolg.LINE_KEY,
        ''Line'',
        ''Failed'',
        REPLACE(:LineErrorMsg, ''[ERRORITEM]'', rolg.line_key)
    FROM RAW.RAW_order_tax_breakup AS rolg
    INNER JOIN DimResultToLog AS dst 
      ON rolg.TAX_BREAKUP_KEY = dst.TAX_BREAKUP_KEY 
      AND rolg.line_key = dst.line_key 
      AND rolg.txn_id = dst.txn_id
    WHERE dst.pk_order_detailid IS NULL 
      AND dst.line_key IS NOT NULL 
      AND processing_status IN (''Failed'', ''Pending'')  
      AND rolg.line_key IS NOT NULL;

INSERT INTO ErrorResultToLog 
  (  
   TAX_BREAKUP_KEY, 
   txn_id,
   line_key,
   processing_errortype,
   processing_status,
   processing_comment
  )
    SELECT DISTINCT
        rolg.TAX_BREAKUP_KEY,
        rolg.txn_id,
        rolg.LINE_KEY,
        ''CHARGE CATEGORY'',
        ''Failed'',
        REPLACE(:ChargeErrorMsg, ''[ERRORITEM]'', rolg.charge_category)
    FROM RAW.RAW_order_tax_breakup AS rolg
    INNER JOIN DimResultToLog AS dst 
      ON rolg.TAX_BREAKUP_KEY = dst.TAX_BREAKUP_KEY 
      AND rolg.txn_id = dst.txn_id
    WHERE dst.pk_chargecategory_typeid IS NULL 
      AND dst.charge_category IS NOT NULL 
      AND processing_status IN (''Failed'', ''Pending'')  
      AND rolg.line_key IS NOT NULL;

MERGE INTO RAW.RAW_order_tax_breakup AS raw
USING (
    SELECT 
        temp1.line_key,
        temp1.TAX_BREAKUP_KEY,
        temp1.txn_id,
        ARRAY_TO_STRING(ARRAY_AGG(temp2.processing_errortype), '','') AS errortype,
        ARRAY_TO_STRING(ARRAY_AGG(temp2.processing_comment), '','') AS comment
    FROM (
        SELECT 
            t2.processing_comment,
            t2.TAX_BREAKUP_KEY,
            t2.txn_id,
            t2.processing_status,
            t2.line_key,
            t2.processing_errortype
        FROM ErrorResultToLog t2
        WHERE t2.processing_status IN (''Failed'')
    ) temp2
    JOIN ErrorResultToLog temp1
        ON temp2.txn_id = temp1.txn_id
        AND temp1.TAX_BREAKUP_KEY = temp2.TAX_BREAKUP_KEY
        AND temp1.line_key = temp2.line_key
    GROUP BY 
        temp1.line_key,
        temp1.TAX_BREAKUP_KEY,
        temp1.txn_id,
        temp1.processing_status
) AS erlist
ON raw.txn_id = erlist.txn_id
   AND raw.TAX_BREAKUP_KEY = erlist.TAX_BREAKUP_KEY
   AND raw.LINE_KEY = erlist.line_key
   AND raw.processing_status IN (''Failed'', ''Pending'')
   AND raw.line_key IS NOT NULL
WHEN MATCHED THEN
UPDATE SET
    raw.processing_errortype = erlist.errortype,
    raw.processing_comment = erlist.comment,
    raw.processing_status = ''Failed'';


MERGE INTO RAW.RAW_order_tax_breakup AS rolg
USING ( select distinct * from DimResultToLog) AS dst
ON rolg.TAX_BREAKUP_KEY = dst.TAX_BREAKUP_KEY
   AND rolg.txn_id = dst.txn_id
   AND rolg.LINE_KEY = dst.line_key
   AND rolg.processing_status IN (''Failed'', ''Pending'')
   AND rolg.LINE_KEY IS NOT NULL
   AND dst.sourceid IS NOT NULL
   AND dst.stgsource IS NOT NULL
   AND dst.pk_order_detailid IS NOT NULL
WHEN MATCHED THEN
UPDATE SET
    rolg.processing_errortype = '''',
    rolg.processing_comment = ''Ready For Processing'';


SELECT COUNT(*) INTO :ErrorCount FROM RAW.RAW_order_tax_breakup WHERE processing_status = ''Failed'';

IF(ErrorCount > 0) THEN 
BEGIN 
    FinalStatus:= ''er_records'';
END;
ELSE 
    FinalStatus:= ''isSuccesful'';
END IF;
      
END;
END IF;

IF (OMSCount = 0) THEN  
BEGIN 
FinalStatus:= ''no_records'';
END;
END IF;
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_LINE_TAX_BREAKUP has been Completed'');
RETURN FinalStatus;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_LINE_TAX_BREAKUP has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_PAYMENT"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    OrderErrorMsg STRING;
    PaymentAmountErrorMsg STRING;
    PaymentDateErrorMsg STRING;
    message STRING;
    FinalStatus INT;
    OMSCount INT;
    OMSErrorCount INT;

BEGIN
    FinalStatus := 0;
    SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_PAYMENT has been Started'');
    IF (EXISTS (SELECT * FROM information_schema.tables WHERE table_name = ''ERRORRESULTTOLOG'')) THEN
        DROP TABLE IF EXISTS ErrorResultToLog;
    END IF;

    -- Create the temporary table
    CREATE TEMPORARY TABLE ErrorResultToLog (
        payment_key STRING,
        order_header_key STRING,
        txn_id STRING,
        processing_errortype STRING,
        processing_status STRING,
        processing_comment STRING
    );

    -- Count OMS records
    SELECT COUNT(*)
    INTO OMSCount
    FROM STG_order_payment;

    -- Error messages
    OrderErrorMsg := ''OrderHeader for [ERRORITEM] Header_Key not found'';
    PaymentAmountErrorMsg := ''Payment Amount [ERRORITEM] not numeric'';
    PaymentDateErrorMsg := ''Payment Date [ERRORITEM] string cannot be converted to date'';

    IF (OMSCount > 0) THEN
        -- Inserts errors into temp table
        INSERT INTO ErrorResultToLog
        SELECT
            stg.payment_key,
            stg.order_header_key,
            stg.txn_id,
            ''Order'' AS processing_errortype,
            ''Failed'' AS processing_status,
            REPLACE(''OrderHeader for [ERRORITEM] Header_Key not found'', ''[ERRORITEM]'', stg.order_header_key) AS processing_comment
        FROM TRANSFORMED.STG_order_payment stg
        LEFT JOIN ANALYTICS.TXN_ORDER_HEADER ord ON stg.order_header_key = ord.ext_order_id
        WHERE ord.pk_order_headerid IS NULL;

        INSERT INTO ErrorResultToLog
        SELECT
            rop.payment_key,
            rop.order_header_key,
            rop.txn_id,
            ''PayAmount'' AS processing_errortype,
            ''Failed'' AS processing_status,
            REPLACE(''Payment Amount [ERRORITEM] not numeric'', ''[ERRORITEM]'', rop.total_charged) AS processing_comment
        FROM STG_order_payment rop
        LEFT JOIN ANALYTICS.TXN_ORDER_HEADER ord ON rop.order_header_key = ord.ext_order_id
        WHERE TRY_TO_NUMBER(rop.total_charged) IS NULL;

        -- Update raw OMS order payment table
       MERGE INTO RAW.RAW_ORDER_PAYMENT rop
    USING (
        SELECT
            temp1.order_header_key,
            temp1.payment_key,
            temp1.txn_id,
            LISTAGG(temp2.processing_errortype, '','') WITHIN GROUP (ORDER BY temp2.processing_errortype) AS  errortype,
            LISTAGG(temp2.processing_comment, '','') WITHIN GROUP (ORDER BY temp2.processing_comment) AS comment
        FROM ErrorResultToLog temp1
        JOIN ErrorResultToLog temp2 
            ON temp1.txn_id = temp2.txn_id
            AND temp1.order_header_key = temp2.order_header_key
            AND temp1.payment_key = temp2.payment_key
        GROUP BY temp1.payment_key, temp1.order_header_key, temp1.txn_id
    ) erlist
    ON rop.txn_id = erlist.txn_id
    AND rop.order_header_key = erlist.order_header_key
    AND rop.payment_key = erlist.payment_key
    WHEN MATCHED 
        AND rop.processing_status IN (''Failed'', ''Pending'')
    THEN UPDATE SET
        rop.processing_errortype = erlist.errortype,
        rop.processing_comment = erlist.comment,
        rop.processing_status = ''Failed'';


        -- Count errors
        SELECT COUNT(*)
        INTO OMSErrorCount
        FROM RAW.RAW_ORDER_PAYMENT
        WHERE processing_status = ''Failed'';

    END IF;

    -- Check for errors and set message
    IF (OMSErrorCount > 0 OR OMSCount = 0) THEN
        IF (OMSErrorCount > 0) THEN
            message := TO_VARCHAR(OMSCount) || '' Records from OMS Payment have business validation errors'';
        ELSEIF (OMSCount = 0) THEN
            message := ''OMS Order payment Have No Records'';
        END IF;
    END IF;

    FinalStatus := 1;
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_PAYMENT has been Completed'');
    RETURN message;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_PAYMENT has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_RELEASE"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE

OrderErrorMsg STRING(100);
SkuErrorMsg STRING(100);
ChargeErrorMsg STRING(100);
SourceErrorMsg STRING(100);

message STRING(1000);
FinalStatus STRING(100) DEFAULT ''0'';
ErrorCount INT;
OMSCount INT;
OMSErrorCount INT;        
DimErrorCount INT;
TxnErrorCount INT;      
InvalidOrderStatus STRING DEFAULT ''CHECKED_INVALID'';
BEGIN
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_RELEASE has been Started'');
-- Create a temporary table for error logging
CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog (
    order_release_key STRING,
    orderheaderkey STRING,
    txn_id STRING,
    processing_errortype STRING,
    processing_status STRING,
    processing_comment STRING
);

SELECT COUNT(*) INTO :OMSCount FROM TRANSFORMED.stg_order_release;

OrderErrorMsg := ''OrderHeader for [ERRORITEM] Header_Key not found'';

--SELECT COUNT(*) INTO :OMSCount FROM RAW.raw_order_shipment;

IF (:OMSCount > 0) THEN
    BEGIN 
    -- Insert into the temporary table
    INSERT INTO ErrorResultToLog
    SELECT
        raw.order_release_key,
        raw.order_header_key,
        raw.txn_id,
        ''Order'' AS processing_errortype,
        ''Failed'' AS processing_status,
        REPLACE(''OrderHeader for [ERRORITEM] Header_Key not found'', ''[ERRORITEM]'', stg.order_release_key) AS processing_comment
    FROM RAW.raw_order_release raw
    INNER JOIN TRANSFORMED.stg_order_release stg
        ON raw.order_release_key = stg.order_release_key
    LEFT JOIN ANALYTICS.txn_order_header ord
        ON stg.order_header_key = ord.ext_order_id
    WHERE ord.pk_order_headerid IS NULL;

    -- Update the original table with error details
    UPDATE RAW.raw_order_release AS raw
    SET
        raw.processing_errortype = erlist.errortype,
        raw.processing_comment = erlist.comment,
        raw.processing_status = ''Failed''
    FROM  (
        SELECT
            temp1.orderheaderkey,
            temp1.order_release_key,
            temp1.txn_id,
            -- temp1.processing_status,
            LISTAGG(temp2.processing_errortype, '','') WITHIN GROUP (ORDER BY temp2.processing_errortype) AS errortype,
            LISTAGG(temp2.processing_comment, '','') WITHIN GROUP (ORDER BY temp2.processing_comment) AS comment
        FROM ErrorResultToLog temp1
        INNER JOIN ErrorResultToLog temp2
            ON temp1.txn_id = temp2.txn_id
            AND temp1.orderheaderkey = temp2.orderheaderkey
            AND temp1.order_release_key = temp2.order_release_key
        WHERE temp2.processing_status = ''Failed''
        GROUP BY temp1.order_release_key, temp1.orderheaderkey, temp1.txn_id --, temp1.processing_status
    ) AS erlist
        where erlist.txn_id = raw.txn_id
        AND erlist.orderheaderkey = raw.order_header_key
        AND erlist.order_release_key = raw.order_release_key
    and  raw.processing_status IN (''Failed'', ''Pending'');



    
IF(:ErrorCount > 0) THEN
BEGIN 
    finalStatus := ''er_records'';
END;
ELSE 
    finalStatus := ''isSuccessful'';
END IF;

END;
END IF;

IF (:omsCount = 0) THEN 
BEGIN
finalStatus := ''no_records'';
END;
END IF;


DELETE FROM TRANSFORMED.stg_order_release AS stg
USING RAW.raw_order_release AS raw
WHERE raw.order_release_key = stg.order_release_key
  AND raw.modifyts = stg.modifyts and raw.processing_status = ''Failed'';

    
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_RELEASE has been Completed'');
RETURN finalStatus;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_RELEASE has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_RELEASE"("CURRENTDATETIME" TIMESTAMP_NTZ(9), "INPUTTRANSACTIONID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE

OrderErrorMsg STRING(100);
SkuErrorMsg STRING(100);
ChargeErrorMsg STRING(100);
SourceErrorMsg STRING(100);

message STRING(1000);
FinalStatus STRING(100) DEFAULT ''0'';
ErrorCount INT;
OMSCount INT;
OMSErrorCount INT;        
DimErrorCount INT;
TxnErrorCount INT;      
InvalidOrderStatus STRING DEFAULT ''CHECKED_INVALID'';
BEGIN
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_RELEASE has been Started'');
-- Create a temporary table for error logging
CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog (
    order_release_key STRING,
    orderheaderkey STRING,
    txn_id STRING,
    processing_errortype STRING,
    processing_status STRING,
    processing_comment STRING
);

OrderErrorMsg := ''OrderHeader for [ERRORITEM] Header_Key not found'';

SELECT COUNT(*) INTO :OMSCount FROM RAW.raw_order_shipment;

IF (OMSCount > 0) THEN
    BEGIN 
    -- Insert into the temporary table
    INSERT INTO ErrorResultToLog
    SELECT
        raw.order_release_key,
        raw.order_header_key,
        raw.txn_id,
        ''Order'' AS processing_errortype,
        ''Failed'' AS processing_status,
        REPLACE(''OrderHeader for [ERRORITEM] Header_Key not found'', ''[ERRORITEM]'', stg.order_release_key) AS processing_comment
    FROM RAW.raw_order_release raw
    INNER JOIN TRANSFORMED.stg_order_release stg
        ON raw.order_release_key = stg.order_release_key
    LEFT JOIN ANALYTICS.txn_order_header ord
        ON stg.order_header_key = ord.ext_order_id
    WHERE ord.pk_order_headerid IS NULL;

    -- Update the original table with error details
    UPDATE RAW.raw_order_release
    SET
        processing_errortype = erlist.errortype,
        processing_comment = erlist.comment,
        processing_status = ''Failed''
    FROM RAW.raw_order_release AS raw
    INNER JOIN (
        SELECT
            temp1.orderheaderkey,
            temp1.order_release_key,
            temp1.txn_id,
            temp1.processing_status,
            LISTAGG(temp2.processing_errortype, '','') WITHIN GROUP (ORDER BY temp2.processing_errortype) AS errortype,
            LISTAGG(temp2.processing_comment, '','') WITHIN GROUP (ORDER BY temp2.processing_comment) AS comment
        FROM ErrorResultToLog temp1
        INNER JOIN ErrorResultToLog temp2
            ON temp1.txn_id = temp2.txn_id
            AND temp1.orderheaderkey = temp2.orderheaderkey
            AND temp1.order_release_key = temp2.order_release_key
        WHERE temp2.processing_status = ''Failed''
        GROUP BY temp1.order_release_key, temp1.orderheaderkey, temp1.txn_id, temp1.processing_status
    ) AS erlist
        ON erlist.txn_id = raw.txn_id
        AND erlist.orderheaderkey = raw.order_header_key
        AND erlist.order_release_key = raw.order_release_key
    WHERE raw.processing_status IN (''Failed'', ''Pending'');

    -- Select the count of records with failed processing status for a given transaction ID
SELECT COUNT(*)
INTO :OMSErrorCount 
FROM RAW.raw_order_release
WHERE imported_date = :currentdatetime
AND processing_status = ''Failed''
AND txn_id = :inputTransactionId; -- Replace with actual transaction ID if needed


    
IF(ErrorCount > 0) THEN
BEGIN 
    finalStatus := ''er_records'';
END;
ELSE 
    finalStatus := ''isSuccessful'';
END IF;

END;
END IF;

IF (omsCount = 0) THEN 
BEGIN
finalStatus := ''no_records'';
END;
END IF;

DELETE FROM TRANSFORMED.stg_order_release AS stg
USING RAW.raw_order_release AS raw
WHERE raw.order_release_key = stg.order_release_key
  AND raw.modifyts = stg.modifyts;

    
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_RELEASE has been Completed'');
RETURN finalStatus;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_RELEASE has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_RELEASE_STATUS"()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    OrderNoErrorMsg STRING DEFAULT ''OrderNo for [ERRORSOURCE] Header_Key is not found'';
    OrderLineErrorMsg STRING DEFAULT ''OrderLineKey for [ERRORSOURCE] Line_Key is not found'';
    OrderStatusErrorMsg STRING DEFAULT ''Status [ERRORITEM] not found in dim'';
    message STRING;
    ErrorCount INT;
    OMSOrderCount INT;
    FinalStatus STRING DEFAULT ''val_records'';
BEGIN
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_RELEASE_STATUS has been Started'');
    -- Drop temporary tables if they exist
    IF (EXISTS (SELECT * FROM information_schema.tables WHERE table_name = ''ERRORRESULTTOLOG'')) THEN
        DROP TABLE IF EXISTS ErrorResultToLog;
    END IF;
    IF (EXISTS (SELECT * FROM information_schema.tables WHERE table_name = ''DIMRESULTTOLOG'')) THEN
        DROP TABLE IF EXISTS DimResultToLog;
    END IF;
    IF (EXISTS (SELECT * FROM information_schema.tables WHERE table_name = ''TXNRESULTTOLOG'')) THEN
        DROP TABLE IF EXISTS TxnResultToLog;
    END IF;

    -- Creating temporary tables
    CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog (
        orderreleasestatuskey STRING,
        orderlinekey STRING,
        txn_id STRING,
        processing_errortype STRING,
        processing_status STRING,
        processing_comment STRING
    );

    CREATE OR REPLACE TEMPORARY TABLE DimResultToLog (
        orderreleasestatuskey STRING,
        orderlinekey STRING,
        stgorderstatus STRING,
        orderstatusid STRING,
        txn_id STRING
    );

    CREATE OR REPLACE TEMPORARY TABLE TxnResultToLog (
        stgsourceref STRING,
        stgorderstatus STRING,
        stgjoinsourceref STRING,
        headsourceref STRING
    );

    -- Count OMS records
    SELECT COUNT(*)
    INTO :OMSOrderCount
    FROM TRANSFORMED.STG_order_header;

    IF (OMSOrderCount > 0) THEN
        -- Insert errors into temp table
        INSERT INTO ErrorResultToLog
        SELECT DISTINCT
            rol.ORDER_HEADER_KEY,
            rol.ORDER_LINE_KEY,
            rol.txn_id,
            ''Order_Header_Key'' AS processing_errortype,
            ''Failed'' AS processing_status,
            REPLACE(:OrderNoErrorMsg || '' in raw order header'', ''[ERRORSOURCE]'', rol.order_header_key) AS processing_comment
        FROM RAW.RAW_ORDER_RELEASE_STATUS AS rol
        WHERE rol.ORDER_HEADER_KEY IS NULL OR rol.ORDER_HEADER_KEY = '''';

        INSERT INTO ErrorResultToLog
        SELECT DISTINCT
            rol.ORDER_HEADER_KEY,
            rol.ORDER_LINE_KEY,
            rol.txn_id,
            ''Line_Key'' AS processing_errortype,
            ''Failed'' AS processing_status,
            REPLACE(:OrderLineErrorMsg || '' in raw order line'', ''[ERRORSOURCE]'', rol.order_line_key) AS processing_comment
        FROM RAW.RAW_ORDER_RELEASE_STATUS AS rol
        WHERE rol.ORDER_LINE_KEY IS NULL OR rol.ORDER_LINE_KEY = '''';

        INSERT INTO ErrorResultToLog
        SELECT DISTINCT
            rol.ORDER_HEADER_KEY,
            rol.ORDER_LINE_KEY,
            rol.txn_id,
            ''Status'' AS processing_errortype,
            ''Failed'' AS processing_status,
            REPLACE(:OrderStatusErrorMsg, ''[ERRORITEM]'', rol.STATUS) AS processing_comment
        FROM RAW.RAW_ORDER_RELEASE_STATUS AS rol
        WHERE rol.STATUS IS NULL OR rol.STATUS = '''';

        -- Insert validation related to dim table
        INSERT INTO DimResultToLog
        SELECT DISTINCT
            stg.ORDER_HEADER_KEY,
            stg.ORDER_LINE_KEY,
            stg.STATUS,
            ordsts.pk_order_statusid,
            stg.txn_id
        FROM RAW.RAW_ORDER_RELEASE_STATUS AS stg
        LEFT JOIN master.dim_ORDER_STATUS AS ordsts ON ordsts.oms_order_status_code = stg.STATUS;

        INSERT INTO ErrorResultToLog
        SELECT DISTINCT
            rol.ORDER_RELEASE_STATUS_KEY,
            rol.ORDER_LINE_KEY,
            rol.txn_id,
            ''Status'' AS processing_errortype,
            ''Failed'' AS processing_status,
            REPLACE(:OrderStatusErrorMsg, ''[ERRORITEM]'', rol.STATUS) AS processing_comment
        FROM RAW.RAW_ORDER_RELEASE_STATUS AS rol
        INNER JOIN DimResultToLog AS dst ON rol.ORDER_LINE_KEY = dst.orderlinekey
            AND rol.txn_id = dst.txn_id
            AND rol.ORDER_HEADER_KEY = dst.orderreleasestatuskey
        WHERE dst.orderstatusid IS NULL AND dst.stgorderstatus IS NOT NULL AND processing_status IN (''Failed'', ''Pending'');

        -- Update RAW_ORDER_RELEASE_STATUS
        UPDATE RAW.RAW_ORDER_RELEASE_STATUS
        SET
            processing_errortype = erlist.errortype,
            processing_comment = erlist.comment,
            processing_status = ''Failed''
        FROM (
            SELECT
                temp1.orderreleasestatuskey,
                temp1.orderlinekey,
                temp1.txn_id,
                LISTAGG(temp2.processing_errortype, '','') WITHIN GROUP (ORDER BY temp2.processing_errortype) AS errortype,
                LISTAGG(temp2.processing_comment, '','') WITHIN GROUP (ORDER BY temp2.processing_comment) AS comment
            FROM ErrorResultToLog temp1
            JOIN ErrorResultToLog temp2 ON temp1.txn_id = temp2.txn_id
                AND temp1.orderreleasestatuskey = temp2.orderreleasestatuskey
                AND temp1.orderlinekey = temp2.orderlinekey
            GROUP BY temp1.orderlinekey, temp1.orderreleasestatuskey, temp1.txn_id
        ) erlist
        WHERE erlist.txn_id = RAW.RAW_ORDER_RELEASE_STATUS.txn_id
            AND erlist.orderreleasestatuskey = RAW.RAW_ORDER_RELEASE_STATUS.ORDER_HEADER_KEY
            AND erlist.orderlinekey = RAW.RAW_ORDER_RELEASE_STATUS.ORDER_LINE_KEY
            AND RAW.RAW_ORDER_RELEASE_STATUS.processing_status IN (''Failed'', ''Pending'');

        UPDATE RAW.RAW_ORDER_RELEASE_STATUS
        SET
            processing_errortype = '''',
            processing_comment = ''Ready For Processing''
        FROM DimResultToLog AS dst
        WHERE RAW.RAW_ORDER_RELEASE_STATUS.ORDER_HEADER_KEY = dst.orderreleasestatuskey
            AND RAW.RAW_ORDER_RELEASE_STATUS.txn_id = dst.txn_id
            AND RAW.RAW_ORDER_RELEASE_STATUS.ORDER_LINE_KEY = dst.orderlinekey
            AND RAW.RAW_ORDER_RELEASE_STATUS.ORDER_LINE_KEY IS NOT NULL
            AND RAW.RAW_ORDER_RELEASE_STATUS.ORDER_LINE_KEY != ''''
            AND RAW.RAW_ORDER_RELEASE_STATUS.ORDER_HEADER_KEY IS NOT NULL
            AND RAW.RAW_ORDER_RELEASE_STATUS.ORDER_HEADER_KEY != ''''
            AND RAW.RAW_ORDER_RELEASE_STATUS.STATUS IS NOT NULL
            AND RAW.RAW_ORDER_RELEASE_STATUS.STATUS != ''''
            AND RAW.RAW_ORDER_RELEASE_STATUS.processing_status IN (''Failed'', ''Pending'');

        DELETE FROM STG_order_release_status
        USING RAW.RAW_ORDER_RELEASE_STATUS
        WHERE RAW.RAW_ORDER_RELEASE_STATUS.ORDER_RELEASE_STATUS_KEY = STG_order_release_status.ORDER_RELEASE_STATUS_KEY
            AND RAW.RAW_ORDER_RELEASE_STATUS.txn_id = STG_order_release_status.txn_id
            AND RAW.RAW_ORDER_RELEASE_STATUS.processing_errortype IS NOT NULL
            AND RAW.RAW_ORDER_RELEASE_STATUS.processing_status = ''Failed'';

        -- Count errors
        SELECT COUNT(*)
        INTO :ErrorCount
        FROM TRANSFORMED.STG_order_release_status
        WHERE processing_status = ''Failed'';

        IF (ErrorCount > 0) THEN
            FinalStatus := ''er_records'';
        END IF;
    ELSE
        FinalStatus := ''no_records'';
    END IF;
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_RELEASE_STATUS has been Completed'');
    RETURN FinalStatus;
    EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_RELEASE_STATUS has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END;
';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_SHIPMENT"("CURRENTDATETIME" TIMESTAMP_NTZ(9), "INPUTTRANSACTIONID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    SourceRefErrorMsg STRING;
    OrderErrorMsg STRING;
    SkuErrorMsg STRING;
    SourceErrorMsg STRING;
    CurrencyErrorMsg STRING;
    CustomerErrorMsg STRING;
    ShippingMethodErrorMsg STRING;
    OrderStatusErrorMsg STRING;
    PaymentAmountErrorMsg STRING;
    PaymentDateErrorMsg STRING;
    EditSourceRefErrorMsg STRING;
    ToAddressErrorMsg STRING;
    FromAddressErrorMsg STRING;
    message STRING DEFAULT ''No relevant data found or unexpected error occurred.'';
    FinalStatus STRING;
    ErrorCount INT;
    OMSCount INT;
    OMSErrorCount INT;
    DimErrorCount INT;
    TxnErrorCount INT;
    action STRING DEFAULT ''CREATE'';
    amendment_topic STRING;
    amendment_note STRING;
    domesticSource STRING DEFAULT ''domestic'';
    internationalSource STRING DEFAULT ''international'';
    HybrisOrderCount INT;
    InvalidOrderStatus STRING DEFAULT ''CHECKED_INVALID'';
BEGIN
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_SHIPMENT has been Started'');
    CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog (
        shipmentkey STRING,
        orderheaderkey STRING,
        txn_id STRING,
        processing_errortype STRING,
        processing_status STRING,
        processing_comment STRING
    );

    -- variables
    FinalStatus := '''';
    OrderErrorMsg := ''OrderHeader for [ERRORITEM] Header_Key not found'';
    ToAddressErrorMsg := ''To Address [ERRORITEM] not found'';
    FromAddressErrorMsg := ''From Address [ERRORITEM] not found'';
    PaymentAmountErrorMsg := ''Payment Amount [ERRORITEM] not numeric'';
    PaymentDateErrorMsg := ''Payment Date [ERRORITEM] string cannot be converted to date'';

    -- Count records in RAW_ORDER_SHIPMENT
    SELECT COUNT(*) INTO :OMSCount FROM RAW.RAW_ORDER_SHIPMENT;

    IF (OMSCount > 0) THEN
        -- Insert records into ErrorResultToLog
        INSERT INTO ErrorResultToLog 
        SELECT 
            raw.shipment_key, 
            raw.order_header_key, 
            raw.txn_id, 
            ''Order'', 
            ''Failed'', 
            REPLACE(''OrderHeader for [ERRORITEM] Header_Key not found'', ''[ERRORITEM]'', stg.order_header_key)
        FROM 
            RAW.RAW_ORDER_SHIPMENT raw 
            JOIN TRANSFORMED.STG_ORDER_SHIPMENT stg 
                ON raw.shipment_key = stg.shipment_key
            LEFT JOIN ANALYTICS.TXN_ORDER_HEADER ord 
                ON stg.order_header_key = ord.ext_order_id
        WHERE 
            ord.pk_order_headerid IS NULL;

        -- Update RAW_order_shipment with error details
        UPDATE 
            RAW.RAW_ORDER_SHIPMENT AS raw
        SET 
            raw.processing_errortype = erlist.errortype,
            raw.processing_comment = erlist.comment,
            raw.processing_status = ''Failed''
        FROM (
            SELECT 
                temp1.orderheaderkey, 
                temp1.shipmentkey, 
                temp1.txn_id, 
                temp1.processing_status, 
                LISTAGG(temp2.processing_errortype, '','') 
                    WITHIN GROUP (ORDER BY temp2.processing_errortype) AS errortype,
                LISTAGG(temp2.processing_comment, '','') 
                    WITHIN GROUP (ORDER BY temp2.processing_comment) AS comment
            FROM 
                ErrorResultToLog temp1
                JOIN ErrorResultToLog temp2 
                    ON temp1.txn_id = temp2.txn_id 
                    AND temp1.orderheaderkey = temp2.orderheaderkey 
                    AND temp1.shipmentkey = temp2.shipmentkey
            GROUP BY 
                temp1.shipmentkey, 
                temp1.orderheaderkey, 
                temp1.txn_id, 
                temp1.processing_status
        ) erlist
        WHERE 
            erlist.txn_id = raw.txn_id 
            AND erlist.orderheaderkey = raw.order_header_key 
            AND erlist.shipmentkey = raw.shipment_key
            AND raw.processing_status IN (''Failed'', ''Pending'');

        -- Count the number of failed records
        SELECT COUNT(*) INTO :OMSErrorCount
        FROM RAW.RAW_ORDER_SHIPMENT
        WHERE imported_date = :currentDatetime 
          AND processing_status = ''Failed''
          AND txn_id = :inputTransactionId;
    ELSE
        message := ''No records found in RAW_ORDER_SHIPMENT'';
    END IF;

    IF (OMSErrorCount > 0 OR OMSCount = 0) THEN
        IF (OMSErrorCount > 0) THEN
            FinalStatus := ''er_records'';
            message := TO_VARCHAR(OMSCount) || '' Records from OMS Shipment have business validation errors '';
        ELSEIF (OMSCount = 0) THEN
            FinalStatus := ''no_records'';
            message := ''OMS Order Shipment Have No Records'';
        END IF;
    ELSE
        message := ''No errors found in OMS Order Shipment processing'';
    END IF;

    -- Drop the temporary table ErrorResultToLog
    DROP TABLE IF EXISTS ErrorResultToLog;
    SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_SHIPMENT has been Completed'');

    RETURN message;

EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_SHIPMENT has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END;
';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_SHIPMENT_CONTAINER"("CURRENTDATETIME" TIMESTAMP_NTZ(9), "INPUTTRANSACTIONID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS ' 
DECLARE 
    OrderErrorMsg STRING; 
    OrderStatusErrorMsg STRING;  
    PaymentDateErrorMsg STRING;
    EditSourceRefErrorMsg STRING; 
    ToAddressErrorMsg STRING; 
    FromAddressErrorMsg STRING;
    OrderLineErrorMsg STRING; 
    OrderShipmentErrorMsg STRING;
    message STRING; 
    FinalStatus STRING;
    OMSCount INT;
    OMSErrorCount INT;        
        
BEGIN
    FinalStatus := 0;  
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_SHIPMENT_CONTAINER has been Started'');
    IF (EXISTS (SELECT * FROM information_schema.tables WHERE table_name = ''ERRORRESULTTOLOG'')) THEN
        DROP TABLE IF EXISTS ErrorResultToLog;
    END IF;

    -- Create the temporary table
    CREATE TEMPORARY TABLE ErrorResultToLog (
        shipmentcontainerkey STRING,
        shipmentkey STRING,
        orderheaderkey STRING,  
        txn_id STRING,
        processing_errortype STRING,
        processing_status STRING,
        processing_comment STRING
    );        
    
    
    -- Error messages
    OrderErrorMsg := ''OrderHeader for [ERRORITEM] Header_Key not found'';
    OrderLineErrorMsg := ''OrderLine [ERRORITEM] Line_Key not found'';
    ToAddressErrorMsg := ''To Address [ERRORITEM] not found'';
    FromAddressErrorMsg := ''From Address [ERRORITEM] not found'';
    OrderShipmentErrorMsg := ''Order Shipment [ERRORITEM] Shipment key not found in raw/txn'';
    PaymentDateErrorMsg := ''Payment Date [ERRORITEM] string cannot be converted to date'';

    -- Selecting count into OMSCount
    OMSCount := (SELECT COUNT(1) FROM RAW.RAW_ORDER_SHIPMENT_CONTAINER);
   

    IF (OMSCount > 0) THEN

    -- Inserts errors into temp table
    INSERT INTO ErrorResultToLog
    SELECT
        raw.shipment_container_key AS shipmentcontainerkey,
        raw.shipment_key AS shipmentkey,
        raw.order_header_key AS orderheaderkey,
        raw.txn_id AS txn_id,
        ''Shipment'' AS processing_errortype,
        ''Failed'' AS processing_status,
        REPLACE(''Order Shipment [ERRORITEM] Shipment key not found in raw/txn'', ''[ERRORITEM]'', stg.shipment_key) AS processing_comment
    FROM RAW.RAW_ORDER_SHIPMENT_CONTAINER raw 
    JOIN STG_order_shipment_container stg 
        ON raw.shipment_key = stg.shipment_key
        AND raw.shipment_container_key = stg.shipment_container_key 
    LEFT JOIN RAW.RAW_ORDER_SHIPMENT ord 
        ON stg.shipment_key = ord.shipment_key
    WHERE 
        ord.shipment_key IS NULL;


     -- Update raw OMS order payment table
    UPDATE RAW.RAW_ORDER_SHIPMENT_CONTAINER raw
    SET 
        raw.processing_errortype = erlist.errortype,
        raw.processing_comment = erlist.comment,
        raw.processing_status = ''Failed''
    FROM (
        SELECT 
            temp1.orderheaderkey,
            temp1.shipmentkey,
            temp1.shipmentcontainerkey,
            temp1.txn_id,
            LISTAGG(temp2.processing_errortype, '','') WITHIN GROUP (ORDER BY temp2.processing_errortype) AS errortype,
            LISTAGG(temp2.processing_comment, '','') WITHIN GROUP (ORDER BY temp2.processing_comment) AS comment
        FROM ErrorResultToLog temp1
        JOIN ErrorResultToLog temp2 
        ON temp1.txn_id = temp2.txn_id 
        AND temp1.orderheaderkey = temp2.orderheaderkey 
        AND temp1.shipmentkey = temp2.shipmentkey 
        AND temp1.shipmentcontainerkey = temp2.shipmentcontainerkey
        WHERE temp1.processing_status = ''Failed''
        GROUP BY 
            temp1.shipmentkey,
            temp1.shipmentcontainerkey,
            temp1.orderheaderkey,
            temp1.txn_id,
            temp1.processing_status
    ) erlist
    WHERE 
        erlist.txn_id = raw.txn_id 
        AND erlist.orderheaderkey = raw.order_header_key 
        AND erlist.shipmentkey = raw.shipment_key
        AND erlist.shipmentcontainerkey = raw.shipment_container_key
        AND raw.processing_status IN (''Failed'', ''Pending'');

    -- Count errors
    SELECT COUNT(*)
    INTO OMSErrorCount
    FROM RAW.RAW_ORDER_SHIPMENT_LINE
    WHERE imported_date = :CURRENTDATETIME 
    AND processing_status = ''Failed''
    AND txn_id = :INPUTTRANSACTIONID;
    
    END IF;

    -- Check for errors and set message
    IF (OMSErrorCount > 0 OR OMSCount = 0) THEN
        IF (OMSErrorCount > 0) THEN
            FinalStatus := ''er_records'';
            message := TO_VARCHAR(OMSCount) || '' Records from OMS Shipment Lines have business validation errors'';
        ELSEIF (OMSCount = 0) THEN
            FinalStatus := ''no_records'';
            message := ''OMS Order Shipment Line Have No Records'';
        END IF;
    END IF;

SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_SHIPMENT_CONTAINER has been Completed'');
RETURN finalStatus;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_SHIPMENT_CONTAINER has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
   
END;
';
CREATE PROCEDURE "USP_BIZ_VALIDATION_ORDER_SHIPMENT_LINE"("CURRENTDATETIME" TIMESTAMP_NTZ(9))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS 'DECLARE
    SourceRefErrorMsg STRING DEFAULT '''';
    OrderErrorMsg STRING DEFAULT '''';
    SkuErrorMsg STRING DEFAULT '''';
    SourceErrorMsg STRING DEFAULT '''';
    CurrencyErrorMsg STRING DEFAULT '''';
    CustomerErrorMsg STRING DEFAULT '''';
    ShippingMethodErrorMsg STRING DEFAULT '''';
    OrderStatusErrorMsg STRING DEFAULT '''';
    PaymentAmountErrorMsg STRING DEFAULT '''';
    PaymentDateErrorMsg STRING DEFAULT '''';
    EditSourceRefErrorMsg STRING DEFAULT '''';
    ToAddressErrorMsg STRING DEFAULT '''';
    FromAddressErrorMsg STRING DEFAULT '''';
    OrderLineErrorMsg STRING DEFAULT '''';
    OrderReleaseErrorMsg STRING DEFAULT '''';
    message STRING DEFAULT '''';
    FinalStatus STRING DEFAULT '''';
    ErrorCount INT DEFAULT 0;
    OMSCount INT DEFAULT 0;
    OMSErrorCount INT DEFAULT 0;
    DimErrorCount INT DEFAULT 0;
    TxnErrorCount INT DEFAULT 0;
    action STRING DEFAULT ''CREATE'';
    amendment_topic STRING DEFAULT '''';
    amendment_note STRING DEFAULT '''';
    domesticSource STRING DEFAULT ''domestic'';
    internationalSource STRING DEFAULT ''international'';
    HybrisOrderCount INT DEFAULT 0;
    InvalidOrderStatus STRING DEFAULT ''CHECKED_INVALID'';

BEGIN
  -- Initialize variables
  SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_SHIPMENT_LINE has been Started'');
  FinalStatus := '''';
  OrderErrorMsg := ''OrderHeader for [ERRORITEM]   Header_Key not found'';
  OrderLineErrorMsg := ''OrderLine [ERRORITEM] Line_Key not found'';
  ToAddressErrorMsg := ''To Address [ERRORITEM] not found'';
  FromAddressErrorMsg := ''From Address [ERRORITEM] not found'';
  PaymentAmountErrorMsg := ''Payment Amount [ERRORITEM] not numeric'';
  PaymentDateErrorMsg := ''Payment Date [ERRORITEM] string cannot be converted to date'';
  OrderReleaseErrorMsg := ''Release Key [ERRORITEM] not found'';

  -- Count the OMS records
  SELECT COUNT(*) INTO :OMSCount FROM RAW.RAW_order_shipment_line;

  IF (OMSCount > 0) THEN
    -- Temporary tables in Snowflake are session-scoped and automatically dropped at the end of the session
    CREATE or replace TEMPORARY TABLE ErrorResultToLog (
      shipmentlinekey STRING,
      shipmentkey STRING,
      orderheaderkey STRING,
      txn_id STRING,
      processing_errortype STRING,
      processing_status STRING,
      processing_comment STRING
    );

    CREATE or replace TEMPORARY TABLE DimResultToLog (
      shipment_line_key STRING,
      shipment_key STRING,
      order_header_key STRING,
      pk_order_headerid STRING,
      pk_order_detailid STRING,
      stgsource STRING,
      sourceid STRING,
      order_release_key STRING,
      txn_id STRING
    );

    -- Insert data into DimResultToLog
    INSERT INTO DimResultToLog
    SELECT DISTINCT
      stg.shipment_line_key,
      stg.shipment_key,
      stg.order_header_key,
      toh.pk_order_headerid,
      tod.pk_order_detailid,
      CAST(ANALYTICS.fun_get_edw_brand_by_order_sellerorgcode(roh.seller_organization_code) || ''&'' || COALESCE(ANALYTICS.fun_get_edw_platform_by_order_entrytype(roh.ENTRY_TYPE), '''') AS STRING),
      src.pk_sourceid,
      roor.order_release_key,
      stg.txn_id
    FROM TRANSFORMED.STG_order_shipment_line stg
    LEFT JOIN RAW.RAW_order_header roh ON stg.order_header_key = roh.order_header_key
    LEFT JOIN RAW.RAW_order_release roor ON stg.order_release_key = roor.order_release_key
    LEFT JOIN (
      SELECT src.pk_sourceid, plt.platform_name, brd.BrandCodeForWHM, brd.context, src.locale
      FROM master.dim_source src
      INNER JOIN master.dim_platform plt ON plt.pk_platformid = src.fk_platformid
      INNER JOIN master.dim_brand brd ON brd.pk_brandid = src.fk_brandid
    ) src ON src.BrandCodeForWHM = roh.seller_organization_code AND src.platform_name = roh.entry_type
    LEFT JOIN ANALYTICS.txn_order_header toh ON toh.ext_order_id = stg.order_header_key AND src.pk_sourceid = toh.fk_sourceid AND toh.source_ref_num = roh.order_no
    LEFT JOIN ANALYTICS.txn_order_detail tod ON tod.fk_order_headerid = toh.pk_order_headerid AND tod.ext_line_id = stg.order_line_key;

    -- Insert data into ErrorResultToLog for Order Errors
    INSERT INTO ErrorResultToLog (shipmentlinekey, shipmentkey, orderheaderkey, txn_id, processing_errortype, processing_status, processing_comment)
    SELECT
      raw.shipment_line_key,
      raw.shipment_key,
      raw.order_header_key,
      raw.txn_id,
      ''Order'',
      ''Failed'',
      REPLACE(:OrderErrorMsg, ''[ERRORITEM]'', raw.order_header_key)
    FROM RAW.RAW_order_shipment_line raw
    INNER JOIN DimResultToLog dst ON raw.shipment_line_key = dst.shipment_line_key AND raw.shipment_key = dst.shipment_key AND raw.order_header_key = dst.order_header_key AND raw.txn_id = dst.txn_id
    WHERE pk_order_headerid IS NULL AND processing_status IN (''Failed'', ''Pending'');

    -- Insert data into ErrorResultToLog for Line Errors
    INSERT INTO ErrorResultToLog (shipmentlinekey, shipmentkey, orderheaderkey, txn_id, processing_errortype, processing_status, processing_comment)
    SELECT
      raw.shipment_line_key,
      raw.shipment_key,
      raw.order_header_key,
      raw.txn_id,
      ''Line'',
      ''Failed'',
      REPLACE(:OrderLineErrorMsg, ''[ERRORITEM]'', raw.order_line_key)
    FROM RAW.RAW_order_shipment_line raw
    INNER JOIN DimResultToLog dst ON raw.shipment_line_key = dst.shipment_line_key AND raw.shipment_key = dst.shipment_key AND raw.order_header_key = dst.order_header_key AND raw.txn_id = dst.txn_id
    WHERE pk_order_detailid IS NULL AND processing_status IN (''Failed'', ''Pending'');

    -- Insert data into ErrorResultToLog for Release Errors
    INSERT INTO ErrorResultToLog (shipmentlinekey, shipmentkey, orderheaderkey, txn_id, processing_errortype, processing_status, processing_comment)
    SELECT
      raw.shipment_line_key,
      raw.shipment_key,
      raw.order_header_key,
      raw.txn_id,
      ''Release'',
      ''Failed'',
      REPLACE(:OrderReleaseErrorMsg, ''[ERRORITEM]'', raw.order_release_key)
    FROM RAW.RAW_order_shipment_line raw
    INNER JOIN DimResultToLog dst ON raw.shipment_line_key = dst.shipment_line_key AND raw.shipment_key = dst.shipment_key AND raw.order_header_key = dst.order_header_key AND raw.txn_id = dst.txn_id
    WHERE dst.order_release_key IS NULL AND processing_status IN (''Failed'', ''Pending'');

    -- Update RAW_order_shipment_line with errors
    UPDATE RAW.RAW_order_shipment_line raw
    SET
      raw.processing_errortype = erlist.errortype,
      raw.processing_comment = erlist.comment,
      raw.processing_status = ''Failed''
    FROM (
      SELECT
        temp1.orderheaderkey, temp1.shipmentkey, temp1.shipmentlinekey, temp1.txn_id, temp1.processing_status,
        LISTAGG(temp2.processing_errortype, '','') WITHIN GROUP (ORDER BY temp2.processing_errortype) AS errortype,
        LISTAGG(temp2.processing_comment, '','') WITHIN GROUP (ORDER BY temp2.processing_comment) AS comment
      FROM ErrorResultToLog temp1
      INNER JOIN ErrorResultToLog temp2 ON temp1.txn_id = temp2.txn_id AND temp1.orderheaderkey = temp2.orderheaderkey AND temp1.shipmentkey = temp2.shipmentkey AND temp1.shipmentlinekey = temp2.shipmentlinekey
      WHERE temp1.processing_status = ''Failed''
      GROUP BY temp1.orderheaderkey, temp1.shipmentkey, temp1.shipmentlinekey, temp1.txn_id, temp1.processing_status
    ) erlist
    WHERE erlist.txn_id = raw.txn_id AND erlist.orderheaderkey = raw.order_header_key AND erlist.shipmentkey = raw.shipment_key AND erlist.shipmentlinekey = raw.shipment_line_key
    AND raw.processing_status IN (''Failed'', ''Pending'');

    -- Update RAW_order_shipment with success
    UPDATE RAW.RAW_order_shipment raw
    SET
      raw.processing_errortype = '''',
      raw.processing_comment = ''Ready For Processing''
    FROM DimResultToLog dst
    WHERE raw.shipment_key = dst.shipment_key AND raw.order_header_key = dst.order_header_key AND raw.txn_id = dst.txn_id
    AND dst.sourceid IS NOT NULL AND dst.stgsource IS NOT NULL
    AND dst.pk_order_headerid IS NOT NULL AND dst.order_header_key IS NOT NULL
    AND raw.processing_status IN (''Failed'', ''Pending'');

    -- Count the errors
    SELECT COUNT(*) INTO OMSErrorCount
    FROM RAW.RAW_order_shipment_line
    WHERE imported_date = :currentDatetime AND processing_status = ''Failed'';

  END IF;

  IF (:OMSErrorCount > 0 OR :OMSCount = 0) THEN
    IF (:OMSErrorCount > 0) THEN
      FinalStatus := ''er_records'';
      message := TO_VARCHAR(OMSCount) || '' Records from OMS Shipment Lines have business validation errors'';
    END IF;
    IF (:OMSCount = 0) THEN
       FinalStatus := ''no_records'';
       message := ''OMS Order Shipment Line Have No Records'';
    END IF;
  END IF;

COMMIT;
   
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_SHIPMENT_LINE has been Completed'');
RETURN finalStatus;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_SHIPMENT_LINE has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
     

END';

CREATE PROCEDURE "USP_INSERT_STG_ORDER_CHARGE_TRANSACTION"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    
    -- Truncate table stg_charge_transaction
    TRUNCATE TABLE transformed.stg_order_charge_transaction;

     CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
        -- Insert data into stg_charge_transaction
        create or replace temporary table transformed.stg_charge_transaction_temp1  as 
        SELECT DISTINCT
            rooh.charge_transaction_key,
            charge_type,
            transfer_from_oh_key,
            transfer_to_oh_key,
            status,
            credit_amount,
            debit_amount,
            book_amount,
            open_authorized_amount,
            request_amount,
            distributed_amount,
            settled_amount,
            authorization_id,
            authorization_expiration_date,
            order_invoice_key,
            order_header_key,
            payment_key,
            audit_transaction_id,
            user_exit_status,
            execution_date,
            is_collection_date_firm,
            collection_date,
            hold_against_book,
            in_person,
            void_transaction,
            postponed_amount,
            offline_status,
            call_for_auth_status,
            cash_back_amount,
            payment_entry_type,
            async_request_identifier,
            for_async_request_identifier,
            reason_code,
            createts,
            rooh.modifyts,
            createuserid,
            modifyuserid,
            createprogid,
            modifyprogid,
            lockid,
            rooh.imported_date,
            txn_id
        FROM 
            raw.raw_order_charge_transaction as rooh
        INNER JOIN (
            SELECT DISTINCT 
                MIN(modifyts) as modifyts,
                charge_transaction_key 
            FROM 
                raw.raw_order_charge_transaction 
            WHERE 
                processing_status IN (''Pending'',''Failed'') 
            GROUP BY 
                charge_transaction_key 
        ) as prelines  
        ON 
            prelines.modifyts = rooh.modifyts 
            AND rooh.charge_transaction_key = prelines.charge_transaction_key 
        WHERE 
            processing_status IN (''Pending'',''Failed'') AND rooh.txn_id is not null;
        
        -- Delete duplicate records
            create or replace temporary table transformed.stg_charge_transaction_temp2 as 
        WITH src AS (
        SELECT charge_transaction_key,modifyts,
               ROW_NUMBER() OVER (Partition By charge_transaction_key Order By charge_transaction_key,modifyts)  AS     
          revision
        FROM transformed.stg_charge_transaction_temp1
        )
        SELECT h.*
        FROM transformed.stg_charge_transaction_temp1 AS h
        INNER JOIN src ON src.revision = 1
        AND h.charge_transaction_key = src.charge_transaction_key
        AND h.modifyts = src.modifyts;
      Insert into transformed.stg_order_charge_transaction
      select * from transformed.stg_charge_transaction_temp2;
    
     CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    COMMIT;    
    RETURN ''usp_insert_stg_charge_transaction executed successfully'';

EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_CHARGE_TRANSACTION'';
            -- Return error message

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_CONTAINER_DETAILS"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

    -- Truncate the staging table
    TRUNCATE TABLE transformed.stg_ORDER_container_details;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );

    -- Insert into stg_order_container_details
    create or replace temporary table  transformed.stg_order_container_details_temp1 as
    SELECT 
        raw.container_details_key,
        raw.order_release_key,
        raw.order_release_status_key,
        raw.shipment_container_key,
        raw.order_line_key,
        raw.order_header_key,
        raw.shipment_key,
        raw.shipment_line_key,
        raw.country_of_origin,
        raw.item_id,
        raw.uom,
        raw.product_class,
        raw.quantity,
        raw.quantity_placed,
        raw.enterprise_key,
        raw.orig_order_line_schedule_key,
        raw.fifo_no,
        raw.lockid,
        raw.createts,
        raw.modifyts,
        raw.createuserid,
        raw.modifyuserid,
        raw.createprogid,
        raw.modifyprogid,
        raw.extn_upc_item_id,
        raw.imported_date,
        raw.txn_id
    FROM raw.raw_ORDER_container_details raw
    INNER JOIN (
        SELECT DISTINCT 
            container_details_key,
            shipment_container_key,
            shipment_key,
            shipment_line_key,
            order_header_key,
            order_line_key,
            MIN(modifyts) AS modifyts
        FROM raw.raw_ORDER_container_details
        WHERE processing_status IN (''Pending'', ''Failed'')
        GROUP BY 
            container_details_key,
            shipment_container_key,
            shipment_key,
            shipment_line_key,
            order_header_key,
            order_line_key
    ) prelines
    ON raw.modifyts = prelines.modifyts 
    AND raw.container_details_key = prelines.container_details_key
    AND raw.order_line_key = prelines.order_line_key
    WHERE raw.processing_status IN (''Pending'', ''Failed'') AND raw.txn_id is not null;

    -- Delete duplicate records
    
    create or replace temporary table transformed.stg_order_container_details_temp2 as 
        WITH src AS (
    SELECT  
    container_details_key,shipment_container_key,
    shipment_key,shipment_line_key,order_header_key,order_line_key,modifyts,Row_Number() over (Partition By container_details_key,shipment_container_key,shipment_key,shipment_line_key,order_header_key,order_line_key
    Order By container_details_key,shipment_container_key,shipment_key,
     shipment_line_key,order_header_key,order_line_key,modifyts) as revision 
    FROM transformed.stg_order_container_details_temp1
    )
    SELECT h.*
    FROM transformed.stg_order_container_details_temp1 AS h
    INNER JOIN src ON src.revision = 1
     and src.container_details_key = h.container_details_key and 
		src. shipment_container_key = h.shipment_container_key and 
		src. shipment_key = h.shipment_key and 
		src. shipment_line_key = h.shipment_line_key and 
		src. order_header_key = h.order_header_key and 
		src. order_line_key = h.order_line_key AND h.modifyts = src.modifyts;

        insert into transformed.stg_ORDER_container_details
        select * from transformed.stg_order_container_details_temp2;
        
    -- -- Get count of records to be processed
        SELECT COUNT(*)
        INTO :toBeProcessedRecordCount
        FROM transformed.stg_ORDER_container_details;

    -- Update log_files_import_status table
        UPDATE analytics.log_files_import_status lofis
        SET lofis.to_be_processed = :toBeProcessedRecordCount
        WHERE lofis.file_name = ''YFS_CONTAINER_DETAILS'';

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    COMMIT;      
    RETURN ''usp_insert_stg_ORDER_container_details executed successfully'';
    EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_CONTAINER_DETAILS'';
    
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                 ''SQLCODE'', sqlcode,
                                 ''SQLERRM'', sqlerrm,
                                 ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
        
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_CREDIT_CARD_TRANSACTION"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 

    BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    
        -- Truncate table stg_credit_card_transaction
        TRUNCATE TABLE transformed.stg_order_credit_card_transaction;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
        -- Insert data into stg_credit_card_transaction
        create or replace temporary table  transformed.stg_credit_card_transaction_temp1  as
        SELECT DISTINCT
            rooh.credit_card_transaction_key,
            charge_transaction_key,
            tran_type,
            tran_amount,
            tran_request_time,
            tran_return_code,
            tran_return_message,
            tran_return_flag,
            request_id,
            internal_return_code,
            internal_return_flag,
            internal_return_message,
            auth_amount,
            auth_code,
            auth_avs,
            auth_return_code,
            auth_return_flag,
            auth_return_message,
            auth_time,
            parent_key,
            reference1,
            reference2,
            cvv_auth_code,
            createts,
            rooh.modifyts,
            createuserid,
            modifyuserid,
            createprogid,
            modifyprogid,
            lockid,
            rooh.imported_date,
            txn_id
        FROM 
            raw.raw_order_credit_card_transaction as rooh
        INNER JOIN (
            SELECT DISTINCT 
                MIN(modifyts) as modifyts,
                credit_card_transaction_key 
            FROM 
                raw.raw_order_credit_card_transaction 
            WHERE 
                processing_status IN (''Pending'',''Failed'') 
            GROUP BY 
                credit_card_transaction_key 
        ) as prelines  
        ON 
            prelines.modifyts = rooh.modifyts 
            AND rooh.credit_card_transaction_key = prelines.credit_card_transaction_key 
        WHERE 
            processing_status IN (''Pending'',''Failed'') AND rooh.txn_id is not null;
        
        -- Delete duplicate records
            create or replace temporary table transformed.stg_credit_card_transaction_temp2 as 
        WITH src AS (
        SELECT credit_card_transaction_key,modifyts,
               ROW_NUMBER() OVER (Partition By credit_card_transaction_key
	   			Order By credit_card_transaction_key,modifyts)  AS revision
        FROM transformed.stg_credit_card_transaction_temp1
        )
        SELECT h.*
        FROM transformed.stg_credit_card_transaction_temp1 AS h
        INNER JOIN src ON src.revision = 1
        AND h.credit_card_transaction_key = src.credit_card_transaction_key 
            AND h.modifyts = src.modifyts;

            insert into transformed.stg_order_credit_card_transaction
            select * from transformed.stg_credit_card_transaction_temp2;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    commit;
            
    RETURN ''usp_insert_stg_credit_card_transaction executed successfully'';
    EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_CREDIT_CARD_TRANSACTION'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_CUSTOMER_PERSON_INFO"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    WarnigCount INT;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

     CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
    
    -- Create a temporary table for DuplicateResultToLog
    CREATE or replace temporary  TABLE transformed.DuplicateResultToLog AS
    SELECT
        stg.Source AS stagesourceref,
        cust.pk_customerid AS custid
    FROM TRANSFORMED.STG_CUSTOMER_PERSON_INFO stg
    LEFT JOIN ANALYTICS.customer cust
     ON stg.SourceRefNum = cust.source_ref_num  and stg.SourceID = cust.fk_sourceid;

    -- -- Calculate the warning count
    SELECT COUNT (*) into  :WarnigCount
    FROM transformed.DuplicateResultToLog
    WHERE stagesourceref IS NOT NULL AND custid IS NOT NULL;

    ---If warning count is greater than 0, update processing_status to ''Rejected''
        IF (:WarnigCount > 0) THEN
        
            -- UPDATE raw.raw_ORDER_customer_person_info roh SET
            -- roh.processing_status = ''Rejected'',
            -- roh.processing_comment = ''Customer already exist'',
            -- roh.processing_errortype = ''''
            -- FROM (SELECT 
            -- roh.PERSON_INFO_KEY,
            -- roh.fk_sourceid
            -- FROM raw.raw_ORDER_customer_person_info roh
            -- JOIN transformed.stg_ORDER_customer_person_info stg
            -- ON stg.fk_sourceid = roh.fk_sourceid
            -- JOIN transformed.DuplicateResultToLog dlog
            -- ON dlog.stagesourceref = roh.PERSON_INFO_KEY
            -- WHERE roh.processing_status IN (''Pending'', ''Failed'')
            -- AND dlog.stagesourceref IS NOT NULL
            -- AND dlog.custid IS NOT NULL)cte
            -- WHERE roh.PERSON_INFO_KEY = cte.PERSON_INFO_KEY
            -- AND roh.fk_sourceid = cte.fk_sourceid;
            MERGE INTO  raw.raw_ORDER_customer_person_info roh
                USING (
                        SELECT roh.person_info_key, roh.fk_sourceid
                        FROM raw.raw_ORDER_customer_person_info roh
                        INNER JOIN transformed.stg_ORDER_customer_person_info stg 
                            ON stg.person_info_key = roh.person_info_key
                        INNER JOIN transformed.DuplicateResultToLog toh 
                            ON toh.stagesourceref = roh.person_info_key 
                            AND stg.fk_sourceid = roh.fk_sourceid
                        WHERE roh.processing_status IN (''Pending'', ''Failed'') 
                            AND toh.stagesourceref IS NOT NULL 
                            AND toh.custid IS NOT NULL
                            ) src
                            ON roh.person_info_key = src.person_info_key
                            AND roh.fk_sourceid = src.fk_sourceid
                            WHEN MATCHED THEN
                                UPDATE SET 
                                    roh.processing_status = ''Rejected'',
                                    roh.processing_comment = ''Customer already exist'',
                                    roh.processing_errortype = '''';

     END IF;

    -- Truncate the staging table
    TRUNCATE TABLE transformed.stg_ORDER_customer_person_info;

    -- Insert into stg_ORDER_customer_person_info
    create or replace temporary table  transformed.stg_ORDER_customer_person_info_temp1 as
    SELECT DISTINCT
        raw.person_info_key,
        person_id,
        title,
        first_name,
        middle_name,
        last_name,
        suffix,
        department,
        company,
        job_title,
        address_line1,
        address_line2,
        address_line3,
        address_line4,
        address_line5,
        address_line6,
        city,
        state,
        zip_code,
        country,
        day_phone,
        evening_phone,
        mobile_phone,
        beeper,
        other_phone,
        day_fax_no,
        evening_fax_no,
        emailid,
        alternate_emailid,
        preferred_ship_address,
        http_url,
        use_count,
        verification_status,
        is_address_verified,
        latitude,
        longitude,
        tax_geo_code,
        error_txt,
        is_commercial_address,
        time_zone,
        lockid,
        createts,
        raw.modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        address_id,
        short_zip_code,
        raw.imported_date,
        raw.txn_id,
        raw.fk_sourceid,
        raw.source
    FROM raw.raw_ORDER_customer_person_info raw
    INNER JOIN (
        SELECT DISTINCT
            MIN(MODIFYTS) AS MODIFYTS,
            person_info_key
        FROM raw.raw_ORDER_customer_person_info 
        WHERE processing_status IN (''Pending'', ''Failed'')
        GROUP BY person_info_key
    ) prelines
    ON raw.person_info_key = prelines.person_info_key
    AND prelines.MODIFYTS = raw.MODIFYTS
    WHERE raw.processing_status IN (''Pending'', ''Failed'');

    -- Delete duplicate records
	create or replace temporary table transformed.stg_ORDER_customer_person_info_temp2 as 
		WITH src AS (
    SELECT person_info_key,modifyts,
           ROW_NUMBER() over (Partition By person_info_key Order By person_info_key,modifyts)  AS revision
    FROM transformed.stg_ORDER_customer_person_info_temp1
    )
    SELECT h.*
    FROM transformed.stg_ORDER_customer_person_info_temp1 AS h
    INNER JOIN src ON src.revision = 1
    AND h.person_info_key = src.person_info_key
    AND h.modifyts = src.modifyts;

   

    insert into transformed.stg_ORDER_customer_person_info
    select * from transformed.stg_ORDER_customer_person_info_temp2;
	
	
    -- Truncate the intermediate staging table
    TRUNCATE TABLE transformed.stg_customer_person_info;

    -- Insert into stg_ORDER_customer_person_info
     Insert into transformed.stg_customer_person_info(
        ID,
        CatalogSubscriber,
        Checkbox_For_New_Customers,
        CompanyName,
        Custom_Field_Custom1,
        Custom_Field_Custom2,
        Custom_Field_Custom3,
        Custom_Field_Custom4,
        Custom_Field_Custom5,
        Customer_IsAnonymous,
        Customer_Notes,
        CustomerType,
        EmailAddress,
        EmailSubscriber,
        FaxNumber,
        FirstDateVisited,
        FirstOrderDate,
        FirstName,
        LastLogin,
        LastName,
        PhoneNumber,
        pk_customerid,
        SourceRefNum,
        TaxExemptAccount,
        DateEntered,
        DateLastModified,
        OrderPlaced,
        SourceID,
        Validation_Status,
        Status,
        Preferred_Lang,
        Regd_Date,
        Title,
        Dob,
        GenderCode,
        Gender,
        MaritalStatusCode,
        MaritalStatus,
        EmailSecondary,
        phone1input,
        phone2input,
        phone4input,
        CreatedBy,
        ModifiedBy,
        EXTERNAL_ID,
        EXTERNAL_ACCOUNTID,
        ExternalEmail2,
        ExternalEmail1,
        MASTERCONTACT,
        LegalName,
        EMAIL_OPT_IN_STATUS,
        MASTERCUSTOMERID,
        DEDUP_TYPE,
        cust_tier,
        tax_id,
        IsNordstromCustomer,
        IsWilliamsonomaCustomer,
        business_cust,
        business_category,
        BusinessLocations,
        DesignTradeFlag,
        social_handle_facebook,
        social_handle_instagram,
        social_handle_twitter,
        phone1_sms,
        phone1_pref,
        phone1_region,
        phone2_sms,
        phone2_pref,
        phone2_region,
        phone3_sms,
        phone3_pref,
        phone3_region,
        phone4_sms,
        phone4_pref,
        phone4_region,
        HashedId,
        source
    )
    SELECT DISTINCT
        person_info_key as ID,
        NULL as   CatalogSubscriber,
        NULL as   Checkbox_For_New_Customers,
        company as   CompanyName,
        NULL as   Custom_Field_Custom1,
        NULL as   Custom_Field_Custom2,
        NULL as   Custom_Field_Custom3,
        NULL as   Custom_Field_Custom4,
        NULL as   Custom_Field_Custom5,
        NULL as   Customer_IsAnonymous,
        NULL as    Customer_Notes,
        ''GUEST'' as    CustomerType,
        NVL(emailid, '''') as    EmailAddress,
        NULL as EmailSubscriber,
        day_fax_no as  FaxNumber,
        NULL as FirstDateVisited,
        NULL as FirstOrderDate,
        first_name as FirstName,
		try_to_timestamp(createts,''yyyymmddhhmiss'') as LastLogin,
        last_name as LastName,
        day_phone as PhoneNumber,
        NULL pk_customerid,
        person_info_key as SourceRefNum,
        NULL  TaxExemptAccount,
		try_to_timestamp(createts,''yyyymmddhhmiss'') as  DateEntered,
		try_to_timestamp(createts,''yyyymmddhhmiss'') as  DateLastModified,
        NULL OrderPlaced,
        fk_sourceid SourceID,
		1 as Validation_Status,
        ''Active'' as Status,
        NULL as  Preferred_Lang,
		try_to_timestamp(createts,''yyyymmddhhmiss'') as Regd_Date,
        title as Title,
        NULL as  Dob,
        NULL as  GenderCode,
        NULL as  Gender,
        NULL as  MaritalStatusCode,
        NULL as  MaritalStatus,
        alternate_emailid as EmailSecondary,
        other_phone as   phone1input,
        evening_phone as   phone2input,
        mobile_phone as   phone4input,
        createuserid as   CreatedBy,
        modifyuserid as   ModifiedBy,
        person_info_key as         EXTERNAL_ID,
        NULL EXTERNAL_ACCOUNTID,
        NULL ExternalEmail2,
        NULL ExternalEmail1,
        NULL MASTERCONTACT,
        NULL LegalName,
        NULL EMAIL_OPT_IN_STATUS,
        NULL MASTERCUSTOMERID,
        NULL DEDUP_TYPE,
        NULL cust_tier,
        NULL tax_id,
        NULL IsNordstromCustomer,
        NULL IsWilliamsonomaCustomer,
        NULL business_cust,
        NULL business_category,
        NULL BusinessLocations,
        NULL DesignTradeFlag,
        NULL social_handle_facebook,
        NULL social_handle_instagram,
        NULL social_handle_twitter,
        NULL phone1_sms,
        NULL phone1_pref,
        NULL phone1_region,
        NULL phone2_sms,
        NULL phone2_pref,
        NULL phone2_region,
        NULL phone3_sms,
        NULL phone3_pref,
        NULL phone3_region,
        NULL phone4_sms,
        NULL phone4_pref,
        NULL phone4_region,
        NULL HashedId,
        source as source

    FROM   transformed.stg_ORDER_customer_person_info;

    -- Delete records from stg_ORDER_customer_person_info using USING clause
    -- DELETE  FROM transformed.stg_customer_person_info
    -- where (SourceRefNum,SourceID) in (select source_ref_num,fk_sourceid from ANALYTICS.customer);

    DELETE FROM transformed.stg_customer_person_info stg
        USING ANALYTICS.customer cust
        WHERE stg.SourceRefNum = cust.source_ref_num 
        AND stg.SourceID = cust.fk_sourceid;


    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    RETURN ''usp_insert_stg_ORDER_customer_person_info executed successfully'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_GTIN_DATA"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

        -- Truncate table stg_gtin_data
        TRUNCATE TABLE transformed.stg_order_gtin_data;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
        -- Insert data into stg_gtin_data
        create or replace temporary table  transformed.stg_gtin_data_temp as 
        SELECT DISTINCT
            rooh.GTIN_KEY,
            RESERVATION_REFERENCE,
            SKU_ITEM_ID,
            SHIP_NODE,
            UPC_ITEM_ID,
            QUANTITY,
            SCHEDULED_ORDER_LINE_KEY,
            ORDER_NO,
            ORDERLINE_RELEASE_KEY,
            PRIME_LINE_NO,
            SUB_LINE_NO,
            UNIT_OF_MEASURE,
            PRODUCT_CLASS,
            SEGMENT_TYPE,
            RESERVATION_EXPIRY_TIME,
            INTERNAL_STATUS,
            CREATETS,
            rooh.MODIFYTS,
            CREATEUSERID,
            MODIFYUSERID,
            CREATEPROGID,
            MODIFYPROGID,
            LOCKID,
            rooh.imported_date,
            txn_id
        FROM 
            raw.raw_order_gtin_data as rooh
        INNER JOIN (
            SELECT DISTINCT 
                MIN(modifyts) as modifyts,
                GTIN_KEY
            FROM 
                raw.raw_order_gtin_data
            WHERE 
                processing_status IN (''Pending'',''Failed'') 
            GROUP BY 
                GTIN_KEY 
        ) as prelines  
        ON 
            prelines.modifyts = rooh.modifyts 
            AND rooh.GTIN_KEY = prelines.GTIN_KEY 
        WHERE 
            processing_status IN (''Pending'',''Failed'') AND rooh.txn_id is not null;

        -- Delete duplicate records
        insert into transformed.stg_order_gtin_data 
       with src as(
            SELECT  
                GTIN_KEY,
                modifyts,TXN_ID,
                ROW_NUMBER() OVER (
                    PARTITION BY GTIN_KEY 
                    ORDER BY GTIN_KEY,modifyts,TXN_ID
                ) AS revision
            FROM 
                transformed.stg_gtin_data_temp
        ) 
        select DISTINCT h.* from transformed.stg_gtin_data_temp h
        inner join src on 
            src.revision = 1 AND
             h.GTIN_KEY = src.GTIN_KEY 
            AND h.modifyts = src.modifyts
            AND H.TXN_ID= SRC.TXN_ID;

    
    --Select the count of records to be processed
    SELECT COUNT(*) INTO :toBeProcessedRecordCount
    FROM transformed.stg_order_gtin_data;

    --Update the log table with the count of records to be processed
    UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    --SET to_be_processed = (SELECT COUNT(*) FROM transformed.stg_gtin_data)
    WHERE file_name = ''EXTN_GTIN_DATA'';


    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    COMMIT;  
    RETURN ''usp_insert_stg_gtin_data executed successfully'';

  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''EXTN_GTIN_DATA'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
        
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_HEADER"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object OBJECT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

    -- Truncate the target staging table
    TRUNCATE TABLE transformed.stg_ORDER_header;

    -- Log the start of the staging process
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );

    -- Insert into the target staging table
    CREATE OR REPLACE TEMPORARY TABLE transformed.stg_ORDER_header_temp1 AS
    SELECT DISTINCT
        rooh.ORDER_HEADER_KEY, ENTERPRISE_KEY, rooh.ORDER_NO, SOURCING_CLASSIFICATION, BUYER_ORGANIZATION_CODE,
        SELLER_ORGANIZATION_CODE, DOCUMENT_TYPE, BILL_TO_KEY, BILL_TO_ID, CUSTOMER_REWARDS_NO,
        VENDOR_ID, SHIP_TO_KEY, SHIP_TO_ID, SHIP_NODE, RECEIVING_NODE, BUYER_RECEIVING_NODE_ID,
        MARK_FOR_KEY, BUYER_MARK_FOR_NODE_ID, REQ_DELIVERY_DATE, REQ_CANCEL_DATE, REQ_SHIP_DATE,
        DEFAULT_TEMPLATE, DIVISION, ORDER_DATE, ORDER_TYPE, DRAFT_ORDER_FLAG, ORDER_PURPOSE,
        RETURN_OH_KEY_FOR_EXCHANGE, EXCHANGE_TYPE, PENDING_TRANSFER_IN, RETURN_BY_GIFT_RECIPIENT,
        ALLOCATION_RULE_ID, PRIORITY_CODE, PRIORITY_NUMBER, CONTACT_KEY, SCAC, CARRIER_SERVICE_CODE,
        CUSTCARRIER_ACCOUNT_NO, NOTIFY_AFTER_SHIPMENT_FLAG, CREATED_AT_NODE, HAS_DERIVED_CHILD,
        HAS_DERIVED_PARENT, NOTIFICATION_TYPE, NOTIFICATION_REFERENCE, ENTRY_TYPE, AUTHORIZED_CLIENT,
        ENTERED_BY, PERSONALIZE_CODE, HOLD_FLAG, HOLD_REASON_CODE, CUSTOMER_PO_NO, CUSTOMER_CUSTOMER_PO_NO,
        ORDER_NAME, PAYMENT_RULE_ID, TERMS_CODE, DELIVERY_CODE, CHARGE_ACTUAL_FREIGHT, TAX,
        TOTAL_AMOUNT, ORIGINAL_TOTAL_AMOUNT, ORIGINAL_TAX, CURRENCY, ENTERPRISE_CURRENCY,
        REPORTING_CONVERSION_RATE, REPORTING_CONVERSION_DATE, PAYMENT_STATUS, AUTHORIZATION_EXPIRATION_DATE,
        SEARCH_CRITERIA_1, SEARCH_CRITERIA_2, CUSTOMER_EMAILID, FOB, TOTAL_ADJUSTMENT_AMOUNT,
        OTHER_CHARGES, PRICE_PROGRAM_KEY, TAXPAYER_ID, TAX_JURISDICTION, TAX_EXEMPT_FLAG,
        TAX_EXEMPTION_CERTIFICATE, PURPOSE, INVOICE_COMPLETE, ORDER_CLOSED, NEXT_ALERT_TS,
        DO_NOT_CONSOLIDATE, CHAIN_TYPE, ADJUSTMENT_INVOICE_PENDING, AUTO_CANCEL_DATE, SALE_VOIDED,
        IS_SHIP_COMPLETE, IS_LINE_SHIP_COMPLETE, IS_SHIP_SINGLE_NODE, IS_LINE_SHIP_SINGLE_NODE,
        CANCEL_ORDER_ON_EXCP_FLAG, OPTIMIZATION_TYPE, PURGE_HISTORY_DATE, PRICING_CLASSIFICATION_CODE,
        SOURCE_TYPE, SOURCE_KEY, LINKED_SOURCE_KEY, ORIGINAL_CONTAINER_KEY, SOLD_TO_KEY, TEAM_CODE,
        LEVEL_OF_SERVICE, NEXT_ITER_SEQ_NO, NEXT_ITER_DATE, HRS_BEFORE_NEXT_ITER, CREATETS,
        rooh.MODIFYTS, CREATEUSERID, MODIFYUSERID, CREATEPROGID, MODIFYPROGID, LOCKID,
        DEPARTMENT_CODE, BUYER_USER_ID, RECREATE_AUTHORIZATIONS, CUSTOMER_CONTACT_ID, OPPORTUNITY_KEY,
        IS_EXPIRATION_DATE_OVERRIDDEN, EXPIRATION_DATE, APPROVAL_CYCLE, IN_STORE_PAYMENT_REQUIRED,
        IMMEDIATE_SETTLEMENT_VALUE, CUSTOMER_AGE, CART_ID, ROLLOUT_VERSION, ALL_ADDRESSES_VERIFIED,
        COMPL_GIFT_BOX_QTY, NO_OF_AUTH_STRIKES, SOURCE_IP_ADDRESS, CUSTOMER_FIRST_NAME,
        CUSTOMER_LAST_NAME, CUSTOMER_PHONE_NO, CUSTOMER_ZIP_CODE, INDEX_VERSION, EXTN_CUSTOMER_TYPE,
        EXTN_CUSTOMER_ID, EXTN_CBA_SHIP_LABEL, EXTN_AMAZON_TFM, EXTN_TFM_SHIP_STATUS,
        EXTN_FINANCED_BY_AFFIRM, EXTN_RISK_STATUS, EXTN_SALES_REP_CUST_ID, EXTN_LATEST_SHIP_DATE,
        EXTN_LATEST_DELIVERY_DATE, EXTN_MARKET_PLACE_ID, EXTN_ORDER_STATUS, EXTN_IS_PRIME,
        EXTN_GA_TAG_ID, EXTN_FRAUD_STATUS, EXTN_ORDER_LOCALE_CODE, EXTN_SHIPTO_FIRSTNAME,
        EXTN_SHIPTO_LASTNAME, EXTN_SHIPTO_ZIPCODE, EXTN_GIFTEE_FULL_NAME, EXTN_GIFTEE_EMAIL_ID,
        EXTN_SMS_OPT_IN, EXTN_RETURN_CONFIRMED_BY, EXTN_EDI_GCN, EXTN_PK_HEADER_KEY, EXTN_MERCHANT_ID,
        EXTN_IS_AVALARA, EXTN_REQ_CANCEL_DATE, EXTN_IS_EMAIL_SENT, EXTN_IS_TXN_COMMITTED,
        EXTN_TAX_TXN_DATE, EXTN_LAST_REFUND_TXN_CODE, EXTN_REFUND_TXN_CODE, EXTN_MIN_ESTIMATED_DELIVERY_DATE,
        EXTN_MAX_ESTIMATED_DELIVERY_DATE, EXTN_APPLY_MIGRATION_HOLD, EXTN_SIGNIFYD_ORDER_ID,
        EXTN_PRIMARY_REASON, EXTN_SECONDARY_REASON, EXTN_SALES_ENTRY_TYPE, EXTN_SALES_ORDER_TYPE,
        EXTN_WARRANTY_ORDER_NO, EXTN_SELLER_PAYMENT_TYPE, order_status, extn_brand, extn_sub_order_type,
        extn_order_total, txn_id, rooh.imported_date 
    FROM raw.raw_ORDER_header AS rooh 
    INNER JOIN (
        SELECT DISTINCT
            MIN(MODIFYTS) AS MODIFYTS, ORDER_HEADER_KEY, ORDER_NO
        FROM raw.raw_ORDER_header
        WHERE processing_status IN (''Pending'', ''Failed'')
        GROUP BY ORDER_HEADER_KEY, ORDER_NO
    ) AS prelines
    ON prelines.MODIFYTS = rooh.MODIFYTS
    AND rooh.ORDER_NO = prelines.ORDER_NO
    AND rooh.ORDER_HEADER_KEY = prelines.ORDER_HEADER_KEY 
    WHERE rooh.processing_status IN (''Pending'', ''Failed'') AND rooh.txn_id is not null
    
--     and rooh.order_no in(
--     ''UJ10424395'',
-- ''UJ10427239'',
-- ''UJ10427015'',
-- ''UJ10424026'',
-- ''UJ10427015'')
    --limit 2000
    ;
    

    INSERT INTO  transformed.stg_ORDER_header 
    (            
ORDER_HEADER_KEY,            
ENTERPRISE_KEY,            
ORDER_NO,            
SOURCING_CLASSIFICATION,            
BUYER_ORGANIZATION_CODE,            
SELLER_ORGANIZATION_CODE,            
DOCUMENT_TYPE,            
BILL_TO_KEY,            
BILL_TO_ID,            
CUSTOMER_REWARDS_NO,            
VENDOR_ID,            
SHIP_TO_KEY,            
SHIP_TO_ID,            
SHIP_NODE,            
RECEIVING_NODE,            
BUYER_RECEIVING_NODE_ID,            
MARK_FOR_KEY,            
BUYER_MARK_FOR_NODE_ID,            
REQ_DELIVERY_DATE,            
REQ_CANCEL_DATE,            
REQ_SHIP_DATE,            
DEFAULT_TEMPLATE,            
DIVISION,            
ORDER_DATE,            
ORDER_TYPE,            
DRAFT_ORDER_FLAG,            
ORDER_PURPOSE,            
RETURN_OH_KEY_FOR_EXCHANGE,            
EXCHANGE_TYPE,            
PENDING_TRANSFER_IN,            
RETURN_BY_GIFT_RECIPIENT,            
ALLOCATION_RULE_ID,            
PRIORITY_CODE,            
PRIORITY_NUMBER,            
CONTACT_KEY,            
SCAC,            
CARRIER_SERVICE_CODE,            
CUSTCARRIER_ACCOUNT_NO,            
NOTIFY_AFTER_SHIPMENT_FLAG,            
CREATED_AT_NODE,            
HAS_DERIVED_CHILD,            
HAS_DERIVED_PARENT,            
NOTIFICATION_TYPE,            
NOTIFICATION_REFERENCE,            
ENTRY_TYPE,            
AUTHORIZED_CLIENT,            
ENTERED_BY,            
PERSONALIZE_CODE,            
HOLD_FLAG,            
HOLD_REASON_CODE,            
CUSTOMER_PO_NO,            
CUSTOMER_CUSTOMER_PO_NO,            
ORDER_NAME,            
PAYMENT_RULE_ID,            
TERMS_CODE,            
DELIVERY_CODE,            
CHARGE_ACTUAL_FREIGHT,            
TAX,            
TOTAL_AMOUNT,            
ORIGINAL_TOTAL_AMOUNT,            
ORIGINAL_TAX,            
CURRENCY,            
ENTERPRISE_CURRENCY,            
REPORTING_CONVERSION_RATE,            
REPORTING_CONVERSION_DATE,            
PAYMENT_STATUS,            
AUTHORIZATION_EXPIRATION_DATE,            
SEARCH_CRITERIA_1,            
SEARCH_CRITERIA_2,            
CUSTOMER_EMAILID,            
FOB,            
TOTAL_ADJUSTMENT_AMOUNT,            
OTHER_CHARGES,            
PRICE_PROGRAM_KEY,            
TAXPAYER_ID,            
TAX_JURISDICTION,            
TAX_EXEMPT_FLAG,            
TAX_EXEMPTION_CERTIFICATE,            
PURPOSE,            
INVOICE_COMPLETE,            
ORDER_CLOSED,            
NEXT_ALERT_TS,            
DO_NOT_CONSOLIDATE,            
CHAIN_TYPE,            
ADJUSTMENT_INVOICE_PENDING,            
AUTO_CANCEL_DATE,            
SALE_VOIDED,            
IS_SHIP_COMPLETE,            
IS_LINE_SHIP_COMPLETE,            
IS_SHIP_SINGLE_NODE,            
IS_LINE_SHIP_SINGLE_NODE,            
CANCEL_ORDER_ON_EXCP_FLAG,            
OPTIMIZATION_TYPE,            
PURGE_HISTORY_DATE,            
PRICING_CLASSIFICATION_CODE,            
SOURCE_TYPE,            
SOURCE_KEY,            
LINKED_SOURCE_KEY,            
ORIGINAL_CONTAINER_KEY,            
SOLD_TO_KEY,            
TEAM_CODE,            
LEVEL_OF_SERVICE,            
NEXT_ITER_SEQ_NO,            
NEXT_ITER_DATE,            
HRS_BEFORE_NEXT_ITER,            
CREATETS,            
MODIFYTS,            
CREATEUSERID,            
MODIFYUSERID,            
CREATEPROGID,            
MODIFYPROGID,            
LOCKID,            
DEPARTMENT_CODE,            
BUYER_USER_ID,            
RECREATE_AUTHORIZATIONS,            
CUSTOMER_CONTACT_ID,            
OPPORTUNITY_KEY,            
IS_EXPIRATION_DATE_OVERRIDDEN,            
EXPIRATION_DATE,            
APPROVAL_CYCLE,            
IN_STORE_PAYMENT_REQUIRED,            
IMMEDIATE_SETTLEMENT_VALUE,            
CUSTOMER_AGE,            
CART_ID,            
ROLLOUT_VERSION,            
ALL_ADDRESSES_VERIFIED,            
COMPL_GIFT_BOX_QTY,      
NO_OF_AUTH_STRIKES,            
SOURCE_IP_ADDRESS,            
CUSTOMER_FIRST_NAME,            
CUSTOMER_LAST_NAME,            
CUSTOMER_PHONE_NO,            
CUSTOMER_ZIP_CODE,            
INDEX_VERSION,            
EXTN_CUSTOMER_TYPE,            
EXTN_CUSTOMER_ID,            
EXTN_CBA_SHIP_LABEL,            
EXTN_AMAZON_TFM,            
EXTN_TFM_SHIP_STATUS,            
EXTN_FINANCED_BY_AFFIRM,            
EXTN_RISK_STATUS,            
EXTN_SALES_REP_CUST_ID,            
EXTN_LATEST_SHIP_DATE,            
EXTN_LATEST_DELIVERY_DATE,            
EXTN_MARKET_PLACE_ID,            
EXTN_ORDER_STATUS,        
EXTN_IS_PRIME,            
EXTN_GA_TAG_ID,            
EXTN_FRAUD_STATUS,            
EXTN_ORDER_LOCALE_CODE,            
EXTN_SHIPTO_FIRSTNAME,            
EXTN_SHIPTO_LASTNAME,            
EXTN_SHIPTO_ZIPCODE,            
EXTN_GIFTEE_FULL_NAME,            
EXTN_GIFTEE_EMAIL_ID,            
EXTN_SMS_OPT_IN,
EXTN_RETURN_CONFIRMED_BY,
EXTN_EDI_GCN,
EXTN_PK_HEADER_KEY,
EXTN_MERCHANT_ID,
EXTN_IS_AVALARA,
EXTN_REQ_CANCEL_DATE,
EXTN_IS_EMAIL_SENT,
EXTN_IS_TXN_COMMITTED,
EXTN_TAX_TXN_DATE,
EXTN_LAST_REFUND_TXN_CODE,
EXTN_REFUND_TXN_CODE,
EXTN_MIN_ESTIMATED_DELIVERY_DATE,
EXTN_MAX_ESTIMATED_DELIVERY_DATE,
EXTN_APPLY_MIGRATION_HOLD,
EXTN_SIGNIFYD_ORDER_ID,
EXTN_PRIMARY_REASON,
EXTN_SECONDARY_REASON,
EXTN_SALES_ENTRY_TYPE,
EXTN_SALES_ORDER_TYPE,
EXTN_WARRANTY_ORDER_NO,
EXTN_SELLER_PAYMENT_TYPE,
order_status,            
extn_brand,            
extn_sub_order_type,      extn_order_total,            
txn_id,            
imported_date            
) 
   select * from  
    (WITH src AS (
        SELECT ORDER_NO, modifyts,
               ROW_NUMBER() OVER (PARTITION BY ORDER_NO ORDER BY ORDER_NO, modifyts) AS revision
        FROM transformed.stg_ORDER_header_temp1
    )
    SELECT h.*
    FROM transformed.stg_ORDER_header_temp1 AS h
    INNER JOIN src ON src.revision = 1
    AND h.ORDER_NO = src.ORDER_NO
    AND h.modifyts = src.modifyts);

    -- Select the count of records to be processed
    SELECT COUNT(*) INTO :toBeProcessedRecordCount
    FROM  transformed.stg_ORDER_header;

    -- Update the log table with the count of records to be processed
    UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    WHERE file_name = ''YFS_ORDER_HEADER'';

    -- Log the completion of the staging process
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    RETURN ''usp_insert_stg_ORDER_header executed successfully'';

COMMIT;

RETURN ''Success'';

EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
    SET processed = 0,
        status = ''Failed''
    WHERE file_name = ''YFS_ORDER_HEADER'';
    
    -- Create error object
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    -- Log the failure
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_HEADER_CHARGES"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object OBJECT;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

    -- Truncate the target staging table
    TRUNCATE TABLE transformed.stg_ORDER_header_charges;

     -- Log the start of the staging process
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );

    -- Insert into the target staging table
    create or replace temporary table  transformed.stg_ORDER_header_charges_temp1 as
    SELECT DISTINCT top 5000
        raw.header_charges_key,
        raw.header_key,
        record_type,
        charge_category,
        charge_name,
        reference,
        charge,
        invoiced_charge,
        original_charge,
        is_manual,
        createts,
        raw.modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        extn_charge_description,
        extn_coupon_code,
        RAW.imported_date,
        txn_id
    FROM raw.raw_ORDER_header_charges raw
    INNER JOIN (
        SELECT DISTINCT
            MIN(MODIFYTS) AS MODIFYTS,
            header_charges_key,
            header_key
        FROM raw.raw_ORDER_header_charges
        WHERE processing_status IN (''Pending'', ''Failed'')
        GROUP BY header_charges_key, header_key
    ) AS prerecords
    ON raw.header_charges_key = prerecords.header_charges_key
    AND raw.header_key = prerecords.header_key
    AND prerecords.MODIFYTS = raw.MODIFYTS
    WHERE raw.processing_status IN (''Pending'', ''Failed'')
    AND raw.record_type = ''ORD'' AND raw.txn_id is not null;
    

    create or replace temporary table transformed.stg_ORDER_header_charges_temp2 as 
    WITH src AS (
    SELECT header_charges_key,modifyts,
           ROW_NUMBER() OVER (Partition By header_charges_key Order By header_charges_key,modifyts)  AS revision
    FROM transformed.stg_ORDER_header_charges_temp1
    )
    SELECT h.*
    FROM transformed.stg_ORDER_header_charges_temp1 AS h
    INNER JOIN src ON src.revision = 1
    AND h.header_charges_key = src.header_charges_key
    AND h.modifyts = src.modifyts;

    insert into transformed.stg_ORDER_header_charges      
	 (
	 header_charges_key,
        header_key,
        record_type,
        charge_category,
        charge_name,
        reference,
        charge,
        invoiced_charge,
        original_charge,
        is_manual,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        extn_charge_description,
        extn_coupon_code,
        imported_date,
        txn_id) 
    select 
        header_charges_key,
        header_key,
        record_type,
        charge_category,
        charge_name,
        reference,
        charge,
        invoiced_charge,
        original_charge,
        is_manual,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        extn_charge_description,
        extn_coupon_code,
        imported_date,
        txn_id from transformed.stg_ORDER_header_charges_temp2;

    -- Select the count of records to be processed
        SELECT COUNT(*) INTO :toBeProcessedRecordCount
        FROM transformed.stg_ORDER_header_charges;

    -- Update the log table with the count of records to be processed
        UPDATE analytics.log_files_import_status
        SET to_be_processed = :toBeProcessedRecordCount
        WHERE file_name = ''YFS_HEADER_CHARGES'';

        -- Log the completion of the staging process
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);


    RETURN ''usp_insert_stg_ORDER_header_charges executed successfully'';
    EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
    SET processed = 0,
        status = ''Failed''
    WHERE file_name = ''YFS_ORDER_HEADER'';
    
    -- Create error object
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    -- Log the failure
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_HISTORICAL_PERSON_INFO_MAP"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
  RESULT VARCHAR ;
  error_object VARIANT;
  start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

     CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );

   

  UPDATE raw.raw_order_historical_person_info_map
  SET
    processing_status = ''Rejected'',
    processing_comment = ''Already loaded by OMS extract with pkid:'' || TO_CHAR(ta.pk_addressid),
    processing_errortype = '''',
    data_engineer_verification = ''''
  FROM raw.raw_order_historical_person_info_map AS r
  INNER JOIN analytics.txn_address AS ta ON ta.ext_address_id = r.person_info_key AND ta.fk_address_typeid = r.address_type
  WHERE r.processing_status IN (''Pending'', ''Failed'');


  TRUNCATE TABLE transformed.stg_ORDER_historical_person_info_map;


  create or replace temporary table transformed.stg_ORDER_historical_person_info_map_temp1
  as
  SELECT
    extn_parent_order_no,
    order_header_key,
    order_no,
    raw.person_info_key,
    key_desc,
    address_type,
    order_name,
    order_type,
    entry_type,
    EMAIL_PRIMARY,
    customer_emailid,
    txn_id,
    imported_date,
    processing_status,
    processing_errortype,
    processing_comment,
    data_engineer_verification,
    raw.modifyts
  FROM raw.raw_order_historical_person_info_map AS raw
  INNER JOIN (
    SELECT DISTINCT
      MIN(MODIFYTS) AS MODIFYTS,
      person_info_key
    FROM
      raw.raw_order_historical_person_info_map
    WHERE
      processing_status IN (''Pending'', ''Failed'')
    GROUP BY
      person_info_key
  ) AS prelines ON raw.person_info_key = prelines.person_info_key AND prelines.MODIFYTS = raw.MODIFYTS
  WHERE
    processing_status IN (''Pending'', ''Failed'');

    create or replace temporary table transformed.stg_ORDER_historical_person_info_map_temp2 as 
   
    WITH src AS (
    SELECT person_info_key,
           address_type,
           ROW_NUMBER() OVER (PARTITION BY person_info_key ORDER BY person_info_key, address_type) AS revision
    FROM transformed.stg_ORDER_historical_person_info_map_temp1
    )
    SELECT h.*
    FROM transformed.stg_ORDER_historical_person_info_map_temp1 AS h
    INNER JOIN src ON src.revision = 1
    AND h.person_info_key = src.person_info_key
    AND h.address_type = src.address_type;

    insert into transformed.stg_ORDER_historical_person_info_map
    select * from transformed.stg_ORDER_historical_person_info_map_temp2;


  UPDATE raw.raw_order_historical_person_info_map 
  SET
   processing_status = ''Failed'',
   processing_comment = ''Record not found in Historical Load: raw_ORDER_historical_person_info'',
   processing_errortype = ''Historical Person Info'',
   data_engineer_verification = ''Auto verification by sp is :Blocked''
  FROM
    raw.raw_order_historical_person_info_map AS r
    LEFT JOIN raw.raw_ORDER_historical_person_info AS rh ON rh.person_info_key = r.person_info_key
  WHERE
    rh.person_info_key IS NULL
    AND r.processing_status IN (''Pending'', ''Failed'');


  UPDATE raw.raw_order_historical_person_info_map
  SET
    processing_status = ''Failed'',
    processing_comment = ''Record found in Historical Load: raw_ORDER_historical_person_info'',
    processing_errortype = ''Historical Person Info'',
    data_engineer_verification = ''Auto verification by sp is :Pending''
  FROM
    raw.raw_order_historical_person_info_map AS r
    LEFT JOIN raw.raw_ORDER_historical_person_info AS rh ON rh.person_info_key = r.person_info_key
  WHERE
    NOT rh.person_info_key IS NULL
    AND r.processing_status IN (''Pending'', ''Failed'');


    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
    
END;
';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_HOLD_TYPE"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
    BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    
        -- Truncate table stg_order_hold_type
    TRUNCATE TABLE transformed.stg_ORDER_hold_type;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
        
        -- Insert data into stg_order_hold_type
        create or replace temporary table transformed.stg_order_hold_type_temp1  as 
        SELECT DISTINCT
            rooh.ORDER_HOLD_TYPE_KEY,
            rooh.ORDER_HEADER_KEY,
            rooh.ORDER_LINE_KEY,
            rooh.HOLD_TYPE,
            rooh.LAST_HOLD_TYPE_DATE,
            rooh.REASON_TEXT,
            rooh.TRANSACTION_ID,
            rooh.ORDER_AUDIT_KEY,
            rooh.STATUS,
            rooh.RESOLVER_USER_ID,
            rooh.CREATETS,
            rooh.MODIFYTS,
            rooh.CREATEUSERID,
            rooh.MODIFYUSERID,
            rooh.CREATEPROGID,
            rooh.MODIFYPROGID,
            rooh.LOCKID,
            rooh.imported_date,
            rooh.txn_id
        FROM 
            raw.raw_ORDER_hold_type as rooh
        INNER JOIN (
            SELECT DISTINCT 
                MIN(MODIFYTS)  AS MODIFYTS,
                ORDER_HOLD_TYPE_KEY,
                ORDER_HEADER_KEY,
                ORDER_LINE_KEY
            FROM 
                raw.raw_ORDER_hold_type    
            WHERE 
                processing_status IN (''Pending'',''Failed'')   
            GROUP BY 
                ORDER_HOLD_TYPE_KEY,
                ORDER_HEADER_KEY,
                ORDER_LINE_KEY  
        ) as prelines  
        ON 
            prelines.MODIFYTS = rooh.MODIFYTS 
            AND rooh.ORDER_HOLD_TYPE_KEY = prelines.ORDER_HOLD_TYPE_KEY 
            AND rooh.ORDER_HEADER_KEY = prelines.ORDER_HEADER_KEY   
            --and rooh.ORDER_LINE_KEY = prelines.ORDER_LINE_KEY  
        WHERE 
            processing_status IN (''Pending'',''Failed'') AND rooh.txn_id is not null;
        
        -- Delete duplicate records
        create or replace temporary table transformed.stg_order_hold_type_temp2 as 
        WITH src AS (
        SELECT ORDER_HOLD_TYPE_KEY,modifyts,
               ROW_NUMBER() OVER (Partition By ORDER_HOLD_TYPE_KEY
	   			Order By ORDER_HOLD_TYPE_KEY,modifyts)  AS revision
        FROM transformed.stg_order_hold_type_temp1
        )
        SELECT h.*
        FROM transformed.stg_order_hold_type_temp1 AS h
        INNER JOIN src ON src.revision = 1
        AND h.ORDER_HOLD_TYPE_KEY = src.ORDER_HOLD_TYPE_KEY 
                AND h.modifyts = src.modifyts;

         Insert into transformed.stg_ORDER_hold_type
         select * from transformed.stg_order_hold_type_temp2;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

        
    RETURN ''usp_insert_stg_order_hold_type Executed successfully'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_HOLD_TYPE'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_INBOX"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object VARIANT;
    --error_string STRING;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    
    -- Truncate table stg_ORDER_inbox
    TRUNCATE TABLE TRANSFORMED.stg_ORDER_inbox;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
    -- Insert data into stg_ORDER_inbox
    CREATE OR REPLACE TEMPORARY TABLE TRANSFORMED.stg_ORDER_inbox_temp AS
    SELECT DISTINCT 
    rooh.inbox_key
	,inbox_type
	,description
	,generated_on
	,queue_key
	,enterprise_key
	,shipnode_key
	,exception_type
	,auto_resolved_flag
	,resolution_date
	,priority
	,resolve_by
	,last_unassign_alert
	,last_unresolve_alert
	,locked_flag
	,locked_by_user_key
	,locked_on
	,parent_inbox_key
	,detail_description
	,list_description
	,status
	,active_flag
	,closed_on
	,followup_date
	,last_exceed_alert
	,exception_escalated_flag
	,owner_type
	,owner_key
	,assigned_to_user_key
	,consolidation_count
	,last_occurred_on
	,flow_name
	,api_name
	,sub_flow_name
	,view_id
	,error_reason
	,error_type
	,expiration_days
	,null  inbox_addnl_data
	,resolved_by_user_id
	,unresolve_realert_count
	,unassign_realert_count
	,lockid
	,createts
	,rooh.modifyts
	,createuserid
	,modifyuserid
	,createprogid
	,modifyprogid
	,count_request_key
	,count_program_name
	,wave_key
	,wave_no
	,supplier_key
	,order_header_key
	,order_no
	,shipment_key
	,shipment_no
	,load_no
	,item_id
	,order_line_key
	,work_order_key
	,work_order_no
	,move_request_key
	,location_id
	,bill_to_id
	,team_code
	,rooh.imported_date
	,txn_id
    FROM 
        RAW.raw_ORDER_inbox AS rooh
    INNER JOIN (
        SELECT DISTINCT 
            MIN(modifyts) AS modifyts,
            inbox_key 
        FROM 
            RAW.raw_ORDER_inbox  
        WHERE 
            processing_status IN (''Pending'',''Failed'') 
        GROUP BY 
            inbox_key 
    ) AS prelines  
    ON 
        prelines.modifyts = rooh.modifyts 
        AND rooh.inbox_key = prelines.inbox_key 
    WHERE 
        processing_status IN (''Pending'',''Failed'') AND rooh.txn_id is not null;
        
    -- Delete duplicate records
    INSERT INTO TRANSFORMED.stg_ORDER_inbox  
    WITH src AS (
        SELECT 
            inbox_key,
            txn_id,
            ROW_NUMBER() OVER (
                PARTITION BY inbox_key 
                ORDER BY inbox_key, txn_id
            ) AS revision
        FROM 
            TRANSFORMED.stg_ORDER_inbox_temp
    )  
    SELECT h.* FROM TRANSFORMED.stg_ORDER_inbox_temp h
    INNER JOIN src ON
        src.revision = 1 
        AND h.inbox_key = src.inbox_key 
        AND h.txn_id = src.txn_id;

    -- Select the count of records to be processed
    SELECT COUNT(*) INTO :toBeProcessedRecordCount
    FROM TRANSFORMED.stg_ORDER_inbox;

    -- Update the log table with the count of records to be processed
    UPDATE ANALYTICS.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    WHERE file_name = ''YFS_INBOX'';

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    COMMIT;
    RETURN ''usp_insert_stg_ORDER_inbox executed successfully'';
    
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_INBOX'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
                            
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_LINE"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object OBJECT;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN
    -- Truncate the staging table
    TRUNCATE TABLE TRANSFORMED.stg_ORDER_line;

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

    -- Log the start of the staging process
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );

    -- Insert into staging table
    CREATE OR REPLACE TEMPORARY TABLE TRANSFORMED.stg_ORDER_line_temp AS
    SELECT 
        rool.ORDER_LINE_KEY,    
        rool.ORDER_HEADER_KEY,    
        PRIME_LINE_NO,    
        SUB_LINE_NO,    
        LINE_TYPE,    
        ORDER_CLASS,    
        ITEM_ID,    
        ALTERNATE_ITEM_ID,    
        UOM,    
        PRODUCT_CLASS,    
        UNIT_PRICE,    
        COST_CURRENCY,    
        ORDERED_QTY,    
        BASIC_CAPACITY_REQUIRED,    
        OPTION_CAPACITY_REQUIRED,    
        DEPENDENT_ON_LINE_KEY,    
        CURRENT_WORK_ORDER_KEY,    
        DEPENDENCY_SHIPPING_RULE,    
        FILL_QUANTITY,    
        COMMITTED_QUANTITY,    
        DEPENDENCY_RATIO,    
        MAINTAIN_RATIO,    
        MERGE_NODE,    
        PARENT_OF_DEPENDENT_GROUP,    
        SOURCE_FROM_ORGANIZATION,    
        CHAINED_FROM_ORDER_LINE_KEY,    
        CHAINED_FROM_ORDER_HEADER_KEY,    
        DERIVED_FROM_ORDER_LINE_KEY,    
        DERIVED_FROM_ORDER_HEADER_KEY,    
        DERIVED_FROM_ORDER_RELEASE_KEY,    
        DISTRIBUTION_RULE_ID,    
        INVOICED_QUANTITY,    
        OVER_RECEIPT_QUANTITY,    
        RETURN_REASON,    
        SHIPNODE_KEY,    
        PROCURE_FROM_NODE,    
        SHIP_TO_KEY,    
        MARK_FOR_KEY,    
        BUYER_MARK_FOR_NODE_ID,    
        REQ_DELIVERY_DATE,    
        REQ_CANCEL_DATE,    
        REQ_SHIP_DATE,    
        SCAC,    
        CARRIER_SERVICE_CODE,    
        CARRIER_ACCOUNT_NO,    
        PICKABLE_FLAG,    
        SHIP_TOGETHER_NO,    
        HOLD_FLAG,    
        KIT_CODE,    
        HOLD_REASON_CODE,    
        OTHER_CHARGES,    
        LINE_TOTAL,    
        INVOICED_LINE_TOTAL,    
        INVOICED_EXTENDED_PRICE,    
        SETTLED_QUANTITY,    
        SETTLED_AMOUNT,    
        TAXABLE_FLAG,    
        TAX_EXEMPTION_CERTIFICATE,    
        DISCOUNT_TYPE,    
        DISCOUNT_REFERENCE,    
        GIFT_FLAG,    
        PERSONALIZE_FLAG,    
        PERSONALIZE_CODE,    
        DEPARTMENT_CODE,    
        CUSTOMER_ITEM,    
        CUSTOMER_ITEM_DESCRIPTION,    
        ITEM_WEIGHT,    
        ITEM_WEIGHT_UOM,    
        ITEM_DESCRIPTION,    
        ITEM_SHORT_DESCRIPTION,    
        RESERVATION_ID,    
        RESERVATION_POOL,    
        CUSTOMER_PO_NO,    
        CUSTOMER_PO_LINE_NO,    
        TAX,    
        DELIVERY_CODE,    
        ORIGINAL_ORDERED_QTY,    
        LIST_PRICE,    
        RETAIL_PRICE,    
        DISCOUNT_PERCENTAGE,    
        PACKLIST_TYPE,    
        SUPPLIER_ITEM,    
        SUPPLIER_ITEM_DESCRIPTION,    
        UNIT_COST,    
        UPC_CODE,    
        FOB,    
        MANUFACTURER_NAME,    
        MANUFACTURER_ITEM,    
        MANUFACTURER_ITEM_DESC,    
        COUNTRY_OF_ORIGIN,    
        ISBN,    
        HARMONIZED_CODE,    
        SHIP_TO_ID,    
        PRODUCT_LINE,    
        NMFC_CODE,    
        NMFC_CLASS,    
        NMFC_DESCRIPTION,    
        TAX_PRODUCT_CODE,    
        IMPORT_LICENSE_NO,    
        IMPORT_LICENSE_EXP_DATE,    
        ECCN_NO,    
        SCHEDULE_B_CODE,    
        SUPPLIER_CODE,    
        PURPOSE,    
        RECEIVING_NODE,    
        BUYER_RECEIVING_NODE_ID,    
        SHIPMENT_CONSOL_GROUP_ID,    
        ORIG_ORDER_LINE_KEY,    
        LINE_SEQ_NO,    
        SPLIT_QTY,    
        PRICING_DATE,    
        PIPELINE_KEY,    
        CONDITION_VARIABLE_1,    
        CONDITION_VARIABLE_2,    
        IS_PRICE_LOCKED,    
        IS_COST_OVERRIDDEN,    
        IS_CAPACITY_OVERRIDDEN,    
        INVOICE_COMPLETE,    
        DELIVERY_METHOD,    
        ITEM_GROUP_CODE,    
        CANNOT_COMPLETE_BEFORE_DATE,    
        CANNOT_COMPLETE_AFTER_DATE,    
        APPT_STATUS,    
        CAN_ADD_SERVICE_LINES,    
        PRICING_UOM,    
        CAPACITY_UOM,    
        PRICING_QUANTITY,    
        SHIPPED_QUANTITY,    
        FIXED_CAPACITY_QTY_PER_LINE,    
        FIXED_PRICING_QTY_PER_LINE,    
        WAIT_FOR_SEQ_LINE,    
        SCHED_FAILURE_REASON_CODE,    
        EARLIEST_SHIP_DATE,    
        EARLIEST_DELIVERY_DATE,    
        CANNOT_MEET_APPT,    
        PROMISED_APPT_START_DATE,    
        PROMISED_APPT_END_DATE,    
        SEGMENT,    
        SEGMENT_TYPE,    
        EARLIEST_SCHEDULE_DATE,    
        TIMEZONE,    
        IS_FORWARDING_ALLOWED,    
        IS_PROCUREMENT_ALLOWED,    
        RESHIP_PARENT_LINE_KEY,    
        BUNDLE_PARENT_ORDER_LINE_KEY,    
        IS_PRICE_INFO_ONLY,    
        LEVEL_OF_SERVICE,    
        FIRST_ITER_SEQ_NO,    
        LAST_ITER_SEQ_NO,    
        CREATETS,    
        rool.MODIFYTS,    
        CREATEUSERID,    
        MODIFYUSERID,    
        CREATEPROGID,    
        MODIFYPROGID,    
        LOCKID,    
        ORDERING_UOM,    
        PRICING_QUANTITY_CONV_FACTOR,    
        PRICING_QUANTITY_STRATEGY,    
        INVOICED_PRICING_QUANTITY,    
        IS_STANDALONE_SERVICE,    
        TRAN_DISCREPANCY_QTY,    
        RECEIVED_QUANTITY,    
        INVOICE_BASED_ON_ACTUALS,    
        ACTUAL_PRICING_QUANTITY,    
        FULFILLMENT_TYPE,    
        SERIAL_NO,    
        RESERVATION_MANDATORY,    
        IS_FIRM_PREDEFINED_NODE,    
        INTENTIONAL_BACKORDER,    
        FUTURE_AVAIL_DATE,    
        REPRICING_QUANTITY,    
        MIN_SHIP_BY_DATE,    
        KIT_QTY,    
        BOM_CONFIG_KEY,    
        BUNDLE_FULFILLMENT_MODE,    
        IS_GIFT_WRAP,    
        GROUP_SEQUENCE_NUM,    
        IN_STORE_PAYMENT_REQUIRED,    
        ITEM_NOT_EXIST,    
        DERIVED_FROM_EXT_ORD,    
        IS_ELIGIBLE_FOR_SHIP_DISC,    
        BACKORDER_NOTIFICATION_QTY,    
        IS_PRICE_MATCHED,    
        IS_PICK_UP_NOW,    
        ITEM_IS_IN_HAND,    
        DISPOSITION_CODE,    
        EXTN_MOD_REASON_CODE,    
        EXTN_MOD_REASON_DESC,    
        EXTN_ASN,    
        EXTN_PARENT_ORDER_NO,    
        EXTN_ITEM_ID,    
        EXTN_ORDER_ITEM_ID,    
        EXTN_PRICE_TYPE,
        EXTN_SECONDARY_RETURN_REASON,
        EXTN_APPLY_LABEL_FEE,
        EXTN_IS_ACTIVATION_COMPLETE,
        EXTN_ITEM_DESC,
        EXTN_RETURN_CARTON_COUNT,
        EXTN_ASN_QUANTITY,
        EXTN_LIGHT_COLOR,
        EXTN_LIGHT_TYPE,
        EXTN_NUMBER_OF_SECTIONS,
        EXTN_TOTAL_CARTONS,
        EXTN_TREE_HEIGHT,
        EXTN_TREE_HEIGHT_UOM,
        EXTN_APPLY_RESTOCKING_FEE,
        EXTN_RETURN_PICKUP_DATE,
        EXTN_PICKUP_CONFIRMATION_NO,
        EXTN_REFUND_SHIPPING_COST,
        EXTN_IS_FULFILLED_LINE,
        EXTN_MFG_WARRANTY_START_DATE,
        EXTN_MFG_WARRANTY_END_DATE,
        EXTN_TERM,
        EXTN_IS_INVOICE_REQUIRED,
        EXTN_PREM_GUARANTEE_END_DATE,
        EXTN_RETURN_DATE,
        EXTN_IS_EMAIL_SENT,
        EXTN_RETURN_REQUIRED,
        EXTN_PARENT_PRIME_LINE_NO,
        EXTN_PARENT_SUB_LINE_NO,
        EXTN_PREM_GUARANTEE_START_DATE,
        EXTN_RESHIP_UPCID,
        CASE
            WHEN extn_parent_order_line_sku LIKE ''%.0'' THEN REPLACE(extn_parent_order_line_sku, ''.0'', '''')
            ELSE extn_parent_order_line_sku
        END AS extn_parent_order_line_sku,
        imported_date,    
        txn_id,    
        order_line_status
        FROM raw.raw_ORDER_line AS rool
    INNER JOIN (
        SELECT DISTINCT MIN(MODIFYTS) AS MODIFYTS, ORDER_LINE_KEY     
        FROM raw.raw_ORDER_line  
        WHERE processing_status IN (''Pending'', ''Failed'')
        AND BUNDLE_PARENT_ORDER_LINE_KEY IS NULL
        GROUP BY ORDER_LINE_KEY
    ) AS prelines ON prelines.MODIFYTS = rool.MODIFYTS 
                  AND rool.ORDER_LINE_KEY = prelines.ORDER_LINE_KEY
    WHERE rool.processing_status IN (''Pending'', ''Failed'') 
      AND rool.BUNDLE_PARENT_ORDER_LINE_KEY IS NULL AND rool.txn_id is not null;

    -- Remove duplicates from stg_ORDER_line
    INSERT INTO transformed.stg_ORDER_line (ORDER_LINE_KEY,    
ORDER_HEADER_KEY,    
PRIME_LINE_NO,    
SUB_LINE_NO,    
LINE_TYPE,    
ORDER_CLASS,    
ITEM_ID,    
ALTERNATE_ITEM_ID,    
UOM,    
PRODUCT_CLASS,    
UNIT_PRICE,    
COST_CURRENCY,    
ORDERED_QTY,    
BASIC_CAPACITY_REQUIRED,    
OPTION_CAPACITY_REQUIRED,    
DEPENDENT_ON_LINE_KEY,    
CURRENT_WORK_ORDER_KEY,    
DEPENDENCY_SHIPPING_RULE,    
FILL_QUANTITY,    
COMMITTED_QUANTITY,    
DEPENDENCY_RATIO,    
MAINTAIN_RATIO,    
MERGE_NODE,    
PARENT_OF_DEPENDENT_GROUP,    
SOURCE_FROM_ORGANIZATION,    
CHAINED_FROM_ORDER_LINE_KEY,    
CHAINED_FROM_ORDER_HEADER_KEY,    
DERIVED_FROM_ORDER_LINE_KEY,    
DERIVED_FROM_ORDER_HEADER_KEY,    
DERIVED_FROM_ORDER_RELEASE_KEY,    
DISTRIBUTION_RULE_ID,    
INVOICED_QUANTITY,    
OVER_RECEIPT_QUANTITY,    
RETURN_REASON,    
SHIPNODE_KEY,    
PROCURE_FROM_NODE,    
SHIP_TO_KEY,    
MARK_FOR_KEY,    
BUYER_MARK_FOR_NODE_ID,    
REQ_DELIVERY_DATE,    
REQ_CANCEL_DATE,    
REQ_SHIP_DATE,    
SCAC,    
CARRIER_SERVICE_CODE,    
CARRIER_ACCOUNT_NO,    
PICKABLE_FLAG,    
SHIP_TOGETHER_NO,    
HOLD_FLAG,    
KIT_CODE,    
HOLD_REASON_CODE,    
OTHER_CHARGES,    
LINE_TOTAL,    
INVOICED_LINE_TOTAL,    
INVOICED_EXTENDED_PRICE,    
SETTLED_QUANTITY,    
SETTLED_AMOUNT,    
TAXABLE_FLAG,    
TAX_EXEMPTION_CERTIFICATE,    
DISCOUNT_TYPE,    
DISCOUNT_REFERENCE,    
GIFT_FLAG,    
PERSONALIZE_FLAG,    
PERSONALIZE_CODE,    
DEPARTMENT_CODE,    
CUSTOMER_ITEM,    
CUSTOMER_ITEM_DESCRIPTION,    
ITEM_WEIGHT,    
ITEM_WEIGHT_UOM,    
ITEM_DESCRIPTION,    
ITEM_SHORT_DESCRIPTION,    
RESERVATION_ID,    
RESERVATION_POOL,    
CUSTOMER_PO_NO,    
CUSTOMER_PO_LINE_NO,    
TAX,    
DELIVERY_CODE,    
ORIGINAL_ORDERED_QTY,    
LIST_PRICE,    
RETAIL_PRICE,    
DISCOUNT_PERCENTAGE,    
PACKLIST_TYPE,    
SUPPLIER_ITEM,    
SUPPLIER_ITEM_DESCRIPTION,    
UNIT_COST,    
UPC_CODE,    
FOB,    
MANUFACTURER_NAME,    
MANUFACTURER_ITEM,    
MANUFACTURER_ITEM_DESC,    
COUNTRY_OF_ORIGIN,    
ISBN,    
HARMONIZED_CODE,    
SHIP_TO_ID,    
PRODUCT_LINE,    
NMFC_CODE,    
NMFC_CLASS,    
NMFC_DESCRIPTION,    
TAX_PRODUCT_CODE,    
IMPORT_LICENSE_NO,    
IMPORT_LICENSE_EXP_DATE,    
ECCN_NO,    
SCHEDULE_B_CODE,    
SUPPLIER_CODE,    
PURPOSE,    
RECEIVING_NODE,    
BUYER_RECEIVING_NODE_ID,    
SHIPMENT_CONSOL_GROUP_ID,    
ORIG_ORDER_LINE_KEY,    
LINE_SEQ_NO,    
SPLIT_QTY,    
PRICING_DATE,    
PIPELINE_KEY,    
CONDITION_VARIABLE_1,    
CONDITION_VARIABLE_2,    
IS_PRICE_LOCKED,    
IS_COST_OVERRIDDEN,    
IS_CAPACITY_OVERRIDDEN,    
INVOICE_COMPLETE,    
DELIVERY_METHOD,    
ITEM_GROUP_CODE,    
CANNOT_COMPLETE_BEFORE_DATE,    
CANNOT_COMPLETE_AFTER_DATE,    
APPT_STATUS,    
CAN_ADD_SERVICE_LINES,    
PRICING_UOM,    
CAPACITY_UOM,    
PRICING_QUANTITY,    
SHIPPED_QUANTITY,    
FIXED_CAPACITY_QTY_PER_LINE,    
FIXED_PRICING_QTY_PER_LINE,    
WAIT_FOR_SEQ_LINE,    
SCHED_FAILURE_REASON_CODE,    
EARLIEST_SHIP_DATE,    
EARLIEST_DELIVERY_DATE,    
CANNOT_MEET_APPT,    
PROMISED_APPT_START_DATE,    
PROMISED_APPT_END_DATE,    
SEGMENT,    
SEGMENT_TYPE,    
EARLIEST_SCHEDULE_DATE,    
TIMEZONE,    
IS_FORWARDING_ALLOWED,    
IS_PROCUREMENT_ALLOWED,    
RESHIP_PARENT_LINE_KEY,    
BUNDLE_PARENT_ORDER_LINE_KEY,    
IS_PRICE_INFO_ONLY,    
LEVEL_OF_SERVICE,    
FIRST_ITER_SEQ_NO,    
LAST_ITER_SEQ_NO,    
CREATETS,    
MODIFYTS,    
CREATEUSERID,    
MODIFYUSERID,    
CREATEPROGID,    
MODIFYPROGID,    
LOCKID,    
ORDERING_UOM,    
PRICING_QUANTITY_CONV_FACTOR,    
PRICING_QUANTITY_STRATEGY,    
INVOICED_PRICING_QUANTITY,    
IS_STANDALONE_SERVICE,    
TRAN_DISCREPANCY_QTY,    
RECEIVED_QUANTITY,    
INVOICE_BASED_ON_ACTUALS,    
ACTUAL_PRICING_QUANTITY,    
FULFILLMENT_TYPE,    
SERIAL_NO,    
RESERVATION_MANDATORY,    
IS_FIRM_PREDEFINED_NODE,    
INTENTIONAL_BACKORDER,    
FUTURE_AVAIL_DATE,    
REPRICING_QUANTITY,    
MIN_SHIP_BY_DATE,    
KIT_QTY,    
BOM_CONFIG_KEY,    
BUNDLE_FULFILLMENT_MODE,    
IS_GIFT_WRAP,    
GROUP_SEQUENCE_NUM,    
IN_STORE_PAYMENT_REQUIRED,    
ITEM_NOT_EXIST,    
DERIVED_FROM_EXT_ORD,    
IS_ELIGIBLE_FOR_SHIP_DISC,    
BACKORDER_NOTIFICATION_QTY,    
IS_PRICE_MATCHED,    
IS_PICK_UP_NOW,    
ITEM_IS_IN_HAND,    
DISPOSITION_CODE,    
EXTN_MOD_REASON_CODE,    
EXTN_MOD_REASON_DESC,    
EXTN_ASN,    
EXTN_PARENT_ORDER_NO,    
EXTN_ITEM_ID,    
EXTN_ORDER_ITEM_ID,    
EXTN_PRICE_TYPE,
EXTN_SECONDARY_RETURN_REASON,
EXTN_APPLY_LABEL_FEE,
EXTN_IS_ACTIVATION_COMPLETE,
EXTN_ITEM_DESC,
EXTN_RETURN_CARTON_COUNT,
EXTN_ASN_QUANTITY,
EXTN_LIGHT_COLOR,
EXTN_LIGHT_TYPE,
EXTN_NUMBER_OF_SECTIONS,
EXTN_TOTAL_CARTONS,
EXTN_TREE_HEIGHT,
EXTN_TREE_HEIGHT_UOM,
EXTN_APPLY_RESTOCKING_FEE,
EXTN_RETURN_PICKUP_DATE,
EXTN_PICKUP_CONFIRMATION_NO,
EXTN_REFUND_SHIPPING_COST,
EXTN_IS_FULFILLED_LINE,
EXTN_MFG_WARRANTY_START_DATE,
EXTN_MFG_WARRANTY_END_DATE,
EXTN_TERM,
EXTN_IS_INVOICE_REQUIRED,
EXTN_PREM_GUARANTEE_END_DATE,
EXTN_RETURN_DATE,
EXTN_IS_EMAIL_SENT,
EXTN_RETURN_REQUIRED,
EXTN_PARENT_PRIME_LINE_NO,
EXTN_PARENT_SUB_LINE_NO,
EXTN_PREM_GUARANTEE_START_DATE,
EXTN_RESHIP_UPCID,
extn_parent_order_line_sku,
imported_date,    
txn_id,    
order_line_status) 
select * from 
   ( WITH src AS (
        SELECT ORDER_LINE_KEY, MODIFYTS, ROW_NUMBER() OVER (PARTITION BY ORDER_LINE_KEY ORDER BY ORDER_LINE_KEY, MODIFYTS) AS revision
        FROM transformed.stg_ORDER_line_temp
    ) 
    SELECT h.* 
    FROM transformed.stg_ORDER_line_temp h
    INNER JOIN src ON 
        src.ORDER_LINE_KEY = h.ORDER_LINE_KEY 
        AND src.MODIFYTS = h.MODIFYTS
        AND src.revision = 1);

    -- Select the count of records to be processed
    SELECT COUNT(*) INTO :toBeProcessedRecordCount
    FROM transformed.stg_ORDER_line;

    -- Update the log table with the count of records to be processed
    UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    WHERE file_name = ''YFS_ORDER_LINE'';

    -- Log the completion of the staging process
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    RETURN ''usp_insert_stg_ORDER_line executed successfully'';

COMMIT;

RETURN ''Success'';

EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
    SET processed = 0,
        status = ''Failed''
    WHERE file_name = ''YFS_ORDER_LINE'';
    
    -- Create error object
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    -- Log the failure
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_LINE_CHARGES"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
        toBeProcessedRecordCount INT;
        error_object OBJECT;
        start_time_proc TIMESTAMP_NTZ(9); 

    -- Attempt to execute the main logic
    BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    
        -- Truncate the staging table
        TRUNCATE TABLE transformed.stg_ORDER_line_charges;

            -- Log the start of the staging process
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );

        
        -- Insert data into staging table
        create or replace temporary table  transformed.stg_ORDER_line_charges_temp1 as 
        SELECT DISTINCT
            raw.line_charges_key,
            raw.header_key,
            raw.line_key,
            record_type,
            charge_category,
            charge_name,
            reference,
            chargeperunit,
            chargeperline,
            chargeamount,
            invoiced_charge_per_line,
            invoiced_extended_charge,
            original_chargeperunit,
            original_chargeperline,
            is_manual,
            createts,
            raw.modifyts,
            raw.createuserid,
            modifyuserid,
            createprogid,
            modifyprogid,
            lockid,
            extn_charge_description,
            extn_coupon_code,
            imported_date,
            txn_id
        FROM
            raw.raw_ORDER_line_charges raw
        INNER JOIN (
            SELECT
                line_charges_key,
                MIN(MODIFYTS) AS MODIFYTS
            FROM
                raw.raw_ORDER_line_charges
            WHERE
                processing_status IN (''Pending'', ''Failed'')
            GROUP BY
                line_charges_key
        ) AS prelines ON raw.line_charges_key = prelines.line_charges_key
        AND prelines.MODIFYTS = raw.MODIFYTS
        WHERE
            processing_status IN (''Pending'', ''Failed'')
            AND raw.record_type = ''ORD'' AND raw.txn_id is not null;

        -- Delete duplicates from staging table
        create or replace temporary table transformed.stg_ORDER_line_charges_temp2 as 
            WITH src AS (
            SELECT line_charges_key,modifyts,
                   ROW_NUMBER() OVER (Partition By line_charges_key Order By line_charges_key,modifyts)  AS     
             revision
            FROM transformed.stg_ORDER_line_charges_temp1
            )
            SELECT h.*
            FROM transformed.stg_ORDER_line_charges_temp1 AS h
            INNER JOIN src ON src.revision = 1
            AND h.line_charges_key = src.line_charges_key
            AND h.modifyts = src.modifyts;

            insert into transformed.stg_ORDER_line_charges
            (line_charges_key
        ,header_key
        ,line_key
        ,record_type
        ,charge_category
        ,charge_name
        ,reference
        ,chargeperunit
        ,chargeperline
        ,chargeamount
        ,invoiced_charge_per_line
        ,invoiced_extended_charge
        ,original_chargeperunit
        ,original_chargeperline
        ,is_manual
        ,createts
        ,modifyts
        ,createuserid
        ,modifyuserid
        ,createprogid
        ,modifyprogid
        ,lockid
        ,extn_charge_description
        ,extn_coupon_code,
        imported_date,
        txn_id)
        select line_charges_key
        ,header_key
        ,line_key
        ,record_type
        ,charge_category
        ,charge_name
        ,reference
        ,chargeperunit
        ,chargeperline
        ,chargeamount
        ,invoiced_charge_per_line
        ,invoiced_extended_charge
        ,original_chargeperunit
        ,original_chargeperline
        ,is_manual
        ,createts
        ,modifyts
        ,createuserid
        ,modifyuserid
        ,createprogid
        ,modifyprogid
        ,lockid
        ,extn_charge_description
        ,extn_coupon_code,
        imported_date,
        txn_id from transformed.stg_ORDER_line_charges_temp2;

        -- Count records in staging table
        SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM      
            transformed.stg_ORDER_line_charges;

        -- -- Update record count in log table
            UPDATE analytics.log_files_import_status
            SET to_be_processed = :toBeProcessedRecordCount
            WHERE file_name = ''YFS_LINE_CHARGES'';

            -- Log the completion of the staging process
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

       
        -- Return success message
        RETURN ''usp_insert_stg_ORDER_line_charges executed successfully.'';

EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
    SET processed = 0,
        status = ''Failed''
    WHERE file_name = ''YFS_ORDER_LINE'';
    
    -- Create error object
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    -- Log the failure
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
    
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_LINE_HEADER_STATUS"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    
    -- Truncate staging tables
    TRUNCATE TABLE transformed.stg_ORDER_line_status;
    TRUNCATE TABLE transformed.stg_ORDER_header_status;

     CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
    
    -- Temporary table for error logging
    CREATE or replace Temporary TABLE transformed.DimInventoryErrorToLog (
        input STRING,
        message STRING,
        snapshotId STRING,
        productID STRING
    );
    
    -- Temporary tables for processing
    CREATE or replace Temporary TABLE transformed.TempAPI_ORDER_line_status (
        order_release_status_key STRING,
        order_line_key STRING,
        order_header_key STRING,
        status_quantity INT,
        MODIFYTS STRING,
        total_quantity INT,
        status STRING,
        priority INT,
        txn_id STRING
    );
    
    CREATE or replace Temporary TABLE transformed.TempAPI_ORDER_header_status (
        order_header_key STRING,
        status_quantity INT,
        total_quantity INT,
        status STRING,
        header_priority INT,
        txn_id STRING
    );
    
           -- Populate TempAPI_ORDER_line_status
        INSERT INTO transformed.TempAPI_ORDER_line_status (
            order_release_status_key,
            order_line_key,
            order_header_key,
            status_quantity,
            total_quantity,
            status,
            priority,
            txn_id,
            MODIFYTS
        )
        SELECT
            order_release_status_key,
            order_line_key,
            order_header_key,
            TRY_CAST(status_quantity AS INT),
            TRY_CAST(total_quantity AS INT),
            status,
            ROW_NUMBER() OVER (PARTITION BY txn_id, order_line_key ORDER BY     
           TRY_CAST(ANALYTICS.CleanAndTrimString(COALESCE(order_release_status_key, ''0'')) AS DECIMAL(38, 0)) DESC),
            txn_id,
            MODIFYTS
        FROM
            transformed.stg_ORDER_release_status
        WHERE
            TRY_CAST(status_quantity AS INT) > 0;
        
        -- Debugging: Display TempAPI_ORDER_line_status
        SELECT * FROM transformed.TempAPI_ORDER_line_status;
        
        -- Insert into stg_ORDER_line_status
        create or replace temporary table  transformed.stg_ORDER_line_status_temp as
        SELECT
            MAX(order_release_status_key) order_release_status_key,
            order_line_key,
            order_header_key,
            ANALYTICS.CleanAndTrimString(COALESCE(status, '''')) status,
            txn_id
        FROM
            transformed.TempAPI_ORDER_line_status
        GROUP BY
            order_line_key,
            order_header_key,
            status,
            txn_id;
        
        -- Debugging: Display stg_ORDER_line_status
        SELECT * FROM transformed.stg_ORDER_line_status;
        
        -- Insert into TempAPI_ORDER_header_status
        create or replace temporary table transformed.TempAPI_ORDER_header_status as
        SELECT
            order_header_key,
            status_quantity,
            total_quantity,
            status,
            ROW_NUMBER() OVER (PARTITION BY txn_id, order_header_key ORDER BY 
            TRY_CAST(ANALYTICS.CleanAndTrimString(COALESCE(status_quantity,''0'')) AS DECIMAL(38, 0)) ASC) header_priority,
            txn_id
        FROM
        (
            SELECT
                order_header_key,
                SUM(status_quantity) AS status_quantity,
                SUM(total_quantity) AS total_quantity,
                status,
                txn_id
            FROM
                transformed.TempAPI_ORDER_line_status
            GROUP BY
                order_header_key,
                status,
                txn_id
        ) AS processed_line;
        
        -- Insert into stg_ORDER_header_status
        CREATE or replace temporary table transformed.stg_ORDER_header_status_temp as  
        SELECT
            ord.order_header_key,
            MAX(status_quantity) status_quantity,
            CASE
                WHEN header_priority > 1 THEN ''_'' || ANALYTICS.CleanAndTrimString(COALESCE(status, ''''))
                WHEN header_priority = 1 THEN ANALYTICS.CleanAndTrimString(COALESCE(status, ''''))
                ELSE NULL
            END as status,
            header_priority,
            txn_id
        FROM
            transformed.TempAPI_ORDER_header_status ord
        GROUP BY
            order_header_key,
            status,
            header_priority,
            txn_id;
        
        -- Delete duplicates from stg_ORDER_line_status
        insert into transformed.stg_ORDER_line_status
        WITH src as (
            SELECT
                order_line_key,
                txn_id,
                ROW_NUMBER() OVER (PARTITION BY order_line_key ORDER BY order_line_key, txn_id) AS revision
            FROM
                transformed.stg_ORDER_line_status_temp
        )
        select h.* from transformed.stg_ORDER_line_status_temp h
        inner join src on src.order_line_key = h.order_line_key
        and revision = 1;
        
        -- Delete duplicates from stg_ORDER_header_status
        insert into transformed.stg_ORDER_header_status
        with src as (
            SELECT
                order_header_key,
                txn_id,
                ROW_NUMBER() OVER (PARTITION BY order_header_key ORDER BY order_header_key, txn_id) AS revision
            FROM
                transformed.stg_ORDER_header_status_temp
        )
        select h.* from transformed.stg_ORDER_header_status_temp h
        inner join src on
        src.order_header_key = h.order_header_key
         and revision = 1;

COMMIT;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_LINE_MULTIPART"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

   CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );

  -- Truncate staging table
  TRUNCATE TABLE TRANSFORMED.stg_ORDER_line_multipart;

  -- Insert data into staging table
  create or replace temporary table  TRANSFORMED.stg_ORDER_line_multipart_temp  as 
      SELECT Distinct    
rool.ORDER_LINE_KEY,  
rool.ORDER_HEADER_KEY,  
PRIME_LINE_NO,  
SUB_LINE_NO,  
LINE_TYPE,  
ORDER_CLASS,  
ITEM_ID,  
ALTERNATE_ITEM_ID,  
UOM,  
PRODUCT_CLASS,  
UNIT_PRICE,  
COST_CURRENCY,  
ORDERED_QTY,  
BASIC_CAPACITY_REQUIRED,  
OPTION_CAPACITY_REQUIRED,  
DEPENDENT_ON_LINE_KEY,  
CURRENT_WORK_ORDER_KEY,  
DEPENDENCY_SHIPPING_RULE,  
FILL_QUANTITY,  
COMMITTED_QUANTITY,  
DEPENDENCY_RATIO,  
MAINTAIN_RATIO,  
MERGE_NODE,  
PARENT_OF_DEPENDENT_GROUP,  
SOURCE_FROM_ORGANIZATION,  
CHAINED_FROM_ORDER_LINE_KEY,  
CHAINED_FROM_ORDER_HEADER_KEY,  
DERIVED_FROM_ORDER_LINE_KEY,  
DERIVED_FROM_ORDER_HEADER_KEY,  
DERIVED_FROM_ORDER_RELEASE_KEY,  
DISTRIBUTION_RULE_ID,  
INVOICED_QUANTITY,  
OVER_RECEIPT_QUANTITY,  
RETURN_REASON,  
SHIPNODE_KEY,  
PROCURE_FROM_NODE,  
SHIP_TO_KEY,  
MARK_FOR_KEY,  
BUYER_MARK_FOR_NODE_ID,  
REQ_DELIVERY_DATE,  
REQ_CANCEL_DATE,  
REQ_SHIP_DATE,  
SCAC,  
CARRIER_SERVICE_CODE,  
CARRIER_ACCOUNT_NO,  
PICKABLE_FLAG,  
SHIP_TOGETHER_NO,  
HOLD_FLAG,  
KIT_CODE,  
HOLD_REASON_CODE,  
OTHER_CHARGES,  
LINE_TOTAL,  
INVOICED_LINE_TOTAL,  
INVOICED_EXTENDED_PRICE,  
SETTLED_QUANTITY,  
SETTLED_AMOUNT,  
TAXABLE_FLAG,  
TAX_EXEMPTION_CERTIFICATE,  
DISCOUNT_TYPE,  
DISCOUNT_REFERENCE,  
GIFT_FLAG,  
PERSONALIZE_FLAG,  
PERSONALIZE_CODE,  
DEPARTMENT_CODE,  
CUSTOMER_ITEM,  
CUSTOMER_ITEM_DESCRIPTION,  
ITEM_WEIGHT,  
ITEM_WEIGHT_UOM,  
ITEM_DESCRIPTION,  
ITEM_SHORT_DESCRIPTION,  
RESERVATION_ID,  
RESERVATION_POOL,  
CUSTOMER_PO_NO,  
CUSTOMER_PO_LINE_NO,  
TAX,  
DELIVERY_CODE,  
ORIGINAL_ORDERED_QTY,  
LIST_PRICE,  
RETAIL_PRICE,  
DISCOUNT_PERCENTAGE,  
PACKLIST_TYPE,  
SUPPLIER_ITEM,  
SUPPLIER_ITEM_DESCRIPTION,  
UNIT_COST,  
UPC_CODE,  
FOB,  
MANUFACTURER_NAME,  
MANUFACTURER_ITEM,  
MANUFACTURER_ITEM_DESC,  
COUNTRY_OF_ORIGIN,  
ISBN,  
HARMONIZED_CODE,  
SHIP_TO_ID,  
PRODUCT_LINE,  
NMFC_CODE,  
NMFC_CLASS,  
NMFC_DESCRIPTION,  
TAX_PRODUCT_CODE,  
IMPORT_LICENSE_NO,  
IMPORT_LICENSE_EXP_DATE,  
ECCN_NO,  
SCHEDULE_B_CODE,  
SUPPLIER_CODE,  
PURPOSE,  
RECEIVING_NODE,  
BUYER_RECEIVING_NODE_ID,  
SHIPMENT_CONSOL_GROUP_ID,  
ORIG_ORDER_LINE_KEY,  
LINE_SEQ_NO,  
SPLIT_QTY,  
PRICING_DATE,  
PIPELINE_KEY,  
CONDITION_VARIABLE_1,  
CONDITION_VARIABLE_2,  
IS_PRICE_LOCKED,  
IS_COST_OVERRIDDEN,  
IS_CAPACITY_OVERRIDDEN,  
INVOICE_COMPLETE,  
DELIVERY_METHOD,  
ITEM_GROUP_CODE,  
CANNOT_COMPLETE_BEFORE_DATE,  
CANNOT_COMPLETE_AFTER_DATE,  
APPT_STATUS,  
CAN_ADD_SERVICE_LINES,  
PRICING_UOM,  
CAPACITY_UOM,  
PRICING_QUANTITY,  
SHIPPED_QUANTITY,  
FIXED_CAPACITY_QTY_PER_LINE,  
FIXED_PRICING_QTY_PER_LINE,  
WAIT_FOR_SEQ_LINE,  
SCHED_FAILURE_REASON_CODE,  
EARLIEST_SHIP_DATE,  
EARLIEST_DELIVERY_DATE,  
CANNOT_MEET_APPT,  
PROMISED_APPT_START_DATE,  
PROMISED_APPT_END_DATE,  
SEGMENT,  
SEGMENT_TYPE,  
EARLIEST_SCHEDULE_DATE,  
TIMEZONE,  
IS_FORWARDING_ALLOWED,  
IS_PROCUREMENT_ALLOWED,  
RESHIP_PARENT_LINE_KEY,  
BUNDLE_PARENT_ORDER_LINE_KEY,  
IS_PRICE_INFO_ONLY,  
LEVEL_OF_SERVICE,  
FIRST_ITER_SEQ_NO,  
LAST_ITER_SEQ_NO,  
CREATETS,  
rool.MODIFYTS,  
CREATEUSERID,  
MODIFYUSERID,  
CREATEPROGID,  
MODIFYPROGID,  
LOCKID,  
ORDERING_UOM,  
PRICING_QUANTITY_CONV_FACTOR,  
PRICING_QUANTITY_STRATEGY,  
INVOICED_PRICING_QUANTITY,  
IS_STANDALONE_SERVICE,  
TRAN_DISCREPANCY_QTY,  
RECEIVED_QUANTITY,  
INVOICE_BASED_ON_ACTUALS,  
ACTUAL_PRICING_QUANTITY,  
FULFILLMENT_TYPE,  
SERIAL_NO,  
RESERVATION_MANDATORY,  
IS_FIRM_PREDEFINED_NODE,  
INTENTIONAL_BACKORDER,  
FUTURE_AVAIL_DATE,  
REPRICING_QUANTITY,  
MIN_SHIP_BY_DATE,  
KIT_QTY,  
BOM_CONFIG_KEY,  
BUNDLE_FULFILLMENT_MODE,  
IS_GIFT_WRAP,  
GROUP_SEQUENCE_NUM,  
IN_STORE_PAYMENT_REQUIRED,  
ITEM_NOT_EXIST,  
DERIVED_FROM_EXT_ORD,  
IS_ELIGIBLE_FOR_SHIP_DISC,  
BACKORDER_NOTIFICATION_QTY,  
IS_PRICE_MATCHED,  
IS_PICK_UP_NOW,  
ITEM_IS_IN_HAND,  
DISPOSITION_CODE,  
EXTN_MOD_REASON_CODE,  
EXTN_MOD_REASON_DESC,  
EXTN_ASN,  
EXTN_PARENT_ORDER_NO,  
EXTN_ITEM_ID,  
EXTN_ORDER_ITEM_ID,  
EXTN_PRICE_TYPE, 
EXTN_SECONDARY_RETURN_REASON,
EXTN_APPLY_LABEL_FEE,
EXTN_IS_ACTIVATION_COMPLETE,
EXTN_ITEM_DESC,
EXTN_RETURN_CARTON_COUNT,
EXTN_ASN_QUANTITY,
EXTN_LIGHT_COLOR,
EXTN_LIGHT_TYPE,
EXTN_NUMBER_OF_SECTIONS,
EXTN_TOTAL_CARTONS,
EXTN_TREE_HEIGHT,
EXTN_TREE_HEIGHT_UOM,
EXTN_APPLY_RESTOCKING_FEE,
EXTN_RETURN_PICKUP_DATE,
EXTN_PICKUP_CONFIRMATION_NO,
EXTN_REFUND_SHIPPING_COST,
EXTN_IS_FULFILLED_LINE,
EXTN_MFG_WARRANTY_START_DATE,
EXTN_MFG_WARRANTY_END_DATE,
EXTN_TERM,
EXTN_IS_INVOICE_REQUIRED,
EXTN_PREM_GUARANTEE_END_DATE,
EXTN_RETURN_DATE,
EXTN_IS_EMAIL_SENT,
EXTN_RETURN_REQUIRED,
EXTN_PARENT_PRIME_LINE_NO,
EXTN_PARENT_SUB_LINE_NO,
EXTN_PREM_GUARANTEE_START_DATE,
EXTN_RESHIP_UPCID,
CASE
    WHEN extn_parent_order_line_sku LIKE ''%.0'' THEN REPLACE(extn_parent_order_line_sku, ''.0'', '''')
    ELSE extn_parent_order_line_sku
  END AS extn_parent_order_line_sku,
rool.imported_date,  
txn_id,  
order_line_status 
  FROM RAW.raw_ORDER_line AS rool
  INNER JOIN (
    SELECT DISTINCT
      MIN(MODIFYTS) AS MODIFYTS,
      ORDER_HEADER_KEY,
      ORDER_LINE_KEY
    FROM RAW.raw_ORDER_line
    WHERE processing_status IN (''Pending'', ''Failed'') AND BUNDLE_PARENT_ORDER_LINE_KEY IS NOT NULL
    GROUP BY ORDER_HEADER_KEY, ORDER_LINE_KEY
  ) AS prelines ON prelines.MODIFYTS = rool.MODIFYTS
    AND rool.ORDER_LINE_KEY = prelines.ORDER_LINE_KEY
    AND rool.ORDER_HEADER_KEY = prelines.ORDER_HEADER_KEY
  WHERE processing_status IN (''Pending'', ''Failed'')
    AND rool.BUNDLE_PARENT_ORDER_LINE_KEY IS NOT NULL AND rool.txn_id is not null;

  -- Select records with multiple revisions
  INSERT INTO   TRANSFORMED.stg_ORDER_line_multipart
  (ORDER_LINE_KEY,  
ORDER_HEADER_KEY,  
PRIME_LINE_NO,  
SUB_LINE_NO,  
LINE_TYPE,  
ORDER_CLASS,  
ITEM_ID,  
ALTERNATE_ITEM_ID,  
UOM,  
PRODUCT_CLASS,  
UNIT_PRICE,  
COST_CURRENCY,  
ORDERED_QTY,  
BASIC_CAPACITY_REQUIRED,  
OPTION_CAPACITY_REQUIRED,  
DEPENDENT_ON_LINE_KEY,  
CURRENT_WORK_ORDER_KEY,  
DEPENDENCY_SHIPPING_RULE,  
FILL_QUANTITY,  
COMMITTED_QUANTITY,  
DEPENDENCY_RATIO,  
MAINTAIN_RATIO,  
MERGE_NODE,  
PARENT_OF_DEPENDENT_GROUP,  
SOURCE_FROM_ORGANIZATION,  
CHAINED_FROM_ORDER_LINE_KEY,  
CHAINED_FROM_ORDER_HEADER_KEY,  
DERIVED_FROM_ORDER_LINE_KEY,  
DERIVED_FROM_ORDER_HEADER_KEY,  
DERIVED_FROM_ORDER_RELEASE_KEY,  
DISTRIBUTION_RULE_ID,  
INVOICED_QUANTITY,  
OVER_RECEIPT_QUANTITY,  
RETURN_REASON,  
SHIPNODE_KEY,  
PROCURE_FROM_NODE,  
SHIP_TO_KEY,  
MARK_FOR_KEY,  
BUYER_MARK_FOR_NODE_ID,  
REQ_DELIVERY_DATE,  
REQ_CANCEL_DATE,  
REQ_SHIP_DATE,  
SCAC,  
CARRIER_SERVICE_CODE,  
CARRIER_ACCOUNT_NO,  
PICKABLE_FLAG,  
SHIP_TOGETHER_NO,  
HOLD_FLAG,  
KIT_CODE,  
HOLD_REASON_CODE,  
OTHER_CHARGES,  
LINE_TOTAL,  
INVOICED_LINE_TOTAL,  
INVOICED_EXTENDED_PRICE,  
SETTLED_QUANTITY,  
SETTLED_AMOUNT,  
TAXABLE_FLAG,  
TAX_EXEMPTION_CERTIFICATE,  
DISCOUNT_TYPE,  
DISCOUNT_REFERENCE,  
GIFT_FLAG,  
PERSONALIZE_FLAG,  
PERSONALIZE_CODE,  
DEPARTMENT_CODE,  
CUSTOMER_ITEM,  
CUSTOMER_ITEM_DESCRIPTION,  
ITEM_WEIGHT,  
ITEM_WEIGHT_UOM,  
ITEM_DESCRIPTION,  
ITEM_SHORT_DESCRIPTION,  
RESERVATION_ID,  
RESERVATION_POOL,  
CUSTOMER_PO_NO,  
CUSTOMER_PO_LINE_NO,  
TAX,  
DELIVERY_CODE,  
ORIGINAL_ORDERED_QTY,  
LIST_PRICE,  
RETAIL_PRICE,  
DISCOUNT_PERCENTAGE,  
PACKLIST_TYPE,  
SUPPLIER_ITEM,  
SUPPLIER_ITEM_DESCRIPTION,  
UNIT_COST,  
UPC_CODE,  
FOB,  
MANUFACTURER_NAME,  
MANUFACTURER_ITEM,  
MANUFACTURER_ITEM_DESC,  
COUNTRY_OF_ORIGIN,  
ISBN,  
HARMONIZED_CODE,  
SHIP_TO_ID,  
PRODUCT_LINE,  
NMFC_CODE,  
NMFC_CLASS,  
NMFC_DESCRIPTION,  
TAX_PRODUCT_CODE,  
IMPORT_LICENSE_NO,  
IMPORT_LICENSE_EXP_DATE,  
ECCN_NO,  
SCHEDULE_B_CODE,  
SUPPLIER_CODE,  
PURPOSE,  
RECEIVING_NODE,  
BUYER_RECEIVING_NODE_ID,  
SHIPMENT_CONSOL_GROUP_ID,  
ORIG_ORDER_LINE_KEY,  
LINE_SEQ_NO,  
SPLIT_QTY,  
PRICING_DATE,  
PIPELINE_KEY,  
CONDITION_VARIABLE_1,  
CONDITION_VARIABLE_2,  
IS_PRICE_LOCKED,  
IS_COST_OVERRIDDEN,  
IS_CAPACITY_OVERRIDDEN,  
INVOICE_COMPLETE,  
DELIVERY_METHOD,  
ITEM_GROUP_CODE,  
CANNOT_COMPLETE_BEFORE_DATE,  
CANNOT_COMPLETE_AFTER_DATE,  
APPT_STATUS,  
CAN_ADD_SERVICE_LINES,  
PRICING_UOM,  
CAPACITY_UOM,  
PRICING_QUANTITY,  
SHIPPED_QUANTITY,  
FIXED_CAPACITY_QTY_PER_LINE,  
FIXED_PRICING_QTY_PER_LINE,  
WAIT_FOR_SEQ_LINE,  
SCHED_FAILURE_REASON_CODE,  
EARLIEST_SHIP_DATE,  
EARLIEST_DELIVERY_DATE,  
CANNOT_MEET_APPT,  
PROMISED_APPT_START_DATE,  
PROMISED_APPT_END_DATE,  
SEGMENT,  
SEGMENT_TYPE,  
EARLIEST_SCHEDULE_DATE,  
TIMEZONE,  
IS_FORWARDING_ALLOWED,  
IS_PROCUREMENT_ALLOWED,  
RESHIP_PARENT_LINE_KEY,  
BUNDLE_PARENT_ORDER_LINE_KEY,  
IS_PRICE_INFO_ONLY,  
LEVEL_OF_SERVICE,  
FIRST_ITER_SEQ_NO,  
LAST_ITER_SEQ_NO,  
CREATETS,  
MODIFYTS,  
CREATEUSERID,  
MODIFYUSERID,  
CREATEPROGID,  
MODIFYPROGID,  
LOCKID,  
ORDERING_UOM,  
PRICING_QUANTITY_CONV_FACTOR,  
PRICING_QUANTITY_STRATEGY,  
INVOICED_PRICING_QUANTITY,  
IS_STANDALONE_SERVICE,  
TRAN_DISCREPANCY_QTY,  
RECEIVED_QUANTITY,  
INVOICE_BASED_ON_ACTUALS,  
ACTUAL_PRICING_QUANTITY,  
FULFILLMENT_TYPE,  
SERIAL_NO,  
RESERVATION_MANDATORY,  
IS_FIRM_PREDEFINED_NODE,  
INTENTIONAL_BACKORDER,  
FUTURE_AVAIL_DATE,  
REPRICING_QUANTITY,  
MIN_SHIP_BY_DATE,  
KIT_QTY,  
BOM_CONFIG_KEY,  
BUNDLE_FULFILLMENT_MODE,  
IS_GIFT_WRAP,  
GROUP_SEQUENCE_NUM,  
IN_STORE_PAYMENT_REQUIRED,  
ITEM_NOT_EXIST,  
DERIVED_FROM_EXT_ORD,  
IS_ELIGIBLE_FOR_SHIP_DISC,  
BACKORDER_NOTIFICATION_QTY,  
IS_PRICE_MATCHED,  
IS_PICK_UP_NOW,  
ITEM_IS_IN_HAND,  
DISPOSITION_CODE,  
EXTN_MOD_REASON_CODE,  
EXTN_MOD_REASON_DESC,  
EXTN_ASN,  
EXTN_PARENT_ORDER_NO,  
EXTN_ITEM_ID,  
EXTN_ORDER_ITEM_ID,  
EXTN_PRICE_TYPE, 
EXTN_SECONDARY_RETURN_REASON,
EXTN_APPLY_LABEL_FEE,
EXTN_IS_ACTIVATION_COMPLETE,
EXTN_ITEM_DESC,
EXTN_RETURN_CARTON_COUNT,
EXTN_ASN_QUANTITY,
EXTN_LIGHT_COLOR,
EXTN_LIGHT_TYPE,
EXTN_NUMBER_OF_SECTIONS,
EXTN_TOTAL_CARTONS,
EXTN_TREE_HEIGHT,
EXTN_TREE_HEIGHT_UOM,
EXTN_APPLY_RESTOCKING_FEE,
EXTN_RETURN_PICKUP_DATE,
EXTN_PICKUP_CONFIRMATION_NO,
EXTN_REFUND_SHIPPING_COST,
EXTN_IS_FULFILLED_LINE,
EXTN_MFG_WARRANTY_START_DATE,
EXTN_MFG_WARRANTY_END_DATE,
EXTN_TERM,
EXTN_IS_INVOICE_REQUIRED,
EXTN_PREM_GUARANTEE_END_DATE,
EXTN_RETURN_DATE,
EXTN_IS_EMAIL_SENT,
EXTN_RETURN_REQUIRED,
EXTN_PARENT_PRIME_LINE_NO,
EXTN_PARENT_SUB_LINE_NO,
EXTN_PREM_GUARANTEE_START_DATE,
EXTN_RESHIP_UPCID,
extn_parent_order_line_sku,
imported_date,  
txn_id,  
order_line_status) 
  select * from (with src as (
    SELECT
      ORDER_LINE_KEY,
      MODIFYTS,
      ROW_NUMBER() OVER (PARTITION BY ORDER_LINE_KEY ORDER BY ORDER_LINE_KEY, MODIFYTS) AS revision
    FROM TRANSFORMED.stg_ORDER_line_multipart_temp
  ) 
  select h.* from TRANSFORMED.stg_ORDER_line_multipart_temp h
  inner join src
  on src.ORDER_LINE_KEY = h.ORDER_LINE_KEY 
      AND src.MODIFYTS = h.MODIFYTS
  and src.revision = 1);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    RETURN ''sp_insert_stg_ORDER_line_multipart executed successfully'';

COMMIT;
   
  RETURN ''usp_insert_stg_ORDER_line_multipart executed successfully'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
    SET processed = 0,
        status = ''Failed''
    WHERE file_name = ''YFS_ORDER_LINE_MULTIPART'';
    
    -- Create error object
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    -- Log the failure
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_NOTES"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
    BEGIN
        start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    
        -- Truncate table stg_order_notes
        TRUNCATE TABLE transformed.stg_order_notes;

       CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
        -- Insert data into stg_order_notes
        create or replace temporary table  transformed.stg_order_notes_temp1 as
            SELECT DISTINCT
            rooh.notes_key,
            table_key,
            sequence_no,
            table_name,
            tranid,
            audit_transaction_id,
            customer_sat_indicator,
            priority,
            reason_code,
            note_text,
            contact_type,
            contact_reference,
            contact_time,
            contact_user,
            lockid,
            createts,
            modifyts,
            createuserid,
            modifyuserid,
            createprogid,
            modifyprogid,
            visible_to_all,
            rooh.imported_date,
            txn_id
        FROM 
            raw.RAW_ORDER_notes as rooh
        INNER JOIN (
            SELECT DISTINCT 
                MIN(imported_date) as imported_date,
                notes_key 
            FROM 
                raw.RAW_ORDER_notes  
            WHERE 
                processing_status IN (''Pending'',''Failed'') 
            GROUP BY 
                notes_key 
        ) as prelines  
        ON 
            prelines.imported_date = rooh.imported_date 
            AND rooh.notes_key = prelines.notes_key 
        WHERE 
            processing_status IN (''Pending'',''Failed'') AND rooh.txn_id is not null;
        
        -- Delete duplicate records
        create or replace temporary table transformed.stg_order_notes_temp2 as 
            WITH src AS (
            SELECT notes_key,txn_id,
                   ROW_NUMBER() OVER (Partition By notes_key Order By notes_key,txn_id)  AS revision
            FROM transformed.stg_order_notes_temp1
            )
            SELECT h.*
            FROM transformed.stg_order_notes_temp1 AS h
            INNER JOIN src ON src.revision = 1
            AND h.notes_key = src.notes_key
            AND h.txn_id = src.txn_id;

     insert into transformed.stg_order_notes
     select * from transformed.stg_order_notes_temp2;

     CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    COMMIT;   
  RETURN ''usp_insert_stg_order_notes executed successfully'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_NOTES'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
    
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_PAYMENT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

        start_time_proc := CURRENT_TIMESTAMP();
        SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    
        -- Truncate staging table
        TRUNCATE TABLE transformed.stg_ORDER_payment;

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
        -- Insert data into stg_ORDER_payment
        create or replace temporary table transformed.stg_ORDER_payment_temp1 as
        SELECT DISTINCT 
            roop.payment_key,
            roop.order_header_key,
            roop.payment_type,
            roop.bill_to_key,
            roop.charge_sequence,
            roop.customer_account_no,
            roop.display_cust_acct_no,
            roop.customer_po_no,
            roop.credit_card_type,
            roop.credit_card_name,
            roop.first_name,
            roop.middle_name,
            roop.last_name,
            roop.credit_card_no,
            roop.display_credit_card_no,
            roop.credit_card_exp_date,
            roop.svc_no,
            roop.display_svc_no,
            roop.debit_card_no,
            roop.display_debit_card_no,
            roop.payment_reference1,
            roop.payment_reference2,
            roop.payment_reference3,
            roop.display_payment_ref1,
            roop.cheque_no,
            roop.cheque_reference,
            roop.extended_flag,
            roop.pay_method_override,
            roop.max_charge_limit,
            roop.total_authorized,
            roop.total_charged,
            roop.requested_auth_amount,
            roop.requested_charge_amount,
            roop.requested_refund_amount,
            roop.total_refunded_amount,
            roop.total_alt_refunded_amount,
            roop.incomplete_payment_type,
            roop.suspend_any_more_charges,
            roop.suspend_exp_auth_reversal,
            roop.planned_refund_amount,
            roop.unlimited_charges,
            roop.cash_back_amount,
            roop.payment_reference4,
            roop.payment_reference5,
            roop.payment_reference6,
            roop.payment_reference7,
            roop.payment_reference8,
            roop.payment_reference9,
            roop.reason_code,
            roop.createts,
            roop.modifyts,
            roop.createuserid,
            roop.modifyuserid,
            roop.createprogid,
            roop.modifyprogid,
            roop.lockid,
            roop.imported_date,
            roop.txn_id
        FROM 
            raw.raw_ORDER_payment roop
        INNER JOIN (
            SELECT DISTINCT 
                MIN(MODIFYTS) AS MODIFYTS,
                payment_key,
                order_header_key 
            FROM 
                raw.raw_ORDER_payment 
            WHERE 
                processing_status IN (''Pending'', ''Failed'') 
            GROUP BY 
                payment_key, 
                order_header_key
        ) AS prelines  
        ON  
            roop.payment_key = prelines.payment_key 
            AND roop.order_header_key = prelines.order_header_key 
            AND prelines.MODIFYTS = roop.MODIFYTS
        WHERE 
            processing_status IN (''Pending'', ''Failed'') AND roop.txn_id is not null;
         
        -- Delete duplicate records
         create or replace temporary table transformed.stg_ORDER_payment_temp2 as 
            WITH src AS (
            SELECT payment_key,txn_id,
                   ROW_NUMBER() OVER (Partition By payment_key Order By payment_key,txn_id)  AS revision
            FROM transformed.stg_ORDER_payment_temp1
            )
            SELECT h.*
            FROM transformed.stg_ORDER_payment_temp1 AS h
            INNER JOIN src ON src.revision = 1
            AND h.payment_key = src.payment_key
            AND h.txn_id = src.txn_id;

            insert into transformed.stg_ORDER_payment
            select * from transformed.stg_ORDER_payment_temp2;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
            
    
    RETURN ''usp_insert_stg_ORDER_payment executed successfully'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_PAYMENT'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_PERSON_INFO"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

        start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
   
        -- Truncate staging table
        TRUNCATE TABLE transformed.stg_ORDER_person_info;

     CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
        -- Insert data into stg_ORDER_person_info
        create or replace temporary table transformed.stg_ORDER_person_info_temp1 as
        SELECT 
            raw.person_info_key,
            person_id,
            title,
            first_name,
            middle_name,
            last_name,
            suffix,
            department,
            company,
            job_title,
            address_line1,
            address_line2,
            address_line3,
            address_line4,
            address_line5,
            address_line6,
            city,
            state,
            zip_code,
            country,
            day_phone,
            evening_phone,
            mobile_phone,
            beeper,
            other_phone,
            day_fax_no,
            evening_fax_no,
            emailid,
            alternate_emailid,
            preferred_ship_address,
            http_url,
            use_count,
            verification_status,
            is_address_verified,
            latitude,
            longitude,
            tax_geo_code,
            error_txt,
            is_commercial_address,
            time_zone,
            lockid,
            createts,
            raw.modifyts,
            createuserid,
            modifyuserid,
            createprogid,
            modifyprogid,
            address_id,
            short_zip_code,
            raw.imported_date,
            raw.txn_id
        FROM 
            raw.raw_ORDER_person_info raw
        INNER JOIN (
            SELECT DISTINCT 
                MIN(MODIFYTS) AS MODIFYTS,
                person_info_key
            FROM 
                raw.raw_ORDER_person_info
            WHERE 
                processing_status IN (''Pending'', ''Failed'') 
            GROUP BY 
                person_info_key
        ) AS prelines  
        ON 
            raw.person_info_key = prelines.person_info_key 
            AND prelines.MODIFYTS = raw.MODIFYTS
        WHERE 
            processing_status IN (''Pending'', ''Failed'') AND raw.txn_id is not null;
         
        -- Delete duplicate records
         create or replace temporary table transformed.stg_ORDER_person_info_temp2 as 
    WITH src AS (
    SELECT person_info_key,txn_id,
           ROW_NUMBER() OVER (Partition By person_info_key Order By person_info_key,txn_id)  AS revision
    FROM transformed.stg_ORDER_person_info_temp1
    )
    SELECT h.*
    FROM transformed.stg_ORDER_person_info_temp1 AS h
    INNER JOIN src ON src.revision = 1
    AND h.person_info_key = src.person_info_key
    AND h.txn_id = src.txn_id;

    insert into transformed.stg_ORDER_person_info
    select * from transformed.stg_ORDER_person_info_temp2;


    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
    

COMMIT;
   
     RETURN ''usp_insert_stg_ORDER_person_info executed successfully'';

EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_INBOX'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
                            
                            
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_RELEASE"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
  RESULT VARCHAR;
  error_object VARIANT;
  start_time_proc TIMESTAMP_NTZ(9);
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

    TRUNCATE TABLE transformed.stg_ORDER_release;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        

  create or replace temporary table transformed.stg_order_release_temp1
  as
  SELECT DISTINCT
    rooh.order_release_key,
    rooh.order_header_key,
    work_order_key,
    work_order_appt_key,
    release_no,
    merge_node,
    ship_to_key,
    shipnode_key,
    enterprise_key,
    buyer_organization_code,
    seller_organization_code,
    document_type,
    bill_to_id,
    ship_to_id,
    pick_list_no,
    scac,
    carrier_service_code,
    custcarrier_account_no,
    delivery_code,
    ship_advice_no,
    shipment_consol_group_id,
    packlist_type,
    sales_order_no,
    order_name,
    order_date,
    order_type,
    customer_po_no,
    mark_for_key,
    buyer_mark_for_node_id,
    cust_req_delivery_date,
    cust_req_ship_date,
    req_delivery_date,
    req_cancel_date,
    req_ship_date,
    priority_code,
    personalize_code,
    currency,
    hold_flag,
    hold_reason_code,
    fob,
    aor_flag,
    division,
    notify_after_shipment_flag,
    notification_type,
    notification_reference,
    ship_complete_flag,
    ship_node_class,
    supplier_code,
    supplier_name,
    release_seq_no,
    ship_order_complete,
    ship_line_complete,
    taxpayer_id,
    purpose,
    gift_flag,
    other_charges,
    receiving_node,
    buyer_receiving_node_id,
    delivery_method,
    pack_and_hold,
    department_code,
    item_classification,
    level_of_service,
    createts,
    rooh.modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    CAST(rooh.imported_date AS STRING) AS imported_date,
    txn_id
  FROM raw.raw_ORDER_release AS rooh
  INNER JOIN (
    SELECT DISTINCT MIN(MODIFYTS) AS MODIFYTS, order_release_key, order_header_key
    FROM raw.raw_ORDER_release
    WHERE processing_status IN (''Pending'', ''Failed'')
    GROUP BY order_release_key, order_header_key
  ) AS prelines
  ON prelines.MODIFYTS = rooh.MODIFYTS
  AND rooh.order_release_key = prelines.order_release_key
  AND rooh.order_header_key = prelines.order_header_key
  WHERE processing_status IN (''Pending'', ''Failed'') AND rooh.txn_id is not null;

 create or replace temporary table transformed.stg_order_release_temp2
  as
  WITH src AS (
    SELECT order_release_key, modifyts,
           ROW_NUMBER() OVER (PARTITION BY order_release_key ORDER BY order_release_key, modifyts) AS revision
    FROM transformed.stg_order_release_temp1
        )
        SELECT h.*
        FROM transformed.stg_order_release_temp1 AS h
        INNER JOIN src ON src.revision = 1
        AND h.order_release_key = src.order_release_key
        AND h.modifyts = src.modifyts;



    insert into  transformed.stg_order_release 
    select * from transformed.stg_order_release_temp2;


    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

        
  RETURN ''usp_insert_stg_order_release executed successfully'';
  EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_RELEASE'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_RELEASE_STATUS"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    RESULT VARCHAR;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

    TRUNCATE TABLE transformed.stg_ORDER_release_status;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        

    create or replace temporary table  transformed.stg_order_release_status_temp1
    as
    SELECT DISTINCT
        rooh.order_release_status_key,
        rooh.order_release_key,
        rooh.order_line_key,
        rooh.order_header_key,
        status,
        status_date,
        status_quantity,
        pipeline_key,
        order_line_schedule_key,
        total_quantity,
        expected_shipment_date,
        chained_to_order_line_key,
        chained_to_order_header_key,
        createts,
        rooh.modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        rooh.imported_date,
        txn_id,
        processing_status,
        processing_errortype,
        processing_comment
    FROM raw.raw_ORDER_release_status as rooh
    INNER JOIN (
        SELECT DISTINCT
            MIN(MODIFYTS) as MODIFYTS,
            order_release_status_key,
            order_release_key,
            order_header_key,
            order_line_key
        FROM raw.raw_ORDER_release_status
        WHERE processing_status IN (''Pending'',''Failed'')
        GROUP BY
            order_release_status_key,
            order_release_key,
            order_header_key,
            order_line_key
    ) as prelines
    ON prelines.MODIFYTS = rooh.MODIFYTS
        AND rooh.order_release_status_key = prelines.order_release_status_key
        AND rooh.order_header_key = prelines.order_header_key
        AND rooh.order_line_key = prelines.order_line_key
    WHERE processing_status IN (''Pending'',''Failed'') AND rooh.txn_id is not null;

   create or replace temporary table  transformed.stg_order_release_status_temp2
    as
    WITH src AS (
    SELECT order_release_status_key,
           order_release_key,
           order_header_key,
           order_line_key,
           txn_id,
           ROW_NUMBER() OVER (PARTITION BY order_release_status_key ORDER BY order_release_status_key, txn_id) AS       revision
        FROM transformed.stg_order_release_status_temp1
        )
        SELECT h.*
        FROM transformed.stg_order_release_status_temp1 AS h
        INNER JOIN src ON src.revision = 1
        AND h.order_release_status_key = src.order_release_status_key
        AND h.order_header_key = src.order_header_key
        AND h.order_line_key = src.order_line_key
        AND h.txn_id = src.txn_id;

        insert into transformed.stg_ORDER_release_status
        select * from transformed.stg_order_release_status_temp2;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);


    RETURN ''Success'';
      EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_RELEASE_STATUS'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_RELEASE_STATUS_ADD"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    RESULT VARCHAR;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    -- Truncate table
     TRUNCATE TABLE transformed.stg_ORDER_release_status;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        

    -- Insert into stg_oms_order_release_status
    create or replace temporary table  transformed.stg_order_release_status_add_temp1
    as
    SELECT DISTINCT
        raw.ORDER_RELEASE_STATUS_KEY,
        raw.ORDER_RELEASE_KEY,
        raw.ORDER_LINE_KEY,
        raw.ORDER_HEADER_KEY,
        raw.STATUS,
        raw.STATUS_DATE,
        raw.STATUS_QUANTITY,
        raw.PIPELINE_KEY,
        raw.ORDER_LINE_SCHEDULE_KEY,
        raw.TOTAL_QUANTITY,
        raw.EXPECTED_SHIPMENT_DATE,
        raw.CHAINED_TO_ORDER_LINE_KEY,
        raw.CHAINED_TO_ORDER_HEADER_KEY,
        raw.CREATETS,
        raw.MODIFYTS,
        raw.CREATEUSERID,
        raw.MODIFYUSERID,
        raw.CREATEPROGID,
        raw.MODIFYPROGID,
        raw.LOCKID,
        raw.imported_date,
        raw.txn_id
    FROM raw.raw_order_release_status raw
    INNER JOIN (
        SELECT MIN(MODIFYTS) AS MODIFYTS, order_line_key
        FROM raw.raw_order_release_status
        WHERE processing_status IN (''Pending'', ''Failed'')
          AND TRY_TO_NUMBER(status_quantity) > 0
        GROUP BY order_line_key
    ) prerecords
    ON raw.order_line_key = prerecords.order_line_key
       AND prerecords.MODIFYTS = raw.MODIFYTS
    INNER JOIN analytics.txn_order_detail tod
    ON tod.order_line_key = raw.order_line_key
    WHERE raw.processing_status IN (''Pending'', ''Failed'')
      AND TRY_TO_NUMBER(raw.status_quantity) > 0;

    -- Remove duplicates
    insert into  transformed.stg_order_release_status
    (  
  ORDER_RELEASE_STATUS_KEY,      
ORDER_RELEASE_KEY,      
ORDER_LINE_KEY,      
ORDER_HEADER_KEY,      
STATUS,      
STATUS_DATE,      
STATUS_QUANTITY,      
PIPELINE_KEY,      
ORDER_LINE_SCHEDULE_KEY,      
TOTAL_QUANTITY,      
EXPECTED_SHIPMENT_DATE,      
CHAINED_TO_ORDER_LINE_KEY,      
CHAINED_TO_ORDER_HEADER_KEY,      
CREATETS,      
MODIFYTS,      
CREATEUSERID,      
MODIFYUSERID,      
CREATEPROGID,      
MODIFYPROGID,      
LOCKID,      
imported_date,      
txn_id)
    select * from 
	(WITH src AS (
    SELECT 
        order_line_key,
        MODIFYTS,
        ROW_NUMBER() OVER (PARTITION BY order_line_key ORDER BY order_line_key, MODIFYTS) AS revision
    FROM transformed.stg_order_release_status_add_temp1
        )
        select h.*  FROM transformed.stg_order_release_status_add_temp1 h
        inner join src on src.revision = 1
        and src.order_line_key=h.order_line_key
        and src.MODIFYTS=h.MODIFYTS
        );


    -- Get record count
    LET toBeProcessedRecordCount INT := (
        SELECT COUNT(*)
        FROM transformed.stg_order_release_status
        WHERE TRY_TO_NUMBER(status_quantity) > 0
    );

    -- Update log_oms_files_import_status
    UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    WHERE file_name = ''YFS_ORDER_RELEASE_STATUS'';
	
 CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;

    RETURN ''Success'';
	
      EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_RELEASE_STATUS'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_RELEASE_STATUS_MULTIPART"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

    -- Truncate the staging table
    TRUNCATE TABLE  transformed.stg_ORDER_release_status_multipart;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
    

    create or replace temporary table transformed.stg_ORDER_release_status_multipart_temp as 
    SELECT DISTINCT
        raw.ORDER_RELEASE_STATUS_KEY,
        raw.ORDER_RELEASE_KEY,
        raw.ORDER_LINE_KEY,
        raw.ORDER_HEADER_KEY,
        raw.STATUS,
        raw.STATUS_DATE,
        raw.STATUS_QUANTITY,
        raw.PIPELINE_KEY,
        raw.ORDER_LINE_SCHEDULE_KEY,
        raw.TOTAL_QUANTITY,
        raw.EXPECTED_SHIPMENT_DATE,
        raw.CHAINED_TO_ORDER_LINE_KEY,
        raw.CHAINED_TO_ORDER_HEADER_KEY,
        raw.CREATETS,
        raw.MODIFYTS,
        raw.CREATEUSERID,
        raw.MODIFYUSERID,
        raw.CREATEPROGID,
        raw.MODIFYPROGID,
        raw.LOCKID,
        raw.imported_date,
        raw.txn_id,
        raw.processing_status ,
        raw.processing_errortype ,
        raw.processing_comment 
    FROM raw.raw_ORDER_release_status raw
    INNER JOIN (
        SELECT DISTINCT MIN(MODIFYTS) AS MODIFYTS, order_line_key
        FROM raw.raw_ORDER_release_status
        WHERE processing_status IN (''Pending'', ''Failed'') AND CAST(status_quantity AS NUMBER) > 0
        GROUP BY order_line_key
    ) AS prerecords ON raw.order_line_key = prerecords.order_line_key
    AND prerecords.MODIFYTS = raw.MODIFYTS
    INNER JOIN  analytics.txn_order_detail_multipart tod ON tod.order_line_key = raw.order_line_key
    WHERE processing_status IN (''Pending'', ''Failed'') AND CAST(status_quantity AS NUMBER) > 0 AND raw.txn_id is not null;

    
    -- Remove duplicate records from the staging table
    insert into  transformed.stg_ORDER_release_status_multipart 
   WITH src AS (
    SELECT order_line_key,modifyts,
           ROW_NUMBER() OVER (Partition By order_line_key Order By order_line_key,modifyts)  AS revision
    FROM transformed.stg_ORDER_release_status_multipart_temp
    )
    SELECT h.*
    FROM transformed.stg_ORDER_release_status_multipart_temp AS h
    INNER JOIN src ON src.revision = 1
    AND h.order_line_key = src.order_line_key
    AND h.modifyts = src.modifyts;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_RELEASE_STATUS_PART2"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

-- Truncate table stg_ORDER_release_status_part2
        TRUNCATE TABLE transformed.stg_ORDER_release_status_part2;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
        -- Insert data into stg_ORDER_release_status_part2
        create or replace temporary table stg_ORDER_release_status_part2_temp as
        SELECT DISTINCT
            raw.ORDER_RELEASE_STATUS_KEY,
            ORDER_RELEASE_KEY,
            raw.ORDER_LINE_KEY,
            raw.ORDER_HEADER_KEY,
            STATUS,
            STATUS_DATE,
            STATUS_QUANTITY,
            PIPELINE_KEY,
            ORDER_LINE_SCHEDULE_KEY,
            TOTAL_QUANTITY,
            EXPECTED_SHIPMENT_DATE,
            CHAINED_TO_ORDER_LINE_KEY,
            CHAINED_TO_ORDER_HEADER_KEY,
            CREATETS,
            raw.MODIFYTS,
            CREATEUSERID,
            MODIFYUSERID,
            CREATEPROGID,
            MODIFYPROGID,
            LOCKID,
            imported_date,
            txn_id,
            raw.PROCESSING_STATUS ,
            raw.PROCESSING_ERRORTYPE ,
            raw.PROCESSING_COMMENT
        FROM raw.raw_ORDER_release_status_part2 raw
        INNER JOIN (
            SELECT DISTINCT 
                MIN(MODIFYTS) AS MODIFYTS,
                ORDER_RELEASE_STATUS_KEY
            FROM  raw.raw_ORDER_release_status_part2
            WHERE 
                processing_status IN (''Pending'', ''Failed'')    
            GROUP BY 
                ORDER_RELEASE_STATUS_KEY
        ) AS prerecords  
        ON   
            raw.ORDER_RELEASE_STATUS_KEY = prerecords.ORDER_RELEASE_STATUS_KEY       
            AND prerecords.MODIFYTS = raw.MODIFYTS          
        WHERE 
            processing_status IN (''Pending'', ''Failed'') AND raw.txn_id is not null;
            
        -- Delete duplicate records
        INSERT INTO transformed.stg_ORDER_release_status_part2 
        with src as (
            SELECT 
                ORDER_RELEASE_STATUS_KEY,
                MODIFYTS,
                ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY ORDER BY ORDER_RELEASE_STATUS_KEY, MODIFYTS) AS revision
            FROM 
                stg_ORDER_release_status_part2_temp
        )  
        select  h.* from stg_ORDER_release_status_part2_temp h
            inner join src on src.revision = 1 
            AND h.ORDER_RELEASE_STATUS_KEY = src.ORDER_RELEASE_STATUS_KEY 
            AND h.MODIFYTS = src.MODIFYTS;

    
         --Select the count of records to be processed
    SELECT COUNT(*) INTO :toBeProcessedRecordCount
    FROM transformed.stg_ORDER_release_status_part2;

    --Update the log table with the count of records to be processed
    UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    --SET to_be_processed = (SELECT COUNT(*) FROM transformed.stg_ORDER_header)
    WHERE file_name = ''YFS_ORDER_RELEASE_STATUS_PART2'';

   CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    COMMIT;

    RETURN ''usp_insert_stg_ORDER_header executed successfully'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_RELEASE_STATUS_PART2'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
                            
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_SHIPMENT"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    

    -- Truncate staging table
    TRUNCATE TABLE IF EXISTS transformed.stg_ORDER_shipment;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
    
    -- Insert data into staging table
    create or replace temporary table transformed.stg_order_shipment_TEMP as
     SELECT Distinct
	rooh.shipment_key
	,pick_list_no
	,original_shipment_key
	,merge_node
	,pickticket_no
	,ship_date
	,unplaced_quantity
	,shipnode_key
	,receiving_node
	,buyer_receiving_node_id
	,shipment_consol_group_id
	,ship_mode
	,from_address_key
	,to_address_key
	,bill_to_address_key
	,ship_to_customer_id
	,bill_to_customer_id
	,has_other_shipments
	,parent_shipment_key
	,ship_via
	,seal_no
	,tracking_no
	,trailer_no
	,manifest_no
	,pro_no
	,scac
	,actual_freight_charge
	,carrier_service_code
	,requested_carrier_service_code
	,status
	,pod_no
	,bol_no
	,total_weight
	,total_weight_uom
	,total_volume
	,total_volume_uom
	,total_quantity
	,containerized_quantity
	,placed_quantity
	,is_product_placing_complete
	,is_pack_process_complete
	,is_revised
	,hold_flag
	,it_no
	,it_date
	,appointment_no
	,from_appointment
	,to_appointment
	,delivery_ts
	,code
	,num_of_pallets
	,num_of_cartons
	,export_taxpayer_id
	,freight_terms
	,delivery_code
	,carrier_type
	,download_count
	,currency
	,delivery_plan_key
	,shipment_no
	,pipeline_key
	,gift_flag
	,shipment_planned_flag
	,shipment_closed_flag
	,seller_organization_code
	,buyer_organization_code
	,enterprise_code
	,requested_shipment_date
	,expected_shipment_date
	,actual_shipment_date
	,requested_delivery_date
	,expected_delivery_date
	,actual_delivery_date
	,return_by_date
	,return_authorization_number
	,document_type
	,origin_zone
	,destination_zone
	,status_date
	,shipment_type
	,commercial_value
	,hazardous_material_flag
	,total_estimated_charge
	,total_actual_charge
	,next_alert_ts
	,shipment_confirm_updates_done
	,shipment_deliver_updates_done
	,shipment_containerized_flag
	,scac_integration_required
	,packlist_type
	,custcarrier_account_no
	,manifest_key
	,is_single_order
	,lines_entered
	,order_available_on_system
	,override_manual_shipment_entry
	,do_not_verify_pallet_content
	,do_not_verify_case_content
	,allow_overage
	,manually_entered
	,allow_new_item_receipt
	,order_no
	,order_header_key
	,release_no
	,order_release_key
	,export_license_no
	,export_license_exp_date
	,delivery_method
	,requires_appt_confirmation
	,work_order_key
	,work_order_appt_key
	,order_type
	,do_not_consolidate
	,department_code
	,item_classification
	,mark_for_key
	,buyer_mark_for_node_id
	,routing_contact_info
	,customer_po_no
	,carrier_pickup_time
	,pack_and_hold
	,esp_check_required
	,is_appointment_reqd
	,routing_source
	,routing_error_code
	,routing_guide_maintained
	,must_ship_before_date
	,priority_code
	,estimated_price
	,has_node_exceptions
	,cod_pay_method
	,airway_bill_no
	,invoice_complete
	,expected_pick_date
	,return_carrier_service
	,return_freight_terms
	,return_billing_account
	,break_bulk_node
	,bbn_min_weight
	,bbn_min_volume
	,fedx_open_ship_index
	,itn_no
	,email_return_label
	,profile_id
	,profileid_provided_by_sterling
	,level_of_service
	,hold_location
	,assigned_to_user_id
	,lockid
	,createts
	,rooh.modifyts
	,createuserid
	,modifyuserid
	,createprogid
	,modifyprogid
	,shipment_sort_location_id
	,carrier_sort_location_id
	,shipment_group_id
	,notification_sent
	,pickticket_printed
	,backroom_pick_required
	,included_in_batch
	,is_receiving_complete
	,received_damaged
	,index_version
	,extn_narvar_url
	,extn_is_sent
	,extn_is_email_sent
	,rooh.imported_date
	,txn_id
    FROM raw.raw_ORDER_shipment rooh
    INNER JOIN (
      SELECT DISTINCT
        MIN(modifyts) AS modifyts,
        shipment_key
      FROM raw.raw_ORDER_shipment
      WHERE processing_status IN (''Pending'', ''Failed'')
      GROUP BY shipment_key
    ) AS prelines
    ON prelines.modifyts = rooh.modifyts
    AND rooh.shipment_key = prelines.shipment_key 
    WHERE processing_status IN (''Pending'', ''Failed'') AND rooh.txn_id is not null;
    
    -- Delete duplicate records from staging table
    insert into transformed.stg_ORDER_shipment 
    (shipment_key
	,pick_list_no
	,original_shipment_key
	,merge_node
	,pickticket_no
	,ship_date
	,unplaced_quantity
	,shipnode_key
	,receiving_node
	,buyer_receiving_node_id
	,shipment_consol_group_id
	,ship_mode
	,from_address_key
	,to_address_key
	,bill_to_address_key
	,ship_to_customer_id
	,bill_to_customer_id
	,has_other_shipments
	,parent_shipment_key
	,ship_via
	,seal_no
	,tracking_no
	,trailer_no
	,manifest_no
	,pro_no
	,scac
	,actual_freight_charge
	,carrier_service_code
	,requested_carrier_service_code
	,status
	,pod_no
	,bol_no
	,total_weight
	,total_weight_uom
	,total_volume
	,total_volume_uom
	,total_quantity
	,containerized_quantity
	,placed_quantity
	,is_product_placing_complete
	,is_pack_process_complete
	,is_revised
	,hold_flag
	,it_no
	,it_date
	,appointment_no
	,from_appointment
	,to_appointment
	,delivery_ts
	,code
	,num_of_pallets
	,num_of_cartons
	,export_taxpayer_id
	,freight_terms
	,delivery_code
	,carrier_type
	,download_count
	,currency
	,delivery_plan_key
	,shipment_no
	,pipeline_key
	,gift_flag
	,shipment_planned_flag
	,shipment_closed_flag
	,seller_organization_code
	,buyer_organization_code
	,enterprise_code
	,requested_shipment_date
	,expected_shipment_date
	,actual_shipment_date
	,requested_delivery_date
	,expected_delivery_date
	,actual_delivery_date
	,return_by_date
	,return_authorization_number
	,document_type
	,origin_zone
	,destination_zone
	,status_date
	,shipment_type
	,commercial_value
	,hazardous_material_flag
	,total_estimated_charge
	,total_actual_charge
	,next_alert_ts
	,shipment_confirm_updates_done
	,shipment_deliver_updates_done
	,shipment_containerized_flag
	,scac_integration_required
	,packlist_type
	,custcarrier_account_no
	,manifest_key
	,is_single_order
	,lines_entered
	,order_available_on_system
	,override_manual_shipment_entry
	,do_not_verify_pallet_content
	,do_not_verify_case_content
	,allow_overage
	,manually_entered
	,allow_new_item_receipt
	,order_no
	,order_header_key
	,release_no
	,order_release_key
	,export_license_no
	,export_license_exp_date
	,delivery_method
	,requires_appt_confirmation
	,work_order_key
	,work_order_appt_key
	,order_type
	,do_not_consolidate
	,department_code
	,item_classification
	,mark_for_key
	,buyer_mark_for_node_id
	,routing_contact_info
	,customer_po_no
	,carrier_pickup_time
	,pack_and_hold
	,esp_check_required
	,is_appointment_reqd
	,routing_source
	,routing_error_code
	,routing_guide_maintained
	,must_ship_before_date
	,priority_code
	,estimated_price
	,has_node_exceptions
	,cod_pay_method
	,airway_bill_no
	,invoice_complete
	,expected_pick_date
	,return_carrier_service
	,return_freight_terms
	,return_billing_account
	,break_bulk_node
	,bbn_min_weight
	,bbn_min_volume
	,fedx_open_ship_index
	,itn_no
	,email_return_label
	,profile_id
	,profileid_provided_by_sterling
	,level_of_service
	,hold_location
	,assigned_to_user_id
	,lockid
	,createts
	,modifyts
	,createuserid
	,modifyuserid
	,createprogid
	,modifyprogid
	,shipment_sort_location_id
	,carrier_sort_location_id
	,shipment_group_id
	,notification_sent
	,pickticket_printed
	,backroom_pick_required
	,included_in_batch
	,is_receiving_complete
	,received_damaged
	,index_version
	,extn_narvar_url
	,extn_is_sent
	,extn_is_email_sent
	,imported_date
	,txn_id)      
     SELECT Distinct
     shipment_key
	,pick_list_no
	,original_shipment_key
	,merge_node
	,pickticket_no
	,ship_date
	,unplaced_quantity
	,shipnode_key
	,receiving_node
	,buyer_receiving_node_id
	,shipment_consol_group_id
	,ship_mode
	,from_address_key
	,to_address_key
	,bill_to_address_key
	,ship_to_customer_id
	,bill_to_customer_id
	,has_other_shipments
	,parent_shipment_key
	,ship_via
	,seal_no
	,tracking_no
	,trailer_no
	,manifest_no
	,pro_no
	,scac
	,actual_freight_charge
	,carrier_service_code
	,requested_carrier_service_code
	,status
	,pod_no
	,bol_no
	,total_weight
	,total_weight_uom
	,total_volume
	,total_volume_uom
	,total_quantity
	,containerized_quantity
	,placed_quantity
	,is_product_placing_complete
	,is_pack_process_complete
	,is_revised
	,hold_flag
	,it_no
	,it_date
	,appointment_no
	,from_appointment
	,to_appointment
	,delivery_ts
	,code
	,num_of_pallets
	,num_of_cartons
	,export_taxpayer_id
	,freight_terms
	,delivery_code
	,carrier_type
	,download_count
	,currency
	,delivery_plan_key
	,shipment_no
	,pipeline_key
	,gift_flag
	,shipment_planned_flag
	,shipment_closed_flag
	,seller_organization_code
	,buyer_organization_code
	,enterprise_code
	,requested_shipment_date
	,expected_shipment_date
	,actual_shipment_date
	,requested_delivery_date
	,expected_delivery_date
	,actual_delivery_date
	,return_by_date
	,return_authorization_number
	,document_type
	,origin_zone
	,destination_zone
	,status_date
	,shipment_type
	,commercial_value
	,hazardous_material_flag
	,total_estimated_charge
	,total_actual_charge
	,next_alert_ts
	,shipment_confirm_updates_done
	,shipment_deliver_updates_done
	,shipment_containerized_flag
	,scac_integration_required
	,packlist_type
	,custcarrier_account_no
	,manifest_key
	,is_single_order
	,lines_entered
	,order_available_on_system
	,override_manual_shipment_entry
	,do_not_verify_pallet_content
	,do_not_verify_case_content
	,allow_overage
	,manually_entered
	,allow_new_item_receipt
	,order_no
	,order_header_key
	,release_no
	,order_release_key
	,export_license_no
	,export_license_exp_date
	,delivery_method
	,requires_appt_confirmation
	,work_order_key
	,work_order_appt_key
	,order_type
	,do_not_consolidate
	,department_code
	,item_classification
	,mark_for_key
	,buyer_mark_for_node_id
	,routing_contact_info
	,customer_po_no
	,carrier_pickup_time
	,pack_and_hold
	,esp_check_required
	,is_appointment_reqd
	,routing_source
	,routing_error_code
	,routing_guide_maintained
	,must_ship_before_date
	,priority_code
	,estimated_price
	,has_node_exceptions
	,cod_pay_method
	,airway_bill_no
	,invoice_complete
	,expected_pick_date
	,return_carrier_service
	,return_freight_terms
	,return_billing_account
	,break_bulk_node
	,bbn_min_weight
	,bbn_min_volume
	,fedx_open_ship_index
	,itn_no
	,email_return_label
	,profile_id
	,profileid_provided_by_sterling
	,level_of_service
	,hold_location
	,assigned_to_user_id
	,lockid
	,createts
	,modifyts
	,createuserid
	,modifyuserid
	,createprogid
	,modifyprogid
	,shipment_sort_location_id
	,carrier_sort_location_id
	,shipment_group_id
	,notification_sent
	,pickticket_printed
	,backroom_pick_required
	,included_in_batch
	,is_receiving_complete
	,received_damaged
	,index_version
	,extn_narvar_url
	,extn_is_sent
	,extn_is_email_sent
	,imported_date
	,txn_id from 
    (select * from (with src as (
      SELECT
        shipment_key,
        txn_id,
        ROW_NUMBER() OVER (PARTITION BY shipment_key ORDER BY shipment_key, txn_id) AS revision
      FROM transformed.stg_order_shipment_temp
    )
     select h.* from transformed.stg_order_shipment_temp h
        inner join src on
     src.revision = 1 
    AND h.shipment_key = src.shipment_key 
    AND h.txn_id = src.txn_id));

     --Select the count of records to be processed
    SELECT COUNT(*) INTO :toBeProcessedRecordCount
    FROM transformed.stg_ORDER_shipment;

    --Update the log table with the count of records to be processed
    UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    --SET to_be_processed = (SELECT COUNT(*) FROM transformed.stg_ORDER_shipment)
    WHERE file_name = ''YFS_SHIPMENT'';


    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    RETURN ''usp_insert_stg_order_shipment executed successfully'';

COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_SHIPMENT'';
            -- Return error message

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_SHIPMENT_CONTAINER"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
BEGIN

   start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

-- Truncate table stg_order_shipment_container
        TRUNCATE TABLE transformed.stg_ORDER_shipment_container;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
        -- Insert data into stg_order_shipment_container
        create or replace temporary table transformed.stg_order_shipment_container_temp as
        SELECT DISTINCT 
            rooh.shipment_container_key,
            manifest_key,
            rooh.shipment_key,
            load_key,
            pipeline_key,
            status,
            document_type,
            order_header_key,
            order_release_key,
            ship_to_key,
            container_seq_no,
            tracking_no,
            cod_return_tracking_no,
            cod_amount,
            ucc128code,
            manifest_no,
            container_scm,
            container_epc,
            container_type,
            corrugation_item_key,
            container_length,
            container_width,
            container_height,
            container_gross_weight,
            container_net_weight,
            container_length_uom,
            container_height_uom,
            container_width_uom,
            container_gross_weight_uom,
            container_net_weight_uom,
            applied_weight_uom,
            has_other_containers,
            master_container_no,
            actual_freight_charge,
            scac,
            ship_date,
            ship_mode,
            zone,
            oversized_flag,
            dimmed_flag,
            carrier_bill_account,
            carrier_payment_type,
            astra_code,
            routing_code,
            service_type,
            carrier_location_id,
            carrier_service_code,
            applied_weight,
            actual_weight,
            actual_weight_uom,
            commitment_code,
            delivery_day,
            deliver_by,
            form_id,
            basic_freight_charge,
            special_services_surcharge,
            delivery_code,
            barcode_discount,
            discount_amount,
            customs_value,
            carriage_value,
            declared_value,
            export_license_no,
            export_license_exp_date,
            freight_terms,
            custcarrier_account_no,
            container_no,
            parent_container_key,
            parent_container_no,
            container_group,
            parent_container_group,
            is_received,
            is_pack_process_complete,
            status_date,
            used_during_pick,
            system_suggested,
            contains_std_qty,
            task_type,
            service_item_id,
            is_hazmat,
            required_no_of_return_labels,
            actual_no_of_return_labels,
            external_reference_1,
            is_manifested,
            lockid,
            createts,
            rooh.modifyts,
            createuserid,
            modifyuserid,
            createprogid,
            modifyprogid,
            wave_key,
            extn_return_label,
            extn_return_bol,
            rooh.imported_date,
            txn_id
        FROM 
            raw.raw_ORDER_shipment_container as rooh
        INNER JOIN (
            SELECT DISTINCT 
                min(MODIFYTS) as MODIFYTS, 
                shipment_container_key, 
                shipment_key
            FROM 
                raw.raw_ORDER_shipment_container
            WHERE 
                processing_status IN (''Pending'',''Failed'') 
            GROUP BY 
                shipment_container_key, 
                shipment_key 
        ) as prelines  
        ON 
            prelines.MODIFYTS = rooh.MODIFYTS 
            AND rooh.shipment_container_key = prelines.shipment_container_key 
            AND rooh.shipment_key = prelines.shipment_key
        WHERE 
            processing_status IN (''Pending'',''Failed'') AND rooh.txn_id is not null;

        -- Delete duplicate records
        INSERT INTO stg_ORDER_shipment_container 
        with src as (
            SELECT 
                shipment_container_key,
                txn_id,
                ROW_NUMBER() OVER (
                    PARTITION BY shipment_container_key 
                    ORDER BY shipment_container_key, txn_id
                ) AS revision
            FROM 
                stg_order_shipment_container_temp
        ) 
        select h.* from transformed.stg_order_shipment_container_temp h
         inner join src on
            src.revision = 1 
            AND h.shipment_container_key = src.shipment_container_key 
            AND h.txn_id = src.txn_id;
            
     --Select the count of records to be processed
    SELECT COUNT(*) INTO :toBeProcessedRecordCount
    FROM transformed.stg_ORDER_shipment_container;

    --Update the log table with the count of records to be processed
    UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    --SET to_be_processed = (SELECT COUNT(*) FROM transformed.stg_ORDER_shipment_container)
    WHERE file_name = ''YFS_SHIPMENT_CONTAINER'';

   CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    COMMIT;
    RETURN ''usp_insert_stg_order_shipment_container executed successfully'';
    
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_SHIPMENT_CONTAINER'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
                            
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_SHIPMENT_LINE"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    toBeProcessedRecordCount INT;
    error_object VARIANT; 
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN
        start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    

        -- Truncate table stg_order_shipment_line
        TRUNCATE TABLE IF EXISTS transformed.stg_order_shipment_line;

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
        -- Insert data into stg_order_shipment_line
        create or replace temporary table  transformed.stg_order_shipment_line_temp as
        SELECT DISTINCT 
            rooh.shipment_line_key,
            rooh.shipment_key,
            shipment_line_no,
            shipment_sub_line_no,
            parent_shipment_line_key,
            order_header_key,
            order_release_key,
            order_line_key,
            order_no,
            release_no,
            prime_line_no,
            sub_line_no,
            item_id,
            product_class,
            uom,
            net_weight,
            net_weight_uom,
            country_of_origin,
            fifo_no,
            quantity,
            over_ship_quantity,
            original_quantity,
            kit_qty,
            requested_tag_number,
            requested_serial_no,
            item_description,
            segment,
            segment_type,
            shortage_qty,
            customer_po_no,
            customer_po_line_no,
            mark_for_key,
            buyer_mark_for_node_id,
            order_type,
            shipment_consol_group_id,
            ship_to_customer_id,
            kit_code,
            is_pickable,
            department_code,
            gift_flag,
            external_release_identifier,
            is_hazmat,
            return_shipping_label_level,
            level_of_service,
            pick_location,
            pick_location_seq,
            group_sequence_num,
            lockid,
            createts,
            rooh.modifyts,
            createuserid,
            modifyuserid,
            createprogid,
            modifyprogid,
            wave_no,
            backroom_picked_qty,
            customer_picked_qty,
            shortage_resolution_reason,
            cancel_reason,
            is_pack_complete,
            backroom_pick_complete,
            is_customer_pick_complete,
            staging_complete,
            staged_qty,
            store_batch_key,
            batch_pick_priority,
            store_batch_location_key,
            rooh.imported_date,
            txn_id
        FROM 
            raw.raw_order_shipment_line as rooh
        INNER JOIN (
            SELECT DISTINCT 
                MIN(MODIFYTS) as MODIFYTS, 
                shipment_line_key, 
                shipment_key
            FROM 
                raw.raw_order_shipment_line
            WHERE 
                processing_status IN (''Pending'',''Failed'') 
            GROUP BY 
                shipment_line_key, 
                shipment_key 
        ) as prelines  
        ON 
            prelines.MODIFYTS = rooh.MODIFYTS 
            AND rooh.shipment_line_key = prelines.shipment_line_key 
            AND rooh.shipment_key = prelines.shipment_key 
        WHERE 
            processing_status IN (''Pending'',''Failed'') AND rooh.txn_id is not null;
        
        -- Delete duplicate records
        insert into transformed.stg_order_shipment_line
        with src as (
            SELECT 
                shipment_line_key,
                txn_id,
                ROW_NUMBER() OVER (
                    PARTITION BY shipment_line_key 
                    ORDER BY shipment_line_key, txn_id
                ) AS revision
            FROM 
                transformed.stg_order_shipment_line_temp
        ) 
        select h.* from transformed.stg_order_shipment_line_temp h
        inner join src on 
            src.revision = 1 
            AND h.shipment_line_key = src.shipment_line_key 
            AND h.txn_id = src.txn_id;


             --Select the count of records to be processed
    SELECT COUNT(*) INTO :toBeProcessedRecordCount
    FROM transformed.stg_order_shipment_line;

    --Update the log table with the count of records to be processed
    UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    --SET to_be_processed = (SELECT COUNT(*) FROM transformed.stg_order_shipment_line)
    WHERE file_name = ''YFS_SHIPMENT_LINE'';

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    RETURN ''usp_insert_stg_order_shipment_line executed successfully'';


COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_SHIPMENT_LINE'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
    
END';
CREATE PROCEDURE "USP_INSERT_STG_ORDER_TAX_BREAKUP"("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
        toBeProcessedRecordCount INT ;
        error_object VARIANT;
        start_time_proc TIMESTAMP_NTZ(9); 
    BEGIN

        start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
    
        -- Truncate table stg_ORDER_tax_breakup
        TRUNCATE TABLE transformed.stg_ORDER_tax_breakup;

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );
        
        
        -- Insert data into stg_ORDER_tax_breakup
        create or replace temporary table  transformed.stg_ORDER_tax_breakup_temp1 as
            
        SELECT DISTINCT
            raw.TAX_BREAKUP_KEY,
            raw.HEADER_KEY,
            raw.LINE_KEY,
            RECORD_TYPE,
            CHARGE_CATEGORY,
            CHARGE_NAME,
            TAX_NAME,
            TAXABLE_FLAG,
            TAX_PERCENTAGE,
            TAX,
            INVOICED_TAX,
            REFERENCE1,
            REFERENCE2,
            REFERENCE3,
            CREATETS,
            raw.MODIFYTS,
            CREATEUSERID,
            MODIFYUSERID,
            CREATEPROGID,
            MODIFYPROGID,
            LOCKID,
            raw.imported_date,
            txn_id,
            PROCESSING_STATUS,
            PROCESSING_ERRORTYPE,
            PROCESSING_COMMENT
        FROM
             raw.raw_ORDER_tax_breakup raw
        INNER JOIN (
            SELECT DISTINCT  
                MIN(MODIFYTS) as MODIFYTS,
                TAX_BREAKUP_KEY,
                header_key,
                LINE_KEY 
            FROM 
                raw.raw_ORDER_tax_breakup 
            WHERE 
                processing_status IN (''Pending'', ''Failed'') 
            GROUP BY 
                TAX_BREAKUP_KEY, 
                header_key,
                LINE_KEY
        ) AS prerecords  
        ON   
            raw.TAX_BREAKUP_KEY = prerecords.TAX_BREAKUP_KEY 
            AND raw.header_key = prerecords.header_key 
            AND prerecords.MODIFYTS = raw.MODIFYTS
        WHERE 
            processing_status IN (''Pending'', ''Failed'') 
            AND raw.record_type = ''ORD'' AND raw.txn_id is not null;
            
        -- Delete duplicate records
        create or replace temporary table transformed.stg_ORDER_tax_breakup_temp2 as 
        WITH src AS (
        SELECT TAX_BREAKUP_KEY,modifyts,
               ROW_NUMBER() OVER (Partition By TAX_BREAKUP_KEY Order By TAX_BREAKUP_KEY,modifyts)  AS revision
        FROM transformed.stg_ORDER_tax_breakup_temp1
        )
        SELECT h.*
        FROM transformed.stg_ORDER_tax_breakup_temp1 AS h
        INNER JOIN src ON src.revision = 1
        AND h.TAX_BREAKUP_KEY = src.TAX_BREAKUP_KEY
        AND h.modifyts = src.modifyts;

        insert into transformed.stg_ORDER_tax_breakup 
        (TAX_BREAKUP_KEY,
        HEADER_KEY,
        LINE_KEY,
        RECORD_TYPE,
        CHARGE_CATEGORY,
        CHARGE_NAME,
        TAX_NAME,
        TAXABLE_FLAG,
        TAX_PERCENTAGE,
        TAX,
        INVOICED_TAX,
        REFERENCE1,
        REFERENCE2,
        REFERENCE3,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID,
        imported_date,
        txn_id,
        PROCESSING_STATUS,
            PROCESSING_ERRORTYPE,
            PROCESSING_COMMENT)
        select 
        TAX_BREAKUP_KEY,
    HEADER_KEY,
    LINE_KEY,
    RECORD_TYPE,
    CHARGE_CATEGORY,
    CHARGE_NAME,
    TAX_NAME,
    TAXABLE_FLAG,
    TAX_PERCENTAGE,
    TAX,
    INVOICED_TAX,
    REFERENCE1,
    REFERENCE2,
    REFERENCE3,
    CREATETS,
    MODIFYTS,
    CREATEUSERID,
    MODIFYUSERID,
    CREATEPROGID,
    MODIFYPROGID,
    LOCKID,
    imported_date,
    txn_id ,PROCESSING_STATUS,
            PROCESSING_ERRORTYPE,
            PROCESSING_COMMENT from transformed.stg_ORDER_tax_breakup_temp2;
        
        -- Get count of records to be processed
        
        SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM transformed.stg_ORDER_tax_breakup;
        
        -- Update log_files_import_status table with the count
        UPDATE analytics.log_files_import_status
        SET to_be_processed = :toBeProcessedRecordCount
        WHERE file_name = ''YFS_TAX_BREAKUP'';

   CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Staging completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

    COMMIT;
    RETURN ''USP_INSERT_STG_ORDER_TAX_BREAKUP executed successfully'';
    
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_SHIPMENT_CONTAINER'';

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;        
END';

