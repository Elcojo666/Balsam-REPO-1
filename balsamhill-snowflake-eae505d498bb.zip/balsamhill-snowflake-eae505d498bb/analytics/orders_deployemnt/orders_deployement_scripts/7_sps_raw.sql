CREATE OR REPLACE PROCEDURE RAW.USP_RAW_TXN_ID_UPDATE("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
	txn_id string;
    captured_time timestamp;
BEGIN
 captured_time := current_timestamp();
 txn_id :=  md5(:captured_time) ;
 
 insert into  RAW.txn_id_REFERENCE (txn_id,id_ts) 
 values (:txn_id,:captured_time);

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
   
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''Staging started''
    );

 
-- Update for RAW_ORDER_AUDIT
UPDATE RAW.RAW_ORDER_AUDIT
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_AUDIT_LEVEL
UPDATE RAW.RAW_ORDER_AUDIT_LEVEL
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_CHARGE_TRANSACTION
UPDATE RAW.RAW_ORDER_CHARGE_TRANSACTION
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_CONTAINER_DETAILS
UPDATE RAW.RAW_ORDER_CONTAINER_DETAILS
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_CREDIT_CARD_TRANSACTION
UPDATE RAW.RAW_ORDER_CREDIT_CARD_TRANSACTION
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_GTIN_DATA
UPDATE RAW.RAW_ORDER_GTIN_DATA
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_INVOICE
UPDATE RAW.RAW_ORDER_INVOICE
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_PERSON_INFO
UPDATE RAW.RAW_ORDER_PERSON_INFO
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_RELEASE_STATUS
UPDATE RAW.RAW_ORDER_RELEASE_STATUS
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_SHIPMENT
UPDATE RAW.RAW_ORDER_SHIPMENT
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_SHIPMENT_CONTAINER
UPDATE RAW.RAW_ORDER_SHIPMENT_CONTAINER
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_HEADER
UPDATE RAW.RAW_ORDER_HEADER
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_HOLD_TYPE
UPDATE RAW.RAW_ORDER_HOLD_TYPE
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_TAX_BREAKUP
UPDATE RAW.RAW_ORDER_TAX_BREAKUP
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_NOTES
UPDATE RAW.RAW_ORDER_NOTES
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_LINE_CHARGES
UPDATE RAW.RAW_ORDER_LINE_CHARGES
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_HEADER_CHARGES
UPDATE RAW.RAW_ORDER_HEADER_CHARGES
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_RELEASE
UPDATE RAW.RAW_ORDER_RELEASE
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_SHIPMENT_LINE
UPDATE RAW.RAW_ORDER_SHIPMENT_LINE
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_INBOX
UPDATE RAW.RAW_ORDER_INBOX
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_PAYMENT
UPDATE RAW.RAW_ORDER_PAYMENT
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_RELEASE_STATUS_PART2
UPDATE RAW.RAW_ORDER_RELEASE_STATUS_PART2
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;

-- Update for RAW_ORDER_LINE
UPDATE RAW.RAW_ORDER_LINE
SET txn_id = :txn_id
WHERE PROCESSING_STATUS = ''Pending'' 
  AND txn_id is null;


   
 CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''Update'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Update completed successfully''
    );

    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;

    RETURN ''Raw table txn_id has been updated Successfully'';
	
      EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''staging'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
END';





