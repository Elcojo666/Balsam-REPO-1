select * 
from dbo.audit_order_discount
where created_date > '2025-03-18 19:53:00.237' OR modified_date > '2025-03-18 19:53:00.237';