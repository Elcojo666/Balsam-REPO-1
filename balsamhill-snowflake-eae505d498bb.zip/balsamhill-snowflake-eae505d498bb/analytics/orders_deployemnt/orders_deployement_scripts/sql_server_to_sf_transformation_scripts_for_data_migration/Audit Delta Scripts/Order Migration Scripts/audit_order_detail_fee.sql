select *
from dbo.audit_order_detail_fee
where created_date > '2025-01-29 01:48:18.327' OR modified_date > '2025-01-29 01:48:18.327'
