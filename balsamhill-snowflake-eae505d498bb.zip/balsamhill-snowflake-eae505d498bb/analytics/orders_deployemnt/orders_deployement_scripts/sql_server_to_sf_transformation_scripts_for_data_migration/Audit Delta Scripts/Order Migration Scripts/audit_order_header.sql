SELECT fk_sourceid
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN source_ref_num IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(source_ref_num, 1) IN ('/', '\') AND RIGHT(source_ref_num, 1) IN ('/', '\') AND LEN(source_ref_num) > 2) 
        THEN SUBSTRING(source_ref_num, 2, LEN(source_ref_num) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(source_ref_num, 1) IN ('/', '\') AND LEN(source_ref_num) > 1
        THEN SUBSTRING(source_ref_num, 2, LEN(source_ref_num) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(source_ref_num, 1) IN ('/', '\') AND LEN(source_ref_num) > 1
        THEN LEFT(source_ref_num, LEN(source_ref_num) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE source_ref_num
		
	END AS source_ref_num
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN ext_order_id IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(ext_order_id, 1) IN ('/', '\') AND RIGHT(ext_order_id, 1) IN ('/', '\') AND LEN(ext_order_id) > 2) 
        THEN SUBSTRING(ext_order_id, 2, LEN(ext_order_id) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(ext_order_id, 1) IN ('/', '\') AND LEN(ext_order_id) > 1
        THEN SUBSTRING(ext_order_id, 2, LEN(ext_order_id) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(ext_order_id, 1) IN ('/', '\') AND LEN(ext_order_id) > 1
        THEN LEFT(ext_order_id, LEN(ext_order_id) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE ext_order_id
		
	END AS ext_order_id
      ,is_domestic
      ,fk_shipping_addressid
      ,fk_billing_addressid
      ,fk_customerid
      ,fk_currencyid
      ,fk_shipping_methodid
      ,payment_amount
      ,gross_amount
      ,discount_amount
      ,fee_amount
      ,tax_amount
      ,shpping_fee_amount
      ,personalization_fee_amount
      ,net_amount
      ,fk_order_typeid
      ,fk_order_statusid
      ,fk_parent_order_headerid
      ,inserted_date
      ,modified_date
      ,created_by
      ,pk_order_headerid
      ,email_address
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN order_comments IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(order_comments, 1) IN ('/', '\') AND RIGHT(order_comments, 1) IN ('/', '\') AND LEN(order_comments) > 2) 
        THEN SUBSTRING(order_comments, 2, LEN(order_comments) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(order_comments, 1) IN ('/', '\') AND LEN(order_comments) > 1
        THEN SUBSTRING(order_comments, 2, LEN(order_comments) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(order_comments, 1) IN ('/', '\') AND LEN(order_comments) > 1
        THEN LEFT(order_comments, LEN(order_comments) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE order_comments
		
	END AS order_comments
      , NULL AS order_notes
      ,tax_exempt
      ,salesrep_customerid
      ,override_errors_warnings
      ,risk_status
      ,ship_residential
      ,order_date
      ,Revision
      ,original_order_number
      ,is_bfy17
      ,group_control_number
      ,extn_order_locale_code
      ,seller_organization_code
      ,customer_first_name
      ,customer_last_name
      ,modifyuserid
      ,createuserid
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
      ,entered_by
      ,entry_type
      ,order_header_key
      ,extn_brand
      ,extn_sub_order_type
      ,extn_order_total
	  ,null as modifyts
  FROM dbo.audit_order_header
  where inserted_date > '2025-03-18 17:52:17.910' OR modified_date > '2025-03-18 17:52:24.687';
