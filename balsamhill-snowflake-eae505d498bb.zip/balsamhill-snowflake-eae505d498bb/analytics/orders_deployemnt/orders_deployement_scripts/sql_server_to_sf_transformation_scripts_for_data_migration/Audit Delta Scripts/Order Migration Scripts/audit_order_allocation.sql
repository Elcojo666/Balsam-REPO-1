select *
from dbo.audit_order_allocation
where inserted_date > '2025-03-18 12:38:28.000' OR modified_date > '2025-03-18 12:38:28.000'
