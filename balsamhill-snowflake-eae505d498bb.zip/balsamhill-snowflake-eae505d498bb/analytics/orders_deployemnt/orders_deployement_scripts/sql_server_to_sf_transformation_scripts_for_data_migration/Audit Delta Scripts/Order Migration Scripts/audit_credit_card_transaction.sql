SELECT credit_card_transaction_key
      ,charge_transaction_key
      ,tran_type
      ,convert(float,tran_amount) as tran_amount
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(tran_request_time,13,0,':'),11,0,':'),9,0,' ')) as  tran_request_time
      ,tran_return_code
      ,tran_return_message
      ,tran_return_flag
      ,request_id
      ,internal_return_code
      ,internal_return_flag
      ,internal_return_message
      ,convert(float,auth_amount) as auth_amount
      ,auth_code
      ,auth_avs
      ,auth_return_code
      ,auth_return_flag
      ,auth_return_message
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(auth_time,13,0,':'),11,0,':'),9,0,' ')) as auth_time
      ,parent_key
      ,reference1
      ,reference2
      ,cvv_auth_code
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,lockid
      ,inserted_date
      ,modified_date
	  ,revision
  FROM dbo.audit_credit_card_transaction
  where inserted_date > '2025-03-18 09:46:43.073';
