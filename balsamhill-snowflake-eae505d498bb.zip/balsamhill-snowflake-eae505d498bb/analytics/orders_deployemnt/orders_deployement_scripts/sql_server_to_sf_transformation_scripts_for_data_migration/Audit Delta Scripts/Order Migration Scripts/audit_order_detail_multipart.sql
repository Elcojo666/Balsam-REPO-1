SELECT  pk_order_detail_multipartid
      ,fk_order_detailid
      ,order_line_key
      ,order_header_key
      ,prime_line_no
      ,sub_line_no
      ,line_type
      ,order_class
      ,item_id
      ,alternate_item_id
      ,uom
      ,product_class
      ,convert(float,unit_price) as unit_price
      ,cost_currency
      ,ordered_qty
      ,basic_capacity_required
      ,option_capacity_required
      ,dependent_on_line_key
      ,current_work_order_key
      ,dependency_shipping_rule
      ,fill_quantity
      ,committed_quantity
      ,dependency_ratio
      ,maintain_ratio
      ,merge_node
      ,parent_of_dependent_group
      ,source_from_organization
      ,chained_from_order_line_key
      ,chained_from_order_header_key
      ,derived_from_order_line_key
      ,derived_from_order_header_key
      ,derived_from_order_release_key
      ,distribution_rule_id
      ,invoiced_quantity
      ,over_receipt_quantity
      ,return_reason
      ,shipnode_key
      ,procure_from_node
      ,ship_to_key
      ,mark_for_key
      ,buyer_mark_for_node_id
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(req_delivery_date,13,0,':'),11,0,':'),9,0,' ')) as req_delivery_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(req_cancel_date,13,0,':'),11,0,':'),9,0,' ')) as req_cancel_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(req_ship_date,13,0,':'),11,0,':'),9,0,' ')) as req_ship_date
      ,scac
      ,carrier_service_code
      ,carrier_account_no
      ,pickable_flag
      ,ship_together_no
      ,hold_flag
      ,kit_code
      ,hold_reason_code
      ,other_charges
      ,convert(float,line_total) as line_total
      ,convert(float,invoiced_line_total) as invoiced_line_total
      ,convert(float,invoiced_extended_price) as invoiced_extended_price
      ,settled_quantity
      ,settled_amount
      ,taxable_flag
      ,tax_exemption_certificate
      ,discount_type
      ,discount_reference
      ,gift_flag
      ,personalize_flag
      ,personalize_code
      ,department_code
      ,customer_item
      ,customer_item_description
      ,item_weight
      ,item_weight_uom
      ,item_description
      ,item_short_description
      ,reservation_id
      ,reservation_pool
      ,customer_po_no
      ,customer_po_line_no
      ,tax
      ,delivery_code
      ,original_ordered_qty
      ,convert(float,list_price) as list_price
      ,convert(float,retail_price) as retail_price
      ,discount_percentage
      ,packlist_type
      ,supplier_item
      ,supplier_item_description
      ,unit_cost
      ,upc_code
      ,fob
      ,manufacturer_name
      ,manufacturer_item
      ,manufacturer_item_desc
      ,country_of_origin
      ,isbn
      ,harmonized_code
      ,ship_to_id
      ,product_line
      ,nmfc_code
      ,nmfc_class
      ,nmfc_description
      ,tax_product_code
      ,import_license_no
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(import_license_exp_date,13,0,':'),11,0,':'),9,0,' ')) as  import_license_exp_date
      ,eccn_no
      ,schedule_b_code
      ,supplier_code
      ,purpose
      ,receiving_node
      ,buyer_receiving_node_id
      ,shipment_consol_group_id
      ,orig_order_line_key
      ,line_seq_no
      ,split_qty
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(pricing_date,13,0,':'),11,0,':'),9,0,' ')) as   pricing_date
      ,pipeline_key
      ,condition_variable_1
      ,condition_variable_2
      ,is_price_locked
      ,is_cost_overridden
      ,is_capacity_overridden
      ,invoice_complete
      ,delivery_method
      ,item_group_code
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(cannot_complete_before_date,13,0,':'),11,0,':'),9,0,' ')) as    cannot_complete_before_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(cannot_complete_after_date,13,0,':'),11,0,':'),9,0,' ')) as    cannot_complete_after_date
      ,appt_status
      ,can_add_service_lines
      ,pricing_uom
      ,capacity_uom
      ,pricing_quantity
      ,shipped_quantity
      ,fixed_capacity_qty_per_line
      ,fixed_pricing_qty_per_line
      ,wait_for_seq_line
      ,sched_failure_reason_code
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(earliest_ship_date,13,0,':'),11,0,':'),9,0,' ')) as     earliest_ship_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(earliest_delivery_date,13,0,':'),11,0,':'),9,0,' ')) as     earliest_delivery_date
      ,cannot_meet_appt
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(promised_appt_start_date,13,0,':'),11,0,':'),9,0,' ')) as     promised_appt_start_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(promised_appt_end_date,13,0,':'),11,0,':'),9,0,' ')) as     promised_appt_end_date
      ,segment
      ,segment_type
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(earliest_schedule_date,13,0,':'),11,0,':'),9,0,' ')) as earliest_schedule_date
      ,timezone
      ,is_forwarding_allowed
      ,is_procurement_allowed
      ,reship_parent_line_key
      ,bundle_parent_order_line_key
      ,is_price_info_only
      ,level_of_service
      ,first_iter_seq_no
      ,last_iter_seq_no
	  ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
	  ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,lockid
      ,ordering_uom
      ,pricing_quantity_conv_factor
      ,pricing_quantity_strategy
      ,invoiced_pricing_quantity
      ,is_standalone_service
      ,tran_discrepancy_qty
      ,received_quantity
      ,invoice_based_on_actuals
      ,actual_pricing_quantity
      ,fulfillment_type
      ,serial_no
      ,reservation_mandatory
      ,is_firm_predefined_node
      ,intentional_backorder
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(future_avail_date,13,0,':'),11,0,':'),9,0,' ')) as future_avail_date
      ,repricing_quantity
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(min_ship_by_date,13,0,':'),11,0,':'),9,0,' ')) as min_ship_by_date
      ,kit_qty
      ,bom_config_key
      ,bundle_fulfillment_mode
      ,is_gift_wrap
      ,group_sequence_num
      ,in_store_payment_required
      ,item_not_exist
      ,derived_from_ext_ord
      ,is_eligible_for_ship_disc
      ,backorder_notification_qty
      ,is_price_matched
      ,is_pick_up_now
      ,item_is_in_hand
      ,disposition_code
      ,extn_mod_reason_code
      ,extn_mod_reason_desc
      ,extn_asn
      ,extn_parent_order_no
      ,extn_item_id
      ,extn_order_item_id
      ,extn_price_type
      ,extn_secondary_return_reason
      ,extn_apply_label_fee
      ,extn_is_activation_complete
      ,extn_item_desc
      ,extn_return_carton_count
      ,extn_asn_quantity
      ,extn_light_color
      ,extn_light_type
      ,extn_number_of_sections
      ,extn_total_cartons
      ,extn_tree_height
      ,extn_tree_height_uom
	  ,revision
      ,extn_apply_restocking_fee
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(extn_return_pickup_date,13,0,':'),11,0,':'),9,0,' ')) as extn_return_pickup_date
      ,extn_pickup_confirmation_no
      ,extn_refund_shipping_cost
      ,extn_is_fulfilled_line
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(extn_mfg_warranty_start_date,13,0,':'),11,0,':'),9,0,' ')) as  extn_mfg_warranty_start_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(extn_mfg_warranty_end_date,13,0,':'),11,0,':'),9,0,' ')) as  extn_mfg_warranty_end_date
      ,extn_term
      ,extn_is_invoice_required
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(extn_prem_guarantee_end_date,13,0,':'),11,0,':'),9,0,' ')) as extn_prem_guarantee_end_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(extn_return_date,13,0,':'),11,0,':'),9,0,' ')) as extn_return_date
      ,extn_is_email_sent
      ,extn_return_required
      ,extn_parent_prime_line_no
      ,extn_parent_sub_line_no
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(extn_prem_guarantee_start_date,13,0,':'),11,0,':'),9,0,' ')) as extn_prem_guarantee_start_date
      ,extn_reship_upcid
      ,extn_parent_order_line_sku
  FROM dbo.audit_order_detail_multipart
where CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) > '2025-03-18 16:32:53.000' OR 
CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) > '2025-03-18 17:15:20.000';
