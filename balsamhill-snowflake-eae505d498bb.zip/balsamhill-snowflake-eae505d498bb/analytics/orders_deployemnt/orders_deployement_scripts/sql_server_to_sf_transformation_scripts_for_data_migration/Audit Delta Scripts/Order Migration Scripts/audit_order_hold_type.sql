select * 
from dbo.audit_order_hold_type
where inserted_date > '2025-03-13 16:48:02.433' OR modified_date > '2025-03-13 16:48:02.433';
