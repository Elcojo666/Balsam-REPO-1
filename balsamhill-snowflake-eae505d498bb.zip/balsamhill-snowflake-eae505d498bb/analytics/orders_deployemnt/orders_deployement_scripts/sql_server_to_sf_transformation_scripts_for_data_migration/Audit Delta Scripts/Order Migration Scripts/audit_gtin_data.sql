SELECT GTIN_KEY
      ,RESERVATION_REFERENCE
      ,SKU_ITEM_ID
      ,SHIP_NODE
      ,UPC_ITEM_ID
      ,convert(float,QUANTITY) as QUANTITY
      ,SCHEDULED_ORDER_LINE_KEY
      ,ORDER_NO
      ,ORDERLINE_RELEASE_KEY
      ,PRIME_LINE_NO
      ,SUB_LINE_NO
      ,UNIT_OF_MEASURE
      ,PRODUCT_CLASS
      ,SEGMENT_TYPE
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(left(RESERVATION_EXPIRY_TIME,14),13,0,':'),11,0,':'),9,0,' ')) as RESERVATION_EXPIRY_TIME
      ,INTERNAL_STATUS
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
	  ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,CREATEUSERID
      ,MODIFYUSERID
      ,CREATEPROGID
      ,MODIFYPROGID
      ,LOCKID
      ,inserted_date
      ,modified_date
	  ,revision
  FROM [dbo].[audit_gtin_data]
  where inserted_date > '2025-03-18 16:55:34.627';
