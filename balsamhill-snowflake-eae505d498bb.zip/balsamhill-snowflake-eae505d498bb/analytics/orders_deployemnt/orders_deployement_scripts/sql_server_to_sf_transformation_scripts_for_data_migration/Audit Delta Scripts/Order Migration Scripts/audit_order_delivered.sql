SELECT  pk_order_deliveredid
      ,external_Id
      ,SourceRefNum
      ,OrderIDForWarehouse
      ,Sku_code
      ,fk_skuproductid
      ,Upc
      ,fk_upcid
      ,fk_WarehouseID
      ,Qty
      ,DateDelivered
      ,WarehouseReferenceNumber
      ,IsResend
      ,IsReroute
      ,IsSuccessful
      ,ShippingMethodID
      ,external_orderid
      ,fk_platformID
      ,OrderType
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN ShipAddress1 IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(ShipAddress1, 1) IN ('/', '\') AND RIGHT(ShipAddress1, 1) IN ('/', '\') AND LEN(ShipAddress1) > 2) 
        THEN SUBSTRING(ShipAddress1, 2, LEN(ShipAddress1) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(ShipAddress1, 1) IN ('/', '\') AND LEN(ShipAddress1) > 1
        THEN SUBSTRING(ShipAddress1, 2, LEN(ShipAddress1) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(ShipAddress1, 1) IN ('/', '\') AND LEN(ShipAddress1) > 1
        THEN LEFT(ShipAddress1, LEN(ShipAddress1) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE ShipAddress1
		
	END AS ShipAddress1
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN ShipAddress2 IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(ShipAddress2, 1) IN ('/', '\') AND RIGHT(ShipAddress2, 1) IN ('/', '\') AND LEN(ShipAddress2) > 2) 
        THEN SUBSTRING(ShipAddress2, 2, LEN(ShipAddress2) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(ShipAddress2, 1) IN ('/', '\') AND LEN(ShipAddress2) > 1
        THEN SUBSTRING(ShipAddress2, 2, LEN(ShipAddress2) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(ShipAddress2, 1) IN ('/', '\') AND LEN(ShipAddress2) > 1
        THEN LEFT(ShipAddress2, LEN(ShipAddress2) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE ShipAddress2
		
	END AS ShipAddress2
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN ShipCity IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(ShipCity, 1) IN ('/', '\') AND RIGHT(ShipCity, 1) IN ('/', '\') AND LEN(ShipCity) > 2) 
        THEN SUBSTRING(ShipCity, 2, LEN(ShipCity) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(ShipCity, 1) IN ('/', '\') AND LEN(ShipCity) > 1
        THEN SUBSTRING(ShipCity, 2, LEN(ShipCity) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(ShipCity, 1) IN ('/', '\') AND LEN(ShipCity) > 1
        THEN LEFT(ShipCity, LEN(ShipCity) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE ShipCity
		
	END AS ShipCity
      ,ShipState
      ,ShipPostalCode
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN SHIPFIRSTNAME IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(SHIPFIRSTNAME, 1) IN ('/', '\') AND RIGHT(SHIPFIRSTNAME, 1) IN ('/', '\') AND LEN(SHIPFIRSTNAME) > 2) 
        THEN SUBSTRING(SHIPFIRSTNAME, 2, LEN(SHIPFIRSTNAME) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(SHIPFIRSTNAME, 1) IN ('/', '\') AND LEN(SHIPFIRSTNAME) > 1
        THEN SUBSTRING(SHIPFIRSTNAME, 2, LEN(SHIPFIRSTNAME) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(SHIPFIRSTNAME, 1) IN ('/', '\') AND LEN(SHIPFIRSTNAME) > 1
        THEN LEFT(SHIPFIRSTNAME, LEN(SHIPFIRSTNAME) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE SHIPFIRSTNAME
		
	END AS SHIPFIRSTNAME
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN ShipLastName IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(ShipLastName, 1) IN ('/', '\') AND RIGHT(ShipLastName, 1) IN ('/', '\') AND LEN(ShipLastName) > 2) 
        THEN SUBSTRING(ShipLastName, 2, LEN(ShipLastName) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(ShipLastName, 1) IN ('/', '\') AND LEN(ShipLastName) > 1
        THEN SUBSTRING(ShipLastName, 2, LEN(ShipLastName) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(ShipLastName, 1) IN ('/', '\') AND LEN(ShipLastName) > 1
        THEN LEFT(ShipLastName, LEN(ShipLastName) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE ShipLastName
		
	END AS ShipLastName
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN ShipCompanyName IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(ShipCompanyName, 1) IN ('/', '\') AND RIGHT(ShipCompanyName, 1) IN ('/', '\') AND LEN(ShipCompanyName) > 2) 
        THEN SUBSTRING(ShipCompanyName, 2, LEN(ShipCompanyName) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(ShipCompanyName, 1) IN ('/', '\') AND LEN(ShipCompanyName) > 1
        THEN SUBSTRING(ShipCompanyName, 2, LEN(ShipCompanyName) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(ShipCompanyName, 1) IN ('/', '\') AND LEN(ShipCompanyName) > 1
        THEN LEFT(ShipCompanyName, LEN(ShipCompanyName) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE ShipCompanyName
		
	END AS ShipCompanyName
      ,OrderDate
      ,fk_sourceid
      ,WarehouseShippingMethodID
      ,CarrierCode
      ,fk_order_headerid
      ,inserted_date
      ,modified_date
  FROM dbo.audit_order_delivered
  where inserted_date = '2023-06-14 21:38:19.000' OR modified_date = '2025-02-24 16:17:51.310';

