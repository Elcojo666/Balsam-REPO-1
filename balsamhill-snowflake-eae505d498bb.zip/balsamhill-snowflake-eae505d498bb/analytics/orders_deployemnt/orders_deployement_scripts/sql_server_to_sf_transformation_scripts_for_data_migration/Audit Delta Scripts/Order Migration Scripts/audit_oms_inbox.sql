SELECT inbox_key
      ,inbox_type
      ,description
      ,generated_on
      ,queue_key
      ,enterprise_key
      ,shipnode_key
      ,exception_type
      ,auto_resolved_flag
      ,resolution_date
      ,priority
      ,resolve_by
      ,last_unassign_alert
      ,last_unresolve_alert
      ,locked_flag
      ,locked_by_user_key
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(locked_on,13,0,':'),11,0,':'),9,0,' ')) as locked_on
      ,parent_inbox_key
      ,detail_description
      ,list_description
      ,status
      ,active_flag
      ,closed_on
      ,followup_date
      ,last_exceed_alert
      ,exception_escalated_flag
      ,owner_type
      ,owner_key
      ,assigned_to_user_key
      ,consolidation_count
      ,FORMAT(CAST(last_occurred_on AS DATETIME), 'yyyy-MM-dd HH:mm:ss')  as last_occurred_on
      ,flow_name
      ,api_name
      ,sub_flow_name
      ,view_id
      ,error_reason
      ,error_type
      ,expiration_days
      ,inbox_addnl_data
      ,resolved_by_user_id
      ,unresolve_realert_count
      ,unassign_realert_count
      ,lockid
	  ,createts
      ,modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,count_request_key
      ,count_program_name
      ,wave_key
      ,wave_no
      ,supplier_key
      ,order_header_key
      ,order_no
      ,shipment_key
      ,shipment_no
      ,load_no
      ,item_id
      ,order_line_key
      ,work_order_key
      ,work_order_no
      ,move_request_key
      ,location_id
      ,bill_to_id
      ,team_code
      ,inserted_date
      ,modified_date
	  ,revision
	  ,createts  as createts_utc
      ,modifyts as modifyts_utc
	  ,NULL as txn_id
  FROM dbo.audit_oms_inbox
  where inserted_date > '2025-03-18 16:55:06.097' OR modified_date > '2025-03-18 16:55:06.097';
