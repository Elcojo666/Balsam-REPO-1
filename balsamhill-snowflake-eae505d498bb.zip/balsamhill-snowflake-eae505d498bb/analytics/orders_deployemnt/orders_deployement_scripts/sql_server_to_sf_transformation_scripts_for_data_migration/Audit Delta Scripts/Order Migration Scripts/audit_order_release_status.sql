SELECT  order_release_status_key
      ,order_release_key
      ,order_line_key
      ,order_header_key
      ,status
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(status_date,13,0,':'),11,0,':'),9,0,' ')) as status_date
      ,convert(float,status_quantity) as status_quantity
      ,pipeline_key
      ,order_line_schedule_key
      ,convert(float,total_quantity) as total_quantity
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(expected_shipment_date,13,0,':'),11,0,':'),9,0,' ')) as expected_shipment_date
      ,chained_to_order_line_key
      ,chained_to_order_header_key
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,lockid
      ,inserted_date
      ,modified_date
	  ,revision
  FROM dbo.audit_order_release_status
  where inserted_date > '2025-03-18 18:59:00.000' OR modified_date > '2025-03-18 18:59:00.000';
