select *
from dbo.audit_order_detail_additional
where created_date > '2023-06-12 16:35:21.000' OR modified_date > '2023-06-12 16:35:21.000';
