select *
from dbo.audit_order_detail_discount
where created_date > '2025-03-18 19:53:16.090' OR modified_date > '2025-03-18 19:53:16.090'
