select 
charge_transaction_key
,charge_type
,transfer_from_oh_key
,transfer_to_oh_key
,status
,convert(float,credit_amount) as credit_amount
,convert(float,debit_amount) as debit_amount
,convert(float,book_amount) as book_amount
,convert(float,open_authorized_amount) as open_authorized_amount
,convert(float,request_amount) as request_amount
,convert(float,distributed_amount) as distributed_amount
,convert(float,settled_amount) as settled_amount
,authorization_id
,CONVERT(DATETIME,STUFF(STUFF(STUFF(authorization_expiration_date,13,0,':'),11,0,':'),9,0,' ')) as authorization_expiration_date
,order_invoice_key
,order_header_key
,payment_key
,audit_transaction_id
,user_exit_status
,CONVERT(DATETIME,STUFF(STUFF(STUFF(execution_date,13,0,':'),11,0,':'),9,0,' ')) as execution_date
,is_collection_date_firm
,CONVERT(DATETIME,STUFF(STUFF(STUFF(collection_date,13,0,':'),11,0,':'),9,0,' ')) as collection_date
,hold_against_book
,in_person
,void_transaction
,convert(float,postponed_amount) as postponed_amount
,offline_status
,call_for_auth_status
,convert(float,cash_back_amount) as cash_back_amount
,payment_entry_type
,async_request_identifier
,for_async_request_identifier
,reason_code
,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
,createuserid
,modifyuserid
,createprogid
,modifyprogid
,lockid
,null as RUNNING_ORDER_AMOUNT
,inserted_date
,modified_date
,revision
from dbo.audit_charge_transaction
where inserted_date > '2025-03-18 16:45:31.463';
