SELECT  fk_order_headerid
      ,fk_skuproductid
      ,quantity
      ,product_price
      ,total_price
      ,is_taxable
      ,options
      ,personalization_fee
      ,product_name
      ,created_by
      ,created_date
      ,modified_date
      ,pk_order_detailid
      ,Revision
      ,ext_line_id
      ,manufacture_year
      ,tree_height
      ,light_type
      ,light_color
      ,number_of_cartons
      ,number_of_sections
      ,order_header_key
      ,order_line_key
	  ,null createts
	  ,null modifyts
  FROM dbo.audit_order_detail
where created_date > '2025-03-18 18:51:39.050' OR modified_date > '2025-03-18 18:51:39.050';
