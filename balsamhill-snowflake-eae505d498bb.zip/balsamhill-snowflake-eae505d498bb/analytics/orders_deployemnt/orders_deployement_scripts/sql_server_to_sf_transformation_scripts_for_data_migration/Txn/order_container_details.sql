SELECT TOP (1000) container_details_key
      ,order_release_key
      ,order_release_status_key
      ,shipment_container_key
      ,order_line_key
      ,order_header_key
      ,shipment_key
      ,shipment_line_key
      ,country_of_origin
      ,item_id
      ,uom
      ,product_class
      ,convert(float,quantity) as quantity
      ,convert(float,quantity_placed) as quantity_placed
      ,enterprise_key
      ,orig_order_line_schedule_key
      ,fifo_no
      ,lockid
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
	  ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,extn_upc_item_id
      ,imported_date
      ,txn_id
      ,inserted_date
      ,modified_date
  FROM dbo.txn_order_container_details;
  
  SELECT TOP (1000) container_details_key
      ,order_release_key
      ,order_release_status_key
      ,shipment_container_key
      ,order_line_key
      ,order_header_key
      ,shipment_key
      ,shipment_line_key
      ,country_of_origin
      ,item_id
      ,uom
      ,product_class
      ,convert(float,quantity) as quantity
      ,convert(float,quantity_placed) as quantity_placed
      ,enterprise_key
      ,orig_order_line_schedule_key
      ,fifo_no
      ,lockid
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
	  ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,extn_upc_item_id
      ,imported_date
      ,txn_id
      ,inserted_date
      ,modified_date
	  ,revision
  FROM dbo.audit_order_container_details;

