SELECT ext_address_id
      ,person_id
      ,title
      ,suffix
      ,department
      ,job_title
      ,day_phone
      ,evening_phone
      ,mobile_phone
      ,beeper
      ,other_phone
      ,day_fax_no
      ,evening_fax_no
      ,emailid
      ,alternate_emailid
      ,preferred_ship_address
      ,http_url
      ,use_count
      ,verification_status
      ,is_address_verified
      ,CONVERT(float,latitude) AS latitude
      ,CONVERT(float,longitude) AS longitude
      ,tax_geo_code
      ,error_txt
      ,is_commercial_address
      ,time_zone
      ,lockid
	  ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
	  ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,address_id
      ,short_zip_code
      ,last_updated_date
  FROM dbo.ext_address where len(createts)=14 and  len(modifyts)=14  ;
