SELECT ext_paymentid
      ,order_header_key
      ,payment_type
      ,bill_to_key
      ,charge_sequence
      ,customer_account_no
      ,display_cust_acct_no
      ,customer_po_no
      ,credit_card_type
      ,credit_card_name
      ,first_name
      ,middle_name
      ,last_name
      ,credit_card_no
      ,display_credit_card_no
      ,credit_card_exp_date
      ,svc_no
      ,display_svc_no
      ,debit_card_no
      ,display_debit_card_no
      ,payment_reference1
      ,payment_reference2
      ,payment_reference3
      ,display_payment_ref1
      ,cheque_no
      ,cheque_reference
      ,extended_flag
      ,pay_method_override
      ,max_charge_limit
      ,convert(float,total_authorized) as total_authorized
      ,convert(float,total_charged) as total_charged
      ,convert(float,requested_auth_amount) as requested_auth_amount
      ,convert(float,requested_charge_amount) as requested_charge_amount
      ,requested_refund_amount
      ,convert(float,total_refunded_amount) as total_refunded_amount
      ,convert(float,total_alt_refunded_amount) as total_alt_refunded_amount
      ,incomplete_payment_type
      ,suspend_any_more_charges
      ,suspend_exp_auth_reversal
      ,planned_refund_amount
      ,unlimited_charges
      ,cash_back_amount
      ,payment_reference4
      ,payment_reference5
      ,payment_reference6
      ,payment_reference7
      ,payment_reference8
      ,payment_reference9
      ,reason_code
      ,createts
	  ,modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,lockid
      ,last_updated_date
  FROM dbo.ext_payment;
