SELECT notes_key
      ,table_key
      ,sequence_no
      ,table_name
      ,tranid
      ,audit_transaction_id
      ,customer_sat_indicator
      ,priority
      ,reason_code
      ,dbo.fun_to_remove_trail_lead_slashes(REPLACE(note_text, '\\', '')) as note_text
      ,contact_type
      ,contact_reference
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(contact_time,13,0,':'),11,0,':'),9,0,' ')) as contact_time
      ,contact_user
      ,lockid
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
	  ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,visible_to_all
      ,inserted_date
      ,modified_date
  FROM dbo.txn_order_notes where len(createts)=14 and  len(modifyts)=14  ;
  
 

