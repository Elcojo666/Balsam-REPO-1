SELECT  pk_order_detailid
      ,fk_order_headerid
      ,fk_skuproductid
      ,quantity
      ,product_price
      ,total_price
      ,is_taxable
      ,options
      ,personalization_fee
      ,product_name
      ,shipping_fee
      ,inserted_date
      ,modified_date
      ,manufacture_year
      ,tree_height
      ,light_type
      ,light_color
      ,number_of_cartons
      ,number_of_sections
      ,prime_line_num
      ,ext_line_id
      ,order_header_key
      ,order_line_key
	  ,NULL createts
	  ,NULL modifyts
  FROM dbo.txn_order_detail;
