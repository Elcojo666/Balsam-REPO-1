SELECT TOP (1000) pk_addressid
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN first_name IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(first_name, 1) IN ('/', '\') AND RIGHT(first_name, 1) IN ('/', '\') AND LEN(first_name) > 2) 
        THEN SUBSTRING(first_name, 2, LEN(first_name) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(first_name, 1) IN ('/', '\') AND LEN(first_name) > 1
        THEN SUBSTRING(first_name, 2, LEN(first_name) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(first_name, 1) IN ('/', '\') AND LEN(first_name) > 1
        THEN LEFT(first_name, LEN(first_name) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE first_name
		
	END AS first_name
      ,last_name
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN company_name IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(company_name, 1) IN ('/', '\') AND RIGHT(company_name, 1) IN ('/', '\') AND LEN(company_name) > 2) 
        THEN SUBSTRING(company_name, 2, LEN(company_name) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(company_name, 1) IN ('/', '\') AND LEN(company_name) > 1
        THEN SUBSTRING(company_name, 2, LEN(company_name) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(company_name, 1) IN ('/', '\') AND LEN(company_name) > 1
        THEN LEFT(company_name, LEN(company_name) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE company_name
		
	END AS company_name
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN phone_number IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(phone_number, 1) IN ('/', '\') AND RIGHT(phone_number, 1) IN ('/', '\') AND LEN(phone_number) > 2) 
        THEN SUBSTRING(phone_number, 2, LEN(phone_number) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(phone_number, 1) IN ('/', '\') AND LEN(phone_number) > 1
        THEN SUBSTRING(phone_number, 2, LEN(phone_number) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(phone_number, 1) IN ('/', '\') AND LEN(phone_number) > 1
        THEN LEFT(phone_number, LEN(phone_number) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE phone_number
		
	END AS phone_number
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN address1 IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(address1, 1) IN ('/', '\') AND RIGHT(address1, 1) IN ('/', '\') AND LEN(address1) > 2) 
        THEN SUBSTRING(address1, 2, LEN(address1) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(address1, 1) IN ('/', '\') AND LEN(address1) > 1
        THEN SUBSTRING(address1, 2, LEN(address1) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(address1, 1) IN ('/', '\') AND LEN(address1) > 1
        THEN LEFT(address1, LEN(address1) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE address1
		
	END AS address1
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN address2 IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(address2, 1) IN ('/', '\') AND RIGHT(address2, 1) IN ('/', '\') AND LEN(address2) > 2) 
        THEN SUBSTRING(address2, 2, LEN(address2) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(address2, 1) IN ('/', '\') AND LEN(address2) > 1
        THEN SUBSTRING(address2, 2, LEN(address2) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(address2, 1) IN ('/', '\') AND LEN(address2) > 1
        THEN LEFT(address2, LEN(address2) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE address2
		
	END AS address2
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN city IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(city, 1) IN ('/', '\') AND RIGHT(city, 1) IN ('/', '\') AND LEN(city) > 2) 
        THEN SUBSTRING(city, 2, LEN(city) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(city, 1) IN ('/', '\') AND LEN(city) > 1
        THEN SUBSTRING(city, 2, LEN(city) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(city, 1) IN ('/', '\') AND LEN(city) > 1
        THEN LEFT(city, LEN(city) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE city
		
	END AS city
      ,state
      ,country
      ,postal_code
      ,fk_address_typeid
      ,inserted_date
      ,modified_date
      ,ext_address_id
      ,address3
      ,address4
      ,address5
      ,address6
  FROM dbo.txn_address;
