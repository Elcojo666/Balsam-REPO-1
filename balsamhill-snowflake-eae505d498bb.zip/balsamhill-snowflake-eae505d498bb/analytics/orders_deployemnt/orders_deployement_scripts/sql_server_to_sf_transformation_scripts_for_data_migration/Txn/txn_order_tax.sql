SELECT pk_order_taxid
      ,fk_order_headerid
      ,tax_name
      ,tax_amount
      ,tax_type
      ,convert(float,tax_rate) as tax_rate
      ,inserted_date
      ,modified_date
      ,avalara_transaction_id
      ,tax_product_code
      ,tax_code
      ,oms_charge_name
      ,item_code
      ,is_avalara_flag
      ,ext_tax_id
  FROM dbo.txn_order_tax;
