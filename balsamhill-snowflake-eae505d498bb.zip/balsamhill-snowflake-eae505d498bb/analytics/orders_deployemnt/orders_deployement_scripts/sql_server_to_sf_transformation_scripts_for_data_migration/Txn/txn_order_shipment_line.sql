SELECT  shipment_line_key
      ,shipment_key
      ,shipment_line_no
      ,shipment_sub_line_no
      ,parent_shipment_line_key
      ,order_header_key
      ,order_release_key
      ,order_line_key
      ,order_no
      ,release_no
      ,prime_line_no
      ,sub_line_no
      ,item_id
      ,product_class
      ,uom
      ,convert(float,net_weight) as net_weight
      ,net_weight_uom
      ,country_of_origin
      ,fifo_no
      ,convert(float,quantity) as  quantity
      ,convert(float,over_ship_quantity) as  over_ship_quantity
      ,convert(float,original_quantity) as  original_quantity
      ,convert(float,kit_qty) as  kit_qty
      ,requested_tag_number
      ,requested_serial_no
      ,item_description
      ,segment
      ,segment_type
      ,convert(float,shortage_qty) as   shortage_qty
      ,customer_po_no
      ,customer_po_line_no
      ,mark_for_key
      ,buyer_mark_for_node_id
      ,order_type
      ,shipment_consol_group_id
      ,ship_to_customer_id
      ,kit_code
      ,is_pickable
      ,department_code
      ,gift_flag
      ,external_release_identifier
      ,is_hazmat
      ,return_shipping_label_level
      ,level_of_service
      ,pick_location
      ,pick_location_seq
      ,group_sequence_num
      ,lockid
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,wave_no
      ,convert(float,backroom_picked_qty) as  backroom_picked_qty
      ,convert(float,customer_picked_qty) as  customer_picked_qty
      ,shortage_resolution_reason
      ,cancel_reason
      ,is_pack_complete
      ,backroom_pick_complete
      ,is_customer_pick_complete
      ,staging_complete
      ,convert(float,staged_qty) as  staged_qty
      ,store_batch_key
      ,batch_pick_priority
      ,store_batch_location_key
      ,inserted_date
      ,modified_date
  FROM dbo.txn_order_shipment_line
