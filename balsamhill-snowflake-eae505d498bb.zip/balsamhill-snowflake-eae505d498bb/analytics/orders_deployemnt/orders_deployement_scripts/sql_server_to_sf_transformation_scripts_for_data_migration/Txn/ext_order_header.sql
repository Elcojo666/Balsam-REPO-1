SELECT order_header_key
      ,sourcing_classification
      ,buyer_organization_code
      ,seller_organization_code
      ,document_type
      ,bill_to_id
      ,customer_rewards_no
      ,vendor_id
      ,ship_to_id
      ,ship_node
      ,receiving_node
      ,buyer_receiving_node_id
      ,mark_for_key
      ,buyer_mark_for_node_id
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(req_delivery_date,13,0,':'),11,0,':'),9,0,' ')) as req_delivery_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(req_cancel_date,13,0,':'),11,0,':'),9,0,' ')) as req_cancel_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(req_ship_date,13,0,':'),11,0,':'),9,0,' ')) as req_ship_date
      ,default_template
      ,division
      ,draft_order_flag
      ,order_purpose
      ,return_oh_key_for_exchange
      ,exchange_type
      ,pending_transfer_in
      ,return_by_gift_recipient
      ,allocation_rule_id
      ,priority_code
      ,priority_number
      ,contact_key
      ,scac
      ,carrier_service_code
      ,custcarrier_account_no
      ,notify_after_shipment_flag
      ,created_at_node
      ,has_derived_child
      ,has_derived_parent
      ,notification_type
      ,notification_reference
      ,entry_type
      ,authorized_client
      ,entered_by
      ,personalize_code
      ,hold_flag
      ,hold_reason_code
      ,customer_po_no
      ,customer_customer_po_no
      ,order_name
      ,payment_rule_id
      ,terms_code
      ,delivery_code
      ,charge_actual_freight
      ,original_tax
      ,currency
      ,enterprise_currency
      ,reporting_conversion_rate
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(reporting_conversion_date,13,0,':'),11,0,':'),9,0,' ')) as reporting_conversion_date
      ,payment_status
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(authorization_expiration_date,13,0,':'),11,0,':'),9,0,' ')) as authorization_expiration_date
      ,search_criteria_1
      ,search_criteria_2
      ,fob
      ,other_charges
      ,price_program_key
      ,taxpayer_id
      ,tax_jurisdiction
      ,tax_exemption_certificate
      ,purpose
      ,invoice_complete
      ,order_closed
      ,next_alert_ts
      ,do_not_consolidate
      ,chain_type
      ,adjustment_invoice_pending
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(auto_cancel_date,13,0,':'),11,0,':'),9,0,' ')) as auto_cancel_date
      ,sale_voided
      ,is_ship_complete
      ,is_line_ship_complete
      ,is_ship_single_node
      ,is_line_ship_single_node
      ,cancel_order_on_excp_flag
      ,optimization_type
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(purge_history_date,13,0,':'),11,0,':'),9,0,' ')) as purge_history_date
      ,pricing_classification_code
      ,source_type
      ,source_key
      ,linked_source_key
      ,original_container_key
      ,sold_to_key
      ,team_code
      ,next_iter_seq_no
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(next_iter_date,13,0,':'),11,0,':'),9,0,' ')) as next_iter_date
      ,hrs_before_next_iter
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,lockid
      ,department_code
      ,buyer_user_id
      ,recreate_authorizations
      ,customer_contact_id
      ,opportunity_key
      ,is_expiration_date_overridden
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(expiration_date,13,0,':'),11,0,':'),9,0,' ')) as expiration_date
      ,approval_cycle
      ,in_store_payment_required
      ,immediate_settlement_value
      ,customer_age
      ,cart_id
      ,rollout_version
      ,all_addresses_verified
      ,compl_gift_box_qty
      ,no_of_auth_strikes
      ,source_ip_address
      ,customer_first_name
      ,customer_last_name
      ,customer_phone_no
      ,customer_zip_code
      ,index_version
      ,extn_customer_type
      ,extn_customer_id
      ,extn_cba_ship_label
      ,extn_amazon_tfm
      ,extn_tfm_ship_status
      ,extn_financed_by_affirm
      ,extn_risk_status
      ,extn_sales_rep_cust_id
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(extn_latest_ship_date,13,0,':'),11,0,':'),9,0,' ')) as extn_latest_ship_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(extn_latest_delivery_date,13,0,':'),11,0,':'),9,0,' ')) as extn_latest_delivery_date
      ,extn_market_place_id
      ,extn_order_status
      ,extn_is_prime
      ,extn_giftee_full_name
      ,extn_giftee_email_id
      ,extn_sms_opt_in
      ,extn_ga_tag_id
      ,extn_fraud_status
      ,extn_order_locale_code
      ,extn_shipto_firstname
      ,extn_shipto_lastname
      ,extn_shipto_zipcode
      ,extn_return_confirmed_by
      ,extn_sales_tracking_info
      ,extn_edi_gcn
      ,extn_pk_header_key
      ,extn_merchant_id
      ,extn_is_avalara
      ,inserted_date
      ,modified_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(extn_req_cancel_date,13,0,':'),11,0,':'),9,0,' ')) as extn_req_cancel_date
      ,extn_is_email_sent
      ,extn_is_txn_committed
      ,cast(extn_tax_txn_date as date) as extn_tax_txn_date
      ,extn_last_refund_txn_code
      ,extn_refund_txn_code
      ,extn_min_estimated_delivery_date
      ,extn_max_estimated_delivery_date
      ,extn_apply_migration_hold
      ,extn_signifyd_order_id
      ,extn_primary_reason
      ,extn_secondary_reason
      ,extn_sales_entry_type
      ,extn_sales_order_type
      ,extn_warranty_order_no
      ,extn_seller_payment_type
      ,last_modified_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
  FROM dbo.ext_order_header where len(authorization_expiration_date)=14  ;
