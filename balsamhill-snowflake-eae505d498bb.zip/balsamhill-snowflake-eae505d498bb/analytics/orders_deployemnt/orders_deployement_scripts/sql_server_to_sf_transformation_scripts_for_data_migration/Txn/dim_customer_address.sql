SELECT PK_CUSTOMER_ADDRESS_ID
      ,FK_CUSTOMER_INFO_ID
      ,ADDRESS_TYPE
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN ADDRESS_LINE_1 IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(ADDRESS_LINE_1, 1) IN ('/', '\') AND RIGHT(ADDRESS_LINE_1, 1) IN ('/', '\') AND LEN(ADDRESS_LINE_1) > 2) 
        THEN SUBSTRING(ADDRESS_LINE_1, 2, LEN(ADDRESS_LINE_1) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(ADDRESS_LINE_1, 1) IN ('/', '\') AND LEN(ADDRESS_LINE_1) > 1
        THEN SUBSTRING(ADDRESS_LINE_1, 2, LEN(ADDRESS_LINE_1) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(ADDRESS_LINE_1, 1) IN ('/', '\') AND LEN(ADDRESS_LINE_1) > 1
        THEN LEFT(ADDRESS_LINE_1, LEN(ADDRESS_LINE_1) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE ADDRESS_LINE_1
		
	END AS ADDRESS_LINE_1
      ,
    CASE 
        -- If the value is only / or \, replace it with a space
        WHEN ADDRESS_LINE_2 IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(ADDRESS_LINE_2, 1) IN ('/', '\') AND RIGHT(ADDRESS_LINE_2, 1) IN ('/', '\') AND LEN(ADDRESS_LINE_2) > 2) 
        THEN SUBSTRING(ADDRESS_LINE_2, 2, LEN(ADDRESS_LINE_2) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(ADDRESS_LINE_2, 1) IN ('/', '\') AND LEN(ADDRESS_LINE_2) > 1
        THEN SUBSTRING(ADDRESS_LINE_2, 2, LEN(ADDRESS_LINE_2) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(ADDRESS_LINE_2, 1) IN ('/', '\') AND LEN(ADDRESS_LINE_2) > 1
        THEN LEFT(ADDRESS_LINE_2, LEN(ADDRESS_LINE_2) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE ADDRESS_LINE_2
		
	END AS ADDRESS_LINE_2
      ,ADDRESS_LINE_3
      ,ADDRESS_LINE_4
      ,
    CASE 
        -- If the value is only / or \, replace it with a space
        WHEN city IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(city, 1) IN ('/', '\') AND RIGHT(city, 1) IN ('/', '\') AND LEN(city) > 2) 
        THEN SUBSTRING(city, 2, LEN(city) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(city, 1) IN ('/', '\') AND LEN(city) > 1
        THEN SUBSTRING(city, 2, LEN(city) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(city, 1) IN ('/', '\') AND LEN(city) > 1
        THEN LEFT(city, LEN(city) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE city
		
	END AS city
      ,STATE
      ,POSTAL_CODE
      ,COUNTRY_CODE
      ,CREATED_BY
      ,CREATED_DATE
      ,MODIFIED_BY
      ,MODIFIED_DATE
      ,latitude
      ,longitude
      ,
    CASE 
        -- If the value is only / or \, replace it with a space
        WHEN FirstName IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(FirstName, 1) IN ('/', '\') AND RIGHT(FirstName, 1) IN ('/', '\') AND LEN(FirstName) > 2) 
        THEN SUBSTRING(FirstName, 2, LEN(FirstName) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(FirstName, 1) IN ('/', '\') AND LEN(FirstName) > 1
        THEN SUBSTRING(FirstName, 2, LEN(FirstName) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(FirstName, 1) IN ('/', '\') AND LEN(FirstName) > 1
        THEN LEFT(FirstName, LEN(FirstName) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE FirstName
		
	END AS FirstName
      ,
    CASE 
        -- If the value is only / or \, replace it with a space
        WHEN LastName IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(LastName, 1) IN ('/', '\') AND RIGHT(LastName, 1) IN ('/', '\') AND LEN(LastName) > 2) 
        THEN SUBSTRING(LastName, 2, LEN(LastName) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(LastName, 1) IN ('/', '\') AND LEN(LastName) > 1
        THEN SUBSTRING(LastName, 2, LEN(LastName) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(LastName, 1) IN ('/', '\') AND LEN(LastName) > 1
        THEN LEFT(LastName, LEN(LastName) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE LastName
		
	END AS LastName
      ,is_default
  FROM dbo.dim_customer_address ;
