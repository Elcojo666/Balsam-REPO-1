SELECT top 10 PK_CUSTOMER_INFO_ID
      ,FK_CUSTOMERID
      ,STATUS
      ,PREFERRED_LANG
      ,REGD_DATE
      ,TITLE
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN first_Name IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(first_Name, 1) IN ('/', '\') AND RIGHT(first_Name, 1) IN ('/', '\') AND LEN(first_Name) > 2) 
        THEN SUBSTRING(first_Name, 2, LEN(first_Name) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(first_Name, 1) IN ('/', '\') AND LEN(first_Name) > 1
        THEN SUBSTRING(first_Name, 2, LEN(first_Name) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(first_Name, 1) IN ('/', '\') AND LEN(first_Name) > 1
        THEN LEFT(first_Name, LEN(first_Name) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE first_Name
		
	END AS first_Name
      ,
    CASE 
        -- If the value is only / or \, replace it with a space
        WHEN Last_Name IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(Last_Name, 1) IN ('/', '\') AND RIGHT(Last_Name, 1) IN ('/', '\') AND LEN(Last_Name) > 2) 
        THEN SUBSTRING(Last_Name, 2, LEN(Last_Name) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(Last_Name, 1) IN ('/', '\') AND LEN(Last_Name) > 1
        THEN SUBSTRING(Last_Name, 2, LEN(Last_Name) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(Last_Name, 1) IN ('/', '\') AND LEN(Last_Name) > 1
        THEN LEFT(Last_Name, LEN(Last_Name) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE Last_Name
		
	END AS Last_Name
      ,DOB
      ,GENDER_CODE
      ,GENDER
      ,MARITAL_STATUS_CODE
      ,MARITAL_STATUS
      ,EMAIL_PRIMARY
      ,EMAIL_SECONDARY
      ,HOME_PHONE_PRIMARY
      ,HOME_PHONE_SECONDARY
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN MOBI_PHONE_PRIMARY IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(MOBI_PHONE_PRIMARY, 1) IN ('/', '\') AND RIGHT(MOBI_PHONE_PRIMARY, 1) IN ('/', '\') AND LEN(MOBI_PHONE_PRIMARY) > 2) 
        THEN SUBSTRING(MOBI_PHONE_PRIMARY, 2, LEN(MOBI_PHONE_PRIMARY) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(MOBI_PHONE_PRIMARY, 1) IN ('/', '\') AND LEN(MOBI_PHONE_PRIMARY) > 1
        THEN SUBSTRING(MOBI_PHONE_PRIMARY, 2, LEN(MOBI_PHONE_PRIMARY) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(MOBI_PHONE_PRIMARY, 1) IN ('/', '\') AND LEN(MOBI_PHONE_PRIMARY) > 1
        THEN LEFT(MOBI_PHONE_PRIMARY, LEN(MOBI_PHONE_PRIMARY) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE MOBI_PHONE_PRIMARY
		
	END AS MOBI_PHONE_PRIMARY
      ,MOBI_PHONE_SECONDARY
      ,COMPANY_NAME
      ,CATALOG_SUBSCRIBER
      ,CUSTOMER_IS_ANONYMOUS
      ,IS_ANONYMOUS_DATE_UPDATED
      ,CUST_TYPE
      ,NEW_CUSTOMER
      ,CUST_NOTES
      ,TAX_EXEMPT_ACCOUNT
      ,ORDER_PLACED
      ,CREATED_BY
      ,CREATED_DATE
      ,MODIFIED_BY
      ,MODIFIED_DATE
      ,EXTERNAL_ID
      ,EXTERNAL_ACCOUNTID
      ,EXTERNAL_EMAIL2
      ,EXTERNAL_EMAIL1
      ,MASTERCONTACT
      ,LEGAL_NAME
      ,EMAIL_OPT_IN_STATUS
      ,FK_MASTERCUSTOMERID
      ,IS_DUPLICATE
      ,IS_ANONYMOUS_DATE_UPDATED_DWH
      ,IS_ANONYMIZED_DWH
      ,POSSIBLE_DUPLICATE
      ,DEDUP_TYPE
      ,LAST_LOGIN_DATE
      ,cust_tier
      ,tax_id
      ,email_subscriber
      ,IsNordstromCustomer
      ,IsWilliamsonomaCustomer
      ,business_cust
      ,business_category
      ,Business_#_of_Locations
      ,DesignTradeFlag
      ,social_handle_facebook
      ,social_handle_instagram
      ,social_handle_twitter
      ,home_phone_primary_sms
      ,home_phone_primary_pref
      ,home_phone_primary_region
      ,home_phone_secondary_sms
      ,home_phone_secondary_pref
      ,home_phone_secondary_region
      ,mobi_phone_primary_sms
      ,mobi_phone_primary_pref
      ,mobi_phone_primary_region
      ,mobi_phone_secondary_sms
      ,mobi_phone_secondary_pref
      ,mobi_phone_secondary_region
      ,home_phone_primary_E164
      ,home_phone_secondary_E164
      ,CASE 
        -- If the value is only / or \, replace it with a space
        WHEN MOBI_PHONE_PRIMARY_E164 IN ('/', '\') THEN ' '

        -- If both start and end have / or \, remove both
	    WHEN (LEFT(MOBI_PHONE_PRIMARY_E164, 1) IN ('/', '\') AND RIGHT(MOBI_PHONE_PRIMARY_E164, 1) IN ('/', '\') AND LEN(MOBI_PHONE_PRIMARY_E164) > 2) 
        THEN SUBSTRING(MOBI_PHONE_PRIMARY_E164, 2, LEN(MOBI_PHONE_PRIMARY_E164) - 2)
        
        -- If only the starting character is / or \, remove it
        WHEN LEFT(MOBI_PHONE_PRIMARY_E164, 1) IN ('/', '\') AND LEN(MOBI_PHONE_PRIMARY_E164) > 1
        THEN SUBSTRING(MOBI_PHONE_PRIMARY_E164, 2, LEN(MOBI_PHONE_PRIMARY_E164) - 1)
        
        -- If only the trailing character is / or \, remove it
        WHEN RIGHT(MOBI_PHONE_PRIMARY_E164, 1) IN ('/', '\') AND LEN(MOBI_PHONE_PRIMARY_E164) > 1
        THEN LEFT(MOBI_PHONE_PRIMARY_E164, LEN(MOBI_PHONE_PRIMARY_E164) - 1)
        
        -- Otherwise, leave the value unchanged
        ELSE MOBI_PHONE_PRIMARY_E164
		
	END AS MOBI_PHONE_PRIMARY_E164
      ,mobi_phone_secondary_E164
      ,domestic_US_Canada_YN
      ,exclude_home_primary_cleanup_yn
      ,category_home_primary
      ,exclude_home_sec_cleanup_yn
      ,category_home_sec
      ,exclude_mobi_primary_cleanup_yn
      ,category_mobi_primary
      ,exclude_mobi_sec_cleanup_yn
      ,category_mobi_sec
      ,Partner
      ,phone1_input
      ,phone1_E164
      ,phone1_sms
      ,phone1_pref
      ,phone1_region
      ,phone2_input
      ,phone2_E164
      ,phone2_sms
      ,phone2_pref
      ,phone2_region
      ,phone3_input
      ,phone3_E164
      ,phone3_sms
      ,phone3_pref
      ,phone3_region
      ,phone4_input
      ,phone4_E164
      ,phone4_sms
      ,phone4_pref
      ,phone4_region
      ,HashedId
  FROM dbo.dim_customer_info;
