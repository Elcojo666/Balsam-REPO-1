SELECT TOP (1000) order_release_key
      ,order_header_key
      ,work_order_key
      ,work_order_appt_key
      ,release_no
      ,merge_node
      ,ship_to_key
      ,shipnode_key
      ,enterprise_key
      ,buyer_organization_code
      ,seller_organization_code
      ,document_type
      ,bill_to_id
      ,ship_to_id
      ,pick_list_no
      ,scac
      ,carrier_service_code
      ,custcarrier_account_no
      ,delivery_code
      ,ship_advice_no
      ,shipment_consol_group_id
      ,packlist_type
      ,sales_order_no
      ,order_name
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(order_date,13,0,':'),11,0,':'),9,0,' ')) as  order_date
      ,order_type
      ,customer_po_no
      ,mark_for_key
      ,buyer_mark_for_node_id
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(cust_req_delivery_date,13,0,':'),11,0,':'),9,0,' ')) as cust_req_delivery_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(cust_req_ship_date,13,0,':'),11,0,':'),9,0,' ')) as cust_req_ship_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(req_delivery_date,13,0,':'),11,0,':'),9,0,' ')) as req_delivery_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(orderreq_cancel_date_date,13,0,':'),11,0,':'),9,0,' ')) as req_cancel_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(req_ship_date,13,0,':'),11,0,':'),9,0,' ')) as req_ship_date
      ,priority_code
      ,personalize_code
      ,currency
      ,hold_flag
      ,hold_reason_code
      ,fob
      ,aor_flag
      ,division
      ,notify_after_shipment_flag
      ,notification_type
      ,notification_reference
      ,ship_complete_flag
      ,ship_node_class
      ,supplier_code
      ,supplier_name
      ,release_seq_no
      ,ship_order_complete
      ,ship_line_complete
      ,taxpayer_id
      ,purpose
      ,gift_flag
      ,convert(float,other_charges) as other_charges
      ,receiving_node
      ,buyer_receiving_node_id
      ,delivery_method
      ,pack_and_hold
      ,department_code
      ,item_classification
      ,level_of_service
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,lockid
      ,inserted_date
      ,modified_date
  FROM dbo.txn_order_release
