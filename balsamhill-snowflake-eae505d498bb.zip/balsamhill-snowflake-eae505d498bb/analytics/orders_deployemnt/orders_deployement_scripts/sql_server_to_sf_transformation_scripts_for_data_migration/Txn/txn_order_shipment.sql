SELECT  shipment_key
      ,pick_list_no
      ,original_shipment_key
      ,merge_node
      ,pickticket_no
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(ship_date,13,0,':'),11,0,':'),9,0,' ')) AS ship_date
      ,convert(float,unplaced_quantity) as unplaced_quantity
      ,shipnode_key
      ,receiving_node
      ,buyer_receiving_node_id
      ,shipment_consol_group_id
      ,ship_mode
      ,from_address_key
      ,to_address_key
      ,bill_to_address_key
      ,ship_to_customer_id
      ,bill_to_customer_id
      ,has_other_shipments
      ,parent_shipment_key
      ,ship_via
      ,seal_no
      ,tracking_no
      ,trailer_no
      ,manifest_no
      ,pro_no
      ,scac
      ,convert(float,actual_freight_charge) as actual_freight_charge
      ,carrier_service_code
      ,requested_carrier_service_code
      ,status
      ,pod_no
      ,bol_no
      ,convert(float,total_weight) as total_weight
      ,total_weight_uom
      ,convert(float,total_volume) as total_volume
      ,total_volume_uom
      ,convert(float,total_quantity) as total_quantity
      ,convert(float,containerized_quantity) as containerized_quantity
      ,convert(float,placed_quantity) as placed_quantity
      ,is_product_placing_complete
      ,is_pack_process_complete
      ,is_revised
      ,hold_flag
      ,it_no
       ,CONVERT(DATETIME,STUFF(STUFF(STUFF(it_date,13,0,':'),11,0,':'),9,0,' ')) AS  it_date
      ,appointment_no
      ,from_appointment
      ,to_appointment
       ,CONVERT(DATETIME,STUFF(STUFF(STUFF(delivery_ts,13,0,':'),11,0,':'),9,0,' ')) AS  delivery_ts
      ,code
      ,convert(float,num_of_pallets) as num_of_pallets
      ,convert(float,num_of_cartons) as num_of_cartons
      ,export_taxpayer_id
      ,freight_terms
      ,delivery_code
      ,carrier_type
      ,download_count
      ,currency
      ,delivery_plan_key
      ,shipment_no
      ,pipeline_key
      ,gift_flag
      ,shipment_planned_flag
      ,shipment_closed_flag
      ,seller_organization_code
      ,buyer_organization_code
      ,enterprise_code
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(requested_shipment_date,13,0,':'),11,0,':'),9,0,' ')) AS requested_shipment_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(expected_shipment_date,13,0,':'),11,0,':'),9,0,' ')) AS expected_shipment_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(actual_shipment_date,13,0,':'),11,0,':'),9,0,' ')) AS actual_shipment_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(requested_delivery_date,13,0,':'),11,0,':'),9,0,' ')) AS requested_delivery_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(expected_delivery_date,13,0,':'),11,0,':'),9,0,' ')) AS expected_delivery_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(actual_delivery_date,13,0,':'),11,0,':'),9,0,' ')) AS actual_delivery_date
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(return_by_date,13,0,':'),11,0,':'),9,0,' ')) AS return_by_date
      ,return_authorization_number
      ,document_type
      ,origin_zone
      ,destination_zone
       ,CONVERT(DATETIME,STUFF(STUFF(STUFF(status_date,13,0,':'),11,0,':'),9,0,' ')) AS status_date
      ,shipment_type
      ,commercial_value
      ,hazardous_material_flag
      ,convert(float,total_estimated_charge) as total_estimated_charge
      ,convert(float,total_actual_charge) as total_actual_charge
       ,CONVERT(DATETIME,STUFF(STUFF(STUFF(next_alert_ts,13,0,':'),11,0,':'),9,0,' ')) AS next_alert_ts
      ,shipment_confirm_updates_done
      ,shipment_deliver_updates_done
      ,shipment_containerized_flag
      ,scac_integration_required
      ,packlist_type
      ,custcarrier_account_no
      ,manifest_key
      ,is_single_order
      ,lines_entered
      ,order_available_on_system
      ,override_manual_shipment_entry
      ,do_not_verify_pallet_content
      ,do_not_verify_case_content
      ,allow_overage
      ,manually_entered
      ,allow_new_item_receipt
      ,order_no
      ,order_header_key
      ,release_no
      ,order_release_key
      ,export_license_no
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(export_license_exp_date,13,0,':'),11,0,':'),9,0,' ')) AS export_license_exp_date
      ,delivery_method
      ,requires_appt_confirmation
      ,work_order_key
      ,work_order_appt_key
      ,order_type
      ,do_not_consolidate
      ,department_code
      ,item_classification
      ,mark_for_key
      ,buyer_mark_for_node_id
      ,routing_contact_info
      ,customer_po_no
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(carrier_pickup_time,13,0,':'),11,0,':'),9,0,' ')) AS  carrier_pickup_time
      ,pack_and_hold
      ,esp_check_required
      ,is_appointment_reqd
      ,routing_source
      ,routing_error_code
      ,routing_guide_maintained
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(must_ship_before_date,13,0,':'),11,0,':'),9,0,' ')) AS  must_ship_before_date
      ,priority_code
      ,convert(float,estimated_price) as estimated_price
      ,has_node_exceptions
      ,cod_pay_method
      ,airway_bill_no
      ,invoice_complete
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(expected_pick_date,13,0,':'),11,0,':'),9,0,' ')) AS   expected_pick_date
      ,return_carrier_service
      ,return_freight_terms
      ,return_billing_account
      ,break_bulk_node
      ,convert(float,bbn_min_weight) as  bbn_min_weight
      ,convert(float,bbn_min_volume) as  bbn_min_volume
      ,fedx_open_ship_index
      ,itn_no
      ,email_return_label
      ,profile_id
      ,profileid_provided_by_sterling
      ,level_of_service
      ,hold_location
      ,assigned_to_user_id
      ,lockid
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) AS  createts
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) AS  modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,shipment_sort_location_id
      ,carrier_sort_location_id
      ,shipment_group_id
      ,notification_sent
      ,pickticket_printed
      ,backroom_pick_required
      ,included_in_batch
      ,is_receiving_complete
      ,received_damaged
      ,index_version
      ,extn_narvar_url
      ,extn_is_sent
      ,extn_is_email_sent
      ,inserted_date
      ,modified_date
  FROM dbo.txn_order_shipment;
