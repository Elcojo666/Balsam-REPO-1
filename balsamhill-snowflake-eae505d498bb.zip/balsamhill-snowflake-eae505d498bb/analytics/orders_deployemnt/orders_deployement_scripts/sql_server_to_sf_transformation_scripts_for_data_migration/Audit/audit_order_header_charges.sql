SELECT  header_charges_key
      ,header_key
      ,record_type
      ,charge_category
      ,charge_name
      ,reference
      ,convert(float,charge) as charge
      ,convert(float,invoiced_charge) as invoiced_charge
      ,convert(float,original_charge) as original_charge
      ,is_manual
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
	  ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,lockid
      ,extn_charge_description
      ,extn_coupon_code
      ,inserted_date
      ,modified_date
	  ,revision
  FROM dbo.audit_order_header_charges;
