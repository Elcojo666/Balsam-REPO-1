SELECT pk_oms_tax_breakupid
      ,tax_breakup_key
      ,header_key
      ,line_key
      ,record_type
      ,charge_category
      ,charge_name
      ,tax_name
      ,taxable_flag
      ,convert(float,tax_percentage) as tax_percentage
      ,convert(float,tax) as tax
      ,convert(float,invoiced_tax) as invoiced_tax
      ,reference1
      ,reference2
      ,reference3
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
	  ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,lockid
      ,inserted_date
      ,modified_date,revision
  FROM dbo.audit_order_tax_breakup;