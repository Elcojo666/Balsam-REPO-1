SELECT  line_charges_key
      ,header_key
      ,line_key
      ,record_type
      ,charge_category
      ,charge_name
      ,reference
      ,convert(float,chargeperunit) as chargeperunit
      ,convert(float,chargeperline) as chargeperline
      ,convert(float,chargeamount) as chargeamount
      ,convert(float,invoiced_charge_per_line) as invoiced_charge_per_line
      ,convert(float,invoiced_extended_charge) as invoiced_extended_charge
      ,convert(float,original_chargeperunit) as original_chargeperunit
      ,convert(float,original_chargeperline) as original_chargeperline
      ,is_manual
      ,CONVERT(DATETIME,STUFF(STUFF(STUFF(createts,13,0,':'),11,0,':'),9,0,' ')) as createts
	  ,CONVERT(DATETIME,STUFF(STUFF(STUFF(modifyts,13,0,':'),11,0,':'),9,0,' ')) as modifyts
      ,createuserid
      ,modifyuserid
      ,createprogid
      ,modifyprogid
      ,lockid
      ,extn_charge_description
      ,extn_coupon_code
      ,inserted_date
      ,modified_date
	  ,revision
  FROM dbo.audit_order_line_charges
