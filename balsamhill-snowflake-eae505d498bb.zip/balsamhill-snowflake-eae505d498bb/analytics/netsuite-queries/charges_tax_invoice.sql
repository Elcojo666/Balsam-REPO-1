
--1. Order Line Charges

select top 100 * from raw_oms_order_line_charges 

select count(*) from raw_oms_order_line_charges	--4197
select count(*) from arc_raw_oms_order_line_charges --1627295

select top 100 * from txn_order_line_charges


select [line_charges_key]
      ,[header_key]
      ,[line_key]
      ,[record_type]
      ,[charge_category]
      ,[charge_name]
      ,[reference]
      ,[chargeperunit]
      ,[chargeperline]
      ,[chargeamount]
      ,[invoiced_charge_per_line]
      ,[invoiced_extended_charge]
      ,[original_chargeperunit]
      ,[original_chargeperline]
      ,[is_manual]
      ,[createts]
      ,[modifyts]
      ,[createuserid ]
      ,[modifyuserid]
      ,[createprogid]
      ,[modifyprogid]
      ,[lockid]
      ,[extn_charge_description]
      ,[extn_coupon_code] from raw_oms_order_line_charges
where processing_status = 'Failed' AND 
header_key in(
	select distinct order_header_key from netsuite_order_extract
)
UNION ALL
select [line_charges_key]
      ,[header_key]
      ,[line_key]
      ,[record_type]
      ,[charge_category]
      ,[charge_name]
      ,[reference]
      ,[chargeperunit]
      ,[chargeperline]
      ,[chargeamount]
      ,[invoiced_charge_per_line]
      ,[invoiced_extended_charge]
      ,[original_chargeperunit]
      ,[original_chargeperline]
      ,[is_manual]
      ,[createts]
      ,[modifyts]
      ,[createuserid]
      ,[modifyuserid]
      ,[createprogid]
      ,[modifyprogid]
      ,[lockid]
      ,[extn_charge_description]
      ,[extn_coupon_code]
	   from txn_order_line_charges
where header_key in(
	select distinct order_header_key from netsuite_order_extract
)		--16,914

--16,960

--2. Order Header Charges

select top 100 * from raw_oms_order_header_charges 

select count(*) from raw_oms_order_header_charges --2196
select  count(*) from arc_raw_oms_order_header_charges --1280527

select [header_charges_key]
      ,[header_key]
      ,[record_type]
      ,[charge_category]
      ,[charge_name]
      ,[reference]
      ,[charge]
      ,[invoiced_charge]
      ,[original_charge]
      ,[is_manual]
      ,[createts]
      ,[modifyts]
      ,[createuserid]
      ,[modifyuserid]
      ,[createprogid]
      ,[modifyprogid]
      ,[lockid]
      ,[extn_charge_description]
      ,[extn_coupon_code]
	  from raw_oms_order_header_charges
where processing_status = 'Failed' AND 
header_key in(
	select distinct order_header_key from netsuite_order_extract
)
UNION ALL
select [header_charges_key]
      ,[header_key]
      ,[record_type]
      ,[charge_category]
      ,[charge_name]
      ,[reference]
      ,[charge]
      ,[invoiced_charge]
      ,[original_charge]
      ,[is_manual]
      ,[createts]
      ,[modifyts]
      ,[createuserid]
      ,[modifyuserid]
      ,[createprogid]
      ,[modifyprogid]
      ,[lockid]
      ,[extn_charge_description]
      ,[extn_coupon_code]
	  from txn_order_header_charges
where header_key in(
	select distinct order_header_key from netsuite_order_extract
)		--19,980


--3. Order Tax Breakup

select top 100 * from raw_oms_order_tax_breakup

select count(*) from raw_oms_order_tax_breakup --12657
select  count(*) from arc_raw_oms_order_tax_breakup --8340883

select [tax_breakup_key]
      ,[header_key]
      ,[line_key]
      ,[record_type]
      ,[charge_category]
      ,[charge_name]
      ,[tax_name]
      ,[taxable_flag]
      ,[tax_percentage]
      ,[tax]
      ,[invoiced_tax]
      ,[reference1]
      ,[reference2]
      ,[reference3]
      ,[createts]
      ,[modifyts]
      ,[createuserid]
      ,[modifyuserid]
      ,[createprogid]
      ,[modifyprogid]
      ,[lockid]
	  from raw_oms_order_tax_breakup
where  processing_status = 'Failed' AND 
header_key in(
	select distinct order_header_key from netsuite_order_extract
)	
UNION ALL
select [tax_breakup_key]
      ,[header_key]
      ,[line_key]
      ,[record_type]
      ,[charge_category]
      ,[charge_name]
      ,[tax_name]
      ,[taxable_flag]
      ,[tax_percentage]
      ,[tax]
      ,[invoiced_tax]
      ,[reference1]
      ,[reference2]
      ,[reference3]
      ,[createts]
      ,[modifyts]
      ,[createuserid]
      ,[modifyuserid]
      ,[createprogid]
      ,[modifyprogid]
      ,[lockid]
	  from txn_order_tax_breakup
where header_key in(
	select distinct order_header_key from netsuite_order_extract
)		--70,965

--4. Order Invoices

select top 100 * from raw_oms_order_invoice

select count(*) from raw_oms_order_invoice --2208129

select order_header_key, count(*) from raw_oms_order_invoice
where order_header_key in(
	select distinct order_header_key from netsuite_order_extract
)
group by order_header_key
order by count(*) desc

select *
from raw_oms_order_invoice
where order_header_key in(
	select distinct order_header_key from netsuite_order_extract
)	--38,103

select distinct order_invoice_key
from raw_oms_order_invoice
where order_header_key in(
	select distinct order_header_key from netsuite_order_extract
)	--36,988

select order_header_key, max(imported_date)
from raw_oms_order_invoice
where order_header_key in(
	select distinct order_header_key from netsuite_order_extract
)	
group by order_header_key		--24,346

select order_header_key, shipment_key, max(imported_date)
from raw_oms_order_invoice
where shipment_key is not null and order_header_key in(
	select distinct order_header_key from netsuite_order_extract
)	
group by order_header_key, shipment_key




select [order_invoice_key]
      ,[order_header_key]
      ,[return_release_key]
      ,[shipment_key]
      ,[charge_transaction_key]
      ,[master_invoice_no]
      ,[invoice_no]
      ,[invoice_type]
      ,[currency]
      ,[charged_actual_freight]
      ,[tax]
      ,[actual_freight_charge]
      ,[total_tax]
      ,[line_subtotal]
      ,[status]
      ,[total_amount]
      ,[amount_collected]
      ,[collected_externally]
      ,[amount_passed_to_ar]
      ,[other_charges]
      ,[derived_from_order_header_key]
      ,[reference_1]
      ,[invoice_creation_reason]
      ,[document_type]
      ,[enterprise_code]
      ,[order_no]
      ,[shipnode_key]
      ,[shipment_no]
      ,[seller_organization_code]
      ,[rollout_version]
      ,[createts]
      ,[modifyts]
      ,[createuserid]
      ,[modifyuserid]
      ,[createprogid]
      ,[modifyprogid]
      ,[lockid]
from raw_oms_order_invoice
where order_header_key in(
	select distinct order_header_key from netsuite_order_extract
)	