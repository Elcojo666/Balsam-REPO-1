
select * from dim_order_status

select count(*) from ext_order_header
where ORDER_CLOSED = 'Y'				--773618

select top 25000 * into #netsuit_extract_order from ext_order_header
where ORDER_CLOSED = 'Y'
order by last_modified_date desc

select  * from ext_order_detail
where order_header_key in(
	select order_header_key from #netsuit_extract_order
)

select distinct extn_customer_id from #netsuit_extract_order

select * from dim_customer
where source_ref_num in(
	select distinct extn_customer_id from #netsuit_extract_order
)

select top 100 * from dim_customer_info



--------------------------------------------------------------------------------------------------------------------------------------------

--order header extract

SELECT top 25000 [order_header_key]
      ,[sourcing_classification]
      ,[buyer_organization_code]
      ,[seller_organization_code]
      ,[document_type]
      ,[bill_to_id]
      ,[customer_rewards_no]
      ,[vendor_id]
      ,[ship_to_id]
      ,[ship_node]
      ,[receiving_node]
      ,[buyer_receiving_node_id]
      ,[mark_for_key]
      ,[buyer_mark_for_node_id]
      ,[req_delivery_date]
      ,[req_cancel_date]
      ,[req_ship_date]
      ,[default_template]
      ,[division]
      ,[draft_order_flag]
      ,[order_purpose]
      ,[return_oh_key_for_exchange]
      ,[exchange_type]
      ,[pending_transfer_in]
      ,[return_by_gift_recipient]
      ,[allocation_rule_id]
      ,[priority_code]
      ,[priority_number]
      ,[contact_key]
      ,[scac]
      ,[carrier_service_code]
      ,[custcarrier_account_no]
      ,[notify_after_shipment_flag]
      ,[created_at_node]
      ,[has_derived_child]
      ,[has_derived_parent]
      ,[notification_type]
      ,[notification_reference]
      ,[entry_type]
      ,[authorized_client]
      ,[entered_by]
      ,[personalize_code]
      ,[hold_flag]
      ,[hold_reason_code]
      ,[customer_po_no]
      ,[customer_customer_po_no]
      ,[order_name]
      ,[payment_rule_id]
      ,[terms_code]
      ,[delivery_code]
      ,[charge_actual_freight]
      ,[original_tax]
      ,[currency]
      ,[enterprise_currency]
      ,[reporting_conversion_rate]
      ,[reporting_conversion_date]
      ,[payment_status]
      ,[authorization_expiration_date]
      ,[search_criteria_1]
      ,[search_criteria_2]
      ,[fob]
      ,[other_charges]
      ,[price_program_key]
      ,[taxpayer_id]
      ,[tax_jurisdiction]
      ,[tax_exemption_certificate]
      ,[purpose]
      ,[invoice_complete]
      ,[order_closed]
      ,[next_alert_ts]
      ,[do_not_consolidate]
      ,[chain_type]
      ,[adjustment_invoice_pending]
      ,[auto_cancel_date]
      ,[sale_voided]
      ,[is_ship_complete]
      ,[is_line_ship_complete]
      ,[is_ship_single_node]
      ,[is_line_ship_single_node]
      ,[cancel_order_on_excp_flag]
      ,[optimization_type]
      ,[purge_history_date]
      ,[pricing_classification_code]
      ,[source_type]
      ,[source_key]
      ,[linked_source_key]
      ,[original_container_key]
      ,[sold_to_key]
      ,[team_code]
      ,[next_iter_seq_no]
      ,[next_iter_date]
      ,[hrs_before_next_iter]
      ,[createuserid]
      ,[modifyuserid]
      ,[createprogid]
      ,[modifyprogid]
      ,[lockid]
      ,[department_code]
      ,[buyer_user_id]
      ,[recreate_authorizations]
      ,[customer_contact_id]
      ,[opportunity_key]
      ,[is_expiration_date_overridden]
      ,[expiration_date]
      ,[approval_cycle]
      ,[in_store_payment_required]
      ,[immediate_settlement_value]
      ,[customer_age]
      ,[cart_id]
      ,[rollout_version]
      ,[all_addresses_verified]
      ,[compl_gift_box_qty]
      ,[no_of_auth_strikes]
      ,[source_ip_address]
      ,[customer_first_name]
      ,[customer_last_name]
      ,[customer_phone_no]
      ,[customer_zip_code]
      ,[index_version]
      ,[extn_customer_type]
      ,[extn_customer_id]
      ,[extn_cba_ship_label]
      ,[extn_amazon_tfm]
      ,[extn_tfm_ship_status]
      ,[extn_financed_by_affirm]
      ,[extn_risk_status]
      ,[extn_sales_rep_cust_id]
      ,[extn_latest_ship_date]
      ,[extn_latest_delivery_date]
      ,[extn_market_place_id]
      ,[extn_order_status]
      ,[extn_is_prime]
      ,[extn_giftee_full_name]
      ,[extn_giftee_email_id]
      ,[extn_sms_opt_in]
      ,[extn_ga_tag_id]
      ,[extn_fraud_status]
      ,[extn_order_locale_code]
      ,[extn_shipto_firstname]
      ,[extn_shipto_lastname]
      ,[extn_shipto_zipcode]
      ,[extn_return_confirmed_by]
      ,[extn_sales_tracking_info]
      ,[extn_edi_gcn]
      ,[extn_pk_header_key]
      ,[extn_merchant_id]
      ,[extn_is_avalara]
      ,[extn_req_cancel_date]
      ,[extn_is_email_sent]
      ,[extn_is_txn_committed]
      ,[extn_tax_txn_date]
      ,[extn_last_refund_txn_code]
      ,[extn_refund_txn_code]
      ,[extn_min_estimated_delivery_date]
      ,[extn_max_estimated_delivery_date]
      ,[extn_apply_migration_hold]
      ,[extn_signifyd_order_id]
      ,[extn_primary_reason]
      ,[extn_secondary_reason]
      ,[extn_sales_entry_type]
      ,[extn_sales_order_type]
      ,[extn_warranty_order_no]
      ,[extn_seller_payment_type]
      ,[createts]
      ,[modifyts]
	INTO #netsuit_extract_order
  FROM [dbo].[ext_order_header]
  where ORDER_CLOSED = 'Y'
order by last_modified_date desc

select * from #netsuit_extract_order

--drop table #netsuit_extract_order

--order detail extract

select  * from ext_order_detail
where order_header_key in(
	select order_header_key from #netsuit_extract_order
)

--customer extract

select * from dim_customer_type

select top 100 * from dim_customer

select top 100 * from dim_customer_address
order by created_date desc

select top 100 * from dim_customer_info
order by created_date desc

SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'dim_customer_address';

select distinct
	dc.source_ref_num
	,ds.Brandcode
	,ds.platformname
	,dct.customer_type
	,dci.STATUS
	,dci.PREFERRED_LANG
	,dci.REGD_DATE
	,dci.TITLE
	,dci.FIRST_NAME
	,dci.LAST_NAME
	,dci.DOB
	,dci.GENDER_CODE
	,dci.GENDER
	,dci.MARITAL_STATUS_CODE
	,dci.MARITAL_STATUS
	,dci.EMAIL_PRIMARY
	,dci.EMAIL_SECONDARY
	,dci.HOME_PHONE_PRIMARY
	,dci.HOME_PHONE_SECONDARY
	,dci.MOBI_PHONE_PRIMARY
	,dci.MOBI_PHONE_SECONDARY
	,dci.COMPANY_NAME
	,dci.CUST_NOTES
	,dci.LAST_LOGIN_DATE
	,dci.cust_tier
	,dci.email_subscriber
	,dci.business_cust
	,dci.business_category
	,dci.Business_#_of_Locations
	,dca.ADDRESS_TYPE
	,dca.ADDRESS_LINE_1
	,dca.ADDRESS_LINE_2
	,dca.ADDRESS_LINE_3
	,dca.ADDRESS_LINE_4
	,dca.CITY
	,dca.STATE
	,dca.POSTAL_CODE
	,dca.COUNTRY_CODE
	,dca.CREATED_BY
	,dca.CREATED_DATE
	,dca.MODIFIED_BY
	,dca.MODIFIED_DATE
	,dca.latitude
	,dca.longitude
from dim_customer dc
	inner join sourcemap ds ON ds.pk_sourceid = dc.fk_sourceid 
	inner join dim_customer_type dct ON dct.pk_customer_typeid = dc.fk_customer_typeid
	inner join dim_customer_info dci on dci.fk_customerid = dc.pk_customerid
	inner join dim_customer_address dca on dca.fk_customer_info_id = dci.PK_CUSTOMER_INFO_ID
where source_ref_num in(
	select distinct extn_customer_id from #netsuit_extract_order
)

