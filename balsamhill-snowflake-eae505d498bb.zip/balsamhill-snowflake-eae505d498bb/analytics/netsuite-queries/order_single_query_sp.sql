select DISTINCT TOH.pk_order_headerid,  
    TOH.source_ref_num,
    DCC.currency_code AS ORDER_HEADER_CURRENCY,
    TOH.order_date,
    'UTC' as TIME_ZONE,
    OH.entry_type,
    DPM.payment_method_name
    ,TAB.first_name as bill_first_name
    ,TAB.last_name as bill_last_name
    ,TAB.phone_number as bill_phone_number
    ,TAB.address1 as bill_address1
    ,TAB.address2 as bill_address2
    ,TAB.city as bill_city
    ,TAB.state as bill_state
    ,TAB.country as bill_country
    ,TAB.postal_code as bill_postal_code
    ,TAB.address3 as bill_address3
    ,TAS.first_name as ship_first_name
    ,TAS.last_name as ship_last_name
    ,TAS.phone_number as ship_phone_number
    ,TAS.address1 as ship_address1
    ,TAS.address2 as ship_address2
    ,TAS.city as ship_city
    ,TAS.state as ship_state
    ,TAS.country as ship_country
    ,TAS.postal_code as ship_postal_code
    ,TAS.address3 as ship_address3
    ,OH.seller_organization_code  AS ORDER_HEADER_seller_organization_code
    ,OD.prime_line_no
    ,OD.invoiced_quantity
    ,OD.unit_price
    ,OD.retail_price
    ,OD.tax_product_code
    ,LC.charge_category AS LINE_CHARGES_charge_category
    ,LC.charge_name AS LINE_CHARGES_charge_name
    ,LC.extn_coupon_code  AS LINE_CHARGES_extn_coupon_code
    ,OD.shipped_quantity
    ,OH.extn_sms_opt_in
    ,CASE
        WHEN OH.seller_organization_code IN ('BH_US', 'BH_CA') THEN
            TO_CHAR(TO_DATE(OH.EXTN_MIN_ESTIMATED_DELIVERY_DATE, 'MM/DD/YYYY'), 'MM/DD/YYYY')
        ELSE
            TO_CHAR(TO_DATE(OH.EXTN_MIN_ESTIMATED_DELIVERY_DATE, 'DD/MM/YYYY'), 'MM/DD/YYYY')
    END AS EXTN_MIN_ESTIMATED_DELIVERY_DATE
    ,CASE
        WHEN OH.seller_organization_code IN ('BH_US', 'BH_CA') THEN
            TO_CHAR(TO_DATE(OH.EXTN_MAX_ESTIMATED_DELIVERY_DATE, 'MM/DD/YYYY'), 'MM/DD/YYYY')
        ELSE
            TO_CHAR(TO_DATE(OH.EXTN_MAX_ESTIMATED_DELIVERY_DATE, 'DD/MM/YYYY'), 'MM/DD/YYYY')
    END AS EXTN_MAX_ESTIMATED_DELIVERY_DATE
    ,OH.extn_giftee_email_id
    ,OH.extn_giftee_full_name
    ,TP.authorization_code
    ,OD.line_type
    ,TOD.ORDER_LINE_KEY
    ,TOH.ORDER_HEADER_KEY
    ,TOD.PK_ORDER_DETAILID
    ,TOI.LINE_SUBTOTAL
    ,LC.chargeperline
    ,LC.invoiced_charge_per_line
    ,LC.reference AS LINE_CHARGES_reference
    ,LC.chargeamount as LINE_CHARGES_chargeamount
    ,HC.EXTN_CHARGE_DESCRIPTION as HEADER_CHARGES_EXTN_CHARGE_DESCRIPTION
    ,HC.reference AS HEADER_CHARGES_reference
    ,HC.charge as HEADER_CHARGES_CHARGE
    ,HC.INVOICED_CHARGE as HEADER_CHARGES_INVOICED_CHARGE
    ,HC.original_charge as HEADER_CHARGES_original_charge
    ,HC.charge_category AS HEADER_CHARGES_charge_category
    ,HC.charge_name AS HEADER_CHARGES_charge_name
    ,HC.extn_coupon_code  AS HEADER_CHARGES_extn_coupon_code
    ,OD.line_total 
    ,OH.scac AS ORDER_HEADER_scac
    ,OD.scac AS ORDER_DETAIL_scac
    ,OH.carrier_service_code AS ORDER_HEADER_carrier_service_code
    ,OD.carrier_service_code AS ORDER_DETAIL_carrier_service_code
    ,OD.level_of_service
    ,TBH.tax_name HEADER_tax_name
    ,OH.original_tax
    ,OD.tax  AS ORDER_DETAIL_tax
    ,TBH.record_type AS HEADER_TAX_BREAKUP_record_type
    ,TBH.charge_category AS HEADER_TAX_BREAKUP_charge_category
    ,TBH.charge_name AS HEADER_TAX_BREAKUP_charge_name
    ,TBL.tax_name AS LINE_TAX_BREAKUP_tax_name
    ,TBL.record_type AS LINE_TAX_BREAKUP_record_type
    ,TBL.charge_category AS LINE_TAX_BREAKUP_charge_category
    ,TBL.charge_name AS LINE_TAX_BREAKUP_charge_name
    ,TOI.TAX  AS INVOICE_TAX
    ,TOI.TOTAL_TAX
    ,TOI.OTHER_CHARGES AS TAX_BREAKUP_OTHER_CHARGES
    ,TOH.tax_amount AS ORDER_HEADER_tax_amount
    ,DS.Brandcode
    ,LC.line_charges_key
    ,CAST(TOS.shipnode_key AS NUMBER(38,0)) AS ship_node
    ,DCI.first_name as CUSTOMER_FIRSTNAME
    ,DCI.last_name as CUSTOMER_LASTNAME
    ,DCI.mobi_phone_primary as CUSTOMER_PHONENUMBER
    ,DC.source_ref_num AS CUSTOMER_SOURCE_REF_NO
    ,OH.customer_po_no AS ORDER_HEADER_customer_po_no
    ,COALESCE(TOSLC.QUANTITY, TOSLP.QUANTITY) AS SHIPMENT_QUANTITY --,TOSL.QUANTITY SHIPMENT_QUANTITY
    ,DPT.PAYMENT_TYPE_NAME
    ,COALESCE(TOSLC.order_release_key, TOSLP.order_release_key) AS order_release_key --,TOSL.order_release_key
    --,TOSL.item_id as sku_code 
    ,SP.sku_code
    ,COALESCE(TOSLC.shipment_key, TOSLP.shipment_key) AS shipment_key --,TOSL.shipment_key
    ,TBH.pk_oms_tax_breakupid as  HEADER_TAX_BREAKUP_pk_oms_tax_breakupid
    ,TBH.tax_breakup_key as HEADER_TAX_BREAKUP_tax_breakup_key
    ,TBL.pk_oms_tax_breakupid as LINE_TAX_BREAKUP_pk_oms_tax_breakupid
    ,TBL.tax_breakup_key as LINE_TAX_BREAKUP_tax_breakup_key
    ,TP.transactionid
    ,TBH.tax_percentage as HEADER_TAX_BREAKUP_tax_percentage
    ,TBL.tax_percentage as LINE_TAX_BREAKUP_tax_percentage
    ,DCI.EMAIL_PRIMARY
    ,TOH.tax_exempt
    ,DOT.ORDER_TYPE_NAME
    ,TOS.tracking_no
    ,DOST.ORDER_STATUS_NAME as ORDER_HEADER_STATUS
    ,DODST.ORDER_STATUS_NAME as ORDER_DETAIL_STATUS
    ,OH.EXTN_IS_PRIME
    ,OH.EXTN_LATEST_SHIP_DATE
    ,OH.EXTN_MARKET_PLACE_ID
    ,OH.CUSTOMER_CUSTOMER_PO_NO
    ,OD.EXTN_ITEM_ID
    ,OD.ITEM_DESCRIPTION
    ,COALESCE(TOSLC.release_no, TOSLP.release_no) AS release_no --,TOSL.release_no
    ,TOS.extn_narvar_url
    ,OD.extn_mfg_warranty_start_date
    ,OD.extn_mfg_warranty_end_date
    ,OH.EXTN_WARRANTY_ORDER_NO
    ,TOHR.source_ref_num as origional_order_no
    ,TBH.tax as HEADER_TAX_BREAKUP_tax
    ,TBL.tax as LINE_TAX_BREAKUP_tax
    ,HC.header_charges_key
    ,TOH.extn_brand
    ,TODM.order_line_key as order_line_key_multipart
    ,COALESCE(TOSC.EXTN_UPC_ITEM_ID, TOSC_ORIG.EXTN_UPC_ITEM_ID) AS upc_code
FROM ANALYTICS.TXN_ORDER_HEADER TOH
INNER JOIN ANALYTICS.txn_order_detail TOD
    ON TOD.fk_order_headerid = TOH.pk_order_headerid

-- Join to get actual child records
LEFT JOIN ANALYTICS.txn_order_detail_multipart TODM
    ON TODM.fk_order_detailid = TOD.pk_order_detailid

-- Auxiliary join to check if children exist
LEFT JOIN ANALYTICS.txn_order_detail_multipart TODM_CHECK
    ON TODM_CHECK.fk_order_detailid = TOD.pk_order_detailid

LEFT JOIN ANALYTICS.ext_order_header OH
    ON OH.order_header_key = TOH.order_header_key
LEFT JOIN ANALYTICS.ext_order_detail OD 
    ON OD.order_header_key = OH.order_header_key 
    AND OD.order_line_key = TOD.order_line_key
LEFT JOIN ANALYTICS.customer DC 
    ON DC.pk_customerid = TOH.fk_customerid
LEFT JOIN master.sourcemap DS 
    ON DS.pk_sourceid = DC.fk_sourceid AND CATALOGID > 5
LEFT JOIN ANALYTICS.customer_info DCI 
    ON DCI.fk_customerid = DC.pk_customerid
LEFT JOIN ANALYTICS.txn_address TAB
    ON TAB.pk_addressid = TOH.fk_billing_addressid
LEFT JOIN ANALYTICS.txn_address TAS
    ON TAS.pk_addressid = TOH.fk_shipping_addressid
LEFT JOIN master.dim_currency DCC
    ON DCC.pk_currencyid = TOH.fk_currencyid
LEFT JOIN analytics.txn_payment TP
    ON TP.fk_order_headerid = TOH.pk_order_headerid
LEFT JOIN master.dim_payment_method DPM
    ON DPM.pk_payment_method_id = TP.fk_payment_methodid
LEFT JOIN master.dim_payment_type DPT
    ON DPT.PK_PAYMENT_TYPEID = TP.fk_payment_typeid
LEFT JOIN ANALYTICS.txn_order_line_charges LC 
    ON LC.line_key = OD.order_line_key
LEFT JOIN ANALYTICS.txn_order_Header_charges HC 
    ON HC.header_key = OH.order_Header_key
LEFT JOIN ANALYTICS.txn_order_tax_breakup TBH 
    ON TBH.header_key = OH.order_header_key 
    AND TBH.line_key IS NULL
LEFT JOIN ANALYTICS.txn_order_tax_breakup TBL 
    ON TBL.line_key = OD.order_line_key
LEFT JOIN ANALYTICS.txn_order_invoice TOI 
    ON TOI.order_header_key = OD.order_header_key

-- Child shipment line join (for multipart items)
LEFT JOIN ANALYTICS.txn_order_shipment_line TOSLC
    ON TOSLC.order_line_key = TODM.order_line_key

-- Parent shipment line join (only if no child exists)
LEFT JOIN ANALYTICS.txn_order_shipment_line TOSLP
    ON TOSLP.order_line_key = CASE 
        WHEN TODM_CHECK.pk_order_detail_multipartid IS NULL THEN TOD.order_line_key
        ELSE NULL
    END

LEFT JOIN ANALYTICS.txn_order_shipment TOS
    ON TOS.shipment_key = COALESCE(TOSLC.shipment_key, TOSLP.shipment_key)

LEFT JOIN analytics.txn_order_container_details TOSC
    ON TOSC.shipment_line_key = COALESCE(TOSLC.shipment_line_key, TOSLP.shipment_line_key)

LEFT JOIN ANALYTICS.txn_order_status TOST
    ON TOST.FK_ORDER_HEADERID = TOH.pk_order_headerid 
LEFT JOIN master.dim_order_status DOST
    ON DOST.PK_ORDER_STATUSID = TOST.FK_ORDER_STATUSID 
    AND DOST.ORDER_STATUS_NAME IN ('Delivered', 'CANCELLED')
LEFT JOIN MASTER.dim_order_type DOT
    ON DOT.pk_order_typeid = TOH.fk_order_typeid
LEFT JOIN analytics.txn_order_detail_status TODS
    ON TODS.pk_order_detailid = TOD.pk_order_detailid
LEFT JOIN master.dim_order_status DODST
    ON DODST.pk_order_statusid = TODS.FK_ORDER__DETAIL_STATUSID
LEFT JOIN ANALYTICS.TXN_ORDER_HEADER TOHR
    ON TOHR.order_header_key = OD.DERIVED_FROM_ORDER_HEADER_KEY
LEFT JOIN analytics.Sku_product SP
    ON SP.pk_skuproductid = TOD.fk_skuproductid


LEFT JOIN ANALYTICS.ext_order_detail OD_ORIG
    ON OD_ORIG.order_line_key = OD.DERIVED_FROM_ORDER_LINE_KEY
LEFT JOIN ANALYTICS.txn_order_shipment_line TOSL_ORIG
    ON TOSL_ORIG.order_line_key = OD_ORIG.order_line_key
LEFT JOIN analytics.txn_order_container_details TOSC_ORIG
    ON TOSC_ORIG.shipment_line_key = TOSL_ORIG.shipment_line_key

WHERE TOH.pk_order_headerid = 6319392;  --5959906;






-----------------------------------------------------------------------------------------------------------


CALL ANALYTICS.SP_ORDER_EXTRACT('2024-12-02', '2024-12-02',     '6333504',     '6333504' );

CALL ANALYTICS.SP_ORDER_EXTRACT('2024-12-02', '2024-12-02',     null,     null );

CALL ANALYTICS.SP_ORDER_EXTRACT('6333504',     '6333504' );

20241202001112558041038	20241202001112558041034
Origional order number - J101002069

CALL ANALYTICS.SP_ORDER_EXTRACT('5959906',     '5959906' );

R100562775 --present
R100562788  --NP
    GRANT USAGE ON PROCEDURE ANALYTICS.SP_ORDER_EXTRACT(
     DATE,
    DATE,
    number,
    number
   
) TO ROLE MULESOFT_SERVICE_ROLE;

    GRANT USAGE ON PROCEDURE ANALYTICS.SP_ORDER_EXTRACT(
    varchar,
    varchar
   
) TO ROLE MULESOFT_SERVICE_ROLE;

CREATE OR REPLACE PROCEDURE ANALYTICS.SP_ORDER_EXTRACT("START_DATE" DATE, "END_DATE" DATE, "START_HEADER_ID" number(38,0) DEFAULT null, "END_HEADER_ID" number(38,0) DEFAULT null)
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE 
    start_time_proc TIMESTAMP_NTZ(9);

BEGIN

start_time_proc := CURRENT_TIMESTAMP();
SYSTEM$LOG('TRACE','SP STARTED- SP_ORDER_EXTRACT');

LET pk_header_id_start_i number(38,0) := :start_header_id;  
LET pk_header_id_end_i number(38,0) := :end_header_id;
--LET start_date_n date := :start_date;
--LET end_date_n date := :end_date;
LET results RESULTSET :=(

select DISTINCT TOH.pk_order_headerid,  
    TOH.source_ref_num,
    DCC.currency_code AS ORDER_HEADER_CURRENCY,
    TOH.order_date,
    'UTC' as TIME_ZONE,
    OH.entry_type,
    DPM.payment_method_name
    ,TAB.first_name as bill_first_name
    ,TAB.last_name as bill_last_name
    ,TAB.phone_number as bill_phone_number
    ,TAB.address1 as bill_address1
    ,TAB.address2 as bill_address2
    ,TAB.city as bill_city
    ,TAB.state as bill_state
    ,TAB.country as bill_country
    ,TAB.postal_code as bill_postal_code
    ,TAB.address3 as bill_address3
    ,TAS.first_name as ship_first_name
    ,TAS.last_name as ship_last_name
    ,TAS.phone_number as ship_phone_number
    ,TAS.address1 as ship_address1
    ,TAS.address2 as ship_address2
    ,TAS.city as ship_city
    ,TAS.state as ship_state
    ,TAS.country as ship_country
    ,TAS.postal_code as ship_postal_code
    ,TAS.address3 as ship_address3
    ,OH.seller_organization_code  AS ORDER_HEADER_seller_organization_code
    ,OD.prime_line_no
    ,OD.invoiced_quantity
    ,OD.unit_price
    ,OD.retail_price
    ,OD.tax_product_code
    ,LC.charge_category AS LINE_CHARGES_charge_category
    ,LC.charge_name AS LINE_CHARGES_charge_name
    ,LC.extn_coupon_code  AS LINE_CHARGES_extn_coupon_code
    ,OD.shipped_quantity
    ,OH.extn_sms_opt_in
    ,CASE
        WHEN OH.seller_organization_code IN ('BH_US', 'BH_CA') THEN
            TO_CHAR(TO_DATE(OH.EXTN_MIN_ESTIMATED_DELIVERY_DATE, 'MM/DD/YYYY'), 'MM/DD/YYYY')
        ELSE
            TO_CHAR(TO_DATE(OH.EXTN_MIN_ESTIMATED_DELIVERY_DATE, 'DD/MM/YYYY'), 'MM/DD/YYYY')
    END AS EXTN_MIN_ESTIMATED_DELIVERY_DATE
    ,CASE
        WHEN OH.seller_organization_code IN ('BH_US', 'BH_CA') THEN
            TO_CHAR(TO_DATE(OH.EXTN_MAX_ESTIMATED_DELIVERY_DATE, 'MM/DD/YYYY'), 'MM/DD/YYYY')
        ELSE
            TO_CHAR(TO_DATE(OH.EXTN_MAX_ESTIMATED_DELIVERY_DATE, 'DD/MM/YYYY'), 'MM/DD/YYYY')
    END AS EXTN_MAX_ESTIMATED_DELIVERY_DATE
    ,OH.extn_giftee_email_id
    ,OH.extn_giftee_full_name
    ,TP.authorization_code
    ,OD.line_type
    ,TOD.ORDER_LINE_KEY
    ,TOH.ORDER_HEADER_KEY
    ,TOD.PK_ORDER_DETAILID
    ,TOI.LINE_SUBTOTAL
    ,LC.chargeperline
    ,LC.invoiced_charge_per_line
    ,LC.reference AS LINE_CHARGES_reference
    ,LC.chargeamount as LINE_CHARGES_chargeamount
    ,HC.EXTN_CHARGE_DESCRIPTION as HEADER_CHARGES_EXTN_CHARGE_DESCRIPTION
    ,HC.reference AS HEADER_CHARGES_reference
    ,HC.charge as HEADER_CHARGES_CHARGE
    ,HC.INVOICED_CHARGE as HEADER_CHARGES_INVOICED_CHARGE
    ,HC.original_charge as HEADER_CHARGES_original_charge
    ,HC.charge_category AS HEADER_CHARGES_charge_category
    ,HC.charge_name AS HEADER_CHARGES_charge_name
    ,HC.extn_coupon_code  AS HEADER_CHARGES_extn_coupon_code
    ,OD.line_total 
    ,OH.scac AS ORDER_HEADER_scac
    ,OD.scac AS ORDER_DETAIL_scac
    ,OH.carrier_service_code AS ORDER_HEADER_carrier_service_code
    ,OD.carrier_service_code AS ORDER_DETAIL_carrier_service_code
    ,OD.level_of_service
    ,TBH.tax_name HEADER_tax_name
    ,OH.original_tax
    ,OD.tax  AS ORDER_DETAIL_tax
    ,TBH.record_type AS HEADER_TAX_BREAKUP_record_type
    ,TBH.charge_category AS HEADER_TAX_BREAKUP_charge_category
    ,TBH.charge_name AS HEADER_TAX_BREAKUP_charge_name
    ,TBL.tax_name AS LINE_TAX_BREAKUP_tax_name
    ,TBL.record_type AS LINE_TAX_BREAKUP_record_type
    ,TBL.charge_category AS LINE_TAX_BREAKUP_charge_category
    ,TBL.charge_name AS LINE_TAX_BREAKUP_charge_name
    ,TOI.TAX  AS INVOICE_TAX
    ,TOI.TOTAL_TAX
    ,TOI.OTHER_CHARGES AS TAX_BREAKUP_OTHER_CHARGES
    ,TOH.tax_amount AS ORDER_HEADER_tax_amount
    ,DS.Brandcode
    ,LC.line_charges_key
    ,CAST(TOS.shipnode_key AS NUMBER(38,0)) AS ship_node
    ,DCI.first_name as CUSTOMER_FIRSTNAME
    ,DCI.last_name as CUSTOMER_LASTNAME
    ,DCI.mobi_phone_primary as CUSTOMER_PHONENUMBER
    ,DC.source_ref_num AS CUSTOMER_SOURCE_REF_NO
    ,OH.customer_po_no AS ORDER_HEADER_customer_po_no
    ,COALESCE(TOSLC.QUANTITY, TOSLP.QUANTITY) AS SHIPMENT_QUANTITY --,TOSL.QUANTITY SHIPMENT_QUANTITY
    ,DPT.PAYMENT_TYPE_NAME
    ,COALESCE(TOSLC.order_release_key, TOSLP.order_release_key) AS order_release_key --,TOSL.order_release_key
    --,TOSL.item_id as sku_code 
    ,SP.sku_code
    ,COALESCE(TOSLC.shipment_key, TOSLP.shipment_key) AS shipment_key --,TOSL.shipment_key
    ,TBH.pk_oms_tax_breakupid as  HEADER_TAX_BREAKUP_pk_oms_tax_breakupid
    ,TBH.tax_breakup_key as HEADER_TAX_BREAKUP_tax_breakup_key
    ,TBL.pk_oms_tax_breakupid as LINE_TAX_BREAKUP_pk_oms_tax_breakupid
    ,TBL.tax_breakup_key as LINE_TAX_BREAKUP_tax_breakup_key
    ,TP.transactionid
    ,TBH.tax_percentage as HEADER_TAX_BREAKUP_tax_percentage
    ,TBL.tax_percentage as LINE_TAX_BREAKUP_tax_percentage
    ,DCI.EMAIL_PRIMARY
    ,TOH.tax_exempt
    ,DOT.ORDER_TYPE_NAME
    ,TOS.tracking_no
    ,DOST.ORDER_STATUS_NAME as ORDER_HEADER_STATUS
    ,DODST.ORDER_STATUS_NAME as ORDER_DETAIL_STATUS
    ,OH.EXTN_IS_PRIME
    ,OH.EXTN_LATEST_SHIP_DATE
    ,OH.EXTN_MARKET_PLACE_ID
    ,OH.CUSTOMER_CUSTOMER_PO_NO
    ,OD.EXTN_ITEM_ID
    ,OD.ITEM_DESCRIPTION
    ,COALESCE(TOSLC.release_no, TOSLP.release_no) AS release_no --,TOSL.release_no
    ,TOS.extn_narvar_url
    ,OD.extn_mfg_warranty_start_date
    ,OD.extn_mfg_warranty_end_date
    ,OH.EXTN_WARRANTY_ORDER_NO
    ,TOHR.source_ref_num as origional_order_no
    ,TBH.tax as HEADER_TAX_BREAKUP_tax
    ,TBL.tax as LINE_TAX_BREAKUP_tax
    ,HC.header_charges_key
    ,TOH.extn_brand
    ,TODM.order_line_key as order_line_key_multipart
    ,COALESCE(TOSC.EXTN_UPC_ITEM_ID, TOSC_ORIG.EXTN_UPC_ITEM_ID) AS upc_code
FROM ANALYTICS.TXN_ORDER_HEADER TOH
INNER JOIN ANALYTICS.txn_order_detail TOD
    ON TOD.fk_order_headerid = TOH.pk_order_headerid

-- Join to get actual child records
LEFT JOIN ANALYTICS.txn_order_detail_multipart TODM
    ON TODM.fk_order_detailid = TOD.pk_order_detailid

-- Auxiliary join to check if children exist
LEFT JOIN ANALYTICS.txn_order_detail_multipart TODM_CHECK
    ON TODM_CHECK.fk_order_detailid = TOD.pk_order_detailid

LEFT JOIN ANALYTICS.ext_order_header OH
    ON OH.order_header_key = TOH.order_header_key
LEFT JOIN ANALYTICS.ext_order_detail OD 
    ON OD.order_header_key = OH.order_header_key 
    AND OD.order_line_key = TOD.order_line_key
LEFT JOIN ANALYTICS.customer DC 
    ON DC.pk_customerid = TOH.fk_customerid
LEFT JOIN master.sourcemap DS 
    ON DS.pk_sourceid = DC.fk_sourceid AND CATALOGID > 5
LEFT JOIN ANALYTICS.customer_info DCI 
    ON DCI.fk_customerid = DC.pk_customerid
LEFT JOIN ANALYTICS.txn_address TAB
    ON TAB.pk_addressid = TOH.fk_billing_addressid
LEFT JOIN ANALYTICS.txn_address TAS
    ON TAS.pk_addressid = TOH.fk_shipping_addressid
LEFT JOIN master.dim_currency DCC
    ON DCC.pk_currencyid = TOH.fk_currencyid
LEFT JOIN analytics.txn_payment TP
    ON TP.fk_order_headerid = TOH.pk_order_headerid
LEFT JOIN master.dim_payment_method DPM
    ON DPM.pk_payment_method_id = TP.fk_payment_methodid
LEFT JOIN master.dim_payment_type DPT
    ON DPT.PK_PAYMENT_TYPEID = TP.fk_payment_typeid
LEFT JOIN ANALYTICS.txn_order_line_charges LC 
    ON LC.line_key = OD.order_line_key
LEFT JOIN ANALYTICS.txn_order_Header_charges HC 
    ON HC.header_key = OH.order_Header_key
LEFT JOIN ANALYTICS.txn_order_tax_breakup TBH 
    ON TBH.header_key = OH.order_header_key 
    AND TBH.line_key IS NULL
LEFT JOIN ANALYTICS.txn_order_tax_breakup TBL 
    ON TBL.line_key = OD.order_line_key
LEFT JOIN ANALYTICS.txn_order_invoice TOI 
    ON TOI.order_header_key = OD.order_header_key

-- Child shipment line join (for multipart items)
LEFT JOIN ANALYTICS.txn_order_shipment_line TOSLC
    ON TOSLC.order_line_key = TODM.order_line_key

-- Parent shipment line join (only if no child exists)
LEFT JOIN ANALYTICS.txn_order_shipment_line TOSLP
    ON TOSLP.order_line_key = CASE 
        WHEN TODM_CHECK.pk_order_detail_multipartid IS NULL THEN TOD.order_line_key
        ELSE NULL
    END

LEFT JOIN ANALYTICS.txn_order_shipment TOS
    ON TOS.shipment_key = COALESCE(TOSLC.shipment_key, TOSLP.shipment_key)

LEFT JOIN analytics.txn_order_container_details TOSC
    ON TOSC.shipment_line_key = COALESCE(TOSLC.shipment_line_key, TOSLP.shipment_line_key)

LEFT JOIN ANALYTICS.txn_order_status TOST
    ON TOST.FK_ORDER_HEADERID = TOH.pk_order_headerid 
LEFT JOIN master.dim_order_status DOST
    ON DOST.PK_ORDER_STATUSID = TOST.FK_ORDER_STATUSID 
    AND DOST.ORDER_STATUS_NAME IN ('Delivered', 'CANCELLED')
LEFT JOIN MASTER.dim_order_type DOT
    ON DOT.pk_order_typeid = TOH.fk_order_typeid
LEFT JOIN analytics.txn_order_detail_status TODS
    ON TODS.pk_order_detailid = TOD.pk_order_detailid
LEFT JOIN master.dim_order_status DODST
    ON DODST.pk_order_statusid = TODS.FK_ORDER__DETAIL_STATUSID
LEFT JOIN ANALYTICS.TXN_ORDER_HEADER TOHR
    ON TOHR.order_header_key = OD.DERIVED_FROM_ORDER_HEADER_KEY
LEFT JOIN analytics.Sku_product SP
    ON SP.pk_skuproductid = TOD.fk_skuproductid

LEFT JOIN ANALYTICS.ext_order_detail OD_ORIG
    ON OD_ORIG.order_line_key = OD.DERIVED_FROM_ORDER_LINE_KEY
LEFT JOIN ANALYTICS.txn_order_shipment_line TOSL_ORIG
    ON TOSL_ORIG.order_line_key = OD_ORIG.order_line_key
LEFT JOIN analytics.txn_order_container_details TOSC_ORIG
    ON TOSC_ORIG.shipment_line_key = TOSL_ORIG.shipment_line_key
    
WHERE --OH.order_header_key BETWEEN :start_header_key AND :end_header_key
    (:pk_header_id_start_i IS NULL OR TOH.pk_order_headerid >= :start_header_id)
      AND (:pk_header_id_end_i IS NULL OR TOH.pk_order_headerid <= :end_header_id)
      AND(DATE(TOH.order_date) >= :start_date AND DATE(TOH.order_date) <= :END_DATE)
	order by TOH.pk_order_headerid, TOD.pk_order_detailid, OD.prime_line_no
);

SYSTEM$LOG('TRACE','SP COMPLETED- SP_ORDER_EXTRACT');

RETURN TABLE(results);

END;




------------------------------------------------------two paramm SP-------------------------------------



CREATE OR REPLACE PROCEDURE ANALYTICS.SP_ORDER_EXTRACT("START_HEADER_ID" VARCHAR(12559), "END_HEADER_ID" VARCHAR(12559))
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE 
    start_time_proc TIMESTAMP_NTZ(9);

BEGIN

start_time_proc := CURRENT_TIMESTAMP();
SYSTEM$LOG('TRACE','SP STARTED- SP_ORDER_EXTRACT');
LET pk_header_id_start_i number(38,0) := :start_header_id;  
LET pk_header_id_end_i number(38,0) := :end_header_id;

LET results RESULTSET :=(

select DISTINCT TOH.pk_order_headerid,  
    TOH.source_ref_num,
    DCC.currency_code AS ORDER_HEADER_CURRENCY,
    TOH.order_date,
    'UTC' as TIME_ZONE,
    OH.entry_type,
    DPM.payment_method_name
    ,TAB.first_name as bill_first_name
    ,TAB.last_name as bill_last_name
    ,TAB.phone_number as bill_phone_number
    ,TAB.address1 as bill_address1
    ,TAB.address2 as bill_address2
    ,TAB.city as bill_city
    ,TAB.state as bill_state
    ,TAB.country as bill_country
    ,TAB.postal_code as bill_postal_code
    ,TAB.address3 as bill_address3
    ,TAS.first_name as ship_first_name
    ,TAS.last_name as ship_last_name
    ,TAS.phone_number as ship_phone_number
    ,TAS.address1 as ship_address1
    ,TAS.address2 as ship_address2
    ,TAS.city as ship_city
    ,TAS.state as ship_state
    ,TAS.country as ship_country
    ,TAS.postal_code as ship_postal_code
    ,TAS.address3 as ship_address3
    ,OH.seller_organization_code  AS ORDER_HEADER_seller_organization_code
    ,OD.prime_line_no
    ,OD.invoiced_quantity
    ,OD.unit_price
    ,OD.retail_price
    ,OD.tax_product_code
    ,LC.charge_category AS LINE_CHARGES_charge_category
    ,LC.charge_name AS LINE_CHARGES_charge_name
    ,LC.extn_coupon_code  AS LINE_CHARGES_extn_coupon_code
    ,OD.shipped_quantity
    ,OH.extn_sms_opt_in
    ,CASE
        WHEN OH.seller_organization_code IN ('BH_US', 'BH_CA') THEN
            TO_CHAR(TO_DATE(OH.EXTN_MIN_ESTIMATED_DELIVERY_DATE, 'MM/DD/YYYY'), 'MM/DD/YYYY')
        ELSE
            TO_CHAR(TO_DATE(OH.EXTN_MIN_ESTIMATED_DELIVERY_DATE, 'DD/MM/YYYY'), 'MM/DD/YYYY')
    END AS EXTN_MIN_ESTIMATED_DELIVERY_DATE
    ,CASE
        WHEN OH.seller_organization_code IN ('BH_US', 'BH_CA') THEN
            TO_CHAR(TO_DATE(OH.EXTN_MAX_ESTIMATED_DELIVERY_DATE, 'MM/DD/YYYY'), 'MM/DD/YYYY')
        ELSE
            TO_CHAR(TO_DATE(OH.EXTN_MAX_ESTIMATED_DELIVERY_DATE, 'DD/MM/YYYY'), 'MM/DD/YYYY')
    END AS EXTN_MAX_ESTIMATED_DELIVERY_DATE
    ,OH.extn_giftee_email_id
    ,OH.extn_giftee_full_name
    ,TP.authorization_code
    ,OD.line_type
    ,TOD.ORDER_LINE_KEY
    ,TOH.ORDER_HEADER_KEY
    ,TOD.PK_ORDER_DETAILID
    ,TOI.LINE_SUBTOTAL
    ,LC.chargeperline
    ,LC.invoiced_charge_per_line
    ,LC.reference AS LINE_CHARGES_reference
    ,LC.chargeamount as LINE_CHARGES_chargeamount
    ,HC.EXTN_CHARGE_DESCRIPTION as HEADER_CHARGES_EXTN_CHARGE_DESCRIPTION
    ,HC.reference AS HEADER_CHARGES_reference
    ,HC.charge as HEADER_CHARGES_CHARGE
    ,HC.INVOICED_CHARGE as HEADER_CHARGES_INVOICED_CHARGE
    ,HC.original_charge as HEADER_CHARGES_original_charge
    ,HC.charge_category AS HEADER_CHARGES_charge_category
    ,HC.charge_name AS HEADER_CHARGES_charge_name
    ,HC.extn_coupon_code  AS HEADER_CHARGES_extn_coupon_code
    ,OD.line_total 
    ,OH.scac AS ORDER_HEADER_scac
    ,OD.scac AS ORDER_DETAIL_scac
    ,OH.carrier_service_code AS ORDER_HEADER_carrier_service_code
    ,OD.carrier_service_code AS ORDER_DETAIL_carrier_service_code
    ,OD.level_of_service
    ,TBH.tax_name HEADER_tax_name
    ,OH.original_tax
    ,OD.tax  AS ORDER_DETAIL_tax
    ,TBH.record_type AS HEADER_TAX_BREAKUP_record_type
    ,TBH.charge_category AS HEADER_TAX_BREAKUP_charge_category
    ,TBH.charge_name AS HEADER_TAX_BREAKUP_charge_name
    ,TBL.tax_name AS LINE_TAX_BREAKUP_tax_name
    ,TBL.record_type AS LINE_TAX_BREAKUP_record_type
    ,TBL.charge_category AS LINE_TAX_BREAKUP_charge_category
    ,TBL.charge_name AS LINE_TAX_BREAKUP_charge_name
    ,TOI.TAX  AS INVOICE_TAX
    ,TOI.TOTAL_TAX
    ,TOI.OTHER_CHARGES AS TAX_BREAKUP_OTHER_CHARGES
    ,TOH.tax_amount AS ORDER_HEADER_tax_amount
    ,DS.Brandcode
    ,LC.line_charges_key
    ,CAST(TOS.shipnode_key AS NUMBER(38,0)) AS ship_node
    ,DCI.first_name as CUSTOMER_FIRSTNAME
    ,DCI.last_name as CUSTOMER_LASTNAME
    ,DCI.mobi_phone_primary as CUSTOMER_PHONENUMBER
    ,DC.source_ref_num AS CUSTOMER_SOURCE_REF_NO
    ,OH.customer_po_no AS ORDER_HEADER_customer_po_no
    ,COALESCE(TOSLC.QUANTITY, TOSLP.QUANTITY) AS SHIPMENT_QUANTITY --,TOSL.QUANTITY SHIPMENT_QUANTITY
    ,DPT.PAYMENT_TYPE_NAME
    ,COALESCE(TOSLC.order_release_key, TOSLP.order_release_key) AS order_release_key --,TOSL.order_release_key
    --,TOSL.item_id as sku_code 
    ,SP.sku_code
    ,COALESCE(TOSLC.shipment_key, TOSLP.shipment_key) AS shipment_key --,TOSL.shipment_key
    ,TBH.pk_oms_tax_breakupid as  HEADER_TAX_BREAKUP_pk_oms_tax_breakupid
    ,TBH.tax_breakup_key as HEADER_TAX_BREAKUP_tax_breakup_key
    ,TBL.pk_oms_tax_breakupid as LINE_TAX_BREAKUP_pk_oms_tax_breakupid
    ,TBL.tax_breakup_key as LINE_TAX_BREAKUP_tax_breakup_key
    ,TP.transactionid
    ,TBH.tax_percentage as HEADER_TAX_BREAKUP_tax_percentage
    ,TBL.tax_percentage as LINE_TAX_BREAKUP_tax_percentage
    ,DCI.EMAIL_PRIMARY
    ,TOH.tax_exempt
    ,DOT.ORDER_TYPE_NAME
    ,TOS.tracking_no
    ,DOST.ORDER_STATUS_NAME as ORDER_HEADER_STATUS
    ,DODST.ORDER_STATUS_NAME as ORDER_DETAIL_STATUS
    ,OH.EXTN_IS_PRIME
    ,OH.EXTN_LATEST_SHIP_DATE
    ,OH.EXTN_MARKET_PLACE_ID
    ,OH.CUSTOMER_CUSTOMER_PO_NO
    ,OD.EXTN_ITEM_ID
    ,OD.ITEM_DESCRIPTION
    ,COALESCE(TOSLC.release_no, TOSLP.release_no) AS release_no --,TOSL.release_no
    ,TOS.extn_narvar_url
    ,OD.extn_mfg_warranty_start_date
    ,OD.extn_mfg_warranty_end_date
    ,OH.EXTN_WARRANTY_ORDER_NO
    ,TOHR.source_ref_num as origional_order_no
    ,TBH.tax as HEADER_TAX_BREAKUP_tax
    ,TBL.tax as LINE_TAX_BREAKUP_tax
    ,HC.header_charges_key
    ,TOH.extn_brand
    ,TODM.order_line_key as order_line_key_multipart
    ,COALESCE(TOSC.EXTN_UPC_ITEM_ID, TOSC_ORIG.EXTN_UPC_ITEM_ID) AS upc_code
FROM ANALYTICS.TXN_ORDER_HEADER TOH
INNER JOIN ANALYTICS.txn_order_detail TOD
    ON TOD.fk_order_headerid = TOH.pk_order_headerid

-- Join to get actual child records
LEFT JOIN ANALYTICS.txn_order_detail_multipart TODM
    ON TODM.fk_order_detailid = TOD.pk_order_detailid

-- Auxiliary join to check if children exist
LEFT JOIN ANALYTICS.txn_order_detail_multipart TODM_CHECK
    ON TODM_CHECK.fk_order_detailid = TOD.pk_order_detailid

LEFT JOIN ANALYTICS.ext_order_header OH
    ON OH.order_header_key = TOH.order_header_key
LEFT JOIN ANALYTICS.ext_order_detail OD 
    ON OD.order_header_key = OH.order_header_key 
    AND OD.order_line_key = TOD.order_line_key
LEFT JOIN ANALYTICS.customer DC 
    ON DC.pk_customerid = TOH.fk_customerid
LEFT JOIN master.sourcemap DS 
    ON DS.pk_sourceid = DC.fk_sourceid AND CATALOGID > 5
LEFT JOIN ANALYTICS.customer_info DCI 
    ON DCI.fk_customerid = DC.pk_customerid
LEFT JOIN ANALYTICS.txn_address TAB
    ON TAB.pk_addressid = TOH.fk_billing_addressid
LEFT JOIN ANALYTICS.txn_address TAS
    ON TAS.pk_addressid = TOH.fk_shipping_addressid
LEFT JOIN master.dim_currency DCC
    ON DCC.pk_currencyid = TOH.fk_currencyid
LEFT JOIN analytics.txn_payment TP
    ON TP.fk_order_headerid = TOH.pk_order_headerid
LEFT JOIN master.dim_payment_method DPM
    ON DPM.pk_payment_method_id = TP.fk_payment_methodid
LEFT JOIN master.dim_payment_type DPT
    ON DPT.PK_PAYMENT_TYPEID = TP.fk_payment_typeid
LEFT JOIN ANALYTICS.txn_order_line_charges LC 
    ON LC.line_key = OD.order_line_key
LEFT JOIN ANALYTICS.txn_order_Header_charges HC 
    ON HC.header_key = OH.order_Header_key
LEFT JOIN ANALYTICS.txn_order_tax_breakup TBH 
    ON TBH.header_key = OH.order_header_key 
    AND TBH.line_key IS NULL
LEFT JOIN ANALYTICS.txn_order_tax_breakup TBL 
    ON TBL.line_key = OD.order_line_key
LEFT JOIN ANALYTICS.txn_order_invoice TOI 
    ON TOI.order_header_key = OD.order_header_key

-- Child shipment line join (for multipart items)
LEFT JOIN ANALYTICS.txn_order_shipment_line TOSLC
    ON TOSLC.order_line_key = TODM.order_line_key

-- Parent shipment line join (only if no child exists)
LEFT JOIN ANALYTICS.txn_order_shipment_line TOSLP
    ON TOSLP.order_line_key = CASE 
        WHEN TODM_CHECK.pk_order_detail_multipartid IS NULL THEN TOD.order_line_key
        ELSE NULL
    END

LEFT JOIN ANALYTICS.txn_order_shipment TOS
    ON TOS.shipment_key = COALESCE(TOSLC.shipment_key, TOSLP.shipment_key)

LEFT JOIN analytics.txn_order_container_details TOSC
    ON TOSC.shipment_line_key = COALESCE(TOSLC.shipment_line_key, TOSLP.shipment_line_key)

LEFT JOIN ANALYTICS.txn_order_status TOST
    ON TOST.FK_ORDER_HEADERID = TOH.pk_order_headerid 
LEFT JOIN master.dim_order_status DOST
    ON DOST.PK_ORDER_STATUSID = TOST.FK_ORDER_STATUSID 
    AND DOST.ORDER_STATUS_NAME IN ('Delivered', 'CANCELLED')
LEFT JOIN MASTER.dim_order_type DOT
    ON DOT.pk_order_typeid = TOH.fk_order_typeid
LEFT JOIN analytics.txn_order_detail_status TODS
    ON TODS.pk_order_detailid = TOD.pk_order_detailid
LEFT JOIN master.dim_order_status DODST
    ON DODST.pk_order_statusid = TODS.FK_ORDER__DETAIL_STATUSID
LEFT JOIN ANALYTICS.TXN_ORDER_HEADER TOHR
    ON TOHR.order_header_key = OD.DERIVED_FROM_ORDER_HEADER_KEY
LEFT JOIN analytics.Sku_product SP
    ON SP.pk_skuproductid = TOD.fk_skuproductid
LEFT JOIN ANALYTICS.ext_order_detail OD_ORIG
    ON OD_ORIG.order_line_key = OD.DERIVED_FROM_ORDER_LINE_KEY
LEFT JOIN ANALYTICS.txn_order_shipment_line TOSL_ORIG
    ON TOSL_ORIG.order_line_key = OD_ORIG.order_line_key
LEFT JOIN analytics.txn_order_container_details TOSC_ORIG
    ON TOSC_ORIG.shipment_line_key = TOSL_ORIG.shipment_line_key
WHERE TOH.pk_order_headerid >= :pk_header_id_start_i AND TOH.pk_order_headerid <= :pk_header_id_end_i
order by TOH.pk_order_headerid, TOD.pk_order_detailid, OD.prime_line_no
);

SYSTEM$LOG('TRACE','SP COMPLETED- SP_ORDER_EXTRACT');

RETURN TABLE(results);

END;

