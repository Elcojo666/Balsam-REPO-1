use schema analytics;

CREATE OR REPLACE PROCEDURE "SP_DELETECUSTOMERADDRESSDETAILS"("SOURCEID" NUMBER(38,0), "PK_CUSTOMERID" VARCHAR(16777216), "PK_CUSTOMER_ADDRESS_ID" NUMBER(38,0))
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    pk_customer_info_id STRING;
    pk_customer_address_id_temp STRING;
    message STRING;
BEGIN
SYSTEM$LOG(''TRACE'','' sp_DeleteCustomerAddressDetails has been Started'');

-- Retrieve PK_CUSTOMER_INFO_ID
SELECT PK_CUSTOMER_INFO_ID
INTO :pk_customer_info_id
FROM analytics.customer_info
WHERE FK_CUSTOMERID = :pk_customerid;

        -- Retrieve PK_CUSTOMER_ADDRESS_ID
SELECT PK_CUSTOMER_ADDRESS_ID
INTO :pk_customer_address_id_temp
FROM analytics.customer_address
WHERE PK_CUSTOMER_ADDRESS_ID = :pk_customer_address_id
AND FK_CUSTOMER_INFO_ID = :pk_customer_info_id;
          
        IF((:pk_customer_info_id IS NULL OR :pk_customer_info_id = '''')) then
         
                LET results resultset := (
                        SELECT ''WARNING: '' || :pk_customerid || '' Customer not found'' AS message, ''Failed'' AS status, ''400'' AS                              statuscode,   NULL AS id);
                RETURN TABLE(results);
        ELSEIF ((:pk_customer_address_id_temp IS NULL OR :pk_customer_address_id_temp = '''')) then
                    
                         LET results resultset := (
                            SELECT  ''WARNING: '' || :pk_customerid || '' Customer address not found'' AS message, ''Failed'' AS status, 
                            ''400'' statuscode, NULL AS id);
                        RETURN TABLE(results);
          ELSE
          --          -- Create a temporary table to capture deleted IDs
                        CREATE OR REPLACE TEMPORARY TABLE CustomerAddressApiCount (PK_CUSTOMER_ADDRESS_ID BIGINT);
                        
          --               -- Capture IDs that will be deleted
                        INSERT INTO CustomerAddressApiCount (PK_CUSTOMER_ADDRESS_ID)
                        SELECT PK_CUSTOMER_ADDRESS_ID
                        FROM analytics.customer_address
                        WHERE PK_CUSTOMER_ADDRESS_ID = :pk_customer_address_id
                          AND FK_CUSTOMER_INFO_ID = :pk_customer_info_id;
                        
          --               -- Delete from dim_customer_Address using the captured IDs
                        DELETE FROM analytics.customer_address
                        WHERE PK_CUSTOMER_ADDRESS_ID IN (SELECT PK_CUSTOMER_ADDRESS_ID FROM CustomerAddressApiCount);
        
                  
                     LET results resultset := (
                        SELECT ''Record Deleted'' AS message, ''Success'' AS status, ''200'' AS statuscode, PK_CUSTOMER_ADDRESS_ID AS id
                        FROM CustomerAddressApiCount);
                        RETURN TABLE(results);
    END IF;
    COMMIT;

    SYSTEM$LOG(''TRACE'','' sp_DeleteCustomerAddressDetails has been Completed'');

    
    EXCEPTION WHEN statement_error THEN ROLLBACK;

    SYSTEM$LOG(''ERROR'','' sp_DeleteCustomerAddressDetails has been Failed'');

        -- Handle errors and log them
        INSERT INTO ANALYTICS.log_microservices_errors(
            microservicesname,  
            methodname,  
            errortime,  
            errormessage,  
            source,  
            exceptiontrace,  
            sql_errornumber,  
            sql_errorstate,  
            sql_errorseverity,  
            sql_errorline,  
            sql_errorprocedure,  
            sql_errormessage
        )
        VALUES(
            ''CustomerApi'',  
            ''DeleteAddress'',  
            CURRENT_TIMESTAMP(),  
            ''Error in SQL'',  
            :sourceid,  
            NULL,  
            sqlcode,  
            NULL,  
            NULL,  
            NULL,  
            NULL,  
            sqlerrm
        );
      LET results resultset := (
            SELECT sqlerror AS message, ''Failed'' AS status, ''500'' AS statuscode, NULL AS id);
    
END';