
CREATE OR REPLACE PROCEDURE PROD.ANALYTICS.SP_Generate_Header_Line_Status("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE 
      start_time_proc TIMESTAMP_NTZ(9);
      error_object VARIANT;
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);


CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'Geneate Status',
        'STARTED',
        :start_time_proc,
        NULL,
        'Geneate Status started'
    );

CREATE OR REPLACE TEMP TABLE order_line_status_temp (
    order_header_key STRING NOT NULL,
    order_line_key STRING NOT NULL,
    line_qty_status_cnt INT,
    line_status STRING NOT NULL
);

CREATE OR REPLACE TEMP TABLE order_line_status_final (
    order_header_key STRING NOT NULL,
    order_line_key STRING NOT NULL,
    line_status STRING NOT NULL
);

CREATE OR REPLACE TEMP TABLE order_header_status (
    order_header_key STRING NOT NULL, 
    header_status STRING NOT NULL
);

INSERT INTO order_line_status_temp
SELECT *
FROM (
    WITH status_data AS (
        SELECT DISTINCT
            TORS.order_line_key,
            TORS.order_header_key,
            TORS.status,
            TORS.status_quantity
        FROM analytics.txn_order_release_status TORS
        JOIN TRANSFORMED.stg_order_release_status SORS
            ON SORS.order_header_key = TORS.order_header_key
        WHERE TORS.status_quantity > 0.0 
          AND TORS.status NOT IN ('1400', '1400.0', '9000', '9000.0', '1000', '1000.0') --AND SORS.order_header_key = '20250715142028704530216'
    )
    SELECT 
        order_header_key,
        order_line_key,
        COUNT(DISTINCT status) AS line_qty_status_cnt,
        MAX(status) AS line_status
    FROM status_data
    GROUP BY order_header_key, order_line_key
);

-- Step 4: Finalize line status with conditional prefix
INSERT INTO order_line_status_final
SELECT 
    order_header_key,
    order_line_key,
    CASE 
        WHEN line_qty_status_cnt > 1 THEN '_' || line_status
        ELSE line_status
    END AS line_status
FROM order_line_status_temp;

-- Step 5: Generate header status from line-level data
INSERT INTO order_header_status
select * from 
(WITH header_status_data AS (
    SELECT 
        order_header_key,
        MAX(line_qty_status_cnt) AS line_qty_status_cnt,
        MAX(line_status) AS max_line_status,
        COUNT(distinct line_status) distinct_line_status_count
    FROM order_line_status_temp
    GROUP BY order_header_key
)
SELECT 
    order_header_key,
    CASE 
        WHEN distinct_line_status_count > 1 OR line_qty_status_cnt > 1 THEN '_' || max_line_status
        ELSE max_line_status
    END AS header_status
FROM header_status_data);

-- Step 6: Handle fully cancelled lines
INSERT INTO order_line_status_final
select DISTINCT * from
(WITH line_cancelled_status_data AS (
    SELECT 
        TORS.order_header_key, 
        TORS.order_line_key, 
        COUNT(DISTINCT TORS.status) AS status_cnt, 
        COUNT(DISTINCT TORS.status_quantity) AS status_quantity_cnt, 
        MAX(TORS.status) AS max_status
    FROM analytics.txn_order_release_status TORS
    JOIN TRANSFORMED.stg_order_release_status SORS
            ON SORS.order_header_key = TORS.order_header_key
    WHERE TORS.status_quantity > 0.0 AND TORS.status not in('1000', '1000.0') 
    GROUP BY TORS.order_line_key, TORS.order_header_key
)
SELECT 
    order_header_key, 
    order_line_key, 
    max_status  
FROM line_cancelled_status_data
WHERE status_quantity_cnt = 0 AND max_status IN ('9000', '9000.0'));

-- Step 7: Handle fully cancelled headers
INSERT INTO order_header_status
select DISTINCT * from
(WITH header_cancelled_status_data AS (
    SELECT 
        TORS.order_header_key,
        MAX(CASE WHEN TORS.status NOT IN ('1000', '1000.0') THEN TORS.status END) AS max_status,
        COUNT(DISTINCT CASE WHEN TORS.status NOT IN ('1000', '1000.0') THEN TORS.status END) AS status_cnt,
        COUNT(DISTINCT CASE 
                WHEN TORS.status NOT IN ('1000', '1000.0', '9000', '9000.0', '1400') THEN TORS.status 
            END) AS disallowed_status_cnt   
    FROM analytics.txn_order_release_status TORS
    JOIN TRANSFORMED.stg_order_release_status SORS
            ON SORS.order_header_key = TORS.order_header_key
    WHERE TORS.status_quantity > 0.0 AND TORS.status not in('1000', '1000.0')
    GROUP BY TORS.order_header_key
)
 SELECT 
        order_header_key,
        max_status
    FROM header_cancelled_status_data
    WHERE disallowed_status_cnt = 0 AND max_status IN ('9000', '9000.0')
    );



MERGE INTO analytics.txn_order_detail_status_final AS target
USING (
    SELECT DISTINCT
        toh.PK_ORDER_HEADERID AS PK_ORDER_HEADERID,
        tod.PK_ORDER_DETAILID AS PK_ORDER_DETAILID,
        dos.pk_order_statusid AS PK_ORDER_STATUSID
    FROM order_line_status_final olsf
    INNER JOIN analytics.txn_order_header toh
        ON toh.order_header_key = olsf.order_header_key
    INNER JOIN analytics.txn_order_detail tod
        ON tod.order_line_key = olsf.order_line_key
    LEFT JOIN master.dim_order_status dos
        ON dos.oms_order_status_code = olsf.line_status
) AS source
ON target.FK_ORDER_DETAILID = source.PK_ORDER_DETAILID

WHEN MATCHED THEN UPDATE SET
    target.FK_ORDER_HEADERID = source.PK_ORDER_HEADERID,
    target.FK_ORDER_DETAILID = source.PK_ORDER_DETAILID,
    target.FK_ORDER_DETAIL_STATUSID = source.PK_ORDER_STATUSID,
    target.MODIFIED_DATE = CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(9))

WHEN NOT MATCHED THEN INSERT (
    FK_ORDER_HEADERID,
    FK_ORDER_DETAILID,
    FK_ORDER_DETAIL_STATUSID,
    INSERTED_DATE
)
VALUES (
    source.PK_ORDER_HEADERID,
    source.PK_ORDER_DETAILID,
    source.PK_ORDER_STATUSID,
    CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(9))
);




MERGE INTO analytics.txn_order_status_final AS target
USING (
    SELECT DISTINCT
        toh.PK_ORDER_HEADERID AS PK_ORDER_HEADERID,
        toh.FK_SOURCEID AS FK_SOURCEID,
        toh.SOURCE_REF_NUM AS SOURCE_REF_NUM,
        dos.pk_order_statusid AS PK_ORDER_STATUSID,
    FROM order_header_status ohs
    INNER JOIN analytics.txn_order_header toh
        ON toh.order_header_key = ohs.order_header_key
    LEFT JOIN master.dim_order_status dos
        ON dos.oms_order_status_code = ohs.header_status
) AS source
ON target.FK_ORDER_HEADERID = source.PK_ORDER_HEADERID

WHEN MATCHED THEN UPDATE SET
    target.FK_SOURCEID = source.FK_SOURCEID,
    target.FK_ORDER_STATUSID = source.PK_ORDER_STATUSID,
    target.MODIFIED_DATE = CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(9))

WHEN NOT MATCHED THEN INSERT (
    FK_ORDER_HEADERID,
    FK_SOURCEID,
    FK_ORDER_STATUSID,
    INSERTED_DATE
)
VALUES (
    source.PK_ORDER_HEADERID,
    source.FK_SOURCEID,
    source.PK_ORDER_STATUSID,
    CAST(CURRENT_TIMESTAMP() AS TIMESTAMP_NTZ(9))
);


CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'Generate Status',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'Generate Status completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

COMMIT;
RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'Generate Status',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	
	RETURN error_object;
END;
