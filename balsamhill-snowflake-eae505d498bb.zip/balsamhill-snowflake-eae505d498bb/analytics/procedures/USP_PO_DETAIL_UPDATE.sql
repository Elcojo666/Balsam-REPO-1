CREATE OR REPLACE PROCEDURE ANALYTICS.USP_PO_DETAIL_UPDATE (
    pipeline_name STRING
)
RETURNS STRING
LANGUAGE SQL
AS
DECLARE
    created_by INT DEFAULT 1;
    processedCount INT;
    currentDateTime TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP();
    start_time_proc TIMESTAMP_NTZ(9);
    error_object VARIANT;
BEGIN
    BEGIN
        start_time_proc := CURRENT_TIMESTAMP();
        SYSTEM$LOG('TRACE','UPDATE SP STARTED - ' || :pipeline_name);

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'update',
            'STARTED',
            :start_time_proc,
            NULL,
            'update started'
        );

        -- MERGE INTO TXN_PO_HEADER WITH AUDIT
        MERGE INTO  ANALYTICS.TXN_PO_HEADER AS txpo
        USING (
            SELECT
                stg.ID,
                stg.PO_NUMBER,
                stg.SUPPLIERID,
                stg.SEASON_NAME,
                stg.RECEIVING_WAREHOUSE_NAME,
                stg.STATUSID,
                TRY_TO_TIMESTAMP(stg.ETD_SHIPPING_START) AS ETD_SHIPPING_START,
                TRY_TO_TIMESTAMP(stg.ETD_SHIPPING_END) AS ETD_SHIPPING_END,
                TRY_TO_TIMESTAMP(stg.INITIAL_ETA) AS INITIAL_ETA,
                stg.ORIGIN_COUNTRYID,
                stg.DESTINATION_COUNTRYID,
                stg.PO_VALUE,
                stg.SUR_CHARGE,
                stg.AGENTID,
                stg.PAYMENT_TERM,
                TRY_TO_TIMESTAMP(stg.INITIAL_PAYMENT_APPROVED_ON) AS INITIAL_PAYMENT_APPROVED_ON,
                TRY_TO_TIMESTAMP(stg.FINAL_PAYMENT_APPROVED_ON) AS FINAL_PAYMENT_APPROVED_ON,
                stg.NOTES,
                TRY_TO_TIMESTAMP(stg.ETD_SHIPPING_START_DATE) AS ETD_SHIPPING_START_DATE,
                TRY_TO_TIMESTAMP(stg.ETD_SHIPPING_END_DATE) AS ETD_SHIPPING_END_DATE,
                TRY_TO_TIMESTAMP(stg.CONFIRM_ON) AS CONFIRM_ON,
                stg.HBL_BOOKED,
                TRY_TO_TIMESTAMP(stg.SAIL_ON) AS SAIL_ON,
                TRY_TO_TIMESTAMP(stg.FTN_ETA) AS FTN_ETA,
                stg.FTN_ETA_NOTE,
                TRY_TO_TIMESTAMP(stg.ETA_WAREHOUSE_DATE) AS ETA_WAREHOUSE_DATE,
                TRY_TO_TIMESTAMP(stg.ATA_WAREHOUSE_DATE) AS ATA_WAREHOUSE_DATE,
                stg.ORIGIN_PORTID,
                stg.DESTINATION_WAREHOUSE_NAME,
                stg.TOTAL_CONTAINERS,
                stg.ETD,
                TRY_TO_TIMESTAMP(stg.CREATED_ON) AS CREATED_ON,
                stg.CREATED_BY,
                TRY_TO_TIMESTAMP(stg.MODIFIED_ON) AS MODIFIED_ON,
                stg.MODIFIED_BY,
                TRY_TO_TIMESTAMP(stg.VALID_FROM) AS VALID_FROM,
                TRY_TO_TIMESTAMP(stg.VALID_TO) AS VALID_TO,
                stg.NOTE,
                stg.WHO_PAYS,
                stg.QB_VENDOR,
                stg.COMMISSION_PERCENTAGE,
                stg.POTYPE,
                wh.pk_warehouseid AS receiving_id,
                dwh.pk_warehouseid AS destination_id,
                pt.id AS potype_id
            FROM TRANSFORMED.STG_PO_DETAIL stg
            LEFT JOIN MASTER.DIM_WAREHOUSE dwh ON dwh.warehouse_name = stg.destination_warehouse_name
            LEFT JOIN MASTER.DIM_WAREHOUSE wh ON wh.warehouse_name = stg.receiving_warehouse_name
            INNER JOIN MASTER.DIM_PO_TYPE pt ON pt.potypename = stg.potype
        ) AS src
        ON txpo.external_id = src.id
        WHEN MATCHED THEN UPDATE SET
            txpo.fk_receiving_warehouseid = src.receiving_id,
            txpo.fk_po_statusid = src.statusid,
            txpo.amount = src.po_value,
            txpo.po_date = src.CREATED_ON,
            txpo.fk_supplierid = src.supplierid,
            txpo.etd_shipping_start = src.ETD_SHIPPING_START,
            txpo.etd_shipping_end = src.ETD_SHIPPING_END,
            txpo.initial_eta = src.INITIAL_ETA,
            txpo.fk_origin_countryid = src.origin_countryid,
            txpo.fk_destination_countryid = src.destination_countryid,
            txpo.sur_charge = src.sur_charge,
            txpo.fk_agentid = src.agentid,
            txpo.payment_term = src.payment_term,
            txpo.initial_payment_approved_on = src.INITIAL_PAYMENT_APPROVED_ON,
            txpo.final_payment_approved_on = src.FINAL_PAYMENT_APPROVED_ON,
            txpo.notes = src.notes,
            txpo.etd_shipping_start_date = src.ETD_SHIPPING_START_DATE,
            txpo.etd_shipping_end_date = src.ETD_SHIPPING_END_DATE,
            txpo.confirm_on = src.CONFIRM_ON,
            txpo.hbl_booked = src.HBL_BOOKED,
            txpo.sail_on = src.SAIL_ON,
            txpo.ftn_eta = src.FTN_ETA,
            txpo.ftn_eta_note = src.FTN_ETA_NOTE,
            txpo.eta_warehouse_date = src.ETA_WAREHOUSE_DATE,
            txpo.ata_warehouse_date = src.ATA_WAREHOUSE_DATE,
            txpo.fk_destination_warehouseid = src.destination_id,
            txpo.total_containers = src.total_containers,
            txpo.etd = src.etd,
            txpo.created_by = :created_by,
            txpo.modified_date = :currentDateTime,
            txpo.valid_from = src.VALID_FROM,
            txpo.valid_to = src.VALID_TO,
            txpo.fk_portid = src.origin_portid,
            txpo.season_name = src.season_name,
            txpo.note = src.note,
            txpo.commission_percentage = src.commission_percentage,
            txpo.who_pays = src.who_pays,
            txpo.qb_vendor = src.qb_vendor,
            txpo.fk_po_typeid = src.potype_id;

        -- INSERT AUDIT FROM UPDATED table ANALYTICS.TXN_PO_HEADER
		
		INSERT INTO   ANALYTICS.AUDIT_PO_HEADER (
            PK_PO_HEADERID,
            PO_NUMBER,
            FK_RECEIVING_WAREHOUSEID,
            FK_PO_STATUSID,
            AMOUNT,
            PO_DATE,
            EXTERNAL_ID,
            FK_SUPPLIERID,
            ETD_SHIPPING_START,
            ETD_SHIPPING_END,
            INITIAL_ETA,
            FK_ORIGIN_COUNTRYID,
            FK_DESTINATION_COUNTRYID,
            SUR_CHARGE,
            FK_AGENTID,
            PAYMENT_TERM,
            INITIAL_PAYMENT_APPROVED_ON,
            FINAL_PAYMENT_APPROVED_ON,
            NOTES,
            ETD_SHIPPING_START_DATE,
            ETD_SHIPPING_END_DATE,
            CONFIRM_ON,
            HBL_BOOKED,
            SAIL_ON,
            FTN_ETA,
            FTN_ETA_NOTE,
            ETA_WAREHOUSE_DATE,
            ATA_WAREHOUSE_DATE,
            FK_DESTINATION_WAREHOUSEID,
            TOTAL_CONTAINERS,
            ETD,
            CREATED_BY,
            MODIFIED_DATE,
            INSERTED_DATE,
            VALID_FROM,
            VALID_TO,
            FK_PORTID,
            SEASON_NAME,
            NOTE,
            COMMISSION_PERCENTAGE,
            WHO_PAYS,
            QB_VENDOR,
            FK_PO_TYPEID
        )
        SELECT
            PK_PO_HEADERID,
            PO_NUMBER,
            FK_RECEIVING_WAREHOUSEID,
            FK_PO_STATUSID,
            AMOUNT,
            PO_DATE,
            EXTERNAL_ID,
            FK_SUPPLIERID,
            ETD_SHIPPING_START,
            ETD_SHIPPING_END,
            INITIAL_ETA,
            FK_ORIGIN_COUNTRYID,
            FK_DESTINATION_COUNTRYID,
            SUR_CHARGE,
            FK_AGENTID,
            PAYMENT_TERM,
            INITIAL_PAYMENT_APPROVED_ON,
            FINAL_PAYMENT_APPROVED_ON,
            NOTES,
            ETD_SHIPPING_START_DATE,
            ETD_SHIPPING_END_DATE,
            CONFIRM_ON,
            HBL_BOOKED,
            SAIL_ON,
            FTN_ETA,
            FTN_ETA_NOTE,
            ETA_WAREHOUSE_DATE,
            ATA_WAREHOUSE_DATE,
            FK_DESTINATION_WAREHOUSEID,
            TOTAL_CONTAINERS,
            ETD,
            CREATED_BY,
            MODIFIED_DATE,
            --INSERTED_DATE,
            current_timestamp() as INSERTED_DATE,
            VALID_FROM,
            VALID_TO,
            FK_PORTID,
            SEASON_NAME,
            NOTE,
            COMMISSION_PERCENTAGE,
            WHO_PAYS,
            QB_VENDOR,
            FK_PO_TYPEID
        FROM ANALYTICS.TXN_PO_HEADER
        WHERE MODIFIED_DATE = :currentDateTime;

        -- MERGE INTO TXN_PO_DETAIL WITH AUDIT
        MERGE INTO ANALYTICS.TXN_PO_DETAIL AS txnpod
        USING (
            SELECT
                skud.ID,
                skud.PO_NUMBER,
                skud.SKU_CODE,
                skud.SKU_NAME,
                skud.DESCRIPTION,
                skud.QUANTITY_ORDERED,
                skud.QUANTITY_RECEIVED,
                skud.INITIAL_UNIT_PRICE,
                skud.TOTAL_SPEND,
                skud.VARIANCE,
                TRY_TO_TIMESTAMP(skud.RECEIVED_ON) AS RECEIVED_ON,
                skud.NOTES_ON_RECEIPT,
                skud.ATA_TO_WAREHOUSE,
                skud.ION_RECEIPTS,
                TRY_TO_TIMESTAMP(skud.ION_RECEIVE_ON) AS ION_RECEIVE_ON,
                skud.MANUAL_RECEIPTS,
                TRY_TO_TIMESTAMP(skud.MANUAL_RECEIVE_ON) AS MANUAL_RECEIVE_ON,
                skud.HTS_CODE,
                skud.HTS_RATE,
                skud.CBF_PER_UNIT,
                skud.TOTAL_CBF,
                skud.SPEND_BY_QTY_RECEIVED,
                skud.ENTERED_BY_ACCT,
                skud.LANDED_COSTS,
                skud.TOTAL_COSTS_BY_QTY_RECEIVED,
                skud.TOTAL_COMMISSION,
                skud.CATEGORY,
                skud.SUB_CATEGORY,
                skud.PG_LANDED_COST,
                skud.TOTAL_LANDED_COST,
                skud.EXPECTED_SHIP_WEEK,
                skud.WEEK_NO_EXPECTED_ARIVAL,
                TRY_TO_TIMESTAMP(skud.CREATED_ON) AS CREATED_ON,
                skud.CREATED_BY,
                TRY_TO_TIMESTAMP(skud.MODIFIED_ON) AS MODIFIED_ON,
                skud.MODIFIED_BY,
                TRY_TO_TIMESTAMP(skud.VALID_FROM) AS VALID_FROM,
                TRY_TO_TIMESTAMP(skud.VALID_TO) AS VALID_TO,
                skud.BRANDID,
                skud.DISCREPANCYREASON,
                poh.PK_PO_HEADERID,
                dims.PK_SKUPRODUCTID,
                dimu.PK_UPCID AS INNER_UPCID,
                dimup.PK_UPCID AS MASTER_UPCID
            FROM TRANSFORMED.STG_SKU_DETAIL AS skud
            INNER JOIN ANALYTICS.TXN_PO_HEADER AS poh ON poh.PO_NUMBER = skud.PO_NUMBER
            LEFT JOIN ANALYTICS.SKU_PRODUCT AS dims ON dims.SKU_CODE = skud.SKU_CODE
            LEFT JOIN ANALYTICS.UPC AS dimu ON dimu.UPC_CODE = skud.INNER_UPC
            LEFT JOIN ANALYTICS.UPC AS dimup ON dimup.UPC_CODE = skud.MASTER_UPC
        ) AS src
        ON txnpod.external_id = src.ID
        WHEN MATCHED THEN UPDATE SET
            txnpod.fk_po_headerid = src.PK_PO_HEADERID,
            txnpod.fk_skuproductid = src.PK_SKUPRODUCTID,
            txnpod.fk_inner_upcid = src.INNER_UPCID,
            txnpod.fk_master_upcid = src.MASTER_UPCID,
            txnpod.ordered_quantity = src.QUANTITY_ORDERED,
            txnpod.received_quantity = src.QUANTITY_RECEIVED,
            txnpod.sku_name = src.SKU_NAME,
            txnpod.description = src.DESCRIPTION,
            txnpod.initial_unit_price = src.INITIAL_UNIT_PRICE,
            txnpod.total_spend = src.TOTAL_SPEND,
            txnpod.variance = src.VARIANCE,
            txnpod.received_on = src.RECEIVED_ON,
            txnpod.notes_on_receipt = src.NOTES_ON_RECEIPT,
            txnpod.ata_to_warehouse = src.ATA_TO_WAREHOUSE,
            txnpod.ion_receipts = src.ION_RECEIPTS,
            txnpod.ion_receive_on = src.ION_RECEIVE_ON,
            txnpod.manual_receipts = src.MANUAL_RECEIPTS,
            txnpod.manual_receive_on = src.MANUAL_RECEIVE_ON,
            txnpod.hts_code = src.HTS_CODE,
            txnpod.hts_rate = src.HTS_RATE,
            txnpod.cbf_per_unit = src.CBF_PER_UNIT,
            txnpod.total_cbf = src.TOTAL_CBF,
            txnpod.spend_by_qty_received = src.SPEND_BY_QTY_RECEIVED,
            txnpod.entered_by_acct = src.ENTERED_BY_ACCT,
            txnpod.landed_costs = src.LANDED_COSTS,
            txnpod.total_costs_by_qty_received = src.TOTAL_COSTS_BY_QTY_RECEIVED,
            txnpod.total_commission = src.TOTAL_COMMISSION,
            txnpod.category = src.CATEGORY,
            txnpod.sub_category = src.SUB_CATEGORY,
            txnpod.pg_landed_cost = src.PG_LANDED_COST,
            txnpod.total_landed_cost = src.TOTAL_LANDED_COST,
            txnpod.expected_ship_week = src.EXPECTED_SHIP_WEEK,
            txnpod.week_no_expected_arival = src.WEEK_NO_EXPECTED_ARIVAL,
            txnpod.created_by = :created_by,
            txnpod.modified_date = :currentDateTime,
            txnpod.valid_from = src.VALID_FROM,
            txnpod.valid_to = src.VALID_TO,
            txnpod.fk_brandid = src.BRANDID,
            txnpod.discrepancyreason = src.DISCREPANCYREASON;

        -- INSERT AUDIT FROM UPDATED TXN_PO_DETAIL
        INSERT INTO audit_po_detail (
    pk_po_detailid,
    fk_po_headerid,
    fk_skuproductid,
    fk_inner_upcid,
    fk_master_upcid,
    ordered_quantity,
    received_quantity,
    external_id,
    po_number,
    sku_name,
    description,
    initial_unit_price,
    total_spend,
    variance,
    received_on,
    notes_on_receipt,
    ata_to_warehouse,
    ion_receipts,
    ion_receive_on,
    manual_receipts,
    manual_receive_on,
    hts_code,
    hts_rate,
    cbf_per_unit,
    total_cbf,
    spend_by_qty_received,
    entered_by_acct,
    landed_costs,
    total_costs_by_qty_received,
    total_commission,
    category,
    sub_category,
    pg_landed_cost,
    total_landed_cost,
    expected_ship_week,
    week_no_expected_arival,
    created_by,
    modified_date,
    valid_from,
    valid_to,
    fk_brandid,
    inserted_date
)
SELECT
    pk_po_detailid,
    fk_po_headerid,
    fk_skuproductid,
    fk_inner_upcid,
    fk_master_upcid,
    ordered_quantity,
    received_quantity,
    external_id,
    po_number,
    sku_name,
    description,
    initial_unit_price,
    total_spend,
    variance,
    received_on,
    notes_on_receipt,
    ata_to_warehouse,
    ion_receipts,
    ion_receive_on,
    manual_receipts,
    manual_receive_on,
    hts_code,
    hts_rate,
    cbf_per_unit,
    total_cbf,
    spend_by_qty_received,
    entered_by_acct,
    landed_costs,
    total_costs_by_qty_received,
    total_commission,
    category,
    sub_category,
    pg_landed_cost,
    total_landed_cost,
    expected_ship_week,
    week_no_expected_arival,
    created_by,
    modified_date,
    valid_from,
    valid_to,
    fk_brandid,
    current_timestamp()
        FROM ANALYTICS.TXN_PO_DETAIL
        WHERE MODIFIED_DATE = :currentDateTime;

        COMMIT;
        RETURN 'Success';

    EXCEPTION
        WHEN STATEMENT_ERROR THEN
            ROLLBACK;
            error_object := OBJECT_CONSTRUCT(
                'Error type', 'STATEMENT_ERROR',
                'SQLCODE', SQLCODE,
                'SQLERRM', SQLERRM,
                'SQLSTATE', SQLSTATE
            );
            CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
                :pipeline_name,
                'update',
                'FAILED',
                :start_time_proc,
                CURRENT_TIMESTAMP(),
                TO_JSON(:error_object)
            );
            SYSTEM$LOG('ERROR','SP FAILED - ' || :pipeline_name);
            RETURN 'ERROR: ' || SQLERRM;
    END;
END;