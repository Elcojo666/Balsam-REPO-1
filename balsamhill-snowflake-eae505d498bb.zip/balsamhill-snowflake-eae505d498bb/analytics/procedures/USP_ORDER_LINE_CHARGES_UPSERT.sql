CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_LINE_CHARGES_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    createdby NUMBER DEFAULT 1;
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    Counter NUMBER DEFAULT 0;
    processedFeeDetails NUMBER DEFAULT 0;
    processedDiscountDetails NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status
SET processed = :Counter
FROM analytics.log_files_import_status AS lofis
WHERE lofis.file_name = 'YFS_LINE_CHARGES';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );
    

CREATE OR REPLACE TEMPORARY TABLE OrderDetailDiscount (
    line_charges_key VARCHAR(255),
    order_header_key VARCHAR(255),
    ext_line_id VARCHAR(255),
    fk_order_headerid BIGINT,
    fk_order_detailid BIGINT,
    discount_name VARCHAR(255),
    discount_amount DECIMAL(38, 2),
    discount_code VARCHAR(255),
    coupon_code VARCHAR(255),
    charge_type VARCHAR(255),
    discount_rate DECIMAL(38, 2),
    txn_id VARCHAR(255)
);

INSERT INTO OrderDetailDiscount (line_charges_key, order_header_key, ext_line_id, fk_order_headerid, fk_order_detailid, discount_name, discount_amount, discount_code, coupon_code, charge_type, discount_rate, txn_id)
SELECT DISTINCT
    stg.line_charges_key,
    toh.order_header_key,
    tod.ext_line_id,
    toh.pk_order_headerid,
    tod.pk_order_detailid,
    stg.charge_name AS discount_name,
    CAST(stg.chargeamount AS DECIMAL(38, 2)) AS discount_amount,
    stg.extn_charge_description AS discount_code,
    stg.extn_coupon_code AS coupon_code,
    stg.charge_category AS charge_type,
    NULL AS discount_rate,
    stg.txn_id
FROM
    TRANSFORMED.stg_ORDER_line_charges stg
INNER JOIN ANALYTICS.txn_order_header AS toh ON toh.order_header_key = stg.header_key AND toh.entry_type IS NOT NULL
INNER JOIN ANALYTICS.txn_order_detail AS tod ON tod.ext_line_id = stg.line_key AND toh.pk_order_headerid = tod.fk_order_headerid
INNER JOIN master.dim_CHARGECATEGORY AS dc ON dc.charge_category = stg.charge_category AND dc.charge = 'DISCOUNT'
WHERE
    UPPER(dc.charge) = 'DISCOUNT';

CREATE OR REPLACE TEMPORARY TABLE TempDetailDiscounts (
    pk_order_detail_discountid BIGINT NOT NULL,
    fk_order_detailid BIGINT NOT NULL,
    ext_charge_id VARCHAR(510) NOT NULL,
    discount_name VARCHAR,
    discount_amount VARCHAR,
    discount_code VARCHAR,
    coupon_code VARCHAR,
    created_by INT,
    created_date TIMESTAMP,
    modified_date TIMESTAMP,
    Revision INT
);

processedDate := CURRENT_TIMESTAMP();  

MERGE INTO  ANALYTICS.txn_order_detail_discount AS todd
USING (
    SELECT DISTINCT
        orddetaildisc.fk_order_detailid,
        orddetaildisc.discount_name,
        orddetaildisc.discount_code,
        orddetaildisc.discount_amount,
        orddetaildisc.coupon_code,
        orddetaildisc.line_charges_key,
        CURRENT_TIMESTAMP() AS created_date,
        CURRENT_TIMESTAMP() AS modified_date
    FROM OrderDetailDiscount AS orddetaildisc
) AS odd
ON ( todd.fk_order_detailid = odd.fk_order_detailid
AND todd.ext_charge_id = odd.line_charges_key)
WHEN MATCHED THEN
    UPDATE SET
        discount_name = odd.discount_name,
        discount_code = odd.discount_code,
        coupon_code = odd.coupon_code,
        discount_amount = odd.discount_amount,
        modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        fk_order_detailid,
        discount_name,
        discount_code,
        discount_amount,
        coupon_code,
        ext_charge_id,
        inserted_date,
        modified_date
    )
    VALUES (
        odd.fk_order_detailid,
        odd.discount_name,
        odd.discount_code,
        odd.discount_amount,
        odd.coupon_code,
        odd.line_charges_key,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempDetailDiscounts (
    pk_order_detail_discountid,
    fk_order_detailid,
    discount_name,
    discount_code,
    discount_amount,
    coupon_code,
    ext_charge_id,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_detail_discountid,
    fk_order_detailid,
    discount_name,
    discount_code,
    discount_amount,
    coupon_code,
    ext_charge_id,
    :createdby, 
    inserted_date, 
    modified_date, 
    :InitialRevision 
FROM ANALYTICS.txn_order_detail_discount todd 
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;

    
-- Populate revision
-- UPDATE TempDetailDiscounts
-- SET Revision = CAST((aodd.revision + 1 ) AS INT)
-- FROM TempDetailDiscounts AS tdd
-- INNER JOIN (
--     SELECT MAX(aodd.revision) AS revision,
--            aodd.pk_order_detail_discountid,
--            aodd.fk_order_detailid
--     FROM ANALYTICS.audit_order_detail_discount AS aodd
--     INNER JOIN TempDetailDiscounts AS tdd ON tdd.pk_order_detail_discountid = aodd.pk_order_detail_discountid AND tdd.fk_order_detailid = aodd.fk_order_detailid
--     GROUP BY aodd.pk_order_detail_discountid,
--              aodd.fk_order_detailid
-- ) AS aodd ON tdd.pk_order_detail_discountid = aodd.pk_order_detail_discountid AND tdd.fk_order_detailid = aodd.fk_order_detailid;

MERGE INTO TempDetailDiscounts tdd
USING (
    SELECT MAX(aodd.revision) AS revision,
           aodd.pk_order_detail_discountid,
           aodd.fk_order_detailid
    FROM ANALYTICS.audit_order_detail_discount AS aodd
    INNER JOIN TempDetailDiscounts AS tdd 
    ON tdd.pk_order_detail_discountid = aodd.pk_order_detail_discountid 
       AND tdd.fk_order_detailid = aodd.fk_order_detailid
    GROUP BY aodd.pk_order_detail_discountid,
             aodd.fk_order_detailid
) AS aodd
ON tdd.pk_order_detail_discountid = aodd.pk_order_detail_discountid 
   AND tdd.fk_order_detailid = aodd.fk_order_detailid
WHEN MATCHED THEN
    UPDATE SET tdd.Revision = CAST((aodd.revision + 1) AS INT);

INSERT INTO  ANALYTICS.AUDIT_ORDER_DETAIL_DISCOUNT(
    pk_order_detail_discountid,
    fk_order_detailid,
    discount_name,
    discount_code,
    discount_amount,
    created_by,
    created_date,
    modified_date,
    revision,
    coupon_code
)
SELECT
    pk_order_detail_discountid,
    fk_order_detailid,
    discount_name,
    discount_code,
    discount_amount,
    created_by,
    created_date,
    modified_date,
    revision,
    coupon_code
FROM TempDetailDiscounts;

CREATE OR REPLACE TEMPORARY TABLE TempDetailFees(
    pk_order_detail_feeid BIGINT NOT NULL,
    fk_order_detailid BIGINT NOT NULL,
    fee_type STRING NOT NULL,
    ext_charge_id STRING NOT NULL,
    fee_amount FLOAT NULL,
    created_by INT NULL,
    created_date TIMESTAMP NULL,
    modified_date TIMESTAMP NULL,
    Revision INT NULL
);

CREATE OR REPLACE TEMPORARY TABLE OrderDetailFee AS
SELECT DISTINCT
    stg.line_charges_key,
    toh.pk_order_headerid AS fk_order_headerid,
    tod.pk_order_detailid AS fk_order_detailid,
    toh.order_header_key,
    tod.ext_line_id AS ext_line_id,
    CAST(stg.chargeamount AS DECIMAL(38,2)) AS fee_amount,
    stg.charge_name AS fee_type,
    stg.txn_id
FROM
    TRANSFORMED.stg_ORDER_line_charges stg
INNER JOIN
    ANALYTICS.txn_order_header AS toh ON toh.order_header_key = stg.header_key AND toh.entry_type IS NOT NULL
INNER JOIN
    ANALYTICS.txn_order_detail AS tod ON tod.ext_line_id = stg.line_key AND toh.pk_order_headerid = tod.fk_order_headerid
INNER JOIN
    master.dim_CHARGECATEGORY AS dc ON dc.charge_category = stg.charge_category AND dc.charge = 'FEE'
WHERE
    UPPER(dc.charge) IN ('FEE');

processedDate := CURRENT_TIMESTAMP();  
    
MERGE INTO ANALYTICS.txn_order_detail_fee AS todf
USING (
    SELECT DISTINCT
        orddetailfee.fk_order_detailid,
        orddetailfee.fee_type,
        orddetailfee.line_charges_key,
        orddetailfee.fee_amount
    FROM OrderDetailFee AS orddetailfee
) AS odf
ON 
    todf.fk_order_detailid = odf.fk_order_detailid
    AND todf.ext_charge_id = odf.line_charges_key

WHEN MATCHED THEN
    UPDATE SET
        fee_type = odf.fee_type,
        fee_amount = odf.fee_amount,
        modified_date = CURRENT_TIMESTAMP()

WHEN NOT MATCHED THEN
    INSERT (
        fk_order_detailid,
        fee_type,
        fee_amount,
        ext_charge_id,
        inserted_date,
        modified_date
    )
    VALUES (
        odf.fk_order_detailid,
        odf.fee_type,
        odf.fee_amount,
        odf.line_charges_key,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempDetailFees (
    pk_order_detail_feeid,
    fk_order_detailid,
    fee_type,
    fee_amount,
    ext_charge_id,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_detail_feeid,
    fk_order_detailid,
    fee_type,
    fee_amount,
    ext_charge_id,
    :createdby, -- Replace :createdby with the appropriate value for created_by
    inserted_date, -- Gets the current UTC date and time
    modified_date, -- Gets the current UTC date and time
    :InitialRevision -- Replace :InitialRevision with the appropriate value for revision
FROM ANALYTICS.txn_order_detail_fee
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;


--Populate revision
-- UPDATE TempDetailFees
-- SET TempDetailFees.Revision = CAST((aodd.revision + 1 ) as int)
-- FROM TempDetailFees as tdd
-- inner join (SELECT MAX(aodd.revision) as revision,aodd.pk_order_detail_feeid,
-- aodd.fk_order_detailid from  ANALYTICS.audit_order_detail_fee as aodd
-- inner join TempDetailFees as tdd on tdd.pk_order_detail_feeid = aodd.pk_order_detail_feeid and tdd.fk_order_detailid = aodd.fk_order_detailid
-- group by aodd.pk_order_Detail_feeid,
-- aodd.fk_order_detailid) as aodd  on tdd.pk_order_detail_feeid = aodd.pk_order_detail_feeid and tdd.fk_order_detailid = aodd.fk_order_detailid
-- ;

MERGE INTO TempDetailFees tdd
USING (
    SELECT MAX(aodd.revision) AS revision,
           aodd.pk_order_detail_feeid,
           aodd.fk_order_detailid
    FROM ANALYTICS.audit_order_detail_fee AS aodd
    INNER JOIN TempDetailFees AS tdd 
    ON tdd.pk_order_detail_feeid = aodd.pk_order_detail_feeid 
       AND tdd.fk_order_detailid = aodd.fk_order_detailid
    GROUP BY aodd.pk_order_detail_feeid,
             aodd.fk_order_detailid
) AS aodd
ON tdd.pk_order_detail_feeid = aodd.pk_order_detail_feeid 
   AND tdd.fk_order_detailid = aodd.fk_order_detailid
WHEN MATCHED THEN
    UPDATE SET tdd.Revision = CAST((aodd.revision + 1) AS INT);


INSERT INTO audit_order_detail_fee (
    pk_order_detail_feeid,
    fk_order_detailid,
    fee_type,
    fee_amount,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_detail_feeid,
    fk_order_detailid,
    fee_type,
    fee_amount,
    created_by,
    created_date,
    modified_date,
    revision
FROM TempDetailFees;

UPDATE RAW.raw_ORDER_line_charges rolc
SET 
    processing_status = 'Processed',
    processing_comment = '',
    processing_errortype = ''
WHERE EXISTS (
    SELECT 1
    FROM TRANSFORMED.stg_ORDER_line_charges solc
    JOIN OrderDetailFee otd ON solc.line_charges_key = otd.line_charges_key AND solc.line_key = otd.ext_line_id AND solc.txn_id = otd.txn_id
    JOIN TempDetailFees tod ON tod.fk_order_detailid = otd.fk_order_detailid AND tod.fee_type = otd.fee_type
    WHERE 
        rolc.line_charges_key = solc.line_charges_key 
        AND rolc.line_key = solc.line_key 
        AND rolc.txn_id = solc.txn_id 
        AND solc.modifyts = rolc.modifyts
);

UPDATE RAW.raw_ORDER_line_charges rolc
SET 
    rolc.processing_status = 'Processed',
    rolc.processing_comment = '',
    rolc.processing_errortype = ''
WHERE EXISTS (
    SELECT 1
    FROM TRANSFORMED.stg_ORDER_line_charges solc
    JOIN OrderDetailDiscount otd ON solc.line_charges_key = otd.line_charges_key AND solc.line_key = otd.ext_line_id AND solc.txn_id = otd.txn_id
    JOIN TempDetailDiscounts tod ON tod.fk_order_detailid = otd.fk_order_detailid AND tod.ext_charge_id = otd.line_charges_key
    WHERE 
        rolc.line_charges_key = solc.line_charges_key 
        AND rolc.line_key = solc.line_key 
        AND rolc.txn_id = solc.txn_id 
        AND solc.modifyts = rolc.modifyts
);


SELECT
    COUNT(*)
INTO
    :processedFeeDetails
FROM
    TempDetailFees;


SELECT
    COUNT(*)
INTO
    :processedDiscountDetails
FROM
    TempDetailDiscounts;
    
processedRecordCount := processedFeeDetails + processedDiscountDetails
;

UPDATE ANALYTICS.log_files_import_status
SET 
    processed = :processedRecordCount,
    status = 'Success'
FROM ANALYTICS.log_files_import_status AS lofis
WHERE lofis.file_name = 'YFS_LINE_CHARGES';

DROP TABLE IF EXISTS TempDetailFees;
DROP TABLE IF EXISTS TempDetailDiscounts;
DROP TABLE IF EXISTS OrderDetailDiscount;
DROP TABLE IF EXISTS OrderDetailFee;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);
COMMIT;

RETURN 'Success';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_LINE_CHARGES';

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
        
            -- Return error message
    RETURN OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
END;

