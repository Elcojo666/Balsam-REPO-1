USE DATABASE DEV;

CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.SP_UPDATECUSTOMERADDRESSDETAILS("P_PK_CUSTOMERID" NUMBER(38,0), "P_PK_CUSTOMER_ADDRESS_ID" NUMBER(38,0), "P_SOURCEID" NUMBER(38,0), "P_ADDRESS_TYPE" VARCHAR DEFAULT null, "P_ADDRESS_LINE_1" VARCHAR DEFAULT null, "P_ADDRESS_LINE_2" VARCHAR DEFAULT null, "P_ADDRESS_LINE_3" VARCHAR DEFAULT null, "P_ADDRESS_LINE_4" VARCHAR DEFAULT null, "P_CITY" VARCHAR DEFAULT null, "P_STATE" VARCHAR DEFAULT null, "P_POSTAL_CODE" VARCHAR DEFAULT null, "P_COUNTRY_CODE" VARCHAR DEFAULT null, "P_CREATED_BY" VARCHAR DEFAULT null, "P_CREATED_DATE" TIMESTAMP_NTZ(9) DEFAULT null, "P_MODIFIED_BY" VARCHAR DEFAULT null, "P_MODIFIED_DATE" TIMESTAMP_NTZ(9) DEFAULT null, "P_LATITUDE" VARCHAR DEFAULT null, "P_LONGITUDE" VARCHAR DEFAULT null, "P_FIRSTNAME" VARCHAR DEFAULT null, "P_LASTNAME" VARCHAR DEFAULT null, "P_IS_DEFAULT" BOOLEAN DEFAULT null)
COPY GRANTS 
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    pk_customer_info_id   NUMBER;
    message               STRING;
    res                   RESULTSET;
    error_message         STRING;
    sql_code              STRING;
    V_CURRENT_DEFAULT BOOLEAN;
BEGIN
    SYSTEM$LOG(''TRACE'',''SP_UPDATECUSTOMERADDRESSDETAILS has been Started'');

    -------------------------------------------------------------------------
    -- Retrieve the customer info id for the given customer id.
    -------------------------------------------------------------------------
    SELECT PK_CUSTOMER_INFO_ID
      INTO :pk_customer_info_id
    FROM analytics.customer_info
    WHERE FK_CUSTOMERID = :p_pk_customerid;
    
    IF (pk_customer_info_id IS NULL) THEN
        message := ''WARNING: '' || :p_pk_customerid || '' Customer not found'';
        res := (SELECT :message AS MESSAGE,
                       ''Failed'' AS STATUS,
                       NULL AS ID,
                       ''409'' AS STATUSCODE);
        RETURN TABLE(res);
    END IF;
    
    -------------------------------------------------------------------------
    -- Verify that the provided customer address exists for this customer.
    -------------------------------------------------------------------------
   SELECT ca.IS_DEFAULT 
     INTO :V_CURRENT_DEFAULT
   FROM analytics.customer_address ca
   WHERE ca.PK_CUSTOMER_ADDRESS_ID = :p_pk_customer_address_id
     AND ca.FK_CUSTOMER_INFO_ID = :pk_customer_info_id;
    
    
    IF (V_CURRENT_DEFAULT IS NULL) THEN
        message := ''WARNING: '' || p_pk_customerid || '' Customer Address not found'';
        res := (SELECT :message AS MESSAGE,
                       ''Failed'' AS STATUS,
                       NULL AS ID,
                       ''409'' AS STATUSCODE);
        RETURN TABLE(res);
    END IF;
    
    -------------------------------------------------------------------------
    -- If the incoming address is marked as default, update any existing addresses 
    -- for this customer so that they are no longer default.
    -------------------------------------------------------------------------
    IF (p_is_default = TRUE AND NOT(V_CURRENT_DEFAULT)) THEN
        UPDATE analytics.customer_address
           SET is_default = FALSE
        WHERE FK_CUSTOMER_INFO_ID = :pk_customer_info_id
            AND IS_DEFAULT = TRUE 
            AND PK_CUSTOMER_ADDRESS_ID <> :p_pk_customer_address_id
        ;
    END IF;
    
    -------------------------------------------------------------------------
    -- Update the customer address record using the passed-in parameters.
    -------------------------------------------------------------------------
    UPDATE analytics.customer_address
       SET 
           address_type   = COALESCE(:p_address_type, address_type),
           address_line_1 = COALESCE(:p_address_line_1, address_line_1),
           address_line_2 = COALESCE(:p_address_line_2, address_line_2),
           address_line_3 = COALESCE(:p_address_line_3, address_line_3),
           address_line_4 = COALESCE(:p_address_line_4, address_line_4),
           city           = COALESCE(:p_city, city),
           state          = COALESCE(:p_state, state),
           postal_code    = COALESCE(:p_postal_code, postal_code),
           country_code   = COALESCE(:p_country_code, country_code),
           modified_by    = COALESCE(:p_modified_by, modified_by),
           modified_date  = CURRENT_TIMESTAMP(),
           latitude       = COALESCE(:p_latitude, latitude),
           longitude      = COALESCE(:p_longitude, longitude),
           FirstName      = COALESCE(:p_firstName, FirstName),
           LastName       = COALESCE(:p_lastName, LastName),
           is_default     = COALESCE(:p_is_default, is_default)
    WHERE PK_CUSTOMER_ADDRESS_ID = :p_pk_customer_address_id
      ;

      
    message := ''Record Updated'';
    res := (SELECT ''Record Updated'' AS MESSAGE,
                   ''Success'' AS STATUS,
                   CAST(:p_pk_customer_address_id AS STRING) AS ID,
                   ''200'' AS STATUSCODE);
    
    SYSTEM$LOG(''TRACE'',''SP_UPDATECUSTOMERADDRESSDETAILS has been Completed'');
    RETURN TABLE(res);
    
COMMIT;
EXCEPTION
    WHEN statement_error THEN
         ROLLBACK;
         SYSTEM$LOG(''ERROR'',''SP_UPDATECUSTOMERADDRESSDETAILS has been Failed'');
         error_message := sqlerrm;
         sql_code := sqlcode;
         INSERT INTO ANALYTICS.log_microservices_errors (
             microservicesname,  
             methodname,  
             errortime,  
             errormessage,  
             source,  
             exceptiontrace,  
             sql_errornumber,  
             sql_errorstate,  
             sql_errorseverity,  
             sql_errorline,  
             sql_errorprocedure,  
             sql_errormessage
         )
         VALUES (
             ''CustomerApi'',  
             ''UpdateCustomerAddressDetails'',  
             CURRENT_TIMESTAMP(),  
             ''Error in SQL'',  
             :p_SOURCEID,  
             NULL,  
             :sql_code,  
             NULL,  
             NULL,  
             NULL,  
             NULL,  
             :error_message
         );
         res := (SELECT ''Error: '' || :error_message AS MESSAGE,
                         ''Failed'' AS STATUS,
                         NULL AS ID,
                         ''500'' AS STATUSCODE);
         RETURN TABLE(res);
END';
