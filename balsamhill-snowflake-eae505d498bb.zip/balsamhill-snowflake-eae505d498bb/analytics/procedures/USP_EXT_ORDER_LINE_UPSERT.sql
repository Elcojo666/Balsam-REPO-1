CREATE OR REPLACE PROCEDURE ANALYTICS.USP_EXT_ORDER_LINE_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    createdby NUMBER DEFAULT 1;
    action STRING DEFAULT ''CREATE'';
    productTaxType STRING DEFAULT ''PRODUCT'';
    personalizationFeeType STRING DEFAULT ''FEE-PERSONALIZE'';
    domesticSource STRING DEFAULT ''domestic'';
    internationalSource STRING DEFAULT ''international'';
    processedRecordCount BIGINT DEFAULT 0;
    processedDate TIMESTAMP_NTZ(9);
    start_time_proc TIMESTAMP_NTZ(9);
    error_object VARIANT;
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
		CREATE OR REPLACE TEMP TABLE TempExtOrderDEtail (
    order_line_key STRING,
    order_header_key STRING,
    prime_line_no STRING,
    sub_line_no STRING,
    line_type STRING,
    order_class STRING,
    alternate_item_id STRING,
    uom STRING,
    product_class STRING,
    cost_currency STRING,
    basic_capacity_required STRING,
    option_capacity_required STRING,
    dependent_on_line_key STRING,
    current_work_order_key STRING,
    dependency_shipping_rule STRING,
    fill_quantity STRING,
    committed_quantity STRING,
    dependency_ratio STRING,
    maintain_ratio STRING,
    merge_node STRING,
    parent_of_dependent_group STRING,
    source_from_organization STRING,
    chained_from_order_line_key STRING,
    chained_from_order_header_key STRING,
    derived_from_order_line_key STRING,
    derived_from_order_header_key STRING,
    derived_from_order_release_key STRING,
    distribution_rule_id STRING,
    invoiced_quantity STRING,
    over_receipt_quantity STRING,
    return_reason STRING,
    shipnode_key STRING,
    procure_from_node STRING,
    ship_to_key STRING,
    mark_for_key STRING,
    buyer_mark_for_node_id STRING,
    req_delivery_date STRING,
    req_cancel_date STRING,
    req_ship_date STRING,
    scac STRING,
    carrier_service_code STRING,
    carrier_account_no STRING,
    pickable_flag STRING,
    ship_together_no STRING,
    hold_flag STRING,
    kit_code STRING,
    hold_reason_code STRING,
    other_charges STRING,
    invoiced_line_total STRING,
    invoiced_extended_price STRING,
    settled_quantity STRING,
    settled_amount STRING,
    tax_exemption_certificate STRING,
    discount_type STRING,
    discount_reference STRING,
    gift_flag STRING,
    personalize_flag STRING,
    personalize_code STRING,
    department_code STRING,
    customer_item STRING,
    customer_item_description STRING,
    item_weight STRING,
    item_weight_uom STRING,
    item_description STRING,
    item_short_description STRING,
    reservation_id STRING,
    reservation_pool STRING,
    customer_po_no STRING,
    customer_po_line_no STRING,
    tax STRING,
    delivery_code STRING,
    original_ordered_qty STRING,
    list_price STRING,
    retail_price STRING,
    discount_percentage STRING,
    packlist_type STRING,
    supplier_item STRING,
    supplier_item_description STRING,
    unit_cost STRING,
    upc_code STRING,
    fob STRING,
    manufacturer_name STRING,
    manufacturer_item STRING,
    manufacturer_item_desc STRING,
    country_of_origin STRING,
    isbn STRING,
    harmonized_code STRING,
    ship_to_id STRING,
    product_line STRING,
    nmfc_code STRING,
    nmfc_class STRING,
    nmfc_description STRING,
    tax_product_code STRING,
    import_license_no STRING,
    import_license_exp_date STRING,
    eccn_no STRING,
    schedule_b_code STRING,
    supplier_code STRING,
    purpose STRING,
    receiving_node STRING,
    buyer_receiving_node_id STRING,
    shipment_consol_group_id STRING,
    orig_order_line_key STRING,
    line_seq_no STRING,
    split_qty STRING,
    pricing_date STRING,
    pipeline_key STRING,
    condition_variable_1 STRING,
    condition_variable_2 STRING,
    is_price_locked STRING,
    is_cost_overridden STRING,
    is_capacity_overridden STRING,
    invoice_complete STRING,
    delivery_method STRING,
    item_group_code STRING,
    cannot_complete_before_date STRING,
    cannot_complete_after_date STRING,
    appt_status STRING,
    can_add_service_lines STRING,
    pricing_uom STRING,
    capacity_uom STRING,
    pricing_quantity STRING,
    shipped_quantity STRING,
    fixed_capacity_qty_per_line STRING,
    fixed_pricing_qty_per_line STRING,
    wait_for_seq_line STRING,
    sched_failure_reason_code STRING,
    earliest_ship_date STRING,
    earliest_delivery_date STRING,
    cannot_meet_appt STRING,
    promised_appt_start_date STRING,
    promised_appt_end_date STRING,
    segment STRING,
    segment_type STRING,
    earliest_schedule_date STRING,
    timezone STRING,
    is_forwarding_allowed STRING,
    is_procurement_allowed STRING,
    reship_parent_line_key STRING,
    bundle_parent_order_line_key STRING,
    is_price_info_only STRING,
    level_of_service STRING,
    first_iter_seq_no STRING,
    last_iter_seq_no STRING,
    createts STRING,
    modifyts STRING,
    createuserid STRING,
    modifyuserid STRING,
    createprogid STRING,
    modifyprogid STRING,
    lockid STRING,
    ordering_uom STRING,
    pricing_quantity_conv_factor STRING,
    pricing_quantity_strategy STRING,
    invoiced_pricing_quantity STRING,
    is_standalone_service STRING,
    tran_discrepancy_qty STRING,
    received_quantity STRING,
    invoice_based_on_actuals STRING,
    actual_pricing_quantity STRING,
    fulfillment_type STRING,
    serial_no STRING,
    reservation_mandatory STRING,
    is_firm_predefined_node STRING,
    intentional_backorder STRING,
    future_avail_date STRING,
    repricing_quantity STRING,
    min_ship_by_date STRING,
    kit_qty STRING,
    bom_config_key STRING,
    bundle_fulfillment_mode STRING,
    is_gift_wrap STRING,
    group_sequence_num STRING,
    in_store_payment_required STRING,
    item_not_exist STRING,
    derived_from_ext_ord STRING,
    is_eligible_for_ship_disc STRING,
    backorder_notification_qty STRING,
    is_price_matched STRING,
    is_pick_up_now STRING,
    item_is_in_hand STRING,
    disposition_code STRING,
    extn_mod_reason_code STRING,
    extn_mod_reason_desc STRING,
    extn_asn STRING,
    extn_parent_order_no STRING,
    extn_item_id STRING,
    extn_order_item_id STRING,
    extn_price_type STRING,
    extn_secondary_return_reason STRING,
    extn_apply_label_fee STRING,
    extn_is_activation_complete STRING,
    extn_item_desc STRING,
    extn_return_carton_count STRING,
    extn_asn_quantity STRING,
    extn_light_color STRING,
    extn_light_type STRING,
    extn_number_of_sections STRING,
    extn_total_cartons STRING,
    extn_tree_height STRING,
    extn_tree_height_uom STRING,
    extn_apply_restocking_fee STRING,
    extn_return_pickup_date STRING,
    extn_pickup_confirmation_no STRING,
    extn_refund_shipping_cost STRING,
    extn_is_fulfilled_line STRING,
    extn_mfg_warranty_start_date STRING,
    extn_mfg_warranty_end_date STRING,
    extn_term STRING,
    extn_is_invoice_required STRING,
    extn_prem_guarantee_end_date STRING,
    extn_return_date STRING,
    extn_is_email_sent STRING,
    extn_return_required STRING,
    extn_parent_prime_line_no STRING,
    extn_parent_sub_line_no STRING,
    extn_prem_guarantee_start_date STRING,
    extn_reship_upcid STRING,
    extn_parent_order_line_sku STRING,
    unit_price DECIMAL(12, 6),
    line_total DECIMAL(12, 6),
    revision STRING
);

processedDate := CURRENT_TIMESTAMP();

ALTER TABLE analytics.ext_order_detail DROP COLUMN if exists inserted_date;

ALTER TABLE analytics.ext_order_detail ADD COLUMN INSERTED_DATE TIMESTAMP_NTZ;

		MERGE into analytics.ext_order_detail eod USING (
		SELECT stg.order_line_key
			,stg.order_header_key
			,stg.prime_line_no
			,stg.sub_line_no
			,stg.line_type
			,stg.order_class
			,stg.alternate_item_id
			,stg.uom
			,stg.product_class
			,stg.cost_currency
			,stg.basic_capacity_required
			,stg.option_capacity_required
			,stg.dependent_on_line_key
			,stg.current_work_order_key
			,stg.dependency_shipping_rule
			,stg.fill_quantity
			,stg.committed_quantity
			,stg.dependency_ratio
			,stg.maintain_ratio
			,stg.merge_node
			,stg.parent_of_dependent_group
			,stg.source_from_organization
			,stg.chained_from_order_line_key
			,stg.chained_from_order_header_key
			,stg.derived_from_order_line_key
			,stg.derived_from_order_header_key
			,stg.derived_from_order_release_key
			,stg.distribution_rule_id
			,stg.invoiced_quantity
			,stg.over_receipt_quantity
			,stg.return_reason
			,stg.shipnode_key
			,stg.procure_from_node
			,stg.ship_to_key
			,stg.mark_for_key
			,stg.buyer_mark_for_node_id
			,stg.req_delivery_date
			,stg.req_cancel_date
			,stg.req_ship_date
			,stg.scac
			,stg.carrier_service_code
			,stg.carrier_account_no
			,stg.pickable_flag
			,stg.ship_together_no
			,stg.hold_flag
			,stg.kit_code
			,stg.hold_reason_code
			,stg.other_charges
			,stg.invoiced_line_total
			,stg.invoiced_extended_price
			,stg.settled_quantity
			,stg.settled_amount
			,stg.tax_exemption_certificate
			,stg.discount_type
			,stg.discount_reference
			,stg.gift_flag
			,stg.personalize_flag
			,stg.personalize_code
			,stg.department_code
			,stg.customer_item
			,stg.customer_item_description
			,stg.item_weight
			,stg.item_weight_uom
			,stg.item_description
			,stg.item_short_description
			,stg.reservation_id
			,stg.reservation_pool
			,stg.customer_po_no
			,stg.customer_po_line_no
			,stg.tax
			,stg.delivery_code
			,stg.original_ordered_qty
			,stg.list_price
			,stg.retail_price
			,stg.discount_percentage
			,stg.packlist_type
			,stg.supplier_item
			,stg.supplier_item_description
			,stg.unit_cost
			,stg.upc_code
			,stg.fob
			,stg.manufacturer_name
			,stg.manufacturer_item
			,stg.manufacturer_item_desc
			,stg.country_of_origin
			,stg.isbn
			,stg.harmonized_code
			,stg.ship_to_id
			,stg.product_line
			,stg.nmfc_code
			,stg.nmfc_class
			,stg.nmfc_description
			,stg.tax_product_code
			,stg.import_license_no
			,stg.import_license_exp_date
			,stg.eccn_no
			,stg.schedule_b_code
			,stg.supplier_code
			,stg.purpose
			,stg.receiving_node
			,stg.buyer_receiving_node_id
			,stg.shipment_consol_group_id
			,stg.orig_order_line_key
			,stg.line_seq_no
			,stg.split_qty
			,stg.pricing_date
			,stg.pipeline_key
			,stg.condition_variable_1
			,stg.condition_variable_2
			,stg.is_price_locked
			,stg.is_cost_overridden
			,stg.is_capacity_overridden
			,stg.invoice_complete
			,stg.delivery_method
			,stg.item_group_code
			,stg.cannot_complete_before_date
			,stg.cannot_complete_after_date
			,stg.appt_status
			,stg.can_add_service_lines
			,stg.pricing_uom
			,stg.capacity_uom
			,stg.pricing_quantity
			,stg.shipped_quantity
			,stg.fixed_capacity_qty_per_line
			,stg.fixed_pricing_qty_per_line
			,stg.wait_for_seq_line
			,stg.sched_failure_reason_code
			,stg.earliest_ship_date
			,stg.earliest_delivery_date
			,stg.cannot_meet_appt
			,stg.promised_appt_start_date
			,stg.promised_appt_end_date
			,stg.segment
			,stg.segment_type
			,stg.earliest_schedule_date
			,stg.timezone
			,stg.is_forwarding_allowed
			,stg.is_procurement_allowed
			,stg.reship_parent_line_key
			,stg.bundle_parent_order_line_key
			,stg.is_price_info_only
			,stg.level_of_service
			,stg.first_iter_seq_no
			,stg.last_iter_seq_no
			,stg.createts
			,stg.modifyts
			,stg.createuserid
			,stg.modifyuserid
			,stg.createprogid
			,stg.modifyprogid
			,stg.lockid
			,stg.ordering_uom
			,stg.pricing_quantity_conv_factor
			,stg.pricing_quantity_strategy
			,stg.invoiced_pricing_quantity
			,stg.is_standalone_service
			,stg.tran_discrepancy_qty
			,stg.received_quantity
			,stg.invoice_based_on_actuals
			,stg.actual_pricing_quantity
			,stg.fulfillment_type
			,stg.serial_no
			,stg.reservation_mandatory
			,stg.is_firm_predefined_node
			,stg.intentional_backorder
			,stg.future_avail_date
			,stg.repricing_quantity
			,stg.min_ship_by_date
			,stg.kit_qty
			,stg.bom_config_key
			,stg.bundle_fulfillment_mode
			,stg.is_gift_wrap
			,stg.group_sequence_num
			,stg.in_store_payment_required
			,stg.item_not_exist
			,stg.derived_from_ext_ord
			,stg.is_eligible_for_ship_disc
			,stg.backorder_notification_qty
			,stg.is_price_matched
			,stg.is_pick_up_now
			,stg.item_is_in_hand
			,stg.disposition_code
			,stg.extn_mod_reason_code
			,stg.extn_mod_reason_desc
			,stg.extn_asn
			,stg.extn_parent_order_no
			,stg.extn_item_id
			,stg.extn_order_item_id
			,stg.extn_price_type
		    ,stg.extn_secondary_return_reason
			,stg.extn_apply_label_fee
			,stg.extn_is_activation_complete
			,stg.extn_item_desc
			,stg.extn_return_carton_count
			,stg.extn_asn_quantity
			,stg.extn_light_color
			,stg.extn_light_type
			,stg.extn_number_of_sections
			,stg.extn_total_cartons
			,stg.extn_tree_height
			,stg.extn_tree_height_uom
			,stg.extn_apply_restocking_fee
			,stg.extn_return_pickup_date
			,stg.extn_pickup_confirmation_no
			,stg.extn_refund_shipping_cost
			,stg.extn_is_fulfilled_line
			,stg.extn_mfg_warranty_start_date
			,stg.extn_mfg_warranty_end_date
			,stg.extn_term
			,stg.extn_is_invoice_required
			,stg.extn_prem_guarantee_end_date
			,stg.extn_return_date
			,stg.extn_is_email_sent
			,stg.extn_return_required
			,stg.extn_parent_prime_line_no
			,stg.extn_parent_sub_line_no
			,stg.extn_prem_guarantee_start_date
			,stg.extn_reship_upcid
			,stg.extn_parent_order_line_sku 
			,stg.unit_price
			,stg.line_total
			,CURRENT_TIMESTAMP()
			from transformed.stg_order_line stg	
			inner join raw.raw_order_line r
				on stg.order_header_key = r.order_header_key AND
					stg.order_line_key = r.order_line_key AND
					r.modifyts = stg.modifyts and
					r.processing_status = ''Processed''
		 ) sod
		 ON (
			eod.order_header_key = sod.order_header_key AND
			eod.order_line_key = sod.order_line_key
		 )
		 WHEN MATCHED THEN
		UPDATE
		SET 
			eod.order_line_key=sod.order_line_key
			,eod.order_header_key=sod.order_header_key
			,eod.prime_line_no=sod.prime_line_no
			,eod.sub_line_no=sod.sub_line_no
			,eod.line_type=sod.line_type
			,eod.order_class=sod.order_class
			,eod.alternate_item_id=sod.alternate_item_id
			,eod.uom=sod.uom
			,eod.product_class=sod.product_class
			,eod.cost_currency=sod.cost_currency
			,eod.basic_capacity_required=sod.basic_capacity_required
			,eod.option_capacity_required=sod.option_capacity_required
			,eod.dependent_on_line_key=sod.dependent_on_line_key
			,eod.current_work_order_key=sod.current_work_order_key
			,eod.dependency_shipping_rule=sod.dependency_shipping_rule
			,eod.fill_quantity=sod.fill_quantity
			,eod.committed_quantity=sod.committed_quantity
			,eod.dependency_ratio=sod.dependency_ratio
			,eod.maintain_ratio=sod.maintain_ratio
			,eod.merge_node=sod.merge_node
			,eod.parent_of_dependent_group=sod.parent_of_dependent_group
			,eod.source_from_organization=sod.source_from_organization
			,eod.chained_from_order_line_key=sod.chained_from_order_line_key
			,eod.chained_from_order_header_key=sod.chained_from_order_header_key
			,eod.derived_from_order_line_key=sod.derived_from_order_line_key
			,eod.derived_from_order_header_key=sod.derived_from_order_header_key
			,eod.derived_from_order_release_key=sod.derived_from_order_release_key
			,eod.distribution_rule_id=sod.distribution_rule_id
			,eod.invoiced_quantity=sod.invoiced_quantity
			,eod.over_receipt_quantity=sod.over_receipt_quantity
			,eod.return_reason=sod.return_reason
			,eod.shipnode_key=sod.shipnode_key
			,eod.procure_from_node=sod.procure_from_node
			,eod.ship_to_key=sod.ship_to_key
			,eod.mark_for_key=sod.mark_for_key
			,eod.buyer_mark_for_node_id=sod.buyer_mark_for_node_id
			,eod.req_delivery_date= TRY_TO_TIMESTAMP(sod.req_delivery_date,''YYYYMMDDHHMISS'')
			,eod.req_cancel_date=TRY_TO_TIMESTAMP(sod.req_cancel_date,''YYYYMMDDHHMISS'')
			,eod.req_ship_date=TRY_TO_TIMESTAMP(sod.req_ship_date,''YYYYMMDDHHMISS'')
			,eod.scac=sod.scac
			,eod.carrier_service_code=sod.carrier_service_code
			,eod.carrier_account_no=sod.carrier_account_no
			,eod.pickable_flag=sod.pickable_flag
			,eod.ship_together_no=sod.ship_together_no
			,eod.hold_flag=sod.hold_flag
			,eod.kit_code=sod.kit_code
			,eod.hold_reason_code=sod.hold_reason_code
			,eod.other_charges=sod.other_charges
			,eod.invoiced_line_total= try_cast( sod.invoiced_line_total as float)  
			,eod.invoiced_extended_price= try_cast( sod.invoiced_extended_price as float)  
			,eod.settled_quantity=sod.settled_quantity
			,eod.settled_amount=sod.settled_amount
			,eod.tax_exemption_certificate=sod.tax_exemption_certificate
			,eod.discount_type=sod.discount_type
			,eod.discount_reference=sod.discount_reference
			,eod.gift_flag=sod.gift_flag
			,eod.personalize_flag=sod.personalize_flag
			,eod.personalize_code=sod.personalize_code
			,eod.department_code=sod.department_code
			,eod.customer_item=sod.customer_item
			,eod.customer_item_description=sod.customer_item_description
			,eod.item_weight=sod.item_weight
			,eod.item_weight_uom=sod.item_weight_uom
			,eod.item_description=sod.item_description
			,eod.item_short_description=sod.item_short_description
			,eod.reservation_id=sod.reservation_id
			,eod.reservation_pool=sod.reservation_pool
			,eod.customer_po_no=sod.customer_po_no
			,eod.customer_po_line_no=sod.customer_po_line_no
			,eod.tax=sod.tax
			,eod.delivery_code=sod.delivery_code
			,eod.original_ordered_qty=sod.original_ordered_qty
			,eod.list_price= try_cast(sod.list_price as float)  
			,eod.retail_price= try_cast(sod.retail_price as float)  
			,eod.discount_percentage=sod.discount_percentage
			,eod.packlist_type=sod.packlist_type
			,eod.supplier_item=sod.supplier_item
			,eod.supplier_item_description=sod.supplier_item_description
			,eod.unit_cost=sod.unit_cost
			,eod.upc_code=sod.upc_code
			,eod.fob=sod.fob
			,eod.manufacturer_name=sod.manufacturer_name
			,eod.manufacturer_item=sod.manufacturer_item
			,eod.manufacturer_item_desc=sod.manufacturer_item_desc
			,eod.country_of_origin=sod.country_of_origin
			,eod.isbn=sod.isbn
			,eod.harmonized_code=sod.harmonized_code
			,eod.ship_to_id=sod.ship_to_id
			,eod.product_line=sod.product_line
			,eod.nmfc_code=sod.nmfc_code
			,eod.nmfc_class=sod.nmfc_class
			,eod.nmfc_description=sod.nmfc_description
			,eod.tax_product_code=sod.tax_product_code
			,eod.import_license_no=sod.import_license_no
			,eod.import_license_exp_date=TRY_TO_TIMESTAMP(sod.import_license_exp_date,''YYYYMMDDHHMISS'')
			,eod.eccn_no=sod.eccn_no
			,eod.schedule_b_code=sod.schedule_b_code
			,eod.supplier_code=sod.supplier_code
			,eod.purpose=sod.purpose
			,eod.receiving_node=sod.receiving_node
			,eod.buyer_receiving_node_id=sod.buyer_receiving_node_id
			,eod.shipment_consol_group_id=sod.shipment_consol_group_id
			,eod.orig_order_line_key=sod.orig_order_line_key
			,eod.line_seq_no=sod.line_seq_no
			,eod.split_qty=sod.split_qty
			,eod.pricing_date=TRY_TO_TIMESTAMP(sod.pricing_date,''YYYYMMDDHHMISS'')
			,eod.pipeline_key=sod.pipeline_key
			,eod.condition_variable_1=sod.condition_variable_1
			,eod.condition_variable_2=sod.condition_variable_2
			,eod.is_price_locked=sod.is_price_locked
			,eod.is_cost_overridden=sod.is_cost_overridden
			,eod.is_capacity_overridden=sod.is_capacity_overridden
			,eod.invoice_complete=sod.invoice_complete
			,eod.delivery_method=sod.delivery_method
			,eod.item_group_code=sod.item_group_code
			,eod.cannot_complete_before_date=TRY_TO_TIMESTAMP(sod.cannot_complete_before_date,''YYYYMMDDHHMISS'')
			,eod.cannot_complete_after_date=TRY_TO_TIMESTAMP(sod.cannot_complete_after_date,''YYYYMMDDHHMISS'')
			,eod.appt_status=sod.appt_status
			,eod.can_add_service_lines=sod.can_add_service_lines
			,eod.pricing_uom=sod.pricing_uom
			,eod.capacity_uom=sod.capacity_uom
			,eod.pricing_quantity=sod.pricing_quantity
			,eod.shipped_quantity=sod.shipped_quantity
			,eod.fixed_capacity_qty_per_line=sod.fixed_capacity_qty_per_line
			,eod.fixed_pricing_qty_per_line=sod.fixed_pricing_qty_per_line
			,eod.wait_for_seq_line=sod.wait_for_seq_line
			,eod.sched_failure_reason_code=sod.sched_failure_reason_code
			,eod.earliest_ship_date=TRY_TO_TIMESTAMP(sod.earliest_ship_date,''YYYYMMDDHHMISS'')
			,eod.earliest_delivery_date=TRY_TO_TIMESTAMP(sod.earliest_delivery_date,''YYYYMMDDHHMISS'')
			,eod.cannot_meet_appt=sod.cannot_meet_appt
			,eod.promised_appt_start_date=TRY_TO_TIMESTAMP(sod.promised_appt_start_date,''YYYYMMDDHHMISS'')
			,eod.promised_appt_end_date=TRY_TO_TIMESTAMP(sod.promised_appt_end_date,''YYYYMMDDHHMISS'')
			,eod.segment=sod.segment
			,eod.segment_type=sod.segment_type
			,eod.earliest_schedule_date=TRY_TO_TIMESTAMP(sod.earliest_schedule_date,''YYYYMMDDHHMISS'')
			,eod.timezone=sod.timezone
			,eod.is_forwarding_allowed=sod.is_forwarding_allowed
			,eod.is_procurement_allowed=sod.is_procurement_allowed
			,eod.reship_parent_line_key=sod.reship_parent_line_key
			,eod.bundle_parent_order_line_key=sod.bundle_parent_order_line_key
			,eod.is_price_info_only=sod.is_price_info_only
			,eod.level_of_service=sod.level_of_service
			,eod.first_iter_seq_no=sod.first_iter_seq_no
			,eod.last_iter_seq_no=sod.last_iter_seq_no
			,eod.createts=TRY_TO_TIMESTAMP(sod.createts,''YYYYMMDDHHMISS'')
			,eod.modifyts=TRY_TO_TIMESTAMP(sod.modifyts,''YYYYMMDDHHMISS'')
			,eod.createuserid=sod.createuserid
			,eod.modifyuserid=sod.modifyuserid
			,eod.createprogid=sod.createprogid
			,eod.modifyprogid=sod.modifyprogid
			,eod.lockid=sod.lockid
			,eod.ordering_uom=sod.ordering_uom
			,eod.pricing_quantity_conv_factor=sod.pricing_quantity_conv_factor
			,eod.pricing_quantity_strategy=sod.pricing_quantity_strategy
			,eod.invoiced_pricing_quantity=sod.invoiced_pricing_quantity
			,eod.is_standalone_service=sod.is_standalone_service
			,eod.tran_discrepancy_qty=sod.tran_discrepancy_qty
			,eod.received_quantity=sod.received_quantity
			,eod.invoice_based_on_actuals=sod.invoice_based_on_actuals
			,eod.actual_pricing_quantity=sod.actual_pricing_quantity
			,eod.fulfillment_type=sod.fulfillment_type
			,eod.serial_no=sod.serial_no
			,eod.reservation_mandatory=sod.reservation_mandatory
			,eod.is_firm_predefined_node=sod.is_firm_predefined_node
			,eod.intentional_backorder=sod.intentional_backorder
			,eod.future_avail_date=TRY_TO_TIMESTAMP(sod.future_avail_date,''YYYYMMDDHHMISS'')
			,eod.repricing_quantity=sod.repricing_quantity
			,eod.min_ship_by_date=TRY_TO_TIMESTAMP(sod.min_ship_by_date,''YYYYMMDDHHMISS'')
			,eod.kit_qty=sod.kit_qty
			,eod.bom_config_key=sod.bom_config_key
			,eod.bundle_fulfillment_mode=sod.bundle_fulfillment_mode
			,eod.is_gift_wrap=sod.is_gift_wrap
			,eod.group_sequence_num=sod.group_sequence_num
			,eod.in_store_payment_required=sod.in_store_payment_required
			,eod.item_not_exist=sod.item_not_exist
			,eod.derived_from_ext_ord=sod.derived_from_ext_ord
			,eod.is_eligible_for_ship_disc=sod.is_eligible_for_ship_disc
			,eod.backorder_notification_qty=sod.backorder_notification_qty
			,eod.is_price_matched=sod.is_price_matched
			,eod.is_pick_up_now=sod.is_pick_up_now
			,eod.item_is_in_hand=sod.item_is_in_hand
			,eod.disposition_code=sod.disposition_code
			,eod.extn_mod_reason_code=sod.extn_mod_reason_code
			,eod.extn_mod_reason_desc=sod.extn_mod_reason_desc
			,eod.extn_asn=sod.extn_asn
			,eod.extn_parent_order_no=sod.extn_parent_order_no
			,eod.extn_item_id=sod.extn_item_id
			,eod.extn_order_item_id=sod.extn_order_item_id
			,eod.extn_price_type=sod.extn_price_type
			,eod.extn_secondary_return_reason=sod.extn_secondary_return_reason
			,eod.extn_apply_label_fee=sod.extn_apply_label_fee
			,eod.extn_is_activation_complete=sod.extn_is_activation_complete
			,eod.extn_item_desc=sod.extn_item_desc
			,eod.extn_return_carton_count=sod.extn_return_carton_count
			,eod.extn_asn_quantity=sod.extn_asn_quantity
			,eod.extn_light_color=sod.extn_light_color
			,eod.extn_light_type=sod.extn_light_type
			,eod.extn_number_of_sections=sod.extn_number_of_sections
			,eod.extn_total_cartons=sod.extn_total_cartons
			,eod.extn_tree_height=sod.extn_tree_height
			,eod.extn_tree_height_uom=sod.extn_tree_height_uom
			,eod.extn_apply_restocking_fee=sod.extn_apply_restocking_fee
			,eod.extn_return_pickup_date=TRY_TO_TIMESTAMP(sod.extn_return_pickup_date,''YYYYMMDDHHMISS'')
			,eod.extn_pickup_confirmation_no=sod.extn_pickup_confirmation_no
			,eod.extn_refund_shipping_cost=sod.extn_refund_shipping_cost
			,eod.extn_is_fulfilled_line=sod.extn_is_fulfilled_line
			,eod.extn_mfg_warranty_start_date=TRY_TO_TIMESTAMP(sod.extn_mfg_warranty_start_date,''YYYYMMDDHHMISS'')
			,eod.extn_mfg_warranty_end_date=TRY_TO_TIMESTAMP(sod.extn_mfg_warranty_end_date,''YYYYMMDDHHMISS'')
			,eod.extn_term=sod.extn_term
			,eod.extn_is_invoice_required=sod.extn_is_invoice_required
			,eod.extn_prem_guarantee_end_date=TRY_TO_TIMESTAMP(sod.extn_prem_guarantee_end_date,''YYYYMMDDHHMISS'')
			,eod.extn_return_date=TRY_TO_TIMESTAMP(sod.extn_return_date,''YYYYMMDDHHMISS'')
			,eod.extn_is_email_sent=sod.extn_is_email_sent
			,eod.extn_return_required=sod.extn_return_required
			,eod.extn_parent_prime_line_no=sod.extn_parent_prime_line_no
			,eod.extn_parent_sub_line_no=sod.extn_parent_sub_line_no
			,eod.extn_prem_guarantee_start_date=TRY_TO_TIMESTAMP(sod.extn_prem_guarantee_start_date,''YYYYMMDDHHMISS'')
			,eod.extn_reship_upcid=sod.extn_reship_upcid
            ,eod.extn_parent_order_line_sku=sod.extn_parent_order_line_sku
			,eod.unit_price=sod.unit_price
            ,eod.line_total=sod.line_total
			,eod.INSERTED_DATE= current_timestamp()

		WHEN NOT MATCHED 
		THEN
			INSERT              
			(
				order_line_key
				,order_header_key
				,prime_line_no
				,sub_line_no
				,line_type
				,order_class
				,alternate_item_id
				,uom
				,product_class
				,cost_currency
				,basic_capacity_required
				,option_capacity_required
				,dependent_on_line_key
				,current_work_order_key
				,dependency_shipping_rule
				,fill_quantity
				,committed_quantity
				,dependency_ratio
				,maintain_ratio
				,merge_node
				,parent_of_dependent_group
				,source_from_organization
				,chained_from_order_line_key
				,chained_from_order_header_key
				,derived_from_order_line_key
				,derived_from_order_header_key
				,derived_from_order_release_key
				,distribution_rule_id
				,invoiced_quantity
				,over_receipt_quantity
				,return_reason
				,shipnode_key
				,procure_from_node
				,ship_to_key
				,mark_for_key
				,buyer_mark_for_node_id
				,req_delivery_date
				,req_cancel_date
				,req_ship_date
				,scac
				,carrier_service_code
				,carrier_account_no
				,pickable_flag
				,ship_together_no
				,hold_flag
				,kit_code
				,hold_reason_code
				,other_charges
				,invoiced_line_total
				,invoiced_extended_price
				,settled_quantity
				,settled_amount
				,tax_exemption_certificate
				,discount_type
				,discount_reference
				,gift_flag
				,personalize_flag
				,personalize_code
				,department_code
				,customer_item
				,customer_item_description
				,item_weight
				,item_weight_uom
				,item_description
				,item_short_description
				,reservation_id
				,reservation_pool
				,customer_po_no
				,customer_po_line_no
				,tax
				,delivery_code
				,original_ordered_qty
				,list_price
				,retail_price
				,discount_percentage
				,packlist_type
				,supplier_item
				,supplier_item_description
				,unit_cost
				,upc_code
				,fob
				,manufacturer_name
				,manufacturer_item
				,manufacturer_item_desc
				,country_of_origin
				,isbn
				,harmonized_code
				,ship_to_id
				,product_line
				,nmfc_code
				,nmfc_class
				,nmfc_description
				,tax_product_code
				,import_license_no
				,import_license_exp_date
				,eccn_no
				,schedule_b_code
				,supplier_code
				,purpose
				,receiving_node
				,buyer_receiving_node_id
				,shipment_consol_group_id
				,orig_order_line_key
				,line_seq_no
				,split_qty
				,pricing_date
				,pipeline_key
				,condition_variable_1
				,condition_variable_2
				,is_price_locked
				,is_cost_overridden
				,is_capacity_overridden
				,invoice_complete
				,delivery_method
				,item_group_code
				,cannot_complete_before_date
				,cannot_complete_after_date
				,appt_status
				,can_add_service_lines
				,pricing_uom
				,capacity_uom
				,pricing_quantity
				,shipped_quantity
				,fixed_capacity_qty_per_line
				,fixed_pricing_qty_per_line
				,wait_for_seq_line
				,sched_failure_reason_code
				,earliest_ship_date
				,earliest_delivery_date
				,cannot_meet_appt
				,promised_appt_start_date
				,promised_appt_end_date
				,segment
				,segment_type
				,earliest_schedule_date
				,timezone
				,is_forwarding_allowed
				,is_procurement_allowed
				,reship_parent_line_key
				,bundle_parent_order_line_key
				,is_price_info_only
				,level_of_service
				,first_iter_seq_no
				,last_iter_seq_no
				,createts
				,modifyts
				,createuserid
				,modifyuserid
				,createprogid
				,modifyprogid
				,lockid
				,ordering_uom
				,pricing_quantity_conv_factor
				,pricing_quantity_strategy
				,invoiced_pricing_quantity
				,is_standalone_service
				,tran_discrepancy_qty
				,received_quantity
				,invoice_based_on_actuals
				,actual_pricing_quantity
				,fulfillment_type
				,serial_no
				,reservation_mandatory
				,is_firm_predefined_node
				,intentional_backorder
				,future_avail_date
				,repricing_quantity
				,min_ship_by_date
				,kit_qty
				,bom_config_key
				,bundle_fulfillment_mode
				,is_gift_wrap
				,group_sequence_num
				,in_store_payment_required
				,item_not_exist
				,derived_from_ext_ord
				,is_eligible_for_ship_disc
				,backorder_notification_qty
				,is_price_matched
				,is_pick_up_now
				,item_is_in_hand
				,disposition_code
				,extn_mod_reason_code
				,extn_mod_reason_desc
				,extn_asn
				,extn_parent_order_no
				,extn_item_id
				,extn_order_item_id
				,extn_price_type
				,extn_secondary_return_reason
				,extn_apply_label_fee
				,extn_is_activation_complete
				,extn_item_desc
				,extn_return_carton_count
				,extn_asn_quantity
				,extn_light_color
				,extn_light_type
				,extn_number_of_sections
				,extn_total_cartons
				,extn_tree_height
				,extn_tree_height_uom
				,extn_apply_restocking_fee
				,extn_return_pickup_date
				,extn_pickup_confirmation_no
				,extn_refund_shipping_cost
				,extn_is_fulfilled_line
				,extn_mfg_warranty_start_date
				,extn_mfg_warranty_end_date
				,extn_term
				,extn_is_invoice_required
				,extn_prem_guarantee_end_date
				,extn_return_date
				,extn_is_email_sent
				,extn_return_required
				,extn_parent_prime_line_no
				,extn_parent_sub_line_no
				,extn_prem_guarantee_start_date
				,extn_reship_upcid
				,extn_parent_order_line_sku
				,unit_price
				,line_total
				,INSERTED_DATE

				)
			VALUES
			(
				order_line_key
				,order_header_key
				,prime_line_no
				,sub_line_no
				,line_type
				,order_class
				,alternate_item_id
				,uom
				,product_class
				,cost_currency
				,basic_capacity_required
				,option_capacity_required
				,dependent_on_line_key
				,current_work_order_key
				,dependency_shipping_rule
				,fill_quantity
				,committed_quantity
				,dependency_ratio
				,maintain_ratio
				,merge_node
				,parent_of_dependent_group
				,source_from_organization
				,chained_from_order_line_key
				,chained_from_order_header_key
				,derived_from_order_line_key
				,derived_from_order_header_key
				,derived_from_order_release_key
				,distribution_rule_id
				,invoiced_quantity
				,over_receipt_quantity
				,return_reason
				,shipnode_key
				,procure_from_node
				,ship_to_key
				,mark_for_key
				,buyer_mark_for_node_id
				,TRY_TO_TIMESTAMP(req_delivery_date,''YYYYMMDDHHMISS'')
				,TRY_TO_TIMESTAMP(req_cancel_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(req_ship_date,''YYYYMMDDHHMISS'')
				,scac
				,carrier_service_code
				,carrier_account_no
				,pickable_flag
				,ship_together_no
				,hold_flag
				,kit_code
				,hold_reason_code
				,other_charges
				, try_cast(invoiced_line_total as float)
				, try_cast(invoiced_extended_price as float)
				,settled_quantity
				,settled_amount
				,tax_exemption_certificate
				,discount_type
				,discount_reference
				,gift_flag
				,personalize_flag
				,personalize_code
				,department_code
				,customer_item
				,customer_item_description
				,item_weight
				,item_weight_uom
				,item_description
				,item_short_description
				,reservation_id
				,reservation_pool
				,customer_po_no
				,customer_po_line_no
				,tax
				,delivery_code
				,original_ordered_qty
				, try_cast(list_price as float)
				, try_cast(retail_price as float)
				,discount_percentage
				,packlist_type
				,supplier_item
				,supplier_item_description
				,unit_cost
				,upc_code
				,fob
				,manufacturer_name
				,manufacturer_item
				,manufacturer_item_desc
				,country_of_origin
				,isbn
				,harmonized_code
				,ship_to_id
				,product_line
				,nmfc_code
				,nmfc_class
				,nmfc_description
				,tax_product_code
				,import_license_no
				, TRY_TO_TIMESTAMP(import_license_exp_date,''YYYYMMDDHHMISS'')
				,eccn_no
				,schedule_b_code
				,supplier_code
				,purpose
				,receiving_node
				,buyer_receiving_node_id
				,shipment_consol_group_id
				,orig_order_line_key
				,line_seq_no
				,split_qty
				, TRY_TO_TIMESTAMP(pricing_date,''YYYYMMDDHHMISS'')
				,pipeline_key
				,condition_variable_1
				,condition_variable_2
				,is_price_locked
				,is_cost_overridden
				,is_capacity_overridden
				,invoice_complete
				,delivery_method
				,item_group_code
				, TRY_TO_TIMESTAMP(cannot_complete_before_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(cannot_complete_after_date,''YYYYMMDDHHMISS'')
				,appt_status
				,can_add_service_lines
				,pricing_uom
				,capacity_uom
				,pricing_quantity
				,shipped_quantity
				,fixed_capacity_qty_per_line
				,fixed_pricing_qty_per_line
				,wait_for_seq_line
				,sched_failure_reason_code
				, TRY_TO_TIMESTAMP(earliest_ship_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(earliest_delivery_date,''YYYYMMDDHHMISS'')
				,cannot_meet_appt
				, TRY_TO_TIMESTAMP(promised_appt_start_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(promised_appt_end_date,''YYYYMMDDHHMISS'')
				,segment
				,segment_type
				, TRY_TO_TIMESTAMP(earliest_schedule_date,''YYYYMMDDHHMISS'')
				,timezone
				,is_forwarding_allowed
				,is_procurement_allowed
				,reship_parent_line_key
				,bundle_parent_order_line_key
				,is_price_info_only
				,level_of_service
				,first_iter_seq_no
				,last_iter_seq_no
				, TRY_TO_TIMESTAMP(createts,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(modifyts,''YYYYMMDDHHMISS'')
				,createuserid
				,modifyuserid
				,createprogid
				,modifyprogid
				,lockid
				,ordering_uom
				,pricing_quantity_conv_factor
				,pricing_quantity_strategy
				,invoiced_pricing_quantity
				,is_standalone_service
				,tran_discrepancy_qty
				,received_quantity
				,invoice_based_on_actuals
				,actual_pricing_quantity
				,fulfillment_type
				,serial_no
				,reservation_mandatory
				,is_firm_predefined_node
				,intentional_backorder
				, TRY_TO_TIMESTAMP(future_avail_date,''YYYYMMDDHHMISS'')
				,repricing_quantity
				, TRY_TO_TIMESTAMP(min_ship_by_date,''YYYYMMDDHHMISS'')
				,kit_qty
				,bom_config_key
				,bundle_fulfillment_mode
				,is_gift_wrap
				,group_sequence_num
				,in_store_payment_required
				,item_not_exist
				,derived_from_ext_ord
				,is_eligible_for_ship_disc
				,backorder_notification_qty
				,is_price_matched
				,is_pick_up_now
				,item_is_in_hand
				,disposition_code
				,extn_mod_reason_code
				,extn_mod_reason_desc
				,extn_asn
				,extn_parent_order_no
				,extn_item_id
				,extn_order_item_id
				,extn_price_type
				,extn_secondary_return_reason
				,extn_apply_label_fee
				,extn_is_activation_complete
				,extn_item_desc
				,extn_return_carton_count
				,extn_asn_quantity
				,extn_light_color
				,extn_light_type
				,extn_number_of_sections
				,extn_total_cartons
				,extn_tree_height
				,extn_tree_height_uom
				,extn_apply_restocking_fee
				, TRY_TO_TIMESTAMP(extn_return_pickup_date,''YYYYMMDDHHMISS'')
				,extn_pickup_confirmation_no
				,extn_refund_shipping_cost
				,extn_is_fulfilled_line
				, TRY_TO_TIMESTAMP(extn_mfg_warranty_start_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(extn_mfg_warranty_end_date,''YYYYMMDDHHMISS'')
				,extn_term
				,extn_is_invoice_required
				, TRY_TO_TIMESTAMP(extn_prem_guarantee_end_date,''YYYYMMDDHHMISS'')
				, TRY_TO_TIMESTAMP(extn_return_date,''YYYYMMDDHHMISS'')
				,extn_is_email_sent
				,extn_return_required
				,extn_parent_prime_line_no
				,extn_parent_sub_line_no
				, TRY_TO_TIMESTAMP(extn_prem_guarantee_start_date,''YYYYMMDDHHMISS'')
				,extn_reship_upcid
				,extn_parent_order_line_sku
				,unit_price
				,line_total
				,current_timestamp()

			);
			
			
			INSERT INTO TempExtOrderDEtail(
				order_line_key
				,order_header_key
				,prime_line_no
				,sub_line_no
				,line_type
				,order_class
				,alternate_item_id
				,uom
				,product_class
				,cost_currency
				,basic_capacity_required
				,option_capacity_required
				,dependent_on_line_key
				,current_work_order_key
				,dependency_shipping_rule
				,fill_quantity
				,committed_quantity
				,dependency_ratio
				,maintain_ratio
				,merge_node
				,parent_of_dependent_group
				,source_from_organization
				,chained_from_order_line_key
				,chained_from_order_header_key
				,derived_from_order_line_key
				,derived_from_order_header_key
				,derived_from_order_release_key
				,distribution_rule_id
				,invoiced_quantity
				,over_receipt_quantity
				,return_reason
				,shipnode_key
				,procure_from_node
				,ship_to_key
				,mark_for_key
				,buyer_mark_for_node_id
				,req_delivery_date
				,req_cancel_date
				,req_ship_date
				,scac
				,carrier_service_code
				,carrier_account_no
				,pickable_flag
				,ship_together_no
				,hold_flag
				,kit_code
				,hold_reason_code
				,other_charges
				,invoiced_line_total
				,invoiced_extended_price
				,settled_quantity
				,settled_amount
				,tax_exemption_certificate
				,discount_type
				,discount_reference
				,gift_flag
				,personalize_flag
				,personalize_code
				,department_code
				,customer_item
				,customer_item_description
				,item_weight
				,item_weight_uom
				,item_description
				,item_short_description
				,reservation_id
				,reservation_pool
				,customer_po_no
				,customer_po_line_no
				,tax
				,delivery_code
				,original_ordered_qty
				,list_price
				,retail_price
				,discount_percentage
				,packlist_type
				,supplier_item
				,supplier_item_description
				,unit_cost
				,upc_code
				,fob
				,manufacturer_name
				,manufacturer_item
				,manufacturer_item_desc
				,country_of_origin
				,isbn
				,harmonized_code
				,ship_to_id
				,product_line
				,nmfc_code
				,nmfc_class
				,nmfc_description
				,tax_product_code
				,import_license_no
				,import_license_exp_date
				,eccn_no
				,schedule_b_code
				,supplier_code
				,purpose
				,receiving_node
				,buyer_receiving_node_id
				,shipment_consol_group_id
				,orig_order_line_key
				,line_seq_no
				,split_qty
				,pricing_date
				,pipeline_key
				,condition_variable_1
				,condition_variable_2
				,is_price_locked
				,is_cost_overridden
				,is_capacity_overridden
				,invoice_complete
				,delivery_method
				,item_group_code
				,cannot_complete_before_date
				,cannot_complete_after_date
				,appt_status
				,can_add_service_lines
				,pricing_uom
				,capacity_uom
				,pricing_quantity
				,shipped_quantity
				,fixed_capacity_qty_per_line
				,fixed_pricing_qty_per_line
				,wait_for_seq_line
				,sched_failure_reason_code
				,earliest_ship_date
				,earliest_delivery_date
				,cannot_meet_appt
				,promised_appt_start_date
				,promised_appt_end_date
				,segment
				,segment_type
				,earliest_schedule_date
				,timezone
				,is_forwarding_allowed
				,is_procurement_allowed
				,reship_parent_line_key
				,bundle_parent_order_line_key
				,is_price_info_only
				,level_of_service
				,first_iter_seq_no
				,last_iter_seq_no
				,createts
				,modifyts
				,createuserid
				,modifyuserid
				,createprogid
				,modifyprogid
				,lockid
				,ordering_uom
				,pricing_quantity_conv_factor
				,pricing_quantity_strategy
				,invoiced_pricing_quantity
				,is_standalone_service
				,tran_discrepancy_qty
				,received_quantity
				,invoice_based_on_actuals
				,actual_pricing_quantity
				,fulfillment_type
				,serial_no
				,reservation_mandatory
				,is_firm_predefined_node
				,intentional_backorder
				,future_avail_date
				,repricing_quantity
				,min_ship_by_date
				,kit_qty
				,bom_config_key
				,bundle_fulfillment_mode
				,is_gift_wrap
				,group_sequence_num
				,in_store_payment_required
				,item_not_exist
				,derived_from_ext_ord
				,is_eligible_for_ship_disc
				,backorder_notification_qty
				,is_price_matched
				,is_pick_up_now
				,item_is_in_hand
				,disposition_code
				,extn_mod_reason_code
				,extn_mod_reason_desc
				,extn_asn
				,extn_parent_order_no
				,extn_item_id
				,extn_order_item_id
				,extn_price_type
				,extn_secondary_return_reason
				,extn_apply_label_fee
				,extn_is_activation_complete
				,extn_item_desc
				,extn_return_carton_count
				,extn_asn_quantity
				,extn_light_color
				,extn_light_type
				,extn_number_of_sections
				,extn_total_cartons
				,extn_tree_height
				,extn_tree_height_uom
				,extn_apply_restocking_fee
				,extn_return_pickup_date
				,extn_pickup_confirmation_no
				,extn_refund_shipping_cost
				,extn_is_fulfilled_line
				,extn_mfg_warranty_start_date
				,extn_mfg_warranty_end_date
				,extn_term
				,extn_is_invoice_required
				,extn_prem_guarantee_end_date
				,extn_return_date
				,extn_is_email_sent
				,extn_return_required
				,extn_parent_prime_line_no
				,extn_parent_sub_line_no
				,extn_prem_guarantee_start_date
				,extn_reship_upcid
				,extn_parent_order_line_sku
				,unit_price
				,line_total
				,revision
			)
			SELECT 
			
			inserted.order_line_key,
			inserted.order_header_key,
			inserted.prime_line_no,
			inserted.sub_line_no,
			inserted.line_type,
			inserted.order_class,
			inserted.alternate_item_id,
			inserted.uom,
			inserted.product_class,
			inserted.cost_currency,
			inserted.basic_capacity_required,
			inserted.option_capacity_required,
			inserted.dependent_on_line_key,
			inserted.current_work_order_key,
			inserted.dependency_shipping_rule,
			inserted.fill_quantity,
			inserted.committed_quantity,
			inserted.dependency_ratio,
			inserted.maintain_ratio,
			inserted.merge_node,
			inserted.parent_of_dependent_group,
			inserted.source_from_organization,
			inserted.chained_from_order_line_key,
			inserted.chained_from_order_header_key,
			inserted.derived_from_order_line_key,
			inserted.derived_from_order_header_key,
			inserted.derived_from_order_release_key,
			inserted.distribution_rule_id,
			inserted.invoiced_quantity,
			inserted.over_receipt_quantity,
			inserted.return_reason,
			inserted.shipnode_key,
			inserted.procure_from_node,
			inserted.ship_to_key,
			inserted.mark_for_key,
			inserted.buyer_mark_for_node_id,
			inserted.req_delivery_date,
			inserted.req_cancel_date,
			inserted.req_ship_date,
			inserted.scac,
			inserted.carrier_service_code,
			inserted.carrier_account_no,
			inserted.pickable_flag,
			inserted.ship_together_no,
			inserted.hold_flag,
			inserted.kit_code,
			inserted.hold_reason_code,
			inserted.other_charges,
			inserted.invoiced_line_total,
			inserted.invoiced_extended_price,
			inserted.settled_quantity,
			inserted.settled_amount,
			inserted.tax_exemption_certificate,
			inserted.discount_type,
			inserted.discount_reference,
			inserted.gift_flag,
			inserted.personalize_flag,
			inserted.personalize_code,
			inserted.department_code,
			inserted.customer_item,
			inserted.customer_item_description,
			inserted.item_weight,
			inserted.item_weight_uom,
			inserted.item_description,
			inserted.item_short_description,
			inserted.reservation_id,
			inserted.reservation_pool,
			inserted.customer_po_no,
			inserted.customer_po_line_no,
			inserted.tax,
			inserted.delivery_code,
			inserted.original_ordered_qty,
			inserted.list_price,
			inserted.retail_price,
			inserted.discount_percentage,
			inserted.packlist_type,
			inserted.supplier_item,
			inserted.supplier_item_description,
			inserted.unit_cost,
			inserted.upc_code,
			inserted.fob,
			inserted.manufacturer_name,
			inserted.manufacturer_item,
			inserted.manufacturer_item_desc,
			inserted.country_of_origin,
			inserted.isbn,
			inserted.harmonized_code,
			inserted.ship_to_id,
			inserted.product_line,
			inserted.nmfc_code,
			inserted.nmfc_class,
			inserted.nmfc_description,
			inserted.tax_product_code,
			inserted.import_license_no,
			inserted.import_license_exp_date,
			inserted.eccn_no,
			inserted.schedule_b_code,
			inserted.supplier_code,
			inserted.purpose,
			inserted.receiving_node,
			inserted.buyer_receiving_node_id,
			inserted.shipment_consol_group_id,
			inserted.orig_order_line_key,
			inserted.line_seq_no,
			inserted.split_qty,
			inserted.pricing_date,
			inserted.pipeline_key,
			inserted.condition_variable_1,
			inserted.condition_variable_2,
			inserted.is_price_locked,
			inserted.is_cost_overridden,
			inserted.is_capacity_overridden,
			inserted.invoice_complete,
			inserted.delivery_method,
			inserted.item_group_code,
			inserted.cannot_complete_before_date,
			inserted.cannot_complete_after_date,
			inserted.appt_status,
			inserted.can_add_service_lines,
			inserted.pricing_uom,
			inserted.capacity_uom,
			inserted.pricing_quantity,
			inserted.shipped_quantity,
			inserted.fixed_capacity_qty_per_line,
			inserted.fixed_pricing_qty_per_line,
			inserted.wait_for_seq_line,
			inserted.sched_failure_reason_code,
			inserted.earliest_ship_date,
			inserted.earliest_delivery_date,
			inserted.cannot_meet_appt,
			inserted.promised_appt_start_date,
			inserted.promised_appt_end_date,
			inserted.segment,
			inserted.segment_type,
			inserted.earliest_schedule_date,
			inserted.timezone,
			inserted.is_forwarding_allowed,
			inserted.is_procurement_allowed,
			inserted.reship_parent_line_key,
			inserted.bundle_parent_order_line_key,
			inserted.is_price_info_only,
			inserted.level_of_service,
			inserted.first_iter_seq_no,
			inserted.last_iter_seq_no,
			inserted.createts,
			inserted.modifyts,
			inserted.createuserid,
			inserted.modifyuserid,
			inserted.createprogid,
			inserted.modifyprogid,
			inserted.lockid,
			inserted.ordering_uom,
			inserted.pricing_quantity_conv_factor,
			inserted.pricing_quantity_strategy,
			inserted.invoiced_pricing_quantity,
			inserted.is_standalone_service,
			inserted.tran_discrepancy_qty,
			inserted.received_quantity,
			inserted.invoice_based_on_actuals,
			inserted.actual_pricing_quantity,
			inserted.fulfillment_type,
			inserted.serial_no,
			inserted.reservation_mandatory,
			inserted.is_firm_predefined_node,
			inserted.intentional_backorder,
			inserted.future_avail_date,
			inserted.repricing_quantity,
			inserted.min_ship_by_date,
			inserted.kit_qty,
			inserted.bom_config_key,
			inserted.bundle_fulfillment_mode,
			inserted.is_gift_wrap,
			inserted.group_sequence_num,
			inserted.in_store_payment_required,
			inserted.item_not_exist,
			inserted.derived_from_ext_ord,
			inserted.is_eligible_for_ship_disc,
			inserted.backorder_notification_qty,
			inserted.is_price_matched,
			inserted.is_pick_up_now,
			inserted.item_is_in_hand,
			inserted.disposition_code,
			inserted.extn_mod_reason_code,
			inserted.extn_mod_reason_desc,
			inserted.extn_asn,
			inserted.extn_parent_order_no,
			inserted.extn_item_id,
			inserted.extn_order_item_id,
			inserted.extn_price_type,
			inserted.extn_secondary_return_reason,
			inserted.extn_apply_label_fee,
			inserted.extn_is_activation_complete,
			inserted.extn_item_desc,
			inserted.extn_return_carton_count,
			inserted.extn_asn_quantity,
			inserted.extn_light_color,
			inserted.extn_light_type,
			inserted.extn_number_of_sections,
			inserted.extn_total_cartons,
			inserted.extn_tree_height,
			inserted.extn_tree_height_uom,
			inserted.extn_apply_restocking_fee,
			inserted.extn_return_pickup_date,
			inserted.extn_pickup_confirmation_no,
			inserted.extn_refund_shipping_cost,
			inserted.extn_is_fulfilled_line,
			inserted.extn_mfg_warranty_start_date,
			inserted.extn_mfg_warranty_end_date,
			inserted.extn_term,
			inserted.extn_is_invoice_required,
			inserted.extn_prem_guarantee_end_date,
			inserted.extn_return_date,
			inserted.extn_is_email_sent,
			inserted.extn_return_required,
			inserted.extn_parent_prime_line_no,
			inserted.extn_parent_sub_line_no,
			inserted.extn_prem_guarantee_start_date,
			inserted.extn_reship_upcid,
			inserted.extn_parent_order_line_sku,
			inserted.unit_price,
			inserted.line_total,
			1
			FROM analytics.ext_order_detail inserted
			where  inserted.inserted_date >= :processedDate
			;
		
		  ALTER TABLE analytics.ext_order_detail DROP COLUMN if exists inserted_date;

				
			MERGE INTO TempExtOrderDetail ttd
				USING (
					SELECT 
						MAX(aot.revision) as revision,
						aot.order_header_key,
						aot.order_line_key
					FROM analytics.audit_ext_order_detail aot
					INNER JOIN TempExtOrderDetail ttd 
						ON ttd.order_header_key = aot.order_header_key
						AND ttd.order_line_key = aot.order_line_key
					GROUP BY 
						aot.order_header_key,
						aot.order_line_key
				) aot
				ON ttd.order_header_key = aot.order_header_key
				AND ttd.order_line_key = aot.order_line_key
				WHEN MATCHED THEN
					UPDATE SET 
						ttd.Revision = COALESCE(aot.revision, 0) + 1;

			
			--Insert audit data    

		  --Insert into audit table 

	INSERT INTO analytics.audit_ext_order_detail(
		order_line_key
				,order_header_key
				,prime_line_no
				,sub_line_no
				,line_type
				,order_class
				,alternate_item_id
				,uom
				,product_class
				,cost_currency
				,basic_capacity_required
				,option_capacity_required
				,dependent_on_line_key
				,current_work_order_key
				,dependency_shipping_rule
				,fill_quantity
				,committed_quantity
				,dependency_ratio
				,maintain_ratio
				,merge_node
				,parent_of_dependent_group
				,source_from_organization
				,chained_from_order_line_key
				,chained_from_order_header_key
				,derived_from_order_line_key
				,derived_from_order_header_key
				,derived_from_order_release_key
				,distribution_rule_id
				,invoiced_quantity
				,over_receipt_quantity
				,return_reason
				,shipnode_key
				,procure_from_node
				,ship_to_key
				,mark_for_key
				,buyer_mark_for_node_id
				,req_delivery_date
				,req_cancel_date
				,req_ship_date
				,scac
				,carrier_service_code
				,carrier_account_no
				,pickable_flag
				,ship_together_no
				,hold_flag
				,kit_code
				,hold_reason_code
				,other_charges
				,invoiced_line_total
				,invoiced_extended_price 
				,settled_quantity
				,settled_amount
				,tax_exemption_certificate
				,discount_type
				,discount_reference
				,gift_flag
				,personalize_flag
				,personalize_code
				,department_code
				,customer_item
				,customer_item_description
				,item_weight
				,item_weight_uom
				,item_description
				,item_short_description
				,reservation_id
				,reservation_pool
				,customer_po_no
				,customer_po_line_no
				,tax
				,delivery_code
				,original_ordered_qty
				,list_price
				,retail_price
				,discount_percentage
				,packlist_type
				,supplier_item
				,supplier_item_description
				,unit_cost
				,upc_code
				,fob
				,manufacturer_name
				,manufacturer_item
				,manufacturer_item_desc
				,country_of_origin
				,isbn
				,harmonized_code
				,ship_to_id
				,product_line
				,nmfc_code
				,nmfc_class
				,nmfc_description
				,tax_product_code
				,import_license_no
				,import_license_exp_date
				,eccn_no
				,schedule_b_code
				,supplier_code
				,purpose
				,receiving_node
				,buyer_receiving_node_id
				,shipment_consol_group_id
				,orig_order_line_key
				,line_seq_no
				,split_qty
				,pricing_date
				,pipeline_key
				,condition_variable_1
				,condition_variable_2
				,is_price_locked
				,is_cost_overridden
				,is_capacity_overridden
				,invoice_complete
				,delivery_method
				,item_group_code
				,cannot_complete_before_date
				,cannot_complete_after_date
				,appt_status
				,can_add_service_lines
				,pricing_uom
				,capacity_uom
				,pricing_quantity
				,shipped_quantity
				,fixed_capacity_qty_per_line
				,fixed_pricing_qty_per_line
				,wait_for_seq_line
				,sched_failure_reason_code
				,earliest_ship_date
				,earliest_delivery_date
				,cannot_meet_appt
				,promised_appt_start_date
				,promised_appt_end_date
				,segment
				,segment_type
				,earliest_schedule_date
				,timezone
				,is_forwarding_allowed
				,is_procurement_allowed
				,reship_parent_line_key
				,bundle_parent_order_line_key
				,is_price_info_only
				,level_of_service
				,first_iter_seq_no
				,last_iter_seq_no
				,createts
				,modifyts
				,createuserid
				,modifyuserid
				,createprogid
				,modifyprogid
				,lockid
				,ordering_uom
				,pricing_quantity_conv_factor
				,pricing_quantity_strategy
				,invoiced_pricing_quantity
				,is_standalone_service
				,tran_discrepancy_qty
				,received_quantity
				,invoice_based_on_actuals
				,actual_pricing_quantity
				,fulfillment_type
				,serial_no
				,reservation_mandatory
				,is_firm_predefined_node
				,intentional_backorder
				,future_avail_date
				,repricing_quantity
				,min_ship_by_date
				,kit_qty
				,bom_config_key
				,bundle_fulfillment_mode
				,is_gift_wrap
				,group_sequence_num
				,in_store_payment_required
				,item_not_exist
				,derived_from_ext_ord
				,is_eligible_for_ship_disc
				,backorder_notification_qty
				,is_price_matched
				,is_pick_up_now
				,item_is_in_hand
				,disposition_code
				,extn_mod_reason_code
				,extn_mod_reason_desc
				,extn_asn
				,extn_parent_order_no
				,extn_item_id
				,extn_order_item_id
				,extn_price_type
				,extn_secondary_return_reason
				,extn_apply_label_fee
				,extn_is_activation_complete
				,extn_item_desc
				,extn_return_carton_count
				,extn_asn_quantity
				,extn_light_color
				,extn_light_type
				,extn_number_of_sections
				,extn_total_cartons
				,extn_tree_height
				,extn_tree_height_uom
				,extn_apply_restocking_fee
				,extn_return_pickup_date
				,extn_pickup_confirmation_no
				,extn_refund_shipping_cost
				,extn_is_fulfilled_line
				,extn_mfg_warranty_start_date
				,extn_mfg_warranty_end_date
				,extn_term
				,extn_is_invoice_required
				,extn_prem_guarantee_end_date
				,extn_return_date
				,extn_is_email_sent
				,extn_return_required
				,extn_parent_prime_line_no
				,extn_parent_sub_line_no
				,extn_prem_guarantee_start_date
				,extn_reship_upcid
				,extn_parent_order_line_sku
				,unit_price
				,line_total
				,revision
			)
			SELECT
				stg.order_line_key,
				stg.order_header_key,
				stg.prime_line_no,
				stg.sub_line_no,
				stg.line_type,
				stg.order_class,
				stg.alternate_item_id,
				stg.uom,
				stg.product_class,
				stg.cost_currency,
				stg.basic_capacity_required,
				stg.option_capacity_required,
				stg.dependent_on_line_key,
				stg.current_work_order_key,
				stg.dependency_shipping_rule,
				stg.fill_quantity,
				stg.committed_quantity,
				stg.dependency_ratio,
				stg.maintain_ratio,
				stg.merge_node,
				stg.parent_of_dependent_group,
				stg.source_from_organization,
				stg.chained_from_order_line_key,
				stg.chained_from_order_header_key,
				stg.derived_from_order_line_key,
				stg.derived_from_order_header_key,
				stg.derived_from_order_release_key,
				stg.distribution_rule_id,
				stg.invoiced_quantity,
				stg.over_receipt_quantity,
				stg.return_reason,
				stg.shipnode_key,
				stg.procure_from_node,
				stg.ship_to_key,
				stg.mark_for_key,
				stg.buyer_mark_for_node_id,
				TRY_TO_TIMESTAMP(stg.req_delivery_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.req_cancel_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.req_ship_date,''YYYYMMDDHHMISS''),
				stg.scac,
				stg.carrier_service_code,
				stg.carrier_account_no,
				stg.pickable_flag,
				stg.ship_together_no,
				stg.hold_flag,
				stg.kit_code,
				stg.hold_reason_code,
				stg.other_charges,
				try_cast(stg.invoiced_line_total as float),
				try_cast(stg.invoiced_extended_price as float),
				stg.settled_quantity,
				stg.settled_amount,
				stg.tax_exemption_certificate,
				stg.discount_type,
				stg.discount_reference,
				stg.gift_flag,
				stg.personalize_flag,
				stg.personalize_code,
				stg.department_code,
				stg.customer_item,
				stg.customer_item_description,
				stg.item_weight,
				stg.item_weight_uom,
				stg.item_description,
				stg.item_short_description,
				stg.reservation_id,
				stg.reservation_pool,
				stg.customer_po_no,
				stg.customer_po_line_no,
				stg.tax,
				stg.delivery_code,
				stg.original_ordered_qty,
				try_cast(stg.list_price as float),
				try_cast(stg.retail_price as float),
				stg.discount_percentage,
				stg.packlist_type,
				stg.supplier_item,
				stg.supplier_item_description,
				stg.unit_cost,
				stg.upc_code,
				stg.fob,
				stg.manufacturer_name,
				stg.manufacturer_item,
				stg.manufacturer_item_desc,
				stg.country_of_origin,
				stg.isbn,
				stg.harmonized_code,
				stg.ship_to_id,
				stg.product_line,
				stg.nmfc_code,
				stg.nmfc_class,
				stg.nmfc_description,
				stg.tax_product_code,
				stg.import_license_no,
				TRY_TO_TIMESTAMP(stg.import_license_exp_date,''YYYYMMDDHHMISS''),
				stg.eccn_no,
				stg.schedule_b_code,
				stg.supplier_code,
				stg.purpose,
				stg.receiving_node,
				stg.buyer_receiving_node_id,
				stg.shipment_consol_group_id,
				stg.orig_order_line_key,
				stg.line_seq_no,
				stg.split_qty,
				TRY_TO_TIMESTAMP(stg.pricing_date,''YYYYMMDDHHMISS''),
				stg.pipeline_key,
				stg.condition_variable_1,
				stg.condition_variable_2,
				stg.is_price_locked,
				stg.is_cost_overridden,
				stg.is_capacity_overridden,
				stg.invoice_complete,
				stg.delivery_method,
				stg.item_group_code,
				TRY_TO_TIMESTAMP(stg.cannot_complete_before_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.cannot_complete_after_date,''YYYYMMDDHHMISS''),
				stg.appt_status,
				stg.can_add_service_lines,
				stg.pricing_uom,
				stg.capacity_uom,
				stg.pricing_quantity,
				stg.shipped_quantity,
				stg.fixed_capacity_qty_per_line,
				stg.fixed_pricing_qty_per_line,
				stg.wait_for_seq_line,
				stg.sched_failure_reason_code,
				TRY_TO_TIMESTAMP(stg.earliest_ship_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.earliest_delivery_date,''YYYYMMDDHHMISS''),
				stg.cannot_meet_appt,
				TRY_TO_TIMESTAMP(stg.promised_appt_start_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.promised_appt_end_date,''YYYYMMDDHHMISS''),
				stg.segment,
				stg.segment_type,
				TRY_TO_TIMESTAMP(stg.earliest_schedule_date,''YYYYMMDDHHMISS''),
				stg.timezone,
				stg.is_forwarding_allowed,
				stg.is_procurement_allowed,
				stg.reship_parent_line_key,
				stg.bundle_parent_order_line_key,
				stg.is_price_info_only,
				stg.level_of_service,
				stg.first_iter_seq_no,
				stg.last_iter_seq_no,
				TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS''),
				stg.createuserid,
				stg.modifyuserid,
				stg.createprogid,
				stg.modifyprogid,
				stg.lockid,
				stg.ordering_uom,
				stg.pricing_quantity_conv_factor,
				stg.pricing_quantity_strategy,
				stg.invoiced_pricing_quantity,
				stg.is_standalone_service,
				stg.tran_discrepancy_qty,
				stg.received_quantity,
				stg.invoice_based_on_actuals,
				stg.actual_pricing_quantity,
				stg.fulfillment_type,
				stg.serial_no,
				stg.reservation_mandatory,
				stg.is_firm_predefined_node,
				stg.intentional_backorder,
				TRY_TO_TIMESTAMP(stg.future_avail_date,''YYYYMMDDHHMISS''),
				stg.repricing_quantity,
				TRY_TO_TIMESTAMP(stg.min_ship_by_date,''YYYYMMDDHHMISS''),
				stg.kit_qty,
				stg.bom_config_key,
				stg.bundle_fulfillment_mode,
				stg.is_gift_wrap,
				stg.group_sequence_num,
				stg.in_store_payment_required,
				stg.item_not_exist,
				stg.derived_from_ext_ord,
				stg.is_eligible_for_ship_disc,
				stg.backorder_notification_qty,
				stg.is_price_matched,
				stg.is_pick_up_now,
				stg.item_is_in_hand,
				stg.disposition_code,
				stg.extn_mod_reason_code,
				stg.extn_mod_reason_desc,
				stg.extn_asn,
				stg.extn_parent_order_no,
				stg.extn_item_id,
				stg.extn_order_item_id,
				stg.extn_price_type,
				stg.extn_secondary_return_reason,
				stg.extn_apply_label_fee,
				stg.extn_is_activation_complete,
				stg.extn_item_desc,
				stg.extn_return_carton_count,
				stg.extn_asn_quantity,
				stg.extn_light_color,
				stg.extn_light_type,
				stg.extn_number_of_sections,
				stg.extn_total_cartons,
				stg.extn_tree_height,
				stg.extn_tree_height_uom,
				stg.extn_apply_restocking_fee,
				TRY_TO_TIMESTAMP(stg.extn_return_pickup_date,''YYYYMMDDHHMISS''),
				stg.extn_pickup_confirmation_no,
				stg.extn_refund_shipping_cost,
				stg.extn_is_fulfilled_line,
				TRY_TO_TIMESTAMP(stg.extn_mfg_warranty_start_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.extn_mfg_warranty_end_date,''YYYYMMDDHHMISS''),
				stg.extn_term,
				stg.extn_is_invoice_required,
				TRY_TO_TIMESTAMP(stg.extn_prem_guarantee_end_date,''YYYYMMDDHHMISS''),
				TRY_TO_TIMESTAMP(stg.extn_return_date,''YYYYMMDDHHMISS''),
				stg.extn_is_email_sent,
				stg.extn_return_required,
				stg.extn_parent_prime_line_no,
				stg.extn_parent_sub_line_no,
				TRY_TO_TIMESTAMP(stg.extn_prem_guarantee_start_date,''YYYYMMDDHHMISS''),
				stg.extn_reship_upcid,
				stg.extn_parent_order_line_sku,
				stg.unit_price,
				stg.line_total,
				stg.Revision
			FROM TempExtOrderDEtail stg;

		
 CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);



DROP TABLE IF EXISTS TempExtOrderDEtail;

RETURN ''Success'';
EXCEPTION 
WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
            
    RETURN sqlerrm;
END';