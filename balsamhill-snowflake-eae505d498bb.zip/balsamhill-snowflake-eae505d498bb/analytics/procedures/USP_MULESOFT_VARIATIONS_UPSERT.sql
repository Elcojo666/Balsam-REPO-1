
use DATABASE balsam_edw_qa;





CREATE OR REPLACE PROCEDURE analytics."USP_INVENTORY_VARIATIONS_UPSERT"(PIPELINE_NAME VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN


START_TIME_PROC := CURRENT_TIMESTAMP();

SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);
CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        NULL,
        CURRENT_TIMESTAMP(),
        'upsert started'
    );
    
CREATE OR REPLACE TEMPORARY TABLE analytics.insertedINVENTORYRecords (pk_variationid number,
	item_id VARCHAR,variation_id VARCHAR,item_name VARCHAR,description VARCHAR,url VARCHAR,image_url VARCHAR,active VARCHAR,facet_size VARCHAR,facet_balsam_hill_exclusive VARCHAR,facet_clearance VARCHAR,facet_color VARCHAR,facet_decorating_theme VARCHAR,facet_design VARCHAR,facet_display_diameter VARCHAR,facet_display_height VARCHAR,facet_display_length VARCHAR,facet_display_width VARCHAR,facet_easy_setup VARCHAR,facet_flavor VARCHAR,facet_foliage_type VARCHAR,facet_frosted VARCHAR,facet_gifting VARCHAR,facet_hand_painted VARCHAR,facet_handcrafted VARCHAR,facet_holiday VARCHAR,facet_key_theme VARCHAR,facet_light_color VARCHAR,facet_light_control VARCHAR,facet_light_design VARCHAR,facet_light_type VARCHAR,facet_material VARCHAR,facet_needle_type VARCHAR,facet_new VARCHAR,facet_outdoor_safe VARCHAR,facet_plays_music VARCHAR,facet_price_usd VARCHAR, facet_price_gbp VARCHAR,facet_price_eur VARCHAR,facet_price_aud VARCHAR,facet_product_type VARCHAR,facet_realism VARCHAR,facet_sale VARCHAR,facet_season VARCHAR,facet_set_size VARCHAR,facet_shape VARCHAR,facet_shatter_resistant VARCHAR,facet_special_features VARCHAR,facet_species VARCHAR,facet_tree_shape VARCHAR,facet_type_of_serveware VARCHAR,facet_type_of_storage VARCHAR,facet_wick_and_wax_type VARCHAR,facet_discount_percentage VARCHAR,metadata_display_diameter_unit VARCHAR,metadata_display_height_unit VARCHAR,facet_stock_level_status VARCHAR,metadata_display_length_unit VARCHAR,metadata_display_width_unit VARCHAR,metadata_future_stock_date VARCHAR,metadata_online_date VARCHAR,metadata_json_original_price VARCHAR,metadata_stock_level_status VARCHAR,metadata_primary_image_alt VARCHAR,metadata_primary_image_title VARCHAR,metadata_primary_image_backup VARCHAR,metadata_json_sale_price VARCHAR,metadata_display_height VARCHAR,metadata_foliage_type VARCHAR,metadata_new VARCHAR,metadata_size VARCHAR,metadata_size_unit VARCHAR,metadata_handcrafted VARCHAR,metadata_hand_painted VARCHAR,metadata_balsam_hill_exclusive VARCHAR,metadata_outdoor_safe VARCHAR,metadata_variation_name VARCHAR,metadata_product_type_key VARCHAR,metadata_family_variations_count VARCHAR,metadata_categoryType VARCHAR,
BRAND VARCHAR,
LOCALE VARCHAR,
PLATFORM VARCHAR,
TXN_ID VARCHAR(16777216),
    CREATED_DATE TIMESTAMP,
    modified_date TIMESTAMP,
    rivision Number,
    FK_SOURCEID NUMBER,
FK_PLATFORMID NUMBER
    );

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.TXN_INVENTORY_VARIATIONS ti
USING (
    SELECT STG.*,
    P.PK_PLATFORMID,
    CASE
        WHEN B.BRANDCODE = 'BAL' THEN 'BHUS'
        ELSE B.BRANDCODE
    END AS BRANDCODE,
    B.PK_SOURCEID
    FROM TRANSFORMED.STG_INVENTORY_VARIATIONS STG
    INNER JOIN MASTER.DIM_PLATFORM P on P.platform_name = STG.platform
    INNER JOIN MASTER.SOURCE_BRAND_PLATFORM_MAP B ON B.PLATFORMID = P.PK_PLATFORMID and B.LOCALE = STG.LOCALE
    WHERE B.BRANDCODE in ('BAL','BHUK','BHDE','BHFR','BHAU')
) si
ON ti.variation_id = si.variation_id AND ti.LOCALE = SI.LOCALE and ti.fk_sourceid = si.pk_sourceid
--and ti.brand = si.brandcode
--and ti.brand = si.brand
WHEN MATCHED THEN
    UPDATE SET
ti.item_id=si.item_id
,ti.item_name=si.item_name
,ti.description=si.description
,ti.url=si.url
,ti.image_url=si.image_url
,ti.active=si.active
,ti.facet_size=si.facet_size
,ti.facet_balsam_hill_exclusive=si.facet_balsam_hill_exclusive
,ti.facet_clearance=si.facet_clearance
,ti.facet_color=si.facet_color
,ti.facet_decorating_theme=si.facet_decorating_theme
,ti.facet_design=si.facet_design
,ti.facet_display_diameter=si.facet_display_diameter
,ti.facet_display_height=si.facet_display_height
,ti.facet_display_length=si.facet_display_length
,ti.facet_display_width=si.facet_display_width
,ti.facet_easy_setup=si.facet_easy_setup
,ti.facet_flavor=si.facet_flavor
,ti.facet_foliage_type=si.facet_foliage_type
,ti.facet_frosted=si.facet_frosted
,ti.facet_gifting=si.facet_gifting
,ti.facet_hand_painted=si.facet_hand_painted
,ti.facet_handcrafted=si.facet_handcrafted
,ti.facet_holiday=si.facet_holiday
,ti.facet_key_theme=si.facet_key_theme
,ti.facet_light_color=si.facet_light_color
,ti.facet_light_control=si.facet_light_control
,ti.facet_light_design=si.facet_light_design
,ti.facet_light_type=si.facet_light_type
,ti.facet_material=si.facet_material
,ti.facet_needle_type=si.facet_needle_type
,ti.facet_new=si.facet_new
,ti.facet_outdoor_safe=si.facet_outdoor_safe
,ti.facet_plays_music=si.facet_plays_music
,ti.facet_price_usd=si.facet_price_usd
,ti.facet_price_gbp=si.facet_price_gbp
,ti.facet_price_eur=si.facet_price_eur
,ti.facet_price_aud=si.facet_price_aud
,ti.facet_product_type=si.facet_product_type
,ti.facet_realism=si.facet_realism
,ti.facet_sale=si.facet_sale
,ti.facet_season=si.facet_season
,ti.facet_set_size=si.facet_set_size
,ti.facet_shape=si.facet_shape
,ti.facet_shatter_resistant=si.facet_shatter_resistant
,ti.facet_special_features=si.facet_special_features
,ti.facet_species=si.facet_species
,ti.facet_tree_shape=si.facet_tree_shape
,ti.facet_type_of_serveware=si.facet_type_of_serveware
,ti.facet_type_of_storage=si.facet_type_of_storage
,ti.facet_wick_and_wax_type=si.facet_wick_and_wax_type
,ti.facet_discount_percentage=si.facet_discount_percentage
,ti.metadata_display_diameter_unit=si.metadata_display_diameter_unit
,ti.metadata_display_height_unit=si.metadata_display_height_unit
,ti.facet_stock_level_status=si.facet_stock_level_status
,ti.metadata_display_length_unit=si.metadata_display_length_unit
,ti.metadata_display_width_unit=si.metadata_display_width_unit
,ti.metadata_future_stock_date=si.metadata_future_stock_date
,ti.metadata_online_date=si.metadata_online_date
,ti.metadata_json_original_price=si.metadata_json_original_price
,ti.metadata_stock_level_status=si.metadata_stock_level_status
,ti.metadata_primary_image_alt=si.metadata_primary_image_alt
,ti.metadata_primary_image_title=si.metadata_primary_image_title
,ti.metadata_primary_image_backup=si.metadata_primary_image_backup
,ti.metadata_json_sale_price=si.metadata_json_sale_price
,ti.metadata_display_height=si.metadata_display_height
,ti.metadata_foliage_type=si.metadata_foliage_type
,ti.metadata_new=si.metadata_new
,ti.metadata_size=si.metadata_size
,ti.metadata_size_unit=si.metadata_size_unit
,ti.metadata_handcrafted=si.metadata_handcrafted
,ti.metadata_hand_painted=si.metadata_hand_painted
,ti.metadata_balsam_hill_exclusive=si.metadata_balsam_hill_exclusive
,ti.metadata_outdoor_safe=si.metadata_outdoor_safe
,ti.metadata_variation_name=si.metadata_variation_name
,ti.metadata_product_type_key=si.metadata_product_type_key
,ti.metadata_family_variations_count=si.metadata_family_variations_count
,ti.metadata_categoryType=si.metadata_categoryType
,ti.TXN_ID=si.TXN_ID
,ti.modified_date = CURRENT_TIMESTAMP()  
WHEN NOT MATCHED THEN
    INSERT (
item_id,
variation_id,
item_name,
description,
url,
image_url,
active,
facet_size,
facet_balsam_hill_exclusive,
facet_clearance,
facet_color,
facet_decorating_theme,
facet_design,
facet_display_diameter,
facet_display_height,
facet_display_length,
facet_display_width,
facet_easy_setup,
facet_flavor,
facet_foliage_type,
facet_frosted,
facet_gifting,
facet_hand_painted,
facet_handcrafted,
facet_holiday,
facet_key_theme,
facet_light_color,
facet_light_control,
facet_light_design,
facet_light_type,
facet_material,
facet_needle_type,
facet_new,
facet_outdoor_safe,
facet_plays_music,
facet_price_usd,
facet_price_gbp,
facet_price_eur,
facet_price_aud,
facet_product_type,
facet_realism,
facet_sale,
facet_season,
facet_set_size,
facet_shape,
facet_shatter_resistant,
facet_special_features,
facet_species,
facet_tree_shape,
facet_type_of_serveware,
facet_type_of_storage,
facet_wick_and_wax_type,
facet_discount_percentage,
metadata_display_diameter_unit,
metadata_display_height_unit,
facet_stock_level_status,
metadata_display_length_unit,
metadata_display_width_unit,
metadata_future_stock_date,
metadata_online_date,
metadata_json_original_price,
metadata_stock_level_status,
metadata_primary_image_alt,
metadata_primary_image_title,
metadata_primary_image_backup,
metadata_json_sale_price,
metadata_display_height,
metadata_foliage_type,
metadata_new,
metadata_size,
metadata_size_unit,
metadata_handcrafted,
metadata_hand_painted,
metadata_balsam_hill_exclusive,
metadata_outdoor_safe,
metadata_variation_name,
metadata_product_type_key,
metadata_family_variations_count,
metadata_categoryType,
LOCALE,
PLATFORM,
BRAND,
TXN_ID,
FK_SOURCEID,
FK_PLATFORMID,
    CREATED_DATE,
    modified_date
    )
    VALUES (
si.item_id,
si.variation_id,
si.item_name,
si.description,
si.url,
si.image_url,
si.active,
si.facet_size,
si.facet_balsam_hill_exclusive,
si.facet_clearance,
si.facet_color,
si.facet_decorating_theme,
si.facet_design,
si.facet_display_diameter,
si.facet_display_height,
si.facet_display_length,
si.facet_display_width,
si.facet_easy_setup,
si.facet_flavor,
si.facet_foliage_type,
si.facet_frosted,
si.facet_gifting,
si.facet_hand_painted,
si.facet_handcrafted,
si.facet_holiday,
si.facet_key_theme,
si.facet_light_color,
si.facet_light_control,
si.facet_light_design,
si.facet_light_type,
si.facet_material,
si.facet_needle_type,
si.facet_new,
si.facet_outdoor_safe,
si.facet_plays_music,
si.facet_price_usd,
si.facet_price_gbp,
si.facet_price_eur,
si.facet_price_aud,
si.facet_product_type,
si.facet_realism,
si.facet_sale,
si.facet_season,
si.facet_set_size,
si.facet_shape,
si.facet_shatter_resistant,
si.facet_special_features,
si.facet_species,
si.facet_tree_shape,
si.facet_type_of_serveware,
si.facet_type_of_storage,
si.facet_wick_and_wax_type,
si.facet_discount_percentage,
si.metadata_display_diameter_unit,
si.metadata_display_height_unit,
si.facet_stock_level_status,
si.metadata_display_length_unit,
si.metadata_display_width_unit,
si.metadata_future_stock_date,
si.metadata_online_date,
si.metadata_json_original_price,
si.metadata_stock_level_status,
si.metadata_primary_image_alt,
si.metadata_primary_image_title,
si.metadata_primary_image_backup,
si.metadata_json_sale_price,
si.metadata_display_height,
si.metadata_foliage_type,
si.metadata_new,
si.metadata_size,
si.metadata_size_unit,
si.metadata_handcrafted,
si.metadata_hand_painted,
si.metadata_balsam_hill_exclusive,
si.metadata_outdoor_safe,
si.metadata_variation_name,
si.metadata_product_type_key,
si.metadata_family_variations_count,
si.metadata_categoryType,
si.LOCALE,
si.PLATFORM,
si.BRAND,
si.TXN_ID,
si.PK_SOURCEID,
si.PK_PLATFORMID,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP()
    );


INSERT INTO analytics.insertedINVENTORYRecords (
pk_variationid,
  item_id,
variation_id,
item_name,
description,
url,
image_url,
active,
facet_size,
facet_balsam_hill_exclusive,
facet_clearance,
facet_color,
facet_decorating_theme,
facet_design,
facet_display_diameter,
facet_display_height,
facet_display_length,
facet_display_width,
facet_easy_setup,
facet_flavor,
facet_foliage_type,
facet_frosted,
facet_gifting,
facet_hand_painted,
facet_handcrafted,
facet_holiday,
facet_key_theme,
facet_light_color,
facet_light_control,
facet_light_design,
facet_light_type,
facet_material,
facet_needle_type,
facet_new,
facet_outdoor_safe,
facet_plays_music,
facet_price_usd,
facet_price_gbp,
facet_price_eur,
facet_price_aud,
facet_product_type,
facet_realism,
facet_sale,
facet_season,
facet_set_size,
facet_shape,
facet_shatter_resistant,
facet_special_features,
facet_species,
facet_tree_shape,
facet_type_of_serveware,
facet_type_of_storage,
facet_wick_and_wax_type,
facet_discount_percentage,
metadata_display_diameter_unit,
metadata_display_height_unit,
facet_stock_level_status,
metadata_display_length_unit,
metadata_display_width_unit,
metadata_future_stock_date,
metadata_online_date,
metadata_json_original_price,
metadata_stock_level_status,
metadata_primary_image_alt,
metadata_primary_image_title,
metadata_primary_image_backup,
metadata_json_sale_price,
metadata_display_height,
metadata_foliage_type,
metadata_new,
metadata_size,
metadata_size_unit,
metadata_handcrafted,
metadata_hand_painted,
metadata_balsam_hill_exclusive,
metadata_outdoor_safe,
metadata_variation_name,
metadata_product_type_key,
metadata_family_variations_count,
metadata_categoryType,
BRAND ,
CREATED_DATE,
modified_date,
locale,
txn_id,
rivision,
PLATFORM,
FK_SOURCEID,
FK_PLATFORMID

)
SELECT
ti.pk_variationid,
 ti.item_id,
ti.variation_id,
ti.item_name,
ti.description,
ti.url,
ti.image_url,
ti.active,
ti.facet_size,
ti.facet_balsam_hill_exclusive,
ti.facet_clearance,
ti.facet_color,
ti.facet_decorating_theme,
ti.facet_design,
ti.facet_display_diameter,
ti.facet_display_height,
ti.facet_display_length,
ti.facet_display_width,
ti.facet_easy_setup,
ti.facet_flavor,
ti.facet_foliage_type,
ti.facet_frosted,
ti.facet_gifting,
ti.facet_hand_painted,
ti.facet_handcrafted,
ti.facet_holiday,
ti.facet_key_theme,
ti.facet_light_color,
ti.facet_light_control,
ti.facet_light_design,
ti.facet_light_type,
ti.facet_material,
ti.facet_needle_type,
ti.facet_new,
ti.facet_outdoor_safe,
ti.facet_plays_music,
ti.facet_price_usd,
ti.facet_price_gbp,
ti.facet_price_eur,
ti.facet_price_aud,
ti.facet_product_type,
ti.facet_realism,
ti.facet_sale,
ti.facet_season,
ti.facet_set_size,
ti.facet_shape,
ti.facet_shatter_resistant,
ti.facet_special_features,
ti.facet_species,
ti.facet_tree_shape,
ti.facet_type_of_serveware,
ti.facet_type_of_storage,
ti.facet_wick_and_wax_type,
ti.facet_discount_percentage,
ti.metadata_display_diameter_unit,
ti.metadata_display_height_unit,
ti.facet_stock_level_status,
ti.metadata_display_length_unit,
ti.metadata_display_width_unit,
ti.metadata_future_stock_date,
ti.metadata_online_date,
ti.metadata_json_original_price,
ti.metadata_stock_level_status,
ti.metadata_primary_image_alt,
ti.metadata_primary_image_title,
ti.metadata_primary_image_backup,
ti.metadata_json_sale_price,
ti.metadata_display_height,
ti.metadata_foliage_type,
ti.metadata_new,
ti.metadata_size,
ti.metadata_size_unit,
ti.metadata_handcrafted,
ti.metadata_hand_painted,
ti.metadata_balsam_hill_exclusive,
ti.metadata_outdoor_safe,
ti.metadata_variation_name,
ti.metadata_product_type_key,
ti.metadata_family_variations_count,
ti.metadata_categoryType,
ti.brand ,
ti.CREATED_DATE,
ti.modified_date,
ti.locale,
ti.txn_id,
:initialRevision,
ti.PLATFORM,
ti.FK_SOURCEID,
ti.FK_PLATFORMID

 
FROM ANALYTICS.TXN_INVENTORY_VARIATIONS ti
        INNER JOIN TRANSFORMED.STG_INVENTORY_VARIATIONS si 
            ON ti.variation_id = si.variation_id and ti.locale = si.locale and ti.brand = si.brand
            
    and ti.CREATED_DATE >= :processedDate or ti.modified_date >= :processedDate and ti.txn_id = si.txn_id
;

    
CREATE OR REPLACE TEMPORARY TABLE analytics.temp_max_revisions AS
SELECT
    MAX(aot.rivision) AS rivision,
    aot.variation_id,
    aot.locale,
    aot.brand
FROM
    ANALYTICS.AUDIT_INVENTORY_VARIATIONS AS aot
GROUP BY
    aot.variation_id,aot.locale,
    aot.brand;

UPDATE analytics.insertedINVENTORYRecords AS ttd
SET
    ttd.rivision = CAST((COALESCE(aot.rivision, 0) + 1) AS INTEGER)
FROM
    analytics.temp_max_revisions AS aot
WHERE
    ttd.variation_id = aot.variation_id and ttd.locale = aot.locale
    and ttd.brand = aot.brand;

DROP TABLE IF EXISTS analytics.temp_max_revisions;


INSERT INTO ANALYTICS.AUDIT_INVENTORY_VARIATIONS (
pk_variationid,
item_id,
variation_id,
item_name,
description,
url,
image_url,
active,
facet_size,
facet_balsam_hill_exclusive,
facet_clearance,
facet_color,
facet_decorating_theme,
facet_design,
facet_display_diameter,
facet_display_height,
facet_display_length,
facet_display_width,
facet_easy_setup,
facet_flavor,
facet_foliage_type,
facet_frosted,
facet_gifting,
facet_hand_painted,
facet_handcrafted,
facet_holiday,
facet_key_theme,
facet_light_color,
facet_light_control,
facet_light_design,
facet_light_type,
facet_material,
facet_needle_type,
facet_new,
facet_outdoor_safe,
facet_plays_music,
facet_price_usd,
facet_price_gbp,
facet_price_eur,
facet_price_aud,
facet_product_type,
facet_realism,
facet_sale,
facet_season,
facet_set_size,
facet_shape,
facet_shatter_resistant,
facet_special_features,
facet_species,
facet_tree_shape,
facet_type_of_serveware,
facet_type_of_storage,
facet_wick_and_wax_type,
facet_discount_percentage,
metadata_display_diameter_unit,
metadata_display_height_unit,
facet_stock_level_status,
metadata_display_length_unit,
metadata_display_width_unit,
metadata_future_stock_date,
metadata_online_date,
metadata_json_original_price,
metadata_stock_level_status,
metadata_primary_image_alt,
metadata_primary_image_title,
metadata_primary_image_backup,
metadata_json_sale_price,
metadata_display_height,
metadata_foliage_type,
metadata_new,
metadata_size,
metadata_size_unit,
metadata_handcrafted,
metadata_hand_painted,
metadata_balsam_hill_exclusive,
metadata_outdoor_safe,
metadata_variation_name,
metadata_product_type_key,
metadata_family_variations_count,
metadata_categoryType,
BRAND ,
CREATED_DATE,
modified_date,
locale,
txn_id,
rivision,
PLATFORM,
FK_SOURCEID,
FK_PLATFORMID

    
)
SELECT
si.pk_variationid,
si.item_id,
si.variation_id,
si.item_name,
si.description,
si.url,
si.image_url,
si.active,
si.facet_size,
si.facet_balsam_hill_exclusive,
si.facet_clearance,
si.facet_color,
si.facet_decorating_theme,
si.facet_design,
si.facet_display_diameter,
si.facet_display_height,
si.facet_display_length,
si.facet_display_width,
si.facet_easy_setup,
si.facet_flavor,
si.facet_foliage_type,
si.facet_frosted,
si.facet_gifting,
si.facet_hand_painted,
si.facet_handcrafted,
si.facet_holiday,
si.facet_key_theme,
si.facet_light_color,
si.facet_light_control,
si.facet_light_design,
si.facet_light_type,
si.facet_material,
si.facet_needle_type,
si.facet_new,
si.facet_outdoor_safe,
si.facet_plays_music,
si.facet_price_usd,
si.facet_price_gbp,
si.facet_price_eur,
si.facet_price_aud,
si.facet_product_type,
si.facet_realism,
si.facet_sale,
si.facet_season,
si.facet_set_size,
si.facet_shape,
si.facet_shatter_resistant,
si.facet_special_features,
si.facet_species,
si.facet_tree_shape,
si.facet_type_of_serveware,
si.facet_type_of_storage,
si.facet_wick_and_wax_type,
si.facet_discount_percentage,
si.metadata_display_diameter_unit,
si.metadata_display_height_unit,
si.facet_stock_level_status,
si.metadata_display_length_unit,
si.metadata_display_width_unit,
si.metadata_future_stock_date,
si.metadata_online_date,
si.metadata_json_original_price,
si.metadata_stock_level_status,
si.metadata_primary_image_alt,
si.metadata_primary_image_title,
si.metadata_primary_image_backup,
si.metadata_json_sale_price,
si.metadata_display_height,
si.metadata_foliage_type,
si.metadata_new,
si.metadata_size,
si.metadata_size_unit,
si.metadata_handcrafted,
si.metadata_hand_painted,
si.metadata_balsam_hill_exclusive,
si.metadata_outdoor_safe,
si.metadata_variation_name,
si.metadata_product_type_key,
si.metadata_family_variations_count,
si.metadata_categoryType,
si.brand ,
si.CREATED_DATE,
si.modified_date,
si.locale,
si.txn_id,
si.rivision,
si.PLATFORM,
si.FK_SOURCEID,
si.FK_PLATFORMID


  
FROM analytics.insertedINVENTORYRecords AS si;

UPDATE RAW.RAW_INVENTORY_VARIATIONS
SET 
    processing_status = 'Processed',
    processing_comment = '''',
    processing_errortype = ''''
FROM RAW.RAW_INVENTORY_VARIATIONS roi
INNER JOIN analytics.insertedINVENTORYRecords toi 
    ON toi.variation_id = roi.variation_id 
    AND toi.locale = roi.locale
    AND toi.txn_id = roi.txn_id ;

SELECT
    COUNT(*)
INTO
    :processedRecordCount
FROM
    analytics.insertedINVENTORYRecords;

UPDATE ANALYTICS.log_files_import_status AS lofis
SET
    lofis.processed = :processedRecordCount,
    lofis.status = 'Success'
WHERE
    lofis.file_name = 'YFS_INVENTORY_VARIATIONS';

DROP TABLE IF EXISTS analytics.insertedINVENTORYRecords;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'COMPLETED',
        :START_TIME_PROC,
        CURRENT_TIMESTAMP(),
        'upsert completed successfully'
    );
COMMIT;
--Log the completion of the stored procedure execution
SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

RETURN 'Success';

EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_INVENTORY_VARIATIONS';
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :START_TIME_PROC,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    -- Log the failure of the stored procedure
SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
 
	
	RETURN error_object;
END;

