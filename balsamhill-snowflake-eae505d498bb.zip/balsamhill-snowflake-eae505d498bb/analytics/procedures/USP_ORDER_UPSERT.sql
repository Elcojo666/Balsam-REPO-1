USE DATABASE DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    createdby INT;
    prcessedHeaderRecordCount INT;
    prcessedLineRecordCount INT;
    toBeProcessedLineRecordCount INT;
    toBeProcessedRecordCount INT;
    detailprocesseddate TIMESTAMP_NTZ(9);
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

SET createdby := 1;

--BEGIN
-- New orders start
TRUNCATE TABLE  TRANSFORMED.stg_ORDER_processed_order_header;
--END;

-- Use session variables for processed record counts
SET prcessedHeaderRecordCount := 0;
SET prcessedLineRecordCount := 0;
--END;

-- Update statements
UPDATE analytics.log_files_import_status lofis
SET lofis.processed = :prcessedHeaderRecordCount 
WHERE lofis.file_name = ''YFS_ORDER_HEADER'';

UPDATE analytics.log_files_import_status lofis
SET lofis.processed = :prcessedLineRecordCount
WHERE lofis.file_name = ''YFS_ORDER_LINE'';

-- Populating order line keys start
CREATE OR REPLACE TEMPORARY TABLE analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS (
    order_header_key STRING,
    order_line_key STRING,
    ITEM_ID STRING,
    PRIME_LINE_NO STRING,
    pk_skuproductid INT
);

INSERT INTO analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS
SELECT DISTINCT sol.order_header_key,
       sol.order_line_key,
       sol.ITEM_ID,
       sol.PRIME_LINE_NO,
       dsl.pk_skuproductid
FROM TRANSFORMED.stg_ORDER_line sol
INNER JOIN analytics.ext_order_header eoh ON eoh.order_header_key = sol.order_header_key AND eoh.order_name = ''MIGRATED''
INNER JOIN analytics.sku_product dsl ON dsl.sku_code = sol.ITEM_ID
WHERE eoh.order_name = ''MIGRATED'';

INSERT INTO analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS
SELECT DISTINCT sol.order_header_key,
       sol.order_line_key,
       sol.ITEM_ID,
       sol.PRIME_LINE_NO,
       dsl.pk_skuproductid
FROM   TRANSFORMED.stg_ORDER_line sol
INNER JOIN   RAW.raw_ORDER_header eoh ON eoh.order_header_key = sol.order_header_key AND eoh.order_name = ''MIGRATED''
INNER JOIN analytics.sku_product dsl ON dsl.sku_code = sol.ITEM_ID
WHERE eoh.order_name = ''MIGRATED'';

INSERT INTO analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS
SELECT DISTINCT sol.order_header_key,
       sol.order_line_key,
       sol.ITEM_ID,
       sol.PRIME_LINE_NO,
       dsl.pk_skuproductid
FROM TRANSFORMED.stg_ORDER_line sol
INNER JOIN ARCHIVE.arc_raw_ORDER_header eoh ON eoh.order_header_key = sol.order_header_key AND eoh.order_name = ''MIGRATED''
INNER JOIN analytics.sku_product dsl ON dsl.sku_code = sol.ITEM_ID
WHERE eoh.order_name = ''MIGRATED'';

-- Delete duplicate
DELETE FROM  analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS
USING (
    SELECT order_line_key,
           ROW_NUMBER() OVER (PARTITION BY order_line_key ORDER BY order_line_key) AS revision
    FROM analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS
) h
WHERE analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS.order_line_key = h.order_line_key
AND h.revision > 1;

-- Delete already populated
DELETE FROM analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS stg
USING analytics.txn_order_detail tod
WHERE tod.order_line_key = stg.order_line_key;

-- Update txn_order_detail
UPDATE analytics.txn_order_detail tod
SET tod.order_header_key = t1.order_header_key,
    tod.order_line_key = t1.order_line_key,
    tod.ext_line_id = t1.order_line_key
FROM analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS t1
INNER JOIN analytics.txn_order_header toh ON toh.order_header_key = t1.order_header_key
WHERE toh.pk_order_headerid = tod.fk_order_headerid
AND t1.PRIME_LINE_NO = tod.prime_line_num
AND t1.pk_skuproductid = tod.fk_skuproductid
AND tod.order_header_key IS NULL
AND tod.order_line_key IS NULL
AND tod.ext_line_id IS NULL
AND t1.order_line_key IS NOT NULL
AND t1.order_header_key IS NOT NULL
AND t1.PRIME_LINE_NO IS NOT NULL
AND t1.pk_skuproductid IS NOT NULL;

-- Drop temporary table
DROP TABLE analytics.TEMP_POPULATE_KEYS_FOR_MIGRATED_ORDERS;



-- END

-- Creating temporary tables
CREATE OR REPLACE TEMPORARY TABLE analytics.TempORDER_Orders (
    pk_order_headerid BIGINT,
    fk_sourceid SMALLINT,
    source_ref_num STRING,
    ext_order_id STRING,
    is_domestic BOOLEAN,
    fk_shipping_addressid BIGINT,
    fk_billing_addressid BIGINT,
    fk_customerid BIGINT,
    fk_currencyid INT,
    fk_shipping_methodid SMALLINT,
    payment_amount NUMBER(9, 2),
    gross_amount NUMBER(9, 2),
    discount_amount NUMBER(9, 2),
    fee_amount NUMBER(9, 2),
    tax_amount NUMBER(9, 2),
    shpping_fee_amount NUMBER(9, 2),
    personalization_fee_amount NUMBER(9, 2),
    net_amount NUMBER(9, 2),
    fk_order_typeid SMALLINT,
    fk_order_statusid SMALLINT,
    fk_parent_order_headerid BIGINT,
    inserted_date TIMESTAMP_NTZ,
    modified_date TIMESTAMP_NTZ,
    order_date TIMESTAMP_NTZ,
    email_address STRING,
    order_comments STRING,
    order_notes STRING,
    tax_exempt BOOLEAN,
    salesrep_customerid STRING,
    risk_status STRING,
    ship_residential BOOLEAN,
    revision NUMBER(10),
    txn_id STRING,
    extn_order_locale_code STRING,
    seller_organization_code STRING,
    customer_first_name STRING,
    customer_last_name STRING,
    modifyuserid STRING,
    createuserid STRING,
    createts TIMESTAMP,
    entered_by STRING,
    is_bfy17 BOOLEAN DEFAULT FALSE,
    entry_type STRING,
    order_header_key STRING,
    extn_brand STRING,
    extn_sub_order_type STRING,
    EXTN_ORDER_TOTAL STRING
);

CREATE OR REPLACE TEMPORARY TABLE analytics.TempOrderDetails (
    fk_order_headerid BIGINT NOT NULL,
    fk_skuproductid INT NOT NULL,
    quantity INT NOT NULL,
    product_price NUMBER(9, 2) NOT NULL,
    total_price NUMBER(9, 2) NOT NULL,
    is_taxable BOOLEAN,
    options STRING,
    personalization_fee NUMBER(9, 2),
    product_name STRING,
    created_by INT,
    created_date TIMESTAMP_NTZ,
    modified_date TIMESTAMP_NTZ,
    pk_order_detailid BIGINT NOT NULL,
    Revision INT,
    prime_line_num INT,
    txn_id STRING,
    ext_line_id STRING,
    order_header_key STRING,
    order_line_key STRING
);

CREATE OR REPLACE TEMPORARY TABLE analytics.createdOrders (
    order_header_key VARCHAR,
    enterprise_key VARCHAR,
    order_no VARCHAR,
    sourcing_classification VARCHAR,
    buyer_organization_code VARCHAR,
    seller_organization_code VARCHAR,
    document_type VARCHAR,
    bill_to_key VARCHAR,
    bill_to_id VARCHAR,
    customer_rewards_no VARCHAR,
    vendor_id VARCHAR,
    ship_to_key VARCHAR,
    ship_to_id VARCHAR,
    ship_node VARCHAR,
    receiving_node VARCHAR,
    buyer_receiving_node_id VARCHAR,
    mark_for_key VARCHAR,
    buyer_mark_for_node_id VARCHAR,
    req_delivery_date VARCHAR,
    req_cancel_date VARCHAR,
    req_ship_date VARCHAR,
    default_template VARCHAR,
    division VARCHAR,
    order_date VARCHAR,
    order_type VARCHAR,
    draft_order_flag VARCHAR,
    order_purpose VARCHAR,
    return_oh_key_for_exchange VARCHAR,
    exchange_type VARCHAR,
    pending_transfer_in VARCHAR,
    return_by_gift_recipient VARCHAR,
    allocation_rule_id VARCHAR,
    priority_code VARCHAR,
    priority_number VARCHAR,
    contact_key VARCHAR,
    scac VARCHAR,
    carrier_service_code VARCHAR,
    custcarrier_account_no VARCHAR,
    notify_after_shipment_flag VARCHAR,
    created_at_node VARCHAR,
    has_derived_child VARCHAR,
    has_derived_parent VARCHAR,
    notification_type VARCHAR,
    notification_reference VARCHAR,
    entry_type VARCHAR,
    authorized_client VARCHAR,
    entered_by VARCHAR,
    personalize_code VARCHAR,
    hold_flag VARCHAR,
    hold_reason_code VARCHAR,
    customer_po_no VARCHAR,
    customer_customer_po_no VARCHAR,
    order_name VARCHAR,
    payment_rule_id VARCHAR,
    terms_code VARCHAR,
    delivery_code VARCHAR,
    charge_actual_freight VARCHAR,
    tax VARCHAR,
    total_amount VARCHAR,
    original_total_amount VARCHAR,
    original_tax VARCHAR,
    currency VARCHAR,
    enterprise_currency VARCHAR,
    reporting_conversion_rate VARCHAR,
    reporting_conversion_date VARCHAR,
    payment_status VARCHAR,
    authorization_expiration_date VARCHAR,
    search_criteria_1 VARCHAR,
    search_criteria_2 VARCHAR,
    customer_emailid VARCHAR,
    fob VARCHAR,
    total_adjustment_amount VARCHAR,
    other_charges VARCHAR,
    price_program_key VARCHAR,
    taxpayer_id VARCHAR,
    tax_jurisdiction VARCHAR,
    tax_exempt_flag VARCHAR,
    tax_exemption_certificate VARCHAR,
    purpose VARCHAR,
    invoice_complete VARCHAR,
    order_closed VARCHAR,
    next_alert_ts VARCHAR,
    do_not_consolidate VARCHAR,
    chain_type VARCHAR,
    adjustment_invoice_pending VARCHAR,
    auto_cancel_date VARCHAR,
    sale_voided VARCHAR,
    is_ship_complete VARCHAR,
    is_line_ship_complete VARCHAR,
    is_ship_single_node VARCHAR,
    is_line_ship_single_node VARCHAR,
    cancel_order_on_excp_flag VARCHAR,
    optimization_type VARCHAR,
    purge_history_date VARCHAR,
    pricing_classification_code VARCHAR,
    source_type VARCHAR,
    source_key VARCHAR,
    linked_source_key VARCHAR,
    original_container_key VARCHAR,
    sold_to_key VARCHAR,
    team_code VARCHAR,
    level_of_service VARCHAR,
    next_iter_seq_no VARCHAR,
    next_iter_date VARCHAR,
    hrs_before_next_iter VARCHAR,
    createts VARCHAR,
    modifyts VARCHAR,
    createuserid VARCHAR,
    modifyuserid VARCHAR,
    createprogid VARCHAR,
    modifyprogid VARCHAR,
    lockid VARCHAR,
    department_code VARCHAR,
    buyer_user_id VARCHAR,
    recreate_authorizations VARCHAR,
    customer_contact_id VARCHAR,
    opportunity_key VARCHAR,
    is_expiration_date_overridden VARCHAR,
    expiration_date VARCHAR,
    approval_cycle VARCHAR,
    in_store_payment_required VARCHAR,
    immediate_settlement_value VARCHAR,
    customer_age VARCHAR,
    cart_id VARCHAR,
    rollout_version VARCHAR,
    all_addresses_verified VARCHAR,
    compl_gift_box_qty VARCHAR,
    no_of_auth_strikes VARCHAR,
    source_ip_address VARCHAR,
    customer_first_name VARCHAR,
    customer_last_name VARCHAR,
    customer_phone_no VARCHAR,
    customer_zip_code VARCHAR,
    index_version VARCHAR,
    extn_customer_type VARCHAR,
    extn_customer_id VARCHAR,
    extn_cba_ship_label VARCHAR,
    extn_amazon_tfm VARCHAR,
    extn_tfm_ship_status VARCHAR,
    extn_financed_by_affirm VARCHAR,
    extn_risk_status VARCHAR,
    extn_sales_rep_cust_id VARCHAR,
    extn_latest_ship_date VARCHAR,
    extn_latest_delivery_date VARCHAR,
    extn_market_place_id VARCHAR,
    extn_order_status VARCHAR,
    extn_is_prime VARCHAR,
    extn_ga_tag_id VARCHAR,
    extn_fraud_status VARCHAR,
    extn_order_locale_code VARCHAR,
    extn_shipto_firstname VARCHAR,
    extn_shipto_lastname VARCHAR,
    extn_shipto_zipcode VARCHAR,
    extn_giftee_full_name VARCHAR,
    extn_giftee_email_id VARCHAR,
    extn_sms_opt_in VARCHAR,
    imported_date VARCHAR,
    txn_id VARCHAR,
    order_status VARCHAR,
    extn_brand VARCHAR,
    extn_sub_order_type VARCHAR,
    extn_order_total VARCHAR,
    extn_return_confirmed_by VARCHAR,
    extn_edi_gcn VARCHAR,
    extn_pk_header_key VARCHAR,
    extn_merchant_id VARCHAR,
    extn_is_avalara VARCHAR,
    extn_req_cancel_date VARCHAR,
    extn_is_email_sent VARCHAR,
    extn_is_txn_committed VARCHAR,
    extn_tax_txn_date VARCHAR,
    extn_last_refund_txn_code VARCHAR,
    extn_refund_txn_code VARCHAR,
    extn_min_estimated_delivery_date VARCHAR,
    extn_max_estimated_delivery_date VARCHAR,
    extn_apply_migration_hold VARCHAR,
    extn_signifyd_order_id VARCHAR,
    extn_primary_reason VARCHAR,
    extn_secondary_reason VARCHAR,
    extn_sales_entry_type VARCHAR,
    extn_sales_order_type VARCHAR,
    extn_warranty_order_no VARCHAR,
    extn_seller_payment_type VARCHAR
);

-- Create temporary tables
CREATE OR REPLACE TEMPORARY TABLE analytics.CREATEDORDERCUSTOMER (
    pk_customerid BIGINT NOT NULL,
    EXTN_CUSTOMER_ID VARCHAR NULL,
    ship_to_key VARCHAR NOT NULL,
    pk_sourceid INT NOT NULL
);

CREATE OR REPLACE TEMPORARY TABLE analytics.CREATEDORDERADDRESSTABLE (
    shipid VARCHAR NOT NULL,
    billid VARCHAR NOT NULL,
    BILL_TO_KEY VARCHAR NOT NULL,
    SHIP_TO_KEY VARCHAR NOT NULL
);



truncate table TRANSFORMED.stg_ORDER_processed_order_header;
INSERT INTO analytics.createdOrders
SELECT DISTINCT 
    ord.*
FROM
    TRANSFORMED.stg_ORDER_header AS ord
    LEFT JOIN analytics.txn_order_header AS ordheadrer ON ordheadrer.source_ref_num = ord.ORDER_NO
WHERE
    ordheadrer.pk_order_headerid IS NULL AND (order_name IS NULL OR order_name = ''EXTEND_CANCEL'' OR order_name = ''GLADLY_RETURN'');

UPDATE analytics.createdOrders
SET order_status = ''1100''
WHERE order_status IS NULL OR order_status = '''';

-- Creating customer ID order create table
CREATE OR REPLACE TEMPORARY TABLE analytics.CUSTOMER_IDS_ORDER_CREATE_ORDER_ (
    customer_id VARCHAR NOT NULL
);

INSERT INTO analytics.CUSTOMER_IDS_ORDER_CREATE_ORDER_
SELECT DISTINCT EXTN_CUSTOMER_ID 
FROM analytics.createdOrders
WHERE EXTN_CUSTOMER_ID IS NOT NULL;

INSERT INTO analytics.CUSTOMER_IDS_ORDER_CREATE_ORDER_
SELECT DISTINCT ship_to_key 
FROM analytics.createdOrders;

-- Creating DIM customer data table
CREATE OR REPLACE TEMPORARY TABLE analytics.DIMCUSTOMERDATA_FOR_ORDER_CREATE_ORDER_ (
    pk_customerid BIGINT NOT NULL,
    fk_sourceid SMALLINT NOT NULL,
    source_ref_num VARCHAR(50) NOT NULL
);

INSERT INTO analytics.DIMCUSTOMERDATA_FOR_ORDER_CREATE_ORDER_
SELECT DISTINCT 
    pk_customerid,
    fk_sourceid,
    source_ref_num
FROM analytics.customer AS d
INNER JOIN analytics.CUSTOMER_IDS_ORDER_CREATE_ORDER_ AS t ON t.customer_id = d.source_ref_num;



INSERT INTO analytics.CREATEDORDERCUSTOMER
WITH DistinctCustomerInfo1 AS (
    SELECT
        MIN(cus.pk_customerid) AS pk_customerid,
        ord.EXTN_CUSTOMER_ID,
        ord.ship_to_key,
        src.pk_sourceid
    FROM
        analytics.createdOrders AS ord
    INNER JOIN
        master.entrytype_platform_map AS pl
        ON pl.entry_type = ord.ENTRY_TYPE AND pl.Order_Type = ord.Order_Type
    INNER JOIN
        master.source_brand_platform_map AS src
        ON src.BrandCodeForWHM = ANALYTICS.fun_get_edw_brand_by_ORDER_sellerorgcode(ord.SELLER_ORGANIZATION_CODE)
        AND src.PlatformName = COALESCE(pl.customer_platform_name, pl.platform_name)
    INNER JOIN
        analytics.DIMCUSTOMERDATA_FOR_ORDER_CREATE_ORDER_ AS cus
        ON (cus.source_ref_num = ord.EXTN_CUSTOMER_ID AND cus.fk_sourceid = src.pk_sourceid)
        OR (cus.source_ref_num = ord.EXTN_CUSTOMER_ID AND ord.Order_Type = ''WARRANTY'')
        OR (ord.EXTN_CUSTOMER_ID IS NULL AND cus.source_ref_num = ord.ship_to_key AND cus.fk_sourceid = src.pk_sourceid)
    GROUP BY
        ord.EXTN_CUSTOMER_ID,
        ord.ship_to_key,
        src.pk_sourceid
)
SELECT DISTINCT
    pk_customerid,
    EXTN_CUSTOMER_ID,
    ship_to_key,
    pk_sourceid
FROM
    DistinctCustomerInfo1;


-- Dropping temporary tables
DROP TABLE IF EXISTS ANALYTICS.CUSTOMER_IDS_ORDER_CREATE_ORDER_;
DROP TABLE IF EXISTS ANALYTICS.DIMCUSTOMERDATA_FOR_ORDER_CREATE_ORDER_;

-- Uncomment and adjust the following lines if needed
--INSERT INTO CREATEDORDERADDRESSTABLE
--SELECT DISTINCT
--    shipaddr.pk_addressid AS shipid,
--    billaddr.pk_addressid AS billid,
--    ord.BILL_TO_KEY,
--    ord.SHIP_TO_KEY
--FROM
--    createdOrders AS ord
--INNER JOIN txn_address AS shipaddr ON CAST(shipaddr.ext_address_id AS VARCHAR) = CAST(ord.SHIP_TO_KEY AS VARCHAR) AND shipaddr.fk_address_typeid = 1
--INNER JOIN txn_address AS billaddr ON CAST(billaddr.ext_address_id AS VARCHAR) = CAST(ord.BILL_TO_KEY AS VARCHAR) AND billaddr.fk_address_typeid = 2
--WHERE shipaddr.pk_addressid IS NOT NULL AND billaddr.pk_addressid IS NOT NULL;

INSERT INTO ANALYTICS.CREATEDORDERADDRESSTABLE
WITH DistinctAddresses1 AS (
    SELECT DISTINCT
        shipaddr.pk_addressid AS shipid,
        billaddr.pk_addressid AS billid,
        ord.BILL_TO_KEY,
        ord.SHIP_TO_KEY
    FROM
        ANALYTICS.createdOrders AS ord
    INNER JOIN
        ANALYTICS.txn_address AS shipaddr
        ON CAST(shipaddr.ext_address_id AS VARCHAR) = CAST(ord.SHIP_TO_KEY AS VARCHAR) AND shipaddr.fk_address_typeid = 1
    INNER JOIN
        ANALYTICS.txn_address AS billaddr
        ON CAST(billaddr.ext_address_id AS VARCHAR) = CAST(ord.BILL_TO_KEY AS VARCHAR) AND billaddr.fk_address_typeid = 2
    WHERE
        shipaddr.pk_addressid IS NOT NULL AND billaddr.pk_addressid IS NOT NULL
)
SELECT shipid, billid, BILL_TO_KEY, SHIP_TO_KEY
FROM DistinctAddresses1;


--BEGIN 
-- Insert into stg_ORDER_processed_order_header
INSERT INTO TRANSFORMED.stg_ORDER_processed_order_header (
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    salesrep_customerid,
    inserted_date,
    modified_date,
    order_date,
    email_address,
    order_comments,
    order_notes,
    tax_exempt,
    risk_status,
    ship_residential,
    is_bfy17,
    txn_id,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    entry_type,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total
)
SELECT DISTINCT
    src.pk_sourceid,
    ord.order_no,
    ord.ORDER_HEADER_KEY,
    CASE
        WHEN ord.SELLER_ORGANIZATION_CODE = ''BH_US'' THEN 1
        ELSE 0
    END,
    addr.shipid,
    addr.billid,
    cus.pk_customerid,
    curr.pk_currencyid,
    ship.pk_shipping_methodid,
    TO_DOUBLE(COALESCE(ord.TOTAL_AMOUNT, ''0'')),
    TO_DOUBLE(COALESCE(ord.ORIGINAL_TOTAL_AMOUNT, ''0'')),
    TO_DOUBLE(COALESCE(ord.TOTAL_ADJUSTMENT_AMOUNT, ''0'')),
    0,
    TO_DOUBLE(COALESCE(ord.tax, ''0'')),
    0,
    0,
    TO_DOUBLE(COALESCE(ord.TOTAL_AMOUNT, ''0'')),
    ordtype.pk_order_typeid,
    ordsts.pk_order_statusid,
    NULL,
    CASE
        WHEN ord.ENTRY_TYPE = ''Call Center'' THEN ord.ENTERED_BY
        ELSE ord.EXTN_SALES_REP_CUST_ID
    END,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    TO_TIMESTAMP_NTZ(
        SUBSTRING(order_date, 1, 4) || ''-'' || 
        SUBSTRING(order_date, 5, 2) || ''-'' || 
        SUBSTRING(order_date, 7, 2) || '' '' || 
        SUBSTRING(order_date, 9, 2) || '':'' || 
        SUBSTRING(order_date, 11, 2) || '':'' || 
        SUBSTRING(order_date, 13, 2)
    ),
    CASE
        WHEN ord.CUSTOMER_EMAILID LIKE ''________-____-____-____-____________|%'' THEN SUBSTRING(
            ord.CUSTOMER_EMAILID,
            CHARINDEX(''|'', ord.CUSTOMER_EMAILID) + 1,
            LEN(ord.CUSTOMER_EMAILID)
        )
        ELSE ord.CUSTOMER_EMAILID
    END,
    NULL,
    NULL,
    CASE
        WHEN ord.TAX_EXEMPT_FLAG = ''True'' OR ord.TAX_EXEMPT_FLAG = ''Y'' THEN 1
        ELSE 0
    END,
    ord.EXTN_RISK_STATUS,
    NULL,
    1,
    txn_id,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    ord.ENTRY_TYPE,
    ord.order_header_key,
    ord.extn_brand,
    ord.extn_sub_order_type,
    ord.extn_order_total
FROM
    ANALYTICS.createdOrders AS ord
INNER JOIN master.entrytype_platform_map AS pl ON pl.entry_type = ord.ENTRY_TYPE AND pl.Order_Type = ord.Order_Type
INNER JOIN master.source_brand_platform_map AS src ON src.BrandCodeForWHM = ANALYTICS.fun_get_edw_brand_by_ORDER_sellerorgcode(ord.SELLER_ORGANIZATION_CODE) AND src.PlatformName = COALESCE(pl.customer_platform_name, pl.platform_name)
INNER JOIN ANALYTICS.CREATEDORDERADDRESSTABLE AS addr ON addr.SHIP_TO_KEY = ord.SHIP_TO_KEY AND addr.BILL_TO_KEY = ord.BILL_TO_KEY
INNER JOIN MASTER.dim_order_type AS ordtype ON ord.ORDER_TYPE = ordtype.order_type_name
INNER JOIN MASTER.dim_currency AS curr ON curr.currency_code = ord.currency
INNER JOIN MASTER.dim_shipping_method AS ship ON (
    UPPER(ship.shipping_method_name) = UPPER(ord.LEVEL_OF_SERVICE) OR 
    (UPPER(ship.shipping_method_name) = UPPER(''CC_Return_Order'') AND ord.document_type = 3) OR 
    (ord.LEVEL_OF_SERVICE IS NULL AND UPPER(ship.shipping_method_name) = ''NA'' AND ord.Order_Type = ''WARRANTY'' AND ord.entry_type = ''Call Center'' AND ord.document_type = 1)
)
INNER JOIN MASTER.dim_order_status AS ordsts ON ordsts.oms_ORDER_status_code = ord.order_status
INNER JOIN ANALYTICS.CREATEDORDERCUSTOMER AS cus ON (
    (ord.EXTN_CUSTOMER_ID IS NOT NULL AND cus.extn_customer_id IS NOT NULL AND cus.EXTN_CUSTOMER_ID = ord.EXTN_CUSTOMER_ID AND cus.pk_sourceid = src.pk_sourceid) OR 
    (ord.EXTN_CUSTOMER_ID IS NULL AND cus.extn_customer_id IS NULL AND cus.ship_to_key = ord.ship_to_key AND cus.pk_sourceid = src.pk_sourceid)
)
WHERE ord.ENTRY_TYPE IS NOT NULL;

--END;



--BEGIN 
-- Insert into txn_order_header
INSERT INTO ANALYTICS.txn_order_header (
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    salesrep_customerid,
    inserted_date,
    modified_date,
    order_date,
    email_address,
    order_comments,
    order_notes,
    tax_exempt,
    risk_status,
    ship_residential,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    entry_type,
    is_bfy17,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total
)
SELECT DISTINCT
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    salesrep_customerid,
    CURRENT_TIMESTAMP() AS inserted_date,
    CURRENT_TIMESTAMP() AS modified_date,
    -- TO_TIMESTAMP_NTZ(
    --     SUBSTRING(order_date, 1, 4) || ''-'' || 
    --     SUBSTRING(order_date, 5, 2) || ''-'' || 
    --     SUBSTRING(order_date, 7, 2) || '' '' || 
    --     SUBSTRING(order_date, 9, 2) || '':'' || 
    --     SUBSTRING(order_date, 11, 2) || '':'' || 
    --     SUBSTRING(order_date, 13, 2)
    -- ) AS order_date,
    TO_TIMESTAMP_NTZ(order_date) as order_date,
    email_address,
    order_comments,
    order_notes,
    CASE
        WHEN tax_exempt = ''True'' OR tax_exempt = ''Y'' THEN 1
        ELSE 0
    END AS tax_exempt,
    risk_status,
    ship_residential,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    TRY_TO_TIMESTAMP(CREATETS,''YYYYMMDDHHMISS''),
    entered_by,
    entry_type,
    is_bfy17,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    try_cast(extn_order_total as float)
FROM
     TRANSFORMED.stg_ORDER_processed_order_header;

MERGE INTO ANALYTICS.txn_order_status tgt
USING (
    SELECT DISTINCT
        toh.pk_order_headerid,
        toh.fk_sourceid,
        toh.source_ref_num,
        toh.fk_order_statusid,
        toh.inserted_date,
        toh.modified_date
    FROM TRANSFORMED.stg_ORDER_processed_order_header stg
    INNER JOIN ANALYTICS.txn_order_header toh ON toh.source_ref_num = stg.source_ref_num
        AND stg.fk_sourceid = toh.fk_sourceid
) src
ON tgt.fk_order_headerid = src.pk_order_headerid
    AND tgt.source_ref_num = src.source_ref_num
    AND tgt.fk_sourceid = src.fk_sourceid
WHEN NOT MATCHED THEN
    INSERT (
        fk_order_headerid,
        fk_sourceid,
        source_ref_num,
        fk_order_statusid,
        inserted_date,
        modified_date
    )
    VALUES (
        src.pk_order_headerid,
        src.fk_sourceid,
        src.source_ref_num,
        src.fk_order_statusid,
        src.inserted_date,
        src.modified_date
    )
WHEN MATCHED THEN
    UPDATE SET
        tgt.fk_order_statusid = src.fk_order_statusid,
        tgt.modified_date = src.modified_date;

--END;      



--BEGIN
INSERT INTO ANALYTICS.TempORDER_Orders (
    pk_order_headerid,
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    inserted_date,
    modified_date,
    order_date,
    email_address,
    order_comments,
    order_notes,
    tax_exempt,
    risk_status,
    ship_residential,
    salesrep_customerid,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    entry_type,
    is_bfy17,
    revision,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total
)
SELECT DISTINCT 
    pk_order_headerid,
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    inserted_date,
    modified_date,
    order_date,
    email_address,
    order_comments,
    order_notes,
    tax_exempt,
    risk_status,
    ship_residential,
    salesrep_customerid,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    entry_type,
    is_bfy17,
    cast(1 as NUMBER(10, 0)) AS revision, -- Ensure default value is set
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total
FROM
    ANALYTICS.txn_order_header
WHERE
    order_header_key IN (
        SELECT order_header_key
        FROM TRANSFORMED.stg_ORDER_processed_order_header
    );

-- Create a temporary table to hold the maximum revision values
CREATE OR REPLACE TEMPORARY TABLE TempMaxRevision AS
SELECT
    MAX(aot.revision) AS max_revision,
    aot.pk_order_headerid
FROM
    ANALYTICS.audit_order_header AS aot
INNER JOIN
    ANALYTICS.TempORDER_Orders AS ttd
    ON ttd.pk_order_headerid = aot.pk_order_headerid
GROUP BY
    aot.pk_order_headerid;

-- Update TempORDER_Orders using the temporary table
UPDATE ANALYTICS.TempORDER_Orders AS ttd
SET
    Revision = CAST((tm.max_revision + 1) AS NUMBER(10, 0))
FROM
    TempMaxRevision AS tm
WHERE
    ttd.pk_order_headerid = tm.pk_order_headerid;

--END;

--BEGIN
INSERT INTO ANALYTICS.audit_order_header (
    pk_order_headerid,
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    inserted_date,
    modified_date,
    created_by,
    order_date,
    email_address,
    order_comments,
    order_notes,
    tax_exempt,
    salesrep_customerid,
    risk_status,
    ship_residential,
    revision,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    entry_type,
    is_bfy17,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total
)
SELECT DISTINCT
    insord.pk_order_headerid,
    insord.fk_sourceid,
    insord.source_ref_num,
    insord.ext_order_id,
    insord.is_domestic,
    insord.fk_shipping_addressid,
    insord.fk_billing_addressid,
    insord.fk_customerid,
    insord.fk_currencyid,
    insord.fk_shipping_methodid,
    insord.payment_amount,
    insord.gross_amount,
    insord.discount_amount,
    insord.fee_amount,
    insord.tax_amount,
    insord.shpping_fee_amount,
    insord.personalization_fee_amount,
    insord.net_amount,
    insord.fk_order_typeid,
    insord.fk_order_statusid,
    insord.fk_parent_order_headerid,
    insord.inserted_date,
    insord.modified_date,
    1 AS created_by,
    insord.order_date,
    insord.email_address,
    insord.order_comments,
    insord.order_notes,
    insord.tax_exempt,
    insord.salesrep_customerid,
    insord.risk_status,
    insord.ship_residential,
    ord.Revision,
    insord.extn_order_locale_code,
    insord.seller_organization_code,
    insord.customer_first_name,
    insord.customer_last_name,
    insord.modifyuserid,
    insord.createuserid,
    insord.createts,
    insord.entered_by,
    insord.entry_type,
    insord.is_bfy17,
    insord.order_header_key,
    insord.extn_brand,
    insord.extn_sub_order_type,
    insord.extn_order_total
FROM ANALYTICS.txn_order_header insord
INNER JOIN ANALYTICS.TempORDER_Orders ord ON ord.source_ref_num = insord.source_ref_num;
--END;

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.createdOrderDetails (
    pk_order_headerid STRING,
    pk_skuproductid STRING,
    ORDERED_QTY STRING,
    UNIT_PRICE STRING,
    LINE_TOTAL STRING,
    is_taxable STRING,
    options STRING,
    ITEM_SHORT_DESCRIPTION STRING,
    txn_id STRING,
    PRIME_LINE_NO STRING,
    source_ref_num STRING,
    order_line_status STRING,
    bh_product_name STRING,
    personalization_fee STRING,
    order_header_key STRING,
    order_line_key STRING
);


INSERT INTO ANALYTICS.createdOrderDetails
SELECT DISTINCT
    toh.pk_order_headerid,
    dsl.pk_skuproductid,
    ord.ORDERED_QTY,
    ord.UNIT_PRICE,
    ord.LINE_TOTAL,
    CASE
        WHEN ord.TAXABLE_FLAG = ''N'' THEN 0
        WHEN ord.TAXABLE_FLAG = ''Y'' THEN 1
    END AS is_taxable,
    ord.PERSONALIZE_CODE AS options,
    ord.ITEM_SHORT_DESCRIPTION,
    ord.txn_id,
    ord.PRIME_LINE_NO AS PRIME_LINE_NO,
    stgpoh.source_ref_num,
    ord.order_line_status,
    dsl.bh_product_name,
    0 AS personalization_fee,
    ord.order_header_key,
    ord.order_line_key
FROM
    TRANSFORMED.stg_ORDER_line AS ord
    INNER JOIN TRANSFORMED.stg_ORDER_processed_order_header AS stgpoh ON stgpoh.order_header_key = ord.ORDER_HEADER_KEY
    INNER JOIN ANALYTICS.TempORDER_Orders AS toh ON toh.order_header_key = ord.order_header_key AND stgpoh.fk_sourceid = toh.fk_sourceid
    INNER JOIN MASTER.dim_source AS src ON src.pk_sourceid = stgpoh.fk_sourceid
    INNER JOIN analytics.sku_product_locale AS dsl ON dsl.sku_code = ord.ITEM_ID AND dsl.locale = src.locale
WHERE
    toh.pk_order_headerid IS NOT NULL AND ord.BUNDLE_PARENT_ORDER_LINE_KEY IS NULL;


TRUNCATE TABLE TRANSFORMED.stg_ORDER_processed_order_line;

-- Create temporary table for intermediate results (createdOrderDetails)
detailprocesseddate := current_timestamp();

-- Insert data into stg_ORDER_processed_order_line
INSERT INTO TRANSFORMED.stg_ORDER_processed_order_line (
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    inserted_date,
    modified_date,
    txn_id,
    order_line_status,
    prime_line_num,
    ext_line_id,
    order_header_key,
    order_line_key
)
SELECT DISTINCT 
    ord.pk_order_headerid,
    ord.pk_skuproductid,
    SUM(TRY_CAST(COALESCE(ord.ORDERED_QTY, 0) AS NUMBER(18,5))),
    ord.UNIT_PRICE,
    SUM(TRY_CAST(COALESCE(ord.LINE_TOTAL, 0) AS NUMBER(18,5))),
    ord.is_taxable,
    ord.options,
    SUM(TRY_CAST(COALESCE(ord.personalization_fee, 0) AS NUMBER(18,5))),
    ord.bh_product_name,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    ord.txn_id,
    ord.order_line_status,
    ord.PRIME_LINE_NO,
    ord.ORDER_LINE_KEY,
    ord.order_header_key,
    ord.order_line_key
FROM
    ANALYTICS.createdOrderDetails AS ord
GROUP BY
    ord.pk_skuproductid,
    ord.UNIT_PRICE,
    ord.is_taxable,
    ord.source_ref_num,
    ord.order_line_status,
    ord.bh_product_name,
    ord.options,
    ord.pk_order_headerid,
    ord.txn_id,
    ord.PRIME_LINE_NO,
    ord.ORDER_LINE_KEY,
    ord.order_header_key,
    ord.order_line_key;



-- Insert into txn_order_detail and capture inserted records
INSERT INTO  ANALYTICS.txn_order_detail (
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    inserted_date,
    modified_date,
    prime_line_num,
    ext_line_id,
    order_header_key,
    order_line_key
)
SELECT DISTINCT 
    sol.fk_order_headerid,
    sol.fk_skuproductid,
    sol.quantity,
    sol.product_price,
    sol.total_price,
    sol.is_taxable,
    sol.options,
    sol.personalization_fee,
    sol.product_name,
    sol.inserted_date,
    sol.modified_date,
    sol.prime_line_num,
    sol.ext_line_id,
    sol.order_header_key,
    sol.order_line_key
FROM
    TRANSFORMED.stg_ORDER_processed_order_line AS sol
    LEFT JOIN ANALYTICS.txn_order_detail AS tod ON tod.fk_order_headerid = sol.fk_order_headerid
        AND tod.fk_skuproductid = sol.fk_skuproductid
        AND tod.prime_line_num = sol.prime_line_num
WHERE
    tod.pk_order_detailid IS NULL;


INSERT INTO ANALYTICS.TempOrderDetails(
    pk_order_detailid, 
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    created_by, 
    CREATED_DATE,
    MODIFIED_DATE,
    revision,
    prime_line_num,
    ext_line_id,
    order_header_key,
    order_line_key

)
SELECT DISTINCT 
     pk_order_detailid,
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    ''system'' AS created_by, -- Replace with the appropriate user or system
    inserted_date,
    modified_date,
    CAST(1 AS NUMBER(10, 0)) AS revision,
    prime_line_num,
    ext_line_id,
    order_header_key,
    order_line_key
    from ANALYTICS.txn_order_detail 
    where inserted_date >= :detailprocesseddate or 
    modified_date >= :detailprocesseddate ;
    
-- SELECT DISTINCT 
--      pk_order_detailid
--     sol.fk_order_headerid,
--     sol.fk_skuproductid,
--     sol.quantity,
--     sol.product_price,
--     sol.total_price,
--     sol.is_taxable,
--     sol.options,
--     sol.personalization_fee,
--     sol.product_name,
--     ''system'' AS created_by, -- Replace with the appropriate user or system
--     CURRENT_TIMESTAMP(),
--     CURRENT_TIMESTAMP(),
--     CAST(1 AS NUMBER(10, 0)) AS revision,
--     sol.prime_line_num,
--     sol.ext_line_id,
--     sol.order_header_key,
--     sol.order_line_key
-- FROM
--     TRANSFORMED.stg_ORDER_processed_order_line AS sol
--     LEFT JOIN   ANALYTICS.txn_order_detail AS tod ON tod.fk_order_headerid = sol.fk_order_headerid
--         AND tod.fk_skuproductid = sol.fk_skuproductid
--         AND tod.prime_line_num = sol.prime_line_num
-- where
--     tod.pk_order_detailid IS NULL;




-- UPDATE
-- 	ANALYTICS.TempOrderDetails
-- SET
-- 	Revision = CAST((aot.revision + 1) as int)
-- FROM
--         ANALYTICS.TempOrderDetails as ttd
--         inner join (
-- 		SELECT
--             MAX(aot.revision) as revision,
--             aot.pk_order_detailid,
--             aot.fk_order_headerid
--         from
--             ANALYTICS.audit_order_detail as aot
--             inner join ANALYTICS.TempOrderDetails as ttd on ttd.pk_order_detailid = aot.pk_order_detailid and ttd.fk_order_headerid = aot.fk_order_headerid
--         group by
-- 			aot.pk_order_detailid,
-- 			aot.fk_order_headerid
-- 	) as aot on ttd.pk_order_detailid = aot.pk_order_detailid
--             and ttd.fk_order_headerid = aot.fk_order_headerid;            

                 MERGE INTO ANALYTICS.TempOrderDetails AS ttd
USING (
    SELECT
        MAX(aot.revision) AS revision,
        aot.pk_order_detailid,
        aot.fk_order_headerid
    FROM
        ANALYTICS.audit_order_detail AS aot
    GROUP BY
        aot.pk_order_detailid,
        aot.fk_order_headerid
) AS src
ON ttd.pk_order_detailid = src.pk_order_detailid
   AND ttd.fk_order_headerid = src.fk_order_headerid
WHEN MATCHED THEN
    UPDATE SET
        ttd.Revision = CAST((src.revision + 1) AS INT);
 


INSERT INTO ANALYTICS.audit_order_detail (
    pk_order_detailid,
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    created_by,
    created_date,
    modified_date,
    revision,
    order_header_key,
    order_line_key
)
SELECT
    pk_order_detailid,
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    created_by,
    created_date,
    modified_date,
    revision,
    order_header_key,
    order_line_key
FROM
    ANALYTICS.TempOrderDetails;


MERGE INTO ANALYTICS.txn_order_detail_status AS Target
USING (
    SELECT DISTINCT
        stg.fk_order_headerid,
        tod.pk_order_detailid,
        pk_order_statusid,
        stg.fk_skuproductid
    FROM
        TRANSFORMED.stg_ORDER_processed_order_line AS stg
    INNER JOIN ANALYTICS.TempOrderDetails AS tod ON tod.fk_order_headerid = stg.fk_order_headerid
        AND stg.fk_skuproductid = tod.fk_skuproductid
    INNER JOIN MASTER.dim_order_status AS dods ON dods.oms_ORDER_status_code = stg.order_line_status
) AS Source ON Source.fk_order_headerid = Target.pk_order_headerid
    AND Source.fk_skuproductid = Target.fk_skuproductid
    AND Source.pk_order_detailid = Target.pk_order_detailid
WHEN NOT MATCHED THEN
INSERT (pk_order_headerid, pk_order_detailid, fk_ORDER__detail_statusid, fk_skuproductid)
VALUES (Source.fk_order_headerid, Source.pk_order_detailid, Source.pk_order_statusid, Source.fk_skuproductid);

-- Update transaction record count and status
SELECT
    COUNT(*) INTO :prcessedHeaderRecordCount
FROM
    ANALYTICS.TempORDER_Orders;

SELECT
    COUNT(*) INTO :prcessedLineRecordCount
FROM
    ANALYTICS.TempOrderDetails;


MERGE INTO RAW.raw_ORDER_header AS target
USING (
    SELECT DISTINCT
        roh.ORDER_NO,
        roh.ORDER_HEADER_KEY,
        roh.modifyts,
        ''Processed'' AS processing_status,
        '''' AS processing_comment,
        '''' AS processing_errortype
    FROM RAW.raw_ORDER_header AS roh
    INNER JOIN TRANSFORMED.stg_ORDER_header AS rod 
        ON rod.ORDER_NO = roh.ORDER_NO 
        AND rod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY 
        AND roh.modifyts = rod.modifyts
    LEFT JOIN ANALYTICS.TempORDER_Orders AS tod 
        ON tod.source_ref_num = roh.ORDER_NO 
        AND tod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY
    WHERE 
        roh.processing_status IN (''Pending'', ''Failed'')
        AND tod.source_ref_num IS NOT NULL
) AS source
ON (target.ORDER_NO = source.ORDER_NO AND target.ORDER_HEADER_KEY = source.ORDER_HEADER_KEY AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;

MERGE INTO RAW.raw_ORDER_line AS target
USING (
    SELECT DISTINCT 
        roh.ORDER_LINE_KEY,
        roh.PRIME_LINE_NO,
        roh.modifyts,
        ''Processed'' AS processing_status,
        '''' AS processing_comment,
        '''' AS processing_errortype
    FROM RAW.raw_ORDER_line AS roh
    INNER JOIN TRANSFORMED.stg_ORDER_line AS rod 
        ON rod.ORDER_LINE_KEY = roh.ORDER_LINE_KEY
        AND rod.PRIME_LINE_NO = roh.PRIME_LINE_NO 
        AND roh.modifyts = rod.modifyts
    INNER JOIN ANALYTICS.TempOrderDetails AS tod 
        ON tod.ext_line_id = roh.ORDER_LINE_KEY 
        AND tod.prime_line_num = rod.PRIME_LINE_NO
    WHERE 
        roh.processing_status IN (''Pending'', ''Failed'')
) AS source
ON (target.ORDER_LINE_KEY = source.ORDER_LINE_KEY 
    AND target.PRIME_LINE_NO = source.PRIME_LINE_NO 
    AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;




CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.TempAmendOrders (
    pk_order_headerid BIGINT,
    fk_sourceid SMALLINT,
    source_ref_num VARCHAR(100),
    ext_order_id VARCHAR(255),
    is_domestic BOOLEAN,
    fk_shipping_addressid BIGINT,
    fk_billing_addressid BIGINT,
    fk_customerid BIGINT,
    fk_currencyid INT,
    fk_shipping_methodid SMALLINT,
    payment_amount DECIMAL(9, 2),
    gross_amount DECIMAL(9, 2),
    discount_amount DECIMAL(9, 2),
    fee_amount DECIMAL(9, 2),
    tax_amount DECIMAL(9, 2),
    shpping_fee_amount DECIMAL(9, 2),
    personalization_fee_amount DECIMAL(9, 2),
    net_amount DECIMAL(9, 2),
    fk_order_typeid SMALLINT,
    fk_order_statusid SMALLINT,
    fk_parent_order_headerid BIGINT,
    inserted_date TIMESTAMP,
    modified_date TIMESTAMP,
    order_date TIMESTAMP,
    email_address VARCHAR(255),
    order_comments VARCHAR,
    order_notes VARCHAR,
    tax_exempt BOOLEAN,
    salesrep_customerid VARCHAR,
    risk_status VARCHAR,
    ship_residential BOOLEAN,
    revision VARCHAR(255),
    txn_id VARCHAR,
    extn_order_locale_code VARCHAR,
    seller_organization_code VARCHAR,
    customer_first_name VARCHAR,
    customer_last_name VARCHAR,
    modifyuserid VARCHAR,
    createuserid VARCHAR,
    createts VARCHAR,
    entered_by VARCHAR,
    is_bfy17 BOOLEAN DEFAULT FALSE,
    entry_type VARCHAR(255),
    order_header_key VARCHAR(255),
	extn_brand VARCHAR(255),
	extn_sub_order_type VARCHAR(255),
	extn_order_total VARCHAR(255)
);

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.TempAmendOrderDetails (
    fk_order_headerid BIGINT NOT NULL,
    fk_skuproductid INT NOT NULL,
    quantity INT NOT NULL,
    product_price DECIMAL(9, 2) NOT NULL,
    total_price DECIMAL(9, 2) NOT NULL,
    is_taxable BOOLEAN,
    options VARCHAR(255),
    personalization_fee DECIMAL(9, 2),
    product_name VARCHAR(255),
    created_by INT,
    created_date TIMESTAMP,
    modified_date TIMESTAMP,
    pk_order_detailid BIGINT NOT NULL,
    Revision INT,
    prime_line_num INT,
    txn_id VARCHAR,
    ext_line_id VARCHAR,
    order_header_key VARCHAR,
    order_line_key VARCHAR,
    extn_return_confirmed_by VARCHAR,
    extn_edi_gcn VARCHAR,
    extn_pk_header_key VARCHAR,
    extn_merchant_id VARCHAR,
    extn_is_avalara VARCHAR,
    extn_req_cancel_date VARCHAR,
    extn_is_email_sent VARCHAR,
    extn_is_txn_committed VARCHAR,
    extn_tax_txn_date VARCHAR,
    extn_last_refund_txn_code VARCHAR,
    extn_refund_txn_code VARCHAR,
    extn_min_estimated_delivery_date VARCHAR,
    extn_max_estimated_delivery_date VARCHAR,
    extn_apply_migration_hold VARCHAR,
    extn_signifyd_order_id VARCHAR,
    extn_primary_reason VARCHAR,
    extn_secondary_reason VARCHAR,
    extn_sales_entry_type VARCHAR,
    extn_sales_order_type VARCHAR,
    extn_warranty_order_no VARCHAR,
    extn_seller_payment_type VARCHAR
);

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.updatedOrders(
    order_header_key VARCHAR,
    enterprise_key VARCHAR,
    order_no VARCHAR,
    sourcing_classification VARCHAR,
    buyer_organization_code VARCHAR,
    seller_organization_code VARCHAR,
    document_type VARCHAR,
    bill_to_key VARCHAR,
    bill_to_id VARCHAR,
    customer_rewards_no VARCHAR,
    vendor_id VARCHAR,
    ship_to_key VARCHAR,
    ship_to_id VARCHAR,
    ship_node VARCHAR,
    receiving_node VARCHAR,
    buyer_receiving_node_id VARCHAR,
    mark_for_key VARCHAR,
    buyer_mark_for_node_id VARCHAR,
    req_delivery_date VARCHAR,
    req_cancel_date VARCHAR,
    req_ship_date VARCHAR,
    default_template VARCHAR,
    division VARCHAR,
    order_date VARCHAR,
    order_type VARCHAR,
    draft_order_flag VARCHAR,
    order_purpose VARCHAR,
    return_oh_key_for_exchange VARCHAR,
    exchange_type VARCHAR,
    pending_transfer_in VARCHAR,
    return_by_gift_recipient VARCHAR,
    allocation_rule_id VARCHAR,
    priority_code VARCHAR,
    priority_number VARCHAR,
    contact_key VARCHAR,
    scac VARCHAR,
    carrier_service_code VARCHAR,
    custcarrier_account_no VARCHAR,
    notify_after_shipment_flag VARCHAR,
    created_at_node VARCHAR,
    has_derived_child VARCHAR,
    has_derived_parent VARCHAR,
    notification_type VARCHAR,
    notification_reference VARCHAR,
    entry_type VARCHAR,
    authorized_client VARCHAR,
    entered_by VARCHAR,
    personalize_code VARCHAR,
    hold_flag VARCHAR,
    hold_reason_code VARCHAR,
    customer_po_no VARCHAR,
    customer_customer_po_no VARCHAR,
    order_name VARCHAR,
    payment_rule_id VARCHAR,
    terms_code VARCHAR,
    delivery_code VARCHAR,
    charge_actual_freight VARCHAR,
    tax VARCHAR,
    total_amount VARCHAR,
    original_total_amount VARCHAR,
    original_tax VARCHAR,
    currency VARCHAR,
    enterprise_currency VARCHAR,
    reporting_conversion_rate VARCHAR,
    reporting_conversion_date VARCHAR,
    payment_status VARCHAR,
    authorization_expiration_date VARCHAR,
    search_criteria_1 VARCHAR,
    search_criteria_2 VARCHAR,
    customer_emailid VARCHAR,
    fob VARCHAR,
    total_adjustment_amount VARCHAR,
    other_charges VARCHAR,
    price_program_key VARCHAR,
    taxpayer_id VARCHAR,
    tax_jurisdiction VARCHAR,
    tax_exempt_flag VARCHAR,
    tax_exemption_certificate VARCHAR,
    purpose VARCHAR,
    invoice_complete VARCHAR,
    order_closed VARCHAR,
    next_alert_ts VARCHAR,
    do_not_consolidate VARCHAR,
    chain_type VARCHAR,
    adjustment_invoice_pending VARCHAR,
    auto_cancel_date VARCHAR,
    sale_voided VARCHAR,
    is_ship_complete VARCHAR,
    is_line_ship_complete VARCHAR,
    is_ship_single_node VARCHAR,
    is_line_ship_single_node VARCHAR,
    cancel_order_on_excp_flag VARCHAR,
    optimization_type VARCHAR,
    purge_history_date VARCHAR,
    pricing_classification_code VARCHAR,
    source_type VARCHAR,
    source_key VARCHAR,
    linked_source_key VARCHAR,
    original_container_key VARCHAR,
    sold_to_key VARCHAR,
    team_code VARCHAR,
    level_of_service VARCHAR,
    next_iter_seq_no VARCHAR,
    next_iter_date VARCHAR,
    hrs_before_next_iter VARCHAR,
    createts VARCHAR,
    modifyts VARCHAR,
    createuserid VARCHAR,
    modifyuserid VARCHAR,
    createprogid VARCHAR,
    modifyprogid VARCHAR,
    lockid VARCHAR,
    department_code VARCHAR,
    buyer_user_id VARCHAR,
    recreate_authorizations VARCHAR,
    customer_contact_id VARCHAR,
    opportunity_key VARCHAR,
    is_expiration_date_overridden VARCHAR,
    expiration_date VARCHAR,
    approval_cycle VARCHAR,
    in_store_payment_required VARCHAR,
    immediate_settlement_value VARCHAR,
    customer_age VARCHAR,
    cart_id VARCHAR,
    rollout_version VARCHAR,
    all_addresses_verified VARCHAR,
    compl_gift_box_qty VARCHAR,
    no_of_auth_strikes VARCHAR,
    source_ip_address VARCHAR,
    customer_first_name VARCHAR,
    customer_last_name VARCHAR,
    customer_phone_no VARCHAR,
    customer_zip_code VARCHAR,
    index_version VARCHAR,
    extn_customer_type VARCHAR,
    extn_customer_id VARCHAR,
    extn_cba_ship_label VARCHAR,
    extn_amazon_tfm VARCHAR,
    extn_tfm_ship_status VARCHAR,
    extn_financed_by_affirm VARCHAR,
    extn_risk_status VARCHAR,
    extn_sales_rep_cust_id VARCHAR,
    extn_latest_ship_date VARCHAR,
    extn_latest_delivery_date VARCHAR,
    extn_market_place_id VARCHAR,
    extn_order_status VARCHAR,
    extn_is_prime VARCHAR,
    extn_ga_tag_id VARCHAR,
    extn_fraud_status VARCHAR,
    extn_order_locale_code VARCHAR,
    extn_shipto_firstname VARCHAR,
    extn_shipto_lastname VARCHAR,
    extn_shipto_zipcode VARCHAR,
    extn_giftee_full_name VARCHAR,
    extn_giftee_email_id VARCHAR,
    extn_sms_opt_in VARCHAR,
    imported_date VARCHAR,
    txn_id VARCHAR,
    order_status VARCHAR,
    extn_brand VARCHAR,
    extn_sub_order_type VARCHAR,
    extn_order_total VARCHAR,
    extn_return_confirmed_by VARCHAR,
    extn_edi_gcn VARCHAR,
    extn_pk_header_key VARCHAR,
    extn_merchant_id VARCHAR,
    extn_is_avalara VARCHAR,
    extn_req_cancel_date VARCHAR,
    extn_is_email_sent VARCHAR,
    extn_is_txn_committed VARCHAR,
    extn_tax_txn_date VARCHAR,
    extn_last_refund_txn_code VARCHAR,
    extn_refund_txn_code VARCHAR,
    extn_min_estimated_delivery_date VARCHAR,
    extn_max_estimated_delivery_date VARCHAR,
    extn_apply_migration_hold VARCHAR,
    extn_signifyd_order_id VARCHAR,
    extn_primary_reason VARCHAR,
    extn_secondary_reason VARCHAR,
    extn_sales_entry_type VARCHAR,
    extn_sales_order_type VARCHAR,
    extn_warranty_order_no VARCHAR,
    extn_seller_payment_type VARCHAR,
    pk_order_headerid VARCHAR not NULL
);

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.UPDATEDORDERCUSTOMER(
    pk_customerid BIGINT not null,
    EXTN_CUSTOMER_ID VARCHAR,
    ship_to_key VARCHAR not null,
    pk_sourceid INT not null
);

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.UPDATEDORDERADDRESSTABLE(
    shipid VARCHAR not null,
    billid VARCHAR not null,
    BILL_TO_KEY VARCHAR not null,
    SHIP_TO_KEY VARCHAR not null
);



truncate table TRANSFORMED.stg_ORDER_processed_order_header;

-- Update txn_order_header with ORDER_HEADER_KEY from raw_ORDER_header
UPDATE ANALYTICS.txn_order_header 
SET ORDER_HEADER_KEY = r.ORDER_HEADER_KEY
FROM ANALYTICS.txn_order_header AS t
INNER JOIN RAW.raw_ORDER_header AS r ON t.source_ref_num = r.order_no
WHERE r.processing_status <> ''Processed'' AND t.ORDER_HEADER_KEY IS NULL;

-- Insert into #updatedOrders
INSERT INTO ANALYTICS.updatedOrders
SELECT DISTINCT 
    ord.*,
    ordheadrer.pk_order_headerid
FROM TRANSFORMED.stg_ORDER_header AS ord
INNER JOIN ANALYTICS.txn_order_header AS ordheadrer ON ordheadrer.source_ref_num = ord.ORDER_NO
    AND ordheadrer.ORDER_HEADER_KEY = ord.ORDER_HEADER_KEY
LEFT JOIN ANALYTICS.createdOrders AS crorder ON crorder.order_no = ord.order_no
    AND crorder.ORDER_HEADER_KEY = ord.ORDER_HEADER_KEY
WHERE ordheadrer.pk_order_headerid IS NOT NULL AND crorder.order_no IS NULL;

-- Update txn_order_header based on conditions
UPDATE ANALYTICS.txn_order_header 
SET order_header_key = ord.order_header_key
FROM ANALYTICS.txn_order_header AS ordheadrer
INNER JOIN TRANSFORMED.stg_ORDER_header AS ord ON ordheadrer.source_ref_num = ord.customer_po_no
    AND ordheadrer.ORDER_HEADER_KEY = ord.ORDER_HEADER_KEY
INNER JOIN MASTER.dim_order_type o ON o.pk_order_typeid = ordheadrer.fk_order_typeid
INNER JOIN MASTER.dim_source s ON s.pk_sourceid = ordheadrer.fk_sourceid
INNER JOIN MASTER.dim_brand b ON b.pk_brandid = s.fk_brandid AND b.BrandCodeForWHM = ord.extn_brand
WHERE ordheadrer.pk_order_headerid IS NOT NULL AND ord.order_name = ''MIGRATED'' AND ordheadrer.order_header_key IS NULL;

INSERT INTO ANALYTICS.updatedOrders
SELECT DISTINCT 
    ord.*,
    ordheadrer.pk_order_headerid
FROM
    TRANSFORMED.stg_ORDER_header AS ord
INNER JOIN ANALYTICS.txn_order_header AS ordheadrer ON ordheadrer.source_ref_num = ord.customer_po_no
    AND ordheadrer.ORDER_HEADER_KEY = ord.ORDER_HEADER_KEY
INNER JOIN MASTER.dim_order_type o ON o.pk_order_typeid = ordheadrer.fk_order_typeid 
INNER JOIN MASTER.dim_source s ON s.pk_sourceid = ordheadrer.fk_sourceid
INNER JOIN MASTER.dim_brand b ON b.pk_brandid = s.fk_brandid AND b.BrandCodeForWHM = ord.extn_brand
WHERE ordheadrer.pk_order_headerid IS NOT NULL AND ord.order_name = ''MIGRATED'';


CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.CUSTOMER_IDS_ORDER_ORDER_ (
    customer_id VARCHAR NOT NULL
);

INSERT INTO ANALYTICS.CUSTOMER_IDS_ORDER_ORDER_
SELECT DISTINCT EXTN_CUSTOMER_ID 
FROM ANALYTICS.updatedOrders
WHERE EXTN_CUSTOMER_ID IS NOT NULL;

INSERT INTO ANALYTICS.CUSTOMER_IDS_ORDER_ORDER_
SELECT DISTINCT ship_to_key 
FROM ANALYTICS.updatedOrders;

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.DIMCUSTOMERDATA_FOR_ORDER_ORDER_ (
    pk_customerid BIGINT NOT NULL,
    fk_sourceid SMALLINT NOT NULL,
    source_ref_num NVARCHAR(50) NOT NULL
);

INSERT INTO ANALYTICS.DIMCUSTOMERDATA_FOR_ORDER_ORDER_
SELECT DISTINCT 
    pk_customerid,
    fk_sourceid,
    source_ref_num 
FROM analytics.customer AS d
INNER JOIN ANALYTICS.CUSTOMER_IDS_ORDER_ORDER_ AS t ON t.customer_id = d.source_ref_num;


INSERT INTO ANALYTICS.UPDATEDORDERCUSTOMER 
WITH DistinctCustomerInfo AS (
    SELECT
        MIN(cus.pk_customerid) AS pk_customerid,
        ord.EXTN_CUSTOMER_ID,
        ord.ship_to_key,
        src.pk_sourceid
    FROM ANALYTICS.updatedOrders AS ord
    INNER JOIN master.entrytype_platform_map AS pl
        ON pl.entry_type = ord.ENTRY_TYPE AND pl.Order_Type = ord.Order_Type
    INNER JOIN master.source_brand_platform_map AS src
        ON src.BrandCodeForWHM = ANALYTICS.fun_get_edw_brand_by_ORDER_sellerorgcode(ord.SELLER_ORGANIZATION_CODE)
        AND src.PlatformName = COALESCE(pl.customer_platform_name, pl.platform_name)
    INNER JOIN
        ANALYTICS.DIMCUSTOMERDATA_FOR_ORDER_ORDER_ AS cus
        ON (cus.source_ref_num = ord.EXTN_CUSTOMER_ID AND cus.fk_sourceid = src.pk_sourceid)
        OR (cus.source_ref_num = ord.EXTN_CUSTOMER_ID AND ord.Order_Type = ''WARRANTY'')
        OR (cus.source_ref_num = ord.ship_to_key AND cus.fk_sourceid = src.pk_sourceid)
    GROUP BY
        ord.EXTN_CUSTOMER_ID,
        ord.ship_to_key,
        src.pk_sourceid
)
SELECT DISTINCT
        pk_customerid,
        EXTN_CUSTOMER_ID,
        ship_to_key,
        pk_sourceid
 FROM DistinctCustomerInfo;

 

	drop table ANALYTICS.CUSTOMER_IDS_ORDER_ORDER_;
	drop table ANALYTICS.DIMCUSTOMERDATA_FOR_ORDER_ORDER_;

    INSERT INTO ANALYTICS.UPDATEDORDERADDRESSTABLE
WITH DistinctAddresses AS (
    SELECT DISTINCT
        shipaddr.pk_addressid AS shipid,
        billaddr.pk_addressid AS billid,
        ord.BILL_TO_KEY,
        ord.SHIP_TO_KEY
    FROM
        ANALYTICS.updatedOrders AS ord
    INNER JOIN
        ANALYTICS.txn_address AS shipaddr
        ON CAST(shipaddr.ext_address_id AS VARCHAR) = CAST(ord.SHIP_TO_KEY AS VARCHAR) AND shipaddr.fk_address_typeid = 1
    INNER JOIN
        ANALYTICS.txn_address AS billaddr
        ON CAST(billaddr.ext_address_id AS VARCHAR) = CAST(ord.BILL_TO_KEY AS VARCHAR) AND billaddr.fk_address_typeid = 2
    WHERE
        shipaddr.pk_addressid IS NOT NULL AND billaddr.pk_addressid IS NOT NULL
)
 SELECT shipid, billid, BILL_TO_KEY, SHIP_TO_KEY
FROM DistinctAddresses;


-- 1818 Originally
INSERT INTO TRANSFORMED.stg_ORDER_processed_order_header
(
    pk_order_headerid,
    fk_sourceid,
    source_ref_num,
    ext_order_id,
    is_domestic,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_customerid,
    fk_currencyid,
    fk_shipping_methodid,
    payment_amount,
    gross_amount,
    discount_amount,
    fee_amount,
    tax_amount,
    shpping_fee_amount,
    personalization_fee_amount,
    net_amount,
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid,
    salesrep_customerid,
    inserted_date,
    modified_date,
    order_date,
    email_address,
    order_comments,
    order_notes,
    tax_exempt,
    risk_status,
    ship_residential,
    is_bfy17,
    txn_id,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    entry_type,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total
)
SELECT DISTINCT
    ord.pk_order_headerid,
    src.pk_sourceid,
    ord.order_no,
    ord.ORDER_HEADER_KEY,
    CASE
        WHEN ord.SELLER_ORGANIZATION_CODE = ''BH_US'' THEN 1
        ELSE 0
    END AS is_domestic,
    NULL AS fk_shipping_addressid,
    NULL AS fk_billing_addressid,
    cus.pk_customerid,
    curr.pk_currencyid,
    NULL AS fk_shipping_methodid,
    TRY_CAST(ord.TOTAL_AMOUNT AS FLOAT),
    TRY_CAST(ord.ORIGINAL_TOTAL_AMOUNT AS FLOAT),
    TRY_CAST(ord.TOTAL_ADJUSTMENT_AMOUNT AS FLOAT),
    0 AS fee_amount,
    TRY_CAST(ord.tax AS FLOAT),
    0 AS shpping_fee_amount,
    0 AS personalization_fee_amount,
    TRY_CAST(ord.TOTAL_AMOUNT AS FLOAT),
    ordtype.pk_order_typeid,
    CASE WHEN ord.order_status IS NULL OR ord.order_status = '''' THEN -1 ELSE -2 END AS fk_order_statusid,
    NULL AS fk_parent_order_headerid,
    CASE
        WHEN ord.ENTRY_TYPE = ''Call Center'' THEN ord.ENTERED_BY
        ELSE ord.EXTN_SALES_REP_CUST_ID
    END AS salesrep_customerid,
    CURRENT_TIMESTAMP() AS inserted_date,
    CURRENT_TIMESTAMP() AS modified_date,
    TO_TIMESTAMP(SUBSTRING(order_date, 1, 4) || ''-'' || SUBSTRING(order_date, 5, 2) || ''-'' || SUBSTRING(order_date, 7, 2) || '' '' || SUBSTRING(order_date, 9, 2) || '':'' || SUBSTRING(order_date, 11, 2) || '':'' || SUBSTRING(order_date, 13, 2), ''YYYY-MM-DD HH24:MI:SS'') AS order_date,
    CASE 
        WHEN ord.CUSTOMER_EMAILID LIKE ''________-____-____-____-____________|%'' THEN SUBSTRING(ord.CUSTOMER_EMAILID, CHARINDEX(''|'', ord.CUSTOMER_EMAILID) + 1, LEN(ord.CUSTOMER_EMAILID))
        ELSE ord.CUSTOMER_EMAILID
    END AS email_address,
    NULL AS order_comments,
    NULL AS order_notes,
    CASE
        WHEN ord.TAX_EXEMPT_FLAG = ''True'' OR ord.TAX_EXEMPT_FLAG = ''Y'' THEN 1
        ELSE 0
    END AS tax_exempt,
    ord.EXTN_RISK_STATUS AS risk_status,
    1 AS ship_residential,
    1 AS is_bfy17,
    txn_id,
    extn_order_locale_code,
    seller_organization_code,
    customer_first_name,
    customer_last_name,
    modifyuserid,
    createuserid,
    createts,
    entered_by,
    ord.entry_type,
    ord.order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total
FROM
    ANALYTICS.updatedOrders AS ord
INNER JOIN
    master.entrytype_platform_map AS pl ON pl.entry_type = ord.ENTRY_TYPE AND pl.Order_Type = ord.Order_Type
INNER JOIN
    master.source_brand_platform_map AS src ON src.BrandCodeForWHM = ANALYTICS.fun_get_edw_brand_by_ORDER_sellerorgcode(ord.SELLER_ORGANIZATION_CODE) AND src.PlatformName = COALESCE(pl.customer_platform_name, pl.platform_name)
INNER JOIN
    MASTER.dim_order_type AS ordtype ON ord.ORDER_TYPE = ordtype.order_type_name
INNER JOIN
    MASTER.dim_currency AS curr ON curr.currency_code = ord.currency
LEFT JOIN
    ANALYTICS.updatedOrderCustomer AS cus ON (ord.EXTN_CUSTOMER_ID IS NOT NULL AND cus.extn_customer_id IS NOT NULL AND cus.EXTN_CUSTOMER_ID = ord.EXTN_CUSTOMER_ID AND cus.pk_sourceid = src.pk_sourceid)
    OR (ord.EXTN_CUSTOMER_ID IS NULL AND cus.extn_customer_id IS NULL AND cus.ship_to_key = ord.ship_to_key AND cus.pk_sourceid = src.pk_sourceid)
WHERE
    ord.ENTRY_TYPE IS NOT NULL;


MERGE INTO TRANSFORMED.stg_ORDER_processed_order_header AS sh
USING (
    SELECT ord.order_no, ord.order_header_key, ordsts.pk_order_statusid
    FROM ANALYTICS.updatedOrders AS ord
    JOIN MASTER.dim_order_status AS ordsts
    ON ordsts.oms_ORDER_status_code = ord.order_status
) AS src
ON sh.source_ref_num = src.order_no 
   AND sh.order_header_key = src.order_header_key
WHEN MATCHED AND sh.fk_order_statusid != src.pk_order_statusid
THEN UPDATE SET fk_order_statusid = src.pk_order_statusid;


-- Update TRANSFORMED.stg_ORDER_processed_order_header 
-- set fk_order_statusid = ordsts.pk_order_statusid
-- from  TRANSFORMED.stg_ORDER_processed_order_header as sh
-- inner join ANALYTICS.updatedOrders as ord on ord.order_no = sh.source_ref_num and ord.order_header_key = sh.order_header_key
-- inner join  MASTER.dim_order_status AS ordsts ON ordsts.oms_ORDER_status_code = ord.order_status;

--RETURN ''here'';

MERGE INTO ANALYTICS.txn_order_header AS tgt
USING (
    SELECT DISTINCT
        pk_order_headerid,
        fk_sourceid,
        source_ref_num,
        ext_order_id,
        is_domestic,
        fk_shipping_addressid,
        fk_billing_addressid,
        fk_customerid,
        fk_currencyid,
        fk_shipping_methodid,
        payment_amount,
        gross_amount,
        discount_amount,
        fee_amount,
        tax_amount,
        shpping_fee_amount,
        personalization_fee_amount,
        net_amount,
        fk_order_typeid,
        fk_order_statusid,
        fk_parent_order_headerid,
        salesrep_customerid,
        inserted_date,
        modified_date,
        order_date,
        email_address,
        order_comments,
        order_notes,
        tax_exempt,
        risk_status,
        ship_residential,
        txn_id,
        extn_order_locale_code,
        seller_organization_code,
        customer_first_name,
        customer_last_name,
        modifyuserid ,
        createuserid ,
        createts,
        entered_by,
        entry_type,
        is_bfy17,
        order_header_key,
        extn_brand,
        extn_sub_order_type,
        try_cast(extn_order_total as float) extn_order_total
    FROM
        TRANSFORMED.stg_ORDER_processed_order_header
    WHERE
        fk_order_statusid <> -2
) AS src ON src.pk_order_headerid = tgt.pk_order_headerid
WHEN MATCHED THEN
    UPDATE SET
        tgt.is_domestic = src.is_domestic,
        tgt.fk_shipping_addressid = tgt.fk_shipping_addressid,
        tgt.fk_billing_addressid = tgt.fk_billing_addressid,
        tgt.fk_customerid = src.fk_customerid,
        tgt.fk_currencyid = src.fk_currencyid,
        tgt.fk_shipping_methodid = src.fk_shipping_methodid,
        tgt.payment_amount = src.payment_amount,
        tgt.gross_amount = src.gross_amount,
        tgt.discount_amount = src.discount_amount,
        tgt.fee_amount = src.fee_amount,
        tgt.tax_amount = src.tax_amount,
        tgt.shpping_fee_amount = src.shpping_fee_amount,
        tgt.personalization_fee_amount = src.personalization_fee_amount,
        tgt.net_amount = src.net_amount,
        tgt.fk_order_typeid = src.fk_order_typeid,
        tgt.fk_order_statusid = CASE 
                                     WHEN src.fk_order_statusid = -1 THEN tgt.fk_order_statusid
                                     ELSE src.fk_order_statusid
                                 END,
        tgt.fk_parent_order_headerid = src.fk_parent_order_headerid,
        tgt.salesrep_customerid = src.salesrep_customerid,
        tgt.modified_date = src.modified_date,
        tgt.email_address = src.email_address,
        tgt.order_comments = src.order_comments,
        tgt.order_notes = src.order_notes,
        tgt.tax_exempt = src.tax_exempt,
        tgt.risk_status = src.risk_status,
        tgt.ship_residential = src.ship_residential,
        tgt.extn_order_locale_code = src.extn_order_locale_code, 
        tgt.seller_organization_code = src.seller_organization_code, 
        tgt.customer_first_name = src.customer_first_name,
        tgt.customer_last_name = src.customer_last_name, 
        tgt.modifyuserid = src.modifyuserid,
        tgt.createuserid = src.createuserid,
        tgt.createts =  TRY_TO_TIMESTAMP(src.createts,''YYYYMMDDHHMISS''),
        tgt.entered_by = src.entered_by,
        tgt.is_bfy17 = src.is_bfy17,
        tgt.order_header_key = src.order_header_key,
        tgt.extn_brand = src.extn_brand,
        tgt.extn_sub_order_type = src.extn_sub_order_type,
        tgt.extn_order_total = src.extn_order_total
 ;


 
------------------------------------------------------------------------------

CREATE OR REPLACE TEMPORARY TABLE  ANALYTICS.TempAmendOrders AS
SELECT DISTINCT pk_order_headerid, 
    fk_sourceid, 
    source_ref_num,
    ext_order_id, 
    is_domestic, 
    fk_shipping_addressid, 
    fk_billing_addressid, 
    fk_customerid, 
    fk_currencyid,
    fk_shipping_methodid, 
    payment_amount, 
    gross_amount,
    discount_amount, 
    fee_amount, 
    tax_amount, 
    shpping_fee_amount,
    personalization_fee_amount, 
    net_amount, 
    fk_order_typeid,
    fk_order_statusid,
    fk_parent_order_headerid, 
    inserted_date, 
    modified_date, 
    order_date, 
    email_address, 
    order_comments, 
    order_notes, 
    tax_exempt, 
    risk_status, 
    ship_residential, 
    salesrep_customerid,
    txn_id,
    extn_order_locale_code, 
    seller_organization_code, 
    customer_first_name,
    customer_last_name, 
    modifyuserid ,
    createuserid ,
    createts, 
    entered_by,
    entry_type,
    is_bfy17,
    CAST(1 AS NUMBER(10, 0)) as revision,
    order_header_key,
    extn_brand,
    extn_sub_order_type,
    extn_order_total
FROM TRANSFORMED.stg_ORDER_processed_order_header
    WHERE
        fk_order_statusid <> -2;
------------------------------------------------------------------------------



UPDATE
	ANALYTICS.TempAmendOrders
SET
	Revision = CAST((aot.revision + 1) as int)
FROM
        ANALYTICS.TempAmendOrders as ttd
        inner join (
		SELECT
            MAX(aot.revision) as revision,
            aot.pk_order_headerid
        from
            ANALYTICS.audit_order_header as aot
            inner join ANALYTICS.TempAmendOrders as ttd on ttd.pk_order_headerid = aot.pk_order_headerid
        group by
			aot.pk_order_headerid
	) as aot on ttd.pk_order_headerid = aot.pk_order_headerid; --Insert audit data    
	
		
INSERT INTO
    ANALYTICS.audit_order_header
        (
        pk_order_headerid,
        fk_sourceid,
        source_ref_num,
        ext_order_id,
        is_domestic,
        fk_shipping_addressid,
        fk_billing_addressid,
        fk_customerid,
        fk_currencyid,
        fk_shipping_methodid,
        payment_amount,
        gross_amount,
        discount_amount,
        fee_amount,
        tax_amount,
        shpping_fee_amount,
        personalization_fee_amount,
        net_amount,
        fk_order_typeid,
        fk_order_statusid,
        fk_parent_order_headerid,
        inserted_date,
        modified_date,
        created_by,
        order_date,
        email_address,
        order_comments,
        order_notes,
        tax_exempt,
        salesrep_customerid,
        risk_status,
        ship_residential,
        Revision,
        extn_order_locale_code,
        seller_organization_code,
        customer_first_name,
        customer_last_name,
        modifyuserid ,
        createuserid ,
        createts,
        entered_by,
        entry_type,
        is_bfy17,
        order_header_key,
        extn_brand,
        extn_sub_order_type,
        extn_order_total
        )
    SELECT
        DISTINCT insord.pk_order_headerid,
        insord.fk_sourceid,
        insord.source_ref_num,
        insord.ext_order_id,
        insord.is_domestic,
        insord.fk_shipping_addressid,
        insord.fk_billing_addressid,
        insord.fk_customerid,
        insord.fk_currencyid,
        insord.fk_shipping_methodid,
        insord.payment_amount,
        insord.gross_amount,
        insord.discount_amount,
        insord.fee_amount,
        insord.tax_amount,
        insord.shpping_fee_amount,
        insord.personalization_fee_amount,
        insord.net_amount,
        insord.fk_order_typeid,
        insord.fk_order_statusid,
        insord.fk_parent_order_headerid,
        insord.inserted_date,
        insord.modified_date,
        1, -- Assuming stg.CREATEUSERID is always 1 (System)
        insord.order_date,
        insord.email_address,
        insord.order_comments,
        insord.order_notes,
        insord.tax_exempt,
        insord.salesrep_customerid,
        insord.risk_status,
        insord.ship_residential,
        ord.Revision,
        insord.extn_order_locale_code,
        insord.seller_organization_code,
        insord.customer_first_name,
        insord.customer_last_name,
        insord.modifyuserid ,
        insord.createuserid ,
        insord.createts,
        insord.entered_by,
        insord.entry_type,
        insord.is_bfy17,
        insord.order_header_key,
        insord.extn_brand,
        insord.extn_sub_order_type,
        insord.extn_order_total
    FROM
        ANALYTICS.txn_order_header insord
        INNER JOIN ANALYTICS.TempAmendOrders ord ON ord.source_ref_num = insord.source_ref_num
        INNER JOIN TRANSFORMED.stg_ORDER_header AS stg ON stg.ORDER_NO = insord.source_ref_num;



MERGE INTO ANALYTICS.txn_order_status AS tgt 
USING (
    SELECT DISTINCT
        toh.pk_order_headerid,
        toh.fk_sourceid,
        toh.source_ref_num,
        toh.fk_order_statusid,
        toh.inserted_date,
        toh.modified_date
    FROM
        TRANSFORMED.stg_ORDER_processed_order_header AS stg
        INNER JOIN ANALYTICS.txn_order_header AS toh ON toh.source_ref_num = stg.source_ref_num
            AND stg.fk_sourceid = toh.fk_sourceid
        INNER JOIN MASTER.dim_order_status AS dods ON dods.pk_order_statusid = stg.fk_order_statusid
) AS src ON src.pk_order_headerid = tgt.fk_order_headerid
        AND src.source_ref_num = tgt.source_ref_num
        AND src.fk_sourceid = tgt.fk_sourceid
WHEN NOT MATCHED THEN
    INSERT (
        fk_order_headerid,
        fk_sourceid,
        source_ref_num,
        fk_order_statusid,
        inserted_date,
        modified_date
    )
    VALUES (
        src.pk_order_headerid,
        src.fk_sourceid,
        src.source_ref_num,
        src.fk_order_statusid,
        src.inserted_date,
        src.modified_date
    )
WHEN MATCHED THEN
    UPDATE
    SET
        tgt.fk_order_statusid = src.fk_order_statusid,
        tgt.modified_date = src.modified_date;

-- Creating a temporary table
CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.updatedOrderDetails(
    pk_order_headerid STRING,
    pk_skuproductid STRING,
    ORDERED_QTY STRING,
    UNIT_PRICE STRING,
    LINE_TOTAL STRING,
    is_taxable STRING,
    options STRING,
    ITEM_SHORT_DESCRIPTION STRING,
    txn_id STRING,
    PRIME_LINE_NO STRING,
    source_ref_num STRING,
    order_line_status STRING,
    bh_product_name STRING,
    personalization_fee STRING,
    order_header_key STRING,
    order_line_key STRING
);


-- Creating a temporary table
INSERT INTO ANALYTICS.updatedOrderDetails 
SELECT DISTINCT
    toh.pk_order_headerid,
    dsl.pk_skuproductid,
    ORDERED_QTY,
    UNIT_PRICE,
    LINE_TOTAL,
    CASE
        WHEN ord.TAXABLE_FLAG = ''N'' THEN 0
        WHEN ord.TAXABLE_FLAG = ''Y'' THEN 1
    END AS is_taxable,
    ord.PERSONALIZE_CODE AS options,
    ITEM_SHORT_DESCRIPTION,
    ord.txn_id,
    ord.PRIME_LINE_NO,
    toh.source_ref_num,
    ord.order_line_status,
    dsl.bh_product_name,
    0 AS personalization_fee,
    ord.order_header_key,
    ord.ORDER_LINE_KEY
FROM
    TRANSFORMED.stg_ORDER_line AS ord
    INNER JOIN ANALYTICS.txn_order_header AS toh ON toh.ORDER_HEADER_KEY = ord.ORDER_HEADER_KEY
    INNER JOIN MASTER.dim_source AS ds ON ds.pk_sourceid = toh.fk_sourceid
    INNER JOIN analytics.sku_product_locale AS dsl ON dsl.sku_code = ord.ITEM_ID
        AND dsl.locale = ds.locale
WHERE
    toh.pk_order_headerid IS NOT NULL
    AND ord.BUNDLE_PARENT_ORDER_LINE_KEY IS NULL;

-- Truncating a table in Snowflake
TRUNCATE TABLE TRANSFORMED.stg_ORDER_processed_order_line;

-- Inserting into stg_ORDER_processed_order_line
INSERT INTO TRANSFORMED.stg_ORDER_processed_order_line (
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    inserted_date,
    modified_date,
    txn_id,
    order_line_status,
    prime_line_num,
    ext_line_id,
    order_header_key,
    order_line_key
)
SELECT DISTINCT 
    ord.pk_order_headerid,
    ord.pk_skuproductid,
    SUM(CAST(ord.ORDERED_QTY AS FLOAT)),
    ord.UNIT_PRICE,
    SUM(CAST(ord.LINE_TOTAL AS FLOAT)),
    ord.is_taxable,
    ord.options,
    SUM(CAST(ord.personalization_fee AS FLOAT)),
    ord.bh_product_name,
    CURRENT_TIMESTAMP() AS inserted_date,
    CURRENT_TIMESTAMP() AS modified_date,
    ord.txn_id,
    ord.order_line_status,
    ord.PRIME_LINE_NO,
    ord.ORDER_LINE_KEY,
    ord.order_header_key,
    ord.order_line_key
FROM
    (
        SELECT DISTINCT *
        FROM ANALYTICS.updatedOrderDetails
    ) AS ord
GROUP BY
    ord.pk_skuproductid,
    ord.UNIT_PRICE,
    ord.is_taxable,
    ord.order_line_status,
    ord.bh_product_name,
    ord.options,
    ord.pk_order_headerid,
    ord.txn_id,
    ord.PRIME_LINE_NO,
    ord.ORDER_LINE_KEY,
    ord.order_header_key,
    ord.order_line_key;

-- Creating a temporary table
-------------


	MERGE INTO ANALYTICS.txn_order_detail AS tgt USING (
		SELECT distinct
        sol.fk_order_headerid,
        sol.fk_skuproductid,
        sol.quantity,
        sol.product_price,
        sol.total_price,
        sol.is_taxable,
        sol.options,
        sol.personalization_fee,
        sol.product_name,
        sol.inserted_date,
        sol.modified_date,
        sol.prime_line_num,
        sol.ext_line_id,
        tod.pk_order_detailid,
		sol.order_header_key,
		sol.order_line_key
    FROM
        TRANSFORMED.stg_ORDER_processed_order_line as sol
        left join ANALYTICS.txn_order_detail as tod on tod.fk_order_headerid = sol.fk_order_headerid
            and tod.ext_line_id = sol.ext_line_id
	) AS src ON src.fk_order_headerid = tgt.fk_order_headerid
        and src.pk_order_detailid = tgt.pk_order_detailid
        and src.ext_line_id = tgt.ext_line_id
	WHEN NOT MATCHED  THEN
INSERT
	(
		fk_order_headerid,
		fk_skuproductid,
		quantity,
		product_price,
		total_price,
		is_taxable,
		options,
		personalization_fee,
		product_name,
		inserted_date,
		modified_date,
		prime_line_num,
		ext_line_id,
		order_header_key,
		order_line_key
	)
VALUES
	(
		src.fk_order_headerid,
		src.fk_skuproductid,
		src.quantity,
		src.product_price,
		src.total_price,
		src.is_taxable,
		src.options,
		src.personalization_fee,
		src.product_name,
		src.inserted_date,
		src.modified_date,
		src.prime_line_num,
		src.ext_line_id,
		src.order_header_key,
		src.order_line_key
	)
	WHEN MATCHED Then
UPDATE
SET
	tgt.fk_skuproductid = src.fk_skuproductid,
	tgt.quantity = src.quantity,
	tgt.product_price = src.product_price,
	tgt.total_price = src.total_price,
	tgt.is_taxable = src.is_taxable,
	tgt.options = src.options,
	tgt.personalization_fee = src.personalization_fee,
	tgt.product_name = src.product_name,
	tgt.modified_date = src.modified_date,
	tgt.prime_line_num = src.prime_line_num,
	tgt.order_header_key = src.order_header_key,
	tgt.order_line_key = src.order_line_key;

INSERT INTO ANALYTICS.TempAmendOrderDetails(
    pk_order_detailid, 
    fk_order_headerid, 
    fk_skuproductid, 
    quantity, 
    product_price, 
    total_price, 
    is_taxable, 
    options, 
    personalization_fee, 
    product_name, 
    created_by, 
    created_date, 
    modified_date, 
    revision,
    prime_line_num,
    ext_line_id,
    order_header_key,
    order_line_key
)
SELECT DISTINCT 
pk_order_detailid,
    sol.fk_order_headerid,
    sol.fk_skuproductid,
    sol.quantity,
    sol.product_price,
    sol.total_price,
    sol.is_taxable,
    sol.options,
    sol.personalization_fee,
    sol.product_name,
    1 AS created_by, -- Replace @createdby with the actual value or variable
    CURRENT_TIMESTAMP() AS created_date,
    CURRENT_TIMESTAMP() AS modified_date,
    CAST(1 AS NUMBER(10, 0)) AS revision,
    sol.prime_line_num,
    sol.ext_line_id,
    sol.order_header_key,
    sol.order_line_key
FROM TRANSFORMED.stg_ORDER_processed_order_line sol
left join ANALYTICS.txn_order_detail as tod on tod.fk_order_headerid = sol.fk_order_headerid and tod.ext_line_id = sol.ext_line_id;



-- Populate revision
UPDATE ANALYTICS.TempAmendOrderDetails
SET Revision = CAST((aot.revision + 1) AS INT)
FROM ANALYTICS.TempAmendOrderDetails ttd
INNER JOIN (
    SELECT
        MAX(aot.revision) AS revision,
        aot.pk_order_detailid,
        aot.fk_order_headerid
    FROM
        ANALYTICS.audit_order_detail aot
    INNER JOIN ANALYTICS.TempAmendOrderDetails ttd ON ttd.pk_order_detailid = aot.pk_order_detailid AND ttd.fk_order_headerid = aot.fk_order_headerid
    GROUP BY
        aot.pk_order_detailid,
        aot.fk_order_headerid
) AS aot ON ttd.pk_order_detailid = aot.pk_order_detailid AND ttd.fk_order_headerid = aot.fk_order_headerid;

-- Insert into audit_order_detail
INSERT INTO ANALYTICS.audit_order_detail (
    pk_order_detailid,
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    created_by,
    created_date,
    modified_date,
    revision,
    order_header_key,
    order_line_key
)
SELECT
    pk_order_detailid,
    fk_order_headerid,
    fk_skuproductid,
    quantity,
    product_price,
    total_price,
    is_taxable,
    options,
    personalization_fee,
    product_name,
    created_by,
    created_date,
    modified_date,
    revision,
    order_header_key,
    order_line_key
FROM
    ANALYTICS.TempAmendOrderDetails;



-- Populate txn_order_detail_status
MERGE INTO ANALYTICS.txn_order_detail_status AS Target
USING (
    SELECT DISTINCT
        stg.fk_order_headerid,
        tod.pk_order_detailid,
        pk_order_statusid,
        stg.fk_skuproductid
    FROM
        TRANSFORMED.stg_ORDER_processed_order_line AS stg
    INNER JOIN ANALYTICS.TempAmendOrderDetails AS tod ON tod.fk_order_headerid = stg.fk_order_headerid AND stg.fk_skuproductid = tod.fk_skuproductid AND tod.ext_line_id = stg.ext_line_id
    INNER JOIN MASTER.dim_order_status AS dods ON dods.oms_ORDER_status_code = stg.order_line_status
) AS Source ON Source.fk_order_headerid = Target.pk_order_headerid
    AND Source.fk_skuproductid = Target.fk_skuproductid
    AND Source.pk_order_detailid = Target.pk_order_detailid
WHEN NOT MATCHED THEN
INSERT (
    pk_order_headerid,
    pk_order_detailid,
    fk_ORDER__detail_statusid,
    fk_skuproductid
)
VALUES (
    Source.fk_order_headerid,
    Source.pk_order_detailid,
    Source.pk_order_statusid,
    Source.fk_skuproductid
);


CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.OrderDetailMultipartItems (
    pk_order_detail_multipartid BIGINT NOT NULL,
    fk_order_detailid BIGINT NOT NULL,
    order_line_key VARCHAR,
    order_header_key VARCHAR,
    prime_line_no VARCHAR NOT NULL,
    sub_line_no VARCHAR,
    line_type VARCHAR,
    order_class VARCHAR,
    item_id VARCHAR,
    alternate_item_id VARCHAR,
    uom VARCHAR,
    product_class VARCHAR,
    unit_price VARCHAR,
    cost_currency VARCHAR,
    ordered_qty VARCHAR,
    basic_capacity_required VARCHAR,
    option_capacity_required VARCHAR,
    dependent_on_line_key VARCHAR,
    current_work_order_key VARCHAR,
    dependency_shipping_rule VARCHAR,
    fill_quantity VARCHAR,
    committed_quantity VARCHAR,
    dependency_ratio VARCHAR,
    maintain_ratio VARCHAR,
    merge_node VARCHAR,
    parent_of_dependent_group VARCHAR,
    source_from_organization VARCHAR,
    chained_from_order_line_key VARCHAR,
    chained_from_order_header_key VARCHAR,
    derived_from_order_line_key VARCHAR,
    derived_from_order_header_key VARCHAR,
    derived_from_order_release_key VARCHAR,
    distribution_rule_id VARCHAR,
    invoiced_quantity VARCHAR,
    over_receipt_quantity VARCHAR,
    return_reason VARCHAR,
    shipnode_key VARCHAR,
    procure_from_node VARCHAR,
    ship_to_key VARCHAR,
    mark_for_key VARCHAR,
    buyer_mark_for_node_id VARCHAR,
    req_delivery_date VARCHAR,
    req_cancel_date VARCHAR,
    req_ship_date VARCHAR,
    scac VARCHAR,
    carrier_service_code VARCHAR,
    carrier_account_no VARCHAR,
    pickable_flag VARCHAR,
    ship_together_no VARCHAR,
    hold_flag VARCHAR,
    kit_code VARCHAR,
    hold_reason_code VARCHAR,
    other_charges VARCHAR,
    line_total VARCHAR,
    invoiced_line_total VARCHAR,
    invoiced_extended_price VARCHAR,
    settled_quantity VARCHAR,
    settled_amount VARCHAR,
    taxable_flag VARCHAR,
    tax_exemption_certificate VARCHAR,
    discount_type VARCHAR,
    discount_reference VARCHAR,
    gift_flag VARCHAR,
    personalize_flag VARCHAR,
    personalize_code VARCHAR,
    department_code VARCHAR,
    customer_item VARCHAR,
    customer_item_description VARCHAR,
    item_weight VARCHAR,
    item_weight_uom VARCHAR,
    item_description VARCHAR,
    item_short_description VARCHAR,
    reservation_id VARCHAR,
    reservation_pool VARCHAR,
    customer_po_no VARCHAR,
    customer_po_line_no VARCHAR,
    tax VARCHAR,
    delivery_code VARCHAR,
    original_ordered_qty VARCHAR,
    list_price VARCHAR,
    retail_price VARCHAR,
    discount_percentage VARCHAR,
    packlist_type VARCHAR,
    supplier_item VARCHAR,
    supplier_item_description VARCHAR,
    unit_cost VARCHAR,
    upc_code VARCHAR,
    fob VARCHAR,
    manufacturer_name VARCHAR,
    manufacturer_item VARCHAR,
    manufacturer_item_desc VARCHAR,
    country_of_origin VARCHAR,
    isbn VARCHAR,
    harmonized_code VARCHAR,
    ship_to_id VARCHAR,
    product_line VARCHAR,
    nmfc_code VARCHAR,
    nmfc_class VARCHAR,
    nmfc_description VARCHAR,
    tax_product_code VARCHAR,
    import_license_no VARCHAR,
    import_license_exp_date VARCHAR,
    eccn_no VARCHAR,
    schedule_b_code VARCHAR,
    supplier_code VARCHAR,
    purpose VARCHAR,
    receiving_node VARCHAR,
    buyer_receiving_node_id VARCHAR,
    shipment_consol_group_id VARCHAR,
    orig_order_line_key VARCHAR,
    line_seq_no VARCHAR,
    split_qty VARCHAR,
    pricing_date VARCHAR,
    pipeline_key VARCHAR,
    condition_variable_1 VARCHAR,
    condition_variable_2 VARCHAR,
    is_price_locked VARCHAR,
    is_cost_overridden VARCHAR,
    is_capacity_overridden VARCHAR,
    invoice_complete VARCHAR,
    delivery_method VARCHAR,
    item_group_code VARCHAR,
    cannot_complete_before_date VARCHAR,
    cannot_complete_after_date VARCHAR,
    appt_status VARCHAR,
    can_add_service_lines VARCHAR,
    pricing_uom VARCHAR,
    capacity_uom VARCHAR,
    pricing_quantity VARCHAR,
    shipped_quantity VARCHAR,
    fixed_capacity_qty_per_line VARCHAR,
    fixed_pricing_qty_per_line VARCHAR,
    wait_for_seq_line VARCHAR,
    sched_failure_reason_code VARCHAR,
    earliest_ship_date VARCHAR,
    earliest_delivery_date VARCHAR,
    cannot_meet_appt VARCHAR,
    promised_appt_start_date VARCHAR,
    promised_appt_end_date VARCHAR,
    segment VARCHAR,
    segment_type VARCHAR,
    earliest_schedule_date VARCHAR,
    timezone VARCHAR,
    is_forwarding_allowed VARCHAR,
    is_procurement_allowed VARCHAR,
    reship_parent_line_key VARCHAR,
    bundle_parent_order_line_key VARCHAR,
    is_price_info_only VARCHAR,
    level_of_service VARCHAR,
    first_iter_seq_no VARCHAR,
    last_iter_seq_no VARCHAR,
    createts VARCHAR,
    modifyts VARCHAR,
    createuserid VARCHAR,
    modifyuserid VARCHAR,
    createprogid VARCHAR,
    modifyprogid VARCHAR,
    lockid INT,
    ordering_uom VARCHAR,
    pricing_quantity_conv_factor VARCHAR,
    pricing_quantity_strategy VARCHAR,
    invoiced_pricing_quantity VARCHAR,
    is_standalone_service VARCHAR,
    tran_discrepancy_qty VARCHAR,
    received_quantity VARCHAR,
    invoice_based_on_actuals VARCHAR,
    actual_pricing_quantity VARCHAR,
    fulfillment_type VARCHAR,
    serial_no VARCHAR,
    reservation_mandatory VARCHAR,
    is_firm_predefined_node VARCHAR,
    intentional_backorder VARCHAR,
    future_avail_date VARCHAR,
    repricing_quantity VARCHAR,
    min_ship_by_date VARCHAR,
    kit_qty VARCHAR,
    bom_config_key VARCHAR,
    bundle_fulfillment_mode VARCHAR,
    is_gift_wrap VARCHAR,
    group_sequence_num VARCHAR,
    in_store_payment_required VARCHAR,
    item_not_exist VARCHAR,
    derived_from_ext_ord VARCHAR,
    is_eligible_for_ship_disc VARCHAR,
    backorder_notification_qty VARCHAR,
    is_price_matched VARCHAR,
    is_pick_up_now VARCHAR,
    item_is_in_hand VARCHAR,
    disposition_code VARCHAR,
    extn_mod_reason_code VARCHAR,
    extn_mod_reason_desc VARCHAR,
    extn_asn VARCHAR,
    extn_parent_order_no VARCHAR,
    extn_item_id VARCHAR,
    extn_order_item_id VARCHAR,
    extn_price_type VARCHAR,
    extn_secondary_return_reason VARCHAR,
    extn_apply_label_fee VARCHAR,
    extn_is_activation_complete VARCHAR,
    extn_item_desc VARCHAR,
    extn_return_carton_count VARCHAR,
    extn_asn_quantity VARCHAR,
    extn_light_color VARCHAR,
    extn_light_type VARCHAR,
    extn_number_of_sections VARCHAR,
    extn_total_cartons VARCHAR,
    extn_tree_height VARCHAR,
    extn_tree_height_uom VARCHAR,
    extn_apply_restocking_fee VARCHAR,
    extn_return_pickup_date VARCHAR,
    extn_pickup_confirmation_no VARCHAR,
    extn_refund_shipping_cost VARCHAR,
    extn_is_fulfilled_line VARCHAR,
    extn_mfg_warranty_start_date VARCHAR,
    extn_mfg_warranty_end_date VARCHAR,
    extn_term VARCHAR,
    extn_is_invoice_required VARCHAR,
    extn_prem_guarantee_end_date VARCHAR,
    extn_return_date VARCHAR,
    extn_is_email_sent VARCHAR,
    extn_return_required VARCHAR,
    extn_parent_prime_line_no VARCHAR,
    extn_parent_sub_line_no VARCHAR,
    extn_prem_guarantee_start_date VARCHAR,
    extn_reship_upcid VARCHAR,
    extn_parent_order_line_sku VARCHAR,
    revision INT NOT NULL
);



	MERGE INTO ANALYTICS.txn_order_detail_multipart
	AS TARGET USING( SELECT DISTINCT stg.*, tod.pk_order_detailid from 
	    TRANSFORMED.stg_ORDER_line_multipart AS stg
		INNER JOIN ANALYTICS.txn_order_header as toh on toh.order_header_key = stg.order_header_key and toh.entry_type is not null
        INNER JOIN ANALYTICS.txn_order_detail as tod on tod.fk_order_headerid = toh.pk_order_headerid 
		and	  stg.BUNDLE_PARENT_ORDER_LINE_KEY =tod.order_line_key
		where stg.BUNDLE_PARENT_ORDER_LINE_KEY is not null
	) as SOURCE on SOURCE.pk_order_detailid = TARGET.fk_order_detailid and SOURCE.order_line_key = TARGET.order_line_key  and SOURCE.BUNDLE_PARENT_ORDER_LINE_KEY = TARGET.BUNDLE_PARENT_ORDER_LINE_KEY AND TARGET.BUNDLE_PARENT_ORDER_LINE_KEY is not null AND SOURCE.BUNDLE_PARENT_ORDER_LINE_KEY is not null

	WHEN MATCHED 
	THEN 
	UPDATE 
	SET
	  
  TARGET.prime_line_no                  =SOURCE.prime_line_no                   
  ,TARGET.sub_line_no                    =SOURCE.sub_line_no                     
  ,TARGET.line_type                      =SOURCE.line_type                      
  ,TARGET.order_class                    =SOURCE.order_class                    
  ,TARGET.item_id                        =SOURCE.item_id  
  ,TARGET.alternate_item_id              =SOURCE.alternate_item_id             
  ,TARGET.uom                            =SOURCE.uom                            
  ,TARGET.product_class                  =SOURCE.product_class                  
  ,TARGET.unit_price                     =try_cast( SOURCE.unit_price as float)                    
  ,TARGET.cost_currency                  =SOURCE.cost_currency                 
  ,TARGET.ordered_qty                    =SOURCE.ordered_qty                    
  ,TARGET.basic_capacity_required        =SOURCE.basic_capacity_required        
  ,TARGET.option_capacity_required       =SOURCE.option_capacity_required       
  ,TARGET.dependent_on_line_key          =SOURCE.dependent_on_line_key         
  ,TARGET.current_work_order_key         =SOURCE.current_work_order_key        
  ,TARGET.dependency_shipping_rule       =SOURCE.dependency_shipping_rule      
  ,TARGET.fill_quantity                  =SOURCE.fill_quantity                  
  ,TARGET.committed_quantity             =SOURCE.committed_quantity            
  ,TARGET.dependency_ratio               =SOURCE.dependency_ratio               
  ,TARGET.maintain_ratio                 =SOURCE.maintain_ratio                
  ,TARGET.merge_node                     =SOURCE.merge_node                    
  ,TARGET.parent_of_dependent_group      =SOURCE.parent_of_dependent_group      
  ,TARGET.source_from_organization       =SOURCE.source_from_organization      
  ,TARGET.chained_from_order_line_key    =SOURCE.chained_from_order_line_key   
  ,TARGET.chained_from_order_header_key  =SOURCE.chained_from_order_header_key 
  ,TARGET.derived_from_order_line_key    =SOURCE.derived_from_order_line_key   
  ,TARGET.derived_from_order_header_key  =SOURCE.derived_from_order_header_key 
  ,TARGET.derived_from_order_release_key =SOURCE.derived_from_order_release_key
  ,TARGET.distribution_rule_id           =SOURCE.distribution_rule_id          
  ,TARGET.invoiced_quantity              =SOURCE.invoiced_quantity              
  ,TARGET.over_receipt_quantity          =SOURCE.over_receipt_quantity          
  ,TARGET.return_reason                  =SOURCE.return_reason                 
  ,TARGET.shipnode_key                   =SOURCE.shipnode_key                  
  ,TARGET.procure_from_node              =SOURCE.procure_from_node             
  ,TARGET.ship_to_key                    =SOURCE.ship_to_key                   
  ,TARGET.mark_for_key                   =SOURCE.mark_for_key                  
  ,TARGET.buyer_mark_for_node_id         =SOURCE.buyer_mark_for_node_id        
  ,TARGET.req_delivery_date              =TRY_TO_TIMESTAMP(SOURCE.req_delivery_date,''YYYYMMDDHHMISS'')          
  ,TARGET.req_cancel_date                =TRY_TO_TIMESTAMP(SOURCE.req_cancel_date,''YYYYMMDDHHMISS'')
  ,TARGET.req_ship_date                  =TRY_TO_TIMESTAMP(SOURCE.req_ship_date,''YYYYMMDDHHMISS'')
  ,TARGET.scac                           =SOURCE.scac                          
  ,TARGET.carrier_service_code           =SOURCE.carrier_service_code          
  ,TARGET.carrier_account_no             =SOURCE.carrier_account_no            
  ,TARGET.pickable_flag                  =SOURCE.pickable_flag                  
  ,TARGET.ship_together_no               =SOURCE.ship_together_no              
  ,TARGET.hold_flag                      =SOURCE.hold_flag                      
  ,TARGET.kit_code                       =SOURCE.kit_code                      
  ,TARGET.hold_reason_code               =SOURCE.hold_reason_code              
  ,TARGET.other_charges                  =SOURCE.other_charges                  
  ,TARGET.line_total                     =try_cast( SOURCE.line_total as float)                    
  ,TARGET.invoiced_line_total            =try_cast( SOURCE.invoiced_line_total as float)         
  ,TARGET.invoiced_extended_price        =try_cast( SOURCE.invoiced_extended_price as float)    
  ,TARGET.settled_quantity               =SOURCE.settled_quantity               
  ,TARGET.settled_amount                 =SOURCE.settled_amount                 
  ,TARGET.taxable_flag                   =SOURCE.taxable_flag                   
  ,TARGET.tax_exemption_certificate      =SOURCE.tax_exemption_certificate     
  ,TARGET.discount_type                  =SOURCE.discount_type                 
  ,TARGET.discount_reference             =SOURCE.discount_reference            
  ,TARGET.gift_flag                      =SOURCE.gift_flag                      
  ,TARGET.personalize_flag               =SOURCE.personalize_flag               
  ,TARGET.personalize_code               =SOURCE.personalize_code              
  ,TARGET.department_code                =SOURCE.department_code               
  ,TARGET.customer_item                  =SOURCE.customer_item  
  ,TARGET.customer_item_description      =SOURCE.customer_item_description      
  ,TARGET.item_weight                    =SOURCE.item_weight                    
  ,TARGET.item_weight_uom                =SOURCE.item_weight_uom                
  ,TARGET.item_description               =SOURCE.item_description               
  ,TARGET.item_short_description         =SOURCE.item_short_description         
  ,TARGET.reservation_id                 =SOURCE.reservation_id                
  ,TARGET.reservation_pool               =SOURCE.reservation_pool              
  ,TARGET.customer_po_no                 =SOURCE.customer_po_no                
  ,TARGET.customer_po_line_no            =SOURCE.customer_po_line_no           
  ,TARGET.tax                            =SOURCE.tax                            
  ,TARGET.delivery_code                  =SOURCE.delivery_code                 
  ,TARGET.original_ordered_qty           =SOURCE.original_ordered_qty           
  ,TARGET.list_price                     =try_cast( SOURCE.list_price as float)                    
  ,TARGET.retail_price                   =try_cast( SOURCE.retail_price as float)                   
  ,TARGET.discount_percentage            =SOURCE.discount_percentage            
  ,TARGET.packlist_type                  =SOURCE.packlist_type                 
  ,TARGET.supplier_item                  =SOURCE.supplier_item                 
  ,TARGET.supplier_item_description      =SOURCE.supplier_item_description     
  ,TARGET.unit_cost                      =SOURCE.unit_cost                      
  ,TARGET.upc_code                       =SOURCE.upc_code                      
  ,TARGET.fob                            =SOURCE.fob                           
  ,TARGET.manufacturer_name              =SOURCE.manufacturer_name             
  ,TARGET.manufacturer_item              =SOURCE.manufacturer_item             
  ,TARGET.manufacturer_item_desc         =SOURCE.manufacturer_item_desc        
  ,TARGET.country_of_origin              =SOURCE.country_of_origin             
  ,TARGET.isbn                           =SOURCE.isbn                          
  ,TARGET.harmonized_code                =SOURCE.harmonized_code               
  ,TARGET.ship_to_id                     =SOURCE.ship_to_id                    
  ,TARGET.product_line                   =SOURCE.product_line                  
  ,TARGET.nmfc_code                      =SOURCE.nmfc_code                     
  ,TARGET.nmfc_class                     =SOURCE.nmfc_class                    
  ,TARGET.nmfc_description               =SOURCE.nmfc_description              
  ,TARGET.tax_product_code               =SOURCE.tax_product_code               
  ,TARGET.import_license_no              =SOURCE.import_license_no             
  ,TARGET.import_license_exp_date        =TRY_TO_TIMESTAMP(SOURCE.import_license_exp_date,''YYYYMMDDHHMISS'')
  ,TARGET.eccn_no                        =SOURCE.eccn_no                       
  ,TARGET.schedule_b_code                =SOURCE.schedule_b_code               
  ,TARGET.supplier_code                  =SOURCE.supplier_code                 
  ,TARGET.purpose                        =SOURCE.purpose                       
  ,TARGET.receiving_node                 =SOURCE.receiving_node                
  ,TARGET.buyer_receiving_node_id        =SOURCE.buyer_receiving_node_id       
  ,TARGET.shipment_consol_group_id       =SOURCE.shipment_consol_group_id      
  ,TARGET.orig_order_line_key            =SOURCE.orig_order_line_key           
  ,TARGET.line_seq_no                    =SOURCE.line_seq_no                    
  ,TARGET.split_qty                      =SOURCE.split_qty                      
  ,TARGET.pricing_date                   =TRY_TO_TIMESTAMP(SOURCE.pricing_date,''YYYYMMDDHHMISS'')        
  ,TARGET.pipeline_key                   =SOURCE.pipeline_key                   
  ,TARGET.condition_variable_1           =SOURCE.condition_variable_1          
  ,TARGET.condition_variable_2           =SOURCE.condition_variable_2          
  ,TARGET.is_price_locked                =SOURCE.is_price_locked                
  ,TARGET.is_cost_overridden             =SOURCE.is_cost_overridden             
  ,TARGET.is_capacity_overridden         =SOURCE.is_capacity_overridden         
  ,TARGET.invoice_complete               =SOURCE.invoice_complete               
  ,TARGET.delivery_method                =SOURCE.delivery_method                
  ,TARGET.item_group_code                =SOURCE.item_group_code                
  ,TARGET.cannot_complete_before_date    =TRY_TO_TIMESTAMP(SOURCE.cannot_complete_before_date,''YYYYMMDDHHMISS'')
  ,TARGET.cannot_complete_after_date     =TRY_TO_TIMESTAMP(SOURCE.cannot_complete_after_date,''YYYYMMDDHHMISS'') 
  ,TARGET.appt_status                    =SOURCE.appt_status                   
  ,TARGET.can_add_service_lines          =SOURCE.can_add_service_lines          
  ,TARGET.pricing_uom                    =SOURCE.pricing_uom                    
  ,TARGET.capacity_uom                   =SOURCE.capacity_uom                  
  ,TARGET.pricing_quantity               =SOURCE.pricing_quantity               
  ,TARGET.shipped_quantity               =SOURCE.shipped_quantity               
  ,TARGET.fixed_capacity_qty_per_line    =SOURCE.fixed_capacity_qty_per_line    
  ,TARGET.fixed_pricing_qty_per_line     =SOURCE.fixed_pricing_qty_per_line     
  ,TARGET.wait_for_seq_line              =SOURCE.wait_for_seq_line              
  ,TARGET.sched_failure_reason_code      =SOURCE.sched_failure_reason_code     
  ,TARGET.earliest_ship_date             =TRY_TO_TIMESTAMP(SOURCE.earliest_ship_date,''YYYYMMDDHHMISS'')
  ,TARGET.earliest_delivery_date         =TRY_TO_TIMESTAMP(SOURCE.earliest_delivery_date,''YYYYMMDDHHMISS'')
  ,TARGET.cannot_meet_appt               =SOURCE.cannot_meet_appt              
  ,TARGET.promised_appt_start_date       =TRY_TO_TIMESTAMP(SOURCE.promised_appt_start_date,''YYYYMMDDHHMISS'')     
  ,TARGET.promised_appt_end_date         =TRY_TO_TIMESTAMP(SOURCE.promised_appt_end_date,''YYYYMMDDHHMISS'')       
  ,TARGET.segment                        =SOURCE.segment                        
  ,TARGET.segment_type                   =SOURCE.segment_type                   
  ,TARGET.earliest_schedule_date         =TRY_TO_TIMESTAMP(SOURCE.earliest_schedule_date,''YYYYMMDDHHMISS'')   
  ,TARGET.timezone                       =SOURCE.timezone                      
  ,TARGET.is_forwarding_allowed          =SOURCE.is_forwarding_allowed         
  ,TARGET.is_procurement_allowed         =SOURCE.is_procurement_allowed        
  ,TARGET.reship_parent_line_key         =SOURCE.reship_parent_line_key        
  ,TARGET.is_price_info_only             =SOURCE.is_price_info_only            
  ,TARGET.level_of_service               =SOURCE.level_of_service               
  ,TARGET.first_iter_seq_no              =SOURCE.first_iter_seq_no             
  ,TARGET.last_iter_seq_no               =SOURCE.last_iter_seq_no              
  ,TARGET.createts                       =TRY_TO_TIMESTAMP(SOURCE.createts,''YYYYMMDDHHMISS'')  
  ,TARGET.modifyts                       =TRY_TO_TIMESTAMP(SOURCE.modifyts,''YYYYMMDDHHMISS'')  
  ,TARGET.createuserid                   =SOURCE.createuserid                   
  ,TARGET.modifyuserid                   =SOURCE.modifyuserid                   
  ,TARGET.createprogid                   =SOURCE.createprogid                   
  ,TARGET.modifyprogid                   =SOURCE.modifyprogid                   
  ,TARGET.lockid                         =SOURCE.lockid  
  ,TARGET.ordering_uom                   =SOURCE.ordering_uom                   
  ,TARGET.pricing_quantity_conv_factor   =SOURCE.pricing_quantity_conv_factor   
  ,TARGET.pricing_quantity_strategy      =SOURCE.pricing_quantity_strategy      
  ,TARGET.invoiced_pricing_quantity      =SOURCE.invoiced_pricing_quantity      
  ,TARGET.is_standalone_service          =SOURCE.is_standalone_service         
  ,TARGET.tran_discrepancy_qty           =SOURCE.tran_discrepancy_qty           
  ,TARGET.received_quantity              =SOURCE.received_quantity              
  ,TARGET.invoice_based_on_actuals       =SOURCE.invoice_based_on_actuals       
  ,TARGET.actual_pricing_quantity        =SOURCE.actual_pricing_quantity        
  ,TARGET.fulfillment_type               =SOURCE.fulfillment_type               
  ,TARGET.serial_no                      =SOURCE.serial_no                     
  ,TARGET.reservation_mandatory          =SOURCE.reservation_mandatory          
  ,TARGET.is_firm_predefined_node        =SOURCE.is_firm_predefined_node        
  ,TARGET.intentional_backorder          =SOURCE.intentional_backorder          
  ,TARGET.future_avail_date              =TRY_TO_TIMESTAMP(SOURCE.future_avail_date,''YYYYMMDDHHMISS'')            
  ,TARGET.repricing_quantity             =SOURCE.repricing_quantity             
  ,TARGET.min_ship_by_date               =TRY_TO_TIMESTAMP(SOURCE.min_ship_by_date,''YYYYMMDDHHMISS'')           
  ,TARGET.kit_qty                        =SOURCE.kit_qty                       
  ,TARGET.bom_config_key                 =SOURCE.bom_config_key                
  ,TARGET.bundle_fulfillment_mode        =SOURCE.bundle_fulfillment_mode       
  ,TARGET.is_gift_wrap                   =SOURCE.is_gift_wrap                  
  ,TARGET.group_sequence_num             =SOURCE.group_sequence_num            
  ,TARGET.in_store_payment_required      =SOURCE.in_store_payment_required     
  ,TARGET.item_not_exist                 =SOURCE.item_not_exist                
  ,TARGET.derived_from_ext_ord           =SOURCE.derived_from_ext_ord          
  ,TARGET.is_eligible_for_ship_disc      =SOURCE.is_eligible_for_ship_disc      
  ,TARGET.backorder_notification_qty     =SOURCE.backorder_notification_qty     
  ,TARGET.is_price_matched               =SOURCE.is_price_matched               
  ,TARGET.is_pick_up_now                 =SOURCE.is_pick_up_now                
  ,TARGET.item_is_in_hand                =SOURCE.item_is_in_hand               
  ,TARGET.disposition_code               =SOURCE.disposition_code              
  ,TARGET.extn_mod_reason_code           =SOURCE.extn_mod_reason_code          
  ,TARGET.extn_mod_reason_desc           =SOURCE.extn_mod_reason_desc          
  ,TARGET.extn_asn                       =SOURCE.extn_asn                      
  ,TARGET.extn_parent_order_no           =SOURCE.extn_parent_order_no          
  ,TARGET.extn_item_id                   =SOURCE.extn_item_id                   
  ,TARGET.extn_order_item_id             =SOURCE.extn_order_item_id            
  ,TARGET.extn_price_type                =SOURCE.extn_price_type                  
  ,TARGET.extn_secondary_return_reason                =SOURCE.extn_secondary_return_reason
  ,TARGET.extn_apply_label_fee                =SOURCE.extn_apply_label_fee
  ,TARGET.extn_is_activation_complete                =SOURCE.extn_is_activation_complete
  ,TARGET.extn_item_desc                =SOURCE.extn_item_desc
  ,TARGET.extn_return_carton_count                =SOURCE.extn_return_carton_count
  ,TARGET.extn_asn_quantity                =SOURCE.extn_asn_quantity
  ,TARGET.extn_light_color                =SOURCE.extn_light_color
  ,TARGET.extn_light_type                =SOURCE.extn_light_type
  ,TARGET.extn_number_of_sections                =SOURCE.extn_number_of_sections
  ,TARGET.extn_total_cartons                =SOURCE.extn_total_cartons
  ,TARGET.extn_tree_height                =SOURCE.extn_tree_height
  ,TARGET.extn_tree_height_uom                =SOURCE.extn_tree_height_uom
  ,TARGET.extn_apply_restocking_fee                =SOURCE.extn_apply_restocking_fee
  ,TARGET.extn_return_pickup_date                =TRY_TO_TIMESTAMP(SOURCE.extn_return_pickup_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_pickup_confirmation_no                =SOURCE.extn_pickup_confirmation_no
  ,TARGET.extn_refund_shipping_cost                =SOURCE.extn_refund_shipping_cost
  ,TARGET.extn_is_fulfilled_line                =SOURCE.extn_is_fulfilled_line
  ,TARGET.extn_mfg_warranty_start_date                =TRY_TO_TIMESTAMP(SOURCE.extn_mfg_warranty_start_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_mfg_warranty_end_date                =TRY_TO_TIMESTAMP(SOURCE.extn_mfg_warranty_end_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_term                =SOURCE.extn_term
  ,TARGET.extn_is_invoice_required                =SOURCE.extn_is_invoice_required
  ,TARGET.extn_prem_guarantee_end_date                =TRY_TO_TIMESTAMP(SOURCE.extn_prem_guarantee_end_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_return_date                =TRY_TO_TIMESTAMP(SOURCE.extn_return_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_is_email_sent                =SOURCE.extn_is_email_sent
  ,TARGET.extn_return_required                =SOURCE.extn_return_required
  ,TARGET.extn_parent_prime_line_no                =SOURCE.extn_parent_prime_line_no
  ,TARGET.extn_parent_sub_line_no                =SOURCE.extn_parent_sub_line_no
  ,TARGET.extn_prem_guarantee_start_date     = TRY_TO_TIMESTAMP(SOURCE.extn_prem_guarantee_start_date,''YYYYMMDDHHMISS'')
  ,TARGET.extn_reship_upcid                =SOURCE.extn_reship_upcid
  ,TARGET.extn_parent_order_line_sku       =SOURCE.extn_parent_order_line_sku
WHEN NOT MATCHED THEN
INSERT (
fk_order_detailid
,order_line_key
,order_header_key
,prime_line_no                   
,sub_line_no                     
,line_type                      
,order_class                    
,item_id  
,alternate_item_id             
,uom                            
,product_class                  
,unit_price                     
,cost_currency                 
,ordered_qty                    
,basic_capacity_required        
,option_capacity_required       
,dependent_on_line_key         
,current_work_order_key        
,dependency_shipping_rule      
,fill_quantity                  
,committed_quantity            
,dependency_ratio               
,maintain_ratio                
,merge_node                    
,parent_of_dependent_group      
,source_from_organization      
,chained_from_order_line_key   
,chained_from_order_header_key 
,derived_from_order_line_key   
,derived_from_order_header_key 
,derived_from_order_release_key
,distribution_rule_id          
,invoiced_quantity              
,over_receipt_quantity          
,return_reason                 
,shipnode_key                  
,procure_from_node             
,ship_to_key                   
,mark_for_key                  
,buyer_mark_for_node_id        
,req_delivery_date             
,req_cancel_date   
,req_ship_date                 
,scac                          
,carrier_service_code          
,carrier_account_no            
,pickable_flag                  
,ship_together_no              
,hold_flag                      
,kit_code                      
,hold_reason_code              
,other_charges                  
,line_total                     
,invoiced_line_total            
,invoiced_extended_price        
,settled_quantity               
,settled_amount                 
,taxable_flag                   
,tax_exemption_certificate     
,discount_type                 
,discount_reference            
,gift_flag                      
,personalize_flag               
,personalize_code              
,department_code               
,customer_item  
,customer_item_description      
,item_weight                    
,item_weight_uom                
,item_description               
,item_short_description         
,reservation_id                
,reservation_pool              
,customer_po_no                
,customer_po_line_no           
,tax                            
,delivery_code                 
,original_ordered_qty           
,list_price                     
,retail_price                   
,discount_percentage            
,packlist_type                 
,supplier_item                 
,supplier_item_description     
,unit_cost                      
,upc_code                      
,fob                           
,manufacturer_name             
,manufacturer_item             
,manufacturer_item_desc        
,country_of_origin             
,isbn                          
,harmonized_code               
,ship_to_id                    
,product_line                  
,nmfc_code                     
,nmfc_class                    
,nmfc_description              
,tax_product_code               
,import_license_no             
,import_license_exp_date                 
,eccn_no                       
,schedule_b_code               
,supplier_code                 
,purpose                       
,receiving_node                
,buyer_receiving_node_id       
,shipment_consol_group_id      
,orig_order_line_key           
,line_seq_no                    
,split_qty                      
,pricing_date                            
,pipeline_key                   
,condition_variable_1          
,condition_variable_2          
,is_price_locked                
,is_cost_overridden             
,is_capacity_overridden         
,invoice_complete               
,delivery_method                
,item_group_code                
,cannot_complete_before_date   
,cannot_complete_after_date    
,appt_status                   
,can_add_service_lines          
,pricing_uom                    
,capacity_uom                  
,pricing_quantity               
,shipped_quantity               
,fixed_capacity_qty_per_line    
,fixed_pricing_qty_per_line     
,wait_for_seq_line              
,sched_failure_reason_code     
,earliest_ship_date  
,earliest_delivery_date  
,cannot_meet_appt              
,promised_appt_start_date      
,promised_appt_end_date        
,segment                        
,segment_type                   
,earliest_schedule_date        
,timezone                      
,is_forwarding_allowed         
,is_procurement_allowed        
,reship_parent_line_key        
,is_price_info_only            
,level_of_service               
,first_iter_seq_no             
,last_iter_seq_no              
,createts                                
,modifyts                                
,createuserid                   
,modifyuserid                   
,createprogid                   
,modifyprogid                   
,lockid  
,ordering_uom                   
,pricing_quantity_conv_factor   
,pricing_quantity_strategy      
,invoiced_pricing_quantity      
,is_standalone_service         
,tran_discrepancy_qty           
,received_quantity              
,invoice_based_on_actuals       
,actual_pricing_quantity        
,fulfillment_type               
,serial_no                     
,reservation_mandatory          
,is_firm_predefined_node        
,intentional_backorder          
,future_avail_date             
,repricing_quantity             
,min_ship_by_date              
,kit_qty                       
,bom_config_key                
,bundle_fulfillment_mode       
,is_gift_wrap                  
,group_sequence_num            
,in_store_payment_required     
,item_not_exist                
,derived_from_ext_ord          
,is_eligible_for_ship_disc      
,backorder_notification_qty     
,is_price_matched               
,is_pick_up_now                
,item_is_in_hand               
,disposition_code              
,extn_mod_reason_code          
,extn_mod_reason_desc          
,extn_asn                      
,extn_parent_order_no          
,extn_item_id                   
,extn_order_item_id            
,extn_price_type  
,bundle_parent_order_line_key
,extn_secondary_return_reason
,extn_apply_label_fee
,extn_is_activation_complete
,extn_item_desc
,extn_return_carton_count
,extn_asn_quantity
,extn_light_color
,extn_light_type
,extn_number_of_sections
,extn_total_cartons
,extn_tree_height
,extn_tree_height_uom
,extn_apply_restocking_fee
,extn_return_pickup_date
,extn_pickup_confirmation_no
,extn_refund_shipping_cost
,extn_is_fulfilled_line
,extn_mfg_warranty_start_date
,extn_mfg_warranty_end_date
,extn_term
,extn_is_invoice_required
,extn_prem_guarantee_end_date
,extn_return_date
,extn_is_email_sent
,extn_return_required
,extn_parent_prime_line_no
,extn_parent_sub_line_no
,extn_prem_guarantee_start_date
,extn_reship_upcid      
,extn_parent_order_line_sku    
)
VALUES(
SOURCE.pk_order_detailid
,SOURCE.order_line_key
,SOURCE.order_header_key
,SOURCE.prime_line_no                   
,SOURCE.sub_line_no                     
,SOURCE.line_type                      
,SOURCE.order_class                    
,SOURCE.item_id  
,SOURCE.alternate_item_id             
,SOURCE.uom                            
,SOURCE.product_class                  
,try_cast( SOURCE.unit_price as float)                     
,SOURCE.cost_currency                 
,SOURCE.ordered_qty                    
,SOURCE.basic_capacity_required        
,SOURCE.option_capacity_required       
,SOURCE.dependent_on_line_key         
,SOURCE.current_work_order_key        
,SOURCE.dependency_shipping_rule      
,SOURCE.fill_quantity                  
,SOURCE.committed_quantity            
,SOURCE.dependency_ratio               
,SOURCE.maintain_ratio                
,SOURCE.merge_node                    
,SOURCE.parent_of_dependent_group      
,SOURCE.source_from_organization      
,SOURCE.chained_from_order_line_key   
,SOURCE.chained_from_order_header_key 
,SOURCE.derived_from_order_line_key   
,SOURCE.derived_from_order_header_key 
,SOURCE.derived_from_order_release_key
,SOURCE.distribution_rule_id          
,SOURCE.invoiced_quantity              
,SOURCE.over_receipt_quantity          
,SOURCE.return_reason                 
,SOURCE.shipnode_key                  
,SOURCE.procure_from_node             
,SOURCE.ship_to_key                   
,SOURCE.mark_for_key                  
,SOURCE.buyer_mark_for_node_id        
,TRY_TO_TIMESTAMP(SOURCE.req_delivery_date,''YYYYMMDDHHMISS'')            
,TRY_TO_TIMESTAMP(SOURCE.req_cancel_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(SOURCE.req_ship_date,''YYYYMMDDHHMISS'')           
,SOURCE.scac                          
,SOURCE.carrier_service_code          
,SOURCE.carrier_account_no            
,SOURCE.pickable_flag                  
,SOURCE.ship_together_no              
,SOURCE.hold_flag                      
,SOURCE.kit_code                      
,SOURCE.hold_reason_code              
,SOURCE.other_charges                  
,try_cast( SOURCE.line_total as float)                   
,try_cast( SOURCE.invoiced_line_total as float)       
,try_cast( SOURCE.invoiced_extended_price as float)    
,SOURCE.settled_quantity               
,SOURCE.settled_amount                 
,SOURCE.taxable_flag                   
,SOURCE.tax_exemption_certificate     
,SOURCE.discount_type                 
,SOURCE.discount_reference            
,SOURCE.gift_flag                      
,SOURCE.personalize_flag               
,SOURCE.personalize_code              
,SOURCE.department_code               
,SOURCE.customer_item  
,SOURCE.customer_item_description      
,SOURCE.item_weight                    
,SOURCE.item_weight_uom                
,SOURCE.item_description               
,SOURCE.item_short_description         
,SOURCE.reservation_id                
,SOURCE.reservation_pool              
,SOURCE.customer_po_no                
,SOURCE.customer_po_line_no           
,SOURCE.tax                            
,SOURCE.delivery_code                 
,SOURCE.original_ordered_qty           
,try_cast( SOURCE.list_price as float)                      
,try_cast( SOURCE.retail_price as float)                 
,SOURCE.discount_percentage            
,SOURCE.packlist_type                 
,SOURCE.supplier_item                 
,SOURCE.supplier_item_description     
,SOURCE.unit_cost                      
,SOURCE.upc_code                      
,SOURCE.fob                           
,SOURCE.manufacturer_name             
,SOURCE.manufacturer_item             
,SOURCE.manufacturer_item_desc        
,SOURCE.country_of_origin             
,SOURCE.isbn                          
,SOURCE.harmonized_code               
,SOURCE.ship_to_id                    
,SOURCE.product_line                  
,SOURCE.nmfc_code                     
,SOURCE.nmfc_class                    
,SOURCE.nmfc_description              
,SOURCE.tax_product_code               
,SOURCE.import_license_no             
,TRY_TO_TIMESTAMP(SOURCE.import_license_exp_date,''YYYYMMDDHHMISS'')             
,SOURCE.eccn_no                       
,SOURCE.schedule_b_code               
,SOURCE.supplier_code                 
,SOURCE.purpose                       
,SOURCE.receiving_node                
,SOURCE.buyer_receiving_node_id       
,SOURCE.shipment_consol_group_id      
,SOURCE.orig_order_line_key           
,SOURCE.line_seq_no                    
,SOURCE.split_qty                      
,TRY_TO_TIMESTAMP(SOURCE.pricing_date,''YYYYMMDDHHMISS'')                          
,SOURCE.pipeline_key                   
,SOURCE.condition_variable_1          
,SOURCE.condition_variable_2          
,SOURCE.is_price_locked                
,SOURCE.is_cost_overridden             
,SOURCE.is_capacity_overridden         
,SOURCE.invoice_complete               
,SOURCE.delivery_method                
,SOURCE.item_group_code                
,TRY_TO_TIMESTAMP(SOURCE.cannot_complete_before_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(SOURCE.cannot_complete_after_date,''YYYYMMDDHHMISS'')
,SOURCE.appt_status                   
,SOURCE.can_add_service_lines          
,SOURCE.pricing_uom                    
,SOURCE.capacity_uom                  
,SOURCE.pricing_quantity               
,SOURCE.shipped_quantity               
,SOURCE.fixed_capacity_qty_per_line    
,SOURCE.fixed_pricing_qty_per_line     
,SOURCE.wait_for_seq_line              
,SOURCE.sched_failure_reason_code     
,TRY_TO_TIMESTAMP(SOURCE.earliest_ship_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(SOURCE.earliest_delivery_date,''YYYYMMDDHHMISS'')
,SOURCE.cannot_meet_appt              
,TRY_TO_TIMESTAMP(SOURCE.promised_appt_start_date,''YYYYMMDDHHMISS'')   
,TRY_TO_TIMESTAMP(SOURCE.promised_appt_end_date,''YYYYMMDDHHMISS'')   
,SOURCE.segment                        
,SOURCE.segment_type                   
,TRY_TO_TIMESTAMP(SOURCE.earliest_schedule_date,''YYYYMMDDHHMISS'')     
,SOURCE.timezone                      
,SOURCE.is_forwarding_allowed         
,SOURCE.is_procurement_allowed        
,SOURCE.reship_parent_line_key        
,SOURCE.is_price_info_only            
,SOURCE.level_of_service               
,SOURCE.first_iter_seq_no             
,SOURCE.last_iter_seq_no              
,TRY_TO_TIMESTAMP(SOURCE.createts,''YYYYMMDDHHMISS'')                             
,TRY_TO_TIMESTAMP(SOURCE.modifyts,''YYYYMMDDHHMISS'')                             
,SOURCE.createuserid                   
,SOURCE.modifyuserid                   
,SOURCE.createprogid                   
,SOURCE.modifyprogid                   
,SOURCE.lockid  
,SOURCE.ordering_uom                   
,SOURCE.pricing_quantity_conv_factor   
,SOURCE.pricing_quantity_strategy      
,SOURCE.invoiced_pricing_quantity      
,SOURCE.is_standalone_service         
,SOURCE.tran_discrepancy_qty           
,SOURCE.received_quantity              
,SOURCE.invoice_based_on_actuals       
,SOURCE.actual_pricing_quantity        
,SOURCE.fulfillment_type               
,SOURCE.serial_no                     
,SOURCE.reservation_mandatory          
,SOURCE.is_firm_predefined_node        
,SOURCE.intentional_backorder          
,TRY_TO_TIMESTAMP(SOURCE.future_avail_date,''YYYYMMDDHHMISS'')      
,SOURCE.repricing_quantity             
,TRY_TO_TIMESTAMP(SOURCE.min_ship_by_date,''YYYYMMDDHHMISS'')          
,SOURCE.kit_qty                       
,SOURCE.bom_config_key                
,SOURCE.bundle_fulfillment_mode       
,SOURCE.is_gift_wrap                  
,SOURCE.group_sequence_num            
,SOURCE.in_store_payment_required     
,SOURCE.item_not_exist                
,SOURCE.derived_from_ext_ord          
,SOURCE.is_eligible_for_ship_disc      
,SOURCE.backorder_notification_qty     
,SOURCE.is_price_matched               
,SOURCE.is_pick_up_now                
,SOURCE.item_is_in_hand               
,SOURCE.disposition_code              
,SOURCE.extn_mod_reason_code          
,SOURCE.extn_mod_reason_desc          
,SOURCE.extn_asn                      
,SOURCE.extn_parent_order_no          
,SOURCE.extn_item_id                   
,SOURCE.extn_order_item_id            
,SOURCE.extn_price_type   
,SOURCE.bundle_parent_order_line_key
,SOURCE.extn_secondary_return_reason
,SOURCE.extn_apply_label_fee
,SOURCE.extn_is_activation_complete
,SOURCE.extn_item_desc
,SOURCE.extn_return_carton_count
,SOURCE.extn_asn_quantity
,SOURCE.extn_light_color
,SOURCE.extn_light_type
,SOURCE.extn_number_of_sections
,SOURCE.extn_total_cartons
,SOURCE.extn_tree_height
,SOURCE.extn_tree_height_uom
,SOURCE.extn_apply_restocking_fee
,TRY_TO_TIMESTAMP(SOURCE.extn_return_pickup_date,''YYYYMMDDHHMISS'')
,SOURCE.extn_pickup_confirmation_no
,SOURCE.extn_refund_shipping_cost
,SOURCE.extn_is_fulfilled_line
,TRY_TO_TIMESTAMP(SOURCE.extn_mfg_warranty_start_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(SOURCE.extn_mfg_warranty_end_date,''YYYYMMDDHHMISS'')
,SOURCE.extn_term
,SOURCE.extn_is_invoice_required
,TRY_TO_TIMESTAMP(SOURCE.extn_prem_guarantee_end_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(SOURCE.extn_return_date,''YYYYMMDDHHMISS'')
,SOURCE.extn_is_email_sent
,SOURCE.extn_return_required
,SOURCE.extn_parent_prime_line_no
,SOURCE.extn_parent_sub_line_no
,TRY_TO_TIMESTAMP(SOURCE.extn_prem_guarantee_start_date,''YYYYMMDDHHMISS'')
,SOURCE.extn_reship_upcid         
,SOURCE.extn_parent_order_line_sku
);

--RETURN ''here'';

CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.OrderDetailMultipartItems
AS
SELECT DISTINCT 
    toh.pk_order_headerid as fk_order_detailid
    ,stg.order_line_key
    ,stg.order_header_key
    ,stg.prime_line_no                   
    ,stg.sub_line_no                     
    ,stg.line_type                      
    ,stg.order_class                    
    ,stg.item_id  
    ,stg.alternate_item_id             
    ,stg.uom                            
    ,stg.product_class                  
    ,try_cast( stg.unit_price as float) as unit_price                     
    ,stg.cost_currency                 
    ,stg.ordered_qty                    
    ,stg.basic_capacity_required        
    ,stg.option_capacity_required       
    ,stg.dependent_on_line_key         
    ,stg.current_work_order_key        
    ,stg.dependency_shipping_rule      
    ,stg.fill_quantity                  
    ,stg.committed_quantity            
    ,stg.dependency_ratio               
    ,stg.maintain_ratio                
    ,stg.merge_node                    
    ,stg.parent_of_dependent_group      
    ,stg.source_from_organization      
    ,stg.chained_from_order_line_key   
    ,stg.chained_from_order_header_key 
    ,stg.derived_from_order_line_key   
    ,stg.derived_from_order_header_key 
    ,stg.derived_from_order_release_key
    ,stg.distribution_rule_id          
    ,stg.invoiced_quantity              
    ,stg.over_receipt_quantity          
    ,stg.return_reason                 
    ,stg.shipnode_key                  
    ,stg.procure_from_node             
    ,stg.ship_to_key                   
    ,stg.mark_for_key                  
    ,stg.buyer_mark_for_node_id        
    ,stg.req_delivery_date             
    ,stg.req_cancel_date   
    ,stg.req_ship_date                 
    ,stg.scac                          
    ,stg.carrier_service_code          
    ,stg.carrier_account_no            
    ,stg.pickable_flag                  
    ,stg.ship_together_no              
    ,stg.hold_flag                      
    ,stg.kit_code                      
    ,stg.hold_reason_code              
    ,stg.other_charges                  
    ,stg.line_total                     
    ,stg.invoiced_line_total            
    ,stg.invoiced_extended_price        
    ,stg.settled_quantity               
    ,stg.settled_amount                 
    ,stg.taxable_flag                   
    ,stg.tax_exemption_certificate     
    ,stg.discount_type                 
    ,stg.discount_reference            
    ,stg.gift_flag                      
    ,stg.personalize_flag               
    ,stg.personalize_code              
    ,stg.department_code               
    ,stg.customer_item  
    ,stg.customer_item_description      
    ,stg.item_weight                    
    ,stg.item_weight_uom                
    ,stg.item_description               
    ,stg.item_short_description         
    ,stg.reservation_id                
    ,stg.reservation_pool              
    ,stg.customer_po_no                
    ,stg.customer_po_line_no           
    ,stg.tax                            
    ,stg.delivery_code                 
    ,stg.original_ordered_qty           
    ,try_cast( stg.list_price as float) as list_price                 
    ,try_cast( stg.retail_price as float) as retail_price                
    ,stg.discount_percentage            
    ,stg.packlist_type                 
    ,stg.supplier_item                 
    ,stg.supplier_item_description     
    ,stg.unit_cost                      
    ,stg.upc_code                      
    ,stg.fob                           
    ,stg.manufacturer_name             
    ,stg.manufacturer_item             
    ,stg.manufacturer_item_desc        
    ,stg.country_of_origin             
    ,stg.isbn                          
    ,stg.harmonized_code               
    ,stg.ship_to_id                    
    ,stg.product_line                  
    ,stg.nmfc_code                     
    ,stg.nmfc_class                    
    ,stg.nmfc_description              
    ,stg.tax_product_code               
    ,stg.import_license_no             
    ,stg.import_license_exp_date                 
    ,stg.eccn_no                       
    ,stg.schedule_b_code               
    ,stg.supplier_code                 
    ,stg.purpose                       
    ,stg.receiving_node                
    ,stg.buyer_receiving_node_id       
    ,stg.shipment_consol_group_id      
    ,stg.orig_order_line_key           
    ,stg.line_seq_no                    
    ,stg.split_qty                      
    ,stg.pricing_date                            
    ,stg.pipeline_key                   
    ,stg.condition_variable_1          
    ,stg.condition_variable_2          
    ,stg.is_price_locked                
    ,stg.is_cost_overridden             
    ,stg.is_capacity_overridden         
    ,stg.invoice_complete               
    ,stg.delivery_method                
    ,stg.item_group_code                
    ,stg.cannot_complete_before_date   
    ,stg.cannot_complete_after_date    
    ,stg.appt_status                   
    ,stg.can_add_service_lines          
    ,stg.pricing_uom                    
    ,stg.capacity_uom                  
    ,stg.pricing_quantity               
    ,stg.shipped_quantity               
    ,stg.fixed_capacity_qty_per_line    
    ,stg.fixed_pricing_qty_per_line     
    ,stg.wait_for_seq_line              
    ,stg.sched_failure_reason_code     
    ,stg.earliest_ship_date  
    ,stg.earliest_delivery_date  
    ,stg.cannot_meet_appt              
    ,stg.promised_appt_start_date      
    ,stg.promised_appt_end_date        
    ,stg.segment                        
    ,stg.segment_type                   
    ,stg.earliest_schedule_date        
    ,stg.timezone                      
    ,stg.is_forwarding_allowed         
    ,stg.is_procurement_allowed        
    ,stg.reship_parent_line_key        
    ,stg.is_price_info_only            
    ,stg.level_of_service               
    ,stg.first_iter_seq_no             
    ,stg.last_iter_seq_no              
    ,stg.createts                                
    ,stg.modifyts                                
    ,stg.createuserid                   
    ,stg.modifyuserid                   
    ,stg.createprogid                   
    ,stg.modifyprogid                   
    ,stg.lockid  
    ,stg.ordering_uom                   
    ,stg.pricing_quantity_conv_factor   
    ,stg.pricing_quantity_strategy      
    ,stg.invoiced_pricing_quantity      
    ,stg.is_standalone_service         
    ,stg.tran_discrepancy_qty           
    ,stg.received_quantity              
    ,stg.invoice_based_on_actuals       
    ,stg.actual_pricing_quantity        
    ,stg.fulfillment_type               
    ,stg.serial_no                     
    ,stg.reservation_mandatory          
    ,stg.is_firm_predefined_node        
    ,stg.intentional_backorder          
    ,stg.future_avail_date             
    ,stg.repricing_quantity             
    ,stg.min_ship_by_date              
    ,stg.kit_qty                       
    ,stg.bom_config_key                
    ,stg.bundle_fulfillment_mode       
    ,stg.is_gift_wrap                  
    ,stg.group_sequence_num            
    ,stg.in_store_payment_required     
    ,stg.item_not_exist                
    ,stg.derived_from_ext_ord          
    ,stg.is_eligible_for_ship_disc      
    ,stg.backorder_notification_qty     
    ,stg.is_price_matched               
    ,stg.is_pick_up_now                
    ,stg.item_is_in_hand               
    ,stg.disposition_code              
    ,stg.extn_mod_reason_code          
    ,stg.extn_mod_reason_desc          
    ,stg.extn_asn                      
    ,stg.extn_parent_order_no          
    ,stg.extn_item_id                   
    ,stg.extn_order_item_id            
    ,stg.extn_price_type                
    ,stg.extn_secondary_return_reason  
    ,stg.extn_apply_label_fee           
    ,stg.extn_is_activation_complete   
    ,stg.extn_item_desc                
    ,stg.extn_return_carton_count       
    ,stg.extn_asn_quantity             
    ,stg.extn_light_color              
    ,stg.extn_light_type               
    ,stg.extn_number_of_sections       
    ,stg.extn_total_cartons            
    ,stg.extn_tree_height              
    ,stg.extn_tree_height_uom    
    ,mp.pk_order_detail_multipartid
    ,stg.bundle_parent_order_line_key
    ,stg.extn_apply_restocking_fee
    ,stg.extn_return_pickup_date
    ,stg.extn_pickup_confirmation_no
    ,stg.extn_refund_shipping_cost
    ,stg.extn_is_fulfilled_line
    ,stg.extn_mfg_warranty_start_date
    ,stg.extn_mfg_warranty_end_date
    ,stg.extn_term
    ,stg.extn_is_invoice_required
    ,stg.extn_prem_guarantee_end_date
    ,stg.extn_return_date
    ,stg.extn_is_email_sent
    ,stg.extn_return_required
    ,stg.extn_parent_prime_line_no
    ,stg.extn_parent_sub_line_no
    ,stg.extn_prem_guarantee_start_date
    ,stg.extn_reship_upcid
    ,stg.extn_parent_order_line_sku
    ,CAST(1 AS NUMBER(10, 0)) as revision
from 
	     TRANSFORMED.stg_ORDER_line_multipart AS stg
		INNER JOIN ANALYTICS.txn_order_header as toh on toh.order_header_key = stg.order_header_key and toh.entry_type is not null
        INNER JOIN ANALYTICS.txn_order_detail as tod on tod.fk_order_headerid = toh.pk_order_headerid 
		and	  stg.BUNDLE_PARENT_ORDER_LINE_KEY =tod.order_line_key
        INNER JOIN ANALYTICS.txn_order_detail_multipart mp on  stg.order_line_key = mp.order_line_key  and stg.BUNDLE_PARENT_ORDER_LINE_KEY = mp.BUNDLE_PARENT_ORDER_LINE_KEY 
		where stg.BUNDLE_PARENT_ORDER_LINE_KEY is not null;

        
UPDATE
	ANALYTICS.OrderDetailMultipartItems
SET
	Revision = CAST((aot.revision + 1) as int)
FROM
        ANALYTICS.OrderDetailMultipartItems as ttd
        inner join (
		SELECT
            MAX(aot.revision) as revision,
            aot.fk_order_detailid,
            aot.pk_order_detail_multipartid
        from
            ANALYTICS.audit_order_detail_multipart as aot
            inner join ANALYTICS.OrderDetailMultipartItems as abc on abc.fk_order_detailid = aot.fk_order_detailid and 
            abc.pk_order_detail_multipartid = aot.pk_order_detail_multipartid
        group by
			 aot.fk_order_detailid,
            aot.pk_order_detail_multipartid
	) as aot on ttd.pk_order_detail_multipartid = aot.pk_order_detail_multipartid
            and ttd.fk_order_detailid = aot.fk_order_detailid;


				INSERT INTO ANALYTICS.audit_order_detail_multipart(
			pk_order_detail_multipartid
,fk_order_detailid
,order_line_key
,order_header_key
,prime_line_no                   
,sub_line_no                     
,line_type                      
,order_class                    
,item_id  
,alternate_item_id             
,uom                            
,product_class                  
,unit_price                     
,cost_currency                 
,ordered_qty                    
,basic_capacity_required        
,option_capacity_required       
,dependent_on_line_key         
,current_work_order_key        
,dependency_shipping_rule      
,fill_quantity                  
,committed_quantity            
,dependency_ratio               
,maintain_ratio                
,merge_node                    
,parent_of_dependent_group      
,source_from_organization      
,chained_from_order_line_key   
,chained_from_order_header_key 
,derived_from_order_line_key   
,derived_from_order_header_key 
,derived_from_order_release_key
,distribution_rule_id          
,invoiced_quantity              
,over_receipt_quantity          
,return_reason                 
,shipnode_key                  
,procure_from_node             
,ship_to_key                   
,mark_for_key                  
,buyer_mark_for_node_id        
,req_delivery_date             
,req_cancel_date   
,req_ship_date                 
,scac                          
,carrier_service_code          
,carrier_account_no            
,pickable_flag                  
,ship_together_no              
,hold_flag                      
,kit_code                      
,hold_reason_code              
,other_charges                  
,line_total                     
,invoiced_line_total            
,invoiced_extended_price        
,settled_quantity               
,settled_amount                 
,taxable_flag                   
,tax_exemption_certificate     
,discount_type                 
,discount_reference            
,gift_flag                      
,personalize_flag               
,personalize_code              
,department_code               
,customer_item  
,customer_item_description      
,item_weight                    
,item_weight_uom                
,item_description               
,item_short_description         
,reservation_id                
,reservation_pool              
,customer_po_no                
,customer_po_line_no           
,tax                            
,delivery_code                 
,original_ordered_qty           
,list_price                     
,retail_price                   
,discount_percentage            
,packlist_type                 
,supplier_item                 
,supplier_item_description     
,unit_cost                      
,upc_code                      
,fob                           
,manufacturer_name             
,manufacturer_item             
,manufacturer_item_desc        
,country_of_origin             
,isbn                          
,harmonized_code               
,ship_to_id                    
,product_line                  
,nmfc_code                     
,nmfc_class                    
,nmfc_description              
,tax_product_code               
,import_license_no             
,import_license_exp_date                 
,eccn_no                       
,schedule_b_code               
,supplier_code                 
,purpose                       
,receiving_node                
,buyer_receiving_node_id       
,shipment_consol_group_id      
,orig_order_line_key           
,line_seq_no                    
,split_qty                      
,pricing_date                            
,pipeline_key                   
,condition_variable_1          
,condition_variable_2          
,is_price_locked                
,is_cost_overridden             
,is_capacity_overridden         
,invoice_complete               
,delivery_method                
,item_group_code                
,cannot_complete_before_date   
,cannot_complete_after_date    
,appt_status                   
,can_add_service_lines          
,pricing_uom                    
,capacity_uom                  
,pricing_quantity               
,shipped_quantity               
,fixed_capacity_qty_per_line    
,fixed_pricing_qty_per_line     
,wait_for_seq_line              
,sched_failure_reason_code     
,earliest_ship_date  
,earliest_delivery_date  
,cannot_meet_appt              
,promised_appt_start_date      
,promised_appt_end_date        
,segment                        
,segment_type                   
,earliest_schedule_date        
,timezone                      
,is_forwarding_allowed         
,is_procurement_allowed        
,reship_parent_line_key        
,is_price_info_only            
,level_of_service               
,first_iter_seq_no             
,last_iter_seq_no              
,createts                                
,modifyts                                
,createuserid                   
,modifyuserid                   
,createprogid                   
,modifyprogid                   
,lockid  
,ordering_uom                   
,pricing_quantity_conv_factor   
,pricing_quantity_strategy      
,invoiced_pricing_quantity      
,is_standalone_service         
,tran_discrepancy_qty           
,received_quantity              
,invoice_based_on_actuals       
,actual_pricing_quantity        
,fulfillment_type               
,serial_no                     
,reservation_mandatory          
,is_firm_predefined_node        
,intentional_backorder          
,future_avail_date             
,repricing_quantity             
,min_ship_by_date              
,kit_qty                       
,bom_config_key                
,bundle_fulfillment_mode       
,is_gift_wrap                  
,group_sequence_num            
,in_store_payment_required     
,item_not_exist                
,derived_from_ext_ord          
,is_eligible_for_ship_disc      
,backorder_notification_qty     
,is_price_matched               
,is_pick_up_now                
,item_is_in_hand               
,disposition_code              
,extn_mod_reason_code          
,extn_mod_reason_desc          
,extn_asn                      
,extn_parent_order_no          
,extn_item_id                   
,extn_order_item_id            
,extn_price_type                
,extn_secondary_return_reason  
,extn_apply_label_fee           
,extn_is_activation_complete   
,extn_item_desc                
,extn_return_carton_count       
,extn_asn_quantity             
,extn_light_color              
,extn_light_type               
,extn_number_of_sections       
,extn_total_cartons            
,extn_tree_height              
,extn_tree_height_uom 
,bundle_parent_order_line_key
,extn_apply_restocking_fee
,extn_return_pickup_date
,extn_pickup_confirmation_no
,extn_refund_shipping_cost
,extn_is_fulfilled_line
,extn_mfg_warranty_start_date
,extn_mfg_warranty_end_date
,extn_term
,extn_is_invoice_required
,extn_prem_guarantee_end_date
,extn_return_date
,extn_is_email_sent
,extn_return_required
,extn_parent_prime_line_no
,extn_parent_sub_line_no
,extn_prem_guarantee_start_date
,extn_reship_upcid      
,extn_parent_order_line_sku
,revision)
select
odmi.pk_order_detail_multipartid
,odmi.fk_order_detailid
,odmi.order_line_key
,odmi.order_header_key
,odmi.prime_line_no                   
,odmi.sub_line_no                     
,odmi.line_type                      
,odmi.order_class                    
,odmi.item_id  
,odmi.alternate_item_id             
,odmi.uom                            
,odmi.product_class                  
,odmi.unit_price                     
,odmi.cost_currency                 
,odmi.ordered_qty                    
,odmi.basic_capacity_required        
,odmi.option_capacity_required       
,odmi.dependent_on_line_key         
,odmi.current_work_order_key        
,odmi.dependency_shipping_rule      
,odmi.fill_quantity                  
,odmi.committed_quantity            
,odmi.dependency_ratio               
,odmi.maintain_ratio                
,odmi.merge_node                    
,odmi.parent_of_dependent_group      
,odmi.source_from_organization      
,odmi.chained_from_order_line_key   
,odmi.chained_from_order_header_key 
,odmi.derived_from_order_line_key   
,odmi.derived_from_order_header_key 
,odmi.derived_from_order_release_key
,odmi.distribution_rule_id          
,odmi.invoiced_quantity              
,odmi.over_receipt_quantity          
,odmi.return_reason                 
,odmi.shipnode_key                  
,odmi.procure_from_node             
,odmi.ship_to_key                   
,odmi.mark_for_key                  
,odmi.buyer_mark_for_node_id        
,TRY_TO_TIMESTAMP(odmi.req_delivery_date,''YYYYMMDDHHMISS'')     
,TRY_TO_TIMESTAMP(odmi.req_cancel_date,''YYYYMMDDHHMISS'') 
,TRY_TO_TIMESTAMP(odmi.req_ship_date,''YYYYMMDDHHMISS'')             
,odmi.scac                          
,odmi.carrier_service_code          
,odmi.carrier_account_no            
,odmi.pickable_flag                  
,odmi.ship_together_no              
,odmi.hold_flag                      
,odmi.kit_code                      
,odmi.hold_reason_code              
,odmi.other_charges                  
,try_cast( odmi.line_total as float)                      
,try_cast( odmi.invoiced_line_total as float)        
,try_cast( odmi.invoiced_extended_price as float)      
,odmi.settled_quantity               
,odmi.settled_amount                 
,odmi.taxable_flag                   
,odmi.tax_exemption_certificate     
,odmi.discount_type                 
,odmi.discount_reference            
,odmi.gift_flag                      
,odmi.personalize_flag               
,odmi.personalize_code              
,odmi.department_code               
,odmi.customer_item  
,odmi.customer_item_description      
,odmi.item_weight                    
,odmi.item_weight_uom                
,odmi.item_description               
,odmi.item_short_description         
,odmi.reservation_id                
,odmi.reservation_pool              
,odmi.customer_po_no                
,odmi.customer_po_line_no           
,odmi.tax                            
,odmi.delivery_code                 
,odmi.original_ordered_qty           
,odmi.list_price                     
,odmi.retail_price                   
,odmi.discount_percentage            
,odmi.packlist_type                 
,odmi.supplier_item                 
,odmi.supplier_item_description     
,odmi.unit_cost                      
,odmi.upc_code                      
,odmi.fob                           
,odmi.manufacturer_name             
,odmi.manufacturer_item             
,odmi.manufacturer_item_desc        
,odmi.country_of_origin             
,odmi.isbn                          
,odmi.harmonized_code               
,odmi.ship_to_id                    
,odmi.product_line                  
,odmi.nmfc_code                     
,odmi.nmfc_class                    
,odmi.nmfc_description              
,odmi.tax_product_code               
,odmi.import_license_no             
,TRY_TO_TIMESTAMP(odmi.import_license_exp_date,''YYYYMMDDHHMISS'')             
,odmi.eccn_no                       
,odmi.schedule_b_code               
,odmi.supplier_code                 
,odmi.purpose                       
,odmi.receiving_node                
,odmi.buyer_receiving_node_id       
,odmi.shipment_consol_group_id      
,odmi.orig_order_line_key           
,odmi.line_seq_no                    
,odmi.split_qty                      
,TRY_TO_TIMESTAMP(odmi.pricing_date,''YYYYMMDDHHMISS'')                          
,odmi.pipeline_key                   
,odmi.condition_variable_1          
,odmi.condition_variable_2          
,odmi.is_price_locked                
,odmi.is_cost_overridden             
,odmi.is_capacity_overridden         
,odmi.invoice_complete               
,odmi.delivery_method                
,odmi.item_group_code                
,TRY_TO_TIMESTAMP(odmi.cannot_complete_before_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(odmi.cannot_complete_after_date,''YYYYMMDDHHMISS'')
,odmi.appt_status                   
,odmi.can_add_service_lines          
,odmi.pricing_uom                    
,odmi.capacity_uom                  
,odmi.pricing_quantity               
,odmi.shipped_quantity               
,odmi.fixed_capacity_qty_per_line    
,odmi.fixed_pricing_qty_per_line     
,odmi.wait_for_seq_line              
,odmi.sched_failure_reason_code     
,TRY_TO_TIMESTAMP(odmi.earliest_ship_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(odmi.earliest_delivery_date,''YYYYMMDDHHMISS'')
,odmi.cannot_meet_appt              
,TRY_TO_TIMESTAMP(odmi.promised_appt_start_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(odmi.promised_appt_end_date,''YYYYMMDDHHMISS'')  
,odmi.segment                        
,odmi.segment_type                   
,TRY_TO_TIMESTAMP(odmi.earliest_schedule_date,''YYYYMMDDHHMISS'')    
,odmi.timezone                      
,odmi.is_forwarding_allowed         
,odmi.is_procurement_allowed        
,odmi.reship_parent_line_key        
,odmi.is_price_info_only            
,odmi.level_of_service               
,odmi.first_iter_seq_no             
,odmi.last_iter_seq_no              
,TRY_TO_TIMESTAMP(odmi.createts,''YYYYMMDDHHMISS'')                             
,TRY_TO_TIMESTAMP(odmi.modifyts,''YYYYMMDDHHMISS'')                           
,odmi.createuserid                   
,odmi.modifyuserid                   
,odmi.createprogid                   
,odmi.modifyprogid                   
,odmi.lockid  
,odmi.ordering_uom                   
,odmi.pricing_quantity_conv_factor   
,odmi.pricing_quantity_strategy      
,odmi.invoiced_pricing_quantity      
,odmi.is_standalone_service         
,odmi.tran_discrepancy_qty           
,odmi.received_quantity              
,odmi.invoice_based_on_actuals       
,odmi.actual_pricing_quantity        
,odmi.fulfillment_type               
,odmi.serial_no                     
,odmi.reservation_mandatory          
,odmi.is_firm_predefined_node        
,odmi.intentional_backorder          
,TRY_TO_TIMESTAMP(odmi.future_avail_date,''YYYYMMDDHHMISS'')        
,odmi.repricing_quantity             
,TRY_TO_TIMESTAMP(odmi.min_ship_by_date,''YYYYMMDDHHMISS'')       
,odmi.kit_qty                       
,odmi.bom_config_key                
,odmi.bundle_fulfillment_mode       
,odmi.is_gift_wrap                  
,odmi.group_sequence_num            
,odmi.in_store_payment_required     
,odmi.item_not_exist                
,odmi.derived_from_ext_ord          
,odmi.is_eligible_for_ship_disc      
,odmi.backorder_notification_qty     
,odmi.is_price_matched               
,odmi.is_pick_up_now                
,odmi.item_is_in_hand               
,odmi.disposition_code              
,odmi.extn_mod_reason_code          
,odmi.extn_mod_reason_desc          
,odmi.extn_asn                      
,odmi.extn_parent_order_no          
,odmi.extn_item_id                   
,odmi.extn_order_item_id            
,odmi.extn_price_type                
,odmi.extn_secondary_return_reason  
,odmi.extn_apply_label_fee           
,odmi.extn_is_activation_complete   
,odmi.extn_item_desc                
,odmi.extn_return_carton_count       
,odmi.extn_asn_quantity             
,odmi.extn_light_color              
,odmi.extn_light_type               
,odmi.extn_number_of_sections       
,odmi.extn_total_cartons            
,odmi.extn_tree_height              
,odmi.extn_tree_height_uom    
,odmi.bundle_parent_order_line_key
,odmi.extn_apply_restocking_fee
,TRY_TO_TIMESTAMP(odmi.extn_return_pickup_date,''YYYYMMDDHHMISS'')
,odmi.extn_pickup_confirmation_no
,odmi.extn_refund_shipping_cost
,odmi.extn_is_fulfilled_line
,TRY_TO_TIMESTAMP(odmi.extn_mfg_warranty_start_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(odmi.extn_mfg_warranty_end_date,''YYYYMMDDHHMISS'')
,odmi.extn_term
,odmi.extn_is_invoice_required
,TRY_TO_TIMESTAMP(odmi.extn_prem_guarantee_end_date,''YYYYMMDDHHMISS'')
,TRY_TO_TIMESTAMP(odmi.extn_return_date,''YYYYMMDDHHMISS'')
,odmi.extn_is_email_sent
,odmi.extn_return_required
,odmi.extn_parent_prime_line_no
,odmi.extn_parent_sub_line_no
,TRY_TO_TIMESTAMP(odmi.extn_prem_guarantee_start_date,''YYYYMMDDHHMISS'')
,odmi.extn_reship_upcid
,odmi.extn_parent_order_line_sku
,odmi.revision
from 
ANALYTICS.OrderDetailMultipartItems as odmi;


	MERGE INTO RAW.raw_ORDER_header AS target
USING (
SELECT DISTINCT 
    roh.ORDER_NO,
    roh.ORDER_HEADER_KEY,
    roh.modifyts,
    -- Add other columns that need to be updated (use appropriate values)
    ''Processed'' AS processing_status,
    '''' AS processing_comment,
    '''' AS processing_errortype
FROM RAW.raw_ORDER_header AS roh
INNER JOIN TRANSFORMED.stg_ORDER_header AS rod 
    ON rod.ORDER_NO = roh.ORDER_NO
    AND rod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY 
    AND roh.modifyts = rod.modifyts
INNER JOIN ANALYTICS.TempAmendOrders AS tod 
    ON tod.source_ref_num = roh.ORDER_NO 
    AND tod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY 
    AND tod.txn_id = rod.txn_id
WHERE 
    roh.processing_status IN (''Pending'', ''Failed'')

) AS source
ON (target.ORDER_NO = source.ORDER_NO 
    AND target.ORDER_HEADER_KEY = source.ORDER_HEADER_KEY 
    AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;
		
		
MERGE INTO RAW.raw_ORDER_header AS target
USING (
SELECT DISTINCT 
    roh.ORDER_NO,
    roh.ORDER_HEADER_KEY,
    roh.modifyts,
    -- Add other columns that need to be updated (use appropriate values)
    ''Processed'' AS processing_status,
    '''' AS processing_comment,
    '''' AS processing_errortype
FROM RAW.raw_ORDER_header AS roh
INNER JOIN TRANSFORMED.stg_ORDER_header AS rod 
    ON rod.ORDER_NO = roh.ORDER_NO 
    AND rod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY 
    AND roh.modifyts = rod.modifyts
LEFT JOIN ANALYTICS.TempAmendOrders AS tod 
    ON tod.source_ref_num = roh.customer_po_no 
    AND tod.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY
WHERE 
    roh.processing_status IN (''Pending'', ''Failed'')
    AND tod.source_ref_num IS NOT NULL
	AND roh.order_name = ''MIGRATED''

) AS source
ON (target.ORDER_NO = source.ORDER_NO AND target.ORDER_HEADER_KEY = source.ORDER_HEADER_KEY AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;




	MERGE INTO RAW.raw_ORDER_line AS target
USING (
SELECT DISTINCT 
    roh.ORDER_LINE_KEY,
    roh.PRIME_LINE_NO,
    roh.modifyts,
    -- Add other columns that need to be updated (use appropriate values)
    ''Processed'' AS processing_status,
    '''' AS processing_comment,
    '''' AS processing_errortype
FROM RAW.raw_ORDER_line AS roh
INNER JOIN TRANSFORMED.stg_ORDER_line AS rod 
    ON rod.ORDER_LINE_KEY = roh.ORDER_LINE_KEY
    AND rod.PRIME_LINE_NO = roh.PRIME_LINE_NO 
    AND roh.modifyts = rod.modifyts
INNER JOIN ANALYTICS.TempAmendOrderDetails AS tod 
    ON tod.ext_line_id = roh.ORDER_LINE_KEY 
    AND tod.prime_line_num = rod.PRIME_LINE_NO
WHERE 
    roh.processing_status IN (''Pending'', ''Failed'')

) AS source
ON (target.ORDER_LINE_KEY = source.ORDER_LINE_KEY 
    AND target.PRIME_LINE_NO = source.PRIME_LINE_NO 
    AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;





	MERGE INTO RAW.raw_ORDER_line AS target
USING (
SELECT DISTINCT 
    roh.ORDER_LINE_KEY,
    roh.PRIME_LINE_NO,
    roh.modifyts,
    -- Add other columns that need to be updated (use appropriate values)
    ''Processed'' AS processing_status,
    '''' AS processing_comment,
    '''' AS processing_errortype
FROM RAW.raw_ORDER_line AS roh
INNER JOIN TRANSFORMED.stg_ORDER_line_multipart AS rod 
    ON rod.ORDER_LINE_KEY = roh.ORDER_LINE_KEY
    AND rod.PRIME_LINE_NO = roh.PRIME_LINE_NO 
    AND roh.modifyts = rod.modifyts
INNER JOIN ANALYTICS.OrderDetailMultipartItems AS tod 
    ON tod.ORDER_LINE_KEY = roh.ORDER_LINE_KEY 
    AND tod.PRIME_LINE_NO = rod.PRIME_LINE_NO
WHERE 
    roh.processing_status IN (''Pending'', ''Failed'')

) AS source
ON (target.ORDER_LINE_KEY = source.ORDER_LINE_KEY 
    AND target.PRIME_LINE_NO = source.PRIME_LINE_NO 
    AND target.modifyts = source.modifyts)
WHEN MATCHED THEN
    UPDATE
    SET
        target.processing_status = source.processing_status,
        target.processing_comment = source.processing_comment,
        target.processing_errortype = source.processing_errortype;

   
        
SELECT COUNT(*) INTO
        :toBeProcessedRecordCount 
    FROM
        TRANSFORMED.stg_ORDER_header;




SELECT
         COUNT(*) INTO :toBeProcessedLineRecordCount
    FROM
        TRANSFORMED.stg_ORDER_line;

		SELECT
        :toBeProcessedLineRecordCount =   :toBeProcessedLineRecordCount + COUNT(*)
    FROM
        TRANSFORMED.stg_ORDER_line_multipart;


SELECT
        :prcessedHeaderRecordCount = :prcessedHeaderRecordCount + COUNT(*)
    FROM
        ANALYTICS.TempAmendOrders;




UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    --SET to_be_processed = (SELECT COUNT(*) FROM transformed.stg_ORDER_inbox)
    WHERE file_name = ''YFS_ORDER_HEADER'';


SELECT
        :prcessedLineRecordCount = :prcessedLineRecordCount + COUNT(*)
    FROM
        ANALYTICS.OrderDetailMultipartItems;


SELECT
        :prcessedLineRecordCount = :prcessedLineRecordCount + COUNT(*)
    FROM
        ANALYTICS.TempAmendOrderDetails;
        

UPDATE analytics.log_files_import_status
    SET to_be_processed = :toBeProcessedRecordCount
    --SET to_be_processed = (SELECT COUNT(*) FROM transformed.stg_ORDER_inbox)
    WHERE file_name = ''YFS_ORDER_LINE'';

--drop table #updatedOrderDetails;
DROP TABLE ANALYTICS.createdOrders;
DROP TABLE ANALYTICS.updatedOrders;
DROP TABLE ANALYTICS.OrderDetailMultipartItems;
DROP TABLE ANALYTICS.UPDATEDORDERCUSTOMER;
	--DROP TABLE #UPDATEDORDERADDRESSTABLE;
DROP TABLE ANALYTICS.updatedOrderDetails;
DROP TABLE ANALYTICS.TempAmendOrders;
DROP TABLE ANALYTICS.TempAmendOrderDetails;

-- Drop tables
DROP TABLE IF EXISTS ANALYTICS.CREATEDORDERCUSTOMER;
DROP TABLE IF EXISTS ANALYTICS.CREATEDORDERADDRESSTABLE;
DROP TABLE IF EXISTS ANALYTICS.createdOrderDetails;
DROP TABLE IF EXISTS ANALYTICS.TempORDER_Orders;
DROP TABLE IF EXISTS ANALYTICS.TempOrderDetails;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;

     UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_HEADER'';
            
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
    RETURN error_object;


END';
