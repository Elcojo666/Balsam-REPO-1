USE DATABASE DEV;

CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.USP_GETORDERMIGRATIONDATABYIDRANGE("STARTHEADERID" NUMBER(38,0), "ENDHEADERID" NUMBER(38,0), "DATEFROM" TIMESTAMP_NTZ(9) DEFAULT null, "DATETO" TIMESTAMP_NTZ(9) DEFAULT null)
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
SELECT_STATEMENT VARCHAR;
RES RESULTSET;
BEGIN 

CREATE OR REPLACE TEMPORARY TABLE ORDER_INFO (
    pk_order_headerid BIGINT NOT NULL,
    order_date TIMESTAMP_NTZ,  -- Equivalent to DATETIME in SQL Server
    FK_CUSTOMERID BIGINT NOT NULL,
    source_ref_num VARCHAR(50) NOT NULL,  -- Equivalent to NVARCHAR(50)
    email_address VARCHAR(320),  -- NULL by default
    risk_status VARCHAR(50),
    salesrep_customerid VARCHAR(50),
    shpping_fee_amount DECIMAL(38, 2),  -- Specify precision and scale if required
    ship_residential BOOLEAN,  -- Equivalent to BIT
    tax_amount DECIMAL(38, 2),
    discount_amount DECIMAL(38, 2),
    payment_amount DECIMAL(38, 2),
    order_comments STRING,  -- Equivalent to NVARCHAR(MAX)
    order_notes STRING,
    original_order_number VARCHAR(50),
    group_control_number INT,
    extn_order_locale_code VARCHAR(50),
    fk_parent_order_headerid BIGINT,
    fk_shipping_methodid BIGINT,
    fk_sourceid SMALLINT,
    fk_order_statusid SMALLINT,
    fk_shipping_addressid BIGINT,
    fk_billing_addressid BIGINT,
    fk_currencyid INT,
    fk_order_typeid SMALLINT
);

INSERT INTO ORDER_INFO
SELECT 
    pk_order_headerid,
    order_date,
    fk_customerid,
    source_ref_num,
    email_address,
    risk_status,
    salesrep_customerid,
    shpping_fee_amount,
    ship_residential,
    tax_amount,
    discount_amount,
    payment_amount,
    order_comments,
    order_notes,
    original_order_number,
    group_control_number,
    extn_order_locale_code,
    fk_parent_order_headerid,
    fk_shipping_methodid,
    fk_sourceid,
    fk_order_statusid,
    fk_shipping_addressid,
    fk_billing_addressid,
    fk_currencyid,
    fk_order_typeid
FROM txn_order_header AS h
WHERE h.pk_order_headerid BETWEEN :StartHeaderId AND :EndHeaderId 
AND h.fk_sourceid NOT IN (3, 5, 12, 19, 28, 30, 32, 33, 42);

-- Step 3: Perform the DELETE operation
DELETE FROM ORDER_INFO
WHERE :datefrom IS NOT NULL
AND order_date > :datefrom
AND order_date < IFNULL(:dateto, CURRENT_TIMESTAMP());

SELECT_STATEMENT := ''
SELECT DISTINCT
    toh.pk_order_headerid as "pk_order_headerid",
    tod.pk_order_detailid as "pk_order_detailid",
    DCC.source_ref_num as "BillToID",
    TOH.ORDER_DATE AS "OrderDate",
    CASE 
        WHEN dp.platform_name = ''''Hybris'''' THEN TOH.SOURCE_REF_NUM
        ELSE NULL
    END AS "OrderNo",
    DSM.SHIPPING_METHOD_NAME AS "CarrierServiceCode",
    todl.shippingmethodid AS "LevelOfService",
    dot.order_type_name AS "OrderType",
    tod.prime_line_num AS "PrimeLineNo",
    COALESCE(DCI.FIRST_NAME, tabi.first_name) AS "CustomerFirstName",
    COALESCE(DCI.LAST_NAME, tabi.last_name) AS "CustomerLastName",
    toh.email_address AS "CustomerEMailID",
    COALESCE(DCI.MOBI_PHONE_PRIMARY, DCI.MOBI_PHONE_secondary, DCI.home_PHONE_PRIMARY, DCI.home_PHONE_secondary, tabi.phone_number) AS "CustomerPhoneNo",
    COALESCE(DCA.POSTAL_CODE, tabi.postal_code) AS "CustomerZipCode",
    TOH.SOURCE_REF_NUM AS "CustomerPONo",
    DCI.CUST_TYPE AS "ExtnCustomerType",
    tbp.financed_by_affirm AS "FinancedByAffirm",
    TOH.risk_status AS "ExtnRiskStatus",
    toh.salesrep_customerid AS "ExtnSalesRepCustomerID",
    TOD.QUANTITY AS "OrderedQty",
    TOD.PRODUCT_PRICE AS "UnitPrice",
    TOD.TOTAL_PRICE AS "LineTotal",
    TOH.shpping_fee_amount AS "SHIPPING_FEE",
    TOD.PERSONALIZATION_FEE as "PERSONALIZATION_FEE",
    dc.currency_code AS "Currency",
    TASH.pk_addressid AS "Ship_ADDRESSId",
    TASH.ADDRESS1 AS "Ship_ADDRESS1",
    TASH.ADDRESS2 AS "Ship_ADDRESS2",
    TASH.CITY AS "Ship_CITY",
    TASH.COUNTRY AS "Ship_COUNTRY",
    TASH.FIRST_NAME AS "Ship_FIRST_NAME",
    TASH.LAST_NAME AS "Ship_LAST_NAME",
    TASH.STATE AS "Ship_STATE",
    TASH.phone_number AS "Ship_phone_number",
    TASH.postal_code AS "Ship_postal_code",
    TASH.company_name AS "Ship_Company",
    toh.email_address AS "Ship_EMAIL_PRIMARY",
    CASE 
        WHEN TOH.ship_residential = 1 THEN ''''N''''
        WHEN TOH.ship_residential = 0 THEN ''''Y''''
        ELSE NULL
    END AS "IsCommercialShipAddress",
    TABI.pk_addressid AS "Bill_ADDRESSId",
    TABI.ADDRESS1 AS "Bill_ADDRESS1",
    TABI.ADDRESS2 AS "Bill_ADDRESS2",
    TABI.CITY AS "Bill_CITY",
    TABI.COUNTRY AS "Bill_COUNTRY",
    TABI.FIRST_NAME AS "Bill_FIRST_NAME",
    TABI.LAST_NAME AS "Bill_LAST_NAME",
    TABI.STATE AS "Bill_STATE",
    TABI.phone_number AS "Bill_phone_number",
    TABI.postal_code AS "Bill_postal_code",
    TABI.company_name AS "Bill_Company",
    toh.email_address AS "Bill_EMAIL_PRIMARY",
    CASE 
        WHEN TOH.ship_residential = 1 THEN ''''N''''
        WHEN TOH.ship_residential = 0 THEN ''''Y''''
        ELSE NULL
    END AS "IsCommercialBillAddress",
    TOHP.source_ref_num AS "ExtnParentOrderNo",
    CASE 
        WHEN dp.platform_name = ''''Store'''' THEN ''''TAX''''
        ELSE totx.tax_name 
    END AS "OrderTaxName",
    CASE 
        WHEN dp.platform_name = ''''Store'''' THEN 1
        ELSE totx.pk_order_taxid 
    END AS "OrderTaxId",
    CASE 
        WHEN dp.platform_name = ''''Store'''' THEN toh.tax_amount
        ELSE totx.tax_amount 
    END AS "OrderTax",
    totx.tax_rate AS "OrderTaxRate",
    totx.avalara_transaction_id AS "order_avalara_transaction_id",
    totx.tax_product_code AS "order_tax_product_code",
    totx.tax_code AS "order_tax_code",
    totx.oms_charge_name AS "order_oms_charge_name",
    totx.item_code AS "order_item_code",
    totx.is_avalara_flag AS "order_is_avalara_flag",
    totx.tax_type AS "order_tax_type",
tof.pk_order_feeid AS "OrderChargeId",
CASE 
    WHEN dp.platform_name = ''''Store'''' THEN ''''FEE''''
    ELSE tof.fee_type 
END AS "OrderChargeName",
tof.fee_amount AS "OrderChargePerLine",
todf.pk_order_detail_feeid AS "ChargeId",
todf.fee_type AS "ChargeName",
todf.fee_amount AS "ChargePerLine",
todt.pk_order_detail_taxid AS "TaxId",
todt.tax_name AS "TaxName",
todt.tax_amount AS "Tax",
todt.tax_rate AS "TaxRate",
todt.avalara_transaction_id AS "avalara_transaction_id",
todt.tax_product_code AS "tax_product_code",
todt.tax_code AS "tax_code",
todt.oms_charge_name AS "oms_charge_name",
todt.item_code AS "item_code",
todt.is_avalara_flag AS "is_avalara_flag",
todt.tax_type AS "tax_type",
dp.platform_name AS "EntryType",
db.storecode AS "EnterpriseCode",
db.storecode AS "SellerOrganizationCode",
tt.fk_warehouseid AS "ShipNode",
tos.order_status_name AS "OrderStatus",
dods.order_status_name AS "Status",
dul.upc_code AS "ItemID",
dsp.sku_code AS "ItemCode",
COALESCE(toa.upc_code, dul.upc_code) AS "ShipmentItemID",
tod.fk_skuproductid AS "skuId",
CASE 
    WHEN dp.platform_name = ''''Store'''' THEN 1
    ELSE todc.pk_order_discountid 
END AS "OrderDiscountId",
todc.coupon_code AS "OrderCouponCode",
todc.discount_name AS "OrderDiscountName",
todc.discount_code AS "OrderDiscountCode",
CASE 
    WHEN dp.platform_name = ''''Store'''' THEN toh.discount_amount
    ELSE ABS(todc.discount_amount) 
END AS "OrderDiscountAmount",
toddsc.pk_order_detail_discountid AS "LineDiscountId",
toddsc.coupon_code AS "LineCouponCode",
toddsc.discount_name AS "LineDiscountName",
toddsc.discount_code AS "LineDiscountCode",
ABS(toddsc.discount_amount) AS "LineDiscountAmount",
tt.tracking_number AS "TrackingNo",
tt.quantity AS "Ship_Quantity",
todl.CarrierCode AS "SCAC",
toe.supplier_id AS "VendorID",
toe.supplier_name AS "VendorName",
NULL AS "ActualDeliveryDate",
tt.ship_date AS "ActualShipmentDate",
oadh.quantity AS "Released_Quantity",
oadh.Upc AS "SubLineUPC",
oadh.WarehouseID AS "SubLineShipNode",
oadh.CarrierCode AS "SubLineSCAC",
oadh.WarehouseShipMethod AS "SubLineCarrierServiceCode",
tp.payment_date AS "payment_date",
CASE 
    WHEN dp.platform_name IN (''''Store'''', ''''Amazon'''', ''''WilliamSonomaEDI'''', ''''PotteryBarnEDI'''', ''''NordstromDSCO'''', ''''Wayfair'''', ''''NordstromRackDSCO'''') 
    THEN toh.payment_amount 
    ELSE tp.payment_amount 
END AS "payment_amount",
tp.transactionid AS "transactionid",
tp.ext_paymentid AS "Payment_Reference1",
dpm.payment_method_name AS "payment_method_name",
tbp.cardholder_name AS "cardholder_name",
tbp.credit_card_number AS "credit_card_number",
tbp.card_type AS "card_type",
tbp.expiration_date AS "expiration_date",
tp.cc_last4 AS "DisplayCreditCardNo",
tbp.payment_method_token AS "PaymentMethodToken",
tbp.credit_card_unique_identifier AS "CreditCardId",
tp.seq_no AS "PaymentSeqNo",
dpt.payment_type_name AS "PaymentIdentifier",
toh.order_notes AS "NoteText",
toh.order_comments AS "InstructionText",
db.BrandCodeForWHM AS "BrandCode",
db.pk_brandid AS "BrandID",
tod.options AS "options",
(-1 * tbp.amount_submitted_for_settlement) AS "RequestAmount",
contract_id AS "ContractId",
end_date AS "EndTS",
cancel_date AS "CancelTS",
tow.start_date AS "StartTS",
tow.status AS "WarrantyStatus",
type_ AS "Type",
warranty_type AS "WarrantyType",
CASE 
    WHEN dp.platform_name IN (''''WilliamSonomaEDI'''', ''''PotteryBarnEDI'''', ''''Wayfair'''') 
    THEN TOH.original_order_number 
    ELSE NULL 
END AS "custcustPoNo",
TOH.group_control_number AS "EDIGCN",
CASE 
    WHEN tod.manufacture_year IS NOT NULL 
    THEN CONCAT(''''20'''', tod.manufacture_year)
    ELSE NULL 
END AS "ManufactureYear",
tod.tree_height AS "tree_height",
tod.light_type AS "light_type",
tod.light_color AS "light_color",
tod.number_of_cartons AS "number_of_cartons",
tod.number_of_sections AS "number_of_sections",
toh.extn_order_locale_code AS "extn_order_locale_code",
tow.extn_premium_guarantee_end_date AS "ExtnPremiumGuaranteeEndDate"
FROM ORDER_INFO AS TOH
LEFT JOIN ANALYTICS.TXN_ORDER_HEADER TOHP ON TOH.fk_parent_order_headerid = TOHP.PK_ORDER_HEADERID
LEFT JOIN ANALYTICS.TXN_ORDER_STATUS TOSS ON TOSS.fk_order_headerid = TOH.PK_ORDER_HEADERID
LEFT JOIN ANALYTICS.TXN_ORDER_DETAIL TOD ON TOD.FK_ORDER_HEADERID = TOH.PK_ORDER_HEADERID
LEFT JOIN ANALYTICS.sku_product dsp ON dsp.pk_skuproductid = tod.fk_skuproductid
LEFT JOIN ANALYTICS.CUSTOMER DCC ON DCC.pk_customerid = TOH.FK_CUSTOMERID
LEFT JOIN ANALYTICS.CUSTOMER_INFO DCI ON DCI.FK_CUSTOMERID = TOH.FK_CUSTOMERID
LEFT JOIN ANALYTICS.CUSTOMER_ADDRESS DCA ON DCA.FK_CUSTOMER_INFO_ID = DCI.PK_CUSTOMER_INFO_ID
LEFT JOIN MASTER.DIM_SHIPPING_METHOD DSM ON DSM.pk_shipping_methodid = TOH.fk_shipping_methodid
LEFT JOIN MASTER.dim_order_status tos ON tos.pk_order_statusid = COALESCE(toss.fk_order_statusid, toh.fk_order_statusid)
LEFT JOIN MASTER.dim_source ds ON ds.pk_sourceid = toh.fk_sourceid
LEFT JOIN MASTER.dim_platform dp ON dp.pk_platformid = ds.fk_platformid
LEFT JOIN MASTER.dim_brand db ON db.pk_brandid = ds.fk_brandid
LEFT JOIN ANALYTICS.TXN_ADDRESS TASH ON TASH.PK_ADDRESSID = TOH.fk_shipping_addressid
LEFT JOIN ANALYTICS.TXN_ADDRESS TABI ON TABI.PK_ADDRESSID = TOH.fk_billing_addressid
LEFT JOIN ANALYTICS.txn_tracking tt ON tt.fk_order_detailid = tod.pk_order_detailid
LEFT JOIN ANALYTICS.TXN_ORDER_DETAIL_FEE todf ON todf.fk_order_detailid = tod.pk_order_detailid AND todf.fee_type NOT IN (''''Personalization'''', ''''FEE-PERSONALIZE'''')
LEFT JOIN ANALYTICS.TXN_ORDER_DETAIL_TAX todt ON todt.fk_order_detailid = tod.pk_order_detailid
LEFT JOIN ANALYTICS.TXN_ORDER_DELIVERED todl ON todl.fk_order_headerid = toh.pk_order_headerid AND todl.fk_skuproductid = tod.fk_skuproductid
LEFT JOIN ANALYTICS.TXN_ORDER_ALLOCATION toa ON toa.fk_order_headerid = toh.pk_order_headerid AND toa.fk_skuproductid = tod.fk_skuproductid
LEFT JOIN ANALYTICS.MAP_SKU_UPC msu ON msu.fk_productid = dsp.pk_skuproductid
LEFT JOIN ANALYTICS.upc dull ON dull.pk_upcid = msu.fk_upcid
LEFT JOIN ANALYTICS.upc dul ON dul.pk_upcid = tt.fk_upcid
LEFT JOIN ANALYTICS.txn_payment tp ON tp.fk_order_headerid = toh.PK_ORDER_HEADERID AND tp.isdeleted = 0
LEFT JOIN MASTER.DIM_PAYMENT_METHOD dpm ON dpm.pk_payment_method_id = tp.fk_payment_methodid
LEFT JOIN analytics.txn_braintree_payments tbp ON tbp.transaction_id = tp.transactionid
LEFT JOIN ANALYTICS.TXN_PAYPAL_PAYMENTS tpp ON tpp.transaction_id = tp.transactionid
LEFT JOIN ANALYTICS.upc du ON du.upc_code = todl.Upc
LEFT JOIN MASTER.dim_currency dc ON dc.pk_currencyid = toh.fk_currencyid
LEFT JOIN ANALYTICS.TXN_ORDER_DETAIL_STATUS tods ON tods.pk_order_detailid = tod.pk_order_detailid
LEFT JOIN MASTER.dim_order_status dods ON tods.fk_order__detail_statusid = dods.pk_order_statusid
LEFT JOIN ANALYTICS.txn_order_discount todsc ON todsc.fk_order_headerid = toh.pk_order_headerid
LEFT JOIN ANALYTICS.txn_order_detail_discount toddsc ON toddsc.fk_order_detailid = tod.pk_order_detailid
LEFT JOIN MASTER.DIM_ORDER_TYPE dot ON dot.pk_order_typeid = toh.fk_order_typeid
LEFT JOIN ANALYTICS.TXN_ORDER_EXTENDED toe ON toe.fk_order_headerid = toh.pk_order_headerid
LEFT JOIN ANALYTICS.TXN_ORDER_TAX totx ON totx.fk_order_headerid = toh.pk_order_headerid
LEFT JOIN ANALYTICS.txn_order_fee tof ON tof.fk_order_headerid = toh.pk_order_headerid AND tof.fee_type <> ''''FEE-PERSONALIZE''''
LEFT JOIN ANALYTICS.txn_order_discount todc ON todc.fk_order_headerid = toh.pk_order_headerid
LEFT JOIN MASTER.dim_payment_type dpt ON tp.fk_payment_typeid = dpt.pk_payment_typeid
LEFT JOIN MASTER.sourcemap sm ON sm.pk_sourceid = ds.pk_sourceid
LEFT JOIN ANALYTICS.OrderAllocationDetailHistory oadh ON oadh.sourcerefnum = toh.source_ref_num AND oadh.sku = dsp.sku_code AND oadh.upc = dul.upc_code
LEFT JOIN ANALYTICS.txn_order_warranty tow ON tow.fk_order_headerid = toh.pk_order_headerid AND tow.fk_order_detailid = tod.pk_order_detailid
''
;
RES := (EXECUTE IMMEDIATE :SELECT_STATEMENT);

DROP TABLE IF EXISTS ORDER_INFO;

RETURN TABLE(RES);
END';
