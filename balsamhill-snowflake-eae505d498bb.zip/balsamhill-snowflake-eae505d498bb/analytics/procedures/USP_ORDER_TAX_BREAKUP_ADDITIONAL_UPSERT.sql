 
CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_TAX_BREAKUP_ADDITIONAL_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

CREATE OR REPLACE TEMPORARY TABLE insertedTaxBreakupRecords (
    pk_ORDER_tax_breakupid BIGINT NOT NULL,
    tax_breakup_key STRING NOT NULL,
    header_key STRING NOT NULL,
    line_key STRING,
    record_type STRING,
    charge_category STRING,
    charge_name STRING,
    tax_name STRING,
    taxable_flag STRING,
    tax_percentage float,
    tax float,
    invoiced_tax float,
    reference1 STRING,
    reference2 STRING,
    reference3 STRING,
    createts TIMESTAMP_NTZ,
    modifyts TIMESTAMP_NTZ,
    createuserid STRING,
    modifyuserid STRING,
    createprogid STRING,
    modifyprogid STRING,
    lockid STRING,
    inserted_date TIMESTAMP_NTZ ,
    modified_date TIMESTAMP_NTZ  ,
    revision INT NOT NULL
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.txn_order_tax_breakup ti
USING (
    SELECT DISTINCT 
        tax_breakup_key,
        header_key,
        line_key,
        record_type,
        charge_category,
        charge_name,
        tax_name,
        taxable_flag,
        TRY_CAST(tax_percentage AS FLOAT) AS tax_percentage,
        TRY_CAST(tax AS FLOAT) AS tax,
        TRY_CAST(invoiced_tax AS FLOAT) AS invoiced_tax,
        reference1,
        reference2,
        reference3,
        TRY_TO_TIMESTAMP(createts,'YYYYMMDDHHMISS') AS createts,
        TRY_TO_TIMESTAMP(modifyts,'YYYYMMDDHHMISS') AS modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid
    FROM TRANSFORMED.stg_ORDER_tax_breakup
) si
ON ti.tax_breakup_key = si.tax_breakup_key
WHEN MATCHED THEN
    UPDATE SET 
        ti.line_key = si.line_key,
        ti.record_type = si.record_type,
        ti.charge_category = si.charge_category,
        ti.charge_name = si.charge_name,
        ti.tax_name = si.tax_name,
        ti.taxable_flag = si.taxable_flag,
        ti.tax_percentage = si.tax_percentage,
        ti.tax = si.tax,
        ti.invoiced_tax = si.invoiced_tax,
        ti.reference1 = si.reference1,
        ti.reference2 = si.reference2,
        ti.reference3 = si.reference3,
        ti.createts = si.createts,
        ti.modifyts = si.modifyts,
        ti.createuserid = si.createuserid,
        ti.modifyuserid = si.modifyuserid,
        ti.createprogid = si.createprogid,
        ti.modifyprogid = si.modifyprogid,
        ti.lockid = si.lockid,
        ti.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        tax_breakup_key,
        header_key,
        line_key,
        record_type,
        charge_category,
        charge_name,
        tax_name,
        taxable_flag,
        tax_percentage,
        tax,
        invoiced_tax,
        reference1,
        reference2,
        reference3,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        inserted_date,
        modified_date
    ) 
    VALUES (
        si.tax_breakup_key,
        si.header_key,
        si.line_key,
        si.record_type,
        si.charge_category,
        si.charge_name,
        si.tax_name,
        si.taxable_flag,
        si.tax_percentage,
        si.tax,
        si.invoiced_tax,
        si.reference1,
        si.reference2,
        si.reference3,
        si.createts,
        si.modifyts,
        si.createuserid,
        si.modifyuserid,
        si.createprogid,
        si.modifyprogid,
        si.lockid,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );

INSERT INTO insertedTaxBreakupRecords (
    pk_ORDER_tax_breakupid,
    tax_breakup_key,
    header_key,
    line_key,
    record_type,
    charge_category,
    charge_name,
    tax_name,
    taxable_flag,
    tax_percentage,
    tax,
    invoiced_tax,
    reference1,
    reference2,
    reference3,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    modified_date,
    revision
)
SELECT
    pk_OMS_tax_breakupid,
    tax_breakup_key,
    header_key,
    line_key,
    record_type,
    charge_category,
    charge_name,
    tax_name,
    taxable_flag,
    tax_percentage,
    tax,
    invoiced_tax,
    reference1,
    reference2,
    reference3,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    modified_date,
    1  
FROM ANALYTICS.txn_order_tax_breakup
WHERE inserted_date >= :processedDate or modified_date >= :processedDate  ;

MERGE INTO insertedTaxBreakupRecords ttd
USING (
    SELECT tax_breakup_key, MAX(revision) AS max_revision
    FROM audit_order_tax_breakup
    GROUP BY tax_breakup_key
) aot
ON ttd.tax_breakup_key = aot.tax_breakup_key
WHEN MATCHED THEN 
    UPDATE SET ttd.revision = COALESCE(aot.max_revision, 0) + 1;


    
INSERT INTO ANALYTICS.audit_order_tax_breakup (
    pk_OMS_tax_breakupid,
    tax_breakup_key,
    header_key,
    line_key,
    record_type,
    charge_category,
    charge_name,
    tax_name,
    taxable_flag,
    tax_percentage,
    tax,
    invoiced_tax,
    reference1,
    reference2,
    reference3,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    modified_date,
    revision
)
SELECT DISTINCT
    si.pk_ORDER_tax_breakupid,
    si.tax_breakup_key,
    si.header_key,
    si.line_key,
    si.record_type,
    si.charge_category,
    si.charge_name,
    si.tax_name,
    si.taxable_flag,
    si.tax_percentage,
    si.tax,
    si.invoiced_tax,
    si.reference1,
    si.reference2,
    si.reference3,
    si.createts,
    si.modifyts,
    si.createuserid,
    si.modifyuserid,
    si.createprogid,
    si.modifyprogid,
    si.lockid,
    si.inserted_date,
    si.modified_date,
    si.revision
FROM insertedTaxBreakupRecords si;

DROP TABLE IF EXISTS insertedTaxBreakupRecords;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

COMMIT;
RETURN 'Success';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

        error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
END;