USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_RAW_TABLE_INVALID_ORDER_CLEANUP()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    message STRING;

BEGIN
    -- Start transaction
    BEGIN TRANSACTION;

    -- Create a temporary table for invalid order headers
    CREATE OR REPLACE TEMPORARY TABLE analytics.INVALID_ORDER_HEADER_KEY AS
    SELECT DISTINCT ORDER_HEADER_KEY, ORDER_NO 
    FROM RAW.raw_order_header 
    WHERE DOCUMENT_TYPE = 5 
    OR ENTERPRISE_KEY = ''DEFAULT'' 
    OR DRAFT_ORDER_FLAG = ''Y'';

    -- Perform delete operations on related tables
    DELETE FROM RAW.raw_order_container_details 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_payment 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_release 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_release_status 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_shipment 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_shipment_container 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_shipment_line 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_header_charges 
    WHERE header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_line_charges 
    WHERE header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_tax_breakup 
    WHERE header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_hold_type 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_inbox 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

 --   DELETE FROM RAW.raw_order_audit_level 
--    WHERE order_audit_key IN (SELECT order_audit_key FROM raw_order_audit WHERE --order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY));

    --DELETE FROM RAW.raw_order_audit 
    --WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_line 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    -- This line needs to be at the end
    DELETE FROM RAW.raw_order_header 
    WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);

    DELETE FROM RAW.raw_order_header_charges 
    WHERE record_type = ''INV'';

    DELETE FROM RAW.raw_order_line_charges 
    WHERE record_type = ''INV'';

    DELETE FROM RAW.raw_order_tax_breakup 
    WHERE record_type = ''INV'';

    -- Reject status with quantity
    UPDATE RAW.raw_order_release_status 
    SET processing_status = ''Rejected'', processing_comment = ''Quantity is zero'' 
    WHERE status_quantity = '''' 
    OR status_quantity = ''0.0'' 
    OR status_quantity = ''0'' 
    OR status_quantity IS NULL;

    -- Drop the temporary table
    DROP TABLE analytics.INVALID_ORDER_HEADER_KEY;

    -- Commit transaction
    COMMIT;

    RETURN ''Procedure executed successfully'';
    
EXCEPTION
    WHEN statement_error THEN
        -- Rollback transaction in case of an error
        ROLLBACK;

        -- Get the error message
        message := SQLERRM;
        
        -- Return the error message
        RETURN message;
END';
