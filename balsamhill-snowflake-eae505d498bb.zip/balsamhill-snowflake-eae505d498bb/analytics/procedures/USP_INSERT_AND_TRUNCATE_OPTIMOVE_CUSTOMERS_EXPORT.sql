CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.USP_INSERT_AND_TRUNCATE_OPTIMOVE_CUSTOMERS_EXPORT("LAST_MODIFIED_DATE" TIMESTAMP_NTZ(9) DEFAULT NULL, "NEW_MODIFIED_DATE" TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP) COPY GRANTS 
RETURNS STRING 
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
    v_last_modified_date TIMESTAMP_NTZ;
BEGIN
    -- Get the max UpdatedDate if LAST_MODIFIED_DATE is null
    IF (LAST_MODIFIED_DATE IS NULL) THEN
        SELECT MAX(UpdatedDate)
        INTO :v_last_modified_date
        FROM ANALYTICS.OPTIMOVE_CUSTOMERS_EXPORT;
    ELSE
        v_last_modified_date := LAST_MODIFIED_DATE- INTERVAL '1 MILLISECOND';
    END IF;

    -- Truncate the table
    TRUNCATE TABLE ANALYTICS.OPTIMOVE_CUSTOMERS_EXPORT;

    INSERT INTO ANALYTICS.OPTIMOVE_CUSTOMERS_EXPORT (
    CustomerId,               
    REGISTRATIONDATE,               
    Email,               
    MobileNumber,               
    IsEmailOptin,               
    IsSMSOptin,               
    IsBlocked,               
    IsTest,               
    DateOfBirth,               
    FirstName,               
    LastName,               
    Country,               
    City,               
    Gender,               
    LastLoginDate,               
    RegisteredPlatform,               
    ReferralType,               
    Currency,     
    Brand,    
    UpdatedDate, 
    sms_opt_in_atntv,  
    phone_atntv     
    ) 
    SELECT DISTINCT
        dc.source_ref_num AS CustomerId,
        dci.REGD_DATE AS RegisterationDate,
        dci.EMAIL_PRIMARY AS Email,
        CASE
            WHEN COALESCE(dci.mobi_phone_primary_E164, dci.mobi_phone_primary, '-') = '-' THEN NULL
            ELSE COALESCE(dci.mobi_phone_primary_E164, dci.mobi_phone_primary)
        END AS "MobileNumber",
        CASE
            WHEN dci.email_subscriber IN ('1','Y','TRUE') THEN 1
            ELSE 0
        END AS IsEmailOptin,
        NULL AS IsSMSOptin,
        NULL AS IsBlocked,
        NULL AS IsTest,
        NULL AS DateOfBirth,
        REPLACE(REPLACE(REPLACE(dci.FIRST_NAME, '"', ' '), '''', ''), '\\', '') AS FirstName,
        REPLACE(REPLACE(REPLACE(dci.LAST_NAME, '"', ' '), '''', ''), '\\', '') AS LastName,
        dca.country_code AS Country,
        REPLACE(REPLACE(REPLACE(dca.city, '"', ' '), '''', ''), '\\', '') AS City,
        dci.GENDER AS Gender,
        dci.LAST_LOGIN_DATE AS LastLoginDate,
        NULL AS RegisteredPlatform,
        NULL AS ReferralType,
        NULL AS Currency,
        dbr.brandcodeforpotracker AS Brand,
        dci.modified_date AS UpdatedDate,
        dci.sms_opt_in_atntv,
        dci.phone_atntv,
    FROM
        PROD_EXTRACT.ANALYTICS.CUSTOMER DC 
    JOIN
        PROD_EXTRACT.ANALYTICS.CUSTOMER_INFO dci ON dc.PK_CUSTOMERID = dci.FK_CUSTOMERID 
    LEFT JOIN
        PROD_EXTRACT.ANALYTICS.CUSTOMER_ADDRESS dca ON dci.PK_CUSTOMER_INFO_ID = dca.fk_customer_info_id 
    LEFT JOIN 
        PROD_EXTRACT.MASTER.DIM_SOURCE DS ON DC.FK_SOURCEID = DS.PK_SOURCEID
    LEFT JOIN
        PROD_EXTRACT.MASTER.DIM_BRAND dbr ON DS.fk_brandid = dbr.pk_brandid 
    WHERE DCI.MODIFIED_DATE > COALESCE(:v_last_modified_date, CURRENT_TIMESTAMP() - INTERVAL '1 DAY') 
        AND DCI.MODIFIED_DATE <= COALESCE(:NEW_MODIFIED_DATE, CURRENT_TIMESTAMP())
    ;

    -- Return info for debugging/logging if desired
    RETURN 'Table Updated. Every record Updated After LAST_MODIFIED_DATE: ' || COALESCE(TO_VARCHAR(:v_last_modified_date), TO_VARCHAR(CURRENT_TIMESTAMP() - INTERVAL '1 DAY')) || ' and Before NEW_MODIFIED_DATE: ' || TO_VARCHAR(COALESCE(:NEW_MODIFIED_DATE, CURRENT_TIMESTAMP()));
END;
$$
;
