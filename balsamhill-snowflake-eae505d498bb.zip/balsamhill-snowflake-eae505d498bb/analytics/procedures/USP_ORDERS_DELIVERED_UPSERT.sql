USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE BALSAM_EDW_DEV.ANALYTICS.USP_ORDERS_DELIVERED_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE error_object VARIANT;
BEGIN

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        CURRENT_TIMESTAMP(),
        NULL,
        ''upsert started''
    );

MERGE into analytics.txn_order_delivered AS tod
				USING (
						SELECT distinct tos.shipment_key as shipment_key 
						   ,tos.order_no as SourceRefNum
						   ,tos.pickticket_no as OrderIDForWarehouse 
						   ,line.item_id as sku_code
						   ,line.item_id as fk_skuproductid
						   ,containerdetails.extn_upc_item_id as upc_code
						   ,dup.pk_upcid as fk_upcid
						   ,85 as fk_warehouseid
						   ,tos.total_quantity as Qty
						   ,tos.actual_delivery_date as DateDelivered
						   ,tos.pickticket_no as WarehouseReferenceNumber
						   ,NULL as IsResend
						   ,NULL as IsReroute
						   ,NULL as IsSuccessful
						   ,tos.carrier_service_code as ShippingMethodID
						   ,src.PlatformId as fk_platformID
						   ,tos.order_header_key as external_orderid
						   ,toh.fk_sourceid as fk_sourceid 
						   ,soopi.address1 as ShipAddress1 
						   ,soopi.address2 as ShipAddress2
						   ,soopi.city as ShipCity
						   ,soopi.state  as ShipState
						   ,soopi.postal_code as ShipPostalCode	 
						   ,soopi.first_name as ShipFirstName
						   ,soopi.last_name as ShipLastName 
						   ,soopi.company_name as ShipCompanyName
						   ,toh.order_date as OrderDate
						   ,toh.pk_order_headerid as fk_order_headerid
						   ,tos.carrier_service_code as WarehouseShippingMethodID
						   ,tos.scac as CarrierCode
						   ,tos.order_type as Ordertype
                           
						from  analytics.txn_order_shipment tos 
						INNER JOIN analytics.txn_order_header as toh 
							ON tos.order_header_key = toh.ext_order_id
						INNER JOIN analytics.txn_order_shipment_line line 
							ON line.shipment_key = tos.shipment_key
						INNER JOIN  MASTER.source_brand_platform_map AS src 
							ON src.BrandCodeForWHM = analytics.fun_get_edw_brand_by_order_sellerorgcode(toh.seller_organization_code) AND src.platformname = nvl(analytics.fun_get_edw_platform_by_order_entrytype(toh.ENTRY_TYPE), '''')
	  					INNER JOIN  analytics.txn_order_shipment_container container 
							ON container.shipment_key = tos.shipment_key
						INNER JOIN analytics.txn_address soopi 
							ON  CAST(soopi.ext_address_id AS VARCHAR) = CAST(tos.to_address_key AS VARCHAR)  
						INNER JOIN analytics.txn_order_detail as tod 
							ON tod.fk_order_headerid = toh.pk_order_headerid and 
								tod.ext_line_id = line.order_line_key
						INNER JOIN analytics.txn_order_container_details containerdetails 
							ON line.order_line_key = containerdetails.order_line_key  AND 
								tos.order_header_key = containerdetails.order_line_key
						INNER JOIN ANALYTICS.upc as dup 
							ON  dup.upc_code = containerdetails.extn_upc_item_id
					)AS orddetail
						ON orddetail.SourceRefNum = tod.SourceRefNum
						AND orddetail.Sku_code = tod.Sku_code
						AND orddetail.Upc_code = tod.Upc
						AND orddetail.fk_order_headerid = tod.fk_order_headerid
					WHEN MATCHED 
					THEN 
					UPDATE SET
						tod.external_Id = orddetail.shipment_key
						,tod.OrderIDForWarehouse = orddetail.OrderIDForWarehouse
						,tod.fk_skuproductid= orddetail.fk_skuproductid
						,tod.fk_upcid= orddetail.fk_upcid
						,tod.fk_WarehouseID =orddetail.fk_WarehouseID
						,tod.Qty            = orddetail.Qty
						,tod.DateDelivered         = orddetail.DateDelivered
						,tod.WarehouseReferenceNumber =orddetail.WarehouseReferenceNumber
						,tod.IsResend = orddetail.IsResend
						,tod.IsReroute = orddetail.IsReroute
						,tod.IsSuccessful = orddetail.IsSuccessful
						,tod.ShippingMethodID = orddetail.ShippingMethodID
						,tod.external_orderid = orddetail.external_orderid
						,tod.fk_platformID = orddetail.fk_platformID
						,tod.OrderType = orddetail.ordertype
						,tod.ShipAddress1 = orddetail.ShipAddress1
						,tod.ShipAddress2 = orddetail.ShipAddress2
						,tod.ShipCity = orddetail.ShipCity
						,tod.ShipState = orddetail.ShipState
						,tod.ShipPostalCode = orddetail.ShipPostalCode
						,tod.ShipFirstName = orddetail.ShipFirstName
						,tod.ShipLastName = orddetail.ShipLastName
						,tod.ShipCompanyName = orddetail.ShipCompanyName
						,tod.OrderDate = orddetail.OrderDate
						,tod.fk_sourceid = orddetail.fk_sourceid
						,tod.WarehouseShippingMethodID = orddetail.WarehouseShippingMethodID
						,tod.CarrierCode = orddetail.CarrierCode
						,tod.modified_date = current_date
				WHEN NOT MATCHED
					THEN
						INSERT (
						 external_Id
						,SourceRefNum
						,OrderIDForWarehouse
						,Sku_code
						,fk_skuproductid
						,Upc
						,fk_upcid
						,fk_WarehouseID
						,Qty
						,DateDelivered
						,WarehouseReferenceNumber
						,IsResend
						,IsReroute
						,IsSuccessful
						,ShippingMethodID
						,external_orderid
						,fk_platformID
						,OrderType
						,ShipAddress1
						,ShipAddress2
						,ShipCity
						,ShipState
						,ShipPostalCode
						,ShipFirstName
						,ShipLastName
						,ShipCompanyName
						,OrderDate
						,fk_sourceid
						,WarehouseShippingMethodID
						,CarrierCode
						,fk_order_headerid
						,inserted_date
						,modified_date
							)
						VALUES (
						orddetail.shipment_key
						,orddetail.SourceRefNum
						,orddetail.OrderIDForWarehouse
						,orddetail.Sku_code
						,orddetail.fk_skuproductid
						,orddetail.Upc_code
						,orddetail.fk_upcid
						,orddetail.fk_WarehouseID
						,orddetail.Qty
						,orddetail.DateDelivered
						,orddetail.WarehouseReferenceNumber
						,orddetail.IsResend
						,orddetail.IsReroute
						,orddetail.IsSuccessful
						,orddetail.ShippingMethodID
						,orddetail.external_orderid
						,orddetail.fk_platformID
						,orddetail.ordertype
						,orddetail.ShipAddress1
						,orddetail.ShipAddress2
						,orddetail.ShipCity
						,orddetail.ShipState
						,orddetail.ShipPostalCode
						,orddetail.ShipFirstName
						,orddetail.ShipLastName
						,orddetail.ShipCompanyName
						,orddetail.OrderDate
						,orddetail.fk_sourceid
						,orddetail.WarehouseShippingMethodID
						,orddetail.CarrierCode
						,orddetail.fk_order_headerid
						,current_date
						,current_date);

COMMIT;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''COMPLETED'',
        NULL,
        CURRENT_TIMESTAMP(),
        ''upsert completed successfully''
    );
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;

            error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);
    
        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        NULL,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';