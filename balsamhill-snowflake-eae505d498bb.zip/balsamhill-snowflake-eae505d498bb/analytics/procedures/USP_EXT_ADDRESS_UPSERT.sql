CREATE OR REPLACE PROCEDURE ANALYTICS.USP_EXT_ADDRESS_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS CALLER
AS DECLARE 
    processedDate TIMESTAMP_NTZ(9);
    start_time_proc TIMESTAMP_NTZ(9);
    error_object VARIANT;
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );
        -- Creating a temporary table with columns similar to the original SQL Server code
    CREATE OR REPLACE TEMPORARY TABLE TempExtAddress (
        ext_address_id STRING,
        person_id STRING,
        title STRING,
        suffix STRING,
        department STRING,
        job_title STRING,
        day_phone STRING,
        evening_phone STRING,
        mobile_phone STRING,
        beeper STRING,
        other_phone STRING,
        day_fax_no STRING,
        evening_fax_no STRING,
        emailid STRING,
        alternate_emailid STRING,
        preferred_ship_address STRING,
        http_url STRING,
        use_count STRING,
        verification_status STRING,
        is_address_verified STRING,
        latitude FLOAT,
        longitude FLOAT,
        tax_geo_code STRING,
        error_txt STRING,
        is_commercial_address STRING,
        time_zone STRING,
        lockid STRING,
        createts TIMESTAMP,
        modifyts TIMESTAMP,
        createuserid STRING,
        modifyuserid STRING,
        createprogid STRING,
        modifyprogid STRING,
        address_id STRING,
        short_zip_code STRING,
        last_updated_date TIMESTAMP,
        revision INT NOT NULL
    );
 processedDate := current_timestamp();

    -- Merge logic to update or insert records in ext_address
    MERGE INTO  analytics.ext_address AS tgt
    USING (
        SELECT DISTINCT
            stg.person_info_key,
            stg.person_id,
            stg.title,
            stg.suffix,
            stg.department,
            stg.job_title,
            stg.day_phone,
            stg.evening_phone,
            stg.mobile_phone,
            stg.beeper,
            stg.other_phone,
            stg.day_fax_no,
            stg.evening_fax_no,
            stg.emailid,
            stg.alternate_emailid,
            stg.preferred_ship_address,
            stg.http_url,
            stg.use_count,
            stg.verification_status,
            stg.is_address_verified,
            TRY_CAST(stg.latitude AS FLOAT) AS latitude,
            TRY_CAST(stg.longitude AS FLOAT) AS longitude,
            stg.tax_geo_code,
            stg.error_txt,
            stg.is_commercial_address,
            stg.time_zone,
            stg.lockid,
            TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS') AS createts,
            TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS') AS modifyts,
            stg.createuserid,
            stg.modifyuserid,
            stg.createprogid,
            stg.modifyprogid,
            stg.address_id,
            stg.short_zip_code
        FROM transformed.stg_order_person_info stg
        INNER JOIN raw.raw_order_person_info r
            ON stg.person_info_key = r.person_info_key
            AND stg.modifyts = r.modifyts
            AND r.processing_status = 'Processed'
    ) AS src
    ON tgt.ext_address_id = src.person_info_key
    WHEN MATCHED THEN
        UPDATE SET
            tgt.person_id = src.person_id,
            tgt.title = src.title,
            tgt.suffix = src.suffix,
            tgt.department = src.department,
            tgt.job_title = src.job_title,
            tgt.day_phone = src.day_phone,
            tgt.evening_phone = src.evening_phone,
            tgt.mobile_phone = src.mobile_phone,
            tgt.other_phone = src.other_phone,
            tgt.day_fax_no = src.day_fax_no,
            tgt.evening_fax_no = src.evening_fax_no,
            tgt.emailid = src.emailid,
            tgt.alternate_emailid = src.alternate_emailid,
            tgt.preferred_ship_address = src.preferred_ship_address,
            tgt.http_url = src.http_url,
            tgt.use_count = src.use_count,
            tgt.verification_status = src.verification_status,
            tgt.is_address_verified = src.is_address_verified,
            tgt.latitude = src.latitude,
            tgt.longitude = src.longitude,
            tgt.tax_geo_code = src.tax_geo_code,
            tgt.error_txt = src.error_txt,
            tgt.is_commercial_address = src.is_commercial_address,
            tgt.time_zone = src.time_zone,
            tgt.lockid = src.lockid,
            tgt.createts = src.createts,
            tgt.modifyts = src.modifyts,
            tgt.createuserid = src.createuserid,
            tgt.modifyuserid = src.modifyuserid,
            tgt.createprogid = src.createprogid,
            tgt.modifyprogid = src.modifyprogid,
            tgt.address_id = src.address_id,
            tgt.short_zip_code = src.short_zip_code,
            tgt.last_updated_date = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
            ext_address_id, person_id, title, suffix, department, job_title, day_phone, evening_phone, mobile_phone,
            beeper, other_phone, day_fax_no, evening_fax_no, emailid, alternate_emailid, preferred_ship_address, http_url,
            use_count, verification_status, is_address_verified, latitude, longitude, tax_geo_code, error_txt,
            is_commercial_address, time_zone, lockid, createts, modifyts, createuserid, modifyuserid, createprogid,
            modifyprogid, address_id, short_zip_code, last_updated_date
        )
        VALUES (
            src.person_info_key, src.person_id, src.title, src.suffix, src.department, src.job_title, src.day_phone,
            src.evening_phone, src.mobile_phone, src.beeper, src.other_phone, src.day_fax_no, src.evening_fax_no,
            src.emailid, src.alternate_emailid, src.preferred_ship_address, src.http_url, src.use_count,
            src.verification_status, src.is_address_verified, src.latitude, src.longitude, src.tax_geo_code,
            src.error_txt, src.is_commercial_address, src.time_zone, src.lockid, src.createts, src.modifyts,
            src.createuserid, src.modifyuserid, src.createprogid, src.modifyprogid, src.address_id, src.short_zip_code,
            CURRENT_TIMESTAMP()
        );

        INSERT INTO TempExtAddress 
						(ext_address_id,
						 person_id ,
						title ,
						suffix ,
						department ,
						job_title ,
						day_phone ,
						evening_phone,
						mobile_phone,
						beeper,
						other_phone,
						day_fax_no,
						evening_fax_no,
						emailid,
						alternate_emailid,
						preferred_ship_address ,
						http_url,
						use_count,
						verification_status,
						is_address_verified,
						latitude,
						longitude,
						tax_geo_code,
						error_txt,
						is_commercial_address,
						time_zone,
						lockid,
						createts,
						modifyts,
						createuserid,
						modifyuserid,
						createprogid,
						modifyprogid,
						address_id ,
						short_zip_code,
						last_updated_date,
						revision)
                        select 
                        inserted.ext_address_id,
						inserted. person_id ,
						inserted.title ,
						inserted.suffix ,
						inserted.department ,
						inserted.job_title ,
						inserted.day_phone ,
						inserted.evening_phone,
						inserted.mobile_phone,
						inserted.beeper,
						inserted.other_phone,
						inserted.day_fax_no,
						inserted.evening_fax_no,
						inserted.emailid,
						inserted.alternate_emailid,
						inserted.preferred_ship_address ,
						inserted.http_url,
						inserted.use_count,
						inserted.verification_status,
						inserted.is_address_verified,
						inserted.latitude,
						inserted.longitude,
						inserted.tax_geo_code,
						inserted.error_txt,
						inserted.is_commercial_address,
						inserted.time_zone,
						inserted.lockid,
						inserted.createts,
						inserted.modifyts,
						inserted.createuserid,
						inserted.modifyuserid,
						inserted.createprogid,
						inserted.modifyprogid,
						inserted.address_id ,
						inserted.short_zip_code,
						inserted.last_updated_date,
						1
                      from analytics.ext_address inserted
                      where inserted.last_updated_date >= :processedDate ; 

    -- Update revision in TempExtAddress
    MERGE INTO TempExtAddress ttd
USING (
    SELECT
        MAX(aot.revision) AS revision,
        aot.ext_address_id
    FROM  analytics.audit_ext_address aot
    INNER JOIN TempExtAddress ttd 
        ON ttd.ext_address_id = aot.ext_address_id
    GROUP BY aot.ext_address_id
) aot
ON ttd.ext_address_id = aot.ext_address_id
WHEN MATCHED THEN
    UPDATE SET 
        ttd.revision = COALESCE(aot.revision, 0) + 1;


    -- Insert into audit_ext_address table
    INSERT INTO analytics.audit_ext_address (
        ext_address_id, person_id, title, suffix, department, job_title, day_phone, evening_phone, mobile_phone, beeper,
        other_phone, day_fax_no, evening_fax_no, emailid, alternate_emailid, preferred_ship_address, http_url, use_count,
        verification_status, is_address_verified, latitude, longitude, tax_geo_code, error_txt, is_commercial_address,
        time_zone, lockid, createts, modifyts, createuserid, modifyuserid, createprogid, modifyprogid, address_id,
        short_zip_code, last_updated_date, revision
    )
    SELECT
        stg.person_info_key, stg.person_id, stg.title, stg.suffix, stg.department, stg.job_title, stg.day_phone,
        stg.evening_phone, stg.mobile_phone, stg.beeper, stg.other_phone, stg.day_fax_no, stg.evening_fax_no,
        stg.emailid, stg.alternate_emailid, stg.preferred_ship_address, stg.http_url, stg.use_count,
        stg.verification_status, stg.is_address_verified, 
        TRY_CAST(stg.latitude AS FLOAT) AS latitude,
            TRY_CAST(stg.longitude AS FLOAT) AS longitude,
            stg.tax_geo_code,
            stg.error_txt,
            stg.is_commercial_address,
            stg.time_zone,
            stg.lockid,
            TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS') AS createts,
            TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS') AS modifyts,
             stg.createuserid,
        stg.modifyuserid, stg.createprogid, stg.modifyprogid, stg.address_id, stg.short_zip_code, CURRENT_TIMESTAMP,
        ord.revision
    FROM transformed.stg_order_person_info stg
    INNER JOIN raw.raw_order_person_info r
        ON stg.person_info_key = r.person_info_key
        AND stg.modifyts = r.modifyts
        AND r.processing_status = 'Processed'
    INNER JOIN TempExtAddress ord ON ord.ext_address_id = stg.person_info_key;

    -- Commit the transaction
 CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

COMMIT;

RETURN 'Success';
EXCEPTION 
WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
            
    RETURN sqlerrm;
END;