CREATE OR REPLACE PROCEDURE ANALYTICS.UPSERT_FLC()
  RETURNS VARCHAR
  LANGUAGE SQL
  EXECUTE AS CALLER
AS
$$
DECLARE
  v_max_fy INT;
  v_cutoff INT;
BEGIN
  -- 1. Get current max fiscal year
  SELECT MAX(FISCALYEAR)
    INTO :v_max_fy
  FROM ANALYTICS.FLC;

  SELECT YEAR(CURRENT_DATE + INTERVAL '7 DAYS')
    INTO :V_CUTOFF
  ;

  -- 2. Only proceed if table is “stale”
  IF(:v_max_fy < :v_cutoff) THEN
    -- 3. Insert the CTE results
    INSERT INTO ANALYTICS.FLC
    WITH
      TOTAL AS (
        SELECT DISTINCT
          BRANDID,
          BRAND,
          SKU,
          FULLYLOADEDCOST,
          INITIALCOST,
          LANDEDCOST,
          VARIABLEFORECASTFLC,
          FISCALYEAR,
          FIRST_COST_CY,
          LANDED_COST_CY
        FROM ANALYTICS.FLC
      ),
      ADD_YEARS AS (
        SELECT
          BRANDID,
          BRAND,
          SKU,
          FULLYLOADEDCOST,
          INITIALCOST,
          LANDEDCOST,
          VARIABLEFORECASTFLC,
          FISCALYEAR + 1 AS FISCALYEAR,
          FIRST_COST_CY,
          LANDED_COST_CY,
          0 AS ORIG
        FROM TOTAL
        WHERE FISCALYEAR >= 2025
      ),
      BASE AS (
        SELECT *, 1 AS ORIG FROM TOTAL
        UNION ALL
        SELECT * FROM ADD_YEARS
      ),
      PREV AS (
        SELECT
          BRANDID,
          BRAND,
          SKU,
          FULLYLOADEDCOST,
          INITIALCOST,
          LANDEDCOST,
          VARIABLEFORECASTFLC,
          FISCALYEAR,
          FIRST_COST_CY,
          LANDED_COST_CY,
          ORIG,
          ROW_NUMBER() OVER (
            PARTITION BY BRAND, SKU, FISCALYEAR
            ORDER BY ORIG DESC
          ) AS RN
        FROM BASE
        WHERE FISCALYEAR = :v_cutoff
        QUALIFY RN = 1
      )
    SELECT DISTINCT
      BRANDID,
      BRAND,
      SKU,
      FULLYLOADEDCOST,
      INITIALCOST,
      LANDEDCOST,
      VARIABLEFORECASTFLC,
      FISCALYEAR,
      FIRST_COST_CY,
      LANDED_COST_CY
    FROM PREV;

    RETURN 'Inserted new FISCALYEAR=' || v_cutoff;
  ELSE
    RETURN 'No action: max fiscal year (' || v_max_fy || ') >= cutoff (' || v_cutoff || ')';
  END IF;
END;
$$;
