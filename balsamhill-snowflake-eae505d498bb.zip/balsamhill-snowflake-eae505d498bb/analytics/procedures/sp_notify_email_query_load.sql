USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.SP_NOTIFY_EMAIL_QUERY_LOAD()
RETURNS STRING 
LANGUAGE SQL 
AS 
BEGIN
LET email_integration_name varchar :=  (select distinct integration_name from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Query Load' and environment='dev'  limit 1);
    
    LET email_list varchar :=  (select LISTAGG(distinct recipient,',') from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Query Load' and environment='dev');
    
    let email_subject varchar := (select DISTINCT subject_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Query Load' and environment='dev' limit 1);
    
    let email_body_default  varchar := (select DISTINCT body_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Query Load' and environment='dev' limit 1);
    
    LET email_body_day varchar := (
        with PREV AS (
            SELECT LH.WAREHOUSE_NAME WN, CEIL(AVG(AVG_RUNNING),2) query_load_ratio 
                FROM "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_LOAD_HISTORY" LH 
                       WHERE START_TIME >= DATEADD(DAY, -1, CURRENT_TIMESTAMP())
            GROUP BY LH.WAREHOUSE_NAME
            )
            SELECT 
                OBJECT_AGG(WN, query_load_ratio) AS warehouse_load_json
            FROM 
                PREV
    );

    LET email_body_week varchar := (
        with PREV AS (
            SELECT LH.WAREHOUSE_NAME WN, CEIL(AVG(AVG_RUNNING),2) query_load_ratio 
                FROM "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_LOAD_HISTORY" LH 
                       WHERE START_TIME >= DATEADD(WEEK, -1, CURRENT_TIMESTAMP())
            GROUP BY LH.WAREHOUSE_NAME
            )
            SELECT 
                OBJECT_AGG(WN, query_load_ratio) AS warehouse_load_json
            FROM 
                PREV
    );
    
    CALL SYSTEM$SEND_EMAIL(
                :email_integration_name,
                :email_list,
                :email_subject,
                :email_body_default 
                ||'\n\n' || 'Query Load by Warehouse (Last Day): ' || :email_body_day
                ||'\n\n' || 'Query Load by Warehouse (Last Week): ' || :email_body_week
                || '\n\n' || 'NOTE: Average query load should NOT exceed the Max number of concurrent queries the Warehouse supports depending on its size.');
    return 'Email Alert Sent';
END;

