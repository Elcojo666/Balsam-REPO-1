CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.USP_EXPORT_OPTIMOVE_orders_items()
RETURNS STRING
LANGUAGE SQL
AS
$$
DECLARE 
    ts STRING;
    copy_sql STRING;
BEGIN
  -- Format the current date as 'YYYY-MM-DD'
  ts := TO_CHAR(CURRENT_TIMESTAMP(), 'YYYY-MM-DD_HH24-MI-SS');
  copy_sql := ' COPY INTO @ANALYTICS.OPTIMOVE_EXPORTS/daily_export/orders_items/orders_items_export_' || :ts || ' FROM (SELECT * FROM ANALYTICS.OPTIMOVE_orders_items_EXPORT) FILE_FORMAT = RAW.CSV_STANDARD_FORMAT HEADER = TRUE OVERWRITE = FALSE ';

  EXECUTE IMMEDIATE :copy_sql;

  RETURN 'Order-Items Export completed on ' || CURRENT_TIMESTAMP();
END;
$$;
