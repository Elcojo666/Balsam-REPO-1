---------------------------------- ADD CUSTOMER 
-- SEE AVAILABLE SOURCES
SELECT DISTINCT PK_SOURCEID
FROM PRE_PROD.MASTER.DIM_SOURCE;

-- SEE AVAILABLE CUSTOMER TYPE
SELECT DISTINCT CUSTOMER_TYPE
FROM PRE_PROD.MASTER.DIM_CUSTOMER_TYPE;

CALL PRE_PROD.ANALYTICS.USP_CUSTOMER_API_INSERT(
    NULL,                         -- pk_customerid (not provided in JSON)
    'DemoSnowflakeSP',            -- sourceRefNum        SHOULD BE UNIQUE, CAN'T EXIST IN CURRENT CUSTOMER TABLE
    'string',                     -- ID                  (from "ID")
    'string',                     -- EmailAddress        (from "EmailAddress")
    NULL,                         -- PhoneNumber         (from "PhoneNumber")
    TRUE,                         -- EmailSubscriber     (from "EmailSubscriber")
    NULL,                         -- CatalogSubscriber   (from "CatalogSubscriber")
    1,                            -- SourceID            NEEDS TO EXIST IN DIM_SOURCE MASTER TABLE (PK_SOURCEID) 
    '1',                          -- Status              (from "Status")
    'GUEST',                      -- CustomerType        NEEDS TO EXIST IN DIM_CUSTOMER_TYPE MASTER TABLE (CUSTOMER_TYPE)
    NULL,                         -- Preferred_Lang      (from "Preferred_Lang")
    NULL,                         -- Regd_Date           (from "Regd_Date")
    NULL,                         -- Title               (from "Title")
    'string',                     -- FirstName           (from "FirstName")
    'string',                     -- LastName            (from "LastName")
    NULL,                         -- Dob                 (from "Dob")
    NULL,                         -- GenderCode          (from "GenderCode")
    NULL,                         -- Gender              (from "Gender")
    NULL,                         -- MaritalStatusCode   (from "MaritalStatusCode")
    NULL,                         -- MaritalStatus       (from "MaritalStatus")
    NULL,                         -- EmailSecondary      (from "EmailSecondary")
    '11234567890',                -- Phone1Input         (from "phone1input")
    '11234567890',                -- Phone2Input         (from "phone2input")
    NULL,                         -- Phone3Input         (not provided in JSON)
    '11234567890',                -- Phone4Input         (from "phone4input")
    NULL,                         -- CompanyName         (from "CompanyName")
    NULL,                         -- Customer_IsAnonymous  (from "Customer_IsAnonymous")
    NULL,                         -- Checkbox_For_New_Customers (from "Checkbox_For_New_Customers")
    NULL,                         -- Customer_Notes      (from "Customer_Notes")
    NULL,                         -- TaxExemptAccount    (from "TaxExemptAccount")
    NULL,                         -- OrderPlaced         (from "OrderPlaced")
    'string',                     -- CreatedBy           (from "CreatedBy")
    NULL,                         -- LastLogin           (from "LastLogin")
    NULL,                         -- EXTERNAL_ID         (from "EXTERNAL_ID")
    NULL,                         -- EXTERNAL_ACCOUNTID  (from "EXTERNAL_ACCOUNTID")
    NULL,                         -- ExternalEmail2      (from "ExternalEmail2")
    NULL,                         -- ExternalEmail1      (from "ExternalEmail1")
    NULL,                         -- MASTERCONTACT       (from "MASTERCONTACT")
    NULL,                         -- LegalName           (from "LegalName")
    NULL,                         -- EMAIL_OPT_IN_STATUS (from "EMAIL_OPT_IN_STATUS")
    NULL, --6830968               -- IF NOT NULL IT NEEDS TO EXIST IN CUSTOMER TABLE
    'string',                     -- cust_tier          (from "cust_tier")
    'string',                     -- tax_id             (from "tax_id")
    NULL,                         -- IsNordstromCustomer (from "IsNordstromCustomer")
    NULL,                         -- IsWilliamsonomaCustomer (from "IsWilliamsonomaCustomer")
    TRUE,                         -- business_cust      (from "business_cust")
    'string',                     -- business_category  (from "business_category")
    NULL,                         -- BusinessLocations  (from "BusinessLocations")
    NULL,                         -- DesignTradeFlag    (from "DesignTradeFlag")
    'string',                     -- social_handle_facebook (from "social_handle_facebook")
    'string',                     -- social_handle_instagram (from "social_handle_instagram")
    'string',                     -- social_handle_twitter   (from "social_handle_twitter")
    TRUE,                         -- phone1_sms         (from "phone1_sms")
    TRUE,                         -- phone1_pref        (from "phone1_pref")
    'string',                     -- phone1_region      (from "phone1_region")
    TRUE,                         -- phone2_sms         (from "phone2_sms")
    TRUE,                         -- phone2_pref        (from "phone2_pref")
    'string',                     -- phone2_region      (from "phone2_region")
    TRUE,                         -- phone3_sms         (from "phone3_sms")
    TRUE,                         -- phone3_pref        (from "phone3_pref")
    'string',                     -- phone3_region      (from "phone3_region")
    TRUE,                         -- phone4_sms         (from "phone4_sms")
    TRUE,                         -- phone4_pref        (from "phone4_pref")
    'string',                     -- phone4_region      (from "phone4_region")
    NULL,                         -- HashedId           (from "HashedId")
    'domestic'                    -- CUSTOMER_SOURCE     (value supplied by caller)
);
-- GET THE ID (PK_CUSTOMERID) COLUMN AND INFO_ID (PK_CUSTOMER_INFO_ID) 
-- FOR EXAMPLE: 6836076, 6706073

SELECT *
FROM PRE_PROD.ANALYTICS.CUSTOMER C 
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO CI 
        ON C.PK_CUSTOMERID = CI.FK_CUSTOMERID
WHERE C.PK_CUSTOMERID = 6836076 -- REPLACE WITH ADDED ID 
    AND CI.PK_CUSTOMER_INFO_ID = 6706073 -- REPLACE WITH ADDED INFO_ID 
;

---------------------------------- ADD CUSTOMER ADDRESS
-- CHECK CURRENT LIST OF ADDRESSES
SELECT DISTINCT  CA.*
FROM PRE_PROD.ANALYTICS.CUSTOMER C
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO CI
        ON C.PK_CUSTOMERID = CI.FK_CUSTOMERID
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_ADDRESS CA 
        ON CI.PK_CUSTOMER_INFO_ID = CA.FK_CUSTOMER_INFO_ID
WHERE  C.PK_CUSTOMERID = 6836076
ORDER BY PK_CUSTOMER_ADDRESS_ID DESC 
;

CALL PRE_PROD.ANALYTICS.SP_INSERTCUSTOMERADDRESSDETAILS(
    6836076,                            -- PK_CUSTOMERID  
    11,                                 -- SOURCE_ID
    TRUE,                               -- IS_DEFAULT
    NULL,                               -- ADDRESS_TYPE
    '5 5100 PALM HILLS',                -- LINE 1
    '',                                 -- LINE 2
    '',                                 -- LINE 3
    '',                                 -- LINE 4
    'MT RUSH',                          -- CITY
    'WY',                               -- STATE
    '77479-6072',                       -- POSTAL
    'US',                               -- COUNTRY
    'SNOWFLAKE',                        -- CREATED_BY
    CURRENT_TIMESTAMP,                  -- CREATED_DATE
    'SNOWFLAKE',                        -- MODIFIED_BY
    CURRENT_TIMESTAMP,                  -- MODIFIED_DATE
    NULL,                               -- LATITUDE
    NULL,                               -- LONGITUDE
    'Snow',                             -- FIRST_NAME
    'Flake'                             -- LAST_NAME
);

-- VERIFY NEW ADDED ADDRESS 
SELECT DISTINCT  CA.*
FROM PRE_PROD.ANALYTICS.CUSTOMER C
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO CI
        ON C.PK_CUSTOMERID = CI.FK_CUSTOMERID
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_ADDRESS CA 
        ON CI.PK_CUSTOMER_INFO_ID = CA.FK_CUSTOMER_INFO_ID
WHERE  C.PK_CUSTOMERID = 6836076
    AND CA.PK_CUSTOMER_ADDRESS_ID = 6514829
ORDER BY PK_CUSTOMER_ADDRESS_ID DESC 
;


---------------------------------- UPDATE CUSTOMER 
-- CHECK INFO FOR PKCUSTOMER_ID

SELECT CI.*
FROM PRE_PROD.ANALYTICS.CUSTOMER C 
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO CI 
        ON C.PK_CUSTOMERID = CI.FK_CUSTOMERID
WHERE C.PK_CUSTOMERID = 6836076 -- REPLACE WITH ADDED ID 
    AND CI.PK_CUSTOMER_INFO_ID = 6706073 -- REPLACE WITH ADDED INFO_ID 
;

CALL PRE_PROD.ANALYTICS.USP_CUSTOMER_API_UPDATE_BY_PKID(
    p_pk_customerid => 6836076,
    p_FIRST_NAME => 'Snow 1',
    p_LAST_NAME => 'Flake 2',
    p_MODIFIEDBY    => 'SNOWFLAKE_3'
    -- ADD COLUMNS AS SEEN ABOVE 
);

-- CHECK AFTER UPDATE
SELECT CI.*
FROM PRE_PROD.ANALYTICS.CUSTOMER C 
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO CI 
        ON C.PK_CUSTOMERID = CI.FK_CUSTOMERID
WHERE C.PK_CUSTOMERID = 6836076 -- REPLACE WITH ADDED ID 
    AND CI.PK_CUSTOMER_INFO_ID = 6706073 -- REPLACE WITH ADDED INFO_ID 
;

---------------------------------- UPDATE CUSTOMER ADDRESS
-- VERIFY LIST OF ADDRESSES 
SELECT DISTINCT  CA.*
FROM PRE_PROD.ANALYTICS.CUSTOMER C
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO CI
        ON C.PK_CUSTOMERID = CI.FK_CUSTOMERID
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_ADDRESS CA 
        ON CI.PK_CUSTOMER_INFO_ID = CA.FK_CUSTOMER_INFO_ID
WHERE  C.PK_CUSTOMERID = 6836076
   -- AND CA.PK_CUSTOMER_ADDRESS_ID = 6514829
ORDER BY PK_CUSTOMER_ADDRESS_ID DESC 
;

CALL PRE_PROD.ANALYTICS.SP_UPDATECUSTOMERADDRESSDETAILS(
    6836076,
    6514829,
    11,
    '',
    '7 5100 PALM HILLS', 
    '', 
    '', 
    '', 
    'MT RUSH', 
    'WY', 
    '77479-6072', 
    'US', 
    'SNOWFLAKE_UPDATE', 
    CURRENT_TIMESTAMP, 
    'SNOWFLAKE_UPDATE', 
    CURRENT_TIMESTAMP, 
    NULL, 
    NULL, 
    'Snow', 
    'Flake', 
    TRUE
);

-- VERIFY CHANGE
SELECT DISTINCT  CA.*
FROM PRE_PROD.ANALYTICS.CUSTOMER C
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO CI
        ON C.PK_CUSTOMERID = CI.FK_CUSTOMERID
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_ADDRESS CA 
        ON CI.PK_CUSTOMER_INFO_ID = CA.FK_CUSTOMER_INFO_ID
WHERE  C.PK_CUSTOMERID = 6836076
    AND CA.PK_CUSTOMER_ADDRESS_ID = 6514829
ORDER BY PK_CUSTOMER_ADDRESS_ID DESC 
;

---------------------------------- GET CUSTOMER BY FILTER
-- TEST EXACT FILTER 
CALL PRE_PROD.ANALYTICS.USP_GET_CUSTOMER_BY_FILTER(
    'dci.last_name in (''Miller'')', -- WHERE CLAUSE
    'dc.pk_customerid   ,dci.first_name  ,dci.last_name' -- COLUMNS TO RETRIVE
);

-- CHECK DATA 
SELECT dc.pk_customerid   ,dci.first_name  ,dci.last_name
FROM PRE_PROD.ANALYTICS.CUSTOMER DC 
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO DCI 
        ON DC.PK_CUSTOMERID = DCI.FK_CUSTOMERID
WHERE dci.last_name in ('Miller')
;

---------------------------------- GET CUSTOMER ADDRESSES
-- CHECK CURRENT LIST OF ADDRESSES
SELECT DISTINCT  CA.*
FROM PRE_PROD.ANALYTICS.CUSTOMER C
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO CI
        ON C.PK_CUSTOMERID = CI.FK_CUSTOMERID
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_ADDRESS CA 
        ON CI.PK_CUSTOMER_INFO_ID = CA.FK_CUSTOMER_INFO_ID
WHERE  C.PK_CUSTOMERID = 6836076
ORDER BY PK_CUSTOMER_ADDRESS_ID DESC 
;

-- RUN SP 
CALL PRE_PROD.ANALYTICS.SP_GETCUSTOMERALLADDRESSBYPKID(6836076);

---------------------------------- GET CUSTOMER ADDRESS
-- CHECK CURRENT LIST OF ADDRESSES
SELECT DISTINCT  CA.*
FROM PRE_PROD.ANALYTICS.CUSTOMER C
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO CI
        ON C.PK_CUSTOMERID = CI.FK_CUSTOMERID
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_ADDRESS CA 
        ON CI.PK_CUSTOMER_INFO_ID = CA.FK_CUSTOMER_INFO_ID
WHERE  C.PK_CUSTOMERID = 6836076
ORDER BY PK_CUSTOMER_ADDRESS_ID DESC 
;

-- RUN SP 
CALL PRE_PROD.ANALYTICS.SP_GETCUSTOMERADDRESSBYPKADDRESSID(6514829);

---------------------------------- DELETE CUSTOMER ADDRESS
-- TEST 
-- CHECK CURRENT LIST OF ADDRESSES
SELECT DISTINCT  c.fk_sourceid, CA.*
FROM PRE_PROD.ANALYTICS.CUSTOMER C
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO CI
        ON C.PK_CUSTOMERID = CI.FK_CUSTOMERID
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_ADDRESS CA 
        ON CI.PK_CUSTOMER_INFO_ID = CA.FK_CUSTOMER_INFO_ID
WHERE  C.PK_CUSTOMERID = 6836076
ORDER BY PK_CUSTOMER_ADDRESS_ID DESC 
;

-- RUN SP 
CALL PRE_PROD.ANALYTICS.SP_DELETECUSTOMERADDRESSDETAILS(
    1, -- FK_SOURCEID 
    6836076,    -- PK_CUSTOMERID 
    6514830     -- PK_CUSTOMER_ADDRESS_ID TO REMOVE
);

-- CHECK AFTER DELETE 
SELECT DISTINCT  c.fk_sourceid, CA.*
FROM PRE_PROD.ANALYTICS.CUSTOMER C
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_INFO CI
        ON C.PK_CUSTOMERID = CI.FK_CUSTOMERID
    INNER JOIN PRE_PROD.ANALYTICS.CUSTOMER_ADDRESS CA 
        ON CI.PK_CUSTOMER_INFO_ID = CA.FK_CUSTOMER_INFO_ID
WHERE  C.PK_CUSTOMERID = 6836076
ORDER BY PK_CUSTOMER_ADDRESS_ID DESC 
;
