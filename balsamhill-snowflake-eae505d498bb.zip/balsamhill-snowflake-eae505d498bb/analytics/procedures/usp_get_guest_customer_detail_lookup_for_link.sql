USE DATABASE DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.usp_get_guest_customer_detail_lookup_for_link(email VARCHAR)
    RETURNS TABLE(
                    first_name           VARCHAR,
                    last_name            VARCHAR,
                    order_email          VARCHAR,
                    customer_email       VARCHAR,
                    OrderDate            TIMESTAMP_NTZ,
                    OrderNo              VARCHAR,
                    TITLE                VARCHAR,
                    legal_name           VARCHAR,
                    pk_order_headerid    NUMBER(38,0),
                    GrandTotal           NUMBER(15,10),
                    NoteText             VARCHAR,
                    pk_bill_addressid    NUMBER(38,0),
                    BillFirstName        VARCHAR,
                    BillLastName         VARCHAR,
                    BillCompany          VARCHAR,
                    BillAddressLine1     VARCHAR,
                    BillAddressLine2     VARCHAR,
                    BillAddressLine3     VARCHAR,
                    BillAddressLine4     VARCHAR,
                    BillAddressLine5     VARCHAR,
                    BillAddressLine6     VARCHAR,
                    BillCity             VARCHAR,
                    BillState            VARCHAR,
                    BillZipCode          VARCHAR,
                    BillCountry          VARCHAR,
                    BillEmailID          VARCHAR,
                    BillMobilePhone      VARCHAR,
                    customer_type        VARCHAR,
                    source_ref_num       VARCHAR,
                    pk_customerid        NUMBER(38,0)
            )
    LANGUAGE SQL
AS
DECLARE
res RESULTSET;
BEGIN

    CREATE OR REPLACE TEMP TABLE guest_customer_detailed_lookup_CUSTOMER_INFO
    (
        FK_CUSTOMERID BIGINT NOT NULL
    );

    CREATE OR REPLACE TEMP TABLE guest_customer_detailed_lookup_ORDER_INFO
    (
        pk_order_headerid  BIGINT NOT NULL,
        order_date          DATETIME,
        FK_CUSTOMERID       BIGINT NOT NULL
    );

    IF (email IS NOT NULL AND email <> '') THEN


    INSERT INTO guest_customer_detailed_lookup_CUSTOMER_INFO
SELECT DISTINCT FK_CUSTOMERID
FROM ANALYTICS.TXN_ORDER_HEADER
WHERE EMAIL_ADDRESS = :email;

INSERT INTO guest_customer_detailed_lookup_ORDER_INFO
SELECT pk_order_headerid,
       order_date,
       h.FK_CUSTOMERID
FROM ANALYTICS.TXN_ORDER_HEADER AS h
         INNER JOIN guest_customer_detailed_lookup_CUSTOMER_INFO AS c
                    ON c.FK_CUSTOMERID = h.FK_CUSTOMERID
                        AND h.ORDER_DATE > DATEADD(YEAR, -4, CURRENT_DATE);

END IF;

    res := (
    SELECT DISTINCT
        dci.first_name,
        dci.last_name,
        toh.email_address as order_email,
        COALESCE(dci.EMAIL_PRIMARY, dci.EMAIL_SECONDARY, dci.EXTERNAL_EMAIL1, dci.EXTERNAL_EMAIL2) AS customer_email,
        toh.order_date as OrderDate,
        toh.source_ref_num as OrderNo,
        dci.TITLE,
        dci.legal_name,
        toh.pk_order_headerid,
        toh.payment_amount as GrandTotal,
        toh.order_notes as NoteText,
        ta2.pk_addressid as pk_bill_addressid,
        ta2.first_name as BillFirstName,
        ta2.last_name as BillLastName,
        ta2.company_name as BillCompany,
        ta2.address1 as BillAddressLine1,
        ta2.address2 as BillAddressLine2,
        ta2.address3 as BillAddressLine3,
        ta2.address4 as BillAddressLine4,
        ta2.address5 as BillAddressLine5,
        ta2.address6 as BillAddressLine6,
        ta2.city as BillCity,
        ta2.state as BillState,
        ta2.postal_code as BillZipCode,
        ta2.country as BillCountry,
        toh.email_address as BillEmailID,
        ta2.phone_number as BillMobilePhone,
        dct.customer_type,
        dc.source_ref_num,
        dc.pk_customerid
    FROM guest_customer_detailed_lookup_CUSTOMER_INFO AS tdci
        INNER JOIN ANALYTICS.CUSTOMER_INFO AS dci -- with(nolock) verificar que es esto
            ON dci.FK_CUSTOMERID = tdci.FK_CUSTOMERID
        INNER JOIN guest_customer_detailed_lookup_ORDER_INFO AS ttoh
            ON ttoh.FK_CUSTOMERID = dci.FK_CUSTOMERID
        INNER JOIN ANALYTICS.TXN_ORDER_HEADER AS toh -- with(nolock) verificar que es esto
            ON toh.PK_ORDER_HEADERID = ttoh.pk_order_headerid
        INNER JOIN ANALYTICS.CUSTOMER AS dc
            ON dc.PK_CUSTOMERID = dci.FK_CUSTOMERID
        INNER JOIN MASTER.DIM_CUSTOMER_TYPE AS dct
            ON dct.PK_CUSTOMER_TYPEID = dc.FK_CUSTOMER_TYPEID
        LEFT JOIN ANALYTICS.TXN_ADDRESS AS ta2 -- with(nolock) verificar que es esto
            ON toh.FK_BILLING_ADDRESSID = ta2.PK_ADDRESSID
    WHERE dct.CUSTOMER_TYPE = 'REGISTERED'
    LIMIT 100);

DROP TABLE guest_customer_detailed_lookup_CUSTOMER_INFO;

DROP TABLE guest_customer_detailed_lookup_ORDER_INFO;

RETURN TABLE(res);

END;