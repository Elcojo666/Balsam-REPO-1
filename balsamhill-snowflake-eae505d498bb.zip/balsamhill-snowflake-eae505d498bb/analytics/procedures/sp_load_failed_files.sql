USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.SP_LOAD_FAILED_FILES()
RETURNS STRING 
LANGUAGE SQL 
AS 
BEGIN
LET email_integration_name varchar :=  (select distinct integration_name from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Ingestion Failure' and environment='dev'  limit 1);
    
    LET email_list varchar :=  (select LISTAGG(distinct recipient,',') from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Ingestion Failure' and environment='dev');
    
    let email_subject varchar := (select DISTINCT subject_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Ingestion Failure' and environment='dev' limit 1);
    
    let email_body_default  varchar := (select DISTINCT body_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Ingestion Failure' and environment='dev' limit 1);
    
    LET email_body_general varchar := (
        SELECT COALESCE(COUNT(CASE WHEN STATUS = 'LOAD_FAILED' THEN TABLE_NAME ELSE NULL END), 0) AS LOAD_FAILED_FILES
        FROM SNOWFLAKE.ACCOUNT_USAGE.LOAD_HISTORY
        WHERE LAST_LOAD_TIME >= DATEADD(DAY, -1, CURRENT_TIMESTAMP())
    );

    LET email_body_specific varchar := (
            WITH ErrorSummary AS (
        SELECT 
            LH.TABLE_NAME,
            LH.FILE_NAME,
            COALESCE(SUM(LH.ERROR_COUNT), 0) AS errors
        FROM 
            SNOWFLAKE.ACCOUNT_USAGE.LOAD_HISTORY LH
        WHERE 
            LAST_LOAD_TIME >= DATEADD(DAY, -1, CURRENT_TIMESTAMP())
            AND LH.STATUS = 'FAILED'
        GROUP BY 
            LH.TABLE_NAME, LH.FILE_NAME
    ),
    FileAggregation AS (
        SELECT 
            TABLE_NAME,
            ARRAY_AGG(OBJECT_CONSTRUCT('file', FILE_NAME, 'error_count', errors)) AS file_info
        FROM 
            ErrorSummary
        GROUP BY 
            TABLE_NAME
    )
    SELECT 
        OBJECT_AGG(TABLE_NAME, file_info) AS files_info
    FROM 
        FileAggregation
    );

    
    CALL SYSTEM$SEND_EMAIL(
                :email_integration_name,
                :email_list,
                :email_subject,
                :email_body_default 
                ||'\n\n' || 'Total: ' || :email_body_general || ' files failed to be loaded.'
                ||'\n\n' || 'Table+File Error Count Report:' 
                ||'\n\n' || :email_body_specific
            );
    return 'Email Alert Sent';
END;
