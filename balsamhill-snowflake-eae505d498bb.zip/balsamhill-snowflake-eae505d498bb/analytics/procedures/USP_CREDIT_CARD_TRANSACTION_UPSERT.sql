


CREATE OR REPLACE PROCEDURE ANALYTICS.USP_CREDIT_CARD_TRANSACTION_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount,
    raw_table = 'raw_order_credit_card_transaction'
WHERE file_name = 'YFS_CREDIT_CARD_TRANSACTION';

CREATE OR REPLACE TEMPORARY TABLE TempCreditCardTransaction (
    credit_card_transaction_key VARCHAR,
    charge_transaction_key VARCHAR,
    tran_type VARCHAR,
    tran_amount FLOAT,
    tran_request_time  TIMESTAMP_NTZ(9),
    tran_return_code VARCHAR,
    tran_return_message VARCHAR,
    tran_return_flag VARCHAR,
    request_id VARCHAR,
    internal_return_code VARCHAR,
    internal_return_flag VARCHAR,
    internal_return_message VARCHAR,
    auth_amount FLOAT,
    auth_code VARCHAR,
    auth_avs VARCHAR,
    auth_return_code VARCHAR,
    auth_return_flag VARCHAR,
    auth_return_message VARCHAR,
    auth_time  TIMESTAMP_NTZ(9),
    parent_key VARCHAR,
    reference1 VARCHAR,
    reference2 VARCHAR,
    cvv_auth_code VARCHAR,
    createts TIMESTAMP_NTZ(9),
    modifyts TIMESTAMP_NTZ(9),
    createuserid VARCHAR,
    modifyuserid VARCHAR,
    createprogid VARCHAR,
    modifyprogid VARCHAR,
    lockid VARCHAR,
    inserted_date TIMESTAMP_NTZ(9),
    modified_date TIMESTAMP_NTZ(9),
    revision INT
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.txn_credit_card_transaction txn
USING (
    SELECT
        credit_card_transaction_key,
        charge_transaction_key,
        tran_type,
        tran_amount,
        tran_request_time,
        tran_return_code,
        tran_return_message,
        tran_return_flag,
        request_id,
        internal_return_code,
        internal_return_flag,
        internal_return_message,
        auth_amount,
        auth_code,
        auth_avs,
        auth_return_code,
        auth_return_flag,
        auth_return_message,
        auth_time,
        parent_key,
        reference1,
        reference2,
        cvv_auth_code,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid
    FROM TRANSFORMED.stg_order_credit_card_transaction stg
) stg
ON txn.credit_card_transaction_key = stg.credit_card_transaction_key
WHEN MATCHED THEN
    UPDATE SET
        txn.charge_transaction_key = stg.charge_transaction_key,
        txn.tran_type = stg.tran_type,
        txn.tran_amount = TRY_CAST(stg.tran_amount AS FLOAT),
        txn.tran_request_time = TRY_TO_TIMESTAMP(stg.tran_request_time,'YYYYMMDDHHMISS'),
        txn.tran_return_code = stg.tran_return_code,
        txn.tran_return_message = stg.tran_return_message,
        txn.tran_return_flag = stg.tran_return_flag,
        txn.request_id = stg.request_id,
        txn.internal_return_code = stg.internal_return_code,
        txn.internal_return_flag = stg.internal_return_flag,
        txn.internal_return_message = stg.internal_return_message,
        txn.auth_amount = TRY_CAST(stg.auth_amount AS FLOAT),
        txn.auth_code = stg.auth_code,
        txn.auth_avs = stg.auth_avs,
        txn.auth_return_code = stg.auth_return_code,
        txn.auth_return_flag = stg.auth_return_flag,
        txn.auth_return_message = stg.auth_return_message,
        txn.auth_time = TRY_TO_TIMESTAMP(stg.auth_time,'YYYYMMDDHHMISS'),
        txn.parent_key = stg.parent_key,
        txn.reference1 = stg.reference1,
        txn.reference2 = stg.reference2,
        txn.cvv_auth_code = stg.cvv_auth_code,
        txn.createts = TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS'),
        txn.modifyts = TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS'),
        txn.createuserid = stg.createuserid,
        txn.modifyuserid = stg.modifyuserid,
        txn.createprogid = stg.createprogid,
        txn.modifyprogid = stg.modifyprogid,
        txn.lockid = stg.lockid,
        txn.modified_date = current_timestamp
WHEN NOT MATCHED THEN
    INSERT (
        credit_card_transaction_key,
        charge_transaction_key,
        tran_type,
        tran_amount,
        tran_request_time,
        tran_return_code,
        tran_return_message,
        tran_return_flag,
        request_id,
        internal_return_code,
        internal_return_flag,
        internal_return_message,
        auth_amount,
        auth_code,
        auth_avs,
        auth_return_code,
        auth_return_flag,
        auth_return_message,
        auth_time,
        parent_key,
        reference1,
        reference2,
        cvv_auth_code,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        inserted_date
    )
    VALUES (
        stg.credit_card_transaction_key,
        stg.charge_transaction_key,
        stg.tran_type,
        TRY_CAST(stg.tran_amount AS FLOAT),
        TRY_TO_TIMESTAMP(stg.tran_request_time,'YYYYMMDDHHMISS'),
        stg.tran_return_code,
        stg.tran_return_message,
        stg.tran_return_flag,
        stg.request_id,
        stg.internal_return_code,
        stg.internal_return_flag,
        stg.internal_return_message,
        TRY_CAST(stg.auth_amount AS FLOAT),
        stg.auth_code,
        stg.auth_avs,
        stg.auth_return_code,
        stg.auth_return_flag,
        stg.auth_return_message,
        TRY_TO_TIMESTAMP(stg.auth_time,'YYYYMMDDHHMISS'),
        stg.parent_key,
        stg.reference1,
        stg.reference2,
        stg.cvv_auth_code,
        TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS'),
        stg.createuserid,
        stg.modifyuserid,
        stg.createprogid,
        stg.modifyprogid,
        stg.lockid,
        current_timestamp
    );

INSERT INTO TempCreditCardTransaction (
    credit_card_transaction_key,
    charge_transaction_key,
    tran_type,
    tran_amount,
    tran_request_time,
    tran_return_code,
    tran_return_message,
    tran_return_flag,
    request_id,
    internal_return_code,
    internal_return_flag,
    internal_return_message,
    auth_amount,
    auth_code,
    auth_avs,
    auth_return_code,
    auth_return_flag,
    auth_return_message,
    auth_time,
    parent_key,
    reference1,
    reference2,
    cvv_auth_code,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    revision
)
SELECT  stg.credit_card_transaction_key,
        stg.charge_transaction_key,
        stg.tran_type,
        stg.tran_amount,
        stg.tran_request_time,
        stg.tran_return_code,
        stg.tran_return_message,
        stg.tran_return_flag,
        stg.request_id,
        stg.internal_return_code,
        stg.internal_return_flag,
        stg.internal_return_message,
        stg.auth_amount,
        stg.auth_code,
        stg.auth_avs,
        stg.auth_return_code,
        stg.auth_return_flag,
        stg.auth_return_message,
        stg.auth_time,
        stg.parent_key,
        stg.reference1,
        stg.reference2,
        stg.cvv_auth_code,
        stg.createts,
        stg.modifyts,
        stg.createuserid,
        stg.modifyuserid,
        stg.createprogid,
        stg.modifyprogid,
        stg.lockid,
        current_timestamp, 1
FROM ANALYTICS.txn_credit_card_transaction stg
where stg.inserted_date > :processedDate or modified_date >= :processedDate;

CREATE OR REPLACE TEMPORARY TABLE TempAuditRevision AS
SELECT
    MAX(aot.revision) as revision,
    aot.credit_card_transaction_key
FROM
    ANALYTICS.audit_credit_card_transaction as aot
    INNER JOIN TempCreditCardTransaction as ttd
    ON ttd.credit_card_transaction_key = aot.credit_card_transaction_key
GROUP BY
    aot.credit_card_transaction_key;

UPDATE TempCreditCardTransaction ttd
SET ttd.Revision = CAST((coalesce(aot.revision, 0) + 1) as int)
FROM TempAuditRevision aot
WHERE ttd.credit_card_transaction_key = aot.credit_card_transaction_key;


UPDATE RAW.raw_order_credit_card_transaction AS roh
SET roh.processing_status = 'Processed',
    roh.processing_comment = '',
    roh.processing_errortype = ''
FROM (select stg.credit_card_transaction_key from TRANSFORMED.stg_order_credit_card_transaction AS stg
    JOIN ANALYTICS.txn_credit_card_transaction AS toh
    ON toh.credit_card_transaction_key = stg.credit_card_transaction_key)stgt
    WHERE stgt.credit_card_transaction_key = roh.credit_card_transaction_key;

-- Insert data into audit_credit_card_transaction
INSERT INTO ANALYTICS.audit_credit_card_transaction (
    credit_card_transaction_key,
    charge_transaction_key,
    tran_type,
    tran_amount,
    tran_request_time,
    tran_return_code,
    tran_return_message,
    tran_return_flag,
    request_id,
    internal_return_code,
    internal_return_flag,
    internal_return_message,
    auth_amount,
    auth_code,
    auth_avs,
    auth_return_code,
    auth_return_flag,
    auth_return_message,
    auth_time,
    parent_key,
    reference1,
    reference2,
    cvv_auth_code,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    Revision
)
SELECT
    stg.credit_card_transaction_key,
    stg.charge_transaction_key,
    stg.tran_type,
    TRY_CAST(stg.tran_amount AS FLOAT),
    TRY_TO_TIMESTAMP(stg.tran_request_time,'YYYYMMDDHHMISS'),
    stg.tran_return_code,
    stg.tran_return_message,
    stg.tran_return_flag,
    stg.request_id,
    stg.internal_return_code,
    stg.internal_return_flag,
    stg.internal_return_message,
    TRY_CAST(stg.auth_amount AS FLOAT),
    stg.auth_code,
    stg.auth_avs,
    stg.auth_return_code,
    stg.auth_return_flag,
    stg.auth_return_message,
    TRY_TO_TIMESTAMP(stg.auth_time,'YYYYMMDDHHMISS'),
    stg.parent_key,
    stg.reference1,
    stg.reference2,
    stg.cvv_auth_code,
     TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS'),
     TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS'),
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    CURRENT_TIMESTAMP(),  -- Use CURRENT_TIMESTAMP() for the current date and time
    ord.Revision
FROM TRANSFORMED.stg_order_credit_card_transaction stg
INNER JOIN TempCreditCardTransaction ord
ON ord.credit_card_transaction_key = stg.credit_card_transaction_key;

SELECT COUNT(*)
INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_order_credit_card_transaction;

-- Calculate the count of records from TempCreditCardTransaction
SELECT COUNT(*)
INTO :processedRecordCount
FROM TempCreditCardTransaction;

UPDATE log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = 'Success'
WHERE file_name = 'YFS_CREDIT_CARD_TRANSACTION';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

-- Drop temporary table
DROP TABLE IF EXISTS TempCreditCardTransaction;
COMMIT;
RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_CREDIT_CARD_TRANSACTION';
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	
	RETURN error_object;
END;