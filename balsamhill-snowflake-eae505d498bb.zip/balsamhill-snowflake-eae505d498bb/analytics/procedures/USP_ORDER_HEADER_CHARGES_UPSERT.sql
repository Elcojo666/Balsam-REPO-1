CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_HEADER_CHARGES_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    createdby NUMBER DEFAULT 1;
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedFeeDetails NUMBER DEFAULT 0;
    processedDiscountDetails NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
    

CREATE OR REPLACE TEMPORARY TABLE OrderDiscountDetails AS
SELECT 
    stg.header_charges_key,
    stg.header_key,
    toh.pk_order_headerid AS fk_order_headerid,
    stg.charge_name AS discount_name,
    CAST(stg.charge AS DECIMAL(38, 2)) AS discount_amount,
    stg.extn_charge_description AS discount_code,
    stg.extn_coupon_code AS coupon_code,
    stg.charge_category AS charge_type,
    stg.txn_id AS txn_id
FROM 
    TRANSFORMED.stg_ORDER_header_charges stg
INNER JOIN 
     ANALYTICS.txn_order_header AS toh ON toh.ext_order_id = stg.header_key AND toh.entry_type IS NOT NULL
INNER JOIN 
      master.dim_CHARGECATEGORY AS dc ON dc.charge_category = stg.charge_category AND dc.charge = ''DISCOUNT''
WHERE 
    toh.pk_order_headerid IS NOT NULL
    AND UPPER(dc.charge) IN (''DISCOUNT'');


    
CREATE OR REPLACE TEMPORARY TABLE TempDiscountDetails(  
  pk_order_discountid BIGINT NOT NULL,  
   ext_charge_id TEXT NOT NULL, 
   fk_order_headerid BIGINT  NOT NULL  
  ,discount_name  TEXT NOT NULL  
  ,discount_amount  DECIMAL(38, 2) NOT NULL  
  ,discount_code TEXT NULL  
  ,coupon_code TEXT NULL  
  ,createdby NUMBER NULL  
  ,created_date TIMESTAMP NULL  
  ,modified_date TIMESTAMP NULL  
  ,Revision NUMBER NULL);

processedDate := CURRENT_TIMESTAMP();  

MERGE INTO  ANALYTICS.txn_order_discount AS tod
USING (
    SELECT DISTINCT
        orddisc.fk_order_headerid,
        orddisc.discount_name,
        orddisc.header_charges_key,
        orddisc.discount_code,
        orddisc.coupon_code,
        orddisc.discount_amount,
        CURRENT_TIMESTAMP() AS created_date,
        CURRENT_TIMESTAMP() AS modified_date
    FROM
        OrderDiscountDetails AS orddisc
) AS ohd
ON (
    tod.fk_order_headerid = ohd.fk_order_headerid
    AND tod.ext_charge_id = ohd.header_charges_key
    AND tod.discount_name = ohd.discount_name
)
WHEN MATCHED THEN
    UPDATE SET
        tod.discount_name = ohd.discount_name,
        tod.discount_code = ohd.discount_code,
        tod.coupon_code = ohd.coupon_code,
        tod.discount_amount = ohd.discount_amount,
        tod.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        fk_order_headerid,
        discount_name,
        discount_code,
        coupon_code,
        discount_amount,
        ext_charge_id,
        inserted_date,
        modified_date
    ) VALUES (
        ohd.fk_order_headerid,
        ohd.discount_name,
        ohd.discount_code,
        ohd.coupon_code,
        ohd.discount_amount,
        ohd.header_charges_key,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );


INSERT INTO TempDiscountDetails (
    pk_order_discountid,
    fk_order_headerid,
    discount_name,
    discount_code,
    coupon_code,
    discount_amount,
    ext_charge_id,
    createdby,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_discountid,
    fk_order_headerid,
    discount_name,
    discount_code,
    coupon_code,
    discount_amount,
    ext_charge_id,
    :createdby,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    :InitialRevision
FROM  ANALYTICS.txn_order_discount
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;



MERGE INTO TempDiscountDetails tdd
USING (
    SELECT
        MAX(aod.revision) AS revision,
        aod.pk_order_discountid,
        aod.fk_order_headerid
    FROM ANALYTICS.audit_order_discount AS aod
    INNER JOIN TempDiscountDetails AS tdd
        ON tdd.pk_order_discountid = aod.pk_order_discountid
        AND tdd.fk_order_headerid = aod.fk_order_headerid
    GROUP BY
        aod.pk_order_discountid,
        aod.fk_order_headerid
) AS src
ON tdd.pk_order_discountid = src.pk_order_discountid
AND tdd.fk_order_headerid = src.fk_order_headerid
WHEN MATCHED THEN
    UPDATE SET tdd.Revision = CAST((src.revision + 1) AS INT);

INSERT INTO  ANALYTICS.audit_order_discount (
    pk_order_discountid,
    fk_order_headerid,
    discount_name,
    discount_code,
    coupon_code,
    discount_amount,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_discountid,
    fk_order_headerid,
    discount_name,
    discount_code,
    coupon_code,
    discount_amount,
    createdby,
    created_date,
    modified_date,
    revision
FROM TempDiscountDetails;

CREATE OR REPLACE TEMPORARY TABLE TempFeeDetails(  
  pk_order_Feeid BIGINT NOT NULL,  
  ext_charge_id TEXT NOT NULL  
  ,fk_order_headerid BIGINT NOT NULL  
  ,fee_type  TEXT NOT NULL  
  ,fee_amount  DECIMAL(38, 2) NOT NULL  
  ,createdby NUMBER NULL  
  ,created_date TIMESTAMP NULL  
  ,modified_date TIMESTAMP NULL  
  ,Revision NUMBER NULL);  

CREATE OR REPLACE TEMPORARY TABLE OrderFeeDetails AS
SELECT 
    stg.header_charges_key,
    stg.header_key,
    toh.pk_order_headerid AS fk_order_headerid,
    stg.charge_name AS fee_type,
    CAST(stg.charge AS DECIMAL(38,2)) AS fee_amount,
    stg.charge_category AS charge_type,
    stg.txn_id AS txn_id
FROM 
    TRANSFORMED.stg_ORDER_header_charges stg
    INNER JOIN analytics.txn_order_header toh 
        ON toh.ext_order_id = stg.header_key 
        AND toh.entry_type IS NOT NULL
    INNER JOIN master.dim_CHARGECATEGORY dc 
        ON dc.charge_category = stg.charge_category 
        AND dc.charge = ''FEE''
WHERE
    toh.pk_order_headerid IS NOT NULL  
    AND UPPER(dc.charge) IN (''FEE'');

    

MERGE INTO  ANALYTICS.txn_order_fee AS tod
USING OrderFeeDetails AS ohd
ON 
    tod.fk_order_headerid = ohd.fk_order_headerid  
    AND tod.ext_charge_id = ohd.header_charges_key  
    AND tod.fee_type = ohd.fee_type
WHEN MATCHED THEN
    UPDATE SET
        tod.fee_type = ohd.fee_type,
        tod.fee_amount = ohd.fee_amount,
        tod.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        fk_order_headerid,
        fee_type,
        fee_amount,
        ext_charge_id,
        inserted_date,
        modified_date
    )
    VALUES (
        ohd.fk_order_headerid,
        ohd.fee_type,
        ohd.fee_amount,
        ohd.header_charges_key,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempFeeDetails (
    pk_order_feeid,
    fk_order_headerid,
    fee_type,
    fee_amount,
    ext_charge_id,
    createdby,
    created_date,
    modified_date,
    revision
)
SELECT
    t.pk_order_feeid,
    t.fk_order_headerid,
    t.fee_type,
    t.fee_amount,
    t.ext_charge_id,
    :createdby, -- Replace with actual value if needed
    t.inserted_date,
    t.modified_date,
    1 AS revision -- Replace with @InitialRevision if needed
FROM analytics.txn_order_fee t
JOIN (
    SELECT 
        fk_order_headerid,
        fee_type,
        fee_amount,
        header_charges_key
    FROM OrderFeeDetails
) AS ohd
ON (
    t.fk_order_headerid = ohd.fk_order_headerid
    AND t.ext_charge_id = ohd.header_charges_key
    AND t.fee_type = ohd.fee_type
)
;

MERGE INTO TempFeeDetails tdd
USING (
    SELECT 
        MAX(aod.revision) AS max_revision,
        aod.pk_order_feeid,
        aod.fk_order_headerid
    FROM analytics.audit_order_fee AS aod
    INNER JOIN TempFeeDetails AS tdd 
        ON tdd.pk_order_feeid = aod.pk_order_feeid 
        AND tdd.fk_order_headerid = aod.fk_order_headerid
    GROUP BY 
        aod.pk_order_feeid,
        aod.fk_order_headerid
) AS src
ON tdd.pk_order_feeid = src.pk_order_feeid
AND tdd.fk_order_headerid = src.fk_order_headerid
WHEN MATCHED THEN
    UPDATE SET tdd.Revision = (src.max_revision + 1)::number ;


INSERT INTO  analytics.audit_order_fee (  
    pk_order_feeid,  
    fk_order_headerid,  
    fee_type,  
    fee_amount,  
    created_by,  
    created_date,  
    modified_date,  
    revision,
    ext_charge_id
)  
SELECT  
    pk_order_feeid,  
    fk_order_headerid,  
    fee_type,  
    fee_amount,  
    createdby,  
    created_date,  
    modified_date,  
    revision,
    ext_charge_id
FROM TempFeeDetails;

MERGE INTO RAW.raw_ORDER_header_charges AS rohc
USING (
    SELECT 
        sohc.header_charges_key, 
        sohc.header_key, 
        sohc.txn_id, 
        sohc.modifyts,
        odd.fk_order_headerid, 
        odd.discount_name
    FROM TRANSFORMED.stg_ORDER_header_charges AS sohc
    INNER JOIN OrderDiscountDetails AS odd 
        ON odd.header_charges_key = sohc.header_charges_key
        AND odd.header_key = sohc.header_key
        AND odd.txn_id = sohc.txn_id
    INNER JOIN TempDiscountDetails AS tdd 
        ON tdd.fk_order_headerid = odd.fk_order_headerid
        AND tdd.discount_name = odd.discount_name
) AS matched
ON rohc.header_charges_key = matched.header_charges_key
    AND rohc.header_key = matched.header_key
    AND rohc.txn_id = matched.txn_id
    AND rohc.modifyts = matched.modifyts
WHEN MATCHED THEN
UPDATE SET 
    rohc.processing_status = ''Processed'',  
    rohc.processing_comment = '''',  
    rohc.processing_errortype = '''';

MERGE INTO RAW.raw_ORDER_header_charges rohc
USING (
    SELECT 
        sohc.header_charges_key, 
        sohc.header_key, 
        sohc.txn_id, 
        sohc.modifyts, 
        odd.header_charges_key AS odd_header_charges_key, 
        tdd.fk_order_headerid, 
        tdd.fee_type
    FROM 
        TRANSFORMED.stg_ORDER_header_charges AS sohc
    INNER JOIN OrderFeeDetails AS odd 
        ON odd.header_charges_key = sohc.header_charges_key 
        AND odd.header_key = sohc.header_key 
        AND odd.txn_id = sohc.txn_id
    INNER JOIN TempFeeDetails AS tdd 
        ON tdd.fk_order_headerid = odd.fk_order_headerid 
        AND tdd.fee_type = odd.fee_type
) AS src
ON rohc.header_charges_key = src.header_charges_key
AND rohc.header_key = src.header_key
AND rohc.txn_id = src.txn_id
AND rohc.modifyts = src.modifyts
WHEN MATCHED THEN
    UPDATE SET 
        rohc.processing_status = ''Processed'',
        rohc.processing_comment = '''',
        rohc.processing_errortype = '''';



SELECT
    COUNT(*)
INTO
    :processedFeeDetails
FROM
    TempFeeDetails;


SELECT
    COUNT(*)
INTO
    :processedDiscountDetails
FROM
    TempDiscountDetails;
    
processedRecordCount := processedFeeDetails + processedDiscountDetails
;

SELECT
    COUNT(*)
INTO
    :toBeProcessedRecordCount
FROM
    TRANSFORMED.stg_ORDER_header_charges;


UPDATE ANALYTICS.log_files_import_status AS lofis
SET   
   lofis.processed = :processedRecordCount,
   lofis.status = ''Success''
WHERE lofis.file_name = ''YFS_HEADER_CHARGES'';


    
  DROP TABLE IF EXISTS OrderFeeDetails;  
  DROP TABLE IF EXISTS TempFeeDetails;  
  
  DROP TABLE IF EXISTS OrderDiscountDetails;  
  DROP TABLE IF EXISTS TempDiscountDetails; 

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_HEADER_CHARGES'';

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';