USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_VALIDATE_ARCHIVE_TABLE("RAWTABLENAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    tableExists NUMBER DEFAULT 0;
    archiveTableName STRING;
    rawCompleteName STRING;
    completeArchiveTableName STRING;
    schemaValid BOOLEAN;
BEGIN
    archiveTableName := ''ARC_'' || rawTableName;

    tableExists := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = UPPER(:archiveTableName));
    
    completeArchiveTableName := ''ARCHIVE.ARC_'' || rawTableName;

    rawCompleteName := ''RAW.'' || rawTableName;
    
    IF (tableExists = 0) THEN
        CREATE TABLE IDENTIFIER(:completeArchiveTableName) AS SELECT * FROM IDENTIFIER(:rawCompleteName) WHERE 1 = 0;
        ALTER TABLE IDENTIFIER(:completeArchiveTableName) ADD COLUMN archived_date TIMESTAMP;
    END IF;
    
RETURN UPPER(:archiveTableName);
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
