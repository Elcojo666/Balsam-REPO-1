USE DATABASE DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.SP_INSERTCUSTOMERADDRESSDETAILS("P_PK_CUSTOMERID" NUMBER(38,0), "P_SOURCEID" NUMBER(38,0), "P_IS_DEFAULT" BOOLEAN DEFAULT null, "P_ADDRESS_TYPE" VARCHAR DEFAULT null, "P_ADDRESS_LINE_1" VARCHAR DEFAULT null, "P_ADDRESS_LINE_2" VARCHAR DEFAULT null, "P_ADDRESS_LINE_3" VARCHAR DEFAULT null, "P_ADDRESS_LINE_4" VARCHAR DEFAULT null, "P_CITY" VARCHAR DEFAULT null, "P_STATE" VARCHAR DEFAULT null, "P_POSTAL_CODE" VARCHAR DEFAULT null, "P_COUNTRY_CODE" VARCHAR DEFAULT null, "P_CREATED_BY" VARCHAR DEFAULT null, "P_CREATED_DATE" TIMESTAMP_NTZ(9) DEFAULT null, "P_MODIFIED_BY" VARCHAR DEFAULT null, "P_MODIFIED_DATE" TIMESTAMP_NTZ(9) DEFAULT null, "P_LATITUDE" VARCHAR DEFAULT null, "P_LONGITUDE" VARCHAR DEFAULT null, "P_FIRSTNAME" VARCHAR DEFAULT null, "P_LASTNAME" VARCHAR DEFAULT null)
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    message                   STRING;
    pk_customer_info_id       STRING;
    pk_customer_address_id    STRING;
    modified                  TIMESTAMP_NTZ(9);
    res                       RESULTSET; 
    error_message             STRING;
    sql_code                  STRING;
BEGIN
    
    -------------------------------------------------------------------------
    -- Retrieve the customer info id from analytics.customer_info using the
    -- passed-in customer id.
    -------------------------------------------------------------------------
    SELECT DISTINCT PK_CUSTOMER_INFO_ID
      INTO :pk_customer_info_id
    FROM analytics.customer_info
    WHERE FK_CUSTOMERID = :p_pk_customerid
      AND PK_CUSTOMER_INFO_ID IS NOT NULL;
      
    IF (pk_customer_info_id IS NULL OR pk_customer_info_id = '''') THEN
        message := ''Status: Failed StatusCode: 400, No Customer Found.'';
        res := (SELECT :message AS MESSAGE,
                       ''Failed'' AS STATUS,
                       NULL AS ID,
                       ''400'' AS STATUSCODE);
        RETURN TABLE(res);
    END IF;
    
    -------------------------------------------------------------------------
    -- If the incoming address is marked as default, update any existing 
    -- addresses for this customer so that they are no longer default.
    -------------------------------------------------------------------------
    IF (p_is_default = TRUE) THEN
        UPDATE analytics.customer_address
           SET is_default = FALSE
         WHERE fk_customer_info_id = :pk_customer_info_id;
    END IF;
    
    -------------------------------------------------------------------------
    -- Set the modified timestamp and perform the INSERT using a VALUES clause.
    -------------------------------------------------------------------------
    modified := CURRENT_TIMESTAMP();
    
    INSERT INTO analytics.customer_address (
        fk_customer_info_id,
        address_type,
        address_line_1,
        address_line_2,
        address_line_3,
        address_line_4,
        city,
        state,
        postal_code,
        country_code,
        created_by,
        created_date,
        modified_by,
        modified_date,
        latitude,
        longitude,
        firstname,
        lastname,
        is_default
    )
    SELECT
        :pk_customer_info_id,
        :p_address_type,
        :p_address_line_1,
        :p_address_line_2,
        :p_address_line_3,
        :p_address_line_4,
        :p_city,
        :p_state,
        :p_postal_code,
        :p_country_code,
        :p_created_by,
        COALESCE(:p_created_date, :modified),
        :p_modified_by,
        :modified,
        :p_latitude,
        :p_longitude,
        :p_firstName,
        :p_lastName,
        :p_is_default;
    
    -------------------------------------------------------------------------
    -- Retrieve the newly inserted PK_CUSTOMER_ADDRESS_ID.
    -------------------------------------------------------------------------
    SELECT PK_CUSTOMER_ADDRESS_ID
      INTO :pk_customer_address_id
    FROM analytics.customer_address
    WHERE fk_customer_info_id = :pk_customer_info_id
      AND modified_date = :modified
    LIMIT 1;
    
    
    message := ''Record Inserted'';
    res := (SELECT ''Record Inserted'' AS MESSAGE,
                   ''Success'' AS STATUS,
                   :pk_customer_address_id AS ID,
                   ''200'' AS STATUSCODE);
    RETURN TABLE(res);
    
EXCEPTION
    WHEN statement_error THEN
        ROLLBACK;
        error_message := sqlerrm;
        sql_code := sqlcode;
        INSERT INTO ANALYTICS.log_microservices_errors (
            microservicesname,  
            methodname,  
            errortime,  
            errormessage,  
            source,  
            exceptiontrace,  
            sql_errornumber,  
            sql_errorstate,  
            sql_errorseverity,  
            sql_errorline,  
            sql_errorprocedure,  
            sql_errormessage
        )
        VALUES (
            ''CustomerApi'',  
            ''InsertCustomerAddressDetails'',  
            CURRENT_TIMESTAMP(),  
            ''Error in SQL'',  
            :p_SOURCEID,  
            NULL,  
            :sql_code,  
            NULL,  
            NULL,  
            NULL,  
            NULL,  
            :error_message
        );
        SYSTEM$LOG(''ERROR'',''SP_INSERTCUSTOMERADDRESSDETAILS has Failed'');
        res := (SELECT ''Error: '' || error_message AS MESSAGE,
                        ''Failed'' AS STATUS,
                        NULL AS ID,
                        ''500'' AS STATUSCODE);
        RETURN TABLE(res);
END';
