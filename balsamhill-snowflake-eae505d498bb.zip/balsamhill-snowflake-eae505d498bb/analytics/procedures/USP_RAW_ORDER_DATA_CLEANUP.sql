USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_RAW_ORDER_DATA_CLEANUP()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
  limitDate datetime DEFAULT DATEADD(day, -50,  getdate());
  BEGIN
  SYSTEM$LOG(''TRACE'','' USP_RAW_ORDER_DATA_CLEANUP has been Started'');

delete  from raw.raw_order_header where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_header_charges  where imported_date < :limitDate  and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_line  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_line_charges  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_tax_breakup  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_container_details  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_payment  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_payment_type  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_person_info  where (((case when IMPORTED_DATE ilike any (''%PM'',''%AM'') then left(to_timestamp(IMPORTED_DATE,''Mon DD YYYY HH12:MIAM''),16) else IMPORTED_DATE end ))) < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_release  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_release_status  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_shipment  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_shipment_container  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
delete  from raw.raw_order_shipment_line  where imported_date < :limitDate and processing_status in (''Processed'',''Rejected'');
SYSTEM$LOG(''TRACE'','' USP_RAW_ORDER_DATA_CLEANUP has been Completed'');

RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    SYSTEM$LOG(''ERROR'','' SP_INSERTCUSTOMERADDRESSDETAILS has Failed'');

	RETURN sqlerrm;
END';
