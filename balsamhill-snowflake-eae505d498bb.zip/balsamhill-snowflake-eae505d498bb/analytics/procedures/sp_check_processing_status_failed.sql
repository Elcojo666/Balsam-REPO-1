USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.SP_CHECK_PROCESSING_STATUS_FAILED()
  RETURNS STRING
  LANGUAGE PYTHON
  RUNTIME_VERSION = '3.8'
  PACKAGES = ('snowflake-snowpark-python')
  HANDLER = 'run'
  EXECUTE AS CALLER
AS
$$
import snowflake.snowpark as snowpark

def run(session) -> str:
    
    # Get list of tables in RAW schema
    tables_query = tables_query = """
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'RAW'
        """
    tables_df = session.sql(tables_query).to_pandas()
    
    for index, row in tables_df.iterrows():
        table_name = row['TABLE_NAME']
        
        # Check if table has PROCESSING_STATUS column
        columns_query = f"""
            SELECT column_name
            FROM information_schema.columns
            WHERE table_schema = 'RAW'
            AND table_name = '{table_name}'
            AND column_name = 'PROCESSING_STATUS'
            """
        columns_df = session.sql(columns_query).to_pandas()
    
        if not columns_df.empty:
            # Count records with PROCESSING_STATUS = 'Failed'
            failed_count_query = f"SELECT COUNT(*) FROM RAW.{table_name} WHERE PROCESSING_STATUS = 'Failed'"
            record_count_query = f"SELECT COUNT(*) FROM RAW.{table_name}"
            
            failed_count = session.sql(failed_count_query).collect()[0][0]
            record_count = session.sql(record_count_query).collect()[0][0]
            
            # Call SQL procedure to send email if any failed records are found
            if failed_count > 0:
                session.sql(f"CALL ANALYTICS.SP_SEND_FAILED_ALERT_EMAIL('{table_name}', {failed_count}, {record_count})").collect()
    
    session.close()
$$
;
