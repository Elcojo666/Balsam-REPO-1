CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_SHIPMENT_LINE_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

UPDATE analytics.log_files_import_status
SET processed = :processedRecordCount,
    raw_table = 'raw_ORDER_shipment'
WHERE file_name = 'YFS_SHIPMENT_LINE';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

CREATE OR REPLACE TEMPORARY TABLE insertedShipmentLineRecords
(
    shipment_key STRING, 
    shipment_line_key STRING, 
    order_header_key STRING, 
    txn_id STRING,
    revision INT
);

processedDate := current_timestamp();

MERGE INTO ANALYTICS.txn_order_shipment_line tsl
USING (
SELECT DISTINCT shipment_line_key
			,shipment_key
			,shipment_line_no
			,shipment_sub_line_no
			,parent_shipment_line_key
			,order_header_key
			,order_release_key
			,order_line_key
			,order_no
			,release_no
			,prime_line_no
			,sub_line_no
			,item_id
			,product_class
			,uom
			,TRY_CAST(net_weight AS FLOAT) AS net_weight
			,net_weight_uom
			,country_of_origin
			,fifo_no
			,TRY_TO_NUMBER(quantity) AS quantity
			,TRY_TO_NUMBER(over_ship_quantity) AS over_ship_quantity
			,TRY_TO_NUMBER(original_quantity) AS original_quantity
			,TRY_TO_NUMBER(kit_qty) AS kit_qty
			,requested_tag_number
			,requested_serial_no
			,item_description
			,segment
			,segment_type
			,shortage_qty
			,customer_po_no
			,customer_po_line_no
			,mark_for_key
			,buyer_mark_for_node_id
			,order_type
			,shipment_consol_group_id
			,ship_to_customer_id
			,kit_code
			,is_pickable
			,department_code
			,gift_flag
			,external_release_identifier
			,is_hazmat
			,return_shipping_label_level
			,level_of_service
			,pick_location
			,pick_location_seq
			,group_sequence_num
			,lockid
			,createts
			,modifyts
			,createuserid
			,modifyuserid
			,createprogid
			,modifyprogid
			,wave_no
			,TRY_TO_NUMBER(backroom_picked_qty) AS backroom_picked_qty
			,TRY_TO_NUMBER(customer_picked_qty) AS customer_picked_qty
			,shortage_resolution_reason
			,cancel_reason
			,is_pack_complete
			,backroom_pick_complete
			,is_customer_pick_complete
			,staging_complete
			,TRY_TO_NUMBER(staged_qty) AS staged_qty
			,store_batch_key
			,batch_pick_priority
			,store_batch_location_key
			,txn_id
FROM TRANSFORMED.stg_ORDER_shipment_line
) ssl
ON
	tsl.shipment_line_key = ssl.shipment_line_key AND
	tsl.shipment_key = ssl.shipment_key
WHEN MATCHED THEN
    UPDATE SET
tsl.shipment_line_key=ssl.shipment_line_key
			,tsl.shipment_key=ssl.shipment_key
			,tsl.shipment_line_no=ssl.shipment_line_no
			,tsl.shipment_sub_line_no=ssl.shipment_sub_line_no
			,tsl.parent_shipment_line_key=ssl.parent_shipment_line_key
			,tsl.order_header_key=ssl.order_header_key
			,tsl.order_release_key=ssl.order_release_key
			,tsl.order_line_key=ssl.order_line_key
			,tsl.order_no=ssl.order_no
			,tsl.release_no=ssl.release_no
			,tsl.prime_line_no=ssl.prime_line_no
			,tsl.sub_line_no=ssl.sub_line_no
			,tsl.item_id=ssl.item_id
			,tsl.product_class=ssl.product_class
			,tsl.uom=ssl.uom
			,tsl.net_weight=ssl.net_weight
			,tsl.net_weight_uom=ssl.net_weight_uom
			,tsl.country_of_origin=ssl.country_of_origin
			,tsl.fifo_no=ssl.fifo_no
			,tsl.quantity=ssl.quantity
			,tsl.over_ship_quantity=ssl.over_ship_quantity
			,tsl.original_quantity=ssl.original_quantity
			,tsl.kit_qty=ssl.kit_qty
			,tsl.requested_tag_number=ssl.requested_tag_number
			,tsl.requested_serial_no=ssl.requested_serial_no
			,tsl.item_description=ssl.item_description
			,tsl.segment=ssl.segment
			,tsl.segment_type=ssl.segment_type
			,tsl.shortage_qty=ssl.shortage_qty
			,tsl.customer_po_no=ssl.customer_po_no
			,tsl.customer_po_line_no=ssl.customer_po_line_no
			,tsl.mark_for_key=ssl.mark_for_key
			,tsl.buyer_mark_for_node_id=ssl.buyer_mark_for_node_id
			,tsl.order_type=ssl.order_type
			,tsl.shipment_consol_group_id=ssl.shipment_consol_group_id
			,tsl.ship_to_customer_id=ssl.ship_to_customer_id
			,tsl.kit_code=ssl.kit_code
			,tsl.is_pickable=ssl.is_pickable
			,tsl.department_code=ssl.department_code
			,tsl.gift_flag=ssl.gift_flag
			,tsl.external_release_identifier=ssl.external_release_identifier
			,tsl.is_hazmat=ssl.is_hazmat
			,tsl.return_shipping_label_level=ssl.return_shipping_label_level
			,tsl.level_of_service=ssl.level_of_service
			,tsl.pick_location=ssl.pick_location
			,tsl.pick_location_seq=ssl.pick_location_seq
			,tsl.group_sequence_num=ssl.group_sequence_num
			,tsl.lockid=ssl.lockid
			,tsl.createts=TRY_TO_TIMESTAMP(ssl.createts,'YYYYMMDDHHMISS') 
			,tsl.modifyts=TRY_TO_TIMESTAMP(ssl.modifyts,'YYYYMMDDHHMISS') 
			,tsl.createuserid=ssl.createuserid
			,tsl.modifyuserid=ssl.modifyuserid
			,tsl.createprogid=ssl.createprogid
			,tsl.modifyprogid=ssl.modifyprogid
			,tsl.wave_no=ssl.wave_no
			,tsl.backroom_picked_qty=ssl.backroom_picked_qty
			,tsl.customer_picked_qty=ssl.customer_picked_qty
			,tsl.shortage_resolution_reason=ssl.shortage_resolution_reason
			,tsl.cancel_reason=ssl.cancel_reason
			,tsl.is_pack_complete=ssl.is_pack_complete
			,tsl.backroom_pick_complete=ssl.backroom_pick_complete
			,tsl.is_customer_pick_complete=ssl.is_customer_pick_complete
			,tsl.staging_complete=ssl.staging_complete
			,tsl.staged_qty=ssl.staged_qty
			,tsl.store_batch_key=ssl.store_batch_key
			,tsl.batch_pick_priority=ssl.batch_pick_priority
			,tsl.store_batch_location_key=ssl.store_batch_location_key
			,tsl.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
shipment_line_key
		,shipment_key
		,shipment_line_no
		,shipment_sub_line_no
		,parent_shipment_line_key
		,order_header_key
		,order_release_key
		,order_line_key
		,order_no
		,release_no
		,prime_line_no
		,sub_line_no
		,item_id
		,product_class
		,uom
		,net_weight
		,net_weight_uom
		,country_of_origin
		,fifo_no
		,quantity
		,over_ship_quantity
		,original_quantity
		,kit_qty
		,requested_tag_number
		,requested_serial_no
		,item_description
		,segment
		,segment_type
		,shortage_qty
		,customer_po_no
		,customer_po_line_no
		,mark_for_key
		,buyer_mark_for_node_id
		,order_type
		,shipment_consol_group_id
		,ship_to_customer_id
		,kit_code
		,is_pickable
		,department_code
		,gift_flag
		,external_release_identifier
		,is_hazmat
		,return_shipping_label_level
		,level_of_service
		,pick_location
		,pick_location_seq
		,group_sequence_num
		,lockid
		,createts
		,modifyts
		,createuserid
		,modifyuserid
		,createprogid
		,modifyprogid
		,wave_no
		,backroom_picked_qty
		,customer_picked_qty
		,shortage_resolution_reason
		,cancel_reason
		,is_pack_complete
		,backroom_pick_complete
		,is_customer_pick_complete
		,staging_complete
		,staged_qty
		,store_batch_key
		,batch_pick_priority
		,store_batch_location_key
		,inserted_date
    )
VALUES (
ssl.shipment_line_key
		,ssl.shipment_key
		,ssl.shipment_line_no
		,ssl.shipment_sub_line_no
		,ssl.parent_shipment_line_key
		,ssl.order_header_key
		,ssl.order_release_key
		,ssl.order_line_key
		,ssl.order_no
		,ssl.release_no
		,ssl.prime_line_no
		,ssl.sub_line_no
		,ssl.item_id
		,ssl.product_class
		,ssl.uom
		,ssl.net_weight
		,ssl.net_weight_uom
		,ssl.country_of_origin
		,ssl.fifo_no
		,ssl.quantity
		,ssl.over_ship_quantity
		,ssl.original_quantity
		,ssl.kit_qty
		,ssl.requested_tag_number
		,ssl.requested_serial_no
		,ssl.item_description
		,ssl.segment
		,ssl.segment_type
		,ssl.shortage_qty
		,ssl.customer_po_no
		,ssl.customer_po_line_no
		,ssl.mark_for_key
		,ssl.buyer_mark_for_node_id
		,ssl.order_type
		,ssl.shipment_consol_group_id
		,ssl.ship_to_customer_id
		,ssl.kit_code
		,ssl.is_pickable
		,ssl.department_code
		,ssl.gift_flag
		,ssl.external_release_identifier
		,ssl.is_hazmat
		,ssl.return_shipping_label_level
		,ssl.level_of_service
		,ssl.pick_location
		,ssl.pick_location_seq
		,ssl.group_sequence_num
		,ssl.lockid
		,TRY_TO_TIMESTAMP(ssl.createts,'YYYYMMDDHHMISS') 
		,TRY_TO_TIMESTAMP(ssl.modifyts,'YYYYMMDDHHMISS')
		,ssl.createuserid
		,ssl.modifyuserid
		,ssl.createprogid
		,ssl.modifyprogid
		,ssl.wave_no
		,ssl.backroom_picked_qty
		,ssl.customer_picked_qty
		,ssl.shortage_resolution_reason
		,ssl.cancel_reason
		,ssl.is_pack_complete
		,ssl.backroom_pick_complete
		,ssl.is_customer_pick_complete
		,ssl.staging_complete
		,ssl.staged_qty
		,ssl.store_batch_key
		,ssl.batch_pick_priority
		,ssl.store_batch_location_key
		,CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TEMPORARY TABLE insertedShipmentLineRecords AS 
SELECT inserted.shipment_key,
		inserted.shipment_line_key,
		inserted.order_header_key,
		ssl.txn_id,
		1 as revision
FROM ANALYTICS.txn_order_shipment_line inserted 
    INNER JOIN TRANSFORMED.STG_ORDER_SHIPMENT_LINE ssl 
        ON inserted.shipment_line_key = ssl.shipment_line_key AND
    	inserted.shipment_key = ssl.shipment_key
WHERE inserted.inserted_date > :processedDate or inserted.modified_date > :processedDate
;

-- UPDATE insertedShipmentLineRecords
-- SET Revision = CAST((IFNULL(aot.revision, 0) + 1) AS INTEGER)
-- FROM insertedShipmentLineRecords ttd
-- INNER JOIN (
--     SELECT
--         MAX(aot.revision) AS revision,
--         aot.shipment_line_key,
--         aot.shipment_key
--     FROM audit_order_shipment_line aot
--     INNER JOIN insertedShipmentLineRecords ttd 
--     ON ttd.shipment_line_key = aot.shipment_line_key 
--     AND ttd.shipment_key = aot.shipment_key 
--     GROUP BY aot.shipment_line_key, aot.shipment_key
-- ) aot 
-- ON ttd.shipment_line_key = aot.shipment_line_key 
-- AND ttd.shipment_key = aot.shipment_key;

CREATE OR REPLACE TEMPORARY TABLE temp_max_revisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.shipment_line_key,
    aot.shipment_key
FROM
    ANALYTICS.audit_order_shipment_line AS aot
GROUP BY
    aot.shipment_line_key,
    aot.shipment_key;

UPDATE insertedShipmentLineRecords AS ttd
SET
    ttd.revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM
    temp_max_revisions AS aot
WHERE
    ttd.shipment_line_key = aot.shipment_line_key AND
    ttd.shipment_key = aot.shipment_key;

DROP TABLE IF EXISTS temp_max_revisions;

INSERT INTO ANALYTICS.audit_order_shipment_line (
    shipment_line_key,
    shipment_key,
    shipment_line_no,
    shipment_sub_line_no,
    parent_shipment_line_key,
    order_header_key,
    order_release_key,
    order_line_key,
    order_no,
    release_no,
    prime_line_no,
    sub_line_no,
    item_id,
    product_class,
    uom,
    net_weight,
    net_weight_uom,
    country_of_origin,
    fifo_no,
    quantity,
    over_ship_quantity,
    original_quantity,
    kit_qty,
    requested_tag_number,
    requested_serial_no,
    item_description,
    segment,
    segment_type,
    shortage_qty,
    customer_po_no,
    customer_po_line_no,
    mark_for_key,
    buyer_mark_for_node_id,
    order_type,
    shipment_consol_group_id,
    ship_to_customer_id,
    kit_code,
    is_pickable,
    department_code,
    gift_flag,
    external_release_identifier,
    is_hazmat,
    return_shipping_label_level,
    level_of_service,
    pick_location,
    pick_location_seq,
    group_sequence_num,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    wave_no,
    backroom_picked_qty,
    customer_picked_qty,
    shortage_resolution_reason,
    cancel_reason,
    is_pack_complete,
    backroom_pick_complete,
    is_customer_pick_complete,
    staging_complete,
    staged_qty,
    store_batch_key,
    batch_pick_priority,
    store_batch_location_key,
    inserted_date,
    revision
)
SELECT
    ssl.shipment_line_key,
    ssl.shipment_key,
    ssl.shipment_line_no,
    ssl.shipment_sub_line_no,
    ssl.parent_shipment_line_key,
    ssl.order_header_key,
    ssl.order_release_key,
    ssl.order_line_key,
    ssl.order_no,
    ssl.release_no,
    ssl.prime_line_no,
    ssl.sub_line_no,
    ssl.item_id,
    ssl.product_class,
    ssl.uom,
    TRY_CAST(ssl.net_weight AS FLOAT),
    ssl.net_weight_uom,
    ssl.country_of_origin,
    ssl.fifo_no,
    TRY_TO_NUMBER(ssl.quantity),
    TRY_TO_NUMBER(ssl.over_ship_quantity),
    TRY_TO_NUMBER(ssl.original_quantity),
    TRY_TO_NUMBER(ssl.kit_qty),
    ssl.requested_tag_number,
    ssl.requested_serial_no,
    ssl.item_description,
    ssl.segment,
    ssl.segment_type,
    TRY_TO_NUMBER(ssl.shortage_qty),
    ssl.customer_po_no,
    ssl.customer_po_line_no,
    ssl.mark_for_key,
    ssl.buyer_mark_for_node_id,
    ssl.order_type,
    ssl.shipment_consol_group_id,
    ssl.ship_to_customer_id,
    ssl.kit_code,
    ssl.is_pickable,
    ssl.department_code,
    ssl.gift_flag,
    ssl.external_release_identifier,
    ssl.is_hazmat,
    ssl.return_shipping_label_level,
    ssl.level_of_service,
    ssl.pick_location,
    ssl.pick_location_seq,
    ssl.group_sequence_num,
    ssl.lockid,
    TRY_TO_TIMESTAMP(ssl.createts,'YYYYMMDDHHMISS') ,
    TRY_TO_TIMESTAMP(ssl.modifyts,'YYYYMMDDHHMISS') ,
    ssl.createuserid,
    ssl.modifyuserid,
    ssl.createprogid,
    ssl.modifyprogid,
    ssl.wave_no,
    TRY_TO_NUMBER(ssl.backroom_picked_qty),
    TRY_TO_NUMBER(ssl.customer_picked_qty),
    ssl.shortage_resolution_reason,
    ssl.cancel_reason,
    ssl.is_pack_complete,
    ssl.backroom_pick_complete,
    ssl.is_customer_pick_complete,
    ssl.staging_complete,
    TRY_TO_NUMBER(ssl.staged_qty),
    ssl.store_batch_key,
    ssl.batch_pick_priority,
    ssl.store_batch_location_key,
    CURRENT_TIMESTAMP,
    ord.revision
FROM TRANSFORMED.stg_ORDER_shipment_line ssl
INNER JOIN insertedShipmentLineRecords ord 
ON ord.shipment_line_key = ssl.shipment_line_key 
AND ord.shipment_key = ssl.shipment_key;

UPDATE RAW.raw_ORDER_shipment_line
SET 
    processing_status = 'Processed',
    processing_comment = '',
    processing_errortype = ''
FROM insertedShipmentLineRecords AS tosl
WHERE 
    tosl.shipment_key = RAW.raw_ORDER_shipment_line.shipment_key 
    AND tosl.shipment_line_key = RAW.raw_ORDER_shipment_line.shipment_line_key 
    AND tosl.order_header_key = RAW.raw_ORDER_shipment_line.order_header_key 
    AND tosl.txn_id = RAW.raw_ORDER_shipment_line.txn_id;

SELECT COUNT(*) INTO :processedRecordCount FROM insertedShipmentLineRecords;

SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM TRANSFORMED.stg_ORDER_shipment_line;

UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = 'Success'
WHERE
    file_name = 'YFS_SHIPMENT_LINE';

DROP TABLE IF EXISTS insertedShipmentLineRecords;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_SHIPMENT_LINE';
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	
	RETURN error_object;
END;