
CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_CUSTOMER_INFO_POPULATE("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 
DECLARE 
 error_object VARIANT;
 start_time_proc TIMESTAMP_NTZ(9);
 
BEGIN

start_time_proc := CURRENT_TIMESTAMP();

SYSTEM$LOG('TRACE',' USP_ORDER_CUSTOMER_INFO_POPULATE has been Started');
CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        CURRENT_TIMESTAMP(),
        NULL,
        'upsert started'
    );

create or replace temporary table analytics.CreateCustomerPersonInfoMatch
(
order_no varchar(200) not null,
order_header_key varchar(500) not null,
order_type varchar(100) not null,
entry_type varchar(100) not null,
ship_to_key varchar not null,
fk_sourceid int not null,
source varchar(100) null
);

insert into analytics.CreateCustomerPersonInfoMatch
(
order_no ,
order_header_key ,
order_type ,
entry_type ,
ship_to_key ,
fk_sourceid,
source
)
select 
distinct 
ord.order_no,
ord.order_header_key,
ord.order_type ,
ord.entry_type,
ord.ship_to_key ,
src.pk_sourceid,
case WHEN src.BrandId = 1
     then 'domestic'
	 else null
	 end
from raw.raw_order_header as ord
INNER JOIN  MASTER.entrytype_platform_map as pl on pl.entry_type = ord.ENTRY_TYPE and pl.Order_Type = ord.Order_Type
INNER JOIN MASTER.source_brand_platform_map AS src ON src.BrandCodeForWHM = analytics.fun_get_edw_brand_by_order_sellerorgcode(ord.SELLER_ORGANIZATION_CODE) AND src.PlatformName = nvl(pl.customer_platform_name,pl.platform_name)
       where  extn_customer_id is null   and  (order_name is null or order_name ='EXTEND_CANCEL') and pl.customer_source = 'Person Info';

insert into raw.raw_order_customer_person_info (
person_info_key	,
person_id	,
title	,
first_name	,
middle_name	,
last_name	,
suffix	,
department	,
company	,
job_title	,
address_line1	,
address_line2	,
address_line3	,
address_line4	,
address_line5	,
address_line6	,
city	,
state	,
zip_code	,
country	,
day_phone	,
evening_phone	,
mobile_phone	,
beeper	,
other_phone	,
day_fax_no	,
evening_fax_no	,
emailid	,
alternate_emailid	,
preferred_ship_address	,
http_url	,
use_count	,
verification_status	,
is_address_verified	,
latitude	,
longitude	,
tax_geo_code	,
error_txt	,
is_commercial_address	,
time_zone	,
lockid	,
createts	,
modifyts	,
createuserid	,
modifyuserid	,
createprogid	,
modifyprogid	,
address_id	,
short_zip_code	,
imported_date	,
txn_id	,
processing_status	,
processing_errortype	,
processing_comment	,
fk_sourceid,
source

)
select distinct

rpi.person_info_key	,
rpi.person_id	,
rpi.title	,
rpi.first_name	,
rpi.middle_name	,
rpi.last_name	,
rpi.suffix	,
rpi.department	,
rpi.company	,
rpi.job_title	,
rpi.address_line1	,
rpi.address_line2	,
rpi.address_line3	,
rpi.address_line4	,
rpi.address_line5	,
rpi.address_line6	,
rpi.city	,
rpi.state	,
rpi.zip_code	,
rpi.country	,
rpi.day_phone	,
rpi.evening_phone	,
rpi.mobile_phone	,
rpi.beeper	,
rpi.other_phone	,
rpi.day_fax_no	,
rpi.evening_fax_no	,
rpi.emailid	,
rpi.alternate_emailid	,
rpi.preferred_ship_address	,
rpi.http_url	,
rpi.use_count	,
rpi.verification_status	,
rpi.is_address_verified	,
rpi.latitude	,
rpi.longitude	,
rpi.tax_geo_code	,
rpi.error_txt	,
rpi.is_commercial_address	,
rpi.time_zone	,
rpi.lockid	,
rpi.createts	,
rpi.modifyts	,
rpi.createuserid	,
rpi.modifyuserid	,
rpi.createprogid	,
rpi.modifyprogid	,
rpi.address_id	,
rpi.short_zip_code	,
current_date,
'call-back-load-from-person-info-for-3rd-party'	,
'Pending'	,
null	,
null	,
tmp.fk_sourceid,
tmp.source

from raw.raw_order_person_info as rpi
INNER JOIN analytics.CreateCustomerPersonInfoMatch as tmp on tmp.ship_to_key = rpi.person_info_key;

insert into raw.raw_order_customer_person_info (
person_info_key	,
person_id	,
title	,
first_name	,
middle_name	,
last_name	,
suffix	,
department	,
company	,
job_title	,
address_line1	,
address_line2	,
address_line3	,
address_line4	,
address_line5	,
address_line6	,
city	,
state	,
zip_code	,
country	,
day_phone	,
evening_phone	,
mobile_phone	,
beeper	,
other_phone	,
day_fax_no	,
evening_fax_no	,
emailid	,
alternate_emailid	,
preferred_ship_address	,
http_url	,
use_count	,
verification_status	,
is_address_verified	,
latitude	,
longitude	,
tax_geo_code	,
error_txt	,
is_commercial_address	,
time_zone	,
lockid	,
createts	,
modifyts	,
createuserid	,
modifyuserid	,
createprogid	,
modifyprogid	,
address_id	,
short_zip_code	,
imported_date	,
txn_id	,
processing_status	,
processing_errortype	,
processing_comment	,
fk_sourceid,
source

)
select distinct

rpi.person_info_key	,
rpi.person_id	,
rpi.title	,
rpi.first_name	,
rpi.middle_name	,
rpi.last_name	,
rpi.suffix	,
rpi.department	,
rpi.company	,
rpi.job_title	,
rpi.address_line1	,
rpi.address_line2	,
rpi.address_line3	,
rpi.address_line4	,
rpi.address_line5	,
rpi.address_line6	,
rpi.city	,
rpi.state	,
rpi.zip_code	,
rpi.country	,
rpi.day_phone	,
rpi.evening_phone	,
rpi.mobile_phone	,
rpi.beeper	,
rpi.other_phone	,
rpi.day_fax_no	,
rpi.evening_fax_no	,
rpi.emailid	,
rpi.alternate_emailid	,
rpi.preferred_ship_address	,
rpi.http_url	,
rpi.use_count	,
rpi.verification_status	,
rpi.is_address_verified	,
rpi.latitude	,
rpi.longitude	,
rpi.tax_geo_code	,
rpi.error_txt	,
rpi.is_commercial_address	,
rpi.time_zone	,
rpi.lockid	,
rpi.createts	,
rpi.modifyts	,
rpi.createuserid	,
rpi.modifyuserid	,
rpi.createprogid	,
rpi.modifyprogid	,
rpi.address_id	,
rpi.short_zip_code	,
current_date,
'call-back-load-from-person-info-for-3rd-party'	,
'Pending'	,
null	,
null	,
tmp.fk_sourceid,
tmp.source

from archive.arc_raw_order_person_info as rpi
INNER JOIN analytics.CreateCustomerPersonInfoMatch as tmp on tmp.ship_to_key = rpi.person_info_key;

drop table analytics.CreateCustomerPersonInfoMatch;

COMMIT;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'COMPLETED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        'upsert completed successfully'
    );
    SYSTEM$LOG('TRACE',' USP_ORDER_CUSTOMER_INFO_POPULATE has been Completed');
  RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;

    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);
    
        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );
    SYSTEM$LOG('ERROR',' USP_BIZ_VALIDATION_ORDER_LINE has Failed');
            -- Return error message
    RETURN OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
END;