

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_CONTAINER_DETAILS_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

UPDATE analytics.log_files_import_status
SET processed = :processedRecordCount,
    raw_table = 'raw_ORDER_container_details'
WHERE file_name = 'YFS_CONTAINER_DETAILS';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

CREATE OR REPLACE TEMPORARY TABLE insertedContainerDetailsRecords (
    container_details_key STRING,
    order_release_key STRING,
    order_release_status_key STRING,
    shipment_container_key STRING,
    order_line_key STRING,
    order_header_key STRING,
    shipment_key STRING,
    shipment_line_key STRING,
    country_of_origin STRING,
    item_id STRING,
    uom STRING,
    product_class STRING,
    quantity NUMBER,
    quantity_placed NUMBER,
    enterprise_key STRING,
    orig_order_line_schedule_key STRING,
    fifo_no STRING,
    lockid STRING,
    createts TIMESTAMP_NTZ(9),
    modifyts TIMESTAMP_NTZ(9),
    createuserid STRING,
    modifyuserid STRING,
    createprogid STRING,
    modifyprogid STRING,
    extn_upc_item_id STRING,
    imported_date TIMESTAMP_NTZ(9),
    txn_id STRING,
    inserted_date TIMESTAMP_NTZ(9),
    modified_date TIMESTAMP_NTZ(9),
    revision INT
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO  ANALYTICS.txn_order_container_details tcd
USING (
  SELECT DISTINCT 
    container_details_key,
    order_release_key,
    order_release_status_key,
    shipment_container_key,
    order_line_key,
    order_header_key,
    shipment_key,
    shipment_line_key,
    country_of_origin,
    item_id,
    uom,
    product_class,
    TRY_TO_NUMBER(quantity) AS quantity,
    TRY_TO_NUMBER(quantity_placed) AS quantity_placed,
    enterprise_key,
    orig_order_line_schedule_key,
    fifo_no,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    extn_upc_item_id,
    txn_id
  FROM TRANSFORMED.stg_ORDER_container_details
) scd
ON (
  tcd.container_details_key = scd.container_details_key AND
  tcd.shipment_container_key = scd.shipment_container_key AND
  tcd.shipment_key = scd.shipment_key AND
  tcd.shipment_line_key = scd.shipment_line_key AND
  tcd.order_header_key = scd.order_header_key AND
  tcd.order_line_key = scd.order_line_key
)
WHEN MATCHED THEN
  UPDATE 
    SET tcd.container_details_key  = scd.container_details_key    
   ,tcd.order_release_key  = scd.order_release_key    
   ,tcd.order_release_status_key  = scd.order_release_status_key    
   ,tcd.shipment_container_key  = scd.shipment_container_key    
   ,tcd.order_line_key  = scd.order_line_key    
   ,tcd.order_header_key  = scd.order_header_key    
   ,tcd.shipment_key  = scd.shipment_key    
   ,tcd.shipment_line_key  = scd.shipment_line_key    
   ,tcd.country_of_origin  = scd.country_of_origin    
   ,tcd.item_id  = scd.item_id    
   ,tcd.uom  = scd.uom    
   ,tcd.product_class  = scd.product_class    
   ,tcd.quantity  = scd.quantity    
   ,tcd.quantity_placed  = scd.quantity_placed    
   ,tcd.enterprise_key  = scd.enterprise_key    
   ,tcd.orig_order_line_schedule_key  = scd.orig_order_line_schedule_key    
   ,tcd.fifo_no  = scd.fifo_no    
   ,tcd.lockid  = scd.lockid    
   ,tcd.createts  = TRY_TO_TIMESTAMP(scd.createts,'YYYYMMDDHHMISS')
   ,tcd.modifyts  = TRY_TO_TIMESTAMP(scd.modifyts,'YYYYMMDDHHMISS')    
   ,tcd.createuserid  = scd.createuserid    
   ,tcd.modifyuserid  = scd.modifyuserid    
   ,tcd.createprogid  = scd.createprogid    
   ,tcd.modifyprogid  = scd.modifyprogid    
   ,tcd.extn_upc_item_id = scd.extn_upc_item_id,  
    tcd.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
  INSERT (
    container_details_key,
    order_release_key,
    order_release_status_key,
    shipment_container_key,
    order_line_key,
    order_header_key,
    shipment_key,
    shipment_line_key,
    country_of_origin,
    item_id,
    uom,
    product_class,
    quantity,
    quantity_placed,
    enterprise_key,
    orig_order_line_schedule_key,
    fifo_no,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    extn_upc_item_id,
    inserted_date
  )
  VALUES (
    scd.container_details_key,
    scd.order_release_key,
    scd.order_release_status_key,
    scd.shipment_container_key,
    scd.order_line_key,
    scd.order_header_key,
    scd.shipment_key,
    scd.shipment_line_key,
    scd.country_of_origin,
    scd.item_id,
    scd.uom,
    scd.product_class,
    scd.quantity,
    scd.quantity_placed,
    scd.enterprise_key,
    scd.orig_order_line_schedule_key,
    scd.fifo_no,
    scd.lockid,
    TRY_TO_TIMESTAMP(scd.createts,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(scd.modifyts,'YYYYMMDDHHMISS'),
    scd.createuserid,
    scd.modifyuserid,
    scd.createprogid,
    scd.modifyprogid,
    scd.extn_upc_item_id,
    CURRENT_TIMESTAMP()
);

INSERT INTO insertedContainerDetailsRecords (
    container_details_key,
    order_release_key,
    order_release_status_key,
    shipment_container_key,
    order_line_key,
    order_header_key,
    shipment_key,
    shipment_line_key,
    country_of_origin,
    item_id,
    uom,
    product_class,
    quantity,
    quantity_placed,
    enterprise_key,
    orig_order_line_schedule_key,
    fifo_no,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    extn_upc_item_id,
    imported_date,
    txn_id,
    inserted_date,
    modified_date,
    revision
)
SELECT DISTINCT 
    tcd.container_details_key,
    tcd.order_release_key,
    tcd.order_release_status_key,
    tcd.shipment_container_key,
    tcd.order_line_key,
    tcd.order_header_key,
    tcd.shipment_key,
    tcd.shipment_line_key,
    tcd.country_of_origin,
    tcd.item_id,
    tcd.uom,
    tcd.product_class,
    tcd.quantity,
    tcd.quantity_placed,
    tcd.enterprise_key,
    tcd.orig_order_line_schedule_key,
    tcd.fifo_no,
    tcd.lockid,
    TRY_TO_TIMESTAMP(scd.createts,'YYYYMMDDHHMISS') AS createts,
    TRY_TO_TIMESTAMP(scd.modifyts,'YYYYMMDDHHMISS') AS modifyts,
    tcd.createuserid,
    tcd.modifyuserid,
    tcd.createprogid,
    tcd.modifyprogid,
    tcd.extn_upc_item_id,
    scd.imported_date,
    scd.txn_id,
    tcd.inserted_date,
    tcd.modified_date,
    1 as revision
FROM ANALYTICS.txn_order_container_details tcd
    INNER JOIN TRANSFORMED.stg_ORDER_container_details scd
        on   tcd.container_details_key = scd.container_details_key AND
      tcd.shipment_container_key = scd.shipment_container_key AND
      tcd.shipment_key = scd.shipment_key AND
      tcd.shipment_line_key = scd.shipment_line_key AND
      tcd.order_header_key = scd.order_header_key AND
      tcd.order_line_key = scd.order_line_key
WHERE tcd.inserted_date >= :processedDate or tcd.modified_date >= :processedDate
;

MERGE INTO insertedContainerDetailsRecords AS ttd
USING (
    SELECT
        MAX(aot.revision) AS revision,
        aot.container_details_key,
        aot.shipment_key,
        aot.shipment_line_key,
        aot.shipment_container_key,
        aot.order_header_key,
        aot.order_line_key
    FROM ANALYTICS.audit_order_container_details AS aot
    GROUP BY
        aot.container_details_key,
        aot.shipment_key,
        aot.shipment_line_key,
        aot.shipment_container_key,
        aot.order_header_key,
        aot.order_line_key
) AS aot
ON ttd.container_details_key = aot.container_details_key
AND ttd.shipment_key = aot.shipment_key
AND ttd.shipment_line_key = aot.shipment_line_key
AND ttd.shipment_container_key = aot.shipment_container_key
AND ttd.order_header_key = aot.order_header_key
AND ttd.order_line_key = aot.order_line_key
WHEN MATCHED THEN
UPDATE SET ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS int);

INSERT INTO  ANALYTICS.audit_order_container_details (
  container_details_key,
  order_release_key,
  order_release_status_key,
  shipment_container_key,
  order_line_key,
  order_header_key,
  shipment_key,
  shipment_line_key,
  country_of_origin,
  item_id,
  uom,
  product_class,
  quantity,
  quantity_placed,
  enterprise_key,
  orig_order_line_schedule_key,
  fifo_no,
  lockid,
  createts,
  modifyts,
  createuserid,
  modifyuserid,
  createprogid,
  modifyprogid,
  extn_upc_item_id,
  inserted_date,
  revision
)
SELECT
  scd.container_details_key,
  scd.order_release_key,
  scd.order_release_status_key,
  scd.shipment_container_key,
  scd.order_line_key,
  scd.order_header_key,
  scd.shipment_key,
  scd.shipment_line_key,
  scd.country_of_origin,
  scd.item_id,
  scd.uom,
  scd.product_class,
  scd.quantity,
  scd.quantity_placed,
  scd.enterprise_key,
  scd.orig_order_line_schedule_key,
  scd.fifo_no,
  scd.lockid,
  scd.createts,
  scd.modifyts,
  scd.createuserid,
  scd.modifyuserid,
  scd.createprogid,
  scd.modifyprogid,
  scd.extn_upc_item_id,
  CURRENT_TIMESTAMP, -- GETDATE() equivalent in Snowflake
  scd.revision
FROM insertedContainerDetailsRecords scd;

UPDATE RAW.raw_ORDER_container_details
SET 
    processing_status = 'Processed',
    processing_comment = '',
    processing_errortype = ''
WHERE EXISTS (
    SELECT 1
    FROM insertedContainerDetailsRecords tocd
    WHERE 
        tocd.container_details_key = RAW.raw_ORDER_container_details.container_details_key AND
        tocd.shipment_key = RAW.raw_ORDER_container_details.shipment_key AND
        tocd.shipment_line_key = RAW.raw_ORDER_container_details.shipment_line_key AND
        tocd.shipment_container_key = RAW.raw_ORDER_container_details.shipment_container_key AND
        tocd.order_header_key = RAW.raw_ORDER_container_details.order_header_key AND
        tocd.order_line_key = RAW.raw_ORDER_container_details.order_line_key AND
        tocd.modifyts = RAW.raw_ORDER_container_details.modifyts
);


SELECT COUNT(*)
INTO :processedRecordCount
FROM insertedContainerDetailsRecords;

UPDATE ANALYTICS.log_files_import_status
SET 
  processed = :processedRecordCount,
  status = 'Success'
WHERE 
  file_name = 'YFS_CONTAINER_DETAILS';

DROP TABLE IF EXISTS insertedContainerDetailsRecords;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

COMMIT;
RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_CONTAINER_DETAILS';
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	
	RETURN error_object;
END;