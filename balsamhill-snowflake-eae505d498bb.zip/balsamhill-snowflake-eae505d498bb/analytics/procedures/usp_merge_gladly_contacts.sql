USE DATABASE DEV;
USE SCHEMA analytics;

CREATE OR REPLACE PROCEDURE analytics.usp_merge_gladly_contacts(pipeline_name VARCHAR DEFAULT 'gladly_contacts')
    RETURNS STRING
    LANGUAGE SQL
AS
DECLARE
pipeline_stage_name VARCHAR := 'merge';
    start_time          TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    completed_message   VARCHAR;
    error_object        VARIANT;
BEGIN
    SYSTEM$LOG('TRACE', 'SP STARTED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'started',
            :start_time,
            NULL,
            :pipeline_stage_name || ' ' || 'started');

BEGIN
MERGE INTO analytics.txn_gladly_contacts AS target
    USING (
        SELECT *
        FROM transformed.stage_gladly_contacts
    ) AS source
    ON source.contact_id = target.contact_id
    WHEN MATCHED AND (
        source.timezone_filter <> target.timezone_filter
            OR source.channel_filter <> target.channel_filter
            OR source.inboxes_filter <> target.inboxes_filter
            OR source.queued_at <> target.queued_at
            OR source.customer_id <> target.customer_id
            OR source.conversation_id <> target.conversation_id
            OR source.conversation_link <> target.conversation_link
            OR source.channel <> target.channel
            OR source.direction <> target.direction
            OR source.contact_initiator <> target.contact_initiator
            OR source.entry_point <> target.entry_point
            OR source.final_ivr_selection <> target.final_ivr_selection
            OR source.fulfilled_type <> target.fulfilled_type
            OR source.status <> target.status
            OR source.inbox_when_queued <> target.inbox_when_queued
            OR source.inbox_when_ended <> target.inbox_when_ended
            OR source.agent_when_ended <> target.agent_when_ended
            OR source.offered_at <> target.offered_at
            OR source.accepted_at <> target.accepted_at
            OR source.fulfilled_at <> target.fulfilled_at
            OR source.due_at <> target.due_at
            OR source.ended_at <> target.ended_at
            OR source.answered_at_outbound <> target.answered_at_outbound
            OR source.sla_target_sec <> target.sla_target_sec
            OR source.queued_to_fulfilled_sec <> target.queued_to_fulfilled_sec
            OR source.queued_to_fulfilled_within_business_hours_sec <> target.queued_to_fulfilled_within_business_hours_sec
            OR source.queued_to_accepted_sec <> target.queued_to_accepted_sec
            OR source.queued_to_ended_sec <> target.queued_to_ended_sec
            OR source.accepted_to_fulfilled_sec <> target.accepted_to_fulfilled_sec
            OR source.seconds_within_or_over_sla <> target.seconds_within_or_over_sla
            OR source.fulfilled_to_ended_sec <> target.fulfilled_to_ended_sec
            OR source.fulfilled_by_contact_id <> target.fulfilled_by_contact_id
            OR source.contact_handle_time_sec <> target.contact_handle_time_sec
            OR source.after_contact_time_sec <> target.after_contact_time_sec
            OR source.total_contact_handle_time_sec <> target.total_contact_handle_time_sec
            OR source.total_talk_time <> target.total_talk_time
            OR source.hold_time_total_sec <> target.hold_time_total_sec
            OR source.hold_time_manual_sec <> target.hold_time_manual_sec
            OR source.hold_time_warm_transfer_sec <> target.hold_time_warm_transfer_sec
            OR source.hold_time_cold_transfer_sec <> target.hold_time_cold_transfer_sec
            OR source.hold_time_conference_sec <> target.hold_time_conference_sec
            OR source.messages_total <> target.messages_total
            OR source.messages_from_customer <> target.messages_from_customer
            OR source.messages_from_agent <> target.messages_from_agent
            OR source.messages_from_rules <> target.messages_from_rules
            OR source.messages_from_api <> target.messages_from_api
            OR source.avg_agent_reply_time_sec <> target.avg_agent_reply_time_sec
            OR source.avg_customer_reply_time_sec <> target.avg_customer_reply_time_sec
            OR source.times_offered <> target.times_offered
            OR source.times_accepted <> target.times_accepted
            OR source.times_missed <> target.times_missed
            OR source.times_declined <> target.times_declined
            OR source.times_transferred <> target.times_transferred
            OR source.times_on_hold_total <> target.times_on_hold_total
            OR source.times_on_hold_manual <> target.times_on_hold_manual
            OR source.times_on_hold_warm_transfer <> target.times_on_hold_warm_transfer
            OR source.times_on_hold_cold_transfer <> target.times_on_hold_cold_transfer
            OR source.times_on_hold_conference <> target.times_on_hold_conference
            OR source.payment_requests_completed <> target.payment_requests_completed
            OR source.payment_requests_declined <> target.payment_requests_declined
            OR source.payment_amount_completed_usd <> target.payment_amount_completed_usd
            OR source.payment_amount_declined_usd <> target.payment_amount_declined_usd
            OR source.start_date <> target.start_date
            OR source.day_of_week <> target.day_of_week
            OR source.week_of <> target.week_of
            OR source.month <> target.month
            OR source.geo <> target.geo
            OR source.start_time <> target.start_time
            OR source.start_interval <> target.start_interval
            OR source.wait_time_sec <> target.wait_time_sec
            OR source.calls_offered <> target.calls_offered
            OR source.calls_handled <> target.calls_handled
            OR source.calls_missed <> target.calls_missed
            OR source.calls_abandoned <> target.calls_abandoned
            OR source.short_abandons <> target.short_abandons
            OR source.in_sla <> target.in_sla
            OR source.time_to_abandon <> target.time_to_abandon
            OR source.full_duration_calc <> target.full_duration_calc
            OR source.talk_plus_hold_time_sec <> target.talk_plus_hold_time_sec
            OR source.year <> target.year)
        THEN
        UPDATE SET
            timezone_filter = source.timezone_filter,
            channel_filter = source.channel_filter,
            inboxes_filter = source.inboxes_filter,
            queued_at = source.queued_at,
            customer_id = source.customer_id,
            conversation_id = source.conversation_id,
            conversation_link = source.conversation_link,
            channel = source.channel,
            direction = source.direction,
            contact_initiator = source.contact_initiator,
            entry_point = source.entry_point,
            final_ivr_selection = source.final_ivr_selection,
            fulfilled_type = source.fulfilled_type,
            status = source.status,
            inbox_when_queued = source.inbox_when_queued,
            inbox_when_ended = source.inbox_when_ended,
            agent_when_ended = source.agent_when_ended,
            offered_at = source.offered_at,
            accepted_at = source.accepted_at,
            fulfilled_at = source.fulfilled_at,
            due_at = source.due_at,
            ended_at = source.ended_at,
            answered_at_outbound = source.answered_at_outbound,
            sla_target_sec = source.sla_target_sec,
            queued_to_fulfilled_sec = source.queued_to_fulfilled_sec,
            queued_to_fulfilled_within_business_hours_sec = source.queued_to_fulfilled_within_business_hours_sec,
            queued_to_accepted_sec = source.queued_to_accepted_sec,
            queued_to_ended_sec = source.queued_to_ended_sec,
            accepted_to_fulfilled_sec = source.accepted_to_fulfilled_sec,
            seconds_within_or_over_sla = source.seconds_within_or_over_sla,
            fulfilled_to_ended_sec = source.fulfilled_to_ended_sec,
            fulfilled_by_contact_id = source.fulfilled_by_contact_id,
            contact_handle_time_sec = source.contact_handle_time_sec,
            after_contact_time_sec = source.after_contact_time_sec,
            total_contact_handle_time_sec = source.total_contact_handle_time_sec,
            total_talk_time = source.total_talk_time,
            hold_time_total_sec = source.hold_time_total_sec,
            hold_time_manual_sec = source.hold_time_manual_sec,
            hold_time_warm_transfer_sec = source.hold_time_warm_transfer_sec,
            hold_time_cold_transfer_sec = source.hold_time_cold_transfer_sec,
            hold_time_conference_sec = source.hold_time_conference_sec,
            messages_total = source.messages_total,
            messages_from_customer = source.messages_from_customer,
            messages_from_agent = source.messages_from_agent,
            messages_from_rules = source.messages_from_rules,
            messages_from_api = source.messages_from_api,
            avg_agent_reply_time_sec = source.avg_agent_reply_time_sec,
            avg_customer_reply_time_sec = source.avg_customer_reply_time_sec,
            times_offered = source.times_offered,
            times_accepted = source.times_accepted,
            times_missed = source.times_missed,
            times_declined = source.times_declined,
            times_transferred = source.times_transferred,
            times_on_hold_total = source.times_on_hold_total,
            times_on_hold_manual = source.times_on_hold_manual,
            times_on_hold_warm_transfer = source.times_on_hold_warm_transfer,
            times_on_hold_cold_transfer = source.times_on_hold_cold_transfer,
            times_on_hold_conference = source.times_on_hold_conference,
            payment_requests_completed = source.payment_requests_completed,
            payment_requests_declined = source.payment_requests_declined,
            payment_amount_completed_usd = source.payment_amount_completed_usd,
            payment_amount_declined_usd = source.payment_amount_declined_usd,
            start_date = source.start_date,
            day_of_week = source.day_of_week,
            week_of = source.week_of,
            month = source.month,
            geo = source.geo,
            start_time = source.start_time,
            start_interval = source.start_interval,
            wait_time_sec = source.wait_time_sec,
            calls_offered = source.calls_offered,
            calls_handled = source.calls_handled,
            calls_missed = source.calls_missed,
            calls_abandoned = source.calls_abandoned,
            short_abandons = source.short_abandons,
            in_sla = source.in_sla,
            time_to_abandon = source.time_to_abandon,
            full_duration_calc = source.full_duration_calc,
            talk_plus_hold_time_sec = source.talk_plus_hold_time_sec,
            year = source.year,
            updated_at = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
                timezone_filter,
                channel_filter,
                inboxes_filter,
                queued_at,
                customer_id,
                conversation_id,
                contact_id,
                conversation_link,
                channel,
                direction,
                contact_initiator,
                entry_point,
                final_ivr_selection,
                fulfilled_type,
                status,
                inbox_when_queued,
                inbox_when_ended,
                agent_when_ended,
                offered_at,
                accepted_at,
                fulfilled_at,
                due_at,
                ended_at,
                answered_at_outbound,
                sla_target_sec,
                queued_to_fulfilled_sec,
                queued_to_fulfilled_within_business_hours_sec,
                queued_to_accepted_sec,
                queued_to_ended_sec,
                accepted_to_fulfilled_sec,
                seconds_within_or_over_sla,
                fulfilled_to_ended_sec,
                fulfilled_by_contact_id,
                contact_handle_time_sec,
                after_contact_time_sec,
                total_contact_handle_time_sec,
                total_talk_time,
                hold_time_total_sec,
                hold_time_manual_sec,
                hold_time_warm_transfer_sec,
                hold_time_cold_transfer_sec,
                hold_time_conference_sec,
                messages_total,
                messages_from_customer,
                messages_from_agent,
                messages_from_rules,
                messages_from_api,
                avg_agent_reply_time_sec,
                avg_customer_reply_time_sec,
                times_offered,
                times_accepted,
                times_missed,
                times_declined,
                times_transferred,
                times_on_hold_total,
                times_on_hold_manual,
                times_on_hold_warm_transfer,
                times_on_hold_cold_transfer,
                times_on_hold_conference,
                payment_requests_completed,
                payment_requests_declined,
                payment_amount_completed_usd,
                payment_amount_declined_usd,
                start_date,
                day_of_week,
                week_of,
                month,
                geo,
                start_time,
                start_interval,
                wait_time_sec,
                calls_offered,
                calls_handled,
                calls_missed,
                calls_abandoned,
                short_abandons,
                in_sla,
                time_to_abandon,
                full_duration_calc,
                talk_plus_hold_time_sec,
                year
            )
            VALUES (
                       source.timezone_filter,
                       source.channel_filter,
                       source.inboxes_filter,
                       source.queued_at,
                       source.customer_id,
                       source.conversation_id,
                       source.contact_id,
                       source.conversation_link,
                       source.channel,
                       source.direction,
                       source.contact_initiator,
                       source.entry_point,
                       source.final_ivr_selection,
                       source.fulfilled_type,
                       source.status,
                       source.inbox_when_queued,
                       source.inbox_when_ended,
                       source.agent_when_ended,
                       source.offered_at,
                       source.accepted_at,
                       source.fulfilled_at,
                       source.due_at,
                       source.ended_at,
                       source.answered_at_outbound,
                       source.sla_target_sec,
                       source.queued_to_fulfilled_sec,
                       source.queued_to_fulfilled_within_business_hours_sec,
                       source.queued_to_accepted_sec,
                       source.queued_to_ended_sec,
                       source.accepted_to_fulfilled_sec,
                       source.seconds_within_or_over_sla,
                       source.fulfilled_to_ended_sec,
                       source.fulfilled_by_contact_id,
                       source.contact_handle_time_sec,
                       source.after_contact_time_sec,
                       source.total_contact_handle_time_sec,
                       source.total_talk_time,
                       source.hold_time_total_sec,
                       source.hold_time_manual_sec,
                       source.hold_time_warm_transfer_sec,
                       source.hold_time_cold_transfer_sec,
                       source.hold_time_conference_sec,
                       source.messages_total,
                       source.messages_from_customer,
                       source.messages_from_agent,
                       source.messages_from_rules,
                       source.messages_from_api,
                       source.avg_agent_reply_time_sec,
                       source.avg_customer_reply_time_sec,
                       source.times_offered,
                       source.times_accepted,
                       source.times_missed,
                       source.times_declined,
                       source.times_transferred,
                       source.times_on_hold_total,
                       source.times_on_hold_manual,
                       source.times_on_hold_warm_transfer,
                       source.times_on_hold_cold_transfer,
                       source.times_on_hold_conference,
                       source.payment_requests_completed,
                       source.payment_requests_declined,
                       source.payment_amount_completed_usd,
                       source.payment_amount_declined_usd,
                       source.start_date,
                       source.day_of_week,
                       source.week_of,
                       source.month,
                       source.geo,
                       source.start_time,
                       source.start_interval,
                       source.wait_time_sec,
                       source.calls_offered,
                       source.calls_handled,
                       source.calls_missed,
                       source.calls_abandoned,
                       source.short_abandons,
                       source.in_sla,
                       source.time_to_abandon,
                       source.full_duration_calc,
                       source.talk_plus_hold_time_sec,
                       source.year
                   );

LET staged_events_count VARCHAR := (
            SELECT COUNT(1)
            FROM analytics.txn_gladly_contacts
            WHERE updated_at >= :start_time
        );

        completed_message := 'Merging completed successfully. ' || 'Merged records: ' || :staged_events_count;

COMMIT;
EXCEPTION
        WHEN statement_error THEN
            ROLLBACK;

            SYSTEM$LOG('ERROR', 'SP FAILED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

            error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                             'SQLCODE', sqlcode,
                                             'SQLERRM', sqlerrm,
                                             'SQLSTATE', sqlstate);

CALL transformed.insert_into_log_pipeline_tasks_execution_details(
                    :pipeline_name,
                    :pipeline_stage_name,
                    'failed',
                    :start_time,
                    CURRENT_TIMESTAMP(),
                    TO_JSON(:error_object));

RETURN error_object;
END;

CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'completed',
            :start_time,
            CURRENT_TIMESTAMP(),
            :completed_message);

SYSTEM$LOG('TRACE', 'SP COMPLETED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

RETURN :start_time || ' - ' || :completed_message;
END;

ALTER PROCEDURE analytics.usp_merge_gladly_contacts(VARCHAR)
    SET LOG_LEVEL = TRACE, TRACE_LEVEL = ALWAYS;