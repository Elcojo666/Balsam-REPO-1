
CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_ADDRESS_UPSERT("PIPELINE_NAME" VARCHAR(16777216)) COPY GRANTS
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    shipAddressType SMALLINT DEFAULT 0;
    billAddressType SMALLINT DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 
start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status
SET 
    processed = :processedRecordCount
WHERE file_name = 'YFS_PERSON_INFO';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

SELECT pk_address_typeid 
INTO :shipAddressType
FROM MASTER.DIM_ADDRESS_TYPE
WHERE address_type_name = 'Shipping';

SELECT pk_address_typeid 
INTO :billAddressType
FROM MASTER.DIM_ADDRESS_TYPE
WHERE address_type_name = 'Billing';

processedDate := CURRENT_TIMESTAMP();  

CREATE OR REPLACE TEMPORARY TABLE temp_audit_address (
    first_name STRING(255), 
    last_name STRING(100), 
    company_name STRING(100), 
    phone_number STRING(255), 
    address1 STRING(255), 
    address2 STRING(255), 
    city STRING(255), 
    state STRING(255), 
    country STRING(255), 
    postal_code STRING(255), 
    fk_address_typeid SMALLINT NOT NULL, 
    inserted_date TIMESTAMP_NTZ NOT NULL, 
    created_by INT, 
    modified_date TIMESTAMP_NTZ, 
    pk_addressid BIGINT NOT NULL, 
    Revision INT, 
    ext_address_id STRING(510), 
    txn_id STRING
);

MERGE INTO   ANALYTICS.txn_address AS ta
USING (
    SELECT  
        person_info_key,  
        first_name,  
        middle_name,  
        last_name,  
        company,  
        address_line1,  
        address_line2,  
        address_line3,  
        address_line4,  
        address_line5,  
        address_line6,  
        city,  
        state,  
        zip_code,  
        country,  
        day_phone,  
        evening_phone,  
        mobile_phone,  
        other_phone,  
        txn_id  
    FROM  
        TRANSFORMED.stg_order_person_info
) AS src
ON src.person_info_key = ta.ext_address_id
AND ta.fk_address_typeid = :shipAddressType
WHEN NOT MATCHED THEN
INSERT
(
    ext_address_id,  
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    address3,  
    address4,  
    address5,  
    address6,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date
)
VALUES
(
    src.person_info_key,  
    src.first_name,  
    TRIM(CONCAT(coalesce(src.middle_name,''), ' ', src.last_name)),  
    src.company,  
    COALESCE(src.mobile_phone, src.other_phone),  
    src.address_line1,  
    src.address_line2,  
    src.address_line3,  
    src.address_line4,  
    src.address_line5,  
    src.address_line6,  
    src.city,  
    src.state,  
    src.country,  
    src.zip_code,  
    :shipAddressType,  
    CURRENT_TIMESTAMP(),  
    CURRENT_TIMESTAMP()
)
WHEN MATCHED THEN
UPDATE SET
    ta.first_name = src.first_name,  
    ta.last_name = TRIM(CONCAT(coalesce(src.middle_name,''), ' ', src.last_name)),  
    ta.company_name = src.company,  
    ta.phone_number = COALESCE(src.mobile_phone, src.other_phone),  
    ta.address1 = src.address_line1,  
    ta.address2 = src.address_line2,  
    ta.address3 = src.address_line3,  
    ta.address4 = src.address_line4,  
    ta.address5 = src.address_line5,  
    ta.address6 = src.address_line6,  
    ta.city = src.city,  
    ta.state = src.state,  
    ta.country = src.country,  
    ta.postal_code = src.zip_code,  
    ta.modified_date = CURRENT_TIMESTAMP();

INSERT INTO temp_audit_address
(
    first_name,
    last_name,
    company_name,
    phone_number,
    address1,
    address2,
    city,
    state,
    country,
    postal_code,
    fk_address_typeid,
    inserted_date,
    modified_date,
    pk_addressid,
    Revision,
    ext_address_id,
    txn_id
)
SELECT
    ta.first_name,
    ta.last_name,
    ta.company_name,
    ta.phone_number,
    ta.address1,
    ta.address2,
    ta.city,
    ta.state,
    ta.country,
    ta.postal_code,
    ta.fk_address_typeid,
    ta.inserted_date,
    ta.modified_date,
    ta.pk_addressid,
    1 AS Revision,
    ta.ext_address_id,
    src.txn_id
FROM ANALYTICS.txn_address ta
    INNER JOIN TRANSFORMED.stg_order_person_info src 
        ON src.person_info_key = ta.ext_address_id
            AND ta.fk_address_typeid = :shipAddressType
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;

-- UPDATE 
--     temp_audit_address
-- SET 
--     Revision = CAST((aot.revision + 1) AS int)
-- FROM 
--     temp_audit_address AS ttd
-- INNER JOIN 
--     (
--         SELECT 
--             MAX(aot.revision) AS revision, 
--             aot.pk_addressid, 
--             aot.fk_address_typeid
--         FROM 
--             ANALYTICS.AUDIT_ADDRESS AS aot
--         INNER JOIN 
--             temP_audit_address AS ttd ON ttd.pk_addressid = aot.pk_addressid 
--             AND ttd.fk_address_typeid = aot.fk_address_typeid
--         GROUP BY 
--             aot.pk_addressid, 
--             aot.fk_address_typeid
--     ) AS aot ON ttd.pk_addressid = aot.pk_addressid 
--     AND ttd.fk_address_typeid = aot.fk_address_typeid;

CREATE OR REPLACE TEMPORARY TABLE temp_max_revisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.pk_addressid,
    aot.fk_address_typeid
FROM
    ANALYTICS.AUDIT_ADDRESS AS aot
GROUP BY
    aot.pk_addressid, 
    aot.fk_address_typeid;

UPDATE temp_audit_address AS ttd
SET
    ttd.revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM
    temp_max_revisions AS aot
WHERE
    ttd.pk_addressid = aot.pk_addressid AND
    ttd.fk_address_typeid = aot.fk_address_typeid ;

DROP TABLE IF EXISTS temp_max_revisions;

INSERT INTO  ANALYTICS.audit_address (
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date,  
    pk_addressid,  
    Revision,
    ext_address_id  
)
SELECT 
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date,  
    pk_addressid,  
    Revision,
    ext_address_id
FROM temp_audit_address;

TRUNCATE TABLE IF EXISTS temp_audit_address;

MERGE INTO  ANALYTICS.txn_address AS ta
USING (
    SELECT  
        person_info_key,  
        first_name,  
        middle_name,  
        last_name,  
        company,  
        address_line1,  
        address_line2,  
        address_line3,  
        address_line4,  
        address_line5,  
        address_line6,  
        city,  
        state,  
        zip_code,  
        country,  
        day_phone,  
        evening_phone,  
        mobile_phone,  
        other_phone,  
        txn_id  
    FROM  
        TRANSFORMED.stg_order_person_info
) AS src
ON src.person_info_key = ta.ext_address_id
AND ta.fk_address_typeid = :billAddressType
WHEN NOT MATCHED THEN
INSERT
(
    ext_address_id,  
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    address3,  
    address4,  
    address5,  
    address6,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date
)
VALUES
(
    src.person_info_key,  
    src.first_name,  
    TRIM(CONCAT(coalesce(src.middle_name,''), ' ', src.last_name)),  
    src.company,  
    COALESCE(src.mobile_phone, src.other_phone),  
    src.address_line1,  
    src.address_line2,  
    src.address_line3,  
    src.address_line4,  
    src.address_line5,  
    src.address_line6,  
    src.city,  
    src.state,  
    src.country,  
    src.zip_code,  
    :billAddressType,  
    CURRENT_TIMESTAMP(),  
    CURRENT_TIMESTAMP()
)
WHEN MATCHED THEN
UPDATE SET
    ta.first_name = src.first_name,  
    ta.last_name = TRIM(CONCAT(coalesce(src.middle_name,''), ' ', src.last_name)),  
    ta.company_name = src.company,  
    ta.phone_number = COALESCE(src.mobile_phone, src.other_phone),  
    ta.address1 = src.address_line1,  
    ta.address2 = src.address_line2,  
    ta.address3 = src.address_line3,  
    ta.address4 = src.address_line4,  
    ta.address5 = src.address_line5,  
    ta.address6 = src.address_line6,  
    ta.city = src.city,  
    ta.state = src.state,  
    ta.country = src.country,  
    ta.postal_code = src.zip_code,  
    ta.modified_date = CURRENT_TIMESTAMP();

INSERT INTO temp_audit_address
(
    first_name,
    last_name,
    company_name,
    phone_number,
    address1,
    address2,
    city,
    state,
    country,
    postal_code,
    fk_address_typeid,
    inserted_date,
    modified_date,
    pk_addressid,
    Revision,
    ext_address_id,
    txn_id
)
SELECT
    ta.first_name,
    ta.last_name,
    ta.company_name,
    ta.phone_number,
    ta.address1,
    ta.address2,
    ta.city,
    ta.state,
    ta.country,
    ta.postal_code,
    ta.fk_address_typeid,
    ta.inserted_date,
    ta.modified_date,
    ta.pk_addressid,
    1 AS Revision,
    ta.ext_address_id,
    src.txn_id
FROM ANALYTICS.txn_address ta
    INNER JOIN TRANSFORMED.stg_order_person_info src 
        ON src.person_info_key = ta.ext_address_id
            AND ta.fk_address_typeid = :billAddressType
;

-- UPDATE 
--     temp_audit_address
-- SET 
--     Revision = CAST((aot.revision + 1) AS int)
-- FROM 
--     temp_audit_address AS ttd
-- INNER JOIN 
--     (
--         SELECT 
--             MAX(aot.revision) AS revision, 
--             aot.pk_addressid, 
--             aot.fk_address_typeid
--         FROM 
--             ANALYTICS.AUDIT_ADDRESS AS aot
--         INNER JOIN 
--             temP_audit_address AS ttd ON ttd.pk_addressid = aot.pk_addressid 
--             AND ttd.fk_address_typeid = aot.fk_address_typeid
--         GROUP BY 
--             aot.pk_addressid, 
--             aot.fk_address_typeid
--     ) AS aot ON ttd.pk_addressid = aot.pk_addressid 
--     AND ttd.fk_address_typeid = aot.fk_address_typeid;

CREATE OR REPLACE TEMPORARY TABLE temp_max_revisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.pk_addressid,
    aot.fk_address_typeid
FROM
    ANALYTICS.AUDIT_ADDRESS AS aot
GROUP BY
    aot.pk_addressid, 
    aot.fk_address_typeid;

UPDATE temp_audit_address AS ttd
SET
    ttd.revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM
    temp_max_revisions AS aot
WHERE
    ttd.pk_addressid = aot.pk_addressid AND
    ttd.fk_address_typeid = aot.fk_address_typeid ;

INSERT INTO   ANALYTICS.audit_address (
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date,  
    pk_addressid,  
    Revision,
    ext_address_id
)
SELECT 
    first_name,  
    last_name,  
    company_name,  
    phone_number,  
    address1,  
    address2,  
    city,  
    state,  
    country,  
    postal_code,  
    fk_address_typeid,  
    inserted_date,  
    modified_date,  
    pk_addressid,  
    Revision,
    ext_address_id
FROM temp_audit_address;

-- UPDATE RAW.raw_order_person_info
-- SET
--     processing_status = 'Processed',
--     processing_comment = '',
--     processing_errortype = ''
-- FROM RAW.raw_order_person_info AS roh
-- INNER JOIN TRANSFORMED.stg_order_person_info AS stg
--     ON stg.person_info_key = roh.person_info_key 
--     AND stg.modifyts = roh.modifyts 
--     AND stg.txn_id = roh.txn_id
-- INNER JOIN TEMP_audit_address AS toh
--     ON toh.ext_address_id = roh.person_info_key 
--     AND toh.txn_id = roh.txn_id
-- INNER JOIN temp_audit_address AS tsoh
--     ON tsoh.ext_address_id = roh.person_info_key 
--     AND tsoh.txn_id = roh.txn_id
-- WHERE roh.processing_status IN ('Pending', 'Failed');

MERGE INTO RAW.raw_order_person_info AS roh
USING (
    SELECT stg.person_info_key, stg.modifyts, stg.txn_id
    FROM TRANSFORMED.stg_order_person_info AS stg
    INNER JOIN TEMP_audit_address AS toh
        ON toh.ext_address_id = stg.person_info_key 
        AND toh.txn_id = stg.txn_id
    INNER JOIN TEMP_audit_address AS tsoh
        ON tsoh.ext_address_id = stg.person_info_key 
        AND tsoh.txn_id = stg.txn_id
) AS source
ON roh.person_info_key = source.person_info_key
   AND roh.modifyts = source.modifyts
   AND roh.txn_id = source.txn_id
   AND roh.processing_status IN ('Pending', 'Failed')
WHEN MATCHED THEN 
    UPDATE SET 
        roh.processing_status = 'Processed',
        roh.processing_comment = '',
        roh.processing_errortype = '';


SELECT  
    :toBeProcessedRecordCount = COUNT(*)  
FROM  
    TRANSFORMED.stg_order_person_info;

SELECT  
    :processedRecordCount = COUNT(*)  
FROM  
    temp_audit_address;

UPDATE  
    ANALYTICS.log_files_import_status  
SET  
    processed = :processedRecordCount,  
    to_be_processed = :toBeProcessedRecordCount,  
    status = 'Success'  
FROM  
    ANALYTICS.log_files_import_status  AS lofis
WHERE  
    lofis.file_name = 'YFS_PERSON_INFO';

DROP TABLE IF EXISTS temp_audit_address;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

COMMIT;

RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_PERSON_INFO';
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	
	RETURN error_object;
END;