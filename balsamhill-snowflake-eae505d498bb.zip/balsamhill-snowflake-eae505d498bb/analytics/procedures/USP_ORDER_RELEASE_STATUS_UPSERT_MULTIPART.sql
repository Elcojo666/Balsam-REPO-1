CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_RELEASE_STATUS_UPSERT_MULTIPART("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );
    -- Temporary table creation in Snowflake (Snowflake uses CTE or TEMP TABLE for temp storage)
    CREATE OR REPLACE TEMPORARY TABLE ANALYTICS.TempOrderReleaseStatus(
        order_release_status_key STRING,    
        order_release_key STRING,    
        order_line_key STRING,    
        order_header_key STRING,    
        status STRING,    
        status_date TIMESTAMP,    
        status_quantity STRING,    
        pipeline_key STRING,    
        order_line_schedule_key STRING,    
        total_quantity STRING,    
        expected_shipment_date TIMESTAMP,    
        chained_to_order_line_key STRING,    
        chained_to_order_header_key STRING,    
        createts TIMESTAMP,    
        modifyts TIMESTAMP,    
        createuserid STRING,    
        modifyuserid STRING,    
        createprogid STRING,    
        modifyprogid STRING,    
        lockid STRING,    
        inserted_date TIMESTAMP,    
        modified_date TIMESTAMP,    
        revision NUMBER
    );

   processedDate := CURRENT_TIMESTAMP();

    -- MERGE statement in Snowflake
    MERGE INTO ANALYTICS.txn_order_release_status_multipart AS tors
    USING (
        SELECT 
            order_release_status_key,    
            order_release_key,    
            order_line_key,    
            order_header_key,    
            status,    
            TRY_TO_TIMESTAMP(status_date,'YYYYMMDDHHMISS') as status_date,    
            try_to_number(status_quantity) as status_quantity,    
            pipeline_key,    
            order_line_schedule_key,    
            try_to_number(total_quantity) as total_quantity,    
            TRY_TO_TIMESTAMP(expected_shipment_date,'YYYYMMDDHHMISS') as expected_shipment_date,    
            chained_to_order_line_key,    
            chained_to_order_header_key,    
            TRY_TO_TIMESTAMP(createts,'YYYYMMDDHHMISS') as createts,    
            TRY_TO_TIMESTAMP(modifyts,'YYYYMMDDHHMISS') as modifyts,    
            createuserid,    
            modifyuserid,    
            createprogid,    
            modifyprogid,    
            lockid
        FROM  transformed.stg_order_release_status_multipart
    ) AS sors
    ON tors.order_release_status_key = sors.order_release_status_key
    AND tors.order_line_key = sors.order_line_key
    AND tors.order_header_key = sors.order_header_key
    WHEN MATCHED THEN
        UPDATE SET
            tors.order_release_status_key = sors.order_release_status_key,    
            tors.order_release_key = sors.order_release_key,    
            tors.order_line_key = sors.order_line_key,    
            tors.order_header_key = sors.order_header_key,    
            tors.status = sors.status,    
            tors.status_date = sors.status_date,    
            tors.status_quantity = sors.status_quantity,    
            tors.pipeline_key = sors.pipeline_key,    
            tors.order_line_schedule_key = sors.order_line_schedule_key,    
            tors.total_quantity = sors.total_quantity,    
            tors.expected_shipment_date = sors.expected_shipment_date,    
            tors.chained_to_order_line_key = sors.chained_to_order_line_key,    
            tors.chained_to_order_header_key = sors.chained_to_order_header_key,    
            tors.createts = sors.createts,    
            tors.modifyts = sors.modifyts,    
            tors.createuserid = sors.createuserid,    
            tors.modifyuserid = sors.modifyuserid,    
            tors.createprogid = sors.createprogid,    
            tors.modifyprogid = sors.modifyprogid,    
            tors.lockid = sors.lockid,    
            tors.modified_date = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
            order_release_status_key,    
            order_release_key,    
            order_line_key,    
            order_header_key,    
            status,    
            status_date,    
            status_quantity,    
            pipeline_key,    
            order_line_schedule_key,    
            total_quantity,    
            expected_shipment_date,    
            chained_to_order_line_key,    
            chained_to_order_header_key,    
            createts,    
            modifyts,    
            createuserid,    
            modifyuserid,    
            createprogid,    
            modifyprogid,    
            lockid,    
            inserted_date
        )
        VALUES (
            sors.order_release_status_key,    
            sors.order_release_key,    
            sors.order_line_key,    
            sors.order_header_key,    
            sors.status,    
            sors.status_date,    
            sors.status_quantity,    
            sors.pipeline_key,    
            sors.order_line_schedule_key,    
            sors.total_quantity,    
            sors.expected_shipment_date,    
            sors.chained_to_order_line_key,    
            sors.chained_to_order_header_key,    
            sors.createts,    
            sors.modifyts,    
            sors.createuserid,    
            sors.modifyuserid,    
            sors.createprogid,    
            sors.modifyprogid,    
            sors.lockid,    
            CURRENT_TIMESTAMP()
        );
  insert into analytics.TempOrderReleaseStatus (    
    order_release_status_key,    
    order_release_key,    
    order_line_key,    
    order_header_key,    
    status,    
    status_date,    
    status_quantity,    
    pipeline_key,    
    order_line_schedule_key,    
    total_quantity,    
    expected_shipment_date,    
    chained_to_order_line_key,    
    chained_to_order_header_key,    
    createts,    
    modifyts,    
    createuserid,    
    modifyuserid,    
    createprogid,    
    modifyprogid,    
    lockid,    
    inserted_date,    
    Revision    
   )    
  select
    inserted.order_release_status_key,    
   inserted.order_release_key,    
   inserted.order_line_key,    
   inserted.order_header_key,    
   inserted.status,    
   inserted.status_date,    
   inserted.status_quantity,    
   inserted.pipeline_key,    
   inserted.order_line_schedule_key,    
   inserted.total_quantity,    
   inserted.expected_shipment_date,    
   inserted.chained_to_order_line_key,    
   inserted.chained_to_order_header_key,    
   inserted.createts,    
   inserted.modifyts,    
   inserted.createuserid,    
   inserted.modifyuserid,    
   inserted.createprogid,    
   inserted.modifyprogid,    
   inserted.lockid,    
   current_timestamp(),    
   1 
   from ANALYTICS.txn_order_release_status_multipart inserted
   where inserted_date >= :processedDate or modified_date >= :processedDate ;
    

    -- Updating the Temp table with revision info
    UPDATE analytics.TempOrderReleaseStatus ttd
    SET ttd.Revision = COALESCE(aot.revision, 0) + 1
    FROM (
        SELECT MAX(aot.revision) AS revision, aot.order_release_status_key, aot.order_line_key, aot.order_header_key
        FROM analytics.audit_order_release_status_multipart aot
        JOIN analytics.TempOrderReleaseStatus ttd
        ON ttd.order_release_status_key = aot.order_release_status_key
        AND ttd.order_line_key = aot.order_line_key
        AND ttd.order_header_key = aot.order_header_key
        GROUP BY aot.order_release_status_key, aot.order_line_key, aot.order_header_key
    ) aot
    WHERE ttd.order_release_status_key = aot.order_release_status_key
    AND ttd.order_line_key = aot.order_line_key
    AND ttd.order_header_key = aot.order_header_key;

    -- Process update in raw_oms_order_release_status
    UPDATE raw.raw_order_release_status roh
    SET roh.processing_status = 'Processed',
        roh.processing_comment = '',
        roh.processing_errortype = ''
    FROM transformed.stg_order_release_status_multipart stg
    WHERE stg.order_release_status_key = roh.order_release_status_key
    AND stg.order_line_key = roh.order_line_key
    AND stg.order_header_key = roh.order_header_key;

    -- Insert into audit_order_release_status_multipart
    INSERT INTO analytics.audit_order_release_status_multipart(
        order_release_status_key,    
        order_release_key,    
        order_line_key,    
        order_header_key,    
        status,    
        status_date,    
        status_quantity,    
        pipeline_key,    
        order_line_schedule_key,    
        total_quantity,    
        expected_shipment_date,    
        chained_to_order_line_key,    
        chained_to_order_header_key,    
        createts,    
        modifyts,    
        createuserid,    
        modifyuserid,    
        createprogid,    
        modifyprogid,    
        lockid,    
        inserted_date,    
        Revision
    )
    SELECT
        ord.order_release_status_key,    
        ord.order_release_key,    
        ord.order_line_key,    
        ord.order_header_key,    
        stg.status,    
        stg.status_date,    
        stg.status_quantity,    
        stg.pipeline_key,    
        stg.order_line_schedule_key,    
        stg.total_quantity,    
        stg.expected_shipment_date,    
        stg.chained_to_order_line_key,    
        stg.chained_to_order_header_key,    
        stg.createts,    
        stg.modifyts,    
        stg.createuserid,    
        stg.modifyuserid,    
        stg.createprogid,    
        stg.modifyprogid,    
        stg.lockid,    
        CURRENT_TIMESTAMP(),    
        ord.Revision
    FROM analytics.txn_order_release_status_multipart stg
    INNER JOIN analytics.TempOrderReleaseStatus ord
    ON ord.order_release_status_key = stg.order_release_status_key
    AND ord.order_line_key = stg.order_line_key
    AND ord.order_header_key = stg.order_header_key;

    -- Count processed records
    SELECT COUNT(*) INTO :processedRecordCount
    FROM analytics.TempOrderReleaseStatus;

    -- Drop the temp table
    DROP TABLE IF EXISTS analytics.TempOrderReleaseStatus;
CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);


COMMIT;

RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_ORDER_RELEASE_STATUS_MULTIPART';
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	
	RETURN error_object;
END;