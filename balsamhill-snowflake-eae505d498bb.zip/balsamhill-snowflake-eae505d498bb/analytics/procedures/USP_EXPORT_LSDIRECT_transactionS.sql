CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.USP_EXPORT_LSDIRECT_transactionS()
RETURNS STRING
LANGUAGE SQL
AS
$$
DECLARE 
    ts STRING;
    copy_sql STRING;
BEGIN
  -- Format the current date as 'YYYY-MM-DD'
  ts := TO_CHAR(CURRENT_TIMESTAMP(), 'YYYY-MM-DD_HH24-MI-SS');
  copy_sql := ' COPY INTO @ANALYTICS.LSDIRECT_EXPORTS/daily_export/transactions/transactions_export_' || :ts || ' FROM (SELECT * FROM ANALYTICS.LSDIRECT_transactionS_EXPORT) FILE_FORMAT = (TYPE = PARQUET COMPRESSION=\'NONE\') HEADER = TRUE OVERWRITE = FALSE ';

  EXECUTE IMMEDIATE :copy_sql;

  RETURN 'Transactions Export completed on ' || CURRENT_TIMESTAMP();
END;
$$;
