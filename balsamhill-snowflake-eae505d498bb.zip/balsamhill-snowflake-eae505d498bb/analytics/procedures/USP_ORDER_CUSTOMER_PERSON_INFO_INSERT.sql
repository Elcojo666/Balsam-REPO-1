USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE BALSAM_EDW_DEV.ANALYTICS.USP_ORDER_CUSTOMER_PERSON_INFO_INSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    warningCount NUMBER DEFAULT 0;
    customerCount NUMBER DEFAULT 0;
    customerParentID TEXT;
    customerID TEXT;
    domesticSource TEXT DEFAULT ''domestic'';
    internationalSource TEXT DEFAULT ''international'';
    processedRecordCount NUMBER DEFAULT 0;
    finalStatus INT DEFAULT 0;
    currentDate TIMESTAMP;
    message TEXT;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    error_object VARIANT;
BEGIN 
SYSTEM$LOG(''TRACE'','' USP_ORDER_CUSTOMER_PERSON_INFO_INSERT has been Started'');
CREATE OR REPLACE TEMPORARY TABLE DuplicateResultToLog (
    stagesourceref STRING,    
    custid STRING
);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''insert'',
        ''STARTED'',
        CURRENT_TIMESTAMP(),
        NULL,
        ''upsert started''
    );


UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount
WHERE file_name = ''INTR_CUSTOMER_INFO'';

SELECT COUNT(*) INTO :CustomerCount FROM TRANSFORMED.stg_customer_person_info;

IF (CustomerCount > 0) THEN
    INSERT INTO DuplicateResultToLog (stagesourceref, custid)
    SELECT stg.SourceRefNum, cust.pk_customerid
    FROM TRANSFORMED.stg_customer_person_info AS stg
    LEFT JOIN ANALYTICS.customer AS cust ON stg.SourceRefNum = cust.source_ref_num
        AND stg.SourceID = cust.fk_sourceid;
END IF;

SELECT COUNT(*)
INTO :WarningCount
FROM DuplicateResultToLog
WHERE stagesourceref IS NOT NULL AND custid IS NOT NULL; 

IF (WarningCount > 0) THEN
    -- Update records
    UPDATE  RAW.raw_customer_person_info
    SET
        processing_status = ''Rejected'',
        processing_comment = ''Customer already exist'',
        processing_errortype = ''''
    FROM RAW.raw_order_customer_person_info AS roh
    INNER JOIN TRANSFORMED.stg_order_customer_person_info AS stg
        ON stg.person_info_key = roh.person_info_key
    INNER JOIN DuplicateResultToLog AS toh
        ON toh.stagesourceref = roh.person_info_key AND stg.fk_sourceid = roh.fk_sourceid
    WHERE roh.processing_status IN (''Pending'', ''Failed'')
        AND stagesourceref IS NOT NULL
        AND custid IS NOT NULL;
    
    message := ''WARNING: '' || WarningCount::STRING || '' Customer already exist'';
    RETURN message;
ELSE
    BEGIN
        CREATE OR REPLACE TEMPORARY TABLE CustomerApiCount (
            pk_customerid INT,
            source_ref_num STRING NOT NULL,
            fk_sourceid INT NOT NULL
        );

        

        CREATE OR REPLACE TEMPORARY TABLE tempBPApiCustomer AS
        SELECT
            cust.*, src.pk_sourceid, custtype.pk_customer_typeid
        FROM TRANSFORMED.stg_customer_person_info AS cust
        INNER JOIN master.dim_SOURCE AS src
            ON cust.SourceID = src.pk_sourceid
        INNER JOIN ANALYTICS.customer_type AS custtype
            ON cust.CustomerType = custtype.customer_type
        LEFT JOIN ANALYTICS.customer AS dimcust
            ON dimcust.source_ref_num = cust.SourceRefNum
            AND dimcust.fk_sourceid = src.pk_sourceid
        WHERE dimcust.pk_customerid IS NULL
            AND src.pk_sourceid IS NOT NULL
            AND validation_Status = 1;

INSERT INTO ANALYTICS.audit_customer (
    fk_sourceid,
    source_ref_num,
    ext_customer_id,
    is_domestic,
    fk_customer_typeid,
    inserted_date,
    city,
    first_name,
    last_name,
    company_name,
    address1,
    address2,
    state,
    country,
    postal_code,
    email_address,
    phone,
    is_tax_exempt,
    email_subscriber,
    catalog_subscriber
)
SELECT 
    bpcust.pk_sourceid,
    bpcust.SourceRefNum,
    bpcust.ID,
    CASE 
        WHEN source = :domesticSource THEN 1
        ELSE 0
    END,
    bpcust.pk_customer_typeid,
    :currentdate,
    '''',
    bpcust.FirstName,
    bpcust.LastName,
    bpcust.CompanyName,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    bpcust.EmailAddress,
    bpcust.PhoneNumber,
    CASE 
        WHEN LOWER(bpcust.TaxExemptAccount) = ''true'' THEN 1
        ELSE 0
    END AS is_tax_exempt,
    CASE 
        WHEN LOWER(bpcust.EmailSubscriber) = ''true'' THEN 1
        ELSE 0
    END AS email_subscriber,
    CASE 
        WHEN LOWER(bpcust.CatalogSubscriber) = ''true'' THEN 1
        ELSE 0
    END AS catalog_subscriber
FROM tempBPApiCustomer AS bpcust
LEFT JOIN ANALYTICS.audit_customer AS audcust 
    ON bpcust.SourceRefNum = audcust.source_ref_num 
    AND bpcust.pk_sourceid = audcust.fk_sourceid
WHERE audcust.source_ref_num IS NULL 
    AND audcust.fk_sourceid IS NULL;

CREATE OR REPLACE TEMPORARY TABLE tempApiCustomers AS
SELECT
    cust.*,
    0 AS IsBP
FROM
    tempBPApiCustomer cust;

-- Create a temporary table to hold deduplicated results
CREATE TEMPORARY TABLE tempDedupedApiCustomers AS
SELECT * 
FROM (
    SELECT 
        *,
        ROW_NUMBER() OVER (PARTITION BY SourceRefNum, pk_sourceid, pk_customer_typeid ORDER BY SourceRefNum, pk_sourceid, pk_customer_typeid) AS rn
    FROM tempApiCustomers
)
WHERE rn = 1;



DROP TABLE tempApiCustomers;

ALTER TABLE tempDedupedApiCustomers RENAME TO tempApiCustomers;

MERGE INTO ANALYTICS.customer AS tgt
USING (
    SELECT DISTINCT 
        cust.pk_sourceid,
        cust.SourceRefNum,
        cust.ID,
        CASE 
            WHEN source = :domesticSource THEN 1
            ELSE 0
        END AS is_domestic,
        cust.pk_customer_typeid
    FROM tempApiCustomers AS cust
    LEFT JOIN ANALYTICS.customer AS dimcust 
        ON dimcust.source_ref_num = cust.SourceRefNum
        AND dimcust.fk_sourceid = cust.pk_sourceid
    WHERE dimcust.pk_customerid IS NULL
) AS src 
ON src.pk_sourceid = tgt.fk_sourceid 
    AND src.SourceRefNum = tgt.source_ref_num
WHEN MATCHED THEN 
    UPDATE SET 
        tgt.fk_customer_typeid = src.pk_customer_typeid,
        tgt.is_domestic = src.is_domestic
WHEN NOT MATCHED THEN 
    INSERT (
        fk_sourceid,
        source_ref_num,
        ext_customer_id,
        is_domestic,
        fk_customer_typeid
    )
    VALUES (
        src.pk_sourceid,
        src.SourceRefNum,
        src.ID,
        src.is_domestic,
        src.pk_customer_typeid
    );
    
INSERT INTO CustomerApiCount (
    pk_customerid,
    source_ref_num,
    fk_sourceid
)
SELECT 
    cust.pk_sourceid,
    cust.SourceRefNum,
    cust.ID
FROM 
    tempApiCustomers AS cust
LEFT JOIN 
    ANALYTICS.customer AS dimcust 
    ON dimcust.source_ref_num = cust.SourceRefNum
    AND dimcust.fk_sourceid = cust.pk_sourceid
WHERE 
    dimcust.pk_customerid IS NULL;
    
-- Added as part phone conversion by Divya Nalam - START

-- Add columns to the temporary table
ALTER TABLE tempApiCustomers ADD COLUMN PhoneNumber_E164 STRING;
ALTER TABLE tempApiCustomers ADD COLUMN Phone1_E164 STRING;
ALTER TABLE tempApiCustomers ADD COLUMN Phone2_E164 STRING;
ALTER TABLE tempApiCustomers ADD COLUMN Phone4_E164 STRING;

-- Update PhoneNumber_E164
UPDATE tempApiCustomers
SET PhoneNumber_E164 = ''+1'' || REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')) = 10
AND PhoneNumber NOT LIKE ''1%''
AND PhoneNumber NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET PhoneNumber_E164 = ''+'' || REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')) = 11
AND PhoneNumber LIKE ''1%''
AND PhoneNumber NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET PhoneNumber_E164 = REGEXP_REPLACE(SUBSTRING(PhoneNumber, 1, POSITION(''ext.'' IN PhoneNumber) - 1), ''[^0-9]'', '''')
WHERE LOWER(PhoneNumber) LIKE ''%ext.%''
AND PhoneNumber LIKE ''+1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(PhoneNumber, 1, POSITION(''ext.'' IN PhoneNumber) - 1), ''[^0-9]'', '''')) = 12
AND PhoneNumber IS NOT NULL;

UPDATE tempApiCustomers
SET PhoneNumber_E164 = ''+'' || REGEXP_REPLACE(SUBSTRING(PhoneNumber, 1, POSITION(''ext.'' IN PhoneNumber) - 1), ''[^0-9]'', '''')
WHERE LOWER(PhoneNumber) LIKE ''%ext.%''
AND PhoneNumber LIKE ''1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(PhoneNumber, 1, POSITION(''ext.'' IN PhoneNumber) - 1), ''[^0-9]'', '''')) = 12
AND PhoneNumber IS NOT NULL;

UPDATE tempApiCustomers
SET PhoneNumber_E164 = NULL
WHERE PhoneNumber LIKE ''11%'';

UPDATE tempApiCustomers
SET PhoneNumber_E164 = REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')
WHERE PhoneNumber LIKE ''+001%''
AND LENGTH(REGEXP_REPLACE(PhoneNumber, ''[^0-9]'', '''')) = 12;

UPDATE tempApiCustomers
SET Phone1_E164 = ''+1'' || REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')) = 10
AND Phone1Input NOT LIKE ''1%''
AND Phone1Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone1_E164 = ''+'' || REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')) = 11
AND Phone1Input LIKE ''1%''
AND Phone1Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone1_E164 = REGEXP_REPLACE(SUBSTRING(Phone1Input, 1, POSITION(''ext.'' IN Phone1Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone1Input) LIKE ''%ext.%''
AND Phone1Input LIKE ''+1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone1Input, 1, POSITION(''ext.'' IN Phone1Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone1Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone1_E164 = ''+'' || REGEXP_REPLACE(SUBSTRING(Phone1Input, 1, POSITION(''ext.'' IN Phone1Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone1Input) LIKE ''%ext.%''
AND Phone1Input LIKE ''1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone1Input, 1, POSITION(''ext.'' IN Phone1Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone1Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone1_E164 = NULL
WHERE Phone1Input LIKE ''11%'';

UPDATE tempApiCustomers
SET Phone1_E164 = REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')
WHERE Phone1Input LIKE ''+001%''
AND LENGTH(REGEXP_REPLACE(Phone1Input, ''[^0-9]'', '''')) = 12;

UPDATE tempApiCustomers
SET Phone2_E164 = ''+1'' || REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')) = 10
AND Phone2Input NOT LIKE ''1%''
AND Phone2Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone2_E164 = ''+'' || REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')) = 11
AND Phone2Input LIKE ''1%''
AND Phone2Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone2_E164 = REGEXP_REPLACE(SUBSTRING(Phone2Input, 1, POSITION(''ext.'' IN Phone2Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone2Input) LIKE ''%ext.%''
AND Phone2Input LIKE ''+1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone2Input, 1, POSITION(''ext.'' IN Phone2Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone2Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone2_E164 = ''+'' || REGEXP_REPLACE(SUBSTRING(Phone2Input, 1, POSITION(''ext.'' IN Phone2Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone2Input) LIKE ''%ext.%''
AND Phone2Input LIKE ''1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone2Input, 1, POSITION(''ext.'' IN Phone2Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone2Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone2_E164 = NULL
WHERE Phone2Input LIKE ''11%'';

UPDATE tempApiCustomers
SET Phone2_E164 = REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')
WHERE Phone2Input LIKE ''+001%''
AND LENGTH(REGEXP_REPLACE(Phone2Input, ''[^0-9]'', '''')) = 12;

UPDATE tempApiCustomers
SET Phone4_E164 = ''+1'' || REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')) = 10
AND Phone4Input NOT LIKE ''1%''
AND Phone4Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone4_E164 = ''+'' || REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')
WHERE LENGTH(REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')) = 11
AND Phone4Input LIKE ''1%''
AND Phone4Input NOT LIKE ''+1%'';

UPDATE tempApiCustomers
SET Phone4_E164 = REGEXP_REPLACE(SUBSTRING(Phone4Input, 1, POSITION(''ext.'' IN Phone4Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone4Input) LIKE ''%ext.%''
AND Phone4Input LIKE ''+1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone4Input, 1, POSITION(''ext.'' IN Phone4Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone4Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone4_E164 = ''+'' || REGEXP_REPLACE(SUBSTRING(Phone4Input, 1, POSITION(''ext.'' IN Phone4Input) - 1), ''[^0-9]'', '''')
WHERE LOWER(Phone4Input) LIKE ''%ext.%''
AND Phone4Input LIKE ''1%''
AND LENGTH(REGEXP_REPLACE(SUBSTRING(Phone4Input, 1, POSITION(''ext.'' IN Phone4Input) - 1), ''[^0-9]'', '''')) = 12
AND Phone4Input IS NOT NULL;

UPDATE tempApiCustomers
SET Phone4_E164 = NULL
WHERE Phone4Input LIKE ''11%'';

UPDATE tempApiCustomers
SET Phone4_E164 = REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')
WHERE Phone4Input LIKE ''+001%''
AND LENGTH(REGEXP_REPLACE(Phone4Input, ''[^0-9]'', '''')) = 12;
-- End of phone conversion by Divya Nalam
desc table ANALYTICS.customer_info;
--Inserting Customer Info data  
INSERT INTO ANALYTICS.customer_info (
    FK_CUSTOMERID,
    STATUS,
    PREFERRED_LANG,
    REGD_DATE,
    TITLE,
    FIRST_NAME,
    LAST_NAME,
    DOB,
    GENDER_CODE,
    GENDER,
    MARITAL_STATUS_CODE,
    MARITAL_STATUS,
    EMAIL_PRIMARY,
    EMAIL_SECONDARY,
    PHONE1_INPUT,
    PHONE2_INPUT,
    PHONE3_INPUT,
    PHONE4_INPUT,
    COMPANY_NAME,
    CATALOG_SUBSCRIBER,
    CUSTOMER_IS_ANONYMOUS,
    IS_ANONYMOUS_DATE_UPDATED,
    CUST_TYPE,
    NEW_CUSTOMER,
    CUST_NOTES,
    TAX_EXEMPT_ACCOUNT,
    ORDER_PLACED,
    CREATED_BY,
    CREATED_DATE,
    MODIFIED_BY,
    MODIFIED_DATE,
    LAST_LOGIN_DATE,
    EXTERNAL_ID,
    EXTERNAL_ACCOUNTID,
    EXTERNAL_EMAIL2,
    EXTERNAL_EMAIL1,
    MASTERCONTACT,
    LEGAL_NAME,
    EMAIL_OPT_IN_STATUS,
    FK_MASTERCUSTOMERID,
    DEDUP_TYPE,
    cust_tier,
    tax_id,
    email_subscriber,
    IsNordstromCustomer,
    IsWilliamsonomaCustomer,
    business_cust,
    business_category,
    "BUSINESS_#_OF_LOCATIONS",
    DesignTradeFlag,
    social_handle_facebook,
    social_handle_instagram,
    social_handle_twitter,
    phone1_sms,
    phone1_pref,
    phone1_region,
    phone2_sms,
    phone2_pref,
    phone2_region,
    phone3_sms,
    phone3_pref,
    phone3_region,
    phone4_sms,
    phone4_pref,
    phone4_region,
    phone1_E164,
    phone2_E164,
    phone3_E164,
    phone4_E164,
    HashedId
)
SELECT DISTINCT 
    dimcust.pk_customerid,
    cust.Status, -- Initial value
    cust.Preferred_Lang, -- demo value
    cust.Regd_Date, -- REGD_Date
    NULL AS Title,
    cust.FirstName,
    cust.LastName,
    cust.Dob, -- DOB
    cust.GenderCode, -- gender_code
    cust.Gender, -- gender
    cust.MaritalStatusCode, -- marital_status_code
    cust.MaritalStatus, -- marital_status
    cust.EmailAddress,
    cust.EmailSecondary, -- EMAIL_SECONDARY
    cust.Phone1Input, -- Phone1Input
    cust.Phone2Input, -- Phone2Input
    cust.PhoneNumber AS Phone3Input,
    cust.Phone4Input, -- Phone4Input
    cust.CompanyName,
    cust.CatalogSubscriber,
    cust.Customer_IsAnonymous,
    NULL AS IS_ANONYMOUS_DATE_UPDATED,
    cust.CustomerType, -- custtype.pk_customer_typeid
    cust.Checkbox_For_New_Customers,
    cust.Customer_Notes,
    cust.TaxExemptAccount,
    cust.OrderPlaced,
    cust.CreatedBy,
    CURRENT_DATE, -- @currentdate
    cust.CreatedBy,
    CURRENT_DATE, -- @currentdate
    IFNULL(cust.LastLogin, NULL),
    cust.EXTERNAL_ID,
    cust.EXTERNAL_ACCOUNTID,
    cust.ExternalEmail2,
    cust.ExternalEmail1,
    cust.MASTERCONTACT,
    cust.LegalName,
    cust.EMAIL_OPT_IN_STATUS,
    cust.MASTERCUSTOMERID,
    NULL,
    cust.cust_tier,
    cust.tax_id,
    CASE
        WHEN LOWER(cust.EmailSubscriber) = ''true''
        THEN 1
        ELSE 0
    END AS email_subscriber,
    cust.IsNordstromCustomer,
    cust.IsWilliamsonomaCustomer,
    cust.business_cust,
    cust.business_category,
    cust.BusinessLocations,
    cust.DesignTradeFlag,
    cust.social_handle_facebook,
    cust.social_handle_instagram,
    cust.social_handle_twitter,
    cust.phone1_sms,
    cust.phone1_pref,
    cust.phone1_region,
    cust.phone2_sms,
    cust.phone2_pref,
    cust.phone2_region,
    cust.phone3_sms,
    cust.phone3_pref,
    cust.phone3_region,
    cust.phone4_sms,
    cust.phone4_pref,
    cust.phone4_region,
    cust.Phone1_E164, -- phone1_E164
    cust.Phone2_E164, -- phone2_E164
    cust.PhoneNumber_E164,
    cust.Phone4_E164,
    cust.HashedId 
    from
    tempApiCustomers AS cust
INNER JOIN ANALYTICS.customer AS dimcust ON dimcust.source_ref_num = cust.SourceRefNum
    AND dimcust.fk_sourceid = cust.pk_sourceid;

    create or replace temp table tempupdated_rows as 
WITH updated_rows AS (
    SELECT ROH.*
    FROM RAW.raw_ORDER_customer_person_info AS roh
    INNER JOIN TRANSFORMED.stg_ORDER_customer_person_info AS stg 
        ON stg.person_info_key = roh.person_info_key
    INNER JOIN CustomerApiCount AS toh 
        ON toh.source_ref_num = roh.person_info_key 
        AND toh.fk_sourceid = roh.fk_sourceid
    WHERE roh.processing_status IN (''Pending'', ''Failed'')
)
select * from updated_rows;

UPDATE RAW.raw_ORDER_customer_person_info
SET
    processing_status = ''Processed'',
    processing_comment = '''',
    processing_errortype = ''''
WHERE person_info_key IN (SELECT person_info_key FROM tempupdated_rows);



SELECT COUNT(*) INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_customer_person_info;

SELECT COUNT(*) INTO :processedRecordCount
FROM CustomerApiCount;

UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
WHERE
    ANALYTICS.log_files_import_status.file_name = ''INTR_CUSTOMER_INFO'';
    
    END;
END IF;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''insert'',
        ''COMPLETED'',
        NULL,
        CURRENT_TIMESTAMP(),
        ''upsert completed successfully''
    );

SYSTEM$LOG(''TRACE'','' USP_ORDER_CUSTOMER_PERSON_INFO_INSERT has been Completed'');
RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

        error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''insert'',
        ''FAILED'',
        NULL,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );
    SYSTEM$LOG(''ERROR'','' USP_ORDER_CUSTOMER_PERSON_INFO_INSERT has Failed'');
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';