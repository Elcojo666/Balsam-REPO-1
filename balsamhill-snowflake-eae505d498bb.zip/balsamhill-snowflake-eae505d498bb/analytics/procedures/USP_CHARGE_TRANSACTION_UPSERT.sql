CREATE OR REPLACE PROCEDURE ANALYTICS.USP_CHARGE_TRANSACTION_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,
    raw_table = ''raw_order_charge_transaction''
WHERE
    file_name = ''YFS_CHARGE_TRANSACTION'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
		
			

		CREATE or REPLACE TEMP TABLE TempChargeTransaction(
			charge_transaction_key VARCHAR,
			charge_type VARCHAR,
			transfer_from_oh_key VARCHAR,
			transfer_to_oh_key VARCHAR,
			status VARCHAR,
			credit_amount VARCHAR,
			debit_amount VARCHAR,
			book_amount VARCHAR,
			open_authorized_amount VARCHAR,
			request_amount VARCHAR,
			distributed_amount VARCHAR,
			settled_amount VARCHAR,
			authorization_id VARCHAR,
			authorization_expiration_date VARCHAR,
			order_invoice_key VARCHAR,
			order_header_key VARCHAR,
			payment_key VARCHAR,
			audit_transaction_id VARCHAR,
			user_exit_status VARCHAR,
			execution_date VARCHAR,
			is_collection_date_firm VARCHAR,
			collection_date VARCHAR,
			hold_against_book VARCHAR,
			in_person VARCHAR,
			void_transaction VARCHAR,
			postponed_amount VARCHAR,
			offline_status VARCHAR,
			call_for_auth_status VARCHAR,
			cash_back_amount VARCHAR,
			payment_entry_type VARCHAR,
			async_request_identifier VARCHAR,
			for_async_request_identifier VARCHAR,
			reason_code VARCHAR,
			createts VARCHAR,
			modifyts VARCHAR,
			createuserid VARCHAR,
			modifyuserid VARCHAR,
			createprogid VARCHAR,
			modifyprogid VARCHAR,
			lockid VARCHAR,
			inserted_date VARCHAR ,
			modified_date VARCHAR ,
			revision int
		);
		
		processedDate := current_timestamp();

		MERGE INTO   analytics.txn_charge_transaction txn USING (
		SELECT DISTINCT charge_transaction_key,
		charge_type,
		transfer_from_oh_key,
		transfer_to_oh_key,
		status,
		credit_amount,
		debit_amount,
		book_amount,
		open_authorized_amount,
		request_amount,
		distributed_amount,
		settled_amount,
		authorization_id,
		authorization_expiration_date,
		order_invoice_key,
		order_header_key,
		payment_key,
		audit_transaction_id,
		user_exit_status,
		execution_date,
		is_collection_date_firm,
		collection_date,
		hold_against_book,
		in_person,
		void_transaction,
		postponed_amount,
		offline_status,
		call_for_auth_status,
		cash_back_amount,
		payment_entry_type,
		async_request_identifier,
		for_async_request_identifier,
		reason_code,
		createts,
		modifyts,
		createuserid,
		modifyuserid,
		createprogid,
		modifyprogid,
		lockid
			from transformed.stg_order_charge_transaction stg	
		 ) stg
		 ON (
			txn.charge_transaction_key = stg.charge_transaction_key 
		 )
		 WHEN MATCHED THEN
		UPDATE
		SET 
			txn.charge_transaction_key=stg.charge_transaction_key,
			txn.charge_type=stg.charge_type,
			txn.transfer_from_oh_key=stg.transfer_from_oh_key,
			txn.transfer_to_oh_key=stg.transfer_to_oh_key,
			txn.status=stg.status,
			txn.credit_amount=stg.credit_amount,
			txn.debit_amount=stg.debit_amount,
			txn.book_amount=stg.book_amount,
			txn.open_authorized_amount=stg.open_authorized_amount,
			txn.request_amount=stg.request_amount,
			txn.distributed_amount=stg.distributed_amount,
			txn.settled_amount=stg.settled_amount,
			txn.authorization_id=stg.authorization_id,
			txn.authorization_expiration_date=stg.authorization_expiration_date,
			txn.order_invoice_key=stg.order_invoice_key,
			txn.order_header_key=stg.order_header_key,
			txn.payment_key=stg.payment_key,
			txn.audit_transaction_id=stg.audit_transaction_id,
			txn.user_exit_status=stg.user_exit_status,
			txn.execution_date=stg.execution_date,
			txn.is_collection_date_firm=stg.is_collection_date_firm,
			txn.collection_date=stg.collection_date,
			txn.hold_against_book=stg.hold_against_book,
			txn.in_person=stg.in_person,
			txn.void_transaction=stg.void_transaction,
			txn.postponed_amount=stg.postponed_amount,
			txn.offline_status=stg.offline_status,
			txn.call_for_auth_status=stg.call_for_auth_status,
			txn.cash_back_amount=stg.cash_back_amount,
			txn.payment_entry_type=stg.payment_entry_type,
			txn.async_request_identifier=stg.async_request_identifier,
			txn.for_async_request_identifier=stg.for_async_request_identifier,
			txn.reason_code=stg.reason_code,
			txn.createts=stg.createts,
			txn.modifyts=stg.modifyts,
			txn.createuserid=stg.createuserid,
			txn.modifyuserid=stg.modifyuserid,
			txn.createprogid=stg.createprogid,
			txn.modifyprogid=stg.modifyprogid,
			txn.lockid=stg.lockid,
			txn.modified_date= CURRENT_TIMESTAMP()
		WHEN NOT MATCHED 
		THEN
			INSERT     
			(
				charge_transaction_key,
				charge_type,
				transfer_from_oh_key,
				transfer_to_oh_key,
				status,
				credit_amount,
				debit_amount,
				book_amount,
				open_authorized_amount,
				request_amount,
				distributed_amount,
				settled_amount,
				authorization_id,
				authorization_expiration_date,
				order_invoice_key,
				order_header_key,
				payment_key,
				audit_transaction_id,
				user_exit_status,
				execution_date,
				is_collection_date_firm,
				collection_date,
				hold_against_book,
				in_person,
				void_transaction,
				postponed_amount,
				offline_status,
				call_for_auth_status,
				cash_back_amount,
				payment_entry_type,
				async_request_identifier,
				for_async_request_identifier,
				reason_code,
				createts,
				modifyts,
				createuserid,
				modifyuserid,
				createprogid,
				modifyprogid,
				lockid,
				inserted_date
			)
			
			VALUES
			(
				charge_transaction_key,
				charge_type,
				transfer_from_oh_key,
				transfer_to_oh_key,
				status,
				credit_amount,
				debit_amount,
				book_amount,
				open_authorized_amount,
				request_amount,
				distributed_amount,
				settled_amount,
				authorization_id,
				authorization_expiration_date,
				order_invoice_key,
				order_header_key,
				payment_key,
				audit_transaction_id,
				user_exit_status,
				execution_date,
				is_collection_date_firm,
				collection_date,
				hold_against_book,
				in_person,
				void_transaction,
				postponed_amount,
				offline_status,
				call_for_auth_status,
				cash_back_amount,
				payment_entry_type,
				async_request_identifier,
				for_async_request_identifier,
				reason_code,
				createts,
				modifyts,
				createuserid,
				modifyuserid,
				createprogid,
				modifyprogid,
				lockid,
				CURRENT_TIMESTAMP()
			);
			
			INSERT INTO TempChargeTransaction(
				charge_transaction_key,
				charge_type,
				transfer_from_oh_key,
				transfer_to_oh_key,
				status,
				credit_amount,
				debit_amount,
				book_amount,
				open_authorized_amount,
				request_amount,
				distributed_amount,
				settled_amount,
				authorization_id,
				authorization_expiration_date,
				order_invoice_key,
				order_header_key,
				payment_key,
				audit_transaction_id,
				user_exit_status,
				execution_date,
				is_collection_date_firm,
				collection_date,
				hold_against_book,
				in_person,
				void_transaction,
				postponed_amount,
				offline_status,
				call_for_auth_status,
				cash_back_amount,
				payment_entry_type,
				async_request_identifier,
				for_async_request_identifier,
				reason_code,
				createts,
				modifyts,
				createuserid,
				modifyuserid,
				createprogid,
				modifyprogid,
				lockid,
				inserted_date,
				Revision
			) SELECT 
			inserted.charge_transaction_key,
			inserted.charge_type,
			inserted.transfer_from_oh_key,
			inserted.transfer_to_oh_key,
			inserted.status,
			inserted.credit_amount,
			inserted.debit_amount,
			inserted.book_amount,
			inserted.open_authorized_amount,
			inserted.request_amount,
			inserted.distributed_amount,
			inserted.settled_amount,
			inserted.authorization_id,
			inserted.authorization_expiration_date,
			inserted.order_invoice_key,
			inserted.order_header_key,
			inserted.payment_key,
			inserted.audit_transaction_id,
			inserted.user_exit_status,
			inserted.execution_date,
			inserted.is_collection_date_firm,
			inserted.collection_date,
			inserted.hold_against_book,
			inserted.in_person,
			inserted.void_transaction,
			inserted.postponed_amount,
			inserted.offline_status,
			inserted.call_for_auth_status,
			inserted.cash_back_amount,
			inserted.payment_entry_type,
			inserted.async_request_identifier,
			inserted.for_async_request_identifier,
			inserted.reason_code,
			inserted.createts,
			inserted.modifyts,
			inserted.createuserid,
			inserted.modifyuserid,
			inserted.createprogid,
			inserted.modifyprogid,
			inserted.lockid,
			CURRENT_TIMESTAMP(),
			1
			FROM  ANALYTICS.txn_charge_transaction inserted
			WHERE inserted.inserted_date >= :processedDate or inserted.modified_date > :processedDate;

		MERGE INTO TempChargeTransaction AS ttd
USING (
    SELECT
        aot.charge_transaction_key,
        MAX(aot.revision) AS revision
    FROM ANALYTICS.audit_charge_transaction AS aot
    INNER JOIN TempChargeTransaction AS ttd2
        ON ttd2.charge_transaction_key = aot.charge_transaction_key
    GROUP BY aot.charge_transaction_key
) AS aot
ON ttd.charge_transaction_key = aot.charge_transaction_key
WHEN MATCHED THEN
    UPDATE SET
        ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS int);
			
			--Insert audit data    

       MERGE INTO RAW.raw_order_charge_transaction AS roh
USING (
    SELECT distinct stg.charge_transaction_key
    FROM TRANSFORMED.stg_order_charge_transaction AS stg
    INNER JOIN ANALYTICS.txn_charge_transaction AS toh 
        ON toh.charge_transaction_key = stg.charge_transaction_key
) AS join_result
ON roh.charge_transaction_key = join_result.charge_transaction_key
WHEN MATCHED THEN
    UPDATE SET
        roh.processing_status = ''Processed'',
        roh.processing_comment = '''',
        roh.processing_errortype = '''';

		--Insert into audit tables

		INSERT INTO  ANALYTICS.audit_charge_transaction (
				charge_transaction_key,
				charge_type,
				transfer_from_oh_key,
				transfer_to_oh_key,
				status,
				credit_amount,
				debit_amount,
				book_amount,
				open_authorized_amount,
				request_amount,
				distributed_amount,
				settled_amount,
				authorization_id,
				authorization_expiration_date,
				order_invoice_key,
				order_header_key,
				payment_key,
				audit_transaction_id,
				user_exit_status,
				execution_date,
				is_collection_date_firm,
				collection_date,
				hold_against_book,
				in_person,
				void_transaction,
				postponed_amount,
				offline_status,
				call_for_auth_status,
				cash_back_amount,
				payment_entry_type,
				async_request_identifier,
				for_async_request_identifier,
				reason_code,
				createts,
				modifyts,
				createuserid,
				modifyuserid,
				createprogid,
				modifyprogid,
				lockid,
				inserted_date,
				Revision
		)
		SELECT
			stg.charge_transaction_key,
			stg.charge_type,
			stg.transfer_from_oh_key,
			stg.transfer_to_oh_key,
			stg.status,
			stg.credit_amount,
			stg.debit_amount,
			stg.book_amount,
			stg.open_authorized_amount,
			stg.request_amount,
			stg.distributed_amount,
			stg.settled_amount,
			stg.authorization_id,
			stg.authorization_expiration_date,
			stg.order_invoice_key,
			stg.order_header_key,
			stg.payment_key,
			stg.audit_transaction_id,
			stg.user_exit_status,
			stg.execution_date,
			stg.is_collection_date_firm,
			stg.collection_date,
			stg.hold_against_book,
			stg.in_person,
			stg.void_transaction,
			stg.postponed_amount,
			stg.offline_status,
			stg.call_for_auth_status,
			stg.cash_back_amount,
			stg.payment_entry_type,
			stg.async_request_identifier,
			stg.for_async_request_identifier,
			stg.reason_code,
			stg.createts,
			stg.modifyts,
			stg.createuserid,
			stg.modifyuserid,
			stg.createprogid,
			stg.modifyprogid,
			stg.lockid,
			CURRENT_TIMESTAMP(),
			ord.Revision
		FROM TRANSFORMED.stg_order_charge_transaction stg
INNER JOIN TempChargeTransaction ord
ON ord.charge_transaction_key = stg.charge_transaction_key;

 SELECT COUNT(*)
INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_order_charge_transaction;

SELECT COUNT(*)
INTO :processedRecordCount
FROM TempChargeTransaction;

UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = ''Success''
WHERE file_name = ''YFS_CHARGE_TRANSACTION'';

DROP TABLE IF EXISTS TempChargeTransaction;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''upsert completed successfully''
    );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;
RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_INBOX'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';