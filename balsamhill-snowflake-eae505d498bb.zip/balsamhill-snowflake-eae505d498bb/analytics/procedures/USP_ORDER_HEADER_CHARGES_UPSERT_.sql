CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_HEADER_CHARGES_UPSERT_("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
        processedRecordCount NUMBER DEFAULT 0;
        processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );
		

		CREATE OR REPLACE TEMPORARY TABLE TempHeaderCharges (
    header_charges_key VARCHAR ,
    header_key VARCHAR ,
    record_type VARCHAR ,
    charge_category VARCHAR ,
    charge_name VARCHAR ,
    reference VARCHAR ,
    charge FLOAT ,
    invoiced_charge FLOAT ,
    original_charge FLOAT ,
    is_manual VARCHAR ,
    createts TIMESTAMP ,
    modifyts TIMESTAMP ,
    createuserid VARCHAR ,
    modifyuserid VARCHAR ,
    createprogid VARCHAR ,
    modifyprogid VARCHAR ,
    lockid VARCHAR ,
    extn_charge_description VARCHAR ,
    extn_coupon_code VARCHAR ,
    inserted_date TIMESTAMP ,
    modified_date TIMESTAMP ,
    revision INT
);

processedDate := CURRENT_TIMESTAMP();  

		MERGE INTO analytics.txn_order_header_charges AS thc
USING (
    SELECT 
        stg.header_charges_key,
        stg.header_key,
        stg.record_type,
        stg.charge_category,
        stg.charge_name,
        stg.reference,
        TRY_CAST(stg.charge AS FLOAT) AS charge,
        TRY_CAST(stg.invoiced_charge AS FLOAT) AS invoiced_charge,
        TRY_CAST(stg.original_charge AS FLOAT) AS original_charge,
        stg.is_manual,
        TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS') AS createts,
        TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS') AS modifyts,
        stg.createuserid,
        stg.modifyuserid,
        stg.createprogid,
        stg.modifyprogid,
        stg.lockid,
        stg.extn_charge_description,
        stg.extn_coupon_code
    FROM   transformed.stg_order_header_charges AS stg
    INNER JOIN raw.raw_order_header_charges AS r
        ON r.header_charges_key = stg.header_charges_key 
        AND r.modifyts = stg.modifyts 
        AND r.processing_status = 'Processed'
) AS shc
ON 
    thc.header_charges_key = shc.header_charges_key
    AND thc.header_key = shc.header_key
WHEN MATCHED THEN
    UPDATE SET 
        thc.header_charges_key = shc.header_charges_key,
        thc.header_key = shc.header_key,
        thc.record_type = shc.record_type,
        thc.charge_category = shc.charge_category,
        thc.charge_name = shc.charge_name,
        thc.reference = shc.reference,
        thc.charge = shc.charge,
        thc.invoiced_charge = shc.invoiced_charge,
        thc.original_charge = shc.original_charge,
        thc.is_manual = shc.is_manual,
        thc.createts = shc.createts,
        thc.modifyts = shc.modifyts,
        thc.createuserid = shc.createuserid,
        thc.modifyuserid = shc.modifyuserid,
        thc.createprogid = shc.createprogid,
        thc.modifyprogid = shc.modifyprogid,
        thc.lockid = shc.lockid,
        thc.extn_charge_description = shc.extn_charge_description,
        thc.extn_coupon_code = shc.extn_coupon_code,
        thc.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        header_charges_key,
        header_key,
        record_type,
        charge_category,
        charge_name,
        reference,
        charge,
        invoiced_charge,
        original_charge,
        is_manual,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        extn_charge_description,
        extn_coupon_code,
        inserted_date
    )
    VALUES (
        shc.header_charges_key,
        shc.header_key,
        shc.record_type,
        shc.charge_category,
        shc.charge_name,
        shc.reference,
        shc.charge,
        shc.invoiced_charge,
        shc.original_charge,
        shc.is_manual,
        shc.createts,
        shc.modifyts,
        shc.createuserid,
        shc.modifyuserid,
        shc.createprogid,
        shc.modifyprogid,
        shc.lockid,
        shc.extn_charge_description,
        shc.extn_coupon_code,
        CURRENT_TIMESTAMP()
    );

			
			INSERT INTO TempHeaderCharges (
    header_charges_key,
    header_key,
    record_type,
    charge_category,
    charge_name,
    reference,
    charge,
    invoiced_charge,
    original_charge,
    is_manual,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    extn_charge_description,
    extn_coupon_code,
    inserted_date,
    Revision
)
SELECT 
    inserted.header_charges_key,
    inserted.header_key,
    inserted.record_type,
    inserted.charge_category,
    inserted.charge_name,
    inserted.reference,
    inserted.charge,
    inserted.invoiced_charge,
    inserted.original_charge,
    inserted.is_manual,
    inserted.createts,
    inserted.modifyts,
    inserted.createuserid,
    inserted.modifyuserid,
    inserted.createprogid,
    inserted.modifyprogid,
    inserted.lockid,
    inserted.extn_charge_description,
    inserted.extn_coupon_code,
    CURRENT_TIMESTAMP(),
    1
FROM analytics.txn_order_header_charges inserted
WHERE inserted_date >= :processedDate OR modified_date >= :processedDate;

MERGE INTO TempHeaderCharges ttd
USING (
    SELECT
        MAX(aot.revision) AS revision,
        aot.header_charges_key,
        aot.header_key
    FROM analytics.audit_order_header_charges aot
    INNER JOIN TempHeaderCharges ttd
        ON ttd.header_charges_key = aot.header_charges_key
        AND ttd.header_key = aot.header_key
    GROUP BY aot.header_charges_key, aot.header_key
) aot
ON ttd.header_charges_key = aot.header_charges_key
AND ttd.header_key = aot.header_key
WHEN MATCHED THEN
    UPDATE SET
        ttd.Revision = CAST(COALESCE(aot.revision, 0) + 1 AS INT);

			
		  

		--Insert into audit tables

		INSERT INTO analytics.audit_order_header_charges (
    header_charges_key,
    header_key,
    record_type,
    charge_category,
    charge_name,
    reference,
    charge,
    invoiced_charge,
    original_charge,
    is_manual,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    extn_charge_description,
    extn_coupon_code,
    inserted_date,
    Revision
)
SELECT
    stg.header_charges_key,
    stg.header_key,
    stg.record_type,
    stg.charge_category,
    stg.charge_name,
    stg.reference,
    TRY_CAST(stg.charge AS FLOAT) AS charge,
        TRY_CAST(stg.invoiced_charge AS FLOAT) AS invoiced_charge,
        TRY_CAST(stg.original_charge AS FLOAT) AS original_charge,
        stg.is_manual,
        TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS') AS createts,
        TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS') AS modifyts,
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    stg.extn_charge_description,
    stg.extn_coupon_code,
    CURRENT_TIMESTAMP(),
    ord.Revision
FROM transformed.stg_order_header_charges stg
INNER JOIN raw.raw_order_header_charges r
    ON r.header_charges_key = stg.header_charges_key
    AND r.modifyts = stg.modifyts
    AND r.processing_status = 'Processed'
INNER JOIN TempHeaderCharges ord 
    ON ord.header_charges_key = stg.header_charges_key
    AND ord.header_key = stg.header_key;



			SELECT COUNT(*) into :processedRecordCount FROM TempHeaderCharges;

		UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,  -- Replace with the actual value or bind variable
    status = 'Success'
WHERE
    file_name = 'YFS_ORDER_HEADER_CHARGES';

	
		DROP TABLE if exists TempHeaderCharges;
		
	CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);
COMMIT;
   
  RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_HEADER_CHARGES';

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
END;