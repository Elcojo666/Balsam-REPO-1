use schema analytics;

CREATE OR REPLACE PROCEDURE "SP_LOGMICROSERVICEERROR"("ERRORMESSAGE" VARCHAR(16777216), "EXCEPTIONTRACE" VARCHAR(16777216), "METHODNAME" VARCHAR(16777216), "MICROSERVICESNAME" VARCHAR(16777216), "SOURCE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    -- Variables for error handling
    sql_errornumber NUMBER;
    sql_errorstate STRING;
    sql_errorseverity STRING;
    sql_errorline NUMBER;
    sql_errorprocedure STRING;
    sql_errormessage STRING;
BEGIN

SYSTEM$LOG(''TRACE'',''sp_LogMicroserviceError has been started'');
    -- Try block for main logic
    
        INSERT INTO ANALYTICS.log_microservices_errors (
            microservicesname,
            methodname,
            errortime,
            errormessage,
            source,
            exceptiontrace
        ) VALUES (
            :microservicesname,
            :methodname,
            CURRENT_TIMESTAMP(),
            :errormessage,
            :source,
            :exceptiontrace
        );
  COMMIT;
  
  SYSTEM$LOG(''TRACE'',''sp_LogMicroserviceError has been Completed'');

        RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    
SYSTEM$LOG(''ERROR'','' sp_LogMicroserviceError has been Failed'');

            -- Fetch error details
            sql_errornumber := sqlcode;
            sql_errormessage := sqlerrm;
            
            -- Note: Snowflake does not provide specific functions for error state, severity, line, and procedure
            sql_errorstate := NULL;
            sql_errorseverity := NULL;
            sql_errorline := NULL;
            sql_errorprocedure := NULL;
            
            -- Log error details
            INSERT INTO ANALYTICS.log_microservices_errors (
                microservicesname,
                methodname,
                errortime,
                errormessage,
                source,
                exceptiontrace,
                sql_errornumber,
                sql_errorstate,
                sql_errorseverity,
                sql_errorline,
                sql_errorprocedure,
                sql_errormessage
            ) VALUES (
                :microservicesname,
                :methodname,
                CURRENT_TIMESTAMP(),
                :errormessage,
                :source,
                :exceptiontrace,
                :sql_errornumber,
                :sql_errorstate,
                :sql_errorseverity,
                :sql_errorline,
                :sql_errorprocedure,
                :sql_errormessage
            );
            
            RETURN ''Error: '' || :sql_errormessage;
    
END';