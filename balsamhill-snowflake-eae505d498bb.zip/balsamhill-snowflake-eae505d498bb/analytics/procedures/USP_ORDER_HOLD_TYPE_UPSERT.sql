
CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_HOLD_TYPE_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status 
SET processed = :processedRecordCount,
    raw_table = 'raw_order_hold_type'    
WHERE file_name = 'YFS_ORDER_HOLD_TYPE';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

CREATE OR REPLACE TEMPORARY TABLE TempOrderHoldType (
    ORDER_HOLD_TYPE_KEY STRING,
    ORDER_HEADER_KEY STRING,
    ORDER_LINE_KEY STRING,
    HOLD_TYPE STRING,
    LAST_HOLD_TYPE_DATE TIMESTAMP_NTZ(9),
    REASON_TEXT STRING,
    TRANSACTION_ID STRING,
    ORDER_AUDIT_KEY STRING,
    STATUS STRING,
    RESOLVER_USER_ID STRING,
    CREATETS TIMESTAMP_NTZ(9),
    MODIFYTS TIMESTAMP_NTZ(9),
    CREATEUSERID STRING,
    MODIFYUSERID STRING,
    CREATEPROGID STRING,
    MODIFYPROGID STRING,
    LOCKID STRING,
    inserted_date TIMESTAMP_NTZ(9),
    modified_date TIMESTAMP_NTZ(9),
    revision INT
);

processedDate := CURRENT_TIMESTAMP();

-- Using MERGE in Snowflake
MERGE INTO ANALYTICS.txn_order_hold_type AS tht
USING (
    SELECT
        ORDER_HOLD_TYPE_KEY,
        ORDER_HEADER_KEY,
        ORDER_LINE_KEY,
        HOLD_TYPE,
        LAST_HOLD_TYPE_DATE,
        REASON_TEXT,
        TRANSACTION_ID,
        ORDER_AUDIT_KEY,
        STATUS,
        RESOLVER_USER_ID,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID
    FROM TRANSFORMED.stg_order_hold_type AS stg
) AS sht
ON tht.ORDER_HOLD_TYPE_KEY = sht.ORDER_HOLD_TYPE_KEY
AND tht.ORDER_HEADER_KEY = sht.ORDER_HEADER_KEY
--AND tht.ORDER_LINE_KEY = sht.ORDER_LINE_KEY
WHEN MATCHED THEN
    UPDATE SET
        tht.ORDER_HOLD_TYPE_KEY = sht.ORDER_HOLD_TYPE_KEY,
        tht.ORDER_HEADER_KEY = sht.ORDER_HEADER_KEY,
        tht.ORDER_LINE_KEY = sht.ORDER_LINE_KEY,
        tht.HOLD_TYPE = sht.HOLD_TYPE,
        tht.LAST_HOLD_TYPE_DATE = TRY_TO_TIMESTAMP(sht.LAST_HOLD_TYPE_DATE,'YYYYMMDDHHMISS'),
        tht.REASON_TEXT = sht.REASON_TEXT,
        tht.TRANSACTION_ID = sht.TRANSACTION_ID,
        tht.ORDER_AUDIT_KEY = sht.ORDER_AUDIT_KEY,
        tht.STATUS = sht.STATUS,
        tht.RESOLVER_USER_ID = sht.RESOLVER_USER_ID,
        tht.CREATETS = TRY_TO_TIMESTAMP(sht.createts,'YYYYMMDDHHMISS'),
        tht.MODIFYTS = TRY_TO_TIMESTAMP(sht.modifyts,'YYYYMMDDHHMISS'),
        tht.CREATEUSERID = sht.CREATEUSERID,
        tht.MODIFYUSERID = sht.MODIFYUSERID,
        tht.CREATEPROGID = sht.CREATEPROGID,
        tht.MODIFYPROGID = sht.MODIFYPROGID,
        tht.LOCKID = sht.LOCKID,
        tht.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        ORDER_HOLD_TYPE_KEY,
        ORDER_HEADER_KEY,
        ORDER_LINE_KEY,
        HOLD_TYPE,
        LAST_HOLD_TYPE_DATE,
        REASON_TEXT,
        TRANSACTION_ID,
        ORDER_AUDIT_KEY,
        STATUS,
        RESOLVER_USER_ID,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID,
        inserted_date
    )
    VALUES (
        sht.ORDER_HOLD_TYPE_KEY,
        sht.ORDER_HEADER_KEY,
        sht.ORDER_LINE_KEY,
        sht.HOLD_TYPE,
        TRY_TO_TIMESTAMP(sht.LAST_HOLD_TYPE_DATE,'YYYYMMDDHHMISS'),
        sht.REASON_TEXT,
        sht.TRANSACTION_ID,
        sht.ORDER_AUDIT_KEY,
        sht.STATUS,
        sht.RESOLVER_USER_ID,
        TRY_TO_TIMESTAMP(sht.createts,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(sht.modifyts,'YYYYMMDDHHMISS'),
        sht.CREATEUSERID,
        sht.MODIFYUSERID,
        sht.CREATEPROGID,
        sht.MODIFYPROGID,
        sht.LOCKID,
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempOrderHoldType (
    ORDER_HOLD_TYPE_KEY,
    ORDER_HEADER_KEY,
    ORDER_LINE_KEY,
    HOLD_TYPE,
    LAST_HOLD_TYPE_DATE,
    REASON_TEXT,
    TRANSACTION_ID,
    ORDER_AUDIT_KEY,
    STATUS,
    RESOLVER_USER_ID,
    CREATETS,
    MODIFYTS,
    CREATEUSERID,
    MODIFYUSERID,
    CREATEPROGID,
    MODIFYPROGID,
    LOCKID,
    inserted_date,
    Revision
)
SELECT
    ORDER_HOLD_TYPE_KEY,
    ORDER_HEADER_KEY,
    ORDER_LINE_KEY,
    HOLD_TYPE,
    LAST_HOLD_TYPE_DATE,
    REASON_TEXT,
    TRANSACTION_ID,
    ORDER_AUDIT_KEY,
    STATUS,
    RESOLVER_USER_ID,
    CREATETS,
    MODIFYTS,
    CREATEUSERID,
    MODIFYUSERID,
    CREATEPROGID,
    MODIFYPROGID,
    LOCKID,
    CURRENT_TIMESTAMP(), -- Replacing GETDATE() with CURRENT_TIMESTAMP() for Snowflake
    1
FROM
    ANALYTICS.txn_order_hold_type tcd
WHERE tcd.inserted_date >= :processedDate or tcd.modified_date >= :processedDate
    -- Add conditions if needed, otherwise, this will insert all records
;

CREATE OR REPLACE TEMPORARY TABLE TempMaxRevisions AS
SELECT
    MAX(aot.revision) AS revision,
    aot.ORDER_HOLD_TYPE_KEY,
    aot.ORDER_HEADER_KEY,
    aot.ORDER_LINE_KEY
FROM ANALYTICS.audit_order_hold_type AS aot
INNER JOIN TempOrderHoldType AS ttd
ON ttd.ORDER_HOLD_TYPE_KEY = aot.ORDER_HOLD_TYPE_KEY
AND ttd.ORDER_HEADER_KEY = aot.ORDER_HEADER_KEY
--AND ttd.ORDER_LINE_KEY = aot.ORDER_LINE_KEY
GROUP BY
    aot.ORDER_HOLD_TYPE_KEY, aot.ORDER_HEADER_KEY, aot.ORDER_LINE_KEY;

UPDATE TempOrderHoldType AS ttd
SET ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
FROM TempMaxRevisions AS aot
WHERE  ttd.ORDER_HOLD_TYPE_KEY = aot.ORDER_HOLD_TYPE_KEY
AND ttd.ORDER_HEADER_KEY = aot.ORDER_HEADER_KEY
--AND ttd.ORDER_LINE_KEY = aot.ORDER_LINE_KEY
;

UPDATE RAW.raw_order_hold_type AS roh
SET
    processing_status = 'Processed',
    processing_comment = '',
    processing_errortype = ''
FROM (
    SELECT
        roh.ORDER_HOLD_TYPE_KEY,
        roh.ORDER_HEADER_KEY
    FROM
        RAW.raw_order_hold_type AS roh
    INNER JOIN
        TRANSFORMED.stg_order_hold_type AS stg ON stg.ORDER_HOLD_TYPE_KEY = roh.ORDER_HOLD_TYPE_KEY
        AND stg.ORDER_HEADER_KEY = roh.ORDER_HEADER_KEY
        --AND stg.ORDER_LINE_KEY = roh.ORDER_LINE_KEY
    INNER JOIN
        ANALYTICS.txn_order_hold_type AS toh ON toh.ORDER_HOLD_TYPE_KEY = stg.ORDER_HOLD_TYPE_KEY
        AND toh.ORDER_HEADER_KEY = stg.ORDER_HEADER_KEY
        --AND toh.ORDER_LINE_KEY = stg.ORDER_LINE_KEY
) AS subquery
WHERE
    roh.ORDER_HOLD_TYPE_KEY = subquery.ORDER_HOLD_TYPE_KEY
    AND roh.ORDER_HEADER_KEY = subquery.ORDER_HEADER_KEY;

INSERT INTO ANALYTICS.audit_order_hold_type (
    ORDER_HOLD_TYPE_KEY,
    ORDER_HEADER_KEY,
    ORDER_LINE_KEY,
    HOLD_TYPE,
    LAST_HOLD_TYPE_DATE,
    REASON_TEXT,
    TRANSACTION_ID,
    ORDER_AUDIT_KEY,
    STATUS,
    RESOLVER_USER_ID,
    CREATETS,
    MODIFYTS,
    CREATEUSERID,
    MODIFYUSERID,
    CREATEPROGID,
    MODIFYPROGID,
    LOCKID,
    inserted_date,
    Revision
)
SELECT
    stg.ORDER_HOLD_TYPE_KEY,
    stg.ORDER_HEADER_KEY,
    stg.ORDER_LINE_KEY,
    stg.HOLD_TYPE,
    TRY_TO_TIMESTAMP(stg.LAST_HOLD_TYPE_DATE,'YYYYMMDDHHMISS'),
    stg.REASON_TEXT,
    stg.TRANSACTION_ID,
    stg.ORDER_AUDIT_KEY,
    stg.STATUS,
    stg.RESOLVER_USER_ID,
    TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS'),
    stg.CREATEUSERID,
    stg.MODIFYUSERID,
    stg.CREATEPROGID,
    stg.MODIFYPROGID,
    stg.LOCKID,
    CURRENT_TIMESTAMP(),
    ord.Revision
FROM TRANSFORMED.stg_order_hold_type stg
INNER JOIN TempOrderHoldType ord ON ord.ORDER_HOLD_TYPE_KEY = stg.ORDER_HOLD_TYPE_KEY
    AND ord.ORDER_HEADER_KEY = stg.ORDER_HEADER_KEY
    --AND ord.ORDER_LINE_KEY = stg.ORDER_LINE_KEY
    ;

SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM TRANSFORMED.stg_order_hold_type;
SELECT COUNT(*) INTO :processedRecordCount FROM TempOrderHoldType;

UPDATE analytics.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = 'Success'
WHERE
    file_name = 'YFS_ORDER_HOLD_TYPE';

-- Dropping the temporary table
DROP TABLE IF EXISTS TempOrderHoldType;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

COMMIT;
RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_ORDER_HOLD_TYPE';
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	
	RETURN error_object;
END;