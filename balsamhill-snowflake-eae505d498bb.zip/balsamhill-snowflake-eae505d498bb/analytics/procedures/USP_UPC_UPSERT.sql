USE DATABASE DEV;

CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.USP_UPC_UPSERT()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
 message STRING;
 FinalStatus BOOLEAN;
 ErrorCount INT;
 UpcErrorMsg STRING DEFAULT ''UPC [ERRORUPC] belongs to multiple SKU'';
 temp_tabCount BIGINT;
 mapupcProcessedCount BIGINT;
 input_file_id NUMBER DEFAULT 111; 
BEGIN 
 
CREATE OR REPLACE TEMPORARY TABLE RAW_CARTONS_RANKED AS 
SELECT 
    *,
    ROW_NUMBER() OVER (
        PARTITION BY Box_Carton_UPC
        ORDER BY Year DESC, COALESCE(YEAR_VERSION,0) DESC, INSERTED_DATE DESC, LANGUAGE
    ) AS upc_rank
FROM RAW.RAW_PRODUCT_CARTON;

-- CREATE TEMP TABLE AS WITH 
MERGE INTO ANALYTICS.UPC AS tgt
USING (
    SELECT DISTINCT
        R.Box_Carton_UPC,
        R.Carton_Height,
        R.Carton_Length,
        R.Carton_Width,
        R.Carton_Weight,
        R.Refurbished_Product,
        R.Year,
        R.Carton_Number,
        R.Sellable_Qty_In_Carton AS quantity_in_carton,
        R.Carton_Total_Count,
        R.Is_Masterpack,
        R.FedEx_Freight,
        R.FILESOURCEID,
        R.YEAR_VERSION,
        R.SAP_NO,
        R.UPC_BUNDLE_ID,
    FROM RAW_CARTONS_RANKED R
    WHERE R.upc_rank = 1 -- only keep the latest year data
      AND R.Box_Carton_UPC IS NOT NULL
      AND R.Box_Carton_UPC <> ''#N/A''
) AS src
ON tgt.upc_code = src.Box_Carton_UPC
WHEN MATCHED THEN
    UPDATE SET 
        tgt.height = COALESCE(src.Carton_Height::FLOAT, 0.0),    
        tgt.length = COALESCE(src.Carton_Length::FLOAT, 0.0),    
        tgt.width = COALESCE(src.Carton_Width::FLOAT, 0.0),    
        tgt.weight = COALESCE(src.Carton_Weight::FLOAT, 0.0),      
        tgt.inner_upc = src.Box_Carton_UPC,    
        tgt.active_flag = 1,    
        tgt.last_updated_date = CURRENT_TIMESTAMP,    
        tgt.is_rtp = CASE WHEN Lower(src.Refurbished_Product) = ''yes'' THEN 1 ELSE 0 END, 
        tgt.upc_year = RIGHT(src.Year, 4)::NUMBER,     
        tgt.lotcode = RIGHT(src.Year, 2),   
        tgt.warrantylotcode = RIGHT(src.Year, 2),    
        tgt.cartonnumber = src.Carton_Number::NUMBER,    
        tgt.quantityincarton = src.quantity_in_carton::NUMBER,    
        tgt.totalcartons = src.Carton_Total_Count::NUMBER,    
        tgt.is_masterpack = CASE WHEN Lower(src.Is_Masterpack) = ''yes'' THEN 1 ELSE 0 END,    
        tgt.IsFedExFreight = CASE WHEN Lower(src.FedEx_Freight) = ''yes'' THEN 1 ELSE 0 END,
        tgt.FK_FILESOURCEID = src.FILESOURCEID,
        TGT.YEAR_VERSION = COALESCE(SRC.YEAR_VERSION,0),
        TGT.SAP_NO = SRC.SAP_NO,
        TGT.UPC_BUNDLE_ID = SRC.UPC_BUNDLE_ID
WHEN NOT MATCHED THEN 
    INSERT (
    upc_code
    , height
    , length
    , width
    , weight
    , cubicfeetperitem
    , inner_upc
    , active_flag
    , last_updated_date
    , is_rtp
    , is_ltl
    , upc_year
    , lotcode
    , warrantylotcode
    , cartonnumber
    , quantityincarton
    , totalcartons
    , is_masterpack
    , IsFedExFreight
    , is_tree
    , active
    , upc_type
    , inserted_date 
    , FK_FILESOURCEID
    , YEAR_VERSION
    , SAP_NO
    , UPC_BUNDLE_ID
)
VALUES (
    src.Box_Carton_UPC
    , TRY_CAST(src.Carton_Height AS FLOAT)
    , TRY_CAST(src.Carton_Length AS FLOAT)
    , TRY_CAST(src.Carton_Width AS FLOAT)
    , TRY_CAST(src.Carton_Weight AS FLOAT)
    , NULL
    , src.Box_Carton_UPC
    , 1
    , CURRENT_TIMESTAMP()
    , CASE WHEN LOWER(src.Refurbished_Product) = ''yes'' THEN 1 ELSE 0 END
    , NULL
    , TRY_CAST(RIGHT(src.Year, 4) AS NUMBER)
    , RIGHT(src.Year::STRING, 2)
    , RIGHT(src.Year::STRING, 2)
    , TRY_CAST(src.Carton_Number AS NUMBER)
    , TRY_CAST(src.quantity_in_carton AS NUMBER)
    , TRY_CAST(src.Carton_Total_Count AS NUMBER)
    , CASE WHEN LOWER(src.Is_Masterpack) = ''yes'' THEN 1 ELSE 0 END
    , CASE WHEN LOWER(src.FedEx_Freight) = ''yes'' THEN 1 ELSE 0 END
    , NULL 
    , 1
    , ''child''
    , CURRENT_TIMESTAMP()
    , src.FILESOURCEID
    , COALESCE(SRC.YEAR_VERSION,0)
    , SRC.SAP_NO
    , SRC.UPC_BUNDLE_ID
)
;

-- Business validation logic
CREATE OR REPLACE TEMPORARY TABLE temp_tab AS
    SELECT DISTINCT skp.pk_skuproductid, up.pk_upcid, pe.SKU, cd.Box_Carton_UPC 
    FROM RAW.RAW_PRODUCT_CARTON cd
    INNER JOIN RAW.RAW_PRODUCT_PRODUCT pe ON cd.External_Key = pe.External_Key AND cd.Language = pe.Language
    INNER JOIN ANALYTICS.SKU_PRODUCT_LOCALE skp ON pe.SKU = skp.sku_code AND pe.Language = skp.locale
    INNER JOIN ANALYTICS.UPC up ON cd.Box_Carton_UPC = up.upc_code
    WHERE cd.Box_Carton_UPC IS NOT NULL
;
    
SELECT COUNT(*) INTO :temp_tabCount FROM temp_tab;

DELETE FROM ANALYTICS.MAP_SKU_UPC
WHERE FK_UPCID IN (SELECT pk_upcid FROM temp_tab);

INSERT INTO ANALYTICS.map_sku_upc (
    fk_productid, fk_upcid, upc_type, active_flag, inserted_date, last_updated_date, group_number, group_quantity
)
SELECT DISTINCT
    src.pk_skuproductid, src.pk_upcid, ''child'', 1, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), NULL, NULL
FROM temp_tab src;

INSERT INTO TRANSFORMED.log_inputsheet  
(fk_inputfileid,  
 source_sheet_name,  
 rejection_reason,  
 source_record_count,  
 staging_record_count,  
 validationerror,  
 is_rejected)  
 VALUES    
       (    
   :input_file_id,    
         ''Raw To Dim Transformation - map_skuupc'',    
         '''',    
         :temp_tabCount,    
         :temp_tabCount,    
         '''',    
         ''0'');  

RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;

    INSERT INTO TRANSFORMED.log_inputsheet  
    (fk_inputfileid,  
     source_sheet_name,  
     rejection_reason,  
     source_record_count,  
     staging_record_count,  
     validationerror,  
     is_rejected)  
VALUES  
    (  
      :input_file_id,  
      ''Raw To Dim Transformation - SKUProduct'',  
      ''error'',  
      :temp_tabCount,  
      ''0'',  
      ''error'',  
      ''1''  
    );

END';
