/**
 * Procedure Name: analytics.usp_klaviyo_back_in_stock_upsert
 *
 * Description:
 * This stored procedure performs an upsert operation on the `txn_klaviyo_back_in_stock_subscriptions` table using data from the staging table `stg_klaviyo_back_in_stock_events`.
 *
 * Parameters:
 * - pipeline_name (VARCHAR): The name of the pipeline. Default is 'klaviyo_back_in_stock'.
 *
 * Returns:
 * - VARCHAR: A message indicating the success or failure of the procedure.
 *
 * Execution Flow:
 * 1. Logs the start of the procedure.
 * 2. Logs the start of the upsert process.
 * 3. Merges data from the staging table into the target table.
 * 4. Deletes processed events from the staging table.
 * 5. Logs the completion of the upsert process.
 * 6. Commits the transaction.
 * 7. Handles any exceptions by rolling back the transaction, logging the error, and returning the error object.
 * 8. Logs the completion of the procedure.
 * 9. Returns a message indicating the success of the procedure.
 */
CREATE PROCEDURE analytics.usp_klaviyo_back_in_stock_upsert(pipeline_name VARCHAR DEFAULT 'klaviyo_back_in_stock')
    RETURNS VARCHAR
    LANGUAGE SQL
    EXECUTE AS OWNER
AS
DECLARE
    pipeline_stage_name VARCHAR := 'upsert';
    start_time          TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    completed_message   VARCHAR;
    error_object        VARIANT;
BEGIN
    SYSTEM$LOG('TRACE', 'SP STARTED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'started',
            :start_time,
            NULL,
            'Upsert started');

    BEGIN
        MERGE INTO analytics.txn_klaviyo_back_in_stock_subscriptions AS target
            USING transformed.stg_klaviyo_back_in_stock_events AS source
            ON target.klaviyo_event_id = source.klaviyo_event_id AND target.fk_brandid = source.fk_brandid
            WHEN MATCHED THEN
                UPDATE SET target.sku = source.sku,
                    target.email = source.email,
                    target.datetime = source.datetime,
                    target.updated_at = CURRENT_TIMESTAMP()
            WHEN NOT MATCHED THEN
                INSERT (klaviyo_event_id, sku, email, datetime, fk_brandid)
                    VALUES (source.klaviyo_event_id, source.sku, source.email, source.datetime, source.fk_brandid);

        DELETE
        FROM transformed.stg_klaviyo_back_in_stock_events
        WHERE EXISTS(SELECT 1
                     FROM analytics.txn_klaviyo_back_in_stock_subscriptions AS target
                     WHERE target.klaviyo_event_id = transformed.stg_klaviyo_back_in_stock_events.klaviyo_event_id
                       AND target.fk_brandid = transformed.stg_klaviyo_back_in_stock_events.fk_brandid
                       AND target.updated_at >= :start_time);

        LET
        loaded_events_count VARCHAR := (SELECT COUNT(1)
                                        FROM analytics.txn_klaviyo_back_in_stock_subscriptions
                                        WHERE updated_at >= :start_time);

        completed_message := 'Upsert completed successfully. ' || 'Upserted events: ' || :loaded_events_count;

        COMMIT;
    EXCEPTION
        WHEN statement_error THEN
            ROLLBACK;

            SYSTEM$LOG('ERROR', 'SP FAILED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

            DELETE
            FROM analytics.txn_klaviyo_back_in_stock_subscriptions
            WHERE created_at >= :start_time;

            error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                             'SQLCODE', sqlcode,
                                             'SQLERRM', sqlerrm,
                                             'SQLSTATE', sqlstate);

            CALL transformed.insert_into_log_pipeline_tasks_execution_details(
                    :pipeline_name,
                    :pipeline_stage_name,
                    'failed',
                    :start_time,
                    CURRENT_TIMESTAMP(),
                    TO_JSON(:error_object));

            RETURN error_object;
    END;


    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'completed',
            :start_time,
            CURRENT_TIMESTAMP(),
            :completed_message);

    SYSTEM$LOG('TRACE', 'SP COMPLETED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

    RETURN :completed_message;
END;

ALTER PROCEDURE analytics.usp_klaviyo_back_in_stock_upsert(varchar) SET LOG_LEVEL=TRACE;
ALTER PROCEDURE analytics.usp_klaviyo_back_in_stock_upsert(varchar) SET TRACE_LEVEL=ALWAYS;