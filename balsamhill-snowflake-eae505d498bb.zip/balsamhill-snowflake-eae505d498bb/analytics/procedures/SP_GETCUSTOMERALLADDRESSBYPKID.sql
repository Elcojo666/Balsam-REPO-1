use database dev;

CREATE OR REPLACE PROCEDURE ANALYTICS.SP_GETCUSTOMERALLADDRESSBYPKID("PK_CUSTOMERID" NUMBER(38,0))
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    pk_customer_info_id STRING;
    message STRING;
    sql_errornumber string;
    sql_errormessage string;

BEGIN
    -- Attempt to execute the main logic
   SYSTEM$LOG(''TRACE'','' sp_GetCustomerAllAddressByPkId has been Started'');
 
        -- Retrieve PK_CUSTOMER_INFO_ID from dim_customer_info table
        pk_customer_info_id := (SELECT dci.PK_CUSTOMER_INFO_ID
                                FROM analytics.customer_info dci
                                WHERE dci.FK_CUSTOMERID = :pk_customerid);

        -- Check if the customer info ID is found
        IF ((:pk_customer_info_id IS NULL OR :pk_customer_info_id = '''')) THEN
        
            LET results resultset := (
                SELECT NULL AS pk_customerid, NULL AS pk_customer_address_id, NULL AS fk_customer_info_id, 
                       ''WARNING: '' || :pk_customerid || '' Customer not found'' AS message, ''Failed'' AS status);
            RETURN TABLE(results);
        ELSE
            -- Return customer address details if found
            
            LET results resultset := (
                SELECT :pk_customerid AS pk_customerid, 
                       dca.*, 
                       ''Record Found'' AS message, ''Success'' AS status
                FROM analytics.customer_address dca
                WHERE dca.FK_CUSTOMER_INFO_ID = :pk_customer_info_id);

                RETURN TABLE(results);
        END IF;
SYSTEM$LOG(''TRACE'','' sp_GetCustomerAllAddressByPkId has been Completed'');

    -- Handle any exceptions and log them
    EXCEPTION WHEN statement_error THEN
        ROLLBACK;
   SYSTEM$LOG(''ERROR'','' sp_GetCustomerAllAddressByPkId has been Failed'');

        sql_errornumber := sqlcode;
        sql_errormessage := sqlerrm;;
        -- Log the error details into the log table
        INSERT INTO ANALYTICS.log_microservices_errors(
            microservicesname,  
            methodname,  
            errortime,  
            errormessage,  
            source,  
            exceptiontrace,  
            sql_errornumber,  
            sql_errorstate,  
            sql_errorseverity,  
            sql_errorline,  
            sql_errorprocedure,  
            sql_errormessage
        )
        VALUES(
            ''CustomerApi'',  
            ''GetCustomerAllAddressByPkId'',  
            CURRENT_TIMESTAMP(),  
            ''Error in SQL'',  
            NULL,  
            NULL,  
            :sql_errornumber,  
            NULL,  
            NULL,  
            NULL,  
            NULL,  
            :sql_errormessage
        );
        
        -- Return the error message
        LET results resultset := (
            SELECT NULL AS pk_customerid, NULL AS pk_customer_address_id, NULL AS fk_customer_info_id, 
                   ''Error occurred while processing'' AS message, ''Failed'' AS status
        );
        RETURN TABLE(results);
    
END';