USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.SP_NOTIFY_EMAIL_STORAGE()
RETURNS STRING 
LANGUAGE SQL 
AS 
BEGIN
LET email_integration_name varchar :=  (select distinct integration_name from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Storage' and environment='dev'  limit 1);
    
    LET email_list varchar :=  (select LISTAGG(distinct recipient,',') from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Storage' and environment='dev');
    
    let email_subject varchar := (select DISTINCT subject_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Storage' and environment='dev' limit 1);
    
    let email_body_default  varchar := (select DISTINCT body_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Storage' and environment='dev' limit 1);
    
    LET email_body varchar := (SELECT CEIL((SUM(STORAGE_BYTES)/1024/1024/1024), 2) AS STORAGE_GB
                                FROM "SNOWFLAKE"."ACCOUNT_USAGE"."STORAGE_USAGE");
    
    CALL SYSTEM$SEND_EMAIL(
                :email_integration_name,
                :email_list,
                :email_subject,
                :email_body_default ||'\n\n'|| 'Total ' || :email_body || ' GB Stored.');
    return 'Email Alert Sent';
END;
