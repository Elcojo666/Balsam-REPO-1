USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_CLEAN_DUPLICATE_RAW_ENTRIES()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN

---raw_ORDER_gtin_data

create or replace temporary table raw.raw_ORDER_gtin_data_temp as 
select *  FROM raw.raw_ORDER_gtin_data
WHERE (gtin_key, modifyts) IN (
    SELECT gtin_key, modifyts
    FROM (
        SELECT 
            gtin_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY gtin_key, modifyts ORDER BY gtin_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_gtin_data
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed'');

DELETE FROM raw.raw_ORDER_gtin_data
WHERE (gtin_key, modifyts) IN (
    SELECT gtin_key, modifyts
    FROM (
        SELECT 
            gtin_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY gtin_key, modifyts ORDER BY gtin_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_gtin_data
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed'');

    insert into raw.raw_ORDER_gtin_data
    select * from  raw.raw_ORDER_gtin_data_temp
    qualify ROW_NUMBER() OVER (PARTITION BY gtin_key, modifyts ORDER BY gtin_key, modifyts, processing_status DESC)=1;
    

    --raw_ORDER_header_charges

    create or replace temporary table  raw.raw_ORDER_header_charges_temp as 
    select * from raw.raw_ORDER_header_charges 
WHERE (header_charges_key, modifyts) IN (
    SELECT header_charges_key, modifyts
    FROM (
        SELECT 
            header_charges_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY header_charges_key, modifyts ORDER BY header_charges_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_header_charges
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);
    
DELETE FROM raw.raw_ORDER_header_charges
WHERE (header_charges_key, modifyts) IN (
    SELECT header_charges_key, modifyts
    FROM (
        SELECT 
            header_charges_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY header_charges_key, modifyts ORDER BY header_charges_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_header_charges
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_header_charges
select * from raw.raw_ORDER_header_charges_temp
qualify ROW_NUMBER() OVER (PARTITION BY header_charges_key, modifyts ORDER BY header_charges_key, modifyts, processing_status DESC)=1;

--raw_ORDER_inbox
create or replace temporary table raw.raw_ORDER_inbox_temp as 
select * from raw.raw_ORDER_inbox
WHERE (INBOX_KEY, modifyts) IN (
    SELECT INBOX_KEY, modifyts
    FROM (
        SELECT 
            INBOX_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY INBOX_KEY, modifyts ORDER BY INBOX_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_inbox
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_inbox
WHERE (INBOX_KEY, modifyts) IN (
    SELECT INBOX_KEY, modifyts
    FROM (
        SELECT 
            INBOX_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY INBOX_KEY, modifyts ORDER BY INBOX_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_inbox
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_inbox
select * from raw.raw_ORDER_inbox_temp
qualify ROW_NUMBER() OVER (PARTITION BY INBOX_KEY, modifyts ORDER BY INBOX_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_line_charges 
create or replace temporary table raw.raw_ORDER_line_charges_temp as 
select *  FROM raw.raw_ORDER_line_charges
WHERE (line_charges_key, modifyts) IN (
    SELECT line_charges_key, modifyts
    FROM (
        SELECT 
            line_charges_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY line_charges_key, modifyts ORDER BY line_charges_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_line_charges
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_line_charges
WHERE (line_charges_key, modifyts) IN (
    SELECT line_charges_key, modifyts
    FROM (
        SELECT 
            line_charges_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY line_charges_key, modifyts ORDER BY line_charges_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_line_charges
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_line_charges
select * from raw.raw_ORDER_line_charges_temp
qualify ROW_NUMBER() OVER (PARTITION BY line_charges_key, modifyts ORDER BY line_charges_key, modifyts, processing_status DESC)=1;

--raw_ORDER_header

create or replace temporary table raw.raw_ORDER_header_temp as 
select * from  raw.raw_ORDER_header
WHERE (ORDER_HEADER_KEY, modifyts) IN (
    SELECT ORDER_HEADER_KEY, modifyts
    FROM (
        SELECT 
            ORDER_HEADER_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_HEADER_KEY, modifyts ORDER BY ORDER_HEADER_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_header
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_header
WHERE (ORDER_HEADER_KEY, modifyts) IN (
    SELECT ORDER_HEADER_KEY, modifyts
    FROM (
        SELECT 
            ORDER_HEADER_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_HEADER_KEY, modifyts ORDER BY ORDER_HEADER_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_header
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_header
select * from raw.raw_ORDER_header_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_HEADER_KEY, modifyts ORDER BY ORDER_HEADER_KEY, modifyts, processing_status DESC)=1;


--raw_ORDER_line
create or replace temporary table raw.raw_ORDER_line_temp as 
select * FROM raw.raw_ORDER_line
WHERE (ORDER_LINE_KEY, modifyts) IN (
    SELECT ORDER_LINE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_LINE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_LINE_KEY, modifyts ORDER BY ORDER_LINE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_line
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_line
WHERE (ORDER_LINE_KEY, modifyts) IN (
    SELECT ORDER_LINE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_LINE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_LINE_KEY, modifyts ORDER BY ORDER_LINE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_line
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_line
select * from raw.raw_ORDER_line_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_LINE_KEY, modifyts ORDER BY ORDER_LINE_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_release_status

create or replace temporary table raw.raw_ORDER_release_status_temp
 as select * FROM raw.raw_ORDER_release_status
WHERE (ORDER_RELEASE_STATUS_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_STATUS_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_STATUS_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release_status
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_release_status
WHERE (ORDER_RELEASE_STATUS_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_STATUS_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_STATUS_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release_status
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);


insert into raw.raw_ORDER_release_status
select * from raw.raw_ORDER_release_status_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_release_status_part2

create or replace temporary table raw.raw_ORDER_release_status_part2_temp
 as select * FROM raw.raw_ORDER_release_status_part2
WHERE (ORDER_RELEASE_STATUS_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_STATUS_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_STATUS_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release_status_part2
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_release_status_part2
WHERE (ORDER_RELEASE_STATUS_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_STATUS_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_STATUS_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release_status_part2
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_release_status_part2
select * from raw.raw_ORDER_release_status_part2_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_STATUS_KEY, modifyts ORDER BY ORDER_RELEASE_STATUS_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_release

create or replace temporary table raw.raw_ORDER_release_temp
 as select * FROM raw.raw_ORDER_release
WHERE (ORDER_RELEASE_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_KEY, modifyts ORDER BY ORDER_RELEASE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_release
WHERE (ORDER_RELEASE_KEY, modifyts) IN (
    SELECT ORDER_RELEASE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_RELEASE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_KEY, modifyts ORDER BY ORDER_RELEASE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_release
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_release
select * from raw.raw_ORDER_release_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_RELEASE_KEY, modifyts ORDER BY ORDER_RELEASE_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_payment

create or replace temporary table raw.raw_ORDER_payment_temp 
 as select * FROM raw.raw_ORDER_payment
WHERE (payment_key, modifyts) IN (
    SELECT payment_key, modifyts
    FROM (
        SELECT 
            payment_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY payment_key, modifyts ORDER BY payment_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_payment
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_payment
WHERE (payment_key, modifyts) IN (
    SELECT payment_key, modifyts
    FROM (
        SELECT 
            payment_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY payment_key, modifyts ORDER BY payment_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_payment
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_payment
select * from raw.raw_ORDER_payment_temp
qualify ROW_NUMBER() OVER (PARTITION BY payment_key, modifyts ORDER BY payment_key, modifyts, processing_status DESC)=1;

--raw_ORDER_person_info

create or replace temporary table raw.raw_ORDER_person_info_temp 
 as select * FROM raw.raw_ORDER_person_info
WHERE (person_info_key, modifyts) IN (
    SELECT person_info_key, modifyts
    FROM (
        SELECT 
            person_info_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_person_info
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_person_info
WHERE (person_info_key, modifyts) IN (
    SELECT person_info_key, modifyts
    FROM (
        SELECT 
            person_info_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_person_info
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_person_info
select * from raw.raw_ORDER_person_info_temp 
qualify ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC)=1;

--raw_ORDER_shipment_container

create or replace temporary table raw.raw_ORDER_shipment_container_temp 
 as select * FROM raw.raw_ORDER_shipment_container
WHERE (shipment_container_key, modifyts) IN (
    SELECT shipment_container_key, modifyts
    FROM (
        SELECT 
            shipment_container_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_container_key, modifyts ORDER BY shipment_container_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment_container
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_shipment_container
WHERE (shipment_container_key, modifyts) IN (
    SELECT shipment_container_key, modifyts
    FROM (
        SELECT 
            shipment_container_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_container_key, modifyts ORDER BY shipment_container_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment_container
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_shipment_container
select * from raw.raw_ORDER_shipment_container_temp
qualify ROW_NUMBER() OVER (PARTITION BY shipment_container_key, modifyts ORDER BY shipment_container_key, modifyts, processing_status DESC)=1;

--raw_ORDER_shipment_line

create or replace temporary table raw.raw_ORDER_shipment_line_temp
 as select * FROM raw.raw_ORDER_shipment_line
WHERE (shipment_line_key, modifyts) IN (
    SELECT shipment_line_key, modifyts
    FROM (
        SELECT 
            shipment_line_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_line_key, modifyts ORDER BY shipment_line_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment_line
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_shipment_line
WHERE (shipment_line_key, modifyts) IN (
    SELECT shipment_line_key, modifyts
    FROM (
        SELECT 
            shipment_line_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_line_key, modifyts ORDER BY shipment_line_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment_line
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_shipment_line
select * from raw.raw_ORDER_shipment_line_temp
qualify ROW_NUMBER() OVER (PARTITION BY shipment_line_key, modifyts ORDER BY shipment_line_key, modifyts, processing_status DESC)=1;

--raw_ORDER_shipment

create or replace temporary table raw.raw_ORDER_shipment_temp 
 as select * FROM raw.raw_ORDER_shipment
WHERE (shipment_key, modifyts) IN (
    SELECT shipment_key, modifyts
    FROM (
        SELECT 
            shipment_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_key, modifyts ORDER BY shipment_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_shipment
WHERE (shipment_key, modifyts) IN (
    SELECT shipment_key, modifyts
    FROM (
        SELECT 
            shipment_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY shipment_key, modifyts ORDER BY shipment_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_shipment
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);


insert into raw.raw_ORDER_shipment
select * from raw.raw_ORDER_shipment_temp
qualify ROW_NUMBER() OVER (PARTITION BY shipment_key, modifyts ORDER BY shipment_key, modifyts, processing_status DESC)=1;

--raw_ORDER_audit

create or replace temporary table raw.raw_ORDER_audit_temp
 as select * FROM raw.raw_ORDER_audit
WHERE (ORDER_AUDIT_KEY, modifyts) IN (
    SELECT ORDER_AUDIT_KEY, modifyts
    FROM (
        SELECT 
            ORDER_AUDIT_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_KEY, modifyts ORDER BY ORDER_AUDIT_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_audit
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

delete FROM raw.raw_ORDER_audit
WHERE (ORDER_AUDIT_KEY, modifyts) IN (
    SELECT ORDER_AUDIT_KEY, modifyts
    FROM (
        SELECT 
            ORDER_AUDIT_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_KEY, modifyts ORDER BY ORDER_AUDIT_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_audit
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_audit
select * from raw.raw_ORDER_audit_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_KEY, modifyts ORDER BY ORDER_AUDIT_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_audit_level


create or replace temporary table raw.raw_ORDER_audit_level_temp 
 as select * FROM raw.raw_ORDER_audit_level
WHERE (ORDER_AUDIT_LEVEL_KEY, modifyts) IN (
    SELECT ORDER_AUDIT_LEVEL_KEY, modifyts
    FROM (
        SELECT 
            ORDER_AUDIT_LEVEL_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_LEVEL_KEY, modifyts ORDER BY ORDER_AUDIT_LEVEL_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_audit_level
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_audit_level
WHERE (ORDER_AUDIT_LEVEL_KEY, modifyts) IN (
    SELECT ORDER_AUDIT_LEVEL_KEY, modifyts
    FROM (
        SELECT 
            ORDER_AUDIT_LEVEL_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_LEVEL_KEY, modifyts ORDER BY ORDER_AUDIT_LEVEL_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_audit_level
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_audit_level
select * from raw.raw_ORDER_audit_level_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_AUDIT_LEVEL_KEY, modifyts ORDER BY ORDER_AUDIT_LEVEL_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_hold_type

create or replace temporary table raw.raw_ORDER_hold_type_temp
 as select * FROM raw.raw_ORDER_hold_type
WHERE (ORDER_HOLD_TYPE_KEY, modifyts) IN (
    SELECT ORDER_HOLD_TYPE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_HOLD_TYPE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_HOLD_TYPE_KEY, modifyts ORDER BY ORDER_HOLD_TYPE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_hold_type
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_hold_type
WHERE (ORDER_HOLD_TYPE_KEY, modifyts) IN (
    SELECT ORDER_HOLD_TYPE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_HOLD_TYPE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_HOLD_TYPE_KEY, modifyts ORDER BY ORDER_HOLD_TYPE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_hold_type
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);
insert into raw.raw_ORDER_hold_type
select distinct * from raw.raw_ORDER_hold_type_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_HOLD_TYPE_KEY, modifyts ORDER BY ORDER_HOLD_TYPE_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_invoice

create or replace temporary table raw.raw_ORDER_invoice_temp
 as select * FROM raw.raw_ORDER_invoice
WHERE (ORDER_INVOICE_KEY, modifyts) IN (
    SELECT ORDER_INVOICE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_INVOICE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_INVOICE_KEY, modifyts ORDER BY ORDER_INVOICE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_invoice
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_invoice
WHERE (ORDER_INVOICE_KEY, modifyts) IN (
    SELECT ORDER_INVOICE_KEY, modifyts
    FROM (
        SELECT 
            ORDER_INVOICE_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY ORDER_INVOICE_KEY, modifyts ORDER BY ORDER_INVOICE_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_invoice
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_invoice
select distinct * from raw.raw_ORDER_invoice_temp
qualify ROW_NUMBER() OVER (PARTITION BY ORDER_INVOICE_KEY, modifyts ORDER BY ORDER_INVOICE_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_notes

create or replace temporary table raw.raw_ORDER_notes_temp
 as select * FROM raw.raw_ORDER_notes
WHERE (NOTES_KEY, modifyts) IN (
    SELECT NOTES_KEY, modifyts
    FROM (
        SELECT 
            NOTES_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY NOTES_KEY, modifyts ORDER BY NOTES_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_notes
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_notes
WHERE (NOTES_KEY, modifyts) IN (
    SELECT NOTES_KEY, modifyts
    FROM (
        SELECT 
            NOTES_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY NOTES_KEY, modifyts ORDER BY NOTES_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_notes
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_notes
select distinct * from raw.raw_ORDER_notes_temp
qualify ROW_NUMBER() OVER (PARTITION BY NOTES_KEY, modifyts ORDER BY NOTES_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_tax_breakup

create or replace temporary table raw.raw_ORDER_tax_breakup_temp
 as select * FROM raw.raw_ORDER_tax_breakup
WHERE (TAX_BREAKUP_KEY, modifyts) IN (
    SELECT TAX_BREAKUP_KEY, modifyts
    FROM (
        SELECT 
            TAX_BREAKUP_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY TAX_BREAKUP_KEY, modifyts ORDER BY TAX_BREAKUP_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_tax_breakup
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_tax_breakup
WHERE (TAX_BREAKUP_KEY, modifyts) IN (
    SELECT TAX_BREAKUP_KEY, modifyts
    FROM (
        SELECT 
            TAX_BREAKUP_KEY,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY TAX_BREAKUP_KEY, modifyts ORDER BY TAX_BREAKUP_KEY, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_tax_breakup
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_tax_breakup
select  * from raw.raw_ORDER_tax_breakup_temp
qualify  ROW_NUMBER() OVER (PARTITION BY TAX_BREAKUP_KEY, modifyts ORDER BY TAX_BREAKUP_KEY, modifyts, processing_status DESC)=1;

--raw_ORDER_customer_person_info

create or replace temporary table raw.raw_ORDER_customer_person_info_temp
 as select * FROM raw.raw_ORDER_customer_person_info
WHERE (person_info_key, modifyts) IN (
    SELECT person_info_key, modifyts
    FROM (
        SELECT 
            person_info_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_customer_person_info
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

delete FROM raw.raw_ORDER_customer_person_info
WHERE (person_info_key, modifyts) IN (
    SELECT person_info_key, modifyts
    FROM (
        SELECT 
            person_info_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_customer_person_info
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_customer_person_info
select  * from raw.raw_ORDER_customer_person_info_temp
qualify ROW_NUMBER() OVER (PARTITION BY person_info_key, modifyts ORDER BY person_info_key, modifyts, processing_status DESC)=1;

--raw_ORDER_charge_transaction

create or replace temporary table raw.raw_ORDER_charge_transaction_temp
 as select * FROM raw.raw_ORDER_charge_transaction
WHERE (charge_transaction_key, modifyts) IN (
    SELECT charge_transaction_key, modifyts
    FROM (
        SELECT 
            charge_transaction_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY charge_transaction_key, modifyts ORDER BY charge_transaction_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_charge_transaction
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

DELETE FROM raw.raw_ORDER_charge_transaction
WHERE (charge_transaction_key, modifyts) IN (
    SELECT charge_transaction_key, modifyts
    FROM (
        SELECT 
            charge_transaction_key,
            modifyts,
            processing_status,
            ROW_NUMBER() OVER (PARTITION BY charge_transaction_key, modifyts ORDER BY charge_transaction_key, modifyts, processing_status DESC) AS revision
        FROM raw.raw_ORDER_charge_transaction
    ) AS h
    WHERE h.revision > 1 AND processing_status != ''Processed''
);

insert into raw.raw_ORDER_charge_transaction
select * from raw.raw_ORDER_charge_transaction_temp
qualify ROW_NUMBER() OVER (PARTITION BY charge_transaction_key, modifyts ORDER BY charge_transaction_key, modifyts, processing_status DESC)=1;


 RETURN ''usp_ORDER_clean_duplicate_raw_entries executed successfully'';
END';
