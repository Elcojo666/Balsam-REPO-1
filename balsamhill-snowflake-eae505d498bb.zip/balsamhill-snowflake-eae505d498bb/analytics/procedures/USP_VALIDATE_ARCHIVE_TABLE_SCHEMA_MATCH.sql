USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_VALIDATE_ARCHIVE_TABLE_SCHEMA("SOURCETABLENAME" VARCHAR(16777216), "DESTINATIONTABLENAME" VARCHAR(16777216), "SCHEMAMATCH" BOOLEAN)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    sourceColumnCount INT;
    destinationColumnCount INT;
    sourceColumns ARRAY;
    destinationColumns ARRAY;
BEGIN
    schemaMatch := FALSE;

    BEGIN
        sourceColumnCount := (SELECT COUNT(*)
                              FROM INFORMATION_SCHEMA.COLUMNS
                              WHERE TABLE_NAME = :sourceTableName);

        destinationColumnCount := (SELECT COUNT(*)
                                   FROM INFORMATION_SCHEMA.COLUMNS
                                    WHERE TABLE_NAME = :destinationTableName);
    IF (sourceColumnCount + 1 = destinationColumnCount) THEN
        schemaMatch := TRUE;
    END IF; 

    RETURN schemaMatch;
    EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
    END;
END';
