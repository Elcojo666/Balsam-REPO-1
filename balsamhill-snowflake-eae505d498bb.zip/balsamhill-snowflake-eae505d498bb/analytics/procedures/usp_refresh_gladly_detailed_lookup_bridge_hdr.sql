USE DATABASE DEV;
USE SCHEMA ANALYTICS;

CREATE OR REPLACE PROCEDURE ANALYTICS.usp_refresh_gladly_detailed_lookup_bridge_hdr(pipeline_name VARCHAR DEFAULT 'gladly_bridge_hdr')
    RETURNS STRING
    LANGUAGE SQL
AS
DECLARE
pipeline_stage_name   VARCHAR := 'refresh';
    start_time            TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    completed_message     VARCHAR;
    error_object          VARIANT;
BEGIN
    SYSTEM$LOG('TRACE', 'SP STARTED - ' || :pipeline_name || ' - ' || :pipeline_stage_name);

CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'started',
            :start_time,
            NULL,
            :pipeline_stage_name || ' started'
         );

BEGIN
TRUNCATE TABLE ANALYTICS.GLADLY_DETAILED_LOOKUP_BRIDGE_HDR;

INSERT INTO ANALYTICS.GLADLY_DETAILED_LOOKUP_BRIDGE_HDR (
    pk_order_headerid,
    fk_customerid,
    fk_currencyid,
    fk_sourceid,
    fk_order_typeid,
    fk_shipping_addressid,
    fk_billing_addressid,
    source_ref_num,
    order_date,
    payment_amount,
    order_notes,
    email_address,
    extn_order_locale_code,
    currency_code,
    seller_storecode,
    platform_name,
    order_type_name,
    order_status_name,
    ship_addressid,
    ship_firstname,
    ship_lastname,
    ship_company,
    ship_address1,
    ship_address2,
    ship_city,
    ship_state,
    ship_postal_code,
    ship_country,
    ship_phone,
    bill_addressid,
    bill_firstname,
    bill_lastname,
    bill_company,
    bill_address1,
    bill_address2,
    bill_city,
    bill_state,
    bill_postal_code,
    bill_country,
    bill_phone,
    pk_order_discountid,
    header_discount_code,
    header_discount_amount,
    header_discount_name,
    pk_order_taxid,
    header_tax_type,
    header_tax_amount,
    header_tax_name,
    pk_order_feeid,
    header_fee_amount,
    header_fee_type,
    cc_last4,
    transactionid,
    ext_paymentid,
    payment_date,
    processed_amount,
    payment_method_name,
    payment_type_name,
    account_code
)
SELECT
    toh.pk_order_headerid,
    toh.fk_customerid,
    toh.fk_currencyid,
    toh.fk_sourceid,
    toh.fk_order_typeid,
    toh.fk_shipping_addressid,
    toh.fk_billing_addressid,
    toh.source_ref_num,
    toh.order_date,
    toh.payment_amount,
    toh.order_notes,
    toh.email_address,
    toh.extn_order_locale_code,
    dcn.currency_code,
    db.storecode                            AS seller_storecode,
    dp.platform_name,
    dot.order_type_name,
    dos.order_status_name,
    ta.pk_addressid                         AS ship_addressid,
    ta.first_name                           AS ship_firstname,
    ta.last_name                            AS ship_lastname,
    ta.company_name                         AS ship_company,
    ta.address1                             AS ship_address1,
    ta.address2                             AS ship_address2,
    ta.city                                 AS ship_city,
    ta.state                                AS ship_state,
    ta.postal_code                          AS ship_postal_code,
    ta.country                              AS ship_country,
    ta.phone_number                         AS ship_phone,
    ta2.pk_addressid                        AS bill_addressid,
    ta2.first_name                          AS bill_firstname,
    ta2.last_name                           AS bill_lastname,
    ta2.company_name                        AS bill_company,
    ta2.address1                            AS bill_address1,
    ta2.address2                            AS bill_address2,
    ta2.city                                AS bill_city,
    ta2.state                               AS bill_state,
    ta2.postal_code                         AS bill_postal_code,
    ta2.country                             AS bill_country,
    ta2.phone_number                        AS bill_phone,
    tohd.pk_order_discountid,
    tohd.discount_code                      AS header_discount_code,
    tohd.discount_amount                    AS header_discount_amount,
    tohd.discount_name                      AS header_discount_name,
    toht.pk_order_taxid,
    toht.tax_type                           AS header_tax_type,
    toht.tax_amount                         AS header_tax_amount,
    toht.tax_name                           AS header_tax_name,
    tohf.pk_order_feeid,
    tohf.fee_amount                         AS header_fee_amount,
    tohf.fee_type                           AS header_fee_type,
    txp.cc_last4,
    txp.transactionid,
    txp.ext_paymentid,
    txp.payment_date,
    txp.payment_amount                      AS processed_amount,
    dpm.payment_method_name,
    dpt.payment_type_name,
    db.code                                 AS account_code
FROM ANALYTICS.TXN_ORDER_HEADER toh
LEFT JOIN master.dim_currency dcn
    ON dcn.pk_currencyid = toh.fk_currencyid
LEFT JOIN master.dim_source ds
    ON ds.pk_sourceid = toh.fk_sourceid
LEFT JOIN master.dim_brand db
    ON db.pk_brandid = ds.fk_brandid
LEFT JOIN master.dim_platform dp
    ON dp.pk_platformid = ds.fk_platformid
LEFT JOIN master.dim_order_type dot
    ON dot.pk_order_typeid = toh.fk_order_typeid
LEFT JOIN analytics.txn_order_status tos
    ON tos.source_ref_num = toh.source_ref_num
    AND tos.fk_sourceid = toh.fk_sourceid
LEFT JOIN master.dim_order_status dos
    ON dos.pk_order_statusid = tos.fk_order_statusid
LEFT JOIN analytics.txn_address ta
    ON ta.pk_addressid = toh.fk_shipping_addressid
LEFT JOIN analytics.txn_address ta2
    ON ta2.pk_addressid = toh.fk_billing_addressid
LEFT JOIN analytics.txn_order_discount tohd
    ON tohd.fk_order_headerid = toh.pk_order_headerid
LEFT JOIN analytics.txn_order_tax toht
    ON toht.fk_order_headerid = toh.pk_order_headerid
LEFT JOIN analytics.txn_order_fee tohf
    ON tohf.fk_order_headerid = toh.pk_order_headerid
LEFT JOIN analytics.txn_payment txp
    ON txp.fk_order_headerid = toh.pk_order_headerid
LEFT JOIN master.dim_payment_method dpm
    ON dpm.pk_payment_method_id = txp.fk_payment_methodid
LEFT JOIN master.dim_payment_type dpt
    ON dpt.pk_payment_typeid = txp.fk_payment_typeid
;

LET inserted_count VARCHAR := (
            SELECT COUNT(1) FROM ANALYTICS.GLADLY_DETAILED_LOOKUP_BRIDGE_HDR
        );

        completed_message := 'Bridge refresh completed. Inserted rows: ' || inserted_count;

COMMIT;
EXCEPTION
        WHEN statement_error THEN
            ROLLBACK;

            SYSTEM$LOG('ERROR', 'SP FAILED - ' || :pipeline_name || ' - ' || :pipeline_stage_name);

            error_object := OBJECT_CONSTRUCT(
                    'Error type', 'STATEMENT_ERROR',
                    'SQLCODE', SQLCODE,
                    'SQLERRM', SQLERRM,
                    'SQLSTATE', SQLSTATE);

CALL transformed.insert_into_log_pipeline_tasks_execution_details(
                    :pipeline_name,
                    :pipeline_stage_name,
                    'failed',
                    :start_time,
                    CURRENT_TIMESTAMP(),
                    TO_JSON(:error_object)
                 );

RETURN error_object;
END;

CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'completed',
            :start_time,
            CURRENT_TIMESTAMP(),
            :completed_message
         );

SYSTEM$LOG('TRACE', 'SP COMPLETED - ' || :pipeline_name || ' - ' || :pipeline_stage_name);

RETURN :start_time || ' - ' || :completed_message;
END;

ALTER PROCEDURE ANALYTICS.usp_refresh_gladly_detailed_lookup_bridge_hdr(VARCHAR)
    SET LOG_LEVEL = TRACE, TRACE_LEVEL = ALWAYS;