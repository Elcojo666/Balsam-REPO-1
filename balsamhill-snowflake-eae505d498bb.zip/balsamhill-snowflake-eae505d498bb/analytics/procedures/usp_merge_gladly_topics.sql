USE DATABASE dev;
USE SCHEMA analytics;

CREATE OR REPLACE PROCEDURE analytics.usp_merge_gladly_topics(pipeline_name VARCHAR DEFAULT 'gladly_topics')
    RETURNS STRING
    LANGUAGE SQL
AS
DECLARE
    pipeline_stage_name VARCHAR := 'merge';
    start_time          TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    completed_message   VARCHAR;
    error_object        VARIANT;
BEGIN
    SYSTEM$LOG('TRACE', 'SP STARTED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'started',
            :start_time,
            NULL,
            :pipeline_stage_name || ' ' || 'started');

    BEGIN
        MERGE INTO analytics.txn_gladly_topics AS target
            USING (SELECT *
                   FROM transformed.stage_gladly_topics) AS source
            ON source.id = target.id
            WHEN MATCHED AND (source.name <> target.name OR source.disabled <> target.disabled) THEN
                UPDATE SET
                    name = source.name,
                    disabled = source.disabled,
                    updated_at = CURRENT_TIMESTAMP()
            WHEN NOT MATCHED THEN
                INSERT (
                        id,
                        disabled,
                        name
                    )
                    VALUES (source.id,
                            source.disabled,
                            source.name);

        LET
        deleted_events_count VARCHAR := (SELECT COUNT(1)
                                         FROM analytics.txn_gladly_topics AS target
                                         WHERE NOT EXISTS (SELECT 1
                                                           FROM transformed.stage_gladly_topics AS source
                                                           WHERE source.id = target.id));

        DELETE
        FROM analytics.txn_gladly_topics AS target
        WHERE NOT EXISTS (SELECT 1
                          FROM transformed.stage_gladly_topics AS source
                          WHERE source.id = target.id);
        LET
        staged_events_count VARCHAR := (SELECT COUNT(1)
                                        FROM analytics.txn_gladly_topics
                                        WHERE updated_at >= :start_time);

        completed_message := 'Merging completed successfully. ' || 'Merged records: ' || :staged_events_count || '- Deleted records: ' || :deleted_events_count;

        COMMIT;
    EXCEPTION
        WHEN statement_error THEN
            ROLLBACK;

            SYSTEM$LOG('ERROR', 'SP FAILED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

            error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                             'SQLCODE', sqlcode,
                                             'SQLERRM', sqlerrm,
                                             'SQLSTATE', sqlstate);

            CALL transformed.insert_into_log_pipeline_tasks_execution_details(
                    :pipeline_name,
                    :pipeline_stage_name,
                    'failed',
                    :start_time,
                    CURRENT_TIMESTAMP(),
                    TO_JSON(:error_object));

            RETURN error_object;
    END;

    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'completed',
            :start_time,
            CURRENT_TIMESTAMP(),
            :completed_message);

    SYSTEM$LOG('TRACE', 'SP COMPLETED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

    RETURN :start_time || ' - ' || :completed_message;
END;

ALTER PROCEDURE analytics.usp_merge_gladly_topics(VARCHAR)
    SET LOG_LEVEL = TRACE, TRACE_LEVEL = ALWAYS;

EXECUTE TASK analytics.task_load_gladly_topics