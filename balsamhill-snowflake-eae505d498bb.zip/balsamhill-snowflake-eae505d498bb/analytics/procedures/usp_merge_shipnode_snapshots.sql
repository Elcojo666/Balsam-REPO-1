USE DATABASE DEV;
USE SCHEMA ANALYTICS;

CREATE OR REPLACE PROCEDURE analytics.usp_merge_shipnode_snapshot(pipeline_name VARCHAR DEFAULT 'shipnode_snapshot')
    RETURNS STRING
    LANGUAGE SQL
AS
DECLARE
    pipeline_stage_name VARCHAR := 'merge';
    start_time          TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    completed_message   VARCHAR;
    error_object        VARIANT;
BEGIN
    SYSTEM$LOG('TRACE', 'SP STARTED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'started',
            :start_time,
            NULL,
            :pipeline_stage_name || ' ' || 'started');

    BEGIN
        INSERT INTO analytics.txn_shipnode_snapshot (
            code,
            id,
            timestamp,
            snapshotId,
            productId,
            segment,
            segmentType,
            shipNode,
            onHandAvailableQuantity,
            fulfillmentAllowed
        )
        SELECT
            code,
            id,
            timestamp,
            snapshotId,
            productId,
            segment,
            segmentType,
            shipNode,
            onHandAvailableQuantity,
            fulfillmentAllowed
        FROM transformed.stage_shipnode_snapshot;

        LET staged_events_count VARCHAR := (
                    SELECT COUNT(1)
                    FROM analytics.txn_shipnode_snapshot
                    WHERE updated_at >= :start_time
                );

                completed_message := 'Merging completed successfully. ' || 'Merged records: ' || :staged_events_count;

        COMMIT;
        EXCEPTION
                WHEN statement_error THEN
                    ROLLBACK;

                    SYSTEM$LOG('ERROR', 'SP FAILED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

                    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                                     'SQLCODE', sqlcode,
                                                     'SQLERRM', sqlerrm,
                                                     'SQLSTATE', sqlstate);

        CALL transformed.insert_into_log_pipeline_tasks_execution_details(
                            :pipeline_name,
                            :pipeline_stage_name,
                            'failed',
                            :start_time,
                            CURRENT_TIMESTAMP(),
                            TO_JSON(:error_object));

        RETURN error_object;
        END;

        CALL transformed.insert_into_log_pipeline_tasks_execution_details(
                    :pipeline_name,
                    :pipeline_stage_name,
                    'completed',
                    :start_time,
                    CURRENT_TIMESTAMP(),
                    :completed_message);

        SYSTEM$LOG('TRACE', 'SP COMPLETED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

        RETURN :start_time || ' - ' || :completed_message;
        END;

ALTER PROCEDURE analytics.usp_merge_shipnode_snapshot(VARCHAR)
    SET LOG_LEVEL = TRACE, TRACE_LEVEL = ALWAYS;