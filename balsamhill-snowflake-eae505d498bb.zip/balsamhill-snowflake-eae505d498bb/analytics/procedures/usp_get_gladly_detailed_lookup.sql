USE DATABASE DEV;

CREATE OR REPLACE PROCEDURE analytics.usp_get_gladly_detailed_lookup(
    p_email VARCHAR DEFAULT NULL,
    p_startdate TIMESTAMP_NTZ DEFAULT NULL,
    p_pk_customerid NUMBER DEFAULT NULL
) COPY GRANTS
    RETURNS TABLE (
        "EnterpriseCode" VARCHAR,
        "EntryType" VARCHAR,
        "OrderDate" TIMESTAMP_NTZ,
        "OrderNo" VARCHAR,
        "pk_order_headerid" NUMBER,
        "OrderType" VARCHAR,
        "SellerOrganizationCode" VARCHAR,
        "Status" VARCHAR,
        "GrandTotal" NUMBER(15, 6),
        "NoteText" VARCHAR,
        "OrderedQty" NUMBER,
        "pk_order_detailid" NUMBER,
        "PrimeLineNo" NUMBER,
        "ItemID" VARCHAR,
        "ProductClass" VARCHAR,
        "UnitOfMeasure" VARCHAR,
        "ItemShortDesc" VARCHAR,
        "UnitPrice" NUMBER(9, 2),
        "LineTotal" NUMBER(9, 2),
        "pk_order_detail_discountid" NUMBER,
        "LineChargeName" VARCHAR,
        "ChargePerLine" NUMBER(9, 2),
        "LineChargeReference" VARCHAR,
        "pk_order_detail_taxid" NUMBER,
        "LineTaxChargeName" VARCHAR,
        "LineTax" NUMBER(9, 2),
        "LineTaxName" VARCHAR,
        "pk_ship_addressid" NUMBER,
        "ShipFirstName" VARCHAR,
        "ShipLastName" VARCHAR,
        "ShipCompany" VARCHAR,
        "ShipAddressLine1" VARCHAR,
        "ShipAddressLine2" VARCHAR,
        "ShipCity" VARCHAR,
        "ShipState" VARCHAR,
        "ShipZipCode" VARCHAR,
        "ShipCountry" VARCHAR,
        "ShipEmailID" VARCHAR,
        "ShipMobilePhone" VARCHAR,
        "pk_bill_addressid" NUMBER,
        "BillFirstName" VARCHAR,
        "BillLastName" VARCHAR,
        "BillCompany" VARCHAR,
        "BillAddressLine1" VARCHAR,
        "BillAddressLine2" VARCHAR,
        "BillCity" VARCHAR,
        "BillState" VARCHAR,
        "BillZipCode" VARCHAR,
        "BillCountry" VARCHAR,
        "BillEmailID" VARCHAR,
        "BillMobilePhone" VARCHAR,
        "pk_order_discountid" NUMBER,
        "HeaderChargeName" VARCHAR,
        "ChargeAmount" NUMBER(9, 2),
        "HeaderChargeReference" VARCHAR,
        "pk_order_taxid" NUMBER,
        "HeaderChargeTaxName" VARCHAR,
        "HeaderTax" NUMBER(9, 2),
        "HeaderTaxName" VARCHAR,
        "CreditCardNo" VARCHAR,
        "CreditCardType" VARCHAR,
        "PaymentReference1" VARCHAR,
        "PaymentReference2" VARCHAR,
        "PaymentType" VARCHAR,
        "AuthTime" TIMESTAMP_NTZ,
        "AuthorizationID" VARCHAR,
        "ProcessedAmount" NUMBER(9, 2),
        "TrackingNo" VARCHAR,
        "CarrierServiceCode" VARCHAR,
        "Carrier" VARCHAR,
        "LineFeeAmount" NUMBER(9, 2),
        "LineFeeType" VARCHAR,
        "pk_order_detail_feeid" NUMBER,
        "HeaderFeeAmount" NUMBER(9, 2),
        "HeaderFeeType" VARCHAR,
        "pk_order_feeid" NUMBER,
        "source_ref_num" VARCHAR,
        "Account" VARCHAR,
        "PK_CUSTOMER_INFO_ID" NUMBER,
        "fk_customerid" NUMBER,
        "legal_name" VARCHAR,
        "first_name" VARCHAR,
        "last_name" VARCHAR,
        "TITLE" VARCHAR,
        "COMPANY_NAME" VARCHAR,
        "EMAIL_PRIMARY" VARCHAR,
        "EXTERNAL_EMAIL1" VARCHAR,
        "EXTERNAL_EMAIL2" VARCHAR,
        "EMAIL_SECONDARY" VARCHAR,
        "HOME_PHONE_PRIMARY" VARCHAR,
        "home_phone_primary_sms" BOOLEAN,
        "home_phone_primary_pref" BOOLEAN,
        "home_phone_primary_region" VARCHAR,
        "HOME_PHONE_SECONDARY" VARCHAR,
        "home_phone_secondary_sms" BOOLEAN,
        "home_phone_secondary_pref" BOOLEAN,
        "home_phone_secondary_region" VARCHAR,
        "MOBI_PHONE_PRIMARY" VARCHAR,
        "mobi_phone_primary_sms" BOOLEAN,
        "mobi_phone_primary_pref" BOOLEAN,
        "mobi_phone_primary_region" VARCHAR,
        "MOBI_PHONE_SECONDARY" VARCHAR,
        "mobi_phone_secondary_sms" BOOLEAN,
        "mobi_phone_secondary_pref" BOOLEAN,
        "mobi_phone_secondary_region" VARCHAR,
        "PK_CUSTOMER_ADDRESS_ID" NUMBER,
        "ADDRESS_LINE_1" VARCHAR,
        "ADDRESS_LINE_2" VARCHAR,
        "CITY" VARCHAR,
        "STATE" VARCHAR,
        "POSTAL_CODE" VARCHAR,
        "COUNTRY_CODE" VARCHAR,
        "CUST_TYPE" VARCHAR,
        "cust_tier" VARCHAR,
        "TAX_EXEMPT_ACCOUNT" VARCHAR,
        "tax_id" VARCHAR,
        "CATALOG_SUBSCRIBER" VARCHAR,
        "email_subscriber" VARCHAR,
        "IsNordstromCustomer" BOOLEAN,
        "IsWilliamsonomaCustomer" BOOLEAN,
        "business_cust" BOOLEAN,
        "business_category" VARCHAR,
        "Business_#_of_Locations" NUMBER,
        "DesignTradeFlag" BOOLEAN,
        "social_handle_facebook" VARCHAR,
        "social_handle_instagram" VARCHAR,
        "social_handle_twitter" VARCHAR,
        "currency_code" VARCHAR,
        "extn_order_locale_code" VARCHAR,
        "extn_mfg_start_date" TIMESTAMP_NTZ,
        "extn_mfg_end_date" TIMESTAMP_NTZ,
        "extn_extnd_start_date" TIMESTAMP_NTZ,
        "extn_extnd_end_date" TIMESTAMP_NTZ
        )
    LANGUAGE SQL
AS
$$
BEGIN
  LET result RESULTSET := (
    WITH customer_info_filtered AS (
      SELECT
        pk_customer_info_id,
        fk_customerid,
        legal_name,
        first_name,
        last_name,
        title,
        company_name,
        email_primary,
        external_email1,
        external_email2,
        email_secondary,
        home_phone_primary,
        home_phone_primary_sms,
        home_phone_primary_pref,
        home_phone_primary_region,
        home_phone_secondary,
        home_phone_secondary_sms,
        home_phone_secondary_pref,
        home_phone_secondary_region,
        mobi_phone_primary,
        mobi_phone_primary_sms,
        mobi_phone_primary_pref,
        mobi_phone_primary_region,
        mobi_phone_secondary,
        mobi_phone_secondary_sms,
        mobi_phone_secondary_pref,
        mobi_phone_secondary_region,
        cust_type,
        cust_tier,
        tax_exempt_account,
        tax_id,
        catalog_subscriber,
        email_subscriber,
        isnordstromcustomer,
        iswilliamsonomacustomer,
        business_cust,
        business_category,
        "BUSINESS_#_OF_LOCATIONS",
        designtradeflag,
        social_handle_facebook,
        social_handle_instagram,
        social_handle_twitter
      FROM ANALYTICS.CUSTOMER_INFO
      WHERE
        (
          :p_email IS NOT NULL
          AND :p_email <> ''
          AND (
            EMAIL_PRIMARY     ILIKE ('%'||:p_email||'%')
            OR EMAIL_SECONDARY ILIKE ('%'||:p_email||'%')
            OR EXTERNAL_EMAIL1 ILIKE ('%'||:p_email||'%')
            OR EXTERNAL_EMAIL2 ILIKE ('%'||:p_email||'%')
          )
        )
        OR (
          :p_pk_customerid IS NOT NULL
          AND :p_pk_customerid <> 0
          AND email_primary IS NOT NULL
          AND fk_customerid = :p_pk_customerid
        )
    ),
    gladlydetailedlookup_customer_info AS (
      SELECT
        fk_customerid
      FROM customer_info_filtered

      UNION

      SELECT
        fk_customerid
      FROM ANALYTICS.TXN_ORDER_HEADER
      WHERE
        email_address ILIKE ('%'||:p_email||'%')
        AND (
          SELECT COUNT(1)
          FROM ANALYTICS.CUSTOMER_INFO
          WHERE
            (
              :p_email IS NOT NULL
              AND :p_email <> ''
              AND (
                EMAIL_PRIMARY     ILIKE ('%'||:p_email||'%')
                OR EMAIL_SECONDARY ILIKE ('%'||:p_email||'%')
                OR EXTERNAL_EMAIL1 ILIKE ('%'||:p_email||'%')
                OR EXTERNAL_EMAIL2 ILIKE ('%'||:p_email||'%')
              )
            )
        ) = 0
      GROUP BY
        fk_customerid
    ),
    gladlydetailedlookup_order_info AS (
      SELECT
        l.pk_customer_info_id,
        l.fk_customerid,
        l.legal_name,
        l.first_name,
        l.last_name,
        l.title,
        l.company_name,
        l.email_primary,
        l.external_email1,
        l.external_email2,
        l.email_secondary,
        l.home_phone_primary,
        l.home_phone_primary_sms,
        l.home_phone_primary_pref,
        l.home_phone_primary_region,
        l.home_phone_secondary,
        l.home_phone_secondary_sms,
        l.home_phone_secondary_pref,
        l.home_phone_secondary_region,
        l.mobi_phone_primary,
        l.mobi_phone_primary_sms,
        l.mobi_phone_primary_pref,
        l.mobi_phone_primary_region,
        l.mobi_phone_secondary,
        l.mobi_phone_secondary_sms,
        l.mobi_phone_secondary_pref,
        l.mobi_phone_secondary_region,
        l.cust_type,
        l.cust_tier,
        l.tax_exempt_account,
        l.tax_id,
        l.catalog_subscriber,
        l.email_subscriber,
        l.isnordstromcustomer,
        l.iswilliamsonomacustomer,
        l.business_cust,
        l.business_category,
        l."BUSINESS_#_OF_LOCATIONS",
        l.designtradeflag,
        l.social_handle_facebook,
        l.social_handle_instagram,
        l.social_handle_twitter,
        toh.order_date,
        toh.source_ref_num,
        toh.pk_order_headerid,
        toh.payment_amount,
        toh.order_notes,
        toh.email_address,
        toh.extn_order_locale_code,
        toh.fk_currencyid,
        toh.fk_sourceid,
        toh.fk_order_typeid,
        toh.fk_shipping_addressid,
        toh.fk_billing_addressid
      FROM gladlydetailedlookup_customer_info AS gci
      INNER JOIN customer_info_filtered AS l
        ON gci.FK_CUSTOMERID = l.FK_CUSTOMERID
      INNER JOIN ANALYTICS.TXN_ORDER_HEADER AS TOH
        ON gci.FK_CUSTOMERID = TOH.FK_CUSTOMERID
      WHERE
        :p_startdate IS NULL
        OR toh.order_date <= :p_startdate
    )
    SELECT DISTINCT
      h.seller_storecode                         AS "EnterpriseCode",
      h.platform_name                            AS "EntryType",
      goi.order_date                             AS "OrderDate",
      goi.source_ref_num                         AS "OrderNo",
      goi.pk_order_headerid                      AS "pk_order_headerid",
      h.order_type_name                          AS "OrderType",
      h.seller_storecode                         AS "SellerOrganizationCode",
      h.order_status_name                        AS "Status",
      goi.payment_amount                         AS "GrandTotal",
      goi.order_notes                            AS "NoteText",

      tod.quantity                               AS "OrderedQty",
      tod.pk_order_detailid                      AS "pk_order_detailid",
      tod.prime_line_num                         AS "PrimeLineNo",
      dsp.sku_code                               AS "ItemID",
      dsp.sub_category                           AS "ProductClass",
      dsp.obs_actual_product_unit_of_measure     AS "UnitOfMeasure",
      tod.product_name                           AS "ItemShortDesc",
      tod.product_price                          AS "UnitPrice",
      tod.total_price                            AS "LineTotal",

      todd.pk_order_detail_discountid            AS "pk_order_detail_discountid",
      todd.discount_code                         AS "LineChargeName",
      todd.discount_amount                       AS "ChargePerLine",
      todd.discount_name                         AS "LineChargeReference",

      todt.pk_order_detail_taxid                 AS "pk_order_detail_taxid",
      todt.tax_name                              AS "LineTaxChargeName",
      todt.tax_amount::NUMBER(9, 2)              AS "LineTax",
      todt.tax_type                              AS "LineTaxName",

      h.ship_addressid                           AS "pk_ship_addressid",
      h.ship_firstname                           AS "ShipFirstName",
      h.ship_lastname                            AS "ShipLastName",
      h.ship_company                             AS "ShipCompany",
      h.ship_address1                            AS "ShipAddressLine1",
      h.ship_address2                            AS "ShipAddressLine2",
      h.ship_city                                AS "ShipCity",
      h.ship_state                               AS "ShipState",
      h.ship_postal_code                         AS "ShipZipCode",
      h.ship_country                             AS "ShipCountry",
      goi.email_address                          AS "ShipEmailID",
      h.ship_phone                               AS "ShipMobilePhone",

      h.bill_addressid                           AS "pk_bill_addressid",
      h.bill_firstname                           AS "BillFirstName",
      h.bill_lastname                            AS "BillLastName",
      h.bill_company                             AS "BillCompany",
      h.bill_address1                            AS "BillAddressLine1",
      h.bill_address2                            AS "BillAddressLine2",
      h.bill_city                                AS "BillCity",
      h.bill_state                               AS "BillState",
      h.bill_postal_code                         AS "BillZipCode",
      h.bill_country                             AS "BillCountry",
      goi.email_address                          AS "BillEmailID",
      h.bill_phone                               AS "BillMobilePhone",

      h.pk_order_discountid                      AS "pk_order_discountid",
      h.header_discount_code                     AS "HeaderChargeName",
      h.header_discount_amount                   AS "ChargeAmount",
      h.header_discount_name                     AS "HeaderChargeReference",

      h.pk_order_taxid                           AS "pk_order_taxid",
      h.header_tax_type                          AS "HeaderChargeTaxName",
      h.header_tax_amount::NUMBER(9, 2)          AS "HeaderTax",
      h.header_tax_name                          AS "HeaderTaxName",

      h.cc_last4                                 AS "CreditCardNo",
      h.payment_method_name                      AS "CreditCardType",
      h.transactionid                            AS "PaymentReference1",
      h.ext_paymentid                            AS "PaymentReference2",
      h.payment_type_name                        AS "PaymentType",
      h.payment_date                             AS "AuthTime",
      h.transactionid                            AS "AuthorizationID",
      h.processed_amount                         AS "ProcessedAmount",

      tt.tracking_number                         AS "TrackingNo",
      todl.shippingmethodid                      AS "CarrierServiceCode",
      todl.carriercode                           AS "Carrier",

      todf.fee_amount                            AS "LineFeeAmount",
      todf.fee_type                              AS "LineFeeType",
      todf.pk_order_detail_feeid                 AS "pk_order_detail_feeid",

      h.header_fee_amount                        AS "HeaderFeeAmount",
      h.header_fee_type                          AS "HeaderFeeType",
      h.pk_order_feeid                           AS "pk_order_feeid",

      dc.source_ref_num                          AS "source_ref_num",
      h.account_code                             AS "Account",

      goi.pk_customer_info_id                    AS "PK_CUSTOMER_INFO_ID",
      goi.fk_customerid                          AS "fk_customerid",
      goi.legal_name                             AS "legal_name",
      goi.first_name                             AS "first_name",
      goi.last_name                              AS "last_name",
      goi.title                                  AS "TITLE",
      goi.company_name                           AS "COMPANY_NAME",
      goi.email_primary                          AS "EMAIL_PRIMARY",
      goi.external_email1                        AS "EXTERNAL_EMAIL1",
      goi.external_email2                        AS "EXTERNAL_EMAIL2",
      goi.email_secondary                        AS "EMAIL_SECONDARY",
      goi.home_phone_primary                     AS "HOME_PHONE_PRIMARY",
      goi.home_phone_primary_sms                 AS "home_phone_primary_sms",
      goi.home_phone_primary_pref                AS "home_phone_primary_pref",
      goi.home_phone_primary_region              AS "home_phone_primary_region",
      goi.home_phone_secondary                   AS "HOME_PHONE_SECONDARY",
      goi.home_phone_secondary_sms               AS "home_phone_secondary_sms",
      goi.home_phone_secondary_pref              AS "home_phone_secondary_pref",
      goi.home_phone_secondary_region            AS "home_phone_secondary_region",
      goi.mobi_phone_primary                     AS "MOBI_PHONE_PRIMARY",
      goi.mobi_phone_primary_sms                 AS "mobi_phone_primary_sms",
      goi.mobi_phone_primary_pref                AS "mobi_phone_primary_pref",
      goi.mobi_phone_primary_region              AS "mobi_phone_primary_region",
      goi.mobi_phone_secondary                   AS "MOBI_PHONE_SECONDARY",
      goi.mobi_phone_secondary_sms               AS "mobi_phone_secondary_sms",
      goi.mobi_phone_secondary_pref              AS "mobi_phone_secondary_pref",
      goi.mobi_phone_secondary_region            AS "mobi_phone_secondary_region",

      dca.pk_customer_address_id                 AS "PK_CUSTOMER_ADDRESS_ID",
      dca.address_line_1                         AS "ADDRESS_LINE_1",
      dca.address_line_2                         AS "ADDRESS_LINE_2",
      dca.city                                   AS "CITY",
      dca.state                                  AS "STATE",
      dca.postal_code                            AS "POSTAL_CODE",
      dca.country_code                           AS "COUNTRY_CODE",

      goi.cust_type                              AS "CUST_TYPE",
      goi.cust_tier                              AS "cust_tier",
      goi.tax_exempt_account                     AS "TAX_EXEMPT_ACCOUNT",
      goi.tax_id                                 AS "tax_id",
      goi.catalog_subscriber                     AS "CATALOG_SUBSCRIBER",
      goi.email_subscriber                       AS "email_subscriber",
      goi.isnordstromcustomer                    AS "IsNordstromCustomer",
      goi.iswilliamsonomacustomer                AS "IsWilliamsonomaCustomer",
      goi.business_cust                          AS "business_cust",
      goi.business_category                      AS "business_category",
      goi."BUSINESS_#_OF_LOCATIONS"              AS "Business_#_of_Locations",
      goi.designtradeflag                        AS "DesignTradeFlag",
      goi.social_handle_facebook                 AS "social_handle_facebook",
      goi.social_handle_instagram                AS "social_handle_instagram",
      goi.social_handle_twitter                  AS "social_handle_twitter",

      h.currency_code                            AS "currency_code",
      goi.extn_order_locale_code                 AS "extn_order_locale_code",

      CASE WHEN tow.warranty_type = 'm-warranty' THEN tow.start_date END AS "extn_mfg_start_date",
      CASE WHEN tow.warranty_type = 'm-warranty' THEN tow.end_date   END AS "extn_mfg_end_date",
      CASE WHEN tow.warranty_type = 'e-warranty' THEN tow.start_date END AS "extn_extnd_start_date",
      CASE WHEN tow.warranty_type = 'e-warranty' THEN tow.end_date   END AS "extn_extnd_end_date"
    FROM gladlydetailedlookup_order_info goi

    LEFT JOIN ANALYTICS.GLADLY_DETAILED_LOOKUP_BRIDGE_HDR h
      ON h.pk_order_headerid = goi.pk_order_headerid

    LEFT JOIN analytics.txn_order_detail tod
      ON goi.pk_order_headerid = tod.fk_order_headerid

    LEFT JOIN analytics.sku_product dsp
      ON tod.fk_skuproductid = dsp.pk_skuproductid

    LEFT JOIN analytics.txn_order_detail_discount todd
      ON todd.fk_order_detailid = tod.pk_order_detailid

    LEFT JOIN analytics.txn_order_detail_tax todt
      ON todt.fk_order_detailid = tod.pk_order_detailid

    LEFT JOIN analytics.txn_order_detail_fee todf
      ON todf.fk_order_detailid = tod.pk_order_detailid

    LEFT JOIN analytics.txn_tracking tt
      ON tt.fk_order_detailid = tod.pk_order_detailid

    LEFT JOIN analytics.txn_order_delivered todl
      ON todl.fk_order_headerid = goi.pk_order_headerid
     AND todl.fk_skuproductid  = tod.fk_skuproductid

    LEFT JOIN analytics.txn_order_warranty tow
      ON tow.fk_order_headerid = goi.pk_order_headerid
     AND tow.fk_order_detailid = tod.pk_order_detailid

    LEFT JOIN analytics.customer_address dca
      ON goi.pk_customer_info_id = dca.fk_customer_info_id

    LEFT JOIN analytics.customer dc
        ON dc.pk_customerid = goi.fk_customerid

  );

  RETURN TABLE(result);
END;
$$;