CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.USP_INSERT_AND_TRUNCATE_LSDIRECT_TRANSACTIONS_EXPORT("LAST_MODIFIED_DATE" TIMESTAMP_NTZ(9) DEFAULT NULL, "NEW_MODIFIED_DATE" TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP) COPY GRANTS 
RETURNS STRING 
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
    v_last_modified_date TIMESTAMP_NTZ;
BEGIN
    -- Get the max UpdatedDate if LAST_MODIFIED_DATE is null
    IF (LAST_MODIFIED_DATE IS NULL) THEN
        SELECT MAX(ORDERDATE)
        INTO :v_last_modified_date
        FROM ANALYTICS.LSDIRECT_TRANSACTIONS_EXPORT;
    ELSE
        v_last_modified_date := LAST_MODIFIED_DATE- INTERVAL '1 MILLISECOND';
    END IF;

    -- Truncate the table
    TRUNCATE TABLE ANALYTICS.LSDIRECT_TRANSACTIONS_EXPORT;

    INSERT INTO ANALYTICS.LSDIRECT_TRANSACTIONS_EXPORT (
        ORDERID ,
    	CUSTOMERID ,
    	ORDERDATE ,
    	STOREID ,
    	UNITSOLD ,
    	LINEITEMPRICE_EXT ,
    	LINEITEMDISCOUNT_EXT ,
    	LINEITEMCOST_EXT ,
    	SKU          
    ) 
    SELECT
        coh.OrderID,
        toh.fk_customerid AS CustomerID,
        coh.OrderDate,
        coh.brand AS StoreID,
        cod.UnitSold,
        cod.ProductPrice * cod.UnitSold AS LineItemPrice_Ext,
        NULL AS LineItemDiscount_Ext,
        COALESCE(f.FullyLoadedCost, f.VariableForecastFLC, cod.ProductPrice * 0.5) * cod.UnitSold AS LineItemCost_Ext,
        cod.SKU,
    FROM PROD_EXTRACT.ANALYTICS.MIGRATED_ORDERHEADER_MIN coh
    JOIN PROD_EXTRACT.ANALYTICS.txn_order_header toh ON coh.pk_order_headerid = toh.pk_order_headerid
    JOIN PROD_EXTRACT.ANALYTICS.customer dc ON dc.pk_customerid = toh.fk_customerid
    JOIN PROD_EXTRACT.ANALYTICS.MIGRATED_ORDERDETAILS_MIN cod ON cod.pk_order_headerid = coh.pk_order_headerid
    LEFT JOIN PROD_EXTRACT.ANALYTICS.FLC f ON TRIM(F.SKU) = cod.sku
        AND YEAR(toh.inserted_date) = F.FISCALYEAR
        AND coh.brand = f.Brand
    WHERE toh.inserted_date > COALESCE(:v_last_modified_date, CURRENT_TIMESTAMP() - INTERVAL '25 HOURS') 
        AND toh.inserted_date <= COALESCE(:NEW_MODIFIED_DATE, CURRENT_TIMESTAMP() - INTERVAL '1 HOUR')
      AND coh.brand = 'BHUS'

    UNION

    SELECT
        coh.OrderID,
        toh.fk_customerid AS CustomerID,
        coh.OrderDate,
        coh.brand AS StoreID,
        1 AS UnitSold,
        NULL AS LineItemPrice_Ext,
        cod.discountAmount AS LineItemDiscount_Ext,
        NULL AS LineItemCost_Ext,
        cod.CouponCode AS SKU,
    FROM PROD_EXTRACT.ANALYTICS.MIGRATED_ORDERHEADER_MIN coh
    JOIN PROD_EXTRACT.ANALYTICS.txn_order_header toh ON coh.pk_order_headerid = toh.pk_order_headerid
    JOIN PROD_EXTRACT.ANALYTICS.MIGRATED_ORDERDISCOUNTS_MIN cod ON cod.pk_order_headerid = coh.pk_order_headerid
    WHERE toh.inserted_date > COALESCE(:v_last_modified_date, CURRENT_TIMESTAMP() - INTERVAL '25 HOURS') 
        AND toh.inserted_date <= COALESCE(:NEW_MODIFIED_DATE, CURRENT_TIMESTAMP() - INTERVAL '1 HOUR')
      AND coh.brand = 'BHUS';

    ;

    -- Return info for debugging/logging if desired
    RETURN 'Table Updated. Every record Updated After LAST_MODIFIED_DATE: ' || COALESCE(TO_VARCHAR(:v_last_modified_date), TO_VARCHAR(CURRENT_TIMESTAMP() - INTERVAL '25 HOURS')) || ' and Before NEW_MODIFIED_DATE: ' || TO_VARCHAR(COALESCE(:NEW_MODIFIED_DATE, CURRENT_TIMESTAMP() - INTERVAL '1 HOUR'));
END;
$$
;
