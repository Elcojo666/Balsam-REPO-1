
CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDERS_ALLOCATION_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

CREATE OR REPLACE TEMPORARY TABLE tempOrderAllocation (
pk_order_allocationid BIGINT
, fk_sourceid SMALLINT 
, source_ref_num TEXT 
, fk_skuproductid INT 
, fk_warehouseid INT 
, upc_code TEXT 
, fk_upcid INT 
, quantity INT 
, external_dateentered  TIMESTAMP_NTZ(9) 
, external_orderid INT 
, fk_order_headerid BIGINT 
, inserted_date TIMESTAMP 
, modified_date TIMESTAMP 
);

CREATE OR REPLACE TEMPORARY TABLE ORDERALLOCATION AS 
    SELECT distinct stg.order_release_key
    ,toh.pk_order_headerid as fk_order_headerid
    ,toh.fk_sourceid as fk_sourceid
    ,toh.source_ref_num as source_ref_num
    ,oegd.sku_item_id as sku_code
    ,sku.pk_skuproductid as fk_skuproductid
    ,upc.pk_upcid as fk_upcid
    ,oegd.upc_item_id  as upc_code
    ,oegd.quantity as quantity
    ,stg.shipnode_key as fk_warehouseid
    ,getdate() as external_dateentered 
    ,stg.order_release_key as external_orderid
FROM ANALYTICS.txn_order_release stg 
    INNER JOIN ANALYTICS.txn_order_header as toh 
		on stg.order_header_key = toh.ext_order_id --and stg.txn_id = roh.txn_id
	INNER JOIN MASTER.source_brand_platform_map AS src 
		ON src.BrandCodeForWHM = ANALYTICS.fun_get_edw_brand_by_order_sellerorgcode(toh.seller_organization_code) AND src.platformname = COALESCE(ANALYTICS.fun_get_edw_platform_by_order_entrytype(toh.ENTRY_TYPE), '')
	INNER JOIN ANALYTICS.txn_gtin_data oegd 
		ON oegd.orderline_release_key = stg.order_release_key
	INNER JOIN ANALYTICS.sku_product sku 
		ON sku.sku_code = oegd.sku_item_id 
	INNER JOIN ANALYTICS.upc upc 
		ON upc.upc_code = oegd.upc_item_id 
;

processedDate := CURRENT_TIMESTAMP();  

MERGE INTO   ANALYTICS.txn_order_allocation AS toa
USING (
    SELECT DISTINCT
        fk_sourceid,
        sku_code,
        fk_warehouseid,
        source_ref_num,
        CAST(CAST(quantity AS NUMERIC) AS INT) AS quantity,
        upc_code,
        fk_order_headerid,
        external_dateentered,
        external_orderid,
        fk_skuproductid,
        fk_upcid
    FROM 
        ORDERALLOCATION AS ordallocation
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM ANALYTICS.txn_order_allocation toa
            WHERE 
                ordallocation.fk_sourceid = toa.fk_sourceid
                AND ordallocation.source_ref_num = toa.source_ref_num
                AND ordallocation.fk_skuproductid = toa.fk_skuproductid
                AND ordallocation.fk_upcid = toa.fk_upcid
        )
) AS oa
ON 
    toa.fk_sourceid = oa.fk_sourceid
    AND toa.source_ref_num = oa.source_ref_num
    AND toa.fk_skuproductid = oa.fk_skuproductid
    AND toa.fk_upcid = oa.fk_upcid
WHEN NOT MATCHED THEN
    INSERT (
        fk_sourceid,
        source_ref_num,
        sku_code,
        fk_skuproductid,
        fk_warehouseid,
        upc_code,
        fk_upcid,
        quantity,
        external_dateentered,
        external_orderid,
        fk_order_headerid,
        inserted_date,
        modified_date
    )
    VALUES (
        oa.fk_sourceid,
        oa.source_ref_num,
        oa.sku_code,
        oa.fk_skuproductid,
        oa.fk_warehouseid,
        oa.upc_code,
        oa.fk_upcid,
        oa.quantity,
        TO_TIMESTAMP_NTZ(oa.external_dateentered),
        TRY_TO_NUMBER(oa.external_orderid),
        oa.fk_order_headerid,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP()
    );

INSERT INTO  ANALYTICS.audit_order_allocation (
    pk_order_allocationid,
    fk_sourceid,
    source_ref_num,
    sku_code,
    fk_skuproductid,
    fk_warehouseid,
    upc_code,
    fk_upcid,
    quantity,
    external_dateentered,
    external_orderid,
    fk_order_headerid,
    inserted_date,
    modified_date
)
SELECT 
    pk_order_allocationid,
    fk_sourceid,
    source_ref_num,
    sku_code,
    fk_skuproductid,
    fk_warehouseid,
    upc_code,
    fk_upcid,
    quantity,
    external_dateentered,
    external_orderid,
    fk_order_headerid,
    inserted_date,
    modified_date
FROM ANALYTICS.txn_order_allocation
WHERE inserted_date >= :processedDate
OR modified_date >= :processedDate;

SELECT COUNT(*)
INTO :processedRecordCount
FROM orderAllocation;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'COMPLETED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        'upsert completed successfully'
    );
    
RETURN 'Success';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

            error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);
                                     
        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );
    RETURN OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
END;