CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_RELEASE_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 
start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status 
SET 
    processed = :processedRecordCount,
    raw_table = 'raw_order_release'  -- Change to appropriate table name
WHERE file_name = 'YFS_ORDER_RELEASE';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );


MERGE INTO ANALYTICS.txn_order_release AS tor
USING (
    SELECT DISTINCT
        order_release_key,
        order_header_key,
        work_order_key,
        work_order_appt_key,
        release_no,
        merge_node,
        ship_to_key,
        shipnode_key,
        enterprise_key,
        buyer_organization_code,
        seller_organization_code,
        document_type,
        bill_to_id,
        ship_to_id,
        pick_list_no,
        scac,
        carrier_service_code,
        custcarrier_account_no,
        delivery_code,
        ship_advice_no,
        shipment_consol_group_id,
        packlist_type,
        sales_order_no,
        order_name,
        order_date,
        order_type,
        customer_po_no,
        mark_for_key,
        buyer_mark_for_node_id,
        cust_req_delivery_date,
        cust_req_ship_date,
        req_delivery_date,
        req_cancel_date,
        req_ship_date,
        priority_code,
        personalize_code,
        currency,
        hold_flag,
        hold_reason_code,
        fob,
        aor_flag,
        division,
        notify_after_shipment_flag,
        notification_type,
        notification_reference,
        ship_complete_flag,
        ship_node_class,
        supplier_code,
        supplier_name,
        release_seq_no,
        ship_order_complete,
        ship_line_complete,
        taxpayer_id,
        purpose,
        gift_flag,
        TRY_CAST(other_charges AS FLOAT) AS other_charges,
        receiving_node,
        buyer_receiving_node_id,
        delivery_method,
        pack_and_hold,
        department_code,
        item_classification,
        level_of_service,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        txn_id
    FROM TRANSFORMED.stg_order_release
) AS sor
ON (
    tor.order_release_key = sor.order_release_key
    AND tor.order_header_key = sor.order_header_key
)
WHEN MATCHED THEN
    UPDATE SET
        tor.order_release_key = sor.order_release_key,
        tor.order_header_key = sor.order_header_key,
        tor.work_order_key = sor.work_order_key,
        tor.work_order_appt_key = sor.work_order_appt_key,
        tor.release_no = sor.release_no,
        tor.merge_node = sor.merge_node,
        tor.ship_to_key = sor.ship_to_key,
        tor.shipnode_key = sor.shipnode_key,
        tor.enterprise_key = sor.enterprise_key,
        tor.buyer_organization_code = sor.buyer_organization_code,
        tor.seller_organization_code = sor.seller_organization_code,
        tor.document_type = sor.document_type,
        tor.bill_to_id = sor.bill_to_id,
        tor.ship_to_id = sor.ship_to_id,
        tor.pick_list_no = sor.pick_list_no,
        tor.scac = sor.scac,
        tor.carrier_service_code = sor.carrier_service_code,
        tor.custcarrier_account_no = sor.custcarrier_account_no,
        tor.delivery_code = sor.delivery_code,
        tor.ship_advice_no = sor.ship_advice_no,
        tor.shipment_consol_group_id = sor.shipment_consol_group_id,
        tor.packlist_type = sor.packlist_type,
        tor.sales_order_no = sor.sales_order_no,
        tor.order_name = sor.order_name,
        tor.order_date = TRY_TO_TIMESTAMP(sor.order_date,'YYYYMMDDHHMISS'),
        tor.order_type = sor.order_type,
        tor.customer_po_no = sor.customer_po_no,
        tor.mark_for_key = sor.mark_for_key,
        tor.buyer_mark_for_node_id = sor.buyer_mark_for_node_id,
        tor.cust_req_delivery_date = TRY_TO_TIMESTAMP(sor.cust_req_delivery_date,'YYYYMMDDHHMISS'),
        tor.cust_req_ship_date = TRY_TO_TIMESTAMP(sor.cust_req_ship_date,'YYYYMMDDHHMISS'),
        tor.req_delivery_date = TRY_TO_TIMESTAMP(sor.req_delivery_date,'YYYYMMDDHHMISS'),
        tor.req_cancel_date = TRY_TO_TIMESTAMP(sor.req_cancel_date,'YYYYMMDDHHMISS'),
        tor.req_ship_date = TRY_TO_TIMESTAMP(sor.req_ship_date,'YYYYMMDDHHMISS'),
        tor.priority_code = sor.priority_code,
        tor.personalize_code = sor.personalize_code,
        tor.currency = sor.currency,
        tor.hold_flag = sor.hold_flag,
        tor.hold_reason_code = sor.hold_reason_code,
        tor.fob = sor.fob,
        tor.aor_flag = sor.aor_flag,
        tor.division = sor.division,
        tor.notify_after_shipment_flag = sor.notify_after_shipment_flag,
        tor.notification_type = sor.notification_type,
        tor.notification_reference = sor.notification_reference,
        tor.ship_complete_flag = sor.ship_complete_flag,
        tor.ship_node_class = sor.ship_node_class,
        tor.supplier_code = sor.supplier_code,
        tor.supplier_name = sor.supplier_name,
        tor.release_seq_no = sor.release_seq_no,
        tor.ship_order_complete = sor.ship_order_complete,
        tor.ship_line_complete = sor.ship_line_complete,
        tor.taxpayer_id = sor.taxpayer_id,
        tor.purpose = sor.purpose,
        tor.gift_flag = sor.gift_flag,
        tor.other_charges = sor.other_charges,
        tor.receiving_node = sor.receiving_node,
        tor.buyer_receiving_node_id = sor.buyer_receiving_node_id,
        tor.delivery_method = sor.delivery_method,
        tor.pack_and_hold = sor.pack_and_hold,
        tor.department_code = sor.department_code,
        tor.item_classification = sor.item_classification,
        tor.level_of_service = sor.level_of_service,
        tor.createts = TRY_TO_TIMESTAMP(sor.createts,'YYYYMMDDHHMISS'),
        tor.modifyts = TRY_TO_TIMESTAMP(sor.modifyts,'YYYYMMDDHHMISS'),
        tor.createuserid = sor.createuserid,
        tor.modifyuserid = sor.modifyuserid,
        tor.createprogid = sor.createprogid,
        tor.modifyprogid = sor.modifyprogid,
        tor.lockid = sor.lockid,
        tor.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        order_release_key,
        order_header_key,
        work_order_key,
        work_order_appt_key,
        release_no,
        merge_node,
        ship_to_key,
        shipnode_key,
        enterprise_key,
        buyer_organization_code,
        seller_organization_code,
        document_type,
        bill_to_id,
        ship_to_id,
        pick_list_no,
        scac,
        carrier_service_code,
        custcarrier_account_no,
        delivery_code,
        ship_advice_no,
        shipment_consol_group_id,
        packlist_type,
        sales_order_no,
        order_name,
        order_date,
        order_type,
        customer_po_no,
        mark_for_key,
        buyer_mark_for_node_id,
        cust_req_delivery_date,
        cust_req_ship_date,
        req_delivery_date,
        req_cancel_date,
        req_ship_date,
        priority_code,
        personalize_code,
        currency,
        hold_flag,
        hold_reason_code,
        fob,
        aor_flag,
        division,
        notify_after_shipment_flag,
        notification_type,
        notification_reference,
        ship_complete_flag,
        ship_node_class,
        supplier_code,
        supplier_name,
        release_seq_no,
        ship_order_complete,
        ship_line_complete,
        taxpayer_id,
        purpose,
        gift_flag,
        other_charges,
        receiving_node,
        buyer_receiving_node_id,
        delivery_method,
        pack_and_hold,
        department_code,
        item_classification,
        level_of_service,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        inserted_date
    ) VALUES (
        sor.order_release_key,
        sor.order_header_key,
        sor.work_order_key,
        sor.work_order_appt_key,
        sor.release_no,
        sor.merge_node,
        sor.ship_to_key,
        sor.shipnode_key,
        sor.enterprise_key,
        sor.buyer_organization_code,
        sor.seller_organization_code,
        sor.document_type,
        sor.bill_to_id,
        sor.ship_to_id,
        sor.pick_list_no,
        sor.scac,
        sor.carrier_service_code,
        sor.custcarrier_account_no,
        sor.delivery_code,
        sor.ship_advice_no,
        sor.shipment_consol_group_id,
        sor.packlist_type,
        sor.sales_order_no,
        sor.order_name,
        TRY_TO_TIMESTAMP(sor.order_date,'YYYYMMDDHHMISS'),
        sor.order_type,
        sor.customer_po_no,
        sor.mark_for_key,
        sor.buyer_mark_for_node_id,
        TRY_TO_TIMESTAMP(sor.cust_req_delivery_date,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(sor.cust_req_ship_date,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(sor.req_delivery_date,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(sor.req_cancel_date,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(sor.req_ship_date,'YYYYMMDDHHMISS'),
        sor.priority_code,
        sor.personalize_code,
        sor.currency,
        sor.hold_flag,
        sor.hold_reason_code,
        sor.fob,
        sor.aor_flag,
        sor.division,
        sor.notify_after_shipment_flag,
        sor.notification_type,
        sor.notification_reference,
        sor.ship_complete_flag,
        sor.ship_node_class,
        sor.supplier_code,
        sor.supplier_name,
        sor.release_seq_no,
        sor.ship_order_complete,
        sor.ship_line_complete,
        sor.taxpayer_id,
        sor.purpose,
        sor.gift_flag,
        sor.other_charges,
        sor.receiving_node,
        sor.buyer_receiving_node_id,
        sor.delivery_method,
        sor.pack_and_hold,
        sor.department_code,
        sor.item_classification,
        sor.level_of_service,
        TRY_TO_TIMESTAMP(sor.createts,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(sor.modifyts,'YYYYMMDDHHMISS'),
        sor.createuserid,
        sor.modifyuserid,
        sor.createprogid,
        sor.modifyprogid,
        sor.lockid,
        CURRENT_TIMESTAMP()
    );

CREATE OR REPLACE TEMPORARY TABLE insertedOrderReleaseRecords AS
SELECT order_release_key
    , order_header_key
    , txn_id 
    , CAST(1 AS INT)  as revision
FROM TRANSFORMED.stg_order_release
;

-- Create a temporary table to hold the revisions
CREATE OR REPLACE TEMPORARY TABLE temp_revisions AS
SELECT
    MAX(aot.revision) as revision,
    aot.order_release_key,
    aot.order_header_key
FROM
    ANALYTICS.audit_order_release aot
    INNER JOIN insertedOrderReleaseRecords ttd
    ON ttd.order_release_key = aot.order_release_key
    AND ttd.order_header_key = aot.order_header_key 
GROUP BY
    aot.order_release_key, aot.order_header_key;

-- Update the temporary table with new revisions
UPDATE insertedOrderReleaseRecords ttd
SET ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS INT)
FROM temp_revisions aot
WHERE ttd.order_release_key = aot.order_release_key
AND ttd.order_header_key = aot.order_header_key;

INSERT INTO ANALYTICS.audit_order_release (
    order_release_key,
    order_header_key,
    work_order_key,
    work_order_appt_key,
    release_no,
    merge_node,
    ship_to_key,
    shipnode_key,
    enterprise_key,
    buyer_organization_code,
    seller_organization_code,
    document_type,
    bill_to_id,
    ship_to_id,
    pick_list_no,
    scac,
    carrier_service_code,
    custcarrier_account_no,
    delivery_code,
    ship_advice_no,
    shipment_consol_group_id,
    packlist_type,
    sales_order_no,
    order_name,
    order_date,
    order_type,
    customer_po_no,
    mark_for_key,
    buyer_mark_for_node_id,
    cust_req_delivery_date,
    cust_req_ship_date,
    req_delivery_date,
    req_cancel_date,
    req_ship_date,
    priority_code,
    personalize_code,
    currency,
    hold_flag,
    hold_reason_code,
    fob,
    aor_flag,
    division,
    notify_after_shipment_flag,
    notification_type,
    notification_reference,
    ship_complete_flag,
    ship_node_class,
    supplier_code,
    supplier_name,
    release_seq_no,
    ship_order_complete,
    ship_line_complete,
    taxpayer_id,
    purpose,
    gift_flag,
    other_charges,
    receiving_node,
    buyer_receiving_node_id,
    delivery_method,
    pack_and_hold,
    department_code,
    item_classification,
    level_of_service,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    revision
)
SELECT
    sor.order_release_key,
    sor.order_header_key,
    sor.work_order_key,
    sor.work_order_appt_key,
    sor.release_no,
    sor.merge_node,
    sor.ship_to_key,
    sor.shipnode_key,
    sor.enterprise_key,
    sor.buyer_organization_code,
    sor.seller_organization_code,
    sor.document_type,
    sor.bill_to_id,
    sor.ship_to_id,
    sor.pick_list_no,
    sor.scac,
    sor.carrier_service_code,
    sor.custcarrier_account_no,
    sor.delivery_code,
    sor.ship_advice_no,
    sor.shipment_consol_group_id,
    sor.packlist_type,
    sor.sales_order_no,
    sor.order_name,
    TRY_TO_TIMESTAMP(sor.order_date,'YYYYMMDDHHMISS'),
    sor.order_type,
    sor.customer_po_no,
    sor.mark_for_key,
    sor.buyer_mark_for_node_id,
    TRY_TO_TIMESTAMP(sor.cust_req_delivery_date,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(sor.cust_req_ship_date,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(sor.req_delivery_date,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(sor.req_cancel_date,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(sor.req_ship_date,'YYYYMMDDHHMISS'),
    sor.priority_code,
    sor.personalize_code,
    sor.currency,
    sor.hold_flag,
    sor.hold_reason_code,
    sor.fob,
    sor.aor_flag,
    sor.division,
    sor.notify_after_shipment_flag,
    sor.notification_type,
    sor.notification_reference,
    sor.ship_complete_flag,
    sor.ship_node_class,
    sor.supplier_code,
    sor.supplier_name,
    sor.release_seq_no,
    sor.ship_order_complete,
    sor.ship_line_complete,
    sor.taxpayer_id,
    sor.purpose,
    sor.gift_flag,
    try_cast(sor.other_charges as float),
    sor.receiving_node,
    sor.buyer_receiving_node_id,
    sor.delivery_method,
    sor.pack_and_hold,
    sor.department_code,
    sor.item_classification,
    sor.level_of_service,
    TRY_TO_TIMESTAMP(sor.createts,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(sor.modifyts,'YYYYMMDDHHMISS'),
    sor.createuserid,
    sor.modifyuserid,
    sor.createprogid,
    sor.modifyprogid,
    sor.lockid,
    CURRENT_TIMESTAMP(), -- Snowflake function to get current timestamp
    ord.revision
FROM TRANSFORMED.stg_order_release sor
INNER JOIN insertedOrderReleaseRecords ord ON ord.order_release_key = sor.order_release_key
AND ord.order_header_key = sor.order_header_key;

MERGE INTO RAW.raw_order_release roor
USING insertedOrderReleaseRecords torr
ON roor.order_release_key = torr.order_release_key 
    AND roor.order_header_key = torr.order_header_key 
    AND roor.txn_id = torr.txn_id
WHEN MATCHED THEN 
UPDATE SET 
    roor.processing_status = 'Processed',
    roor.processing_comment = '',
    roor.processing_errortype = '';

SELECT COUNT(*) INTO :processedRecordCount
FROM insertedOrderReleaseRecords;

SELECT COUNT(*) INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_order_release;

UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = 'Success'
WHERE
    file_name = 'YFS_ORDER_RELEASE';

DROP TABLE IF EXISTS insertedOrderReleaseRecords;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);


COMMIT;

RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_ORDER_RELEASE';
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	
	RETURN error_object;
END;