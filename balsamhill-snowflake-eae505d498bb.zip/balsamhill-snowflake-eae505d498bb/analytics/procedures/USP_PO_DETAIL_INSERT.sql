CREATE  PROCEDURE ANALYTICS.USP_PO_DETAIL_INSERT (pipeline_name varchar
)
    RETURNS STRING
    LANGUAGE SQL
AS
DECLARE
    created_by INT DEFAULT 1;
    processedCount INT;
    modifiedDateInsertRecordsID TIMESTAMP_NTZ DEFAULT TO_TIMESTAMP_NTZ('1970-01-01');
    inputTransactionId INT;
    error_object VARIANT;
	currentDateTime TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP();
	 start_time_proc TIMESTAMP_NTZ(9);

BEGIN
    BEGIN
        start_time_proc := CURRENT_TIMESTAMP();
		SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);
		CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
			);
        CREATE  OR REPLACE TEMP TABLE po_header_temp (
                    pk_po_headerid INT,
                    po_number VARCHAR,
                    fk_receiving_warehouseid INT,
                    fk_po_statusid INT,
                    amount DECIMAL(9, 2),
                    po_date DATETIME,
                    external_id INT,
                    fk_supplierid INT,
                    etd_shipping_start DATETIME,
                    etd_shipping_end DATETIME,
                    initial_eta DATETIME,
                    fk_origin_countryid INT,
                    fk_destination_countryid INT,
                    sur_charge DECIMAL(9, 2),
                    fk_agentid INT,
                    payment_term VARCHAR,
                    initial_payment_approved_on DATETIME,
                    final_payment_approved_on DATETIME,
                    notes VARCHAR,
                    etd_shipping_start_date DATETIME,
                    etd_shipping_end_date DATETIME,
                    confirm_on DATETIME,
                    hbl_booked VARCHAR,
                    sail_on DATETIME,
                    ftn_eta DATETIME,
                    ftn_eta_note VARCHAR,
                    eta_warehouse_date DATETIME,
                    ata_warehouse_date DATETIME,
                    fk_destination_warehouseid INT,
                    total_containers INT,
                    etd INT,
                    created_by INT,
                    modified_date DATETIME,
                    inserted_date DATETIME,
                    valid_from DATETIME,
                    valid_to DATETIME,
                    fk_portid INT,
                    season_name VARCHAR(50),
                    note VARCHAR,
                    commission_percentage DECIMAL(18, 2),
                    who_pays VARCHAR,
                    qb_vendor VARCHAR,
                    potypeid INT
        );


        CREATE  OR REPLACE TEMP TABLE po_tobecreated AS
        SELECT  
            stg.ID,
            stg.PO_NUMBER,
            stg.SUPPLIERID,
            stg.SEASON_NAME,
            stg.RECEIVING_WAREHOUSE_NAME,
            stg.STATUSID,
            TRY_TO_TIMESTAMP(stg.ETD_SHIPPING_START) AS ETD_SHIPPING_START,
            TRY_TO_TIMESTAMP(stg.ETD_SHIPPING_END) AS ETD_SHIPPING_END,
            TRY_TO_TIMESTAMP(stg.INITIAL_ETA) AS INITIAL_ETA,
            stg.ORIGIN_COUNTRYID,
            stg.DESTINATION_COUNTRYID,
            stg.PO_VALUE,
            stg.SUR_CHARGE,
            stg.AGENTID,
            stg.PAYMENT_TERM,
            TRY_TO_TIMESTAMP(stg.INITIAL_PAYMENT_APPROVED_ON) AS INITIAL_PAYMENT_APPROVED_ON,
            TRY_TO_TIMESTAMP(stg.FINAL_PAYMENT_APPROVED_ON) AS FINAL_PAYMENT_APPROVED_ON,
            stg.NOTES,
            TRY_TO_TIMESTAMP(stg.ETD_SHIPPING_START_DATE) AS ETD_SHIPPING_START_DATE,
            TRY_TO_TIMESTAMP(stg.ETD_SHIPPING_END_DATE) AS ETD_SHIPPING_END_DATE,
            TRY_TO_TIMESTAMP(stg.CONFIRM_ON) AS CONFIRM_ON,
            stg.HBL_BOOKED,
            TRY_TO_TIMESTAMP(stg.SAIL_ON) AS SAIL_ON,
            TRY_TO_TIMESTAMP(stg.FTN_ETA) AS FTN_ETA,
            stg.FTN_ETA_NOTE,
            TRY_TO_TIMESTAMP(stg.ETA_WAREHOUSE_DATE) AS ETA_WAREHOUSE_DATE,
            TRY_TO_TIMESTAMP(stg.ATA_WAREHOUSE_DATE) AS ATA_WAREHOUSE_DATE,
            stg.ORIGIN_PORTID,
            stg.DESTINATION_WAREHOUSE_NAME,
            stg.TOTAL_CONTAINERS,
            stg.ETD,
            TRY_TO_TIMESTAMP(stg.CREATED_ON) AS CREATED_ON,
            stg.CREATED_BY,
            TRY_TO_TIMESTAMP(stg.MODIFIED_ON) AS MODIFIED_ON,
            stg.MODIFIED_BY,
            TRY_TO_TIMESTAMP(stg.VALID_FROM) AS VALID_FROM,
            TRY_TO_TIMESTAMP(stg.VALID_TO) AS VALID_TO,
            stg.NOTE,
            stg.WHO_PAYS,
            stg.QB_VENDOR,
            stg.COMMISSION_PERCENTAGE,
            stg.POTYPE
        FROM TRANSFORMED.STG_PO_DETAIL AS stg
                 LEFT JOIN ANALYTICS.TXN_PO_HEADER AS txn ON stg.id = txn.external_id
        WHERE txn.pk_po_headerid IS NULL;


        INSERT INTO ANALYTICS.TXN_PO_HEADER (
             PO_NUMBER,
             FK_RECEIVING_WAREHOUSEID,
             FK_PO_STATUSID,
             AMOUNT,
             PO_DATE,
             EXTERNAL_ID,
             FK_SUPPLIERID,
             ETD_SHIPPING_START,
             ETD_SHIPPING_END,
             INITIAL_ETA,
             FK_ORIGIN_COUNTRYID,
             FK_DESTINATION_COUNTRYID,
             SUR_CHARGE,
             FK_AGENTID,
             PAYMENT_TERM,
             INITIAL_PAYMENT_APPROVED_ON,
             FINAL_PAYMENT_APPROVED_ON,
             NOTES,
             ETD_SHIPPING_START_DATE,
             ETD_SHIPPING_END_DATE,
             CONFIRM_ON,
             HBL_BOOKED,
             SAIL_ON,
             FTN_ETA,
             FTN_ETA_NOTE,
             ETA_WAREHOUSE_DATE,
             ATA_WAREHOUSE_DATE,
             FK_DESTINATION_WAREHOUSEID,
             TOTAL_CONTAINERS,
             ETD,
             CREATED_BY,
             MODIFIED_DATE,
             INSERTED_DATE,
             VALID_FROM,
             VALID_TO,
             FK_PORTID,
             SEASON_NAME,
             NOTE,
             COMMISSION_PERCENTAGE,
             WHO_PAYS,
             QB_VENDOR,
             FK_PO_TYPEID
        )
        SELECT
        pod.po_number,
        wh.pk_warehouseid,
        pod.statusid,
        COALESCE(pod.po_value, '0') AS po_value,
        TRY_TO_TIMESTAMP(pod.created_on) AS created_on,
        pod.id,
        pod.supplierid,
        TRY_TO_TIMESTAMP(pod.etd_shipping_start) AS etd_shipping_start,
        TRY_TO_TIMESTAMP(pod.etd_shipping_end) AS etd_shipping_end,
        TRY_TO_TIMESTAMP(pod.initial_eta) AS initial_eta,
        pod.origin_countryid,
        pod.destination_countryid,
        pod.sur_charge,
        pod.agentid,
        pod.payment_term,
        TRY_TO_TIMESTAMP(pod.initial_payment_approved_on) AS initial_payment_approved_on,
        TRY_TO_TIMESTAMP(pod.final_payment_approved_on) AS final_payment_approved_on,
        pod.notes,
        TRY_TO_TIMESTAMP(pod.etd_shipping_start_date) AS etd_shipping_start_date,
        TRY_TO_TIMESTAMP(pod.etd_shipping_end_date) AS etd_shipping_end_date,
        TRY_TO_TIMESTAMP(pod.confirm_on) AS confirm_on,
        pod.hbl_booked,
        TRY_TO_TIMESTAMP(pod.sail_on) AS sail_on,
        TRY_TO_TIMESTAMP(pod.ftn_eta) AS ftn_eta,
        pod.ftn_eta_note,
        TRY_TO_TIMESTAMP(pod.eta_warehouse_date) AS eta_warehouse_date,
        TRY_TO_TIMESTAMP(pod.ata_warehouse_date) AS ata_warehouse_date,
        dwh.pk_warehouseid,
        pod.total_containers,
        pod.etd,
        :created_by,
        :currentDateTime,
        :currentDateTime,
        TRY_TO_TIMESTAMP(pod.valid_from) AS valid_from,
        TRY_TO_TIMESTAMP(pod.valid_to) AS valid_to,
        pod.origin_portid,
        pod.season_name,
        pod.note,
        pod.commission_percentage,
        pod.who_pays,
        pod.qb_vendor,
        p.id
        FROM TRANSFORMED.STG_PO_DETAIL AS pod
        INNER JOIN MASTER.DIM_PO_STATUS AS post
            ON post.PK_PO_STATUSID = pod.STATUSID
        INNER JOIN po_tobecreated AS pos
            ON pos.ID = pod.ID
        LEFT JOIN MASTER.DIM_SUPPLIER AS su
            ON su.PK_SUPPLIERID = pod.SUPPLIERID
        LEFT JOIN MASTER.DIM_COUNTRY AS con
            ON con.PK_COUNTRYID = pod.ORIGIN_COUNTRYID
        LEFT JOIN MASTER.DIM_COUNTRY AS coun
                  ON coun.PK_COUNTRYID = pod.DESTINATION_COUNTRYID
        LEFT JOIN MASTER.DIM_AGENT AS ag
            ON ag.PK_AGENTID = pod.AGENTID
        LEFT JOIN MASTER.DIM_PORT AS po
            ON po.PK_PORTID = pod.ORIGIN_PORTID
        LEFT JOIN MASTER.DIM_WAREHOUSE AS dwh
            ON  dwh.WAREHOUSE_NAME = pod.DESTINATION_WAREHOUSE_NAME
        LEFT JOIN MASTER.DIM_WAREHOUSE AS wh
            ON wh.WAREHOUSE_NAME = pod.RECEIVING_WAREHOUSE_NAME
        INNER JOIN MASTER.DIM_PO_TYPE AS p
            ON p.POTYPENAME = pod.POTYPE;


        INSERT INTO po_header_temp (
            pk_po_headerid,
            po_number,
            fk_receiving_warehouseid,
            fk_po_statusid,
            amount,
            po_date,
            external_id,
            fk_supplierid,
            etd_shipping_start,
            etd_shipping_end,
            initial_eta,
            fk_origin_countryid,
            fk_destination_countryid,
            sur_charge,
            fk_agentid,
            payment_term,
            initial_payment_approved_on,
            final_payment_approved_on,
            notes,
            etd_shipping_start_date,
            etd_shipping_end_date,
            confirm_on,
            hbl_booked,
            sail_on,
            ftn_eta,
            ftn_eta_note,
            eta_warehouse_date,
            ata_warehouse_date,
            fk_destination_warehouseid,
            total_containers,
            etd,
            created_by,
            modified_date,
            inserted_date,
            valid_from,
            valid_to,
            fk_portid,
            season_name,
            note,
            commission_percentage,
            who_pays,
            qb_vendor,
            potypeid
        )
        SELECT
            PK_PO_HEADERID,
            PO_NUMBER,
            FK_RECEIVING_WAREHOUSEID,
            FK_PO_STATUSID,
            AMOUNT,
            PO_DATE,
            EXTERNAL_ID,
            FK_SUPPLIERID,
            ETD_SHIPPING_START,
            ETD_SHIPPING_END,
            INITIAL_ETA,
            FK_ORIGIN_COUNTRYID,
            FK_DESTINATION_COUNTRYID,
            SUR_CHARGE,
            FK_AGENTID,
            PAYMENT_TERM,
            INITIAL_PAYMENT_APPROVED_ON,
            FINAL_PAYMENT_APPROVED_ON,
            NOTES,
            ETD_SHIPPING_START_DATE,
            ETD_SHIPPING_END_DATE,
            CONFIRM_ON,
            HBL_BOOKED,
            SAIL_ON,
            FTN_ETA,
            FTN_ETA_NOTE,
            ETA_WAREHOUSE_DATE,
            ATA_WAREHOUSE_DATE,
            FK_DESTINATION_WAREHOUSEID,
            TOTAL_CONTAINERS,
            ETD,
            CREATED_BY,
            MODIFIED_DATE,
            INSERTED_DATE,
            VALID_FROM,
            VALID_TO,
            FK_PORTID,
            SEASON_NAME,
            NOTE,
            COMMISSION_PERCENTAGE,
            WHO_PAYS,
            QB_VENDOR,
            FK_PO_TYPEID
        FROM ANALYTICS.TXN_PO_HEADER
        WHERE external_id IN (SELECT id FROM po_tobecreated);


        INSERT INTO ANALYTICS.AUDIT_PO_HEADER (
            PK_PO_HEADERID,
            PO_NUMBER,
            FK_RECEIVING_WAREHOUSEID,
            FK_PO_STATUSID,
            AMOUNT,
            PO_DATE,
            EXTERNAL_ID,
            FK_SUPPLIERID,
            ETD_SHIPPING_START,
            ETD_SHIPPING_END,
            INITIAL_ETA,
            FK_ORIGIN_COUNTRYID,
            FK_DESTINATION_COUNTRYID,
            SUR_CHARGE,
            FK_AGENTID,
            PAYMENT_TERM,
            INITIAL_PAYMENT_APPROVED_ON,
            FINAL_PAYMENT_APPROVED_ON,
            NOTES,
            ETD_SHIPPING_START_DATE,
            ETD_SHIPPING_END_DATE,
            CONFIRM_ON,
            HBL_BOOKED,
            SAIL_ON,
            FTN_ETA,
            FTN_ETA_NOTE,
            ETA_WAREHOUSE_DATE,
            ATA_WAREHOUSE_DATE,
            FK_DESTINATION_WAREHOUSEID,
            TOTAL_CONTAINERS,
            ETD,
            CREATED_BY,
            MODIFIED_DATE,
            INSERTED_DATE,
            VALID_FROM,
            VALID_TO,
            FK_PORTID,
            SEASON_NAME,
            NOTE,
            QB_VENDOR,
            WHO_PAYS,
            COMMISSION_PERCENTAGE,
            FK_PO_TYPEID
        )
        SELECT pk_po_headerid,
               po_number,
               fk_receiving_warehouseid,
               fk_po_statusid,
               amount,
               po_date,
               external_id,
               fk_supplierid,
               etd_shipping_start,
               etd_shipping_end,
               initial_eta,
               fk_origin_countryid,
               fk_destination_countryid,
               sur_charge,
               fk_agentid,
               payment_term,
               initial_payment_approved_on,
               final_payment_approved_on,
               notes,
               etd_shipping_start_date,
               etd_shipping_end_date,
               confirm_on,
               hbl_booked,
               sail_on,
               ftn_eta,
               ftn_eta_note,
               eta_warehouse_date,
               ata_warehouse_date,
               fk_destination_warehouseid,
               total_containers,
               etd,
               created_by,
               modified_date,
               inserted_date,
               valid_from,
               valid_to,
               fk_portid,
               season_name,
               note,
               qb_vendor,
               who_pays,
               commission_percentage,
               potypeid
        FROM po_header_temp;


        INSERT INTO ANALYTICS.TXN_PO_DETAIL(
                FK_PO_HEADERID,
                FK_SKUPRODUCTID,
                FK_INNER_UPCID,
                FK_MASTER_UPCID,
                ORDERED_QUANTITY,
                RECEIVED_QUANTITY,
                EXTERNAL_ID,
                PO_NUMBER,
                SKU_NAME,
                DESCRIPTION,
                INITIAL_UNIT_PRICE,
                TOTAL_SPEND,
                VARIANCE,
                RECEIVED_ON,
                NOTES_ON_RECEIPT,
                ATA_TO_WAREHOUSE,
                ION_RECEIPTS,
                ION_RECEIVE_ON,
                MANUAL_RECEIPTS,
                MANUAL_RECEIVE_ON,
                HTS_CODE,
                HTS_RATE,
                CBF_PER_UNIT,
                TOTAL_CBF,
                SPEND_BY_QTY_RECEIVED,
                ENTERED_BY_ACCT,
                LANDED_COSTS,
                TOTAL_COSTS_BY_QTY_RECEIVED,
                TOTAL_COMMISSION,
                CATEGORY,
                SUB_CATEGORY,
                PG_LANDED_COST,
                TOTAL_LANDED_COST,
                EXPECTED_SHIP_WEEK,
                WEEK_NO_EXPECTED_ARIVAL,
                CREATED_BY,
                MODIFIED_DATE,
                INSERTED_DATE,
                VALID_FROM,
                VALID_TO,
                FK_BRANDID,
                SKUPRODUCTCODE,
                INNER_UPCCODE,
                MASTER_UPCCODE
        )
        SELECT
            poh.pk_po_headerid,
            dims.pk_skuproductid,
            dimu.pk_upcid,
            dimup.pk_upcid,
            skud.quantity_ordered,
            skud.quantity_received,
            skud.id,
            skud.po_number,
            skud.sku_name,
            skud.description,
            skud.initial_unit_price,
            skud.total_spend,
            skud.variance,
            TRY_TO_TIMESTAMP(skud.received_on) AS received_on,
            skud.notes_on_receipt,
            skud.ata_to_warehouse,
            skud.ion_receipts,
            TRY_TO_TIMESTAMP(skud.ion_receive_on) AS ion_receive_on,
            skud.manual_receipts,
            TRY_TO_TIMESTAMP(skud.manual_receive_on) AS manual_receive_on,
            skud.hts_code,
            skud.hts_rate,
            skud.cbf_per_unit,
            skud.total_cbf,
            skud.spend_by_qty_received,
            skud.entered_by_acct,
            skud.landed_costs,
            skud.total_costs_by_qty_received,
            skud.total_commission,
            skud.category,
            skud.sub_category,
            skud.pg_landed_cost,
            skud.total_landed_cost,
            skud.expected_ship_week,
            skud.week_no_expected_arival,
            :created_by,
            :modifiedDateInsertRecordsID,
            :currentDateTime,
            TRY_TO_TIMESTAMP(skud.valid_from) AS valid_from,
            TRY_TO_TIMESTAMP(skud.valid_to) AS valid_to,
            skud.brandid,
            skud.sku_code,
            skud.inner_upc,
            skud.master_upc
        FROM  TRANSFORMED.STG_SKU_DETAIL AS skud
        INNER JOIN  MASTER.DIM_PO_BRAND AS br
            ON br.ID = skud.BRANDID
        INNER JOIN ANALYTICS.TXN_PO_HEADER AS poh
            ON poh.PO_NUMBER = skud.PO_NUMBER
        INNER JOIN po_tobecreated AS pod
            ON pod.ID = poh.EXTERNAL_ID
        LEFT JOIN ANALYTICS.SKU_PRODUCT AS dims
            ON dims.SKU_CODE = skud.SKU_CODE
        LEFT JOIN ANALYTICS.UPC AS dimu
            ON dimu.UPC_CODE = skud.INNER_UPC
        LEFT JOIN ANALYTICS.UPC AS dimup
            ON dimup.UPC_CODE = skud.MASTER_UPC;


        INSERT INTO ANALYTICS.AUDIT_PO_DETAIL(
            PK_PO_DETAILID,
            FK_PO_HEADERID,
            FK_SKUPRODUCTID,
            FK_INNER_UPCID,
            FK_MASTER_UPCID,
            ORDERED_QUANTITY,
            RECEIVED_QUANTITY,
            EXTERNAL_ID,
            PO_NUMBER,
            SKU_NAME,
            DESCRIPTION,
            INITIAL_UNIT_PRICE,
            TOTAL_SPEND,
            VARIANCE,
            RECEIVED_ON,
            NOTES_ON_RECEIPT,
            ATA_TO_WAREHOUSE,
            ION_RECEIPTS,
            ION_RECEIVE_ON,
            MANUAL_RECEIPTS,
            MANUAL_RECEIVE_ON,
            HTS_CODE,
            HTS_RATE,
            CBF_PER_UNIT,
            TOTAL_CBF,
            SPEND_BY_QTY_RECEIVED,
            ENTERED_BY_ACCT,
            LANDED_COSTS,
            TOTAL_COSTS_BY_QTY_RECEIVED,
            TOTAL_COMMISSION,
            CATEGORY,
            SUB_CATEGORY,
            PG_LANDED_COST,
            TOTAL_LANDED_COST,
            EXPECTED_SHIP_WEEK,
            WEEK_NO_EXPECTED_ARIVAL,
            CREATED_BY,
            MODIFIED_DATE,
            INSERTED_DATE,
            VALID_FROM,
            VALID_TO,
            FK_BRANDID,
            SKUPRODUCTCODE,
            INNER_UPCCODE,
            MASTER_UPCCODE
        )
        SELECT source.PK_PO_DETAILID,
               source.FK_PO_HEADERID,
               source.FK_SKUPRODUCTID,
               source.FK_INNER_UPCID,
               source.FK_MASTER_UPCID,
               source.ORDERED_QUANTITY,
               source.RECEIVED_QUANTITY,
               source.EXTERNAL_ID,
               source.PO_NUMBER,
               source.SKU_NAME,
               source.DESCRIPTION,
               source.INITIAL_UNIT_PRICE,
               source.TOTAL_SPEND,
               source.VARIANCE,
               source.RECEIVED_ON,
               source.NOTES_ON_RECEIPT,
               source.ATA_TO_WAREHOUSE,
               source.ION_RECEIPTS,
               source.ION_RECEIVE_ON,
               source.MANUAL_RECEIPTS,
               source.MANUAL_RECEIVE_ON,
               source.HTS_CODE,
               source.HTS_RATE,
               source.CBF_PER_UNIT,
               source.TOTAL_CBF,
               source.SPEND_BY_QTY_RECEIVED,
               source.ENTERED_BY_ACCT,
               source.LANDED_COSTS,
               source.TOTAL_COSTS_BY_QTY_RECEIVED,
               source.TOTAL_COMMISSION,
               source.CATEGORY,
               source.SUB_CATEGORY,
               source.PG_LANDED_COST,
               source.TOTAL_LANDED_COST,
               source.EXPECTED_SHIP_WEEK,
               source.WEEK_NO_EXPECTED_ARIVAL,
               :created_by,
               :currentDateTime,
               :currentDateTime,
               source.VALID_FROM,
               source.VALID_TO,
               source.FK_BRANDID,
               source.SKUPRODUCTCODE,
               source.INNER_UPCCODE,
               source.MASTER_UPCCODE
        FROM ANALYTICS.TXN_PO_DETAIL AS source
        WHERE MODIFIED_DATE = '1970-01-01';


        UPDATE ANALYTICS.TXN_PO_DETAIL
        SET MODIFIED_DATE = INSERTED_DATE
        WHERE MODIFIED_DATE = '1970-01-01';


        CREATE  OR REPLACE TEMP TABLE po_tobeupdated AS
        SELECT
            stg.ID,
            stg.SKU_CODE,
            stg.SKU_NAME,
            stg.DESCRIPTION,
            stg.QUANTITY_ORDERED,
            stg.INITIAL_UNIT_PRICE,
            stg.TOTAL_SPEND,
            stg.INNER_UPC,
            stg.MASTER_UPC,
            stg.QUANTITY_RECEIVED,
            stg.VARIANCE,
            TRY_TO_TIMESTAMP(stg.RECEIVED_ON) AS RECEIVED_ON,
            stg.NOTES_ON_RECEIPT,
            stg.ATA_TO_WAREHOUSE,
            stg.ION_RECEIPTS,
            TRY_TO_TIMESTAMP(stg.ION_RECEIVE_ON) AS ION_RECEIVE_ON,
            stg.MANUAL_RECEIPTS,
            TRY_TO_TIMESTAMP(stg.MANUAL_RECEIVE_ON) AS MANUAL_RECEIVE_ON,
            stg.HTS_CODE,
            stg.HTS_RATE,
            stg.CBF_PER_UNIT,
            stg.TOTAL_CBF,
            stg.SPEND_BY_QTY_RECEIVED,
            stg.ENTERED_BY_ACCT,
            stg.LANDED_COSTS,
            stg.TOTAL_COSTS_BY_QTY_RECEIVED,
            stg.TOTAL_COMMISSION,
            stg.CATEGORY,
            stg.SUB_CATEGORY,
            stg.PG_LANDED_COST,
            stg.TOTAL_LANDED_COST,
            stg.EXPECTED_SHIP_WEEK,
            stg.WEEK_NO_EXPECTED_ARIVAL,
            TRY_TO_TIMESTAMP(stg.CREATED_ON) AS CREATED_ON,
            stg.CREATED_BY,
            TRY_TO_TIMESTAMP(stg.MODIFIED_ON) AS MODIFIED_ON,
            stg.MODIFIED_BY,
            TRY_TO_TIMESTAMP(stg.VALID_FROM) AS VALID_FROM,
            TRY_TO_TIMESTAMP(stg.VALID_TO) AS VALID_TO,
            stg.PO_NUMBER,
            stg.BRANDID,
            stg.DISCREPANCYREASON
        FROM TRANSFORMED.STG_SKU_DETAIL AS stg
        LEFT JOIN ANALYTICS.TXN_PO_DETAIL AS txn
            ON stg.ID = txn.EXTERNAL_ID
        WHERE txn.PK_PO_DETAILID IS NULL;


        INSERT INTO ANALYTICS.TXN_PO_DETAIL(
            FK_PO_HEADERID,
            FK_SKUPRODUCTID,
            FK_INNER_UPCID,
            FK_MASTER_UPCID,
            ORDERED_QUANTITY,
            RECEIVED_QUANTITY,
            EXTERNAL_ID,
            PO_NUMBER,
            SKU_NAME,
            DESCRIPTION,
            INITIAL_UNIT_PRICE,
            TOTAL_SPEND,
            VARIANCE,
            RECEIVED_ON,
            NOTES_ON_RECEIPT,
            ATA_TO_WAREHOUSE,
            ION_RECEIPTS,
            ION_RECEIVE_ON,
            MANUAL_RECEIPTS,
            MANUAL_RECEIVE_ON,
            HTS_CODE,
            HTS_RATE,
            CBF_PER_UNIT,
            TOTAL_CBF,
            SPEND_BY_QTY_RECEIVED,
            ENTERED_BY_ACCT,
            LANDED_COSTS,
            TOTAL_COSTS_BY_QTY_RECEIVED,
            TOTAL_COMMISSION,
            CATEGORY,
            SUB_CATEGORY,
            PG_LANDED_COST,
            TOTAL_LANDED_COST,
            EXPECTED_SHIP_WEEK,
            WEEK_NO_EXPECTED_ARIVAL,
            CREATED_BY,
            MODIFIED_DATE,
            INSERTED_DATE,
            VALID_FROM,
            VALID_TO,
            FK_BRANDID,
            SKUPRODUCTCODE,
            INNER_UPCCODE,
            MASTER_UPCCODE,
            DISCREPANCYREASON
        )
       SELECT
            poh.pk_po_headerid,
            dims.pk_skuproductid,
            dimu.pk_upcid,
            dimup.pk_upcid,
            skud.quantity_ordered,
            skud.quantity_received,
            skud.id,
            skud.po_number,
            skud.sku_name,
            skud.description,
            skud.initial_unit_price,
            skud.total_spend,
            skud.variance,
            TRY_TO_TIMESTAMP(skud.received_on) AS received_on,
            skud.notes_on_receipt,
            skud.ata_to_warehouse,
            skud.ion_receipts,
            TRY_TO_TIMESTAMP(skud.ion_receive_on) AS ion_receive_on,
            skud.manual_receipts,
            TRY_TO_TIMESTAMP(skud.manual_receive_on) AS manual_receive_on,
            skud.hts_code,
            skud.hts_rate,
            skud.cbf_per_unit,
            skud.total_cbf,
            skud.spend_by_qty_received,
            skud.entered_by_acct,
            skud.landed_costs,
            skud.total_costs_by_qty_received,
            skud.total_commission,
            skud.category,
            skud.sub_category,
            skud.pg_landed_cost,
            skud.total_landed_cost,
            skud.expected_ship_week,
            skud.week_no_expected_arival,
            :created_by,
            :modifiedDateInsertRecordsID,
            :currentDateTime,
            TRY_TO_TIMESTAMP(skud.valid_from) AS valid_from,
            TRY_TO_TIMESTAMP(skud.valid_to) AS valid_to,
            skud.brandid,
            skud.sku_code,
            skud.inner_upc,
            skud.master_upc,
            skud.discrepancyreason
        FROM TRANSFORMED.STG_SKU_DETAIL AS skud
                 INNER JOIN MASTER.DIM_PO_BRAND AS br
                            ON br.ID = skud.BRANDID
                 INNER JOIN ANALYTICS.TXN_PO_HEADER AS poh
                            ON poh.PO_NUMBER = skud.PO_NUMBER
                 INNER JOIN po_tobeupdated AS pod
                            ON pod.ID = poh.EXTERNAL_ID
                 LEFT JOIN ANALYTICS.SKU_PRODUCT AS dims
                           ON dims.SKU_CODE = skud.SKU_CODE
                 LEFT JOIN ANALYTICS.UPC AS dimu
                           ON dimu.UPC_CODE = skud.INNER_UPC
                 LEFT JOIN ANALYTICS.UPC AS dimup
                           ON dimup.UPC_CODE = skud.MASTER_UPC;


        INSERT INTO ANALYTICS.AUDIT_PO_DETAIL(
            PK_PO_DETAILID,
            FK_PO_HEADERID,
            FK_SKUPRODUCTID,
            FK_INNER_UPCID,
            FK_MASTER_UPCID,
            ORDERED_QUANTITY,
            RECEIVED_QUANTITY,
            EXTERNAL_ID,
            PO_NUMBER,
            SKU_NAME,
            DESCRIPTION,
            INITIAL_UNIT_PRICE,
            TOTAL_SPEND,
            VARIANCE,
            RECEIVED_ON,
            NOTES_ON_RECEIPT,
            ATA_TO_WAREHOUSE,
            ION_RECEIPTS,
            ION_RECEIVE_ON,
            MANUAL_RECEIPTS,
            MANUAL_RECEIVE_ON,
            HTS_CODE,
            HTS_RATE,
            CBF_PER_UNIT,
            TOTAL_CBF,
            SPEND_BY_QTY_RECEIVED,
            ENTERED_BY_ACCT,
            LANDED_COSTS,
            TOTAL_COSTS_BY_QTY_RECEIVED,
            TOTAL_COMMISSION,
            CATEGORY,
            SUB_CATEGORY,
            PG_LANDED_COST,
            TOTAL_LANDED_COST,
            EXPECTED_SHIP_WEEK,
            WEEK_NO_EXPECTED_ARIVAL,
            CREATED_BY,
            MODIFIED_DATE,
            INSERTED_DATE,
            VALID_FROM,
            VALID_TO,
            FK_BRANDID,
            SKUPRODUCTCODE,
            INNER_UPCCODE,
            MASTER_UPCCODE
        )
        SELECT source.PK_PO_DETAILID,
               source.FK_PO_HEADERID,
               source.FK_SKUPRODUCTID,
               source.FK_INNER_UPCID,
               source.FK_MASTER_UPCID,
               source.ORDERED_QUANTITY,
               source.RECEIVED_QUANTITY,
               source.EXTERNAL_ID,
               source.PO_NUMBER,
               source.SKU_NAME,
               source.DESCRIPTION,
               source.INITIAL_UNIT_PRICE,
               source.TOTAL_SPEND,
               source.VARIANCE,
               source.RECEIVED_ON,
               source.NOTES_ON_RECEIPT,
               source.ATA_TO_WAREHOUSE,
               source.ION_RECEIPTS,
               source.ION_RECEIVE_ON,
               source.MANUAL_RECEIPTS,
               source.MANUAL_RECEIVE_ON,
               source.HTS_CODE,
               source.HTS_RATE,
               source.CBF_PER_UNIT,
               source.TOTAL_CBF,
               source.SPEND_BY_QTY_RECEIVED,
               source.ENTERED_BY_ACCT,
               source.LANDED_COSTS,
               source.TOTAL_COSTS_BY_QTY_RECEIVED,
               source.TOTAL_COMMISSION,
               source.CATEGORY,
               source.SUB_CATEGORY,
               source.PG_LANDED_COST,
               source.TOTAL_LANDED_COST,
               source.EXPECTED_SHIP_WEEK,
               source.WEEK_NO_EXPECTED_ARIVAL,
               :created_by,
               :currentDateTime,
               :currentDateTime,
               source.VALID_FROM,
               source.VALID_TO,
               source.FK_BRANDID,
               source.SKUPRODUCTCODE,
               source.INNER_UPCCODE,
               source.MASTER_UPCCODE
        FROM ANALYTICS.TXN_PO_DETAIL AS source
        WHERE MODIFIED_DATE = '1970-01-01';

        UPDATE ANALYTICS.TXN_PO_DETAIL
        SET MODIFIED_DATE = INSERTED_DATE
        WHERE MODIFIED_DATE = '1970-01-01';

    SELECT COUNT(*) INTO processedCount FROM po_header_temp;

   -- UPDATE ANALYTICS.LOG_INPUT_TXN
    --SET IS_REJECTED = 0,
     --   RECORD_COUNT = :processedCount
    --WHERE ID = :inputTransactionId;
	CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

    COMMIT;

    RETURN 'Success';

    EXCEPTION
        WHEN statement_error THEN
            ROLLBACK;

            error_object := OBJECT_CONSTRUCT(
                    'Error type', 'STATEMENT_ERROR',
                    'SQLCODE', sqlcode,
                    'SQLERRM', sqlerrm,
                    'SQLSTATE', sqlstate
                            );
	CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
            --UPDATE ANALYTICS.LOG_INPUT_TXN
            --SET IS_REJECTED = 1,
            --    ERROR_MESSAGE = sqlerrm
            --WHERE ID = :inputTransactionId;

            RETURN 'ERROR: ' || sqlerrm;
    END;

END;