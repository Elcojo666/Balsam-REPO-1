
CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDERS_PAYMENTS_INSERT(pipeline_name VARCHAR)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE 
    createdby NUMBER DEFAULT 1;
    shipAddressType NUMBER;
    InitialRevision NUMBER DEFAULT 1;
    prcessedRecordCount NUMBER DEFAULT 0;
    maxPaymentId NUMBER;
    maxPaymentMethodId NUMBER;  
    toBeProcessedRecordCount NUMBER;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);

BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

SELECT COALESCE(MAX(pk_payment_typeid)+1, 0)  INTO :maxPaymentId FROM  master.dim_PAYMENT_TYPE;

  
  --CREATE or replace SEQUENCE analytics.payment_seq STARTswith ((:maxPaymentId)+1) INCREMENT BY 1 ;
  
execute immediate 'CREATE or replace SEQUENCE analytics.payment_seq start with ' ||:maxPaymentId ||' INCREMENT BY 1';


  INSERT INTO master.dim_PAYMENT_TYPE(pk_payment_typeid, payment_type_name)
  SELECT  analytics.payment_Seq.NEXTVAL+ 1, LOWER(temp.payment_type)
  FROM (
    SELECT DISTINCT stg.payment_type
    FROM transformed.stg_order_payment stg
    LEFT JOIN analytics.txn_order_header ord ON stg.order_header_key = ord.order_header_key
    LEFT JOIN master.dim_PAYMENT_TYPE AS ptype ON LOWER(ptype.payment_type_name) = LOWER(stg.payment_type)
    WHERE pk_order_headerid IS NOT NULL AND ptype.pk_payment_typeid IS NULL
  ) AS temp;

  

  SELECT COALESCE(MAX(pk_payment_method_id)+1,0) INTO :maxPaymentMethodId FROM master.dim_PAYMENT_METHOD;

   --CREATE or replace SEQUENCE analytics.payment_seq START WITH :maxPaymentMethodId+1 INCREMENT BY 1 ;

   execute immediate 'CREATE or replace SEQUENCE analytics.payment_seq start with ' ||:maxPaymentMethodId ||' INCREMENT BY 1';

  INSERT INTO master.dim_PAYMENT_METHOD(pk_payment_method_id, payment_method_name)
  SELECT analytics.payment_Seq.NEXTVAL+ 1, LOWER(temp.payment_method)
  FROM (
    SELECT DISTINCT stg.credit_card_type AS payment_method
    FROM transformed.stg_order_payment stg
    LEFT JOIN analytics.txn_order_header ord ON stg.order_header_key = ord.order_header_key
    LEFT JOIN master.dim_PAYMENT_METHOD AS pmethod ON LOWER(pmethod.payment_method_name) = LOWER(stg.credit_card_type)
    WHERE pk_order_headerid IS NOT NULL AND pmethod.pk_payment_method_id IS NULL AND stg.credit_card_type IS NOT NULL
  ) AS temp;


  
create or replace temporary table analytics.orderpaymentdetails as 
  SELECT
    ptype.pk_payment_typeid AS fk_payment_typeid,
    NULL AS authorization_id,
    pmethod.pk_payment_method_id AS fk_payment_method_id,
    ord.fk_sourceid,
    ord.pk_order_headerid,
    stg.payment_key AS ext_paymentid,
    NULL AS auth_code,
    NULL AS cvv2_response,
    ord.fk_currencyid,
    stg.total_charged AS payment_amount,
    CONCAT('xxx-xxx-', RIGHT(stg.credit_card_no, 4)) AS payment_Details,
    0 AS is_deleted,
    1 AS seq_no,
    stg.createts AS order_payment_date,
    stg.display_credit_card_no
  FROM
     transformed.stg_order_payment stg
  LEFT JOIN analytics.txn_order_header ord ON stg.order_header_key = ord.order_header_key
  LEFT JOIN master.dim_PAYMENT_TYPE AS ptype ON LOWER(ptype.payment_type_name) = LOWER(stg.payment_type)
  LEFT JOIN master.dim_PAYMENT_METHOD AS pmethod ON LOWER(pmethod.payment_method_name) = LOWER(stg.credit_card_type)
  WHERE
    pk_order_headerid IS NOT NULL AND ptype.pk_payment_typeid IS NOT NULL;


CREATE OR REPLACE temporary TABLE analytics.paymentseqno AS
  SELECT
    paydetails.ext_paymentid,
    COALESCE(MAX(txnpay.seq_no) + 1, 1) AS calc_seq_no
  FROM
    analytics.orderpaymentdetails paydetails
  LEFT JOIN analytics.txn_payment txnpay ON paydetails.pk_order_headerid = txnpay.fk_order_headerid AND paydetails.ext_paymentid <> txnpay.ext_paymentid
  GROUP BY
    paydetails.ext_paymentid;

    create or replace temporary table analytics.VALID_charge_transaction as 
SELECT DISTINCT * FROM analytics.txn_charge_transaction as r where r.status ='CHECKED'  ;


   MERGE INTO  analytics.txn_payment AS pay
USING (
    SELECT 
        pd.*, 
        ps.calc_seq_no,
        tct.authorization_id AS auth_id
    FROM 
        analytics.orderpaymentdetails AS pd
    JOIN 
        analytics.paymentseqno AS ps 
    ON 
        pd.ext_paymentid = ps.ext_paymentid
    LEFT JOIN 
        analytics.VALID_charge_transaction AS tct 
    ON 
        tct.payment_key = pd.ext_paymentid
) AS paydetail ON paydetail.ext_paymentid = pay.ext_paymentid
WHEN NOT MATCHED THEN
    INSERT (
      transactionid,
      ext_paymentid,
      fk_sourceid,
      fk_payment_methodid,
      fk_payment_typeid,
      authorization_code,
      avs_response,
      cvv2_response,
      payment_amount,
      fk_currencyid,
      payment_details,
      isdeleted,
      payment_date,
      cc_last4,
      fk_parent_paymentid,
      fk_order_headerid,
      seq_no,
      CreatedDate,
      modified_date
    )
    VALUES (
      COALESCE(paydetail.auth_id, '0'),
      paydetail.ext_paymentid,
      paydetail.fk_sourceid,
      COALESCE(paydetail.fk_payment_method_id, 23),
      paydetail.fk_payment_typeid,
      NULL,
      NULL,
      paydetail.cvv2_response,
      paydetail.payment_amount,
      paydetail.fk_currencyid,
      paydetail.payment_details,
      0,
      -- TO_TIMESTAMP(CONCAT(SUBSTRING(paydetail.order_payment_date, 1, 8), ' ', STUFF(STUFF(RIGHT(paydetail.order_payment_date, 6), 5, 0, ':'), 3, 0, ':'))),
      try_to_timestamp(order_payment_date,'yyyymmddhhmiss'),
      REPLACE(paydetail.display_credit_card_no, '.0', ''),
      NULL,
      paydetail.pk_order_headerid,
      paydetail.calc_seq_no,
      current_timestamp(),
      current_timestamp()
      
    );

    UPDATE raw.raw_order_payment raw
  SET
    raw.processing_status = 'Processed',
    raw.processing_comment = 'Inserted into Payments',
    raw.processing_errortype = NULL,
    raw.imported_date = current_timestamp()
  where raw.payment_key in 
  (select raw.payment_key from 
    raw.raw_order_payment raw
  JOIN analytics.orderpaymentdetails paydetails ON paydetails.ext_paymentid = raw.payment_key
  JOIN analytics.txn_payment txn ON txn.ext_paymentid = raw.payment_key);

  SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM transformed.stg_order_payment;

  
  SELECT COUNT(*) INTO :prcessedRecordCount  from analytics.orderpaymentdetails;

  UPDATE analytics.log_files_import_status lofis
  SET
    lofis.processed = :prcessedRecordCount,
    lofis.to_be_processed = :toBeProcessedRecordCount,
    lofis.status = 'Success'
  WHERE
    lofis.file_name = 'YFS_PAYMENT';
CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

COMMIT;

RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_PAYMENT';
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	
	RETURN error_object;
END;

