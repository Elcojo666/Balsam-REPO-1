USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_VALIDATE_ARCHIVE_TABLE_SCHEMA("SOURCETABLENAME" VARCHAR(16777216), "DESTINATIONTABLENAME" VARCHAR(16777216))
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    sourceColumnCount INT;
    destinationColumnCount INT;
    sourceColumns ARRAY;
    destinationColumns ARRAY;
    schemaMatch BOOLEAN;
BEGIN
    schemaMatch := FALSE;

    BEGIN
        sourceColumnCount := (SELECT COUNT(*)
                              FROM INFORMATION_SCHEMA.COLUMNS
                              WHERE TABLE_NAME = :sourceTableName);

        destinationColumnCount := (SELECT COUNT(*)
                                   FROM INFORMATION_SCHEMA.COLUMNS
                                    WHERE TABLE_NAME = :destinationTableName);
    IF (sourceColumnCount + 1 = destinationColumnCount) THEN
        IF (NOT EXISTS (
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = UPPER(:sourceTableName) AND COLUMN_NAME != UPPER(''archived_date'')
            MINUS
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = UPPER(:destinationTableName) AND COLUMN_NAME != UPPER(''archived_date'')
        ) AND NOT EXISTS (
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = UPPER(:destinationTableName) AND COLUMN_NAME != UPPER(''archived_date'')
            MINUS
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = UPPER(:sourceTableName) AND COLUMN_NAME != UPPER(''archived_date'')
        )) THEN
            schemaMatch := TRUE; -- Schemas match (excluding ''archived_date'')
        ELSE
            schemaMatch := FALSE; -- Schemas don''t match
        END IF;
    ELSE 
        schemaMatch := FALSE;
    END IF; 

    RETURN schemaMatch;
    EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
    END;
END';
