
CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_EXTN_WARRANTY_DATA_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 
DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED - '||:pipeline_name);

    UPDATE ANALYTICS.log_files_import_status 
    SET processed = :processedRecordCount,
        raw_table = 'raw_order_extn_warranty_data'    
    WHERE file_name = 'YFS_ORDER_EXTN_WARRANTY_DATA';

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

    CREATE OR REPLACE TEMPORARY TABLE TempWarrantyData (
        WARRANTY_KEY STRING,
        WARRANTY_ORDER_LINE_KEY STRING,
        CONTRACT_ID STRING,
        START_TS TIMESTAMP_NTZ(9),
        END_TS TIMESTAMP_NTZ(9),
        CANCEL_TS TIMESTAMP_NTZ(9),
        STATUS STRING,
        TYPE STRING,
        WARRANTY_TYPE STRING,
        LOCKID STRING,
        CREATETS TIMESTAMP_NTZ(9),
        MODIFYTS TIMESTAMP_NTZ(9),
        CREATEUSERID STRING,
        MODIFYUSERID STRING,
        CREATEPROGID STRING,
        MODIFYPROGID STRING,
        inserted_date TIMESTAMP_NTZ(9),
        modified_date TIMESTAMP_NTZ(9),
        revision INT
    );

    processedDate := CURRENT_TIMESTAMP();

    -- Upsert into TXN table
    MERGE INTO ANALYTICS.txn_order_extn_warranty_data AS tgt
    USING (
        SELECT
            WARRANTY_KEY,
            WARRANTY_ORDER_LINE_KEY,
            CONTRACT_ID,
            START_TS,
            END_TS,
            CANCEL_TS,
            STATUS,
            TYPE,
            WARRANTY_TYPE,
            LOCKID,
            CREATETS,
            MODIFYTS,
            CREATEUSERID,
            MODIFYUSERID,
            CREATEPROGID,
            MODIFYPROGID
        FROM TRANSFORMED.stg_order_extn_warranty_data AS stg
    ) AS src
    ON tgt.WARRANTY_KEY = src.WARRANTY_KEY
    WHEN MATCHED THEN
        UPDATE SET
            tgt.WARRANTY_ORDER_LINE_KEY = src.WARRANTY_ORDER_LINE_KEY,
            tgt.CONTRACT_ID = src.CONTRACT_ID,
            tgt.START_TS = TRY_TO_TIMESTAMP(src.START_TS,'YYYYMMDDHHMISS'),
            tgt.END_TS = TRY_TO_TIMESTAMP(src.END_TS,'YYYYMMDDHHMISS'),
            tgt.CANCEL_TS = TRY_TO_TIMESTAMP(src.CANCEL_TS,'YYYYMMDDHHMISS'),
            tgt.STATUS = src.STATUS,
            tgt.TYPE = src.TYPE,
            tgt.WARRANTY_TYPE = src.WARRANTY_TYPE,
            tgt.LOCKID = src.LOCKID,
            tgt.CREATETS = TRY_TO_TIMESTAMP(src.CREATETS,'YYYYMMDDHHMISS'),
            tgt.MODIFYTS = TRY_TO_TIMESTAMP(src.MODIFYTS,'YYYYMMDDHHMISS'),
            tgt.CREATEUSERID = src.CREATEUSERID,
            tgt.MODIFYUSERID = src.MODIFYUSERID,
            tgt.CREATEPROGID = src.CREATEPROGID,
            tgt.MODIFYPROGID = src.MODIFYPROGID,
            tgt.modified_date = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
            WARRANTY_KEY,
            WARRANTY_ORDER_LINE_KEY,
            CONTRACT_ID,
            START_TS,
            END_TS,
            CANCEL_TS,
            STATUS,
            TYPE,
            WARRANTY_TYPE,
            LOCKID,
            CREATETS,
            MODIFYTS,
            CREATEUSERID,
            MODIFYUSERID,
            CREATEPROGID,
            MODIFYPROGID,
            inserted_date
        )
        VALUES (
            src.WARRANTY_KEY,
            src.WARRANTY_ORDER_LINE_KEY,
            src.CONTRACT_ID,
            TRY_TO_TIMESTAMP(src.START_TS,'YYYYMMDDHHMISS'),
            TRY_TO_TIMESTAMP(src.END_TS,'YYYYMMDDHHMISS'),
            TRY_TO_TIMESTAMP(src.CANCEL_TS,'YYYYMMDDHHMISS'),
            src.STATUS,
            src.TYPE,
            src.WARRANTY_TYPE,
            src.LOCKID,
            TRY_TO_TIMESTAMP(src.CREATETS,'YYYYMMDDHHMISS'),
            TRY_TO_TIMESTAMP(src.MODIFYTS,'YYYYMMDDHHMISS'),
            src.CREATEUSERID,
            src.MODIFYUSERID,
            src.CREATEPROGID,
            src.MODIFYPROGID,
            CURRENT_TIMESTAMP()
        );

    -- Capture changed rows for audit insert
    INSERT INTO TempWarrantyData (
        WARRANTY_KEY,
        WARRANTY_ORDER_LINE_KEY,
        CONTRACT_ID,
        START_TS,
        END_TS,
        CANCEL_TS,
        STATUS,
        TYPE,
        WARRANTY_TYPE,
        LOCKID,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        inserted_date,
        Revision
    )
    SELECT
        WARRANTY_KEY,
        WARRANTY_ORDER_LINE_KEY,
        CONTRACT_ID,
        START_TS,
        END_TS,
        CANCEL_TS,
        STATUS,
        TYPE,
        WARRANTY_TYPE,
        LOCKID,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        CURRENT_TIMESTAMP(),
        1
    FROM ANALYTICS.txn_order_extn_warranty_data tcd
    WHERE tcd.inserted_date >= :processedDate OR tcd.modified_date >= :processedDate;

    CREATE OR REPLACE TEMPORARY TABLE TempMaxRevisions AS
    SELECT
        MAX(aot.revision) AS revision,
        aot.WARRANTY_KEY
    FROM ANALYTICS.audit_order_extn_warranty_data AS aot
    INNER JOIN TempWarrantyData AS twd
        ON twd.WARRANTY_KEY = aot.WARRANTY_KEY
    GROUP BY aot.WARRANTY_KEY;

    UPDATE TempWarrantyData AS twd
    SET twd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
    FROM TempMaxRevisions AS aot
    WHERE twd.WARRANTY_KEY = aot.WARRANTY_KEY;

    -- Insert into Audit Table
    INSERT INTO ANALYTICS.audit_order_extn_warranty_data (
        WARRANTY_KEY,
        WARRANTY_ORDER_LINE_KEY,
        CONTRACT_ID,
        START_TS,
        END_TS,
        CANCEL_TS,
        STATUS,
        TYPE,
        WARRANTY_TYPE,
        LOCKID,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        inserted_date,
        Revision
    )
    SELECT
        stg.WARRANTY_KEY,
        stg.WARRANTY_ORDER_LINE_KEY,
        stg.CONTRACT_ID,
        TRY_TO_TIMESTAMP(stg.START_TS,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(stg.END_TS,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(stg.CANCEL_TS,'YYYYMMDDHHMISS'),
        stg.STATUS,
        stg.TYPE,
        stg.WARRANTY_TYPE,
        stg.LOCKID,
        TRY_TO_TIMESTAMP(stg.CREATETS,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(stg.MODIFYTS,'YYYYMMDDHHMISS'),
        stg.CREATEUSERID,
        stg.MODIFYUSERID,
        stg.CREATEPROGID,
        stg.MODIFYPROGID,
        CURRENT_TIMESTAMP(),
        ord.Revision
    FROM TRANSFORMED.stg_order_extn_warranty_data stg
    INNER JOIN TempWarrantyData ord
        ON ord.WARRANTY_KEY = stg.WARRANTY_KEY;

    UPDATE RAW.raw_ORDER_extn_warranty_data AS roh
    SET 
        roh.processing_status = 'Processed',
        roh.processing_comment = '',
        roh.processing_errortype = ''
    FROM TRANSFORMED.stg_order_extn_warranty_data AS stg
    INNER JOIN ANALYTICS.txn_order_extn_warranty_data AS toh
        ON toh.WARRANTY_KEY = stg.WARRANTY_KEY
    WHERE roh.WARRANTY_KEY = stg.WARRANTY_KEY and roh.MODIFYTS = stg.modifyts;

    SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM TRANSFORMED.stg_order_extn_warranty_data;
    SELECT COUNT(*) INTO :processedRecordCount FROM TempWarrantyData;

    UPDATE analytics.log_files_import_status
    SET
        processed = :processedRecordCount,
        to_be_processed = :toBeProcessedRecordCount,
        status = 'Success'
    WHERE file_name = 'YFS_ORDER_EXTN_WARRANTY_DATA';

    DROP TABLE IF EXISTS TempWarrantyData;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'COMPLETED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        'upsert completed successfully'
    );

    SYSTEM$LOG('TRACE','SP COMPLETED - '||:pipeline_name);

    COMMIT;
    RETURN 'Success';

EXCEPTION
    WHEN statement_error THEN
        ROLLBACK;
        UPDATE ANALYTICS.log_files_import_status
            SET processed = 0,
                status = 'Failed'
        WHERE file_name = 'YFS_ORDER_EXTN_WARRANTY_DATA';

        error_object := OBJECT_CONSTRUCT(
            'Error type', 'STATEMENT_ERROR',
            'SQLCODE', sqlcode,
            'SQLERRM', sqlerrm,
            'SQLSTATE', sqlstate
        );

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'FAILED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            TO_JSON(:error_object)
        );

        SYSTEM$LOG('ERROR','SP FAILED - '||:pipeline_name);

        RETURN error_object;
END;

