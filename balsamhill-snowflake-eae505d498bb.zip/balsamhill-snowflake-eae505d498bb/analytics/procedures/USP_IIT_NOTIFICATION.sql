CREATE   PROCEDURE ANALYTICS.USP_IIT_NOTIFICATION( status string,message string)
RETURNS STRING
LANGUAGE SQL
AS
BEGIN

LET email_integration_name varchar :=  (select distinct integration_name from   ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Query failure' and environment='prod'  limit 1);

LET email_list varchar :=  (select LISTAGG(distinct recipient,',') from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Query failure' and environment='prod');

CALL SYSTEM$SEND_EMAIL(
            :email_integration_name,
            :email_list,
            :status,
            :message
        );
    return 'Email sent successfully';
    
END;