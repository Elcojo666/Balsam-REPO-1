USE DATABASE DEV;

CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.USP_GET_CUSTOMER_BY_FILTER("WHERECLAUSE" VARCHAR(16777216), "QUERY" VARCHAR(16777216))
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    message STRING;
    statement STRING;
    sanitized_whereclause STRING;
    res RESULTSET;
BEGIN
    -- Sanitize WHERECLAUSE to remove unwanted escape characters
    sanitized_whereclause := REPLACE(WHERECLAUSE, ''&'', '''''''') || '' LIMIT 100 '';
    -- res:= (SELECT ''Debug: whereclause  = '' || :WHERECLAUSE  AS DEBUG_whereclause,
    -- ''Debug: sanitized_whereclause  = '' || :sanitized_whereclause  AS DEBUG_sanitized_whereclause );
    -- RETURN TABLE(res);

    BEGIN
        -- Build dynamic SQL statement
        IF (QUERY = '''' AND sanitized_whereclause = '''') THEN
            statement := ''
                SELECT *
                FROM analytics.customer AS dc
                LEFT JOIN analytics.customer_info AS dci ON dci.FK_CUSTOMERID = dc.pk_customerid
                LEFT JOIN MASTER.dim_customer_type AS dct ON dct.pk_customer_typeid = dc.fk_customer_typeid
                LEFT JOIN analytics.customer_address AS dca ON dca.FK_CUSTOMER_INFO_ID = dci.PK_CUSTOMER_INFO_ID 
                LIMIT 100
                ''
                ;
        ELSEIF (QUERY = '''') THEN 
            statement := ''
                    SELECT *
                    FROM analytics.customer AS dc
                    LEFT JOIN analytics.customer_info AS dci ON dci.FK_CUSTOMERID = dc.pk_customerid
                    LEFT JOIN MASTER.dim_customer_type AS dct ON dct.pk_customer_typeid = dc.fk_customer_typeid
                    LEFT JOIN analytics.customer_address AS dca ON dca.FK_CUSTOMER_INFO_ID = dci.PK_CUSTOMER_INFO_ID
                    WHERE '' || sanitized_whereclause
                    ;
        ELSE
            statement := ''
                SELECT '' || QUERY || ''
                FROM analytics.customer AS dc
                LEFT JOIN analytics.customer_info AS dci ON dci.FK_CUSTOMERID = dc.pk_customerid
                LEFT JOIN MASTER.dim_customer_type AS dct ON dct.pk_customer_typeid = dc.fk_customer_typeid
                LEFT JOIN analytics.customer_address AS dca ON dca.FK_CUSTOMER_INFO_ID = dci.PK_CUSTOMER_INFO_ID
                WHERE '' || sanitized_whereclause
                ;
        END IF;

        -- Execute dynamic SQL
        res := (EXECUTE IMMEDIATE statement);

        -- Set success message
        message := ''Success: Found customer records'';
        RETURN TABLE(res);
    EXCEPTION
        WHEN statement_error THEN
            message := sqlerrm;
            res := (SELECT 
                ''Error: '' || :message AS MESSAGE,
                ''ERROR'' AS STATUS,
                ''500'' AS STATUSCODE);
        RETURN TABLE(res);
    END;
END;
';
