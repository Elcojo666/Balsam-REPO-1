CREATE  PROCEDURE ANALYTICS.USP_BIZ_VALIDATION_PO_DETAIL()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    SourceRefErrorMsg       VARCHAR;
    OrderErrorMsg           VARCHAR;
    SourceWarehouseMsg      VARCHAR;
    DestiWarehouseMsg       VARCHAR;
    PoStatusErrorMsg        VARCHAR;
    BrandErrorMsg           VARCHAR;
    SupplierErrorMsg        VARCHAR;
    OriginCountryErrorMsg   VARCHAR;
    DestiCountryErrorMsg    VARCHAR;
    AgentErrorMsg           VARCHAR;
    EditSourceRefErrorMsg   VARCHAR;
    PortErrorMsg            VARCHAR;
    SkuErrorMsg             VARCHAR;
    InnerUPCErrorMsg        VARCHAR;
    ParentUPCErrorMsg       VARCHAR;
    PONumberErrorMsg        VARCHAR;
    message                 VARCHAR;
    ErrorCount              INT;
    StageErrorCount         INT;
    DimPOErrorCount         INT;
    DimSKUErrorCount        INT;
    TxnErrorCount           INT;
    StagingRecordCount      INT;
    FinalStatus             BOOLEAN;
    DataValidationErrCount  INT;
    OrderTypeCount          INT;
    result                  RESULTSET;

        BEGIN


            CREATE OR REPLACE TEMP TABLE DimPOResultToLog
            (
                ponumber            VARCHAR,
                stgsourcewarehouse  VARCHAR,
                sourcewarehouseid   VARCHAR,
                stgdestiwarehouse   VARCHAR,
                destiwarehouseid    VARCHAR,
                stgpostatus         VARCHAR,
                postatusid          VARCHAR,
                stgsupplier         VARCHAR,
                supplierid          VARCHAR,
                stgagent            VARCHAR,
                agentid             VARCHAR,
                stgport             VARCHAR,
                portid              VARCHAR
            );

            CREATE OR REPLACE TEMP TABLE DimSKUResultToLog
            (
                ponumber            VARCHAR,
                stgskucode          VARCHAR,
                skuid               VARCHAR,
                stginnerupc         VARCHAR,
                innerupcid          VARCHAR,
                stgparentupc        VARCHAR,
                parentupcid         VARCHAR,
                stgbrand            VARCHAR,
                brandid             VARCHAR
            );

            CREATE OR REPLACE TEMP TABLE TxnResultToLog
                (
                 stgponumber        VARCHAR,
                 stgjoinponumber    VARCHAR,
                 headponumber       VARCHAR
            );

            -- IF (inputTransactionId IS NULL OR inputTransactionId < 0) THEN
            --     message := 'TRANSACTION IDENTIFIER MISSING';
            --     RETURN message;
            -- END IF;

            SourceRefErrorMsg       := 'SourceRefNum [ERRORSOURCE] not found';
            OrderErrorMsg           := 'OrderId [ERRORORDERID] not found';
            SourceWarehouseMsg      := 'Source Warehouse [ERRORITEM] not found';
            DestiWarehouseMsg       := 'Destination Warehouse [ERRORITEM] not found';
            PoStatusErrorMsg        := 'PO Status [ERRORITEM] not found';
            BrandErrorMsg           := 'Brand [ERRORITEM] not found';
            SupplierErrorMsg        := 'Supplier [ERRORITEM] not found';
            OriginCountryErrorMsg   := 'Origin Country [ERRORITEM] not found';
            DestiCountryErrorMsg    := 'Destination Country [ERRORITEM] not found';
            AgentErrorMsg           := 'Agent [ERRORITEM] not found';
            EditSourceRefErrorMsg   := 'SourceRefNum [ERRORITEM] have no records for modification';
            PortErrorMsg            := 'Port [ERRORITEM] not found';
            SkuErrorMsg             := 'SKU [ERRORITEM] not found';
            InnerUPCErrorMsg        := 'Inner Upc [ERRORITEM] not found';
            ParentUPCErrorMsg       := 'Master Upc [ERRORITEM] not found';
            PONumberErrorMsg        := 'PO Number [ERRORITEM] Not Exist';

            INSERT INTO DimPOResultToLog -- revisar si todas las columnas tienen los mismos nombres en las tablas unidas
            SELECT
                stg.po_number,
                stg.receiving_warehouse_name,
                wh.pk_warehouseid,
                stg.destination_warehouse_name,
                dwh.pk_warehouseid,
                stg.statusid,
                post.pk_po_statusid,
                stg.supplierid,
                su.pk_supplierid,
                stg.agentid,
                ag.pk_agentid,
                stg.origin_portid,
                po.pk_portid
            FROM TRANSFORMED.STG_PO_DETAIL AS stg
                LEFT JOIN MASTER.DIM_WAREHOUSE AS wh
                    ON wh.warehouse_name = stg.receiving_warehouse_name
                LEFT JOIN MASTER.DIM_WAREHOUSE AS dwh
                    ON dwh.warehouse_name = stg.destination_warehouse_name
                LEFT JOIN MASTER.DIM_PO_STATUS AS post
                    ON post.pk_po_statusid = stg.statusid
                LEFT JOIN MASTER.DIM_SUPPLIER AS su
                    ON su.pk_supplierid = stg.supplierid
                LEFT JOIN MASTER.DIM_AGENT AS ag
                    ON ag.pk_agentid = stg.agentid
                LEFT JOIN MASTER.DIM_PORT AS po
                    ON po.pk_portid = stg.origin_portid;

                INSERT INTO ANALYTICS.LOG_BIZLOGIC_VALIDATION
                (
                    -- fk_log_inputtxn_id,
                    primary_field_name,
                    primary_field_value,
                    secondary_field_name,
                    secondary_field_value,
                    issue_type,
                    issue
                    )
                SELECT DISTINCT
                    --:inputTransactionId,
                    'Source Warehouse',
                    stgsourcewarehouse,
                    'PO Number',
                    ponumber,
                    'Dependent Error',
                    REPLACE(:SourceWarehouseMsg,'[ERRORITEM]', stgsourcewarehouse)
                FROM DimPOResultToLog
                WHERE sourcewarehouseid IS NULL
                    AND stgsourcewarehouse IS NOT NULL;

                INSERT INTO ANALYTICS.LOG_BIZLOGIC_VALIDATION
                (
                    --fk_log_inputtxn_id,
                    primary_field_name,
                    primary_field_value,
                    secondary_field_name,
                    secondary_field_value,
                    issue_type,
                    issue,INSERTED_DATE
                )
                SELECT DISTINCT
                   -- :inputTransactionId,
                    'Destination Warehouse',
                    stgdestiwarehouse,
                    'PO Number',
                    ponumber,
                    'Dependent Error',
                    REPLACE(:DestiWarehouseMsg,'[ERRORITEM]',stgdestiwarehouse),current_timestamp()
                FROM DimPOResultToLog
                WHERE destiwarehouseid IS NULL
                  AND stgdestiwarehouse IS NOT NULL;

                INSERT INTO ANALYTICS.LOG_BIZLOGIC_VALIDATION
                (
                    --fk_log_inputtxn_id,
                    primary_field_name,
                    primary_field_value,
                    secondary_field_name,
                    secondary_field_value,
                    issue_type,
                    issue,INSERTED_DATE
                )
                SELECT DISTINCT
                    --:inputTransactionId,
                    'PO Status',
                    stgpostatus,
                    'PO Number',
                    ponumber,
                    'Dependent Error',
                    REPLACE(:PoStatusErrorMsg,'[ERRORITEM]',stgpostatus),current_timestamp()
                FROM DimPOResultToLog
                WHERE postatusid IS NULL
                  AND stgpostatus IS NOT NULL;

                INSERT INTO ANALYTICS.LOG_BIZLOGIC_VALIDATION
                (
                    --fk_log_inputtxn_id,
                    primary_field_name,
                    primary_field_value,
                    secondary_field_name,
                    secondary_field_value,
                    issue_type,
                    issue,INSERTED_DATE
                )
                SELECT DISTINCT
                    --:inputTransactionId,
                    'Supplier',
                    stgsupplier,
                    'PO Number',
                    ponumber,
                    'Dependent Error',
                    REPLACE(:SupplierErrorMsg,'[ERRORITEM]',stgsupplier),current_timestamp()
                FROM DimPOResultToLog
                WHERE supplierid IS NULL
                  AND stgsupplier IS NOT NULL;

                INSERT INTO ANALYTICS.LOG_BIZLOGIC_VALIDATION
                (
                   -- fk_log_inputtxn_id,
                    primary_field_name,
                    primary_field_value,
                    secondary_field_name,
                    secondary_field_value,
                    issue_type,
                    issue,INSERTED_DATE
                )
                SELECT DISTINCT
                    --:inputTransactionId,
                    'Agent',
                    stgagent,
                    'PO Number',
                    ponumber,
                    'Dependent Error',
                    REPLACE(:AgentErrorMsg,'[ERRORITEM]',stgagent),current_timestamp()
                FROM DimPOResultToLog
                WHERE agentid IS NULL
                  AND stgagent IS NOT NULL;

                INSERT INTO ANALYTICS.LOG_BIZLOGIC_VALIDATION
                (
                    --fk_log_inputtxn_id,
                    primary_field_name,
                    primary_field_value,
                    secondary_field_name,
                    secondary_field_value,
                    issue_type,
                    issue,INSERTED_DATE
                )
                SELECT DISTINCT
                    --:inputTransactionId,
                    'Port',
                    stgport,
                    'PO Number',
                    ponumber,
                    'Dependent Error',
                    REPLACE(:PortErrorMsg,'[ERRORITEM]',stgport),current_timestamp()
                FROM DimPOResultToLog
                WHERE portid IS NULL
                  AND stgport IS NOT NULL;

            INSERT INTO DimSKUResultToLog
            SELECT
                stg.po_number,
                stg.sku_code,
                dims.pk_skuproductid,
                stg.inner_upc,
                dimu.pk_upcid,
                stg.master_upc,
                dimup.pk_upcid,
                stg.brandid,
                br.pk_brandid
            FROM TRANSFORMED.STG_SKU_DETAIL AS stg
                LEFT JOIN MASTER.DIM_BRAND AS br
                    ON br.pk_brandid = stg.brandid
                LEFT JOIN ANALYTICS.SKU_PRODUCT AS dims
                    ON dims.sku_code = stg.sku_code
                LEFT JOIN ANALYTICS.UPC AS dimu
                    ON dimu.inner_upc = stg.inner_upc
                LEFT JOIN ANALYTICS.UPC AS dimup
                    ON dimup.parent_upc_code = stg.master_upc;

                INSERT INTO ANALYTICS.LOG_BIZLOGIC_VALIDATION
                (
                    --fk_log_inputtxn_id,
                    primary_field_name,
                    primary_field_value,
                    secondary_field_name,
                    secondary_field_value,
                    issue_type,
                    issue,INSERTED_DATE
                )
                SELECT DISTINCT
                    --:inputTransactionId,
                    'Sku',
                    stgskucode,
                    'PO Number',
                    ponumber,
                    'Dependent Error',
                    REPLACE(:SkuErrorMsg,'[ERRORITEM]',stgskucode),current_timestamp()
                FROM DimSKUResultToLog
                WHERE skuid IS NULL
                  AND stgskucode IS NOT NULL;

                INSERT INTO ANALYTICS.LOG_BIZLOGIC_VALIDATION
                (
                    --fk_log_inputtxn_id,
                    primary_field_name,
                    primary_field_value,
                    secondary_field_name,
                    secondary_field_value,
                    issue_type,
                    issue,INSERTED_DATE
                )
                SELECT DISTINCT
                    --:inputTransactionId,
                    'Inner Upc',
                    stginnerupc,
                    'PO Number',
                    ponumber,
                    'Dependent Error',
                    REPLACE(:InnerUPCErrorMsg,'[ERRORITEM]',stginnerupc),current_timestamp()
                FROM DimSKUResultToLog
                WHERE innerupcid IS NULL
                  AND stginnerupc IS NOT NULL;

                INSERT INTO ANALYTICS.LOG_BIZLOGIC_VALIDATION
                (
                   -- fk_log_inputtxn_id,
                    primary_field_name,
                    primary_field_value,
                    secondary_field_name,
                    secondary_field_value,
                    issue_type,
                    issue,INSERTED_DATE
                )
                SELECT DISTINCT
                   -- :inputTransactionId,
                    'Parent Upc',
                    stgparentupc,
                    'PO Number',
                    ponumber,
                    'Dependent Error',
                    REPLACE(:ParentUPCErrorMsg,'[ERRORITEM]',stgparentupc),current_timestamp()
                FROM DimSKUResultToLog
                WHERE parentupcid IS NULL
                  AND stgparentupc IS NOT NULL;

                INSERT INTO ANALYTICS.LOG_BIZLOGIC_VALIDATION
                (
                   -- fk_log_inputtxn_id,
                    primary_field_name,
                    primary_field_value,
                    secondary_field_name,
                    secondary_field_value,
                    issue_type,
                    issue,INSERTED_DATE
                )
                SELECT DISTINCT
                   -- :inputTransactionId,
                    'Brand',
                    stgbrand,
                    'PO Number',
                    ponumber,
                    'Dependent Error',
                    REPLACE(:BrandErrorMsg,'[ERRORITEM]',stgbrand),current_timestamp()
                FROM DimSKUResultToLog
                WHERE brandid IS NULL
                  AND stgbrand IS NOT NULL;

            INSERT INTO TxnResultToLog
            SELECT DISTINCT
                stg.po_number,
                pohead.po_number,
                stgjoin.po_number
            FROM TRANSFORMED.STG_PO_DETAIL AS stg
                LEFT JOIN ANALYTICS.TXN_PO_HEADER AS pohead
                    ON stg.po_number = pohead.po_number
                LEFT JOIN TRANSFORMED.STG_SKU_DETAIL AS stgjoin
                    ON stg.po_number = stgjoin.po_number;

                INSERT INTO ANALYTICS.LOG_BIZLOGIC_VALIDATION
                (
                    --fk_log_inputtxn_id,
                    primary_field_name,
                    primary_field_value,
                    secondary_field_name,
                    secondary_field_value,
                    issue_type,
                    issue,INSERTED_DATE
                )
                SELECT DISTINCT
                    --:inputTransactionId,
                    'PO Number',
                    stgponumber,
                    null,
                    null,
                    'Dependent Error',
                    REPLACE(:PONumberErrorMsg,'[ERRORITEM]',stgponumber),current_timestamp()
                FROM TxnResultToLog
                WHERE (stgjoinponumber IS NULL AND headponumber IS NULL)
                  AND stgponumber IS NOT NULL;

            DimPOErrorCount := (
                SELECT COUNT(*)
                FROM DimPOResultToLog
                WHERE (
                    sourcewarehouseid IS NULL
                    OR destiwarehouseid IS NULL
                    OR postatusid IS NULL
                    OR supplierid IS NULL
                    OR agentid IS NULL
                    OR portid IS NULL
                    )
                  AND (
                    stgsourcewarehouse IS NOT NULL
                    AND stgdestiwarehouse IS NOT NULL
                    AND stgpostatus IS NOT NULL
                    AND stgsupplier IS NOT NULL
                    AND stgagent IS NOT NULL
                    AND stgport IS NOT NULL
                    )
            );

            DimSKUErrorCount := (
                SELECT COUNT(*)
                FROM DimSKUResultToLog
                WHERE (
                    skuid IS NULL
                    OR innerupcid IS NULL
                    OR parentupcid IS NULL
                    OR brandid IS NULL
                    )
                  AND (
                    stgskucode IS NOT NULL
                    AND stginnerupc IS NOT NULL
                    AND stgparentupc IS NOT NULL
                    AND stgbrand IS NOT NULL
                    )
            );

            TxnErrorCount := (
                SELECT COUNT(*)
                FROM TxnResultToLog
                WHERE (
                    stgjoinponumber IS NULL
                    AND headponumber IS NULL
                    )
                    AND stgponumber IS NOT NULL
            );

            ErrorCount := :DimPOErrorCount + :DimSKUErrorCount + :TxnErrorCount;

            IF (:ErrorCount > 0) THEN
                message := 'Warning: ' || :ErrorCount || ' Records have business validation errors';

                -- UPDATE ANALYTICS.LOG_INPUT_TXN
                -- SET
                --     error_message = message,
                --     is_rejected = 0
                -- WHERE id = :inputTransactionId;

                -- FinalStatus := 1;
                RETURN :message;
            ELSE
                -- UPDATE analytics.log_input_txn
                -- SET
                --     is_rejected = 0
                -- WHERE id = :inputTransactionId;

                -- FinalStatus := 1;
                RETURN 'No Errors';
            END IF;

    RETURN 'Success';
END;

;