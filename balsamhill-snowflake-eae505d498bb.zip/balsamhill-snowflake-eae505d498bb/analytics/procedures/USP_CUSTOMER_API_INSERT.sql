USE DATABASE DEV; 

CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.USP_CUSTOMER_API_INSERT("PK_CUSTOMERID" NUMBER(38,0), "SOURCEREFNUM" VARCHAR(16777216), "ID" VARCHAR(16777216), "EMAILADDRESS" VARCHAR(16777216), "PHONENUMBER" VARCHAR(16777216), "EMAILSUBSCRIBER" BOOLEAN, "CATALOGSUBSCRIBER" BOOLEAN, "SOURCEID" NUMBER(38,0), "STATUS" VARCHAR(16777216), "CUSTOMERTYPE" VARCHAR(16777216), "PREFERRED_LANG" VARCHAR(16777216), "REGD_DATE" TIMESTAMP_NTZ(9), "TITLE" VARCHAR(16777216), "FIRSTNAME" VARCHAR(16777216), "LASTNAME" VARCHAR(16777216), "DOB" TIMESTAMP_NTZ(9), "GENDERCODE" VARCHAR(16777216), "GENDER" VARCHAR(16777216), "MARITALSTATUSCODE" VARCHAR(16777216), "MARITALSTATUS" VARCHAR(16777216), "EMAILSECONDARY" VARCHAR(16777216), "PHONE1INPUT" VARCHAR(16777216), "PHONE2INPUT" VARCHAR(16777216), "PHONE3INPUT" VARCHAR(16777216), "PHONE4INPUT" VARCHAR(16777216), "PHONE1INPUT_E164" VARCHAR(16777216), "PHONE2INPUT_E164" VARCHAR(16777216), "PHONENUMBER_E164" VARCHAR(16777216), "PHONE4INPUT_E164" VARCHAR(16777216), "COMPANYNAME" VARCHAR(16777216), "CUSTOMER_ISANONYMOUS" BOOLEAN, "CHECKBOX_FOR_NEW_CUSTOMERS" BOOLEAN, "CUSTOMER_NOTES" VARCHAR(16777216), "TAXEXEMPTACCOUNT" BOOLEAN, "ORDERPLACED" BOOLEAN, "CREATEDBY" VARCHAR(16777216), "LASTLOGIN" TIMESTAMP_NTZ(9), "EXTERNAL_ID" VARCHAR(16777216), "EXTERNAL_ACCOUNTID" VARCHAR(16777216), "EXTERNALEMAIL2" VARCHAR(16777216), "EXTERNALEMAIL1" VARCHAR(16777216), "MASTERCONTACT" VARCHAR(16777216), "LEGALNAME" VARCHAR(16777216), "EMAIL_OPT_IN_STATUS" VARCHAR(16777216), "FK_MASTERCUSTOMERID" NUMBER(38,0), "CUST_TIER" VARCHAR(16777216), "TAX_ID" VARCHAR(16777216), "ISNORDSTROMCUSTOMER" BOOLEAN, "ISWILLIAMSONOMACUSTOMER" BOOLEAN, "BUSINESS_CUST" BOOLEAN, "BUSINESS_CATEGORY" VARCHAR(16777216), "BUSINESSLOCATIONS" NUMBER(38,0), "DESIGNTRADEFLAG" BOOLEAN, "SOCIAL_HANDLE_FACEBOOK" VARCHAR(16777216), "SOCIAL_HANDLE_INSTAGRAM" VARCHAR(16777216), "SOCIAL_HANDLE_TWITTER" VARCHAR(16777216), "PHONE1_SMS" BOOLEAN, "PHONE1_PREF" BOOLEAN, "PHONE1_REGION" VARCHAR(16777216), "PHONE2_SMS" BOOLEAN, "PHONE2_PREF" BOOLEAN, "PHONE2_REGION" VARCHAR(16777216), "PHONE3_SMS" BOOLEAN, "PHONE3_PREF" BOOLEAN, "PHONE3_REGION" VARCHAR(16777216), "PHONE4_SMS" BOOLEAN, "PHONE4_PREF" BOOLEAN, "PHONE4_REGION" VARCHAR(16777216), "HASHEDID" VARCHAR(16777216), "CUSTOMER_SOURCE" VARCHAR(16777216), "ISBUSINESS" BOOLEAN)
COPY GRANTS 
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    message            STRING;
    warningCount       INT; 
    warningParentCount INT DEFAULT 0;
    customerParentID   STRING;
    customerID         STRING;
    customerInfoID     STRING;
    domesticSource     STRING DEFAULT ''domestic'';
    error_message      STRING;
    sql_code           STRING; 
    res                RESULTSET; 
    pk_sourceid        NUMBER;
    pk_customer_typeid         NUMBER;
BEGIN
        
    ---------------------------------------------------------------------------
    -- Check for warnings (e.g. duplicate customers or missing parent customer)
    ---------------------------------------------------------------------------
    SELECT COUNT(DISTINCT CUST.pk_customerid) INTO :warningCount
      FROM analytics.customer AS cust 
      WHERE cust.source_ref_num = :sourceRefNum
        AND CUST.FK_SOURCEID = :SOURCEID
      ;
    
    SELECT COUNT(mast.source_ref_num) INTO :warningParentCount
      FROM analytics.customer AS mast 
      WHERE mast.pk_customerid = :FK_MASTERCUSTOMERID;
    
    IF (warningCount > 0) THEN
        message := ''WARNING: '' || CAST(warningCount AS VARCHAR(50)) || '' Customer already exists'';
        
        SELECT MIN(cust.pk_customerid) INTO :customerID
         FROM analytics.customer AS cust 
      WHERE cust.source_ref_num = :sourceRefNum
        AND CUST.FK_SOURCEID = :SOURCEID
      ;
    
        res := (SELECT 
                  :message       AS MESSAGE,
                  ''Failed''      AS STATUS,
                  :customerID    AS ID,
                  :customerInfoID AS INFO_ID,
                  ''409''         AS STATUSCODE);
    
        RETURN TABLE(res);

    ELSEIF (FK_MASTERCUSTOMERID IS NOT NULL AND  warningParentCount = 0) THEN
    
    
        message := ''WARNING: '' || FK_MASTERCUSTOMERID || '' Master Customer does not exist'';
    
        res := (SELECT 
                  :message         AS MESSAGE,
                  ''Failed''        AS STATUS,
                  :FK_MASTERCUSTOMERID AS ID,
                  :customerInfoID  AS INFO_ID,
                  ''400''           AS STATUSCODE);
    
        RETURN TABLE(res);
      
    ELSE 
    BEGIN
        -----------------------------------------------------------------------
        -- Create a temporary table joining our input row with dimension data.
        -----------------------------------------------------------------------
        SELECT src.pk_sourceid INTO :pk_sourceid
        FROM MASTER.DIM_source src 
        WHERE src.pk_sourceid = :SourceID;

        SELECT custtype.pk_customer_typeid INTO :pk_customer_typeid
          FROM  MASTER.DIM_customer_type custtype 
        WHERE custtype.customer_type = :CustomerType;
    
        -----------------------------------------------------------------------
        -- Insert into audit table
        -----------------------------------------------------------------------
        INSERT INTO ANALYTICS.audit_customer (
            fk_sourceid,
            source_ref_num,
            ext_customer_id,
            is_domestic,
            fk_customer_typeid,
            inserted_date,
            first_name,
            last_name,
            company_name,
            email_address,
            phone,
            is_tax_exempt,
            email_subscriber,
            catalog_subscriber
        )
        SELECT
            :pk_sourceid,
            :SourceRefNum,
            :ID,
            CASE WHEN :CUSTOMER_SOURCE = :domesticSource THEN 1 ELSE 0 END,
            :pk_customer_typeid,
            CURRENT_DATE,
            :FirstName,
            :LastName,
            :CompanyName,
            :EmailAddress,
            :PhoneNumber,
            CASE WHEN LOWER(:TaxExemptAccount) = ''true'' THEN 1 ELSE 0 END ,
            CASE WHEN LOWER(:EmailSubscriber) = ''true'' THEN 1 ELSE 0 END,
            CASE WHEN LOWER(:CatalogSubscriber) = ''true'' THEN 1 ELSE 0 END 
        
          ;

        -----------------------------------------------------------------------
        -- Insert into customer table
        -----------------------------------------------------------------------
        INSERT INTO analytics.customer (
            fk_sourceid,
            source_ref_num,
            ext_customer_id,
            is_domestic,
            fk_customer_typeid
        )
        SELECT 
            :pk_sourceid,
            :SourceRefNum,
            :ID,
            CASE WHEN :CUSTOMER_SOURCE = :domesticSource THEN 1 ELSE 0 END,
            :pk_customer_typeid
            
        ;
        SELECT MIN(dimcust.PK_CUSTOMERID) INTO :customerID
          FROM  analytics.customer AS dimcust
        WHERE  dimcust.source_ref_num = :SourceRefNum
            AND dimcust.FK_SOURCEID = :SOURCEID
        ;
        
        -----------------------------------------------------------------------
        -- Insert into customer_info table
        -----------------------------------------------------------------------

            INSERT INTO analytics.customer_info (
        FK_CUSTOMERID,
        STATUS,
        PREFERRED_LANG,
        REGD_DATE,
        TITLE,
        FIRST_NAME,
        LAST_NAME,
        DOB,
        GENDER_CODE,
        GENDER,
        MARITAL_STATUS_CODE,
        MARITAL_STATUS,
        EMAIL_PRIMARY,
        EMAIL_SECONDARY,
        PHONE1_INPUT,
        PHONE2_INPUT,
        PHONE3_INPUT,
        PHONE4_INPUT,
        COMPANY_NAME,
        CATALOG_SUBSCRIBER,
        CUSTOMER_IS_ANONYMOUS,
        IS_ANONYMOUS_DATE_UPDATED,
        CUST_TYPE,
        NEW_CUSTOMER,
        CUST_NOTES,
        TAX_EXEMPT_ACCOUNT,
        ORDER_PLACED,
        CREATED_BY,
        CREATED_DATE,
        MODIFIED_BY,
        MODIFIED_DATE,
        LAST_LOGIN_DATE,
        EXTERNAL_ID,
        EXTERNAL_ACCOUNTID,
        EXTERNAL_EMAIL2,
        EXTERNAL_EMAIL1,
        MASTERCONTACT,
        LEGAL_NAME,
        EMAIL_OPT_IN_STATUS,
        FK_MASTERCUSTOMERID,
        DEDUP_TYPE,
        cust_tier,
        tax_id,
        email_subscriber,
        IsNordstromCustomer,
        IsWilliamsonomaCustomer,
        business_cust,
        business_category,
        "BUSINESS_#_OF_LOCATIONS",
        DesignTradeFlag,
        social_handle_facebook,
        social_handle_instagram,
        social_handle_twitter,
        phone1_sms,
        phone1_pref,
        phone1_region,
        phone2_sms,
        phone2_pref,
        phone2_region,
        phone3_sms,
        phone3_pref,
        phone3_region,
        phone4_sms,
        phone4_pref,
        phone4_region,
        phone1_E164,
        phone2_E164,
        phone3_E164,
        phone4_E164,
        HashedId,
        ISBUSINESS 
    )
    SELECT
        :customerID,                                  -- FK_CUSTOMERID (assumed already determined)
        :Status,                                      -- STATUS
        :Preferred_Lang,                              -- PREFERRED_LANG
        :Regd_Date,                                   -- REGD_DATE
        :Title,                                       -- TITLE
        :FirstName,                                   -- FIRST_NAME
        :LastName,                                    -- LAST_NAME
        :Dob,                                         -- DOB
        :GenderCode,                                  -- GENDER_CODE
        :Gender,                                      -- GENDER
        :MaritalStatusCode,                           -- MARITAL_STATUS_CODE
        :MaritalStatus,                               -- MARITAL_STATUS
        :EmailAddress,                                -- EMAIL_PRIMARY
        :EmailSecondary,                              -- EMAIL_SECONDARY
        :Phone1Input,                                 -- PHONE1_INPUT
        :Phone2Input,                                 -- PHONE2_INPUT
        :PhoneNumber,                                 -- PHONE3_INPUT
        :Phone4Input,                                 -- PHONE4_INPUT
        :CompanyName,                                 -- COMPANY_NAME
        :CatalogSubscriber,                           -- CATALOG_SUBSCRIBER
        :Customer_IsAnonymous,                        -- CUSTOMER_IS_ANONYMOUS
        NULL,                                         -- IS_ANONYMOUS_DATE_UPDATED
        :CustomerType,                                -- CUST_TYPE
        :Checkbox_For_New_Customers,                  -- NEW_CUSTOMER
        :Customer_Notes,                              -- CUST_NOTES
        :TaxExemptAccount,                            -- TAX_EXEMPT_ACCOUNT
        :OrderPlaced,                                 -- ORDER_PLACED
        :CreatedBy,                                   -- CREATED_BY
        CURRENT_TIMESTAMP,                                 -- CREATED_DATE
        :CreatedBy,                                   -- MODIFIED_BY
        CURRENT_TIMESTAMP,                                 -- MODIFIED_DATE
        :LastLogin,                                   -- LAST_LOGIN_DATE
        :EXTERNAL_ID,                                 -- EXTERNAL_ID
        :EXTERNAL_ACCOUNTID,                          -- EXTERNAL_ACCOUNTID
        :ExternalEmail2,                              -- EXTERNAL_EMAIL2
        :ExternalEmail1,                              -- EXTERNAL_EMAIL1
        :MASTERCONTACT,                               -- MASTERCONTACT
        :LegalName,                                   -- LEGAL_NAME
        :EMAIL_OPT_IN_STATUS,                         -- EMAIL_OPT_IN_STATUS
        :FK_MASTERCUSTOMERID,                         -- FK_MASTERCUSTOMERID
        NULL,                                         -- DEDUP_TYPE
        :cust_tier,                                   -- cust_tier
        :tax_id,                                      -- tax_id
        CASE
            WHEN LOWER(:EmailSubscriber::STRING) = ''true'' THEN 1
            ELSE 0
        END,                                          -- email_subscriber
        :IsNordstromCustomer,                         -- IsNordstromCustomer
        :IsWilliamsonomaCustomer,                     -- IsWilliamsonomaCustomer
        :business_cust,                               -- business_cust
        :business_category,                           -- business_category
        :BusinessLocations,                           -- "BUSINESS_#_OF_LOCATIONS"
        :DesignTradeFlag,                             -- DesignTradeFlag
        :social_handle_facebook,                      -- social_handle_facebook
        :social_handle_instagram,                     -- social_handle_instagram
        :social_handle_twitter,                       -- social_handle_twitter
        :phone1_sms,                                  -- phone1_sms
        :phone1_pref,                                 -- phone1_pref
        :phone1_region,                               -- phone1_region
        :phone2_sms,                                  -- phone2_sms
        :phone2_pref,                                 -- phone2_pref
        :phone2_region,                               -- phone2_region
        :phone3_sms,                                  -- phone3_sms
        :phone3_pref,                                 -- phone3_pref
        :phone3_region,                               -- phone3_region
        :phone4_sms,                                  -- phone4_sms
        :phone4_pref,                                 -- phone4_pref
        :phone4_region,                               -- phone4_region
        :Phone1Input_E164,-- phone1_E164
        :Phone2Input_E164,-- phone2_E164
        :PhoneNumber_E164,-- phone3_E164
        :Phone4Input_E164, -- phone4_E164
        :HashedId, -- HashedId
        :ISBUSINESS 
        
        ;
        SELECT custinfo.PK_CUSTOMER_INFO_ID
          INTO :customerInfoID
          FROM analytics.customer_info AS custinfo
          WHERE custinfo.FK_CUSTOMERID = :customerID;
        
    END;
    END IF;

    


    ---------------------------------------------------------------------------
    -- Return success
    ---------------------------------------------------------------------------
    res := (SELECT 
              ''Record Inserted'' AS MESSAGE,
              ''Success'' AS STATUS,
              :customerID AS ID,
              :customerInfoID AS INFO_ID,
              ''200'' AS STATUSCODE);
    
    RETURN TABLE(res);
    
EXCEPTION
    WHEN statement_error THEN
        ROLLBACK;
        error_message := sqlerrm;
        sql_code := sqlcode;
        
        -- Log the error
        INSERT INTO ANALYTICS.log_microservices_errors (
            microservicesname,  
            methodname,  
            errortime,  
            errormessage,  
            source,  
            exceptiontrace,  
            sql_errornumber,  
            sql_errorstate,  
            sql_errorseverity,  
            sql_errorline,  
            sql_errorprocedure,  
            sql_errormessage
        )
        VALUES (
            ''CustomerApi'',  
            ''Insert/Add Customer'',  
            CURRENT_TIMESTAMP(),  
            ''Error in SQL'',  
            NULL,  
            NULL,  
            :sql_code,  
            NULL,  
            NULL,  
            NULL,  
            NULL,  
            :error_message
        );
        
        res := (SELECT 
                  ''Error: '' || :error_message AS MESSAGE,
                  ''Failed'' AS STATUS,
                  NULL AS ID,
                  NULL AS INFO_ID,
                  ''500'' AS STATUSCODE);
    
        RETURN TABLE(res);
END';
