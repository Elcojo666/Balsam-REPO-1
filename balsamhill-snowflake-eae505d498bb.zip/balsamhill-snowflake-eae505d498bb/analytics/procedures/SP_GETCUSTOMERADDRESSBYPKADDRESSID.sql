use database dev;

CREATE OR REPLACE PROCEDURE ANALYTICS.SP_GETCUSTOMERADDRESSBYPKADDRESSID("PK_CUSTOMER_ADDRESS_ID" NUMBER(38,0))
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    pk_customer_address_id_temp STRING;
    pk_customer_info_id STRING;
    pk_customerid STRING;
    message STRING;
    sql_errornumber string;
    sql_errormessage string;
    
      
BEGIN

SYSTEM$LOG(''TRACE'','' sp_GetCustomerAddressByPkAddressId has been Started'');

    -- Attempt to execute the main logic
    
        -- Retrieve PK_CUSTOMER_ADDRESS_ID 
        SELECT dca.PK_CUSTOMER_ADDRESS_ID
        INTO :pk_customer_address_id_temp
        FROM analytics.customer_address dca
        WHERE dca.PK_CUSTOMER_ADDRESS_ID = :pk_customer_address_id;

        -- Retrieve FK_CUSTOMER_INFO_ID
        SELECT dca.FK_CUSTOMER_INFO_ID
        INTO  :pk_customer_info_id
        FROM analytics.customer_address dca
        WHERE dca.PK_CUSTOMER_ADDRESS_ID = :pk_customer_address_id;
        
        -- Retrieve FK_CUSTOMERID based on FK_CUSTOMER_INFO_ID
        SELECT dci.FK_CUSTOMERID
        INTO :pk_customerid
        FROM analytics.customer_info dci
        WHERE dci.PK_CUSTOMER_INFO_ID = :pk_customer_info_id ;
        
        IF ((:pk_customer_address_id_temp is NULL)OR (:pk_customer_address_id_temp = '''') ) THEN

             
             
            --CREATE  or replace TABLE analytics.customer_address_record_failed_with_notfound as 
          LET results RESULTSET  := (SELECT NULL AS pk_customerid, NULL AS pk_customer_address_id, NULL AS fk_customer_info_id, 
            ''WARNING: '' || (:pk_customer_address_id :: STRING) || '' Customer address not found'' AS message, ''Failed'' AS status);
            
            RETURN  TABLE(results);

            --RETURN ''Failed'';
        ELSE
                --CREATE  or replace TABLE analytics.customer_address_record_found as 
          LET results RESULTSET  := ( SELECT :pk_customerid AS pk_customerid, 
                           --DCA.pk_customer_address_id, DCA. fk_customer_info_id, 
                           DCA.*,
                           ''Record Found'' AS message, ''Success'' AS status
                    from analytics.customer_address DCA
                WHERE DCA.PK_CUSTOMER_ADDRESS_ID = :pk_customer_address_id);
                
            RETURN  TABLE(results);
            
        END IF;
COMMIT;
SYSTEM$LOG(''TRACE'','' sp_GetCustomerAddressByPkAddressId has been Completed'');

    -- Handle any exceptions and log them
EXCEPTION WHEN statement_error THEN
    ROLLBACK;
SYSTEM$LOG(''ERROR'','' sp_GetCustomerAddressByPkAddressId has been Failed'');

    sql_errornumber := sqlcode;
    sql_errormessage := sqlerrm;
        -- Log the error details into the log table
        INSERT INTO ANALYTICS.log_microservices_errors(
            microservicesname,  
            methodname,  
            errortime,  
            errormessage,  
            source,  
            exceptiontrace,  
            sql_errornumber,  
            sql_errorstate,  
            sql_errorseverity,  
            sql_errorline,  
            sql_errorprocedure,  
            sql_errormessage
        )
        VALUES(
            ''CustomerApi'',  
            ''GetCustomerAddressByPkAddressId'',  
            CURRENT_TIMESTAMP(),  
            ''Error in SQL'',  
            NULL,  
            NULL,  
            :sql_errornumber,  
            NULL,  
            NULL,  
            NULL,  
            NULL,  
            :sql_errormessage
        );
     LET results RESULTSET  := (SELECT NULL,NULL) ;

     RETURN TABLE(results);
        
          
END';