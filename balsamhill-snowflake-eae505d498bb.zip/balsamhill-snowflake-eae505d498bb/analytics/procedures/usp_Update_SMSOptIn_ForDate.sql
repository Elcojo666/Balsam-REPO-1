CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.usp_Update_SMSOptIn_ForDate(INPUT_DATE DATE DEFAULT NULL)
  RETURNS STRING
  LANGUAGE SQL
  EXECUTE AS OWNER
AS
$$
DECLARE
    EFFECTIVE_DATE DATE;
BEGIN

-- If INPUT_DATE is null, use MAX(timestamp) from customer_SMS_optin_attentive
IF(:INPUT_DATE IS NULL) THEN  
    SELECT MAX(CAST(timestamp AS DATE)) 
    INTO :EFFECTIVE_DATE 
    FROM customer_SMS_optin_attentive;
ELSE 
    EFFECTIVE_DATE := :INPUT_DATE;
END IF; 

-- First update: opt-in users
UPDATE ANALYTICS.CUSTOMER_INFO DI 
    SET 
        DI.sms_opt_in_atntv = 1,
        DI.phone_atntv = cs.phone,
        DI.MODIFIED_DATE = CURRENT_TIMESTAMP()
FROM customer_SMS_optin_attentive AS cs 
WHERE LOWER(TRIM(di.EMAIL_PRIMARY)) = LOWER(TRIM(cs.email))
    AND TRY_CAST(cs.timestamp AS DATE) = :EFFECTIVE_DATE
    AND cs.join_source IN (
        'CODE',
        'CHECKOUT',
        'DIRECT',
        'DOUBLE_OPT_IN',
        'DOUBLE_OPT_IN_AFFILIATED',
        'MANUAL'
    )
    AND di.EMAIL_PRIMARY IS NOT NULL
    AND cs.email IS NOT NULL
    AND di.EMAIL_PRIMARY != ''
    AND cs.email != ''
;

-- Second update: opt-out users
UPDATE ANALYTICS.CUSTOMER_INFO DI 
    SET 
        di.sms_opt_in_atntv = 0,
        di.phone_atntv = cs.phone,
        di.MODIFIED_DATE = CURRENT_TIMESTAMP()
FROM customer_SMS_optin_attentive AS cs 
WHERE LOWER(TRIM(di.EMAIL_PRIMARY)) = LOWER(TRIM(cs.email))
    AND CAST(cs.timestamp AS DATE) = :EFFECTIVE_DATE
    AND cs.Type = 'SUBSCRIPTION_OPTED_OUT'
    AND di.EMAIL_PRIMARY IS NOT NULL
    AND cs.email IS NOT NULL
    AND di.EMAIL_PRIMARY != ''
    AND cs.email != ''
;

RETURN 'Success';
END;
$$;