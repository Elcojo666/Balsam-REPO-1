USE DATABASE DEV; 

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_TAX_BREAKUP_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    createdby NUMBER DEFAULT 1;
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    Counter NUMBER DEFAULT 0;
    processedLineTaxDetails NUMBER DEFAULT 0;
    processedTaxDetails NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE TempTaxDetails (
    pk_order_taxid BIGINT,
    fk_order_headerid BIGINT,
    tax_name VARCHAR,
    tax_type VARCHAR,
    tax_rate FLOAT,
    tax_amount FLOAT,
    ext_tax_id VARCHAR,
    created_by INT,
    created_date TIMESTAMP_NTZ,
    modified_date TIMESTAMP_NTZ,
    Revision INT
);

CREATE OR REPLACE TEMPORARY TABLE ordertaxdetails AS
SELECT DISTINCT  
    stg.TAX_BREAKUP_KEY,  
    stg.header_key,  
    toh.pk_order_headerid AS fk_order_headerid,  
    stg.tax_name AS tax_name,  
    TRY_CAST(stg.tax  AS FLOAT) AS tax_amount,  
    stg.charge_category AS tax_type,  
    TRY_CAST(STG.TAX_PERCENTAGE AS FLOAT) AS tax_rate,  
    stg.txn_id
FROM  
    TRANSFORMED.stg_ORDER_tax_breakup stg  
INNER JOIN 
    ANALYTICS.txn_order_header AS toh ON toh.order_header_key = stg.header_key AND toh.entry_type IS NOT NULL  
INNER JOIN 
    master.dim_chargecategory AS dc ON dc.charge_category = stg.charge_category AND dc.charge = ''TAX''  
WHERE 
    stg.line_key IS NULL;

processedDate := CURRENT_TIMESTAMP(); 
    
MERGE INTO ANALYTICS.txn_order_tax AS tot 
USING (
    SELECT  
        DISTINCT ordtax.fk_order_headerid,  
        ordtax.TAX_BREAKUP_KEY,  
        ordtax.tax_name,  
        ordtax.tax_type,  
        ordtax.tax_rate,  
        ordtax.tax_amount,  
        CURRENT_TIMESTAMP() AS inserted_date,  
        CURRENT_TIMESTAMP() AS modified_date  
    FROM  
        ordertaxdetails AS ordtax  
) AS otd  
ON (  
    tot.fk_order_headerid = otd.fk_order_headerid  
    AND tot.ext_tax_id = otd.TAX_BREAKUP_KEY  
)  
WHEN MATCHED THEN  
    UPDATE  
    SET   
        tot.tax_name = otd.tax_name,  
        tot.tax_type = otd.tax_type,  
        tot.tax_rate = otd.tax_rate,  
        tot.tax_amount = otd.tax_amount,  
        tot.modified_date = CURRENT_TIMESTAMP()  
WHEN NOT MATCHED THEN  
    INSERT                
    (  
        fk_order_headerid,  
        ext_tax_id,  
        tax_name,  
        tax_type,  
        tax_rate,  
        tax_amount,  
        inserted_date,  
        modified_date  
    )              
    VALUES                
    (                
        otd.fk_order_headerid,  
        otd.TAX_BREAKUP_KEY,  
        otd.tax_name,  
        otd.tax_type,  
        otd.tax_rate,  
        otd.tax_amount,  
        CURRENT_TIMESTAMP(),  
        CURRENT_TIMESTAMP()             
    );

INSERT INTO TempTaxDetails (
    pk_order_taxid,
    fk_order_headerid,
    tax_name,
    tax_amount,
    tax_type,
    ext_tax_id,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_taxid,
    fk_order_headerid,
    tax_name,
    tax_amount,
    tax_type,
    ext_tax_id,
    :createdby,
    inserted_date,
    modified_date,
    :InitialRevision
FROM ANALYTICS.txn_order_tax
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;

create or replace temp table analytics.MaxRevisions as 
    SELECT 
        MAX(aot.revision) AS revision,
        aot.pk_order_taxid,
        aot.fk_order_headerid
    FROM analytics.audit_order_tax AS aot
    JOIN TempTaxDetails AS ttd 
        ON ttd.pk_order_taxid = aot.pk_order_taxid 
        AND ttd.fk_order_headerid = aot.fk_order_headerid
    GROUP BY aot.pk_order_taxid, aot.fk_order_headerid;
    
MERGE INTO TempTaxDetails ttd
USING analytics.MaxRevisions aot
ON ttd.pk_order_taxid = aot.pk_order_taxid 
AND ttd.fk_order_headerid = aot.fk_order_headerid
WHEN MATCHED THEN 
    UPDATE SET 
        ttd.Revision = CAST((aot.revision + 1) AS INT);



INSERT INTO ANALYTICS.audit_order_tax (
    pk_order_taxid,
    fk_order_headerid,
    tax_name,
    tax_amount,
    tax_type,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT
    pk_order_taxid,
    fk_order_headerid,
    tax_name,
    tax_amount,
    tax_type,
    created_by,
    created_date,
    modified_date,
    revision
FROM TempTaxDetails;

-- MERGE INTO RAW.raw_ORDER_tax_breakup rohc
-- USING (
--     SELECT 
--         sohc.TAX_BREAKUP_KEY, 
--         sohc.header_key, 
--         sohc.txn_id, 
--         sohc.modifyts 
--     FROM TRANSFORMED.stg_ORDER_tax_breakup sohc
--     JOIN ordertaxdetails otd 
--         ON otd.TAX_BREAKUP_KEY = sohc.TAX_BREAKUP_KEY
--         AND otd.header_key = sohc.header_key
--         AND otd.txn_id = sohc.txn_id
--     JOIN TempTaxDetails tod 
--         ON tod.fk_order_headerid = otd.fk_order_headerid
--         AND tod.ext_tax_id = otd.TAX_BREAKUP_KEY
--         AND tod.tax_type = otd.tax_type
--     WHERE sohc.modifyts = rohc.modifyts
-- ) matching_data
-- ON rohc.TAX_BREAKUP_KEY = matching_data.TAX_BREAKUP_KEY
-- AND rohc.header_key = matching_data.header_key
-- AND rohc.txn_id = matching_data.txn_id
-- AND rohc.line_key IS NULL
-- WHEN MATCHED THEN
--     UPDATE SET 
--         rohc.processing_status = ''Processed'',
--         rohc.processing_comment = '''',
--         rohc.processing_errortype = '''';

MERGE INTO  raw.raw_order_tax_breakup rohc
USING (
    SELECT sohc.TAX_BREAKUP_KEY, sohc.header_key, sohc.txn_id, sohc.modifyts
    FROM  transformed.stg_order_tax_breakup sohc
    INNER JOIN ordertaxdetails otd
        ON otd.TAX_BREAKUP_KEY = sohc.TAX_BREAKUP_KEY
        AND otd.header_key = sohc.header_key
        AND otd.txn_id = sohc.txn_id
    INNER JOIN TempTaxDetails tod
        ON tod.fk_order_headerid = otd.fk_order_headerid
        AND tod.ext_tax_id = otd.TAX_BREAKUP_KEY
        AND tod.tax_type = otd.tax_type
) AS source
ON rohc.TAX_BREAKUP_KEY = source.TAX_BREAKUP_KEY
   AND rohc.header_key = source.header_key
   AND rohc.txn_id = source.txn_id
   AND rohc.modifyts = source.modifyts
and rohc.line_key IS NULL
WHEN MATCHED THEN
    UPDATE SET
        rohc.processing_status = ''Processed'',
        rohc.processing_comment = '''',
        rohc.processing_errortype = '''';



CREATE OR REPLACE TEMPORARY TABLE OrderLineDetailTaxes AS
SELECT DISTINCT
    stg.TAX_BREAKUP_KEY,
    toh.order_header_key AS order_header_key,
    tod.ext_line_id AS ext_line_id,
    toh.pk_order_headerid AS fk_order_headerid,
    tod.pk_order_detailid AS fk_order_detailid,
    stg.tax_name AS tax_name,
    TRY_CAST(stg.tax AS FLOAT) AS tax_amount,
    stg.charge_category AS tax_type,
    TRY_CAST(tax_percentage AS FLOAT) AS tax_rate,
    stg.txn_id
FROM
    TRANSFORMED.stg_ORDER_tax_breakup stg
INNER JOIN ANALYTICS.txn_order_header toh ON toh.order_header_key = stg.header_key AND toh.entry_type IS NOT NULL
INNER JOIN master.dim_chargecategory dc ON dc.charge_category = stg.charge_category AND dc.charge = ''TAX''
INNER JOIN ANALYTICS.txn_order_detail tod ON tod.fk_order_headerid = toh.pk_order_headerid AND tod.ext_line_id = stg.line_key
WHERE stg.line_key IS NOT NULL;

CREATE OR REPLACE TEMPORARY TABLE TempLineTaxDetails (
    pk_order_detail_taxid BIGINT,
    fk_order_detailid BIGINT,
    tax_name VARCHAR,
    tax_type VARCHAR,
    tax_rate FLOAT,
    tax_amount FLOAT,
    ext_tax_id VARCHAR,
    created_by INT,
    created_date TIMESTAMP,
    modified_date TIMESTAMP,
    Revision INT
);

processedDate := CURRENT_TIMESTAMP(); 


MERGE INTO ANALYTICS.txn_order_detail_tax AS todt
USING (
    SELECT DISTINCT
        orddetailtaxes.fk_order_detailid,
        orddetailtaxes.tax_name,
        orddetailtaxes.tax_amount,
        orddetailtaxes.tax_type,
        orddetailtaxes.tax_rate,
        orddetailtaxes.TAX_BREAKUP_KEY
    FROM OrderLineDetailTaxes AS orddetailtaxes
) AS odt
ON (
    todt.fk_order_detailid = odt.fk_order_detailid
    AND todt.tax_name = odt.tax_name
    AND todt.tax_type = odt.tax_type
    AND odt.TAX_BREAKUP_KEY = todt.ext_tax_id
)
WHEN MATCHED THEN
UPDATE SET
    todt.tax_name = odt.tax_name,
    todt.tax_type = odt.tax_type,
    todt.tax_rate = odt.tax_rate,
    todt.tax_amount = odt.tax_amount,
    todt.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
INSERT (
    fk_order_detailid,
    ext_tax_id,
    tax_name,
    tax_type,
    tax_rate,
    tax_amount,
    inserted_date,
    modified_date
)
VALUES (
    odt.fk_order_detailid,
    odt.TAX_BREAKUP_KEY,
    odt.tax_name,
    odt.tax_type,
    odt.tax_rate,
    odt.tax_amount,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP()
);

INSERT INTO TempLineTaxDetails (
    pk_order_detail_taxid,
    fk_order_detailid,
    tax_name,
    tax_amount,
    tax_type,
    tax_rate,
    ext_tax_id,
    created_by,
    created_date,
    modified_date,
    revision
)
SELECT 
    pk_order_detail_taxid,
    fk_order_detailid,
    tax_name,
    tax_amount,
    tax_type,
    tax_rate,
    ext_tax_id,
    :createdby,
    inserted_date,
    modified_date,
    :InitialRevision
FROM ANALYTICS.txn_order_detail_tax
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;

MERGE INTO TempLineTaxDetails ttd
USING (
    SELECT 
        MAX(aot.revision) AS revision, 
        aot.pk_order_detail_taxid, 
        aot.fk_order_detailid
    FROM ANALYTICS.audit_order_detail_tax aot
    JOIN TempLineTaxDetails ttd 
        ON ttd.pk_order_detail_taxid = aot.pk_order_detail_taxid
        AND ttd.fk_order_detailid = aot.fk_order_detailid
    GROUP BY aot.pk_order_detail_taxid, aot.fk_order_detailid
) aot
ON ttd.pk_order_detail_taxid = aot.pk_order_detail_taxid
AND ttd.fk_order_detailid = aot.fk_order_detailid
WHEN MATCHED THEN
    UPDATE SET 
        ttd.Revision = CAST((aot.revision + 1) AS INT);


INSERT INTO ANALYTICS.audit_order_detail_tax (
   pk_order_detail_taxid,  
   fk_order_detailid,   
   tax_name,   
   tax_amount,    
   created_by,   
   created_date,   
   modified_date,   
   ext_tax_id,  
   revision
)      
SELECT DISTINCT  
   pk_order_detail_taxid,  
   fk_order_detailid,  
   tax_name,  
   tax_amount,  
   created_by,  
   created_date,  
   modified_date,  
   ext_tax_id,  
   revision  
FROM TempLineTaxDetails;


MERGE INTO raw.raw_order_tax_breakup rohc
USING (
    SELECT sohc.TAX_BREAKUP_KEY, sohc.line_key, sohc.txn_id, sohc.modifyts
    FROM transformed.stg_order_tax_breakup sohc
    INNER JOIN OrderLineDetailTaxes otd
        ON otd.TAX_BREAKUP_KEY = sohc.TAX_BREAKUP_KEY
        AND otd.ext_line_id = sohc.line_key
        AND otd.txn_id = sohc.txn_id
    INNER JOIN TempLineTaxDetails tod
        ON tod.fk_order_detailid = otd.fk_order_detailid
        AND tod.ext_tax_id = otd.TAX_BREAKUP_KEY
        AND tod.tax_type = otd.tax_type
) AS source
ON rohc.TAX_BREAKUP_KEY = source.TAX_BREAKUP_KEY
   AND rohc.line_key = source.line_key
   AND rohc.txn_id = source.txn_id
   AND rohc.modifyts = source.modifyts
and rohc.line_key IS NOT NULL
WHEN MATCHED THEN
    UPDATE SET
        rohc.processing_status = ''Processed'',
        rohc.processing_comment = '''',
        rohc.processing_errortype = '''';



SELECT
    COUNT(*)
INTO
    :processedLineTaxDetails
FROM
    TempLineTaxDetails;


SELECT
    COUNT(*)
INTO
    :processedTaxDetails
FROM
    TempTaxDetails;
    
processedRecordCount := processedLineTaxDetails + processedTaxDetails
;

SELECT  
    :toBeProcessedRecordCount = COUNT(*)  
FROM  
    TRANSFORMED.stg_ORDER_tax_breakup;

UPDATE ANALYTICS.log_files_import_status  
SET 
    processed = :processedRecordCount,  
    to_be_processed = :toBeProcessedRecordCount,  
    status = ''Success''  
FROM 
    ANALYTICS.log_files_import_status AS lofis  
WHERE 
    lofis.file_name = ''YFS_TAX_BREAKUP'';

DROP TABLE IF EXISTS OrderTaxDetails;
DROP TABLE IF EXISTS TempTaxDetails;
DROP TABLE IF EXISTS OrderLineDetailTaxes;
DROP TABLE IF EXISTS TempLineTaxDetails;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;

RETURN ''Success'';

EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_INBOX'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	
	RETURN error_object;
END';
