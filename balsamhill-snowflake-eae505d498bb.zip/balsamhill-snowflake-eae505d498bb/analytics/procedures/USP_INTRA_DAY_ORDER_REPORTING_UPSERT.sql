USE DATABASE DEV; 

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_INTRA_DAY_ORDER_REPORTING_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
    start_time_proc TIMESTAMP_NTZ(9);
    error_object VARIANT;
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

INSERT INTO ANALYTICS.TXN_INTRA_DAY_ORDER_REPORTING
SELECT DISTINCT STG.*
    , SRC.PK_SOURCEID
    , DIM.PK_ORDER_STATUSID
FROM TRANSFORMED.STG_INTRA_DAY_ORDER_REPORTING STG 
    LEFT JOIN MASTER.SOURCE_BRAND_PLATFORM_MAP SRC 
        ON CASE WHEN STG.ENTERPRISE_CODE = ''BHUS'' THEN ''BAL'' ELSE STG.ENTERPRISE_CODE END = SRC.BRANDCODEFORWHM
            AND STG.ORDER_TYPE = UPPER(SRC.PLATFORMNAME)
    LEFT JOIN MASTER.DIM_ORDER_STATUS DIM 
        ON STG.ORDER_STATUS = DIM.ORDER_STATUS_NAME
;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;

RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
    
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
        
    RETURN :error_object;
END';
