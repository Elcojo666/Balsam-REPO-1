CREATE OR REPLACE PROCEDURE ANALYTICS.USP_EXT_ORDER_HEADER_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    createdby NUMBER DEFAULT 1;
    action STRING DEFAULT ''CREATE'';
    productTaxType STRING DEFAULT ''PRODUCT'';
    personalizationFeeType STRING DEFAULT ''FEE-PERSONALIZE'';
    domesticSource STRING DEFAULT ''domestic'';
    internationalSource STRING DEFAULT ''international'';
    processedRecordCount BIGINT DEFAULT 0;
    processedDate TIMESTAMP_NTZ(9);
    start_time_proc TIMESTAMP_NTZ(9);
    error_object VARIANT;
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

CREATE OR REPLACE TEMPORARY TABLE TempExtOrderHeader (
   order_header_key VARCHAR,
   sourcing_classification VARCHAR,
   buyer_organization_code VARCHAR,
   seller_organization_code VARCHAR,
   document_type VARCHAR,
   bill_to_id VARCHAR,
   customer_rewards_no VARCHAR,
   vendor_id VARCHAR,
   ship_to_id VARCHAR,
   ship_node VARCHAR,
   receiving_node VARCHAR,
   buyer_receiving_node_id VARCHAR,
   mark_for_key VARCHAR,
   buyer_mark_for_node_id VARCHAR,
   req_delivery_date VARCHAR,
   req_cancel_date VARCHAR,
   req_ship_date VARCHAR,
   default_template VARCHAR,
   division VARCHAR,
   draft_order_flag VARCHAR,
   order_purpose VARCHAR,
   return_oh_key_for_exchange VARCHAR,
   exchange_type VARCHAR,
   pending_transfer_in VARCHAR,
   return_by_gift_recipient VARCHAR,
   allocation_rule_id VARCHAR,
   priority_code VARCHAR,
   priority_number VARCHAR,
   contact_key VARCHAR,
   scac VARCHAR,
   carrier_service_code VARCHAR,
   custcarrier_account_no VARCHAR,
   notify_after_shipment_flag VARCHAR,
   created_at_node VARCHAR,
   has_derived_child VARCHAR,
   has_derived_parent VARCHAR,
   notification_type VARCHAR,
   notification_reference VARCHAR,
   entry_type VARCHAR,
   authorized_client VARCHAR,
   entered_by VARCHAR,
   personalize_code VARCHAR,
   hold_flag VARCHAR,
   hold_reason_code VARCHAR,
   customer_po_no VARCHAR,
   customer_customer_po_no VARCHAR,
   order_name VARCHAR,
   payment_rule_id VARCHAR,
   terms_code VARCHAR,
   delivery_code VARCHAR,
   charge_actual_freight VARCHAR,
   original_tax VARCHAR,
   currency VARCHAR,
   enterprise_currency VARCHAR,
   reporting_conversion_rate VARCHAR,
   reporting_conversion_date VARCHAR,
   payment_status VARCHAR,
   authorization_expiration_date VARCHAR,
   search_criteria_1 VARCHAR,
   search_criteria_2 VARCHAR,
   fob VARCHAR,
   other_charges VARCHAR,
   price_program_key VARCHAR,
   taxpayer_id VARCHAR,
   tax_jurisdiction VARCHAR,
   tax_exemption_certificate VARCHAR,
   purpose VARCHAR,
   invoice_complete VARCHAR,
   order_closed VARCHAR,
   next_alert_ts VARCHAR,
   do_not_consolidate VARCHAR,
   chain_type VARCHAR,
   adjustment_invoice_pending VARCHAR,
   auto_cancel_date VARCHAR,
   sale_voided VARCHAR,
   is_ship_complete VARCHAR,
   is_line_ship_complete VARCHAR,
   is_ship_single_node VARCHAR,
   is_line_ship_single_node VARCHAR,
   cancel_order_on_excp_flag VARCHAR,
   optimization_type VARCHAR,
   purge_history_date VARCHAR,
   pricing_classification_code VARCHAR,
   source_type VARCHAR,
   source_key VARCHAR,
   linked_source_key VARCHAR,
   original_container_key VARCHAR,
   sold_to_key VARCHAR,
   team_code VARCHAR,
   next_iter_seq_no VARCHAR,
   next_iter_date VARCHAR,
   hrs_before_next_iter VARCHAR,
   createuserid VARCHAR,
   modifyuserid VARCHAR,
   createprogid VARCHAR,
   modifyprogid VARCHAR,
   lockid VARCHAR,
   department_code VARCHAR,
   buyer_user_id VARCHAR,
   recreate_authorizations VARCHAR,
   customer_contact_id VARCHAR,
   opportunity_key VARCHAR,
   is_expiration_date_overridden VARCHAR,
   expiration_date VARCHAR,
   approval_cycle VARCHAR,
   in_store_payment_required VARCHAR,
   immediate_settlement_value VARCHAR,
   customer_age VARCHAR,
   cart_id VARCHAR,
   rollout_version VARCHAR,
   all_addresses_verified VARCHAR,
   compl_gift_box_qty VARCHAR,
   no_of_auth_strikes VARCHAR,
   source_ip_address VARCHAR,
   customer_first_name VARCHAR,
   customer_last_name VARCHAR,
   customer_phone_no VARCHAR,
   customer_zip_code VARCHAR,
   index_version VARCHAR,
   extn_customer_type VARCHAR,
   extn_customer_id VARCHAR,
   extn_cba_ship_label VARCHAR,
   extn_amazon_tfm VARCHAR,
   extn_tfm_ship_status VARCHAR,
   extn_financed_by_affirm VARCHAR,
   extn_risk_status VARCHAR,
   extn_sales_rep_cust_id VARCHAR,
   extn_latest_ship_date VARCHAR,
   extn_latest_delivery_date VARCHAR,
   extn_market_place_id VARCHAR,
   extn_order_status VARCHAR,
   extn_is_prime VARCHAR,
   extn_giftee_full_name VARCHAR,
   extn_giftee_email_id VARCHAR,
   extn_sms_opt_in VARCHAR,
   extn_ga_tag_id VARCHAR,
   extn_fraud_status VARCHAR,
   extn_order_locale_code VARCHAR,
   extn_shipto_firstname VARCHAR,
   extn_shipto_lastname VARCHAR,
   extn_shipto_zipcode VARCHAR,
   extn_return_confirmed_by VARCHAR,
   extn_edi_gcn VARCHAR,
   extn_pk_header_key VARCHAR,
   extn_merchant_id VARCHAR,
   extn_is_avalara VARCHAR,
   extn_req_cancel_date VARCHAR,
   extn_is_email_sent VARCHAR,
   extn_is_txn_committed VARCHAR,
   extn_tax_txn_date VARCHAR,
   extn_last_refund_txn_code VARCHAR,
   extn_refund_txn_code VARCHAR,
   extn_min_estimated_delivery_date VARCHAR,
   extn_max_estimated_delivery_date VARCHAR,
   extn_apply_migration_hold VARCHAR,
   extn_signifyd_order_id VARCHAR,
   extn_primary_reason VARCHAR,
   extn_secondary_reason VARCHAR,
   extn_sales_entry_type VARCHAR,
   extn_sales_order_type VARCHAR,
   extn_warranty_order_no VARCHAR,
   extn_seller_payment_type VARCHAR,
   createts VARCHAR,
   modifyts VARCHAR,
   revision VARCHAR
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.ext_order_header eoh
USING (
  SELECT DISTINCT
    stg.order_header_key,
    stg.sourcing_classification,
    stg.buyer_organization_code,
    stg.seller_organization_code,
    stg.document_type,
    stg.bill_to_id,
    stg.customer_rewards_no,
    stg.vendor_id,
    stg.ship_to_id,
    stg.ship_node,
    stg.receiving_node,
    stg.buyer_receiving_node_id,
    stg.mark_for_key,
    stg.buyer_mark_for_node_id,
    stg.req_delivery_date,
    stg.req_cancel_date,
    stg.req_ship_date,
    stg.default_template,
    stg.division,
    stg.draft_order_flag,
    stg.order_purpose,
    stg.return_oh_key_for_exchange,
    stg.exchange_type,
    stg.pending_transfer_in,
    stg.return_by_gift_recipient,
    stg.allocation_rule_id,
    stg.priority_code,
    stg.priority_number,
    stg.contact_key,
    stg.scac,
    stg.carrier_service_code,
    stg.custcarrier_account_no,
    stg.notify_after_shipment_flag,
    stg.created_at_node,
    stg.has_derived_child,
    stg.has_derived_parent,
    stg.notification_type,
    stg.notification_reference,
    stg.entry_type,
    stg.authorized_client,
    stg.entered_by,
    stg.personalize_code,
    stg.hold_flag,
    stg.hold_reason_code,
    stg.customer_po_no,
    stg.customer_customer_po_no,
    stg.order_name,
    stg.payment_rule_id,
    stg.terms_code,
    stg.delivery_code,
    stg.charge_actual_freight,
    stg.original_tax,
    stg.currency,
    stg.enterprise_currency,
    stg.reporting_conversion_rate,
    stg.reporting_conversion_date,
    stg.payment_status,
    stg.authorization_expiration_date,
    stg.search_criteria_1,
    stg.search_criteria_2,
    stg.fob,
    stg.other_charges,
    stg.price_program_key,
    stg.taxpayer_id,
    stg.tax_jurisdiction,
    stg.tax_exemption_certificate,
    stg.purpose,
    stg.invoice_complete,
    stg.order_closed,
    stg.next_alert_ts,
    stg.do_not_consolidate,
    stg.chain_type,
    stg.adjustment_invoice_pending,
    stg.auto_cancel_date,
    stg.sale_voided,
    stg.is_ship_complete,
    stg.is_line_ship_complete,
    stg.is_ship_single_node,
    stg.is_line_ship_single_node,
    stg.cancel_order_on_excp_flag,
    stg.optimization_type,
    stg.purge_history_date,
    stg.pricing_classification_code,
    stg.source_type,
    stg.source_key,
    stg.linked_source_key,
    stg.original_container_key,
    stg.sold_to_key,
    stg.team_code,
    stg.next_iter_seq_no,
    stg.next_iter_date,
    stg.hrs_before_next_iter,
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    stg.department_code,
    stg.buyer_user_id,
    stg.recreate_authorizations,
    stg.customer_contact_id,
    stg.opportunity_key,
    stg.is_expiration_date_overridden,
    stg.expiration_date,
    stg.approval_cycle,
    stg.in_store_payment_required,
    stg.immediate_settlement_value,
    stg.customer_age,
    stg.cart_id,
    stg.rollout_version,
    stg.all_addresses_verified,
    stg.compl_gift_box_qty,
    stg.no_of_auth_strikes,
    stg.source_ip_address,
    stg.customer_first_name,
    stg.customer_last_name,
    stg.customer_phone_no,
    stg.customer_zip_code,
    stg.index_version,
    stg.extn_customer_type,
    stg.extn_customer_id,
    stg.extn_cba_ship_label,
    stg.extn_amazon_tfm,
    stg.extn_tfm_ship_status,
    stg.extn_financed_by_affirm,
    stg.extn_risk_status,
    stg.extn_sales_rep_cust_id,
    stg.extn_latest_ship_date,
    stg.extn_latest_delivery_date,
    stg.extn_market_place_id,
    stg.extn_order_status,
    stg.extn_is_prime,
    stg.extn_giftee_full_name,
    stg.extn_giftee_email_id,
    stg.extn_sms_opt_in,
    stg.extn_ga_tag_id,
    stg.extn_fraud_status,
    stg.extn_order_locale_code,
    stg.extn_shipto_firstname,
    stg.extn_shipto_lastname,
    stg.extn_shipto_zipcode,
    stg.extn_return_confirmed_by,
    stg.extn_edi_gcn,
    stg.extn_pk_header_key,
    stg.extn_merchant_id,
    stg.extn_is_avalara,
    stg.extn_req_cancel_date,
    stg.extn_is_email_sent,
    stg.extn_is_txn_committed,
    stg.extn_tax_txn_date,
    stg.extn_last_refund_txn_code,
    stg.extn_refund_txn_code,
    stg.extn_min_estimated_delivery_date,
    stg.extn_max_estimated_delivery_date,
    stg.extn_apply_migration_hold,
    stg.extn_signifyd_order_id,
    stg.extn_primary_reason,
    stg.extn_secondary_reason,
    stg.extn_sales_entry_type,
    stg.extn_sales_order_type,
    stg.extn_warranty_order_no,
    stg.extn_seller_payment_type,
    stg.createts,
    stg.modifyts
  FROM TRANSFORMED.stg_order_header stg
  INNER JOIN RAW.raw_order_header r
    ON r.order_header_key = stg.order_header_key
    AND r.modifyts = stg.modifyts
    AND r.processing_status = ''Processed''
) soh
ON eoh.order_header_key = soh.order_header_key
WHEN MATCHED THEN
  UPDATE SET
    eoh.order_header_key = soh.order_header_key,
    eoh.sourcing_classification = soh.sourcing_classification,
    eoh.buyer_organization_code = soh.buyer_organization_code,
    eoh.seller_organization_code = soh.seller_organization_code,
    eoh.document_type = soh.document_type,
    eoh.bill_to_id = soh.bill_to_id,
    eoh.customer_rewards_no = soh.customer_rewards_no,
    eoh.vendor_id = soh.vendor_id,
    eoh.ship_to_id = soh.ship_to_id,
    eoh.ship_node = soh.ship_node,
    eoh.receiving_node = soh.receiving_node,
    eoh.buyer_receiving_node_id = soh.buyer_receiving_node_id,
    eoh.mark_for_key = soh.mark_for_key,
    eoh.buyer_mark_for_node_id = soh.buyer_mark_for_node_id,
    eoh.req_delivery_date = TRY_TO_TIMESTAMP(soh.req_delivery_date,''YYYYMMDDHHMISS'')  ,
    eoh.req_cancel_date = TRY_TO_TIMESTAMP(soh.req_cancel_date,''YYYYMMDDHHMISS'')  ,
    eoh.req_ship_date = TRY_TO_TIMESTAMP(soh.req_ship_date,''YYYYMMDDHHMISS'')  ,
    eoh.default_template = soh.default_template,
    eoh.division = soh.division,
    eoh.draft_order_flag = soh.draft_order_flag,
    eoh.order_purpose = soh.order_purpose,
    eoh.return_oh_key_for_exchange = soh.return_oh_key_for_exchange,
    eoh.exchange_type = soh.exchange_type,
    eoh.pending_transfer_in = soh.pending_transfer_in,
    eoh.return_by_gift_recipient = soh.return_by_gift_recipient,
    eoh.allocation_rule_id = soh.allocation_rule_id,
    eoh.priority_code = soh.priority_code,
    eoh.priority_number = soh.priority_number,
    eoh.contact_key = soh.contact_key,
    eoh.scac = soh.scac,
    eoh.carrier_service_code = soh.carrier_service_code,
    eoh.custcarrier_account_no = soh.custcarrier_account_no,
    eoh.notify_after_shipment_flag = soh.notify_after_shipment_flag,
    eoh.created_at_node = soh.created_at_node,
    eoh.has_derived_child = soh.has_derived_child,
    eoh.has_derived_parent = soh.has_derived_parent,
    eoh.notification_type = soh.notification_type,
    eoh.notification_reference = soh.notification_reference,
    eoh.entry_type = soh.entry_type,
    eoh.authorized_client = soh.authorized_client,
    eoh.entered_by = soh.entered_by,
    eoh.personalize_code = soh.personalize_code,
    eoh.hold_flag = soh.hold_flag,
    eoh.hold_reason_code = soh.hold_reason_code,
    eoh.customer_po_no = soh.customer_po_no,
    eoh.customer_customer_po_no = soh.customer_customer_po_no,
    eoh.order_name = soh.order_name,
    eoh.payment_rule_id = soh.payment_rule_id,
    eoh.terms_code = soh.terms_code,
    eoh.delivery_code = soh.delivery_code,
    eoh.charge_actual_freight = soh.charge_actual_freight,
    eoh.original_tax = soh.original_tax,
    eoh.currency = soh.currency,
    eoh.enterprise_currency = soh.enterprise_currency,
    eoh.reporting_conversion_rate = soh.reporting_conversion_rate,
    eoh.reporting_conversion_date =  TRY_TO_TIMESTAMP(soh.reporting_conversion_date,''YYYYMMDDHHMISS'')  ,
    eoh.payment_status = TRY_TO_TIMESTAMP(soh.payment_status,''YYYYMMDDHHMISS'')  ,
    eoh.authorization_expiration_date = TRY_TO_TIMESTAMP(soh.authorization_expiration_date,''YYYYMMDDHHMISS'')  ,
    eoh.search_criteria_1 = soh.search_criteria_1,
    eoh.search_criteria_2 = soh.search_criteria_2,
    eoh.fob = soh.fob,
    eoh.other_charges = soh.other_charges,
    eoh.price_program_key = soh.price_program_key,
    eoh.taxpayer_id = soh.taxpayer_id,
    eoh.tax_jurisdiction = soh.tax_jurisdiction,
    eoh.tax_exemption_certificate = soh.tax_exemption_certificate,
    eoh.purpose = soh.purpose,
    eoh.invoice_complete = soh.invoice_complete,
    eoh.order_closed = soh.order_closed,
    eoh.next_alert_ts = soh.next_alert_ts,
    eoh.do_not_consolidate =  TRY_TO_TIMESTAMP(soh.do_not_consolidate,''YYYYMMDDHHMISS'')  ,
    eoh.chain_type = soh.chain_type,
    eoh.adjustment_invoice_pending = soh.adjustment_invoice_pending,
    eoh.auto_cancel_date = TRY_TO_TIMESTAMP(soh.auto_cancel_date,''YYYYMMDDHHMISS'')  ,
    eoh.sale_voided = soh.sale_voided,
    eoh.is_ship_complete = soh.is_ship_complete,
    eoh.is_line_ship_complete = soh.is_line_ship_complete,
    eoh.is_ship_single_node = soh.is_ship_single_node,
    eoh.is_line_ship_single_node = soh.is_line_ship_single_node,
    eoh.cancel_order_on_excp_flag = soh.cancel_order_on_excp_flag,
    eoh.optimization_type = soh.optimization_type,
    eoh.purge_history_date = TRY_TO_TIMESTAMP(soh.purge_history_date,''YYYYMMDDHHMISS'')  ,
    eoh.pricing_classification_code = soh.pricing_classification_code,
    eoh.source_type = soh.source_type,
    eoh.source_key = soh.source_key,
    eoh.linked_source_key = soh.linked_source_key,
    eoh.original_container_key = soh.original_container_key,
    eoh.sold_to_key = soh.sold_to_key,
    eoh.team_code = soh.team_code,
    eoh.next_iter_seq_no = soh.next_iter_seq_no,
    eoh.next_iter_date = TRY_TO_TIMESTAMP(soh.next_iter_date,''YYYYMMDDHHMISS'')  ,
    eoh.hrs_before_next_iter = soh.hrs_before_next_iter,
    eoh.createuserid = soh.createuserid,
    eoh.modifyuserid = soh.modifyuserid,
    eoh.createprogid = soh.createprogid,
    eoh.modifyprogid = soh.modifyprogid,
    eoh.lockid = soh.lockid,
    eoh.department_code = soh.department_code,
    eoh.buyer_user_id = soh.buyer_user_id,
    eoh.recreate_authorizations = soh.recreate_authorizations,
    eoh.customer_contact_id = soh.customer_contact_id,
    eoh.opportunity_key = soh.opportunity_key,
    eoh.is_expiration_date_overridden = soh.is_expiration_date_overridden ,
    eoh.expiration_date = TRY_TO_TIMESTAMP(soh.expiration_date,''YYYYMMDDHHMISS'')  ,
    eoh.approval_cycle = soh.approval_cycle,
    eoh.in_store_payment_required = soh.in_store_payment_required,
    eoh.immediate_settlement_value = soh.immediate_settlement_value,
    eoh.customer_age = soh.customer_age,
    eoh.cart_id = soh.cart_id,
    eoh.rollout_version = soh.rollout_version,
    eoh.all_addresses_verified = soh.all_addresses_verified,
    eoh.compl_gift_box_qty = soh.compl_gift_box_qty,
    eoh.no_of_auth_strikes = soh.no_of_auth_strikes,
    eoh.source_ip_address = soh.source_ip_address,
    eoh.customer_first_name = soh.customer_first_name,
    eoh.customer_last_name = soh.customer_last_name,
    eoh.customer_phone_no = soh.customer_phone_no,
    eoh.customer_zip_code = soh.customer_zip_code,
    eoh.index_version = soh.index_version,
    eoh.extn_customer_type = soh.extn_customer_type,
    eoh.extn_customer_id = soh.extn_customer_id,
    eoh.extn_cba_ship_label = soh.extn_cba_ship_label,
    eoh.extn_amazon_tfm = soh.extn_amazon_tfm,
    eoh.extn_tfm_ship_status = soh.extn_tfm_ship_status,
    eoh.extn_financed_by_affirm = soh.extn_financed_by_affirm,
    eoh.extn_risk_status = soh.extn_risk_status,
    eoh.extn_sales_rep_cust_id = soh.extn_sales_rep_cust_id,
    eoh.extn_latest_ship_date = TRY_TO_TIMESTAMP(soh.extn_latest_ship_date,''YYYYMMDDHHMISS'')  ,
    eoh.extn_latest_delivery_date = TRY_TO_TIMESTAMP(soh.extn_latest_delivery_date,''YYYYMMDDHHMISS'')  ,
    eoh.extn_market_place_id = soh.extn_market_place_id,
    eoh.extn_order_status = soh.extn_order_status,
    eoh.extn_is_prime = soh.extn_is_prime,
    eoh.extn_giftee_full_name = soh.extn_giftee_full_name,
    eoh.extn_giftee_email_id = soh.extn_giftee_email_id,
    eoh.extn_sms_opt_in = soh.extn_sms_opt_in,
    eoh.extn_ga_tag_id = soh.extn_ga_tag_id,
    eoh.extn_fraud_status = soh.extn_fraud_status,
    eoh.extn_order_locale_code = soh.extn_order_locale_code,
    eoh.extn_shipto_firstname = soh.extn_shipto_firstname,
    eoh.extn_shipto_lastname = soh.extn_shipto_lastname,
    eoh.extn_shipto_zipcode = soh.extn_shipto_zipcode,
    eoh.extn_return_confirmed_by = soh.extn_return_confirmed_by,
    eoh.extn_edi_gcn = soh.extn_edi_gcn,
    eoh.extn_pk_header_key = soh.extn_pk_header_key,
    eoh.extn_merchant_id = soh.extn_merchant_id,
    eoh.extn_is_avalara = soh.extn_is_avalara,
    eoh.extn_req_cancel_date = TRY_TO_TIMESTAMP(soh.extn_req_cancel_date,''YYYYMMDDHHMISS''),
    eoh.extn_is_email_sent = soh.extn_is_email_sent,
    eoh.extn_is_txn_committed = soh.extn_is_txn_committed,
    eoh.extn_tax_txn_date = TRY_TO_TIMESTAMP(soh.extn_tax_txn_date,''YYYYMMDDHHMISS'')  ,
    eoh.extn_last_refund_txn_code = soh.extn_last_refund_txn_code,
    eoh.extn_refund_txn_code = soh.extn_refund_txn_code,
    eoh.extn_min_estimated_delivery_date = TRY_TO_TIMESTAMP(soh.extn_min_estimated_delivery_date,''YYYYMMDDHHMISS'')  ,
    eoh.extn_max_estimated_delivery_date = TRY_TO_TIMESTAMP(soh.extn_max_estimated_delivery_date,''YYYYMMDDHHMISS'')  ,
    eoh.extn_apply_migration_hold = soh.extn_apply_migration_hold,
    eoh.extn_signifyd_order_id = soh.extn_signifyd_order_id,
    eoh.extn_primary_reason = soh.extn_primary_reason,
    eoh.extn_secondary_reason = soh.extn_secondary_reason,
    eoh.extn_sales_entry_type = soh.extn_sales_entry_type,
    eoh.extn_sales_order_type = soh.extn_sales_order_type,
    eoh.extn_warranty_order_no = soh.extn_warranty_order_no,
    eoh.extn_seller_payment_type = soh.extn_seller_payment_type,
    eoh.createts = TRY_TO_TIMESTAMP(soh.createts,''YYYYMMDDHHMISS''),
    eoh.modifyts = TRY_TO_TIMESTAMP(soh.modifyts,''YYYYMMDDHHMISS'')
WHEN NOT MATCHED THEN
  INSERT  (  
    order_header_key  
    ,sourcing_classification  
    ,buyer_organization_code  
    ,seller_organization_code  
    ,document_type  
    ,bill_to_id  
    ,customer_rewards_no  
    ,vendor_id  
    ,ship_to_id  
    ,ship_node  
    ,receiving_node  
    ,buyer_receiving_node_id  
    ,mark_for_key  
    ,buyer_mark_for_node_id  
    ,req_delivery_date  
    ,req_cancel_date  
    ,req_ship_date  
    ,default_template  
    ,division  
    ,draft_order_flag  
    ,order_purpose  
    ,return_oh_key_for_exchange  
    ,exchange_type  
    ,pending_transfer_in  
    ,return_by_gift_recipient  
    ,allocation_rule_id  
    ,priority_code  
    ,priority_number  
    ,contact_key  
    ,scac  
    ,carrier_service_code  
    ,custcarrier_account_no  
    ,notify_after_shipment_flag  
    ,created_at_node  
    ,has_derived_child  
    ,has_derived_parent  
    ,notification_type  
    ,notification_reference  
    ,entry_type  
    ,authorized_client  
    ,entered_by  
    ,personalize_code  
    ,hold_flag  
    ,hold_reason_code  
    ,customer_po_no  
    ,customer_customer_po_no  
    ,order_name  
    ,payment_rule_id  
    ,terms_code  
    ,delivery_code  
    ,charge_actual_freight  
    ,original_tax  
    ,currency  
    ,enterprise_currency  
    ,reporting_conversion_rate  
    ,reporting_conversion_date  
    ,payment_status  
    ,authorization_expiration_date  
    ,search_criteria_1  
    ,search_criteria_2  
    ,fob  
    ,other_charges  
    ,price_program_key  
    ,taxpayer_id  
    ,tax_jurisdiction  
    ,tax_exemption_certificate  
    ,purpose  
    ,invoice_complete  
    ,order_closed  
    ,next_alert_ts  
    ,do_not_consolidate  
    ,chain_type  
    ,adjustment_invoice_pending  
    ,auto_cancel_date  
    ,sale_voided  
    ,is_ship_complete  
    ,is_line_ship_complete  
    ,is_ship_single_node  
    ,is_line_ship_single_node  
    ,cancel_order_on_excp_flag  
    ,optimization_type  
    ,purge_history_date  
    ,pricing_classification_code  
    ,source_type  
    ,source_key  
    ,linked_source_key  
    ,original_container_key  
    ,sold_to_key  
    ,team_code  
    ,next_iter_seq_no  
    ,next_iter_date  
    ,hrs_before_next_iter  
    ,createuserid  
    ,modifyuserid  
    ,createprogid  
    ,modifyprogid  
    ,lockid  
    ,department_code  
    ,buyer_user_id  
    ,recreate_authorizations  
    ,customer_contact_id  
    ,opportunity_key  
    ,is_expiration_date_overridden  
    ,expiration_date  
    ,approval_cycle  
    ,in_store_payment_required  
    ,immediate_settlement_value  
    ,customer_age  
    ,cart_id  
    ,rollout_version  
    ,all_addresses_verified  
    ,compl_gift_box_qty  
    ,no_of_auth_strikes  
    ,source_ip_address  
    ,customer_first_name  
    ,customer_last_name  
    ,customer_phone_no  
    ,customer_zip_code  
    ,index_version  
    ,extn_customer_type  
    ,extn_customer_id  
    ,extn_cba_ship_label  
    ,extn_amazon_tfm  
    ,extn_tfm_ship_status  
    ,extn_financed_by_affirm  
    ,extn_risk_status  
    ,extn_sales_rep_cust_id  
    ,extn_latest_ship_date  
    ,extn_latest_delivery_date  
    ,extn_market_place_id  
    ,extn_order_status  
    ,extn_is_prime  
    ,extn_giftee_full_name  
    ,extn_giftee_email_id  
    ,extn_sms_opt_in  
    ,extn_ga_tag_id  
    ,extn_fraud_status  
    ,extn_order_locale_code  
    ,extn_shipto_firstname  
    ,extn_shipto_lastname  
    ,extn_shipto_zipcode  
   ,extn_return_confirmed_by
   ,extn_edi_gcn
   ,extn_pk_header_key
   ,extn_merchant_id
   ,extn_is_avalara
   ,extn_req_cancel_date
   ,extn_is_email_sent
   ,extn_is_txn_committed
   ,extn_tax_txn_date
   ,extn_last_refund_txn_code
   ,extn_refund_txn_code
   ,extn_min_estimated_delivery_date
   ,extn_max_estimated_delivery_date
   ,extn_apply_migration_hold
   ,extn_signifyd_order_id
   ,extn_primary_reason
   ,extn_secondary_reason
   ,extn_sales_entry_type
   ,extn_sales_order_type
   ,extn_warranty_order_no
   ,extn_seller_payment_type
   ,createts
   ,modifyts
   ,inserted_date
   )  
  VALUES (
    soh.order_header_key,
    soh.sourcing_classification,
    soh.buyer_organization_code,
    soh.seller_organization_code,
    soh.document_type,
    soh.bill_to_id,
    soh.customer_rewards_no,
    soh.vendor_id,
    soh.ship_to_id,
    soh.ship_node,
    soh.receiving_node,
    soh.buyer_receiving_node_id,
    soh.mark_for_key,
    soh.buyer_mark_for_node_id,
    TRY_TO_TIMESTAMP(soh.req_delivery_date,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(soh.req_cancel_date,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(soh.req_ship_date,''YYYYMMDDHHMISS''),
    soh.default_template,
    soh.division,
    soh.draft_order_flag,
    soh.order_purpose,
    soh.return_oh_key_for_exchange,
    soh.exchange_type,
    soh.pending_transfer_in,
    soh.return_by_gift_recipient,
    soh.allocation_rule_id,
    soh.priority_code,
    soh.priority_number,
    soh.contact_key,
    soh.scac,
    soh.carrier_service_code,
    soh.custcarrier_account_no,
    soh.notify_after_shipment_flag,
    soh.created_at_node,
    soh.has_derived_child,
    soh.has_derived_parent,
    soh.notification_type,
    soh.notification_reference,
    soh.entry_type,
    soh.authorized_client,
    soh.entered_by,
    soh.personalize_code,
    soh.hold_flag,
    soh.hold_reason_code,
    soh.customer_po_no,
    soh.customer_customer_po_no,
    soh.order_name,
    soh.payment_rule_id,
    soh.terms_code,
    soh.delivery_code,
    soh.charge_actual_freight,
    soh.original_tax,
    soh.currency,
    soh.enterprise_currency,
    soh.reporting_conversion_rate,
    TRY_TO_TIMESTAMP(soh.reporting_conversion_date,''YYYYMMDDHHMISS''),
    soh.payment_status,
    TRY_TO_TIMESTAMP(soh.authorization_expiration_date,''YYYYMMDDHHMISS''),
    soh.search_criteria_1,
    soh.search_criteria_2,
    soh.fob,
    soh.other_charges,
    soh.price_program_key,
    soh.taxpayer_id,
    soh.tax_jurisdiction,
    soh.tax_exemption_certificate,
    soh.purpose,
    soh.invoice_complete,
    soh.order_closed,
    soh.next_alert_ts,
    TRY_TO_TIMESTAMP(soh.do_not_consolidate,''YYYYMMDDHHMISS''),
    soh.chain_type,
    soh.adjustment_invoice_pending,
    TRY_TO_TIMESTAMP(soh.auto_cancel_date,''YYYYMMDDHHMISS''),
    soh.sale_voided,
    soh.is_ship_complete,
    soh.is_line_ship_complete,
    soh.is_ship_single_node,
    soh.is_line_ship_single_node,
    soh.cancel_order_on_excp_flag,
    soh.optimization_type,
    TRY_TO_TIMESTAMP(soh.purge_history_date,''YYYYMMDDHHMISS''),
    soh.pricing_classification_code,
    soh.source_type,
    soh.source_key,
    soh.linked_source_key,
    soh.original_container_key,
    soh.sold_to_key,
    soh.team_code,
    soh.next_iter_seq_no,
    TRY_TO_TIMESTAMP(soh.next_iter_date,''YYYYMMDDHHMISS''),
    soh.hrs_before_next_iter,
    soh.createuserid,
    soh.modifyuserid,
    soh.createprogid,
    soh.modifyprogid,
    soh.lockid,
    soh.department_code,
    soh.buyer_user_id,
    soh.recreate_authorizations,
    soh.customer_contact_id,
    soh.opportunity_key,
    soh.is_expiration_date_overridden,
    TRY_TO_TIMESTAMP(soh.expiration_date,''YYYYMMDDHHMISS''),
    soh.approval_cycle,
    soh.in_store_payment_required,
    soh.immediate_settlement_value,
    soh.customer_age,
    soh.cart_id,
    soh.rollout_version,
    soh.all_addresses_verified,
    soh.compl_gift_box_qty,
    soh.no_of_auth_strikes,
    soh.source_ip_address,
    soh.customer_first_name,
    soh.customer_last_name,
    soh.customer_phone_no,
    soh.customer_zip_code,
    soh.index_version,
    soh.extn_customer_type,
    soh.extn_customer_id,
    soh.extn_cba_ship_label,
    soh.extn_amazon_tfm,
    soh.extn_tfm_ship_status,
    soh.extn_financed_by_affirm,
    soh.extn_risk_status,
    soh.extn_sales_rep_cust_id,
    TRY_TO_TIMESTAMP(soh.extn_latest_ship_date,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(soh.extn_latest_delivery_date,''YYYYMMDDHHMISS''),
    soh.extn_market_place_id,
    soh.extn_order_status,
    soh.extn_is_prime,
    soh.extn_giftee_full_name,
    soh.extn_giftee_email_id,
    soh.extn_sms_opt_in,
    soh.extn_ga_tag_id,
    soh.extn_fraud_status,
    soh.extn_order_locale_code,
    soh.extn_shipto_firstname,
    soh.extn_shipto_lastname,
    soh.extn_shipto_zipcode,
    soh.extn_return_confirmed_by,
    soh.extn_edi_gcn,
    soh.extn_pk_header_key,
    soh.extn_merchant_id,
    soh.extn_is_avalara,
    TRY_TO_TIMESTAMP(soh.extn_req_cancel_date,''YYYYMMDDHHMISS''),
    soh.extn_is_email_sent,
    soh.extn_is_txn_committed,
    TRY_TO_TIMESTAMP(soh.extn_tax_txn_date,''YYYYMMDDHHMISS''),
    soh.extn_last_refund_txn_code,
    soh.extn_refund_txn_code,
    TRY_TO_TIMESTAMP(soh.extn_min_estimated_delivery_date,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(soh.extn_max_estimated_delivery_date,''YYYYMMDDHHMISS''),
    soh.extn_apply_migration_hold,
    soh.extn_signifyd_order_id,
    soh.extn_primary_reason,
    soh.extn_secondary_reason,
    soh.extn_sales_entry_type,
    soh.extn_sales_order_type,
    soh.extn_warranty_order_no,
    soh.extn_seller_payment_type,
    TRY_TO_TIMESTAMP(soh.createts,''YYYYMMDDHHMISS''),
    TRY_TO_TIMESTAMP(soh.modifyts,''YYYYMMDDHHMISS''),
    CURRENT_TIMESTAMP()
  );

INSERT INTO TempExtOrderHeader(
order_header_key  
    ,sourcing_classification  
    ,buyer_organization_code  
    ,seller_organization_code  
    ,document_type  
    ,bill_to_id  
    ,customer_rewards_no  
    ,vendor_id  
    ,ship_to_id  
    ,ship_node  
    ,receiving_node  
    ,buyer_receiving_node_id  
    ,mark_for_key  
    ,buyer_mark_for_node_id  
    ,req_delivery_date  
    ,req_cancel_date  
    ,req_ship_date  
    ,default_template  
    ,division  
    ,draft_order_flag  
    ,order_purpose  
    ,return_oh_key_for_exchange  
    ,exchange_type  
    ,pending_transfer_in  
    ,return_by_gift_recipient  
    ,allocation_rule_id  
    ,priority_code  
    ,priority_number  
    ,contact_key  
    ,scac  
    ,carrier_service_code  
    ,custcarrier_account_no  
    ,notify_after_shipment_flag  
    ,created_at_node  
    ,has_derived_child  
    ,has_derived_parent  
    ,notification_type  
    ,notification_reference  
    ,entry_type  
    ,authorized_client  
    ,entered_by  
    ,personalize_code  
    ,hold_flag  
    ,hold_reason_code  
    ,customer_po_no  
    ,customer_customer_po_no  
    ,order_name  
    ,payment_rule_id  
    ,terms_code  
    ,delivery_code  
    ,charge_actual_freight  
    ,original_tax  
    ,currency  
    ,enterprise_currency  
    ,reporting_conversion_rate  
    ,reporting_conversion_date  
    ,payment_status  
    ,authorization_expiration_date  
    ,search_criteria_1  
    ,search_criteria_2  
    ,fob  
    ,other_charges  
    ,price_program_key  
    ,taxpayer_id  
    ,tax_jurisdiction  
    ,tax_exemption_certificate  
    ,purpose  
    ,invoice_complete  
    ,order_closed  
    ,next_alert_ts  
    ,do_not_consolidate  
    ,chain_type  
    ,adjustment_invoice_pending  
    ,auto_cancel_date  
    ,sale_voided  
    ,is_ship_complete  
    ,is_line_ship_complete  
    ,is_ship_single_node  
    ,is_line_ship_single_node  
    ,cancel_order_on_excp_flag  
    ,optimization_type  
    ,purge_history_date  
    ,pricing_classification_code  
    ,source_type  
    ,source_key  
    ,linked_source_key  
    ,original_container_key  
    ,sold_to_key  
    ,team_code  
    ,next_iter_seq_no  
    ,next_iter_date  
    ,hrs_before_next_iter  
    ,createuserid  
    ,modifyuserid  
    ,createprogid  
    ,modifyprogid  
    ,lockid  
    ,department_code  
    ,buyer_user_id  
    ,recreate_authorizations  
    ,customer_contact_id  
    ,opportunity_key  
    ,is_expiration_date_overridden  
    ,expiration_date  
    ,approval_cycle  
    ,in_store_payment_required  
    ,immediate_settlement_value  
    ,customer_age  
    ,cart_id  
    ,rollout_version  
    ,all_addresses_verified  
    ,compl_gift_box_qty  
    ,no_of_auth_strikes  
    ,source_ip_address  
    ,customer_first_name  
    ,customer_last_name  
    ,customer_phone_no  
    ,customer_zip_code  
    ,index_version  
    ,extn_customer_type  
    ,extn_customer_id  
    ,extn_cba_ship_label  
    ,extn_amazon_tfm  
    ,extn_tfm_ship_status  
    ,extn_financed_by_affirm  
    ,extn_risk_status  
    ,extn_sales_rep_cust_id  
    ,extn_latest_ship_date  
    ,extn_latest_delivery_date  
    ,extn_market_place_id  
    ,extn_order_status  
    ,extn_is_prime  
    ,extn_giftee_full_name  
    ,extn_giftee_email_id  
    ,extn_sms_opt_in  
    ,extn_ga_tag_id  
    ,extn_fraud_status  
    ,extn_order_locale_code  
    ,extn_shipto_firstname  
    ,extn_shipto_lastname  
    ,extn_shipto_zipcode
	,extn_return_confirmed_by
    ,extn_edi_gcn
    ,extn_pk_header_key
    ,extn_merchant_id
    ,extn_is_avalara
    ,extn_req_cancel_date
    ,extn_is_email_sent
    ,extn_is_txn_committed
    ,extn_tax_txn_date
    ,extn_last_refund_txn_code
    ,extn_refund_txn_code
    ,extn_min_estimated_delivery_date
    ,extn_max_estimated_delivery_date
    ,extn_apply_migration_hold
    ,extn_signifyd_order_id
    ,extn_primary_reason
    ,extn_secondary_reason
    ,extn_sales_entry_type
    ,extn_sales_order_type
    ,extn_warranty_order_no
    ,extn_seller_payment_type
	,createts
	,modifyts
    ,Revision  
)
SELECT inserted.order_header_key,  
   inserted.sourcing_classification,  
   inserted.buyer_organization_code,  
   inserted.seller_organization_code,  
   inserted.document_type,  
   inserted.bill_to_id,  
   inserted.customer_rewards_no,  
   inserted.vendor_id,  
   inserted.ship_to_id,  
   inserted.ship_node,  
   inserted.receiving_node,  
   inserted.buyer_receiving_node_id,  
   inserted.mark_for_key,  
   inserted.buyer_mark_for_node_id,  
   inserted.req_delivery_date,  
   inserted.req_cancel_date,  
   inserted.req_ship_date,  
   inserted.default_template,  
   inserted.division,  
   inserted.draft_order_flag,  
   inserted.order_purpose,  
   inserted.return_oh_key_for_exchange,  
   inserted.exchange_type,  
   inserted.pending_transfer_in,  
   inserted.return_by_gift_recipient,  
   inserted.allocation_rule_id,  
   inserted.priority_code,  
   inserted.priority_number,  
   inserted.contact_key,  
   inserted.scac,  
   inserted.carrier_service_code,  
   inserted.custcarrier_account_no,  
   inserted.notify_after_shipment_flag,  
   inserted.created_at_node,  
   inserted.has_derived_child,  
   inserted.has_derived_parent,  
   inserted.notification_type,  
   inserted.notification_reference,  
   inserted.entry_type,  
   inserted.authorized_client,  
   inserted.entered_by,  
   inserted.personalize_code,  
   inserted.hold_flag,  
   inserted.hold_reason_code,  
   inserted.customer_po_no,  
   inserted.customer_customer_po_no,  
   inserted.order_name,  
   inserted.payment_rule_id,  
   inserted.terms_code,  
   inserted.delivery_code,  
   inserted.charge_actual_freight,  
   inserted.original_tax,  
   inserted.currency,  
   inserted.enterprise_currency,  
   inserted.reporting_conversion_rate,  
   inserted.reporting_conversion_date,  
   inserted.payment_status,  
   inserted.authorization_expiration_date,  
   inserted.search_criteria_1,  
   inserted.search_criteria_2,  
   inserted.fob,  
   inserted.other_charges,  
   inserted.price_program_key,  
   inserted.taxpayer_id,  
   inserted.tax_jurisdiction,  
   inserted.tax_exemption_certificate,  
   inserted.purpose,  
   inserted.invoice_complete,  
   inserted.order_closed,  
   inserted.next_alert_ts,  
   inserted.do_not_consolidate,  
   inserted.chain_type,  
   inserted.adjustment_invoice_pending,  
   inserted.auto_cancel_date,  
   inserted.sale_voided,  
   inserted.is_ship_complete,  
   inserted.is_line_ship_complete,  
   inserted.is_ship_single_node,  
   inserted.is_line_ship_single_node,  
   inserted.cancel_order_on_excp_flag,  
   inserted.optimization_type,  
   inserted.purge_history_date,  
   inserted.pricing_classification_code,  
   inserted.source_type,  
   inserted.source_key,  
   inserted.linked_source_key,  
   inserted.original_container_key,  
   inserted.sold_to_key,  
   inserted.team_code,  
   inserted.next_iter_seq_no,  
   inserted.next_iter_date,  
   inserted.hrs_before_next_iter,  
   inserted.createuserid,  
   inserted.modifyuserid,  
   inserted.createprogid,  
   inserted.modifyprogid,  
   inserted.lockid,  
   inserted.department_code,  
   inserted.buyer_user_id,  
   inserted.recreate_authorizations,  
   inserted.customer_contact_id,  
   inserted.opportunity_key,  
   inserted.is_expiration_date_overridden,  
   inserted.expiration_date,  
   inserted.approval_cycle,  
   inserted.in_store_payment_required,  
   inserted.immediate_settlement_value,  
   inserted.customer_age,  
   inserted.cart_id,  
   inserted.rollout_version,  
   inserted.all_addresses_verified,  
   inserted.compl_gift_box_qty,  
   inserted.no_of_auth_strikes,  
   inserted.source_ip_address,  
   inserted.customer_first_name,  
   inserted.customer_last_name,  
   inserted.customer_phone_no,  
   inserted.customer_zip_code,  
   inserted.index_version,  
   inserted.extn_customer_type,  
   inserted.extn_customer_id,  
   inserted.extn_cba_ship_label,  
   inserted.extn_amazon_tfm,  
   inserted.extn_tfm_ship_status,  
   inserted.extn_financed_by_affirm,  
   inserted.extn_risk_status,  
   inserted.extn_sales_rep_cust_id,  
   inserted.extn_latest_ship_date,  
   inserted.extn_latest_delivery_date,  
   inserted.extn_market_place_id,  
   inserted.extn_order_status,  
   inserted.extn_is_prime,  
   inserted.extn_giftee_full_name,  
   inserted.extn_giftee_email_id,  
   inserted.extn_sms_opt_in,  
   inserted.extn_ga_tag_id,  
   inserted.extn_fraud_status,  
   inserted.extn_order_locale_code,  
   inserted.extn_shipto_firstname,  
   inserted.extn_shipto_lastname,  
   inserted.extn_shipto_zipcode,
   inserted.extn_return_confirmed_by,
   inserted.extn_edi_gcn,
   inserted.extn_pk_header_key,
   inserted.extn_merchant_id,
   inserted.extn_is_avalara,
   inserted.extn_req_cancel_date,
   inserted.extn_is_email_sent,
   inserted.extn_is_txn_committed,
   inserted.extn_tax_txn_date,
   inserted.extn_last_refund_txn_code,
   inserted.extn_refund_txn_code,
   inserted.extn_min_estimated_delivery_date,
   inserted.extn_max_estimated_delivery_date,
   inserted.extn_apply_migration_hold,
   inserted.extn_signifyd_order_id,
   inserted.extn_primary_reason,
   inserted.extn_secondary_reason,
   inserted.extn_sales_entry_type,
   inserted.extn_sales_order_type,
   inserted.extn_warranty_order_no,
   inserted.extn_seller_payment_type,
   inserted.createts,
   inserted.modifyts,
   1  as revision 
FROM ANALYTICS.EXT_ORDER_HEADER inserted 
WHERE inserted.inserted_date >= :processedDate OR inserted.modified_date >= :processedDate
;

CREATE OR REPLACE TEMPORARY TABLE TempAuditRevisions AS
SELECT  
    MAX(aot.revision) AS revision,  
    aot.order_header_key  
FROM  
    ANALYTICS.audit_ext_order_header AS aot  
    INNER JOIN TempExtOrderHeader AS ttd 
    ON ttd.order_header_key = aot.order_header_key  
GROUP BY  
    aot.order_header_key;

UPDATE TempExtOrderHeader ttd
SET ttd.Revision = NVL(aot.revision, 0) + 1
FROM TempAuditRevisions aot
WHERE ttd.order_header_key = aot.order_header_key;

DROP TABLE IF EXISTS TempAuditRevisions;

INSERT INTO ANALYTICS.audit_ext_order_header (
    order_header_key
    ,sourcing_classification
    ,buyer_organization_code
    ,seller_organization_code
    ,document_type
    ,bill_to_id
    ,customer_rewards_no
    ,vendor_id
    ,ship_to_id
    ,ship_node
    ,receiving_node
    ,buyer_receiving_node_id
    ,mark_for_key
    ,buyer_mark_for_node_id
    ,req_delivery_date
    ,req_cancel_date
    ,req_ship_date
    ,default_template
    ,division
    ,draft_order_flag
    ,order_purpose
    ,return_oh_key_for_exchange
    ,exchange_type
    ,pending_transfer_in
    ,return_by_gift_recipient
    ,allocation_rule_id
    ,priority_code
    ,priority_number
    ,contact_key
    ,scac
    ,carrier_service_code
    ,custcarrier_account_no
    ,notify_after_shipment_flag
    ,created_at_node
    ,has_derived_child
    ,has_derived_parent
    ,notification_type
    ,notification_reference
    ,entry_type
    ,authorized_client
    ,entered_by
    ,personalize_code
    ,hold_flag
    ,hold_reason_code
    ,customer_po_no
    ,customer_customer_po_no
    ,order_name
    ,payment_rule_id
    ,terms_code
    ,delivery_code
    ,charge_actual_freight
    ,original_tax
    ,currency
    ,enterprise_currency
    ,reporting_conversion_rate
    ,reporting_conversion_date
    ,payment_status
    ,authorization_expiration_date
    ,search_criteria_1
    ,search_criteria_2
    ,fob
    ,other_charges
    ,price_program_key
    ,taxpayer_id
    ,tax_jurisdiction
    ,tax_exemption_certificate
    ,purpose
    ,invoice_complete
    ,order_closed
    ,next_alert_ts
    ,do_not_consolidate
    ,chain_type
    ,adjustment_invoice_pending
    ,auto_cancel_date
    ,sale_voided
    ,is_ship_complete
    ,is_line_ship_complete
    ,is_ship_single_node
    ,is_line_ship_single_node
    ,cancel_order_on_excp_flag
    ,optimization_type
    ,purge_history_date
    ,pricing_classification_code
    ,source_type
    ,source_key
    ,linked_source_key
    ,original_container_key
    ,sold_to_key
    ,team_code
    ,next_iter_seq_no
    ,next_iter_date
    ,hrs_before_next_iter
    ,createuserid
    ,modifyuserid
    ,createprogid
    ,modifyprogid
    ,lockid
    ,department_code
    ,buyer_user_id
    ,recreate_authorizations
    ,customer_contact_id
    ,opportunity_key
    ,is_expiration_date_overridden
    ,expiration_date
    ,approval_cycle
    ,in_store_payment_required
    ,immediate_settlement_value
    ,customer_age
    ,cart_id
    ,rollout_version
    ,all_addresses_verified
    ,compl_gift_box_qty
    ,no_of_auth_strikes
    ,source_ip_address
    ,customer_first_name
    ,customer_last_name
    ,customer_phone_no
    ,customer_zip_code
    ,index_version
    ,extn_customer_type
    ,extn_customer_id
    ,extn_cba_ship_label
    ,extn_amazon_tfm
    ,extn_tfm_ship_status
    ,extn_financed_by_affirm
    ,extn_risk_status
    ,extn_sales_rep_cust_id
    ,extn_latest_ship_date
    ,extn_latest_delivery_date
    ,extn_market_place_id
    ,extn_order_status
    ,extn_is_prime
    ,extn_giftee_full_name
    ,extn_giftee_email_id
    ,extn_sms_opt_in
    ,extn_ga_tag_id
    ,extn_fraud_status
    ,extn_order_locale_code
    ,extn_shipto_firstname
    ,extn_shipto_lastname
    ,extn_shipto_zipcode
    ,extn_return_confirmed_by
    ,extn_edi_gcn
    ,extn_pk_header_key
    ,extn_merchant_id
    ,extn_is_avalara
    ,extn_req_cancel_date
    ,extn_is_email_sent
    ,extn_is_txn_committed
    ,extn_tax_txn_date
    ,extn_last_refund_txn_code
    ,extn_refund_txn_code
    ,extn_min_estimated_delivery_date
    ,extn_max_estimated_delivery_date
    ,extn_apply_migration_hold
    ,extn_signifyd_order_id
    ,extn_primary_reason
    ,extn_secondary_reason
    ,extn_sales_entry_type
    ,extn_sales_order_type
    ,extn_warranty_order_no
    ,extn_seller_payment_type
    ,createts
    ,modifyts
    ,inserted_date  -- Equivalent to GETDATE() in Snowflake
    ,Revision
)
SELECT
    stg.order_header_key
    ,stg.sourcing_classification
    ,stg.buyer_organization_code
    ,stg.seller_organization_code
    ,stg.document_type
    ,stg.bill_to_id
    ,stg.customer_rewards_no
    ,stg.vendor_id
    ,stg.ship_to_id
    ,stg.ship_node
    ,stg.receiving_node
    ,stg.buyer_receiving_node_id
    ,stg.mark_for_key
    ,stg.buyer_mark_for_node_id
    ,TRY_TO_TIMESTAMP(stg.req_delivery_date,''YYYYMMDDHHMISS'')
    ,TRY_TO_TIMESTAMP(stg.req_cancel_date,''YYYYMMDDHHMISS'')
    ,TRY_TO_TIMESTAMP(stg.req_ship_date,''YYYYMMDDHHMISS'')
    ,stg.default_template
    ,stg.division
    ,stg.draft_order_flag
    ,stg.order_purpose
    ,stg.return_oh_key_for_exchange
    ,stg.exchange_type
    ,stg.pending_transfer_in
    ,stg.return_by_gift_recipient
    ,stg.allocation_rule_id
    ,stg.priority_code
    ,stg.priority_number
    ,stg.contact_key
    ,stg.scac
    ,stg.carrier_service_code
    ,stg.custcarrier_account_no
    ,stg.notify_after_shipment_flag
    ,stg.created_at_node
    ,stg.has_derived_child
    ,stg.has_derived_parent
    ,stg.notification_type
    ,stg.notification_reference
    ,stg.entry_type
    ,stg.authorized_client
    ,stg.entered_by
    ,stg.personalize_code
    ,stg.hold_flag
    ,stg.hold_reason_code
    ,stg.customer_po_no
    ,stg.customer_customer_po_no
    ,stg.order_name
    ,stg.payment_rule_id
    ,stg.terms_code
    ,stg.delivery_code
    ,stg.charge_actual_freight
    ,stg.original_tax
    ,stg.currency
    ,stg.enterprise_currency
    ,stg.reporting_conversion_rate
    ,TRY_TO_TIMESTAMP(stg.reporting_conversion_date,''YYYYMMDDHHMISS'')
    ,stg.payment_status
    ,TRY_TO_TIMESTAMP(stg.authorization_expiration_date,''YYYYMMDDHHMISS'')
    ,stg.search_criteria_1
    ,stg.search_criteria_2
    ,stg.fob
    ,stg.other_charges
    ,stg.price_program_key
    ,stg.taxpayer_id
    ,stg.tax_jurisdiction
    ,stg.tax_exemption_certificate
    ,stg.purpose
    ,stg.invoice_complete
    ,stg.order_closed
    ,stg.next_alert_ts
    ,TRY_TO_TIMESTAMP(stg.do_not_consolidate,''YYYYMMDDHHMISS'')
    ,stg.chain_type
    ,stg.adjustment_invoice_pending
    ,TRY_TO_TIMESTAMP(stg.auto_cancel_date,''YYYYMMDDHHMISS'')
    ,stg.sale_voided
    ,stg.is_ship_complete
    ,stg.is_line_ship_complete
    ,stg.is_ship_single_node
    ,stg.is_line_ship_single_node
    ,stg.cancel_order_on_excp_flag
    ,stg.optimization_type
    ,TRY_TO_TIMESTAMP(stg.purge_history_date,''YYYYMMDDHHMISS'')
    ,stg.pricing_classification_code
    ,stg.source_type
    ,stg.source_key
    ,stg.linked_source_key
    ,stg.original_container_key
    ,stg.sold_to_key
    ,stg.team_code
    ,stg.next_iter_seq_no
    ,TRY_TO_TIMESTAMP(stg.next_iter_date,''YYYYMMDDHHMISS'')
    ,stg.hrs_before_next_iter
    ,stg.createuserid
    ,stg.modifyuserid
    ,stg.createprogid
    ,stg.modifyprogid
    ,stg.lockid
    ,stg.department_code
    ,stg.buyer_user_id
    ,stg.recreate_authorizations
    ,stg.customer_contact_id
    ,stg.opportunity_key
    ,stg.is_expiration_date_overridden
    ,TRY_TO_TIMESTAMP(stg.expiration_date,''YYYYMMDDHHMISS'')
    ,stg.approval_cycle
    ,stg.in_store_payment_required
    ,stg.immediate_settlement_value
    ,stg.customer_age
    ,stg.cart_id
    ,stg.rollout_version
    ,stg.all_addresses_verified
    ,stg.compl_gift_box_qty
    ,stg.no_of_auth_strikes
    ,stg.source_ip_address
    ,stg.customer_first_name
    ,stg.customer_last_name
    ,stg.customer_phone_no
    ,stg.customer_zip_code
    ,stg.index_version
    ,stg.extn_customer_type
    ,stg.extn_customer_id
    ,stg.extn_cba_ship_label
    ,stg.extn_amazon_tfm
    ,stg.extn_tfm_ship_status
    ,stg.extn_financed_by_affirm
    ,stg.extn_risk_status
    ,stg.extn_sales_rep_cust_id
    ,TRY_TO_TIMESTAMP(stg.extn_latest_ship_date,''YYYYMMDDHHMISS'')
    ,TRY_TO_TIMESTAMP(stg.extn_latest_delivery_date,''YYYYMMDDHHMISS'')
    ,stg.extn_market_place_id
    ,stg.extn_order_status
    ,stg.extn_is_prime
    ,stg.extn_giftee_full_name
    ,stg.extn_giftee_email_id
    ,stg.extn_sms_opt_in
    ,stg.extn_ga_tag_id
    ,stg.extn_fraud_status
    ,stg.extn_order_locale_code
    ,stg.extn_shipto_firstname
    ,stg.extn_shipto_lastname
    ,stg.extn_shipto_zipcode
    ,stg.extn_return_confirmed_by
    ,stg.extn_edi_gcn
    ,stg.extn_pk_header_key
    ,stg.extn_merchant_id
    ,stg.extn_is_avalara
    ,TRY_TO_TIMESTAMP(stg.extn_req_cancel_date,''YYYYMMDDHHMISS'')
    ,stg.extn_is_email_sent
    ,stg.extn_is_txn_committed
    ,TRY_TO_TIMESTAMP(stg.extn_tax_txn_date,''YYYYMMDDHHMISS'')
    ,stg.extn_last_refund_txn_code
    ,stg.extn_refund_txn_code
    ,TRY_TO_TIMESTAMP(stg.extn_min_estimated_delivery_date,''YYYYMMDDHHMISS'')
    ,TRY_TO_TIMESTAMP(stg.extn_max_estimated_delivery_date,''YYYYMMDDHHMISS'')
    ,stg.extn_apply_migration_hold
    ,stg.extn_signifyd_order_id
    ,stg.extn_primary_reason
    ,stg.extn_secondary_reason
    ,stg.extn_sales_entry_type
    ,stg.extn_sales_order_type
    ,stg.extn_warranty_order_no
    ,stg.extn_seller_payment_type
    ,TRY_TO_TIMESTAMP(stg.createts,''YYYYMMDDHHMISS'')
    ,TRY_TO_TIMESTAMP(stg.modifyts,''YYYYMMDDHHMISS'')
    ,CURRENT_TIMESTAMP()  -- Equivalent to GETDATE() in Snowflake
    ,ord.Revision
FROM TRANSFORMED.stg_order_header stg
INNER JOIN RAW.raw_order_header r
    ON r.order_header_key = stg.order_header_key
    AND r.modifyts = stg.modifyts
    AND r.processing_status = ''Processed''
INNER JOIN TempExtOrderHeader ord
    ON ord.order_header_key = stg.order_header_key;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);



DROP TABLE IF EXISTS TempExtOrderHeader;

RETURN ''Success'';
EXCEPTION 
WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
            
    RETURN sqlerrm;
END';