CREATE OR REPLACE PROCEDURE TRANSFORMED.USP_BIZ_VALIDATION_ORDER_LINE()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    OrderNoErrorMsg STRING;
    SourceRefErrorMsg STRING;
    OrderErrorMsg STRING;
    SkuErrorMsg STRING;
    SourceErrorMsg STRING;
    CurrencyErrorMsg STRING;
    CustomerErrorMsg STRING;
    ShippingMethodErrorMsg STRING;
    OrderStatusErrorMsg STRING;
    PaymentMethodErrorMsg STRING;
    OrderTypeErrorMsg STRING;
    EditSourceRefErrorMsg STRING;
    OrderLineErrorMsg STRING;
    OrderShipErrorMsg STRING;
    OrderItemErrorMsg STRING;
    message STRING;
    ErrorCount INT;
    StageErrorCount INT;
    DimErrorCount INT;
    TxnErrorCount INT;
    amendment_topic STRING;
    amendment_note STRING;
    OMSOrderCount INT;
    OMSErrorOrderCount INT;
  
    StagingRecordCount INT;
    FinalStatus STRING;
    DataValidationErrCount INT;
    OrderTypeCount INT;

BEGIN
SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_LINE has been Started'');
    CREATE OR REPLACE TEMPORARY TABLE DimResultToLog (
        orderheaderkey STRING,
        orderlinekey STRING,
        stgorderstatus STRING,
        orderstatusid STRING,
        stgitemid STRING,
        skuid STRING,
        txn_id STRING
    );

    CREATE OR REPLACE TEMPORARY TABLE ErrorResultToLog (
        orderheaderkey STRING,
        orderlinekey STRING,
        txn_id STRING,
        processing_errortype STRING,
        processing_status STRING,
        processing_comment STRING
    );

    CREATE OR REPLACE TEMPORARY TABLE TxnResultToLog (
        stgsourceref STRING,
        stgorderstaus STRING,
        stgjoinsourceref STRING,
        headsourceref STRING
    );

    FinalStatus := ''val_records'';

    SELECT COUNT(*) INTO OMSOrderCount FROM TRANSFORMED.STG_order_header;

    OrderNoErrorMsg := ''OrderNo for [ERRORSOURCE]   Header_Key is not found'';
    OrderLineErrorMsg := ''OrderLineKey for [ERRORSOURCE]   Line_Key is not found'';
    OrderShipErrorMsg := ''Ship_to_key for [ERRORSOURCE] Ship_to_Key is not found'';
    SourceErrorMsg := ''[ERRORITEM] for this brand and platform no source found'';
    CurrencyErrorMsg := ''Currency [ERRORITEM] not found'';
    CustomerErrorMsg := ''Customer [ERRORITEM] not found'';
    ShippingMethodErrorMsg := ''Shipping Method [ERRORITEM] not found'';
    OrderStatusErrorMsg := ''Order Line Status [ERRORITEM] not found'';
    OrderTypeErrorMsg := ''Order Type [ERRORITEM] not found'';
    EditSourceRefErrorMsg := ''SourceRefNum [ERRORITEM] have no records for modification'';
    OrderItemErrorMsg := ''ItemID [ERRORITEM] not found'';
    SourceRefErrorMsg := ''SourceRefNum [ERRORSOURCE] not found'';
    OrderErrorMsg := ''OrderId [ERRORORDERID] not found'';
    SkuErrorMsg := ''SKU [ERRORITEM] not found'';
    PaymentMethodErrorMsg := ''Payment Method [ERRORITEM] not found'';

    IF (OMSOrderCount > 0) THEN
        INSERT INTO DimResultToLog
        SELECT DISTINCT
            stg.ORDER_HEADER_KEY,
            stg.ORDER_LINE_KEY,
            stg.order_line_status,
            ordsts.pk_order_statusid,
            stg.ITEM_ID,
            dsl.pk_skuproductid,
            stg.txn_id
        FROM  TRANSFORMED.STG_order_line AS stg
        LEFT JOIN  master.dim_order_status AS ordsts ON ordsts.oms_order_status_code = stg.order_line_status
        LEFT JOIN analytics.txn_order_header AS toh ON toh.ext_order_id = stg.order_header_key AND toh.entry_type IS NOT NULL
        LEFT JOIN master.dim_source AS src ON src.pk_sourceid = toh.fk_sourceid
        LEFT JOIN ANALYTICS.sku_product_locale AS dsl ON dsl.sku_code = stg.ITEM_ID AND dsl.locale = src.locale;

        INSERT INTO ErrorResultToLog
        (orderheaderkey, orderlinekey, txn_id, processing_errortype, processing_status, processing_comment)
        SELECT DISTINCT
            rol.ORDER_HEADER_KEY,
            rol.ORDER_LINE_KEY,
            rol.txn_id,
            ''SKU'',
            ''Failed'',
            REPLACE(''ItemID [ERRORITEM] not found'', ''[ERRORITEM]'', rol.ITEM_ID)
        FROM RAW.RAW_order_line AS rol
        INNER JOIN DimResultToLog AS dst ON rol.ORDER_LINE_KEY = dst.orderlinekey AND rol.txn_id =      dst.txn_id
        WHERE dst.skuid IS NULL AND rol.processing_status IN (''Failed'', ''Pending'');


        -- Step 1: Create and populate the temporary table for aggregated error results
     CREATE or replace TEMPORARY TABLE temp_erlist AS
    SELECT 
        temp1.orderlinekey, 
        temp1.txn_id, 
        temp1.processing_status,  
       LISTAGG(temp2.processing_errortype, '','') AS errortype,
       LISTAGG(temp2.processing_comment, '','') AS comment
    FROM ErrorResultToLog temp1
    INNER JOIN ErrorResultToLog temp2 
        ON temp1.txn_id = temp2.txn_id 
        AND temp1.orderlinekey = temp2.orderlinekey
    WHERE temp1.processing_status IN (''Failed'')
    GROUP BY temp1.orderlinekey, temp1.txn_id, temp1.processing_status;
    
    -- Step 2: Create and populate the temporary table for rows to be updated
    CREATE or replace TEMPORARY TABLE temp_updated_rows AS
    SELECT 
        rol.ORDER_LINE_KEY, 
        erlist.errortype, 
        erlist.comment
    FROM RAW.RAW_order_line AS rol
    INNER JOIN temp_erlist AS erlist
        ON erlist.txn_id = rol.txn_id 
        AND erlist.orderlinekey = rol.ORDER_LINE_KEY
    WHERE rol.processing_status IN (''Failed'', ''Pending'');
    
    -- Step 3: Perform the update based on the temporary tables
    -- UPDATE RAW.RAW_order_line rol
    -- SET 
    --     processing_errortype = (
    --         SELECT errortype 
    --         FROM temp_updated_rows 
    --         WHERE temp_updated_rows.ORDER_LINE_KEY = rol.ORDER_LINE_KEY
    --     ),
    --     processing_comment = (
    --         SELECT comment 
    --         FROM temp_updated_rows 
    --         WHERE temp_updated_rows.ORDER_LINE_KEY = rol.ORDER_LINE_KEY
    --     ),
    --     processing_status = ''Failed''
    -- WHERE ORDER_LINE_KEY IN (SELECT ORDER_LINE_KEY FROM temp_updated_rows);
    MERGE INTO RAW.RAW_order_line AS rol
        USING (SELECT DISTINCT ORDER_LINE_KEY,errortype,comment FROM temp_updated_rows) AS temp
        ON rol.ORDER_LINE_KEY = temp.ORDER_LINE_KEY
        WHEN MATCHED THEN 
    UPDATE SET 
        rol.processing_errortype = temp.errortype,
        rol.processing_comment = temp.comment,
        rol.processing_status = ''Failed'';


-- Optional: Drop the temporary tables if no longer needed
    DROP TABLE IF EXISTS temp_erlist;
    DROP TABLE IF EXISTS temp_updated_rows;


        -- Use a CTE to identify the rows to update
    create or replace temp table tempupdated_rows as 
    WITH updated_rows AS (
        SELECT rol.ORDER_LINE_KEY
        FROM RAW.RAW_order_line AS rol
        INNER JOIN DimResultToLog AS dst 
            ON rol.txn_id = dst.txn_id 
            AND rol.ORDER_LINE_KEY = dst.orderlinekey
        WHERE 
            rol.ORDER_LINE_KEY IS NOT NULL 
            AND rol.ORDER_LINE_KEY != ''''
            AND rol.ORDER_HEADER_KEY IS NOT NULL 
            AND rol.ORDER_HEADER_KEY != '''' 
            AND rol.ITEM_ID IS NOT NULL 
            AND rol.ITEM_ID != '''' 
            AND rol.processing_status IN (''Failed'', ''Pending'')
    )
    select * from updated_rows;
    
    -- Perform the update based on the CTE results
    UPDATE RAW.RAW_order_line
    SET
        processing_errortype = '''',
        processing_comment = ''Ready For Processing''
    WHERE ORDER_LINE_KEY IN (SELECT distinct ORDER_LINE_KEY FROM tempupdated_rows);
    

        SELECT COUNT(*) INTO ErrorCount FROM RAW.RAW_order_line WHERE processing_status = ''Failed'';
        IF (ErrorCount > 0) THEN
            FinalStatus := ''er_records'';
        END IF;
    ELSE
        FinalStatus := ''no_records'';
    END IF;
    SYSTEM$LOG(''TRACE'','' USP_BIZ_VALIDATION_ORDER_LINE has been Completed'');

    RETURN FinalStatus;
    EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    SYSTEM$LOG(''ERROR'','' USP_BIZ_VALIDATION_ORDER_LINE has Failed'');
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';