CREATE OR REPLACE PROCEDURE PROD.ANALYTICS.USP_ORDER_STATUS_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    initialRevision NUMBER DEFAULT 1;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount
WHERE file_name = ''YFS_ORDER_RELEASE_STATUS'';

CREATE OR REPLACE TEMPORARY TABLE TempCreatedLineStatus (
    fk_order_headerid BIGINT NOT NULL,
    pk_order_detailid BIGINT NOT NULL,
    fk_order_detail_statusid INT NULL
);

CREATE OR REPLACE TEMPORARY TABLE TempLineStatus (
    fk_order_headerid BIGINT NOT NULL,
    pk_order_detailid BIGINT NOT NULL,
    fk_order_detail_statusid INT NULL,
    order_release_status_key VARCHAR NOT NULL
);

CREATE OR REPLACE TEMPORARY TABLE TempHeaderStatus (
    fk_order_headerid BIGINT NOT NULL,
    fk_order_statusid INT NULL
);

INSERT INTO TempHeaderStatus (
    fk_order_headerid,
    fk_order_statusid
)
SELECT 
    pk_order_headerid,
    max(pk_order_statusid) 
FROM 
     TRANSFORMED.stg_ORDER_header_status AS stg
INNER JOIN 
    RAW.raw_ORDER_header AS r ON r.ORDER_HEADER_KEY = stg.order_header_key
INNER JOIN 
    ANALYTICS.txn_order_header  AS toh ON toh.source_ref_num = r.ORDER_NO AND toh.ext_order_id = stg.order_header_key
    and to_timestamp(r.modifyts,''yyyymmddhhmiss'')= toh.modifyts
INNER JOIN 
      MASTER.DIM_ORDER_STATUS AS dods ON dods.OMS_ORDER_status_code = stg.status
      group by all;

MERGE INTO ANALYTICS.txn_order_status AS tgt
USING (
  SELECT DISTINCT
    fk_order_headerid,
    fk_order_statusid
  FROM
    TempHeaderStatus AS stg
) AS src
ON src.fk_order_headerid = tgt.fk_order_headerid
-- WHEN NOT MATCHED THEN
--   INSERT (
--     fk_order_headerid,
--     fk_order_statusid,
--     inserted_date,
--     modified_date
--   )
--   VALUES (
--     src.fk_order_headerid,
--     src.fk_order_statusid,
--     CURRENT_TIMESTAMP(),
--     CURRENT_TIMESTAMP()
--   )
WHEN MATCHED THEN
  UPDATE SET
    tgt.fk_order_statusid = src.fk_order_statusid,
    tgt.modified_date = CURRENT_TIMESTAMP();

INSERT INTO TempLineStatus (
    fk_order_headerid,
    pk_order_detailid,
    fk_order_detail_statusid,
    order_release_status_key
)
SELECT DISTINCT 
    pk_order_headerid,
    tod.pk_order_detailid,
    max(pk_order_statusid),
    max(stg.order_release_status_key)
FROM  TRANSFORMED.stg_ORDER_line_status AS stg
INNER JOIN RAW.raw_ORDER_header AS r ON r.ORDER_HEADER_KEY = stg.order_header_key
INNER JOIN ANALYTICS.txn_order_header AS toh ON toh.source_ref_num = r.ORDER_NO AND toh.ext_order_id = stg.order_header_key
INNER JOIN ANALYTICS.txn_order_detail AS tod ON tod.fk_order_headerid = toh.pk_order_headerid AND tod.ext_line_id = stg.order_line_key
INNER JOIN MASTER.DIM_ORDER_STATUS AS dods ON dods.OMS_ORDER_status_code = stg.status
group by all;

MERGE INTO ANALYTICS.txn_order_detail_status AS Target
USING (
    SELECT DISTINCT
        fk_order_headerid,
        pk_order_detailid,
        fk_order_detail_statusid,
        order_release_status_key
    FROM TempLineStatus AS stg
) AS Source
ON Source.fk_order_headerid = Target.pk_order_headerid
AND Source.pk_order_detailid = Target.pk_order_detailid
WHEN MATCHED THEN
    UPDATE SET
        Target.fk_order__detail_statusid = Source.fk_order_detail_statusid
WHEN NOT MATCHED THEN
    INSERT (
        pk_order_headerid,
        pk_order_detailid,
        fk_order__detail_statusid
    )
    VALUES (
        Source.fk_order_headerid,
        Source.pk_order_detailid,
        Source.fk_order_detail_statusid
    );

INSERT INTO TempCreatedLineStatus(
    fk_order_headerid,
    pk_order_detailid,
    fk_order_detail_statusid
)
SELECT pk_order_headerid,
        pk_order_detailid,
        fk_order__detail_statusid
FROM ANALYTICS.txn_order_detail_status
;

UPDATE RAW.raw_ORDER_release_status
SET 
    processing_status = ''Processed'',
    processing_comment = '''',
    processing_errortype = ''''
WHERE 
    processing_status IN (''Pending'', ''Failed'')
    AND EXISTS (
        SELECT 1
        FROM TRANSFORMED.stg_ORDER_line_status AS rod
        INNER JOIN TempLineStatus AS tol 
            ON tol.order_release_status_key = rod.ORDER_RELEASE_STATUS_KEY
        INNER JOIN TempCreatedLineStatus AS tod 
            ON tod.pk_order_detailid = tol.pk_order_detailid
            AND tod.fk_order_headerid = tol.fk_order_headerid
        WHERE rod.ORDER_RELEASE_STATUS_KEY = RAW.raw_ORDER_release_status.ORDER_RELEASE_STATUS_KEY
          AND rod.txn_id = RAW.raw_ORDER_release_status.txn_id
    );


SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM TRANSFORMED.stg_ORDER_line_status;

SELECT COUNT(*) INTO :processedRecordCount FROM TempCreatedLineStatus;

UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount,
    status = ''Success''
WHERE file_name = ''YFS_ORDER_RELEASE_STATUS'';

DROP TABLE IF EXISTS TempCreatedLineStatus;
DROP TABLE IF EXISTS TempHeaderStatus;
DROP TABLE IF EXISTS TempLineStatus;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

COMMIT;
    
RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

        error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
    
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';