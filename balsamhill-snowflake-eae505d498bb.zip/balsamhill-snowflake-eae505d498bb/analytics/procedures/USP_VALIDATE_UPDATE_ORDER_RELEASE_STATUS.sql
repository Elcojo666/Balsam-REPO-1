USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_VALIDATE_UPDATE_ORDER_RELEASE_STATUS()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1300'' WHERE STATUS = ''1300.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1500'' WHERE STATUS = ''1500.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3700.300'' WHERE STATUS = ''3700.3'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1100'' WHERE STATUS = ''1100.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''_1500'' WHERE STATUS = ''_1500.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3200'' WHERE STATUS = ''3200.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3700'' WHERE STATUS = ''3700.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3350'' WHERE STATUS = ''3350.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''9000'' WHERE STATUS = ''9000.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1400'' WHERE STATUS = ''1400.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''_1400'' WHERE STATUS = ''_1400.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3950'' WHERE STATUS = ''3950.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''3350'' WHERE STATUS = ''3350.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''_3350'' WHERE STATUS = ''_3350.0'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1300.100'' WHERE STATUS = ''1300.1'';
UPDATE raw.raw_ORDER_release_status SET STATUS = ''1310'' WHERE STATUS = ''1310.0'';

UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1300'' WHERE STATUS = ''1300.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1500'' WHERE STATUS = ''1500.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3700.300'' WHERE STATUS = ''3700.3'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1100'' WHERE STATUS = ''1100.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''_1500'' WHERE STATUS = ''_1500.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3200'' WHERE STATUS = ''3200.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3700'' WHERE STATUS = ''3700.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3350'' WHERE STATUS = ''3350.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''9000'' WHERE STATUS = ''9000.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1400'' WHERE STATUS = ''1400.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''_1400'' WHERE STATUS = ''_1400.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3950'' WHERE STATUS = ''3950.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''3350'' WHERE STATUS = ''3350.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''_3350'' WHERE STATUS = ''_3350.0'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1300.100'' WHERE STATUS = ''1300.1'';
UPDATE raw.raw_ORDER_release_status_part2 SET STATUS = ''1310'' WHERE STATUS = ''1310.0'';

UPDATE raw.raw_ORDER_header SET order_status = ''1300'' WHERE order_status = ''1300.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''1500'' WHERE order_status = ''1500.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3700.300'' WHERE order_status = ''3700.3'';
UPDATE raw.raw_ORDER_header SET order_status = ''1100'' WHERE order_status = ''1100.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''_1500'' WHERE order_status = ''_1500.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3200'' WHERE order_status = ''3200.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3700'' WHERE order_status = ''3700.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3350'' WHERE order_status = ''3350.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''9000'' WHERE order_status = ''9000.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''1400'' WHERE order_status = ''1400.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''_1400'' WHERE order_status = ''_1400.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3950'' WHERE order_status = ''3950.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''3350'' WHERE order_status = ''3350.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''_3350'' WHERE order_status = ''_3350.0'';
UPDATE raw.raw_ORDER_header SET order_status = ''1300.100'' WHERE order_status = ''1300.1'';
UPDATE raw.raw_ORDER_header SET order_status = ''1310'' WHERE order_status = ''1310.0'';

 RETURN ''Success'';
END';
