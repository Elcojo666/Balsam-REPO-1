

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_EXT_PAYMENT_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE 
    processedDate TIMESTAMP_NTZ(9);
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

CREATE OR REPLACE TEMPORARY TABLE TempExtPayment (
    ext_paymentid VARCHAR(16777216),
    order_header_key VARCHAR(16777216),
    payment_type VARCHAR(16777216),
    bill_to_key VARCHAR(16777216),
    charge_sequence VARCHAR(16777216),
    customer_account_no VARCHAR(16777216),
    display_cust_acct_no VARCHAR(16777216),
    customer_po_no VARCHAR(16777216),
    credit_card_type VARCHAR(16777216),
    credit_card_name VARCHAR(16777216),
    first_name VARCHAR(16777216),
    middle_name VARCHAR(16777216),
    last_name VARCHAR(16777216),
    credit_card_no VARCHAR(16777216),
    display_credit_card_no VARCHAR(16777216),
    credit_card_exp_date varchar,
    svc_no VARCHAR(16777216),
    display_svc_no VARCHAR(16777216),
    debit_card_no VARCHAR(16777216),
    display_debit_card_no VARCHAR(16777216),
    payment_reference1 VARCHAR(16777216),
    payment_reference2 VARCHAR(16777216),
    payment_reference3 VARCHAR(16777216),
    display_payment_ref1 VARCHAR(16777216),
    cheque_no VARCHAR(16777216),
    cheque_reference VARCHAR(16777216),
    extended_flag VARCHAR(16777216),
    pay_method_override VARCHAR(16777216),
    max_charge_limit VARCHAR(16777216),
    total_authorized float,
    total_charged float,
    requested_auth_amount float,
    requested_charge_amount float,
    requested_refund_amount float,
    total_refunded_amount float,
    total_alt_refunded_amount float,
    incomplete_payment_type VARCHAR(16777216),
    suspend_any_more_charges VARCHAR(16777216),
    suspend_exp_auth_reversal VARCHAR(16777216),
    planned_refund_amount float,
    unlimited_charges VARCHAR(16777216),
    cash_back_amount float,
    payment_reference4 VARCHAR(16777216),
    payment_reference5 VARCHAR(16777216),
    payment_reference6 VARCHAR(16777216),
    payment_reference7 VARCHAR(16777216),
    payment_reference8 VARCHAR(16777216),
    payment_reference9 VARCHAR(16777216),
    reason_code VARCHAR(16777216),
    createts TIMESTAMP,
    modifyts TIMESTAMP,
    createuserid VARCHAR(16777216),
    modifyuserid VARCHAR(16777216),
    createprogid VARCHAR(16777216),
    modifyprogid VARCHAR(16777216),
    lockid VARCHAR(16777216),
    last_updated_date TIMESTAMP,
    revision INT NOT NULL
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.EXT_PAYMENT tgt
USING (
    SELECT DISTINCT 
        stg.payment_key,
        stg.order_header_key,
        stg.payment_type,
        stg.bill_to_key,
        stg.charge_sequence,
        stg.customer_account_no,
        stg.display_cust_acct_no,
        stg.customer_po_no,
        stg.credit_card_type,
        stg.credit_card_name,
        stg.first_name,
        stg.middle_name,
        stg.last_name,
        stg.credit_card_no,
        stg.display_credit_card_no,
        stg.credit_card_exp_date,
        stg.svc_no,
        stg.display_svc_no,
        stg.debit_card_no,
        stg.display_debit_card_no,
        stg.payment_reference1,
        stg.payment_reference2,
        stg.payment_reference3,
        stg.display_payment_ref1,
        stg.cheque_no,
        stg.cheque_reference,
        stg.extended_flag,
        stg.pay_method_override,
        stg.max_charge_limit,
        TRY_CAST(stg.total_authorized AS FLOAT) as total_authorized,
        TRY_CAST(stg.total_charged AS FLOAT) as total_charged,
        TRY_CAST(stg.requested_auth_amount AS FLOAT) as requested_auth_amount,
        TRY_CAST(stg.requested_charge_amount AS FLOAT) as requested_charge_amount,
        TRY_CAST(stg.requested_refund_amount AS FLOAT) as requested_refund_amount,
        TRY_CAST(stg.total_refunded_amount AS FLOAT) as total_refunded_amount,
        TRY_CAST(stg.total_alt_refunded_amount AS FLOAT) as total_alt_refunded_amount,
        stg.incomplete_payment_type,
        stg.suspend_any_more_charges,
        stg.suspend_exp_auth_reversal,
        TRY_CAST(stg.planned_refund_amount AS FLOAT) as planned_refund_amount,
        stg.unlimited_charges,
        TRY_CAST(stg.cash_back_amount AS FLOAT) as cash_back_amount,
        stg.payment_reference4,
        stg.payment_reference5,
        stg.payment_reference6,
        stg.payment_reference7,
        stg.payment_reference8,
        stg.payment_reference9,
        stg.reason_code,
         TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS') as createts,
         TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS') as modifyts,
        stg.createuserid,
        stg.modifyuserid,
        stg.createprogid,
        stg.modifyprogid,
        stg.lockid
    FROM TRANSFORMED.STG_ORDER_PAYMENT stg
    INNER JOIN RAW.RAW_ORDER_PAYMENT r
        ON stg.payment_key = r.payment_key 
        AND stg.modifyts = r.modifyts 
        AND r.processing_status = 'Processed'
) src
ON tgt.ext_paymentid = src.payment_key
WHEN MATCHED THEN
    UPDATE SET
        tgt.ext_paymentid = src.payment_key,
        tgt.order_header_key = src.order_header_key,
        tgt.payment_type = src.payment_type,
        tgt.bill_to_key = src.bill_to_key,
        tgt.charge_sequence = src.charge_sequence,
        tgt.customer_account_no = src.customer_account_no,
        tgt.display_cust_acct_no = src.display_cust_acct_no,
        tgt.customer_po_no = src.customer_po_no,
        tgt.credit_card_type = src.credit_card_type,
        tgt.credit_card_name = src.credit_card_name,
        tgt.first_name = src.first_name,
        tgt.middle_name = src.middle_name,
        tgt.last_name = src.last_name,
        tgt.credit_card_no = src.credit_card_no,
        tgt.display_credit_card_no = src.display_credit_card_no,
        tgt.credit_card_exp_date = src.credit_card_exp_date,
        tgt.svc_no = src.svc_no,
        tgt.display_svc_no = src.display_svc_no,
        tgt.debit_card_no = src.debit_card_no,
        tgt.display_debit_card_no = src.display_debit_card_no,
        tgt.payment_reference1 = src.payment_reference1,
        tgt.payment_reference2 = src.payment_reference2,
        tgt.payment_reference3 = src.payment_reference3,
        tgt.display_payment_ref1 = src.display_payment_ref1,
        tgt.cheque_no = src.cheque_no,
        tgt.cheque_reference = src.cheque_reference,
        tgt.extended_flag = src.extended_flag,
        tgt.pay_method_override = src.pay_method_override,
        tgt.max_charge_limit = src.max_charge_limit,
        tgt.total_authorized = src.total_authorized,
        tgt.total_charged = src.total_charged,
        tgt.requested_auth_amount = src.requested_auth_amount,
        tgt.requested_charge_amount = src.requested_charge_amount,
        tgt.requested_refund_amount = src.requested_refund_amount,
        tgt.total_refunded_amount = src.total_refunded_amount,
        tgt.total_alt_refunded_amount = src.total_alt_refunded_amount,
        tgt.incomplete_payment_type = src.incomplete_payment_type,
        tgt.suspend_any_more_charges = src.suspend_any_more_charges,
        tgt.suspend_exp_auth_reversal = src.suspend_exp_auth_reversal,
        tgt.planned_refund_amount = src.planned_refund_amount,
        tgt.unlimited_charges = src.unlimited_charges,
        tgt.cash_back_amount = src.cash_back_amount,
        tgt.payment_reference4 = src.payment_reference4,
        tgt.payment_reference5 = src.payment_reference5,
        tgt.payment_reference6 = src.payment_reference6,
        tgt.payment_reference7 = src.payment_reference7,
        tgt.payment_reference8 = src.payment_reference8,
        tgt.payment_reference9 = src.payment_reference9,
        tgt.reason_code = src.reason_code,
        tgt.createts = src.createts,
        tgt.modifyts = src.modifyts,
        tgt.createuserid = src.createuserid,
        tgt.modifyuserid = src.modifyuserid,
        tgt.createprogid = src.createprogid,
        tgt.modifyprogid = src.modifyprogid,
        tgt.lockid = src.lockid,
        tgt.last_updated_date = :processedDate
WHEN NOT MATCHED THEN
    INSERT (
        ext_paymentid, order_header_key, payment_type, bill_to_key, charge_sequence, 
        customer_account_no, display_cust_acct_no, customer_po_no, credit_card_type, 
        credit_card_name, first_name, middle_name, last_name, credit_card_no, 
        display_credit_card_no, credit_card_exp_date, svc_no, display_svc_no, 
        debit_card_no, display_debit_card_no, payment_reference1, payment_reference2, 
        payment_reference3, display_payment_ref1, cheque_no, cheque_reference, 
        extended_flag, pay_method_override, max_charge_limit, total_authorized, 
        total_charged, requested_auth_amount, requested_charge_amount, 
        requested_refund_amount, total_refunded_amount, total_alt_refunded_amount, 
        incomplete_payment_type, suspend_any_more_charges, suspend_exp_auth_reversal, 
        planned_refund_amount, unlimited_charges, cash_back_amount, payment_reference4, 
        payment_reference5, payment_reference6, payment_reference7, payment_reference8, 
        payment_reference9, reason_code, createts, modifyts, createuserid, modifyuserid, 
        createprogid, modifyprogid, lockid, last_updated_date
    ) 
    VALUES (
        src.payment_key, src.order_header_key, src.payment_type, src.bill_to_key, 
        src.charge_sequence, src.customer_account_no, src.display_cust_acct_no, 
        src.customer_po_no, src.credit_card_type, src.credit_card_name, src.first_name, 
        src.middle_name, src.last_name, src.credit_card_no, src.display_credit_card_no, 
        src.credit_card_exp_date, src.svc_no, src.display_svc_no, src.debit_card_no, 
        src.display_debit_card_no, src.payment_reference1, src.payment_reference2, 
        src.payment_reference3, src.display_payment_ref1, src.cheque_no, src.cheque_reference, 
        src.extended_flag, src.pay_method_override, src.max_charge_limit, src.total_authorized, 
        src.total_charged, src.requested_auth_amount, src.requested_charge_amount, 
        src.requested_refund_amount, src.total_refunded_amount, src.total_alt_refunded_amount, 
        src.incomplete_payment_type, src.suspend_any_more_charges, 
        src.suspend_exp_auth_reversal, src.planned_refund_amount, src.unlimited_charges, 
        src.cash_back_amount, src.payment_reference4, src.payment_reference5, 
        src.payment_reference6, src.payment_reference7, src.payment_reference8, 
        src.payment_reference9, src.reason_code, src.createts, src.modifyts, src.createuserid, 
        src.modifyuserid, src.createprogid, src.modifyprogid, src.lockid, :processedDate
    );

INSERT INTO  TempExtPayment(
    ext_paymentid,
    order_header_key,
    payment_type,
    bill_to_key,
    charge_sequence,
    customer_account_no,
    display_cust_acct_no,
    customer_po_no,
    credit_card_type,
    credit_card_name,
    first_name,
    middle_name,
    last_name,
    credit_card_no,
    display_credit_card_no,
    credit_card_exp_date,
    svc_no,
    display_svc_no,
    debit_card_no,
    display_debit_card_no,
    payment_reference1,
    payment_reference2,
    payment_reference3,
    display_payment_ref1,
    cheque_no,
    cheque_reference,
    extended_flag,
    pay_method_override,
    max_charge_limit,
    total_authorized,
    total_charged,
    requested_auth_amount,
    requested_charge_amount,
    requested_refund_amount,
    total_refunded_amount,
    total_alt_refunded_amount,
    incomplete_payment_type,
    suspend_any_more_charges,
    suspend_exp_auth_reversal,
    planned_refund_amount,
    unlimited_charges,
    cash_back_amount,
    payment_reference4,
    payment_reference5,
    payment_reference6,
    payment_reference7,
    payment_reference8,
    payment_reference9,
    reason_code,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    last_updated_date,
    revision
)
SELECT 
    stg.payment_key AS ext_paymentid,
    stg.order_header_key,
    stg.payment_type,
    stg.bill_to_key,
    stg.charge_sequence,
    stg.customer_account_no,
    stg.display_cust_acct_no,
    stg.customer_po_no,
    stg.credit_card_type,
    stg.credit_card_name,
    stg.first_name,
    stg.middle_name,
    stg.last_name,
    stg.credit_card_no,
    stg.display_credit_card_no,
    stg.credit_card_exp_date,
    stg.svc_no,
    stg.display_svc_no,
    stg.debit_card_no,
    stg.display_debit_card_no,
    stg.payment_reference1,
    stg.payment_reference2,
    stg.payment_reference3,
    stg.display_payment_ref1,
    stg.cheque_no,
    stg.cheque_reference,
    stg.extended_flag,
    stg.pay_method_override,
    stg.max_charge_limit,
    stg.total_authorized,
    stg.total_charged,
    stg.requested_auth_amount,
    stg.requested_charge_amount,
    stg.requested_refund_amount,
    stg.total_refunded_amount,
    stg.total_alt_refunded_amount,
    stg.incomplete_payment_type,
    stg.suspend_any_more_charges,
    stg.suspend_exp_auth_reversal,
    stg.planned_refund_amount,
    stg.unlimited_charges,
    stg.cash_back_amount,
    stg.payment_reference4,
    stg.payment_reference5,
    stg.payment_reference6,
    stg.payment_reference7,
    stg.payment_reference8,
    stg.payment_reference9,
    stg.reason_code,
    stg.createts,
    stg.modifyts,
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    :processedDate,
    1 AS revision
FROM 
    TRANSFORMED.STG_ORDER_PAYMENT stg
    INNER JOIN RAW.RAW_ORDER_PAYMENT r 
        ON stg.payment_key = r.payment_key
        AND stg.modifyts = r.modifyts
WHERE
    r.processing_status = 'Processed';

CREATE OR REPLACE TEMPORARY TABLE TempExtPaymentRevision AS
SELECT
    MAX(aot.revision) AS revision,
    aot.ext_paymentid
FROM
    ANALYTICS.AUDIT_EXT_PAYMENT aot
INNER JOIN TempExtPayment ttd
    ON ttd.ext_paymentid = aot.ext_paymentid
GROUP BY
    aot.ext_paymentid;
   
UPDATE TempExtPayment ttd
SET ttd.Revision = COALESCE(aot.revision, 0) + 1
FROM TempExtPaymentRevision aot
WHERE ttd.ext_paymentid = aot.ext_paymentid;

INSERT INTO ANALYTICS.audit_ext_payment
(
    ext_paymentid,
    order_header_key,
    payment_type,
    bill_to_key,
    charge_sequence,
    customer_account_no,
    display_cust_acct_no,
    customer_po_no,
    credit_card_type,
    credit_card_name,
    first_name,
    middle_name,
    last_name,
    credit_card_no,
    display_credit_card_no,
    credit_card_exp_date,
    svc_no,
    display_svc_no,
    debit_card_no,
    display_debit_card_no,
    payment_reference1,
    payment_reference2,
    payment_reference3,
    display_payment_ref1,
    cheque_no,
    cheque_reference,
    extended_flag,
    pay_method_override,
    max_charge_limit,
    total_authorized,
    total_charged,
    requested_auth_amount,
    requested_charge_amount,
    requested_refund_amount,
    total_refunded_amount,
    total_alt_refunded_amount,
    incomplete_payment_type,
    suspend_any_more_charges,
    suspend_exp_auth_reversal,
    planned_refund_amount,
    unlimited_charges,
    cash_back_amount,
    payment_reference4,
    payment_reference5,
    payment_reference6,
    payment_reference7,
    payment_reference8,
    payment_reference9,
    reason_code,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    last_updated_date,
    revision
)
SELECT
    stg.payment_key,
    stg.order_header_key,
    stg.payment_type,
    stg.bill_to_key,
    stg.charge_sequence,
    stg.customer_account_no,
    stg.display_cust_acct_no,
    stg.customer_po_no,
    stg.credit_card_type,
    stg.credit_card_name,
    stg.first_name,
    stg.middle_name,
    stg.last_name,
    stg.credit_card_no,
    stg.display_credit_card_no,
    stg.credit_card_exp_date,
    stg.svc_no,
    stg.display_svc_no,
    stg.debit_card_no,
    stg.display_debit_card_no,
    stg.payment_reference1,
    stg.payment_reference2,
    stg.payment_reference3,
    stg.display_payment_ref1,
    stg.cheque_no,
    stg.cheque_reference,
    stg.extended_flag,
    stg.pay_method_override,
    stg.max_charge_limit,
    TRY_CAST(stg.total_authorized AS FLOAT) as total_authorized,
    TRY_CAST(stg.total_charged AS FLOAT) as total_charged,
    TRY_CAST(stg.requested_auth_amount AS FLOAT) as requested_auth_amount,
    TRY_CAST(stg.requested_charge_amount AS FLOAT) as requested_charge_amount,
    TRY_CAST(stg.requested_refund_amount AS FLOAT) as requested_refund_amount,
    TRY_CAST(stg.total_refunded_amount AS FLOAT) as total_refunded_amount,
    TRY_CAST(stg.total_alt_refunded_amount AS FLOAT) as total_alt_refunded_amount,
    stg.incomplete_payment_type,
    stg.suspend_any_more_charges,
    stg.suspend_exp_auth_reversal,
    TRY_CAST(stg.planned_refund_amount AS FLOAT) as planned_refund_amount, 
    stg.unlimited_charges,
    TRY_CAST(stg.cash_back_amount AS FLOAT) as cash_back_amount,
    stg.payment_reference4,
    stg.payment_reference5,
    stg.payment_reference6,
    stg.payment_reference7,
    stg.payment_reference8,
    stg.payment_reference9,
    stg.reason_code,
    TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS'),
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    :processedDate, -- Replaces GETDATE() in SQL Server
    ord.revision
FROM
    TRANSFORMED.STG_ORDER_PAYMENT stg
INNER JOIN
    RAW.RAW_ORDER_PAYMENT r
    ON stg.payment_key = r.payment_key
    AND stg.modifyts = r.modifyts
    AND processing_status = 'Processed'
INNER JOIN
    TempExtPayment ord 
    ON ord.ext_paymentid = stg.payment_key;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

RETURN 'Success';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;

        error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
    
    RETURN OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
END;