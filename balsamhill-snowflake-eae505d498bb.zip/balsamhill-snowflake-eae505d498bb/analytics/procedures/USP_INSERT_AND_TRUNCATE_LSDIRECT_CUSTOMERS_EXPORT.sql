CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.USP_INSERT_AND_TRUNCATE_LSDIRECT_CUSTOMERS_EXPORT("LAST_MODIFIED_DATE" TIMESTAMP_NTZ(9) DEFAULT NULL, "NEW_MODIFIED_DATE" TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP) COPY GRANTS 
RETURNS STRING 
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
    v_last_modified_date TIMESTAMP_NTZ;
BEGIN
    -- Get the max UpdatedDate if LAST_MODIFIED_DATE is null
    IF (LAST_MODIFIED_DATE IS NULL) THEN
        SELECT MAX(order_date)
        INTO :v_last_modified_date
        FROM ANALYTICS.LSDIRECT_CUSTOMERS_EXPORT;
    ELSE
        v_last_modified_date := LAST_MODIFIED_DATE- INTERVAL '1 MILLISECOND';
    END IF;

    -- Truncate the table
    TRUNCATE TABLE ANALYTICS.LSDIRECT_CUSTOMERS_EXPORT;

    INSERT INTO ANALYTICS.LSDIRECT_CUSTOMERS_EXPORT (
        CustomerID,
        ShipFirstName,
        ShipLastName,
        ShipAddress1,
        ShipAddress2,
        ShipCity,
        ShipState,
        ShipPostalCode,
        BillingFirstName,
        BillingLastName,
        BillingAddress1,
        BillingAddress2,
        BillingCity,
        BillingState,
        BillingPostalCode,
        EmailAddress,
        PhoneNumber,
        order_date         
    ) 
    SELECT DISTINCT
        toh.fk_customerid AS CustomerID,
        shipaddr.first_name AS ShipFirstName,
        shipaddr.last_name AS ShipLastName,
        shipaddr.address1 AS ShipAddress1,
        shipaddr.address2 AS ShipAddress2,
        shipaddr.city AS ShipCity,
        shipaddr.state AS ShipState,
        shipaddr.postal_code AS ShipPostalCode,
        billaddr.first_name AS BillingFirstName,
        billaddr.last_name AS BillingLastName,
        billaddr.address1 AS BillingAddress1,
        billaddr.address2 AS BillingAddress2,
        billaddr.city AS BillingCity,
        billaddr.state AS BillingState,
        billaddr.postal_code AS BillingPostalCode,
        toh.email_address AS EmailAddress,
        dci.phone3_e164 AS PhoneNumber,
        MAX(toh.inserted_date) AS ORDER_DATE 
    FROM PROD_EXTRACT.ANALYTICS.txn_order_header toh
    JOIN PROD_EXTRACT.MASTER.dim_source ds ON toh.fk_sourceid = ds.pk_sourceid
    JOIN PROD_EXTRACT.ANALYTICS.txn_address billaddr ON billaddr.pk_addressid = toh.fk_billing_addressid
    JOIN PROD_EXTRACT.ANALYTICS.txn_address shipaddr ON shipaddr.pk_addressid = toh.fk_shipping_addressid
    JOIN PROD_EXTRACT.MASTER.dim_brand db ON ds.fk_brandID = db.pk_brandID
    JOIN PROD_EXTRACT.ANALYTICS.CUSTOMER_INFO dci ON toh.fk_customerid = dci.fk_customerid
    WHERE db.BrandCodeForPOTracker = 'BHUS'
        AND toh.inserted_date > COALESCE(:v_last_modified_date, CURRENT_TIMESTAMP() - INTERVAL '25 HOURS') 
        AND toh.inserted_date <= COALESCE(:NEW_MODIFIED_DATE, CURRENT_TIMESTAMP() - INTERVAL '1 HOUR')
    GROUP BY ALL 
    ;

    -- Return info for debugging/logging if desired
    RETURN 'Table Updated. Every record Updated After LAST_MODIFIED_DATE: ' || COALESCE(TO_VARCHAR(:v_last_modified_date), TO_VARCHAR(CURRENT_TIMESTAMP() - INTERVAL '25 HOURS')) || ' and Before NEW_MODIFIED_DATE: ' || TO_VARCHAR(COALESCE(:NEW_MODIFIED_DATE, CURRENT_TIMESTAMP() - INTERVAL '1 HOUR'));
END;
$$
;
