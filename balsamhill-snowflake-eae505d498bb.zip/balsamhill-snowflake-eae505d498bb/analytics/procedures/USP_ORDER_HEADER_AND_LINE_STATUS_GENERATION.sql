USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_HEADER_AND_LINE_STATUS_GENERATION()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN 

CREATE OR REPLACE TEMPORARY TABLE DimInventoryErrorToLog (
    input STRING, 
    message STRING, 
    snapshotId STRING, 
    productID STRING
);

CREATE OR REPLACE TEMPORARY TABLE TempAPI_ORDER_line_status (
    order_release_status_key STRING NOT NULL, 
    order_line_key STRING NOT NULL, 
    order_header_key STRING NOT NULL, 
    status_quantity INT, 
    total_quantity INT, 
    status STRING(254),
    priority INT NOT NULL,
    txn_id STRING NOT NULL
);

CREATE OR REPLACE TEMPORARY TABLE TempAPI_ORDER_header_status (
    order_header_key STRING NOT NULL, 
    status_quantity INT, 
    total_quantity INT, 
    status STRING(254),
    header_priority INT NOT NULL,
    txn_id STRING NOT NULL
);

INSERT INTO TempAPI_ORDER_line_status (
    order_release_status_key,
    order_line_key,
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    priority,
    txn_id
)
SELECT
    order_release_status_key,
    order_line_key,
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    priority,
    txn_id
FROM (
    SELECT 
        order_release_status_key,
        order_header_key,
        order_line_key,
        status_quantity,
        total_quantity,
        status,
        txn_id,
        ROW_NUMBER() OVER (PARTITION BY txn_id, order_line_key ORDER BY TO_NUMBER(COALESCE(order_release_status_key, ''0'')) DESC) AS priority
    FROM BALSAM_EDW_DEV.RAW.raw_ORDER_release_status
    WHERE status_quantity > 0 AND processing_status IN (''Pending'', ''Failed'')
) AS processed
WHERE priority = 1;

UPDATE BALSAM_EDW_DEV.RAW.raw_ORDER_line
SET order_line_status = LTRIM(RTRIM(COALESCE(ls.status, '''')))
FROM (
    SELECT 
        MAX(order_release_status_key) AS order_release_status_key,
        order_line_key,
        order_header_key,
        status,
        txn_id
    FROM TempAPI_ORDER_line_status
    GROUP BY order_line_key, order_header_key, status, txn_id
) AS ls
WHERE ls.order_header_key = BALSAM_EDW_DEV.RAW.raw_ORDER_line.ORDER_HEADER_KEY
  AND ls.order_line_key = BALSAM_EDW_DEV.RAW.raw_ORDER_line.ORDER_LINE_KEY
  AND BALSAM_EDW_DEV.RAW.raw_ORDER_line.txn_id = ls.txn_id;

INSERT INTO TempAPI_ORDER_header_status (
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority,
    txn_id
)
SELECT 
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority,
    txn_id
FROM (
    SELECT 
        order_header_key,
        status_quantity,
        total_quantity,
        status,
        txn_id,
        ROW_NUMBER() OVER (
            PARTITION BY txn_id, order_header_key 
            ORDER BY CAST(LTRIM(RTRIM(COALESCE(status_quantity, 0))) AS DECIMAL(38, 0)) ASC
        ) AS header_priority
    FROM (
        SELECT 
            order_header_key,
            SUM(status_quantity) AS status_quantity,
            SUM(total_quantity) AS total_quantity,
            status,
            txn_id
        FROM TempAPI_ORDER_line_status
        GROUP BY order_header_key, status, txn_id
    ) AS processed_line
) AS processed
WHERE header_priority = 1;
  
UPDATE BALSAM_EDW_DEV.RAW.raw_ORDER_header
SET order_status = CASE 
    WHEN ls.header_priority > 1 THEN 
        ''_'' || LTRIM(RTRIM(COALESCE(ls.status, '''')))
    WHEN ls.header_priority = 1 THEN 
        LTRIM(RTRIM(COALESCE(ls.status, '''')))
    ELSE NULL
END
FROM (
    SELECT 
        MAX(status_quantity) AS status_quantity,
        order_header_key,
        status,
        header_priority,
        txn_id
    FROM TempAPI_ORDER_header_status
    GROUP BY order_header_key, status, header_priority, txn_id
) AS ls
WHERE ls.order_header_key = BALSAM_EDW_DEV.RAW.raw_ORDER_header.ORDER_HEADER_KEY 
  AND BALSAM_EDW_DEV.RAW.raw_ORDER_header.txn_id = ls.txn_id 
  AND LTRIM(RTRIM(COALESCE(ls.status, ''''))) IS NOT NULL;

SELECT 
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority,
    txn_id
FROM (
    SELECT 
        order_header_key,
        status_quantity,
        total_quantity,
        status,
        txn_id,
        ROW_NUMBER() OVER (
            PARTITION BY txn_id, order_header_key 
            ORDER BY CAST(LTRIM(RTRIM(COALESCE(status_quantity::string, ''0''))) AS DECIMAL(38, 0)) ASC
        ) AS header_priority
    FROM (
        SELECT 
            order_header_key,
            SUM(status_quantity) AS status_quantity,
            SUM(total_quantity) AS total_quantity,
            status,
            txn_id
        FROM TempAPI_ORDER_line_status
        GROUP BY order_header_key, status, txn_id
    ) AS processed_line
) AS processed;

COMMIT;
RETURN ''Success'';
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
