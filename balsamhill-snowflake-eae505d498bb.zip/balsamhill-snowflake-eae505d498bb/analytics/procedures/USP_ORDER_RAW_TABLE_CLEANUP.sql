USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_RAW_TABLE_CLEANUP()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN

call balsam_edw_dev.analytics.usp_ORDER_raw_table_invalid_nord_order_cleanup();

create or replace temporary table balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY as 
SELECT ORDER_HEADER_KEY,ORDER_NO  FROM balsam_edw_dev.raw.raw_ORDER_header 
WHERE DOCUMENT_TYPE in (5) OR  ENTERPRISE_KEY in (''DEFAULT'');


create or replace temporary table balsam_edw_dev.analytics.INVALID_ORDER_LINE_KEY as 
SELECT ORDER_LINE_KEY  from balsam_edw_dev.raw.raw_ORDER_line  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);




delete  from balsam_edw_dev.raw.raw_ORDER_container_details  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY );
delete  from balsam_edw_dev.raw.raw_ORDER_payment  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);
delete  from balsam_edw_dev.raw.raw_ORDER_release  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);
delete  from balsam_edw_dev.raw.raw_ORDER_release_status  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);
delete  from balsam_edw_dev.raw.raw_ORDER_shipment  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);
delete  from balsam_edw_dev.raw.raw_ORDER_shipment_container  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);
delete  from balsam_edw_dev.raw.raw_ORDER_shipment_line  where order_header_key IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);
delete  from balsam_edw_dev.raw.raw_ORDER_header_charges  where header_key IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);
delete  from balsam_edw_dev.raw.raw_ORDER_line_charges  where header_key IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);
delete  from balsam_edw_dev.raw.raw_ORDER_tax_breakup  where header_key IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);


delete  from balsam_edw_dev.raw.raw_ORDER_audit_level  where ORDER_LINE_KEY IN (SELECT ORDER_LINE_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_LINE_KEY);
delete  from balsam_edw_dev.raw.raw_ORDER_audit  where ORDER_HEADER_KEY IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);
delete  from balsam_edw_dev.raw.raw_ORDER_hold_type  where ORDER_HEADER_KEY IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);
delete  from balsam_edw_dev.raw.raw_ORDER_invoice  where ORDER_HEADER_KEY IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);

delete  from balsam_edw_dev.raw.raw_ORDER_line  where ORDER_LINE_KEY IN (SELECT ORDER_LINE_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_LINE_KEY);



--THIS LINE NEEDS TO BE AT THE END

delete  from balsam_edw_dev.raw.raw_ORDER_header  where ORDER_HEADER_KEY IN (SELECT ORDER_HEADER_KEY FROM balsam_edw_dev.analytics.INVALID_ORDER_HEADER_KEY);

COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
