USE DATABASE DEV;
USE SCHEMA analytics;

CREATE OR REPLACE PROCEDURE analytics.usp_merge_gladly_customer(pipeline_name VARCHAR DEFAULT 'gladly_customer')
    RETURNS STRING
    LANGUAGE SQL
AS
DECLARE
    pipeline_stage_name VARCHAR := 'merge';
    start_time          TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    completed_message   VARCHAR;
    error_object        VARIANT;
BEGIN
    SYSTEM$LOG('TRACE', 'SP STARTED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'started',
            :start_time,
            NULL,
            :pipeline_stage_name || ' ' || 'started');

    BEGIN
        MERGE INTO analytics.txn_gladly_customer AS target
            USING (
                SELECT *
                FROM transformed.stage_gladly_customer
            ) AS source
            ON source.id = target.id
            WHEN MATCHED AND (  source.name <> target.name
                OR source.address <> target.address
                OR source.external_customer_ids <> target.external_customer_ids
                OR source.phone_numbers <> target.phone_numbers
                OR source.email_addresses <> target.email_addresses)
                THEN
                UPDATE SET
                    name = source.name,
                    address = source.address,
                    external_customer_ids = source.external_customer_ids,
                    phone_numbers = source.phone_numbers,
                    email_addresses = source.email_addresses,
                    updated_at = CURRENT_TIMESTAMP()
            WHEN NOT MATCHED THEN
                INSERT (
                        id,
                        name,
                        address,
                        external_customer_ids,
                        phone_numbers,
                        email_addresses
                    )
                    VALUES (
                               source.id,
                               source.name,
                               source.address,
                               source.external_customer_ids,
                               source.phone_numbers,
                               source.email_addresses
                           );

        LET staged_events_count VARCHAR := (
            SELECT COUNT(1)
            FROM analytics.txn_gladly_customer
            WHERE updated_at >= :start_time
        );

        completed_message := 'Merging completed successfully. ' || 'Merged records: ' || :staged_events_count;

        COMMIT;
    EXCEPTION
        WHEN statement_error THEN
            ROLLBACK;

            SYSTEM$LOG('ERROR', 'SP FAILED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

            error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                             'SQLCODE', sqlcode,
                                             'SQLERRM', sqlerrm,
                                             'SQLSTATE', sqlstate);

            CALL transformed.insert_into_log_pipeline_tasks_execution_details(
                    :pipeline_name,
                    :pipeline_stage_name,
                    'failed',
                    :start_time,
                    CURRENT_TIMESTAMP(),
                    TO_JSON(:error_object));

            RETURN error_object;
    END;

    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'completed',
            :start_time,
            CURRENT_TIMESTAMP(),
            :completed_message);

    SYSTEM$LOG('TRACE', 'SP COMPLETED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

    RETURN :start_time || ' - ' || :completed_message;
END;

ALTER PROCEDURE analytics.usp_merge_gladly_customer(VARCHAR)
    SET LOG_LEVEL = TRACE, TRACE_LEVEL = ALWAYS;