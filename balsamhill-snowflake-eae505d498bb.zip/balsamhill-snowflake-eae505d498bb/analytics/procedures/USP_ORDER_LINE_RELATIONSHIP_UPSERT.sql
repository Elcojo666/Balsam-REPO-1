
CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_LINE_RELATIONSHIP_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS
DECLARE 
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

    start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED - '||:pipeline_name);

    UPDATE ANALYTICS.log_files_import_status 
    SET processed = :processedRecordCount,
        raw_table = 'raw_order_line_relationship'
    WHERE file_name = 'YFS_ORDER_LINE_RELATIONSHIP';

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

    CREATE OR REPLACE TEMPORARY TABLE TempOrderLineRelationship (
        ORDER_LINE_RELATIONSHIP_KEY STRING,
        RELATIONSHIP_TYPE STRING,
        ORDER_HEADER_KEY STRING,
        PARENT_ORDER_LINE_KEY STRING,
        CHILD_ORDER_LINE_KEY STRING,
        CREATETS TIMESTAMP_NTZ(9),
        MODIFYTS TIMESTAMP_NTZ(9),
        CREATEUSERID STRING,
        MODIFYUSERID STRING,
        CREATEPROGID STRING,
        MODIFYPROGID STRING,
        LOCKID STRING,
        inserted_date TIMESTAMP_NTZ(9),
        modified_date TIMESTAMP_NTZ(9),
        revision INT
    );

    processedDate := CURRENT_TIMESTAMP();

    -- Merge into TXN table
    MERGE INTO ANALYTICS.txn_order_line_relationship AS txn
    USING (
        SELECT
            ORDER_LINE_RELATIONSHIP_KEY,
            RELATIONSHIP_TYPE,
            ORDER_HEADER_KEY,
            PARENT_ORDER_LINE_KEY,
            CHILD_ORDER_LINE_KEY,
            CREATETS,
            MODIFYTS,
            CREATEUSERID,
            MODIFYUSERID,
            CREATEPROGID,
            MODIFYPROGID,
            LOCKID
        FROM TRANSFORMED.stg_order_line_relationship
    ) AS stg
    ON txn.ORDER_LINE_RELATIONSHIP_KEY = stg.ORDER_LINE_RELATIONSHIP_KEY
    WHEN MATCHED THEN
        UPDATE SET
            txn.RELATIONSHIP_TYPE = stg.RELATIONSHIP_TYPE,
            txn.PARENT_ORDER_LINE_KEY = stg.PARENT_ORDER_LINE_KEY,
            txn.CHILD_ORDER_LINE_KEY = stg.CHILD_ORDER_LINE_KEY,
            txn.CREATETS = TRY_TO_TIMESTAMP(stg.CREATETS,'YYYYMMDDHHMISS'),
            txn.MODIFYTS = TRY_TO_TIMESTAMP(stg.MODIFYTS,'YYYYMMDDHHMISS'),
            txn.CREATEUSERID = stg.CREATEUSERID,
            txn.MODIFYUSERID = stg.MODIFYUSERID,
            txn.CREATEPROGID = stg.CREATEPROGID,
            txn.MODIFYPROGID = stg.MODIFYPROGID,
            txn.LOCKID = stg.LOCKID,
            txn.modified_date = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
            ORDER_LINE_RELATIONSHIP_KEY,
            RELATIONSHIP_TYPE,
            ORDER_HEADER_KEY,
            PARENT_ORDER_LINE_KEY,
            CHILD_ORDER_LINE_KEY,
            CREATETS,
            MODIFYTS,
            CREATEUSERID,
            MODIFYUSERID,
            CREATEPROGID,
            MODIFYPROGID,
            LOCKID,
            inserted_date
        )
        VALUES (
            stg.ORDER_LINE_RELATIONSHIP_KEY,
            stg.RELATIONSHIP_TYPE,
            stg.ORDER_HEADER_KEY,
            stg.PARENT_ORDER_LINE_KEY,
            stg.CHILD_ORDER_LINE_KEY,
            TRY_TO_TIMESTAMP(stg.CREATETS,'YYYYMMDDHHMISS'),
            TRY_TO_TIMESTAMP(stg.MODIFYTS,'YYYYMMDDHHMISS'),
            stg.CREATEUSERID,
            stg.MODIFYUSERID,
            stg.CREATEPROGID,
            stg.MODIFYPROGID,
            stg.LOCKID,
            CURRENT_TIMESTAMP()
        );

    -- Capture processed records
    INSERT INTO TempOrderLineRelationship (
        ORDER_LINE_RELATIONSHIP_KEY,
        RELATIONSHIP_TYPE,
        ORDER_HEADER_KEY,
        PARENT_ORDER_LINE_KEY,
        CHILD_ORDER_LINE_KEY,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID,
        inserted_date,
        Revision
    )
    SELECT
        ORDER_LINE_RELATIONSHIP_KEY,
        RELATIONSHIP_TYPE,
        ORDER_HEADER_KEY,
        PARENT_ORDER_LINE_KEY,
        CHILD_ORDER_LINE_KEY,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID,
        CURRENT_TIMESTAMP(),
        1
    FROM ANALYTICS.txn_order_line_relationship txn
    WHERE txn.inserted_date >= :processedDate OR txn.modified_date >= :processedDate;

    -- Track max revision for audit
    CREATE OR REPLACE TEMPORARY TABLE TempMaxRevisions AS
    SELECT
        MAX(aot.revision) AS revision,
        aot.ORDER_LINE_RELATIONSHIP_KEY
    FROM ANALYTICS.audit_order_line_relationship AS aot
    INNER JOIN TempOrderLineRelationship AS tmp
        ON tmp.ORDER_LINE_RELATIONSHIP_KEY = aot.ORDER_LINE_RELATIONSHIP_KEY
    GROUP BY aot.ORDER_LINE_RELATIONSHIP_KEY;

    UPDATE TempOrderLineRelationship tmp
    SET tmp.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS INTEGER)
    FROM TempMaxRevisions aot
    WHERE tmp.ORDER_LINE_RELATIONSHIP_KEY = aot.ORDER_LINE_RELATIONSHIP_KEY;

    -- Insert into Audit
    INSERT INTO ANALYTICS.audit_order_line_relationship (
        ORDER_LINE_RELATIONSHIP_KEY,
        RELATIONSHIP_TYPE,
        ORDER_HEADER_KEY,
        PARENT_ORDER_LINE_KEY,
        CHILD_ORDER_LINE_KEY,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID,
        inserted_date,
        Revision
    )
    SELECT
        stg.ORDER_LINE_RELATIONSHIP_KEY,
        stg.RELATIONSHIP_TYPE,
        stg.ORDER_HEADER_KEY,
        stg.PARENT_ORDER_LINE_KEY,
        stg.CHILD_ORDER_LINE_KEY,
        TRY_TO_TIMESTAMP(stg.CREATETS,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(stg.MODIFYTS,'YYYYMMDDHHMISS'),
        stg.CREATEUSERID,
        stg.MODIFYUSERID,
        stg.CREATEPROGID,
        stg.MODIFYPROGID,
        stg.LOCKID,
        CURRENT_TIMESTAMP(),
        tmp.Revision
    FROM TRANSFORMED.stg_order_line_relationship stg
    INNER JOIN TempOrderLineRelationship tmp
        ON tmp.ORDER_LINE_RELATIONSHIP_KEY = stg.ORDER_LINE_RELATIONSHIP_KEY;

    UPDATE RAW.raw_ORDER_LINE_RELATIONSHIP AS roh
    SET 
        roh.processing_status = 'Processed',
        roh.processing_comment = '',
        roh.processing_errortype = ''
    FROM TRANSFORMED.stg_order_LINE_RELATIONSHIP AS stg
    INNER JOIN ANALYTICS.txn_order_LINE_RELATIONSHIP AS toh
        ON toh.ORDER_LINE_RELATIONSHIP_KEY = stg.ORDER_LINE_RELATIONSHIP_KEY
    WHERE roh.ORDER_LINE_RELATIONSHIP_KEY = stg.ORDER_LINE_RELATIONSHIP_KEY and roh.MODIFYTS = stg.modifyts;

    -- Stats update
    SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM TRANSFORMED.stg_order_line_relationship;
    SELECT COUNT(*) INTO :processedRecordCount FROM TempOrderLineRelationship;

    UPDATE analytics.log_files_import_status
    SET
        processed = :processedRecordCount,
        to_be_processed = :toBeProcessedRecordCount,
        status = 'Success'
    WHERE file_name = 'YFS_ORDER_LINE_RELATIONSHIP';

    DROP TABLE IF EXISTS TempOrderLineRelationship;

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'COMPLETED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        'upsert completed successfully'
    );

    SYSTEM$LOG('TRACE','SP COMPLETED - '||:pipeline_name);

    COMMIT;
    RETURN 'Success';

EXCEPTION
    WHEN statement_error THEN
        ROLLBACK;
        UPDATE ANALYTICS.log_files_import_status
            SET processed = 0,
                status = 'Failed'
        WHERE file_name = 'YFS_ORDER_LINE_RELATIONSHIP';

        error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                         'SQLCODE', sqlcode,
                                         'SQLERRM', sqlerrm,
                                         'SQLSTATE', sqlstate);

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'FAILED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            TO_JSON(:error_object)
        );

        SYSTEM$LOG('ERROR','SP FAILED - '||:pipeline_name);

        RETURN error_object;
END;
