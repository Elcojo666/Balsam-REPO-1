USE DATABASE DEV;

CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.USP_CUSTOMER_API_UPDATE_BY_PKID("P_PK_CUSTOMERID" NUMBER(38,0), "P_SOURCEREFNUM" VARCHAR DEFAULT null, "P_SOURCEID" VARCHAR DEFAULT null, "P_VALIDATION_STATUS" NUMBER(38,0) DEFAULT null, "P_CUSTOMERTYPE" VARCHAR DEFAULT null, "P_PHONENUMBER" VARCHAR DEFAULT null, "P_PHONE1INPUT" VARCHAR DEFAULT null, "P_PHONE2INPUT" VARCHAR DEFAULT null, "P_PHONE4INPUT" VARCHAR DEFAULT null, "P_PHONENUMBER_E164" VARCHAR DEFAULT null, "P_PHONE1INPUT_E164" VARCHAR DEFAULT null, "P_PHONE2INPUT_E164" VARCHAR DEFAULT null, "P_PHONE4INPUT_E164" VARCHAR DEFAULT null, "P_COMPANYNAME" VARCHAR DEFAULT null, "P_CATALOGSUBSCRIBER" VARCHAR DEFAULT null, "P_CUSTOMER_ISANONYMOUS" VARCHAR DEFAULT null, "P_CHECKBOX_FOR_NEW_CUSTOMERS" VARCHAR DEFAULT null, "P_CUSTOMER_NOTES" VARCHAR DEFAULT null, "P_TAXEXEMPTACCOUNT" VARCHAR DEFAULT null, "P_ORDERPLACED" VARCHAR DEFAULT null, "P_LEGALNAME" VARCHAR DEFAULT null, "P_MASTERCONTACT" VARCHAR DEFAULT null, "P_LASTLOGIN" TIMESTAMP_NTZ(9) DEFAULT null, "P_MODIFIEDBY" VARCHAR DEFAULT null, "P_EXTERNALEMAIL2" VARCHAR DEFAULT null, "P_EXTERNAL_EMAIL1" VARCHAR DEFAULT null, "P_STATUS" VARCHAR DEFAULT null, "P_PREFERRED_LANG" VARCHAR DEFAULT null, "P_TITLE" VARCHAR DEFAULT null, "P_DOB" DATE DEFAULT null, "P_GENDER" VARCHAR DEFAULT null, "P_GENDERCODE" VARCHAR DEFAULT null, "P_MARITALSTATUS" VARCHAR DEFAULT null, "P_EMAIL_OPT_IN_STATUS" VARCHAR DEFAULT null, "P_EXTERNAL_ACCOUNTID" VARCHAR DEFAULT null, "P_MARITALSTATUSCODE" VARCHAR DEFAULT null, "P_CUST_TIER" VARCHAR DEFAULT null, "P_TAX_ID" VARCHAR DEFAULT null, "P_EMAILSUBSCRIBER" BOOLEAN DEFAULT null, "P_EMAILSECONDARY" VARCHAR DEFAULT null, "P_ISNORDSTROMCUSTOMER" VARCHAR DEFAULT null, "P_ISWILLIAMSONOMACUSTOMER" VARCHAR DEFAULT null, "P_BUSINESS_CUST" VARCHAR DEFAULT null, "P_BUSINESS_CATEGORY" VARCHAR DEFAULT null, "P_BUSINESSLOCATIONS" VARCHAR DEFAULT null, "P_DESIGNTRADEFLAG" VARCHAR DEFAULT null, "P_SOCIAL_HANDLE_FACEBOOK" VARCHAR DEFAULT null, "P_SOCIAL_HANDLE_INSTAGRAM" VARCHAR DEFAULT null, "P_SOCIAL_HANDLE_TWITTER" VARCHAR DEFAULT null, "P_PHONE1_SMS" VARCHAR DEFAULT null, "P_PHONE1_PREF" VARCHAR DEFAULT null, "P_PHONE1_REGION" VARCHAR DEFAULT null, "P_PHONE2_SMS" VARCHAR DEFAULT null, "P_PHONE2_PREF" VARCHAR DEFAULT null, "P_PHONE2_REGION" VARCHAR DEFAULT null, "P_PHONE3_SMS" VARCHAR DEFAULT null, "P_PHONE3_PREF" VARCHAR DEFAULT null, "P_PHONE3_REGION" VARCHAR DEFAULT null, "P_PHONE4_SMS" VARCHAR DEFAULT null, "P_PHONE4_PREF" VARCHAR DEFAULT null, "P_PHONE4_REGION" VARCHAR DEFAULT null, "P_HASHEDID" VARCHAR DEFAULT null, "P_REGD_DATE" TIMESTAMP_NTZ(9) DEFAULT null, "P_FIRST_NAME" VARCHAR DEFAULT null, "P_LAST_NAME" VARCHAR DEFAULT null, "P_EMAIL_PRIMARY" VARCHAR DEFAULT null, "P_ISBUSINESS" BOOLEAN DEFAULT null)
COPY GRANTS 
RETURNS TABLE ()
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    currentDateTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP();
    FinalStatus     BOOLEAN DEFAULT FALSE;
    WarningCount    INT;
    CustomerCount   INT;
    message         STRING;
    error_message   STRING;
    sql_code        STRING;
    res             RESULTSET;
    customerInfoID  STRING;
    prev_Cust_Type STRING;
BEGIN

    --------------------------------------------------------------------------
    -- Check for warnings: if there is no customer record for the given PK,
    -- then return a warning message.
    --------------------------------------------------------------------------
    SELECT COUNT(source_ref_num) INTO WarningCount
    FROM analytics.customer AS cust 
    WHERE cust.pk_customerid = :p_pk_customerid;

    IF (WarningCount = 0) THEN
        message := ''WARNING: 1 There are no Records to update; Need to add customer'';
        res := (SELECT 
            :message AS MESSAGE,
            ''Failed'' AS STATUS,
            NULL AS ID,
            ''400'' AS STATUSCODE);
        RETURN TABLE(res);
    END IF;

    --------------------------------------------------------------------------
    -- Update the CUSTOMER_INFO table using data from parsedData.
    --------------------------------------------------------------------------
    SELECT CUST_TYPE
    INTO :prev_Cust_Type
    FROM ANALYTICS.CUSTOMER_INFO
    WHERE FK_CUSTOMERID = :p_pk_customerid;
    
    UPDATE ANALYTICS.CUSTOMER_INFO
    SET 
        REGD_DATE           = COALESCE(:p_REGD_DATE, REGD_DATE),
        FIRST_NAME          = COALESCE(:p_FIRST_NAME, FIRST_NAME),
        LAST_NAME           = COALESCE(:p_LAST_NAME, LAST_NAME),
        EMAIL_PRIMARY       = COALESCE(:p_EMAIL_PRIMARY, EMAIL_PRIMARY),
        phone3_input        = COALESCE(:p_PhoneNumber, phone3_input),
        phone1_input        = COALESCE(:p_Phone1Input, phone1_input),
        phone2_input        = COALESCE(:p_Phone2Input, phone2_input),
        phone4_input        = COALESCE(:p_Phone4Input, phone4_input),
        phone3_E164         = COALESCE(:P_PHONENUMBER_E164, phone3_E164),
        phone1_E164         = COALESCE(:p_Phone1Input_E164, phone1_E164),
        Phone2_E164         = COALESCE(:p_Phone2Input_E164, Phone2_E164),
        phone4_E164         = COALESCE(:p_Phone4Input_E164, phone4_E164),
        COMPANY_NAME        = COALESCE(:p_CompanyName, COMPANY_NAME),
        CATALOG_SUBSCRIBER  = COALESCE(:p_CatalogSubscriber, CATALOG_SUBSCRIBER),
        CUSTOMER_IS_ANONYMOUS = COALESCE(:p_Customer_IsAnonymous, CUSTOMER_IS_ANONYMOUS),
        NEW_CUSTOMER        = COALESCE(:p_Checkbox_For_New_Customers, NEW_CUSTOMER),
        CUST_NOTES          = COALESCE(:p_Customer_Notes, CUST_NOTES),
        TAX_EXEMPT_ACCOUNT  = COALESCE(:p_TaxExemptAccount, TAX_EXEMPT_ACCOUNT),
        ORDER_PLACED        = COALESCE(:p_OrderPlaced, ORDER_PLACED),
        legal_name          = COALESCE(:p_legalname, legal_name),
        Mastercontact       = COALESCE(:p_Mastercontact, Mastercontact),
        LAST_LOGIN_DATE     = COALESCE(:p_LastLogin, LAST_LOGIN_DATE),
        MODIFIED_BY         = :p_MODIFIEDBY,
        MODIFIED_DATE       = CURRENT_TIMESTAMP,
        EXTERNAL_EMAIL2     = COALESCE(:p_EXTERNALEMAIL2, EXTERNAL_EMAIL2),
        EXTERNAL_EMAIL1     = COALESCE(:p_EXTERNAL_EMAIL1, EXTERNAL_EMAIL1),
        status              = COALESCE(:p_status, status),
        preferred_lang      = COALESCE(:p_preferred_lang, preferred_lang),
        title               = COALESCE(:p_title, title),
        dob                 = COALESCE(:p_dob, dob),
        gender              = COALESCE(:p_gender, gender),
        gender_code         = COALESCE(:p_gendercode, gender_code),
        CUST_TYPE           = COALESCE(:p_CustomerType, CUST_TYPE),
        marital_status      = COALESCE(:p_maritalstatus, marital_status),
        email_opt_in_status = COALESCE(:p_email_opt_in_status, email_opt_in_status),
        externaL_ACCOUNTID  = COALESCE(:p_externaL_ACCOUNTID, externaL_ACCOUNTID),
        marital_status_code = COALESCE(:p_maritalstatuscode, marital_status_code),
        cust_tier           = COALESCE(:p_cust_tier, cust_tier),
        tax_id              = COALESCE(:p_tax_id, tax_id),
        email_subscriber    = CAST(COALESCE(CASE WHEN LOWER(:p_emailsubscriber) = ''true'' THEN 1 ELSE 0 END, email_subscriber) AS INT),
        EMAIL_secondary     = COALESCE(:p_EMAILsecondary, EMAIL_secondary),
        IsNordstromCustomer = COALESCE(:p_IsNordstromCustomer, IsNordstromCustomer),
        IsWilliamsonomaCustomer = COALESCE(:p_IsWilliamsonomaCustomer, IsWilliamsonomaCustomer),
        business_cust       = COALESCE(:p_business_cust, business_cust),
        business_category   = COALESCE(:p_business_category, business_category),
        "BUSINESS_#_OF_LOCATIONS" = COALESCE(:p_BusinessLocations, "BUSINESS_#_OF_LOCATIONS"),
        DesignTradeFlag     = COALESCE(:p_DesignTradeFlag, DesignTradeFlag),
        social_handle_facebook = COALESCE(:p_social_handle_facebook, social_handle_facebook),
        social_handle_instagram = COALESCE(:p_social_handle_instagram, social_handle_instagram),
        social_handle_twitter  = COALESCE(:p_social_handle_twitter, social_handle_twitter),
        phone1_sms          = COALESCE(:p_phone1_sms, phone1_sms),
        phone1_pref         = COALESCE(:p_phone1_pref, phone1_pref),
        phone1_region       = COALESCE(:p_phone1_region, phone1_region),
        phone2_sms          = COALESCE(:p_phone2_sms, phone2_sms),
        phone2_pref         = COALESCE(:p_phone2_pref, phone2_pref),
        phone2_region       = COALESCE(:p_phone2_region, phone2_region),
        phone3_sms          = COALESCE(:p_phone3_sms, phone3_sms),
        phone3_pref         = COALESCE(:p_phone3_pref, phone3_pref),
        phone3_region       = COALESCE(:p_phone3_region, phone3_region),
        phone4_sms          = COALESCE(:p_phone4_sms, phone4_sms),
        phone4_pref         = COALESCE(:p_phone4_pref, phone4_pref),
        phone4_region       = COALESCE(:p_phone4_region, phone4_region),
        HashedId            = COALESCE(:p_HashedId, HashedId),
        ISBUSINESS          = COALESCE(:p_ISBUSINESS, ISBUSINESS)
    WHERE FK_CUSTOMERID = :p_pk_customerid;


    --------------------------------------------------------------------------
    -- Retrieve the CUSTOMER_INFO primary key (for the response).
    --------------------------------------------------------------------------
    SELECT DISTINCT custinfo.PK_CUSTOMER_INFO_ID 
      INTO :customerInfoID
    FROM analytics.customer_info AS custinfo
    WHERE custinfo.fk_customerid = :p_pk_customerid;

    --------------------------------------------------------------------------
    -- Merge update the analytics.customer table.
    --------------------------------------------------------------------------

    IF(prev_Cust_Type <> p_CustomerType) THEN 
        MERGE INTO analytics.customer AS tgt
        USING (
            SELECT 
                :p_pk_customerid AS fk_customerid,
                :p_SourceID AS pk_sourceid,
                dct.pk_customer_typeid AS new_customer_typeid
            FROM MASTER.dim_customer_type AS dct
            WHERE dct.customer_type = :p_CustomerType
        ) AS src
        ON tgt.pk_customerid = src.fk_customerid
           AND tgt.fk_sourceid = src.pk_sourceid
        WHEN MATCHED 
             AND :p_CustomerType IS NOT NULL THEN
          UPDATE 
            SET tgt.fk_customer_typeid = src.new_customer_typeid;
    END IF;

    --------------------------------------------------------------------------
    -- Return the result.
    --------------------------------------------------------------------------
    res := (SELECT 
              ''Record Updated for Info ID'' AS MESSAGE,
              ''Success'' AS STATUS,
              :customerInfoID AS ID,
              ''200'' AS STATUSCODE);
    RETURN TABLE(res);

EXCEPTION
    WHEN statement_error THEN
        ROLLBACK;
        error_message := sqlerrm;
        sql_code := sqlcode;
        INSERT INTO ANALYTICS.log_microservices_errors (
            microservicesname,  
            methodname,  
            errortime,  
            errormessage,  
            source,  
            exceptiontrace,  
            sql_errornumber,  
            sql_errorstate,  
            sql_errorseverity,  
            sql_errorline,  
            sql_errorprocedure,  
            sql_errormessage
        )
        VALUES (
            ''CustomerApi'',  
            ''Update Customer'',  
            CURRENT_TIMESTAMP(),  
            ''Error in SQL'',  
            NULL,  
            NULL,  
            :sql_code,  
            NULL,  
            NULL,  
            NULL,  
            NULL,  
            :error_message
        );
        res := (SELECT 
                  ''Error: '' || :error_message AS MESSAGE,
                  ''Failed'' AS STATUS,
                  NULL AS ID,
                  ''500'' AS STATUSCODE);
        RETURN TABLE(res);
END';
