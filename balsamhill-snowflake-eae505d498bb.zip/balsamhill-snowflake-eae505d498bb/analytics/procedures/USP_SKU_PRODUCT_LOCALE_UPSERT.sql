USE DATABASE DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_SKU_PRODUCT_LOCALE_UPSERT()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
 startTime TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP();
 stagingRecordCount NUMBER DEFAULT 0;
 file_source_id NUMBER DEFAULT 110; 
BEGIN 

CREATE OR REPLACE TEMPORARY TABLE RAW_PRODUCT_RANKED AS
WITH RANKER AS (
SELECT *, RANK() OVER (
               PARTITION BY SKU
               ORDER BY
                   CASE WHEN TRY_CAST(Year AS NUMBER) = YEAR(CURRENT_DATE) THEN 0 ELSE 1 END, -- Current year has priority
                   Year DESC,
                   INSERTED_DATE DESC
           ) AS skulabel_rank_number
           , ROW_NUMBER() OVER (
               PARTITION BY SKU
               ORDER BY
                   CASE WHEN TRY_CAST(Year AS NUMBER) = YEAR(CURRENT_DATE) THEN 0 ELSE 1 END, -- Current year has priority
                   Year DESC,
                   INSERTED_DATE DESC,
                   case when LANGUAGE = ''en_WW'' THEN 0 ELSE 1 END -- Prioritizing English Worldwide
           ) AS skulabel_row_number
FROM RAW.RAW_PRODUCT_PRODUCT
WHERE SKU IS NOT NULL
)
SELECT *
FROM RANKER 
WHERE skulabel_rank_number = 1
;

SELECT COUNT(*)
INTO :stagingRecordCount
FROM RAW_PRODUCT_RANKED;

------------------- UPSERT SKUPRODUCT -------------------
-------------------------------------------------------------

-- Update skuproduct table using the temporary table
UPDATE ANALYTICS.SKU_PRODUCT AS ds
SET ds.fk_filesourceid = :file_source_id,
    ds.sku_code = spe.SKU,
    ds.product_information = spe.Product_Description,
    ds.agent = spe.Third_Party_LiaisonAgent,
    ds.assembly_requirements = spe.Assembly_Required,
    ds.bh_exclusive = spe.Balsam_Hill_Exclusive,
    ds.battries_included = spe.Batteries_Included,
    ds.care_instructions = spe.Use_Care_Cleaning_Recomdtn,
    ds.collection = '' '',
    ds.vendor_contact = spe.Vendor_Contact_Name,
    ds.is_handcrafted = spe.Handcrafted,
    ds.is_handpainted = spe.Handpainted,
    ds.realism_level = spe.Level_Realism,
    ds.vendor = spe.vendor_externalkey,
    ds.no_of_batteries = TRY_CAST(spe.Batteries_Number_Required AS FLOAT),
    ds.outdoor_safe = spe.Outdoor_Safe,
    ds.personalisation = spe.Personalization_Monogram,
    ds.product_material_contents = spe.Material,
    ds.type_of_batteries = spe.Batteries_Type_Required,
    ds.vendor_prod_name = spe.Vendor_ProductName,
    ds.drop_ship_item = spe.Drop_Ship,
    ds.plug_in_cord_length_inch = TRY_CAST(spe.Length_Cord_Inches_Value AS FLOAT),
    ds.units_per_inner_pack = TRY_CAST(spe.Size_Set_Pack AS FLOAT),
    ds.item_colors = spe.Vendor_Color,
    ds.pillar_category = spe.Category_Path,
    ds.no_of_items_set = TRY_CAST(spe.Size_Set_Pack AS FLOAT),
    ds.entity_type = spe.entity_type,
    ds.country_of_origin = spe.Country_Of_Origin,
    ds.last_updated_date = CURRENT_TIMESTAMP
FROM RAW_PRODUCT_RANKED AS spe
WHERE ds.sku_code = spe.SKU
and spe.skulabel_row_number = 1;

INSERT INTO ANALYTICS.SKU_PRODUCT (
    sku_code,
    fk_filesourceid,
    collection,
    warranty_included,
    no_of_items_set,
    item_colors,
    battries_included,
    no_of_batteries,
    type_of_batteries,
    entity_type,
    plug_in_cord_length_inch,
    drop_ship_item,
    vendor,
    product_material_contents,
    product_information,
    vendor_prod_name,
    is_handpainted,
    bh_exclusive,
    is_handcrafted,
    agent,
    assembly_requirements,
    care_instructions,
    vendor_contact,
    realism_level,
    outdoor_safe,
    personalisation,
    units_per_inner_pack,
    pillar_category,
    country_of_origin,
    active_flag,
    inserted_date,
    last_updated_date,
    is_parent_available,
    is_parent
)
SELECT
    spe.SKU,
    :file_source_id,
    '' '',
    '''',
    TRY_CAST(spe.Size_Set_Pack AS FLOAT),
    spe.Vendor_Color,
    spe.Batteries_Included,
    TRY_CAST(spe.Batteries_Number_Required AS FLOAT),
    spe.Batteries_Type_Required,
    spe.entity_type,
    TRY_CAST(spe.Length_Cord_Inches_Value AS FLOAT),
    spe.Drop_Ship,
    spe.vendor_externalkey,
    spe.Material,
    spe.Product_Description,
    spe.Vendor_ProductName,
    spe.Handpainted,
    spe.Balsam_Hill_Exclusive,
    spe.Handcrafted,
    spe.Third_Party_LiaisonAgent,
    spe.Assembly_Required,
    spe.Use_Care_Cleaning_Recomdtn,
    spe.Vendor_Contact_Name,
    spe.Level_Realism,
    spe.Outdoor_Safe,
    spe.Personalization_Monogram,
    TRY_CAST(spe.Size_Set_Pack AS FLOAT),
    spe.Category_Path,
    spe.Country_Of_Origin,
    1,
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    0,
    0
FROM RAW_PRODUCT_RANKED AS spe
LEFT JOIN ANALYTICS.SKU_PRODUCT AS ds ON ds.SKU_CODE = spe.SKU
WHERE ds.pk_skuproductid IS NULL AND spe.SKU IS NOT NULL AND LENGTH(spe.SKU) > 0
and spe.skulabel_row_number = 1;


------------------- UPSERT SKUPROUDCT_LOCALE -------------------
--------------------------------------------------------------------

UPDATE ANALYTICS.SKU_PRODUCT_locale dsl
SET
  dsl.sku_code = spe.SKU,                
  dsl.bh_product_name = spe.Product_Name,                
  dsl.product_information = spe.Product_Description,             
  dsl.actual_product_diameter = spe.Diameter_ProvidedByVendor,                
  dsl.actual_product_height = spe.Height_ProvidedByVendor,                
  dsl.actual_product_length = '''', --(NA IN CNS)               
  dsl.actual_product_width = spe.Width_ProvidedByVendor,                
  dsl.actual_product_weight = spe.Weight_ProvidedByVendor,              
  dsl.master_box_height = TRY_CAST(spe.MasterPack_Height_Inches_Value AS FLOAT),                
  dsl.master_box_length = TRY_CAST(spe.MasterPack_Length_Inches_Value AS FLOAT),                
  dsl.master_box_weight = TRY_CAST(spe.MasterPack_Weight_Lbs_value AS FLOAT),                
  dsl.master_box_width = TRY_CAST(spe.MasterPack_Width_Inches_Value AS FLOAT),              
  dsl.pillar_category = spe.Category_Path,                
  dsl.actual_product_unit_of_measure= '''',  --(NA IN CNS)      
  dsl.pillar_category_sub = '''',            --(NA IN CNS)      
  dsl."seo//title_tag" = spe.SEO_TitleTag,      
  dsl."content_attributes_cat//foliage_module__heading" = '''',        --(NA IN CNS)      
  dsl."seo//product_name" = spe.Product_Name,      
  dsl."seo//product_name__h1" = spe.Product_Description_Headline,      
  dsl."CO_A_live_on_site_date" = TRY_TO_TIMESTAMP(spe.Live_On_SiteDate, ''MM/DD/YYYY HH24:MI:SS''),                  
  dsl."M_gen//is_child_of_product_code" = spe.Parent_SKU,      
  dsl."CA_crosssell_description" = '''',             --(NA IN CNS)      
  dsl."IM_child_product_name_on_mobile" = '''',      --(NA IN CNS)      
  dsl."IM_display_width_unit_of_measurement" = '''',   --(NA IN CNS)      
  dsl."IM_display_length_unit_of_measurement" = '''',   --(NA IN CNS)      
  dsl."seo//slug" = spe.SEO_Slug,      
  dsl."CA_included_module__bullets_html" = '''',         --(NA IN CNS)     
  dsl.KA_status = spe.Channel_Status  
FROM ANALYTICS.SKU_PRODUCT ds
    INNER JOIN RAW_PRODUCT_RANKED spe
        ON ds.sku_code = spe.SKU          
WHERE dsl.pk_skuproductid = ds.pk_skuproductid
    AND dsl.locale = spe.language
    AND spe.language is NOT NULL 
;

INSERT INTO ANALYTICS.SKU_PRODUCT_locale (
  sku_code,          
  bh_product_name,            
  actual_product_weight,            
  actual_product_length,            
  actual_product_width,             
  actual_product_height,            
  actual_product_diameter,            
  master_box_height,            
  master_box_width,            
  master_box_length,            
  master_box_weight,            
  product_information,            
  outer_height,            
  outer_length,            
  outer_width,            
  sub_category,            
  pillar_category,            
  locale,      
  "seo//title_tag",      
  "content_attributes_cat//foliage_module__heading",      
  "seo//product_name",      
  "seo//product_name__h1",      
  "CO_A_live_on_site_date",      
  "M_gen//is_child_of_product_code",      
  "CA_crosssell_description",      
  "IM_child_product_name_on_mobile",      
  "IM_display_width_unit_of_measurement",      
  "IM_display_length_unit_of_measurement",      
  "seo//slug",      
  "CA_included_module__bullets_html",   
  KA_status  
)
SELECT
  spe.SKU,     
  spe.Product_Name,            
  spe.Weight_ProvidedByVendor,            
  '''' AS actual_product_length, -- (NA IN CNS)            
  spe.Width_ProvidedByVendor,            
  spe.Height_ProvidedByVendor,            
  spe.Diameter_ProvidedByVendor,             
  TRY_CAST(spe.MasterPack_Height_Inches_Value AS FLOAT),            
  TRY_CAST(spe.MasterPack_Width_Inches_Value AS FLOAT),            
  TRY_CAST(spe.MasterPack_Length_Inches_Value AS FLOAT),            
  TRY_CAST(spe.MasterPack_Weight_Lbs_value AS FLOAT),             
  spe.Product_Description,            
  '''' AS outer_height, -- (NA IN CNS)            
  '''' AS outer_length, -- (NA IN CNS)            
  '''' AS outer_width, -- (NA IN CNS)            
  '''' AS sub_category, -- (NA IN CNS)            
  spe.Category_Path,            
  spe.language as locale,      
  spe.SEO_TitleTag,      
  '''', -- (NA IN CNS)      
  spe.Product_Name,      
  spe.Product_Description_Headline,      
  TRY_TO_TIMESTAMP(spe.Live_On_SiteDate, ''MM/DD/YYYY HH24:MI:SS''), -- (NA IN CNS)            
  spe.Parent_SKU,      
  '''' , -- (NA IN CNS)      
  '''' , -- (NA IN CNS)      
  '''' , -- (NA IN CNS)      
  '''' , -- (NA IN CNS)      
  spe.SEO_Slug,      
  '''' , -- (NA IN CNS)    
  spe.Channel_Status  
FROM RAW_PRODUCT_RANKED AS spe
LEFT JOIN ANALYTICS.SKU_PRODUCT_locale ds 
  ON ds.sku_code = spe.SKU  
  AND ds.locale = spe.language     
WHERE ds.pk_skuproductid IS NULL
    AND spe.language is NOT NULL 
    AND spe.SKU IS NOT NULL  
    AND LENGTH(spe.SKU) > 0;

UPDATE ANALYTICS.SKU_PRODUCT_locale ds
SET ds.pk_skuproductid = sku.pk_skuproductid
FROM ANALYTICS.SKU_PRODUCT sku
WHERE ds.sku_code = sku.sku_code
  AND ds.pk_skuproductid IS NULL;

INSERT INTO TRANSFORMED.log_inputsheet  
    (fk_inputfileid,  
     source_sheet_name,  
     rejection_reason,  
     source_record_count,  
     staging_record_count,  
     validationerror,  
     is_rejected)  
VALUES  
    ( 
      :file_source_id,  
      ''Raw To Dim Transformation - SKUProduct'',  
      '''',  
      :stagingRecordCount,  
      :stagingRecordCount,  
      '''',  
      ''0''  
    );


RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;

    INSERT INTO TRANSFORMED.log_inputsheet  
    (fk_inputfileid,  
     source_sheet_name,  
     rejection_reason,  
     source_record_count,  
     staging_record_count,  
     validationerror,  
     is_rejected)  
VALUES  
    (  
      :file_source_id,  
      ''Raw To Dim Transformation - SKUProduct'',  
      ''error'',  
      :stagingRecordCount,  
      ''0'',  
      ''error'',  
      ''1''  
    );

    
END';