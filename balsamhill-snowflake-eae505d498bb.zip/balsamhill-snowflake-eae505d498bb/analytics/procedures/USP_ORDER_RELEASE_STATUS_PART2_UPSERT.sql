USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_RELEASE_STATUS_PART2_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

UPDATE log_files_import_status
SET processed = :processedRecordCount
WHERE file_name = ''YFS_ORDER_RELEASE_STATUS_PART2'' 
AND raw_table = ''raw_ORDER_release_status_part2'';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );
    

processedDate := CURRENT_TIMESTAMP();  

CREATE OR REPLACE TEMPORARY TABLE TempOrderReleaseStatus (
    order_release_status_key VARCHAR(16777216),
    order_release_key VARCHAR(16777216),
    order_line_key VARCHAR(16777216),
    order_header_key VARCHAR(16777216),
    status VARCHAR(16777216),
    status_date VARCHAR(16777216),
    status_quantity VARCHAR(16777216),
    pipeline_key VARCHAR(16777216),
    order_line_schedule_key VARCHAR(16777216),
    total_quantity VARCHAR(16777216),
    expected_shipment_date VARCHAR(16777216),
    chained_to_order_line_key VARCHAR(16777216),
    chained_to_order_header_key VARCHAR(16777216),
    createts VARCHAR(16777216),
    modifyts VARCHAR(16777216),
    createuserid VARCHAR(16777216),
    modifyuserid VARCHAR(16777216),
    createprogid VARCHAR(16777216),
    modifyprogid VARCHAR(16777216),
    lockid VARCHAR(16777216),
    inserted_date VARCHAR(16777216) NULL,
    modified_date VARCHAR(16777216) NULL,
    revision INT
);

MERGE INTO ANALYTICS.txn_order_release_status tors
USING (
    SELECT 
        stg.order_release_status_key,
        stg.order_release_key,
        stg.order_line_key,
        stg.order_header_key,
        stg.status,
        stg.status_date,
        stg.status_quantity,
        stg.pipeline_key,
        stg.order_line_schedule_key,
        stg.total_quantity,
        stg.expected_shipment_date,
        stg.chained_to_order_line_key,
        stg.chained_to_order_header_key,
        stg.createts,
        stg.modifyts,
        stg.createuserid,
        stg.modifyuserid,
        stg.createprogid,
        stg.modifyprogid,
        stg.lockid
    FROM TRANSFORMED.stg_ORDER_release_status_part2 stg
) sors
ON 
    tors.order_release_status_key = sors.order_release_status_key
    AND tors.order_line_key = sors.order_line_key
    AND tors.order_header_key = sors.order_header_key
WHEN MATCHED THEN
    UPDATE SET 
        tors.order_release_status_key = sors.order_release_status_key,
        tors.order_release_key = sors.order_release_key,
        tors.order_line_key = sors.order_line_key,
        tors.order_header_key = sors.order_header_key,
        tors.status = sors.status,
        tors.status_date = sors.status_date,
        tors.status_quantity = sors.status_quantity,
        tors.pipeline_key = sors.pipeline_key,
        tors.order_line_schedule_key = sors.order_line_schedule_key,
        tors.total_quantity = sors.total_quantity,
        tors.expected_shipment_date = sors.expected_shipment_date,
        tors.chained_to_order_line_key = sors.chained_to_order_line_key,
        tors.chained_to_order_header_key = sors.chained_to_order_header_key,
        tors.createts = sors.createts,
        tors.modifyts = sors.modifyts,
        tors.createuserid = sors.createuserid,
        tors.modifyuserid = sors.modifyuserid,
        tors.createprogid = sors.createprogid,
        tors.modifyprogid = sors.modifyprogid,
        tors.lockid = sors.lockid,
        tors.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        order_release_status_key,
        order_release_key,
        order_line_key,
        order_header_key,
        status,
        status_date,
        status_quantity,
        pipeline_key,
        order_line_schedule_key,
        total_quantity,
        expected_shipment_date,
        chained_to_order_line_key,
        chained_to_order_header_key,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        lockid,
        inserted_date
    )
    VALUES (
        sors.order_release_status_key,
        sors.order_release_key,
        sors.order_line_key,
        sors.order_header_key,
        sors.status,
        sors.status_date,
        sors.status_quantity,
        sors.pipeline_key,
        sors.order_line_schedule_key,
        sors.total_quantity,
        sors.expected_shipment_date,
        sors.chained_to_order_line_key,
        sors.chained_to_order_header_key,
        sors.createts,
        sors.modifyts,
        sors.createuserid,
        sors.modifyuserid,
        sors.createprogid,
        sors.modifyprogid,
        sors.lockid,
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempOrderReleaseStatus(
    order_release_status_key,
    order_release_key,
    order_line_key,
    order_header_key,
    status,
    status_date,
    status_quantity,
    pipeline_key,
    order_line_schedule_key,
    total_quantity,
    expected_shipment_date,
    chained_to_order_line_key,
    chained_to_order_header_key,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    Revision
)
SELECT 
    tors.order_release_status_key,
    tors.order_release_key,
    tors.order_line_key,
    tors.order_header_key,
    tors.status,
    tors.status_date,
    tors.status_quantity,
    tors.pipeline_key,
    tors.order_line_schedule_key,
    tors.total_quantity,
    tors.expected_shipment_date,
    tors.chained_to_order_line_key,
    tors.chained_to_order_header_key,
    tors.createts,
    tors.modifyts,
    tors.createuserid,
    tors.modifyuserid,
    tors.createprogid,
    tors.modifyprogid,
    tors.lockid,
    CURRENT_TIMESTAMP,
    1
FROM txn_order_release_status tors
WHERE inserted_date >= :processedDate or modified_date >= :processedDate
;

UPDATE TempOrderReleaseStatus
SET Revision = COALESCE(aot.revision, 0) + 1
FROM (
    SELECT
        MAX(aot.revision) AS revision,
        aot.order_release_status_key,
        aot.order_line_key,
        aot.order_header_key
    FROM ANALYTICS.audit_order_release_status AS aot
    INNER JOIN TempOrderReleaseStatus AS ttd
    ON ttd.order_release_status_key = aot.order_release_status_key
    AND ttd.order_line_key = aot.order_line_key
    AND ttd.order_header_key = aot.order_header_key
    GROUP BY
        aot.order_release_status_key,
        aot.order_line_key,
        aot.order_header_key
) AS aot
WHERE TempOrderReleaseStatus.order_release_status_key = aot.order_release_status_key
AND TempOrderReleaseStatus.order_line_key = aot.order_line_key
AND TempOrderReleaseStatus.order_header_key = aot.order_header_key;

INSERT INTO ANALYTICS.audit_order_release_status (
    order_release_status_key,
    order_release_key,
    order_line_key,
    order_header_key,
    status,
    status_date,
    status_quantity,
    pipeline_key,
    order_line_schedule_key,
    total_quantity,
    expected_shipment_date,
    chained_to_order_line_key,
    chained_to_order_header_key,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    inserted_date,
    Revision
)
SELECT
    stg.order_release_status_key,
    stg.order_release_key,
    stg.order_line_key,
    stg.order_header_key,
    stg.status,
    stg.status_date,
    stg.status_quantity,
    stg.pipeline_key,
    stg.order_line_schedule_key,
    stg.total_quantity,
    stg.expected_shipment_date,
    stg.chained_to_order_line_key,
    stg.chained_to_order_header_key,
    stg.createts,
    stg.modifyts,
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    CURRENT_TIMESTAMP(),
    ord.Revision
FROM TRANSFORMED.stg_ORDER_release_status_part2 stg
INNER JOIN TempOrderReleaseStatus ord
ON ord.order_release_status_key = stg.order_release_status_key
AND ord.order_line_key = stg.order_line_key
AND ord.order_header_key = stg.order_header_key;

SELECT COUNT(*) INTO :processedRecordCount
FROM TempOrderReleaseStatus;

UPDATE RAW.raw_ORDER_release_status_part2 
SET
    processing_status = ''Processed'',
    processing_comment = '''',
    processing_errortype = ''''
FROM RAW.raw_ORDER_release_status_part2 roh
INNER JOIN TRANSFORMED.stg_ORDER_release_status_part2 rod 
    ON rod.ORDER_RELEASE_STATUS_KEY = roh.ORDER_RELEASE_STATUS_KEY
    AND roh.modifyts = rod.modifyts
INNER JOIN TempOrderReleaseStatus tol 
    ON tol.order_release_status_key = rod.ORDER_RELEASE_STATUS_KEY 
    AND roh.modifyts = tol.modifyts
WHERE roh.processing_status IN (''Pending'', ''Failed'');

UPDATE ANALYTICS.log_files_import_status lofis
SET
    processed = :processedRecordCount,
    status = ''Success''
WHERE file_name = ''YFS_ORDER_RELEASE_STATUS_PART2''
AND raw_table = ''raw_ORDER_release_status_part2'';

DROP TABLE IF EXISTS TempOrderReleaseStatus;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            ''upsert'',
            ''COMPLETED'',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            ''upsert completed successfully''
        );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
COMMIT;

COMMIT;
RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = ''Failed''
        WHERE file_name = ''YFS_ORDER_RELEASE_STATUS_PART2'';
            -- Return error message
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
	RETURN error_object;
END';
