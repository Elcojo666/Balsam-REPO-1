
CREATE OR REPLACE PROCEDURE ANALYTICS.USP_GTIN_DATA_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

UPDATE log_files_import_status
SET processed = :processedRecordCount,
    raw_table = 'raw_order_gtin_data'
WHERE file_name = 'EXTN_GTIN_DATA';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

CREATE OR REPLACE TEMPORARY TABLE insertedGtinRecords
(
    GTIN_KEY STRING, 
    txn_id STRING,
    revision INT
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO   ANALYTICS.txn_gtin_data ts
USING (
    SELECT DISTINCT 
        GTIN_KEY,
        RESERVATION_REFERENCE,
        SKU_ITEM_ID,
        SHIP_NODE,
        UPC_ITEM_ID,
        TRY_TO_NUMBER(QUANTITY) AS QUANTITY,
        SCHEDULED_ORDER_LINE_KEY,
        ORDER_NO,
        ORDERLINE_RELEASE_KEY,
        PRIME_LINE_NO,
        SUB_LINE_NO,
        UNIT_OF_MEASURE,
        PRODUCT_CLASS,
        SEGMENT_TYPE,
        TRY_TO_TIMESTAMP(LEFT(RESERVATION_EXPIRY_TIME,14),'YYYYMMDDHHMISS') AS RESERVATION_EXPIRY_TIME,
        INTERNAL_STATUS,
        TRY_TO_TIMESTAMP(CREATETS,'YYYYMMDDHHMISS') AS CREATETS,
        TRY_TO_TIMESTAMP(MODIFYTS,'YYYYMMDDHHMISS') AS MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID,
        txn_id
    FROM TRANSFORMED.stg_order_gtin_data
) ss
ON ts.GTIN_KEY = ss.GTIN_KEY
WHEN MATCHED THEN
    UPDATE SET
        ts.GTIN_KEY = ss.GTIN_KEY,
        ts.RESERVATION_REFERENCE = ss.RESERVATION_REFERENCE,
        ts.SKU_ITEM_ID = ss.SKU_ITEM_ID,
        ts.SHIP_NODE = ss.SHIP_NODE,
        ts.UPC_ITEM_ID = ss.UPC_ITEM_ID,
        ts.QUANTITY = ss.QUANTITY,
        ts.SCHEDULED_ORDER_LINE_KEY = ss.SCHEDULED_ORDER_LINE_KEY,
        ts.ORDER_NO = ss.ORDER_NO,
        ts.ORDERLINE_RELEASE_KEY = ss.ORDERLINE_RELEASE_KEY,
        ts.PRIME_LINE_NO = ss.PRIME_LINE_NO,
        ts.SUB_LINE_NO = ss.SUB_LINE_NO,
        ts.UNIT_OF_MEASURE = ss.UNIT_OF_MEASURE,
        ts.PRODUCT_CLASS = ss.PRODUCT_CLASS,
        ts.SEGMENT_TYPE = ss.SEGMENT_TYPE,
        ts.RESERVATION_EXPIRY_TIME = ss.RESERVATION_EXPIRY_TIME,
        ts.INTERNAL_STATUS = ss.INTERNAL_STATUS,
        ts.CREATETS = ss.CREATETS,
        ts.MODIFYTS = ss.MODIFYTS,
        ts.CREATEUSERID = ss.CREATEUSERID,
        ts.MODIFYUSERID = ss.MODIFYUSERID,
        ts.CREATEPROGID = ss.CREATEPROGID,
        ts.MODIFYPROGID = ss.MODIFYPROGID,
        ts.LOCKID = ss.LOCKID,
        ts.modified_date = CURRENT_TIMESTAMP
WHEN NOT MATCHED THEN
    INSERT (
        GTIN_KEY,
        RESERVATION_REFERENCE,
        SKU_ITEM_ID,
        SHIP_NODE,
        UPC_ITEM_ID,
        QUANTITY,
        SCHEDULED_ORDER_LINE_KEY,
        ORDER_NO,
        ORDERLINE_RELEASE_KEY,
        PRIME_LINE_NO,
        SUB_LINE_NO,
        UNIT_OF_MEASURE,
        PRODUCT_CLASS,
        SEGMENT_TYPE,
        RESERVATION_EXPIRY_TIME,
        INTERNAL_STATUS,
        CREATETS,
        MODIFYTS,
        CREATEUSERID,
        MODIFYUSERID,
        CREATEPROGID,
        MODIFYPROGID,
        LOCKID,
        inserted_date
    ) 
    VALUES (
        ss.GTIN_KEY,
        ss.RESERVATION_REFERENCE,
        ss.SKU_ITEM_ID,
        ss.SHIP_NODE,
        ss.UPC_ITEM_ID,
        ss.QUANTITY,
        ss.SCHEDULED_ORDER_LINE_KEY,
        ss.ORDER_NO,
        ss.ORDERLINE_RELEASE_KEY,
        ss.PRIME_LINE_NO,
        ss.SUB_LINE_NO,
        ss.UNIT_OF_MEASURE,
        ss.PRODUCT_CLASS,
        ss.SEGMENT_TYPE,
        ss.RESERVATION_EXPIRY_TIME,
        ss.INTERNAL_STATUS,
        ss.CREATETS,
        ss.MODIFYTS,
        ss.CREATEUSERID,
        ss.MODIFYUSERID,
        ss.CREATEPROGID,
        ss.MODIFYPROGID,
        ss.LOCKID,
        CURRENT_TIMESTAMP
    );

INSERT INTO insertedGtinRecords
SELECT 
    t.GTIN_KEY,
    s.txn_id,
    1
FROM ANALYTICS.txn_gtin_data t
    INNER JOIN TRANSFORMED.stg_order_gtin_data s
        on t.GTIN_KEY = s.GTIN_KEY
WHERE t.inserted_date >= :processedDate or t.modified_date >= :processedDate;


UPDATE insertedGtinRecords AS ttd
SET ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS INT)
FROM (
    SELECT
        MAX(aot.revision) AS revision,
        aot.GTIN_KEY
    FROM
        ANALYTICS.audit_gtin_data AS aot
        INNER JOIN insertedGtinRecords AS ttd ON ttd.GTIN_KEY = aot.GTIN_KEY
    GROUP BY
        aot.GTIN_KEY
) AS aot
WHERE ttd.GTIN_KEY = aot.GTIN_KEY;

INSERT INTO ANALYTICS.audit_gtin_data (
    GTIN_KEY,
    RESERVATION_REFERENCE,
    SKU_ITEM_ID,
    SHIP_NODE,
    UPC_ITEM_ID,
    QUANTITY,
    SCHEDULED_ORDER_LINE_KEY,
    ORDER_NO,
    ORDERLINE_RELEASE_KEY,
    PRIME_LINE_NO,
    SUB_LINE_NO,
    UNIT_OF_MEASURE,
    PRODUCT_CLASS,
    SEGMENT_TYPE,
    RESERVATION_EXPIRY_TIME,
    INTERNAL_STATUS,
    CREATETS,
    MODIFYTS,
    CREATEUSERID,
    MODIFYUSERID,
    CREATEPROGID,
    MODIFYPROGID,
    LOCKID,
    inserted_date,
    revision
)
SELECT 
    ss.GTIN_KEY,
    ss.RESERVATION_REFERENCE,
    ss.SKU_ITEM_ID,
    ss.SHIP_NODE,
    ss.UPC_ITEM_ID,
    TRY_TO_NUMBER(ss.QUANTITY),
    ss.SCHEDULED_ORDER_LINE_KEY,
    ss.ORDER_NO,
    ss.ORDERLINE_RELEASE_KEY,
    ss.PRIME_LINE_NO,
    ss.SUB_LINE_NO,
    ss.UNIT_OF_MEASURE,
    ss.PRODUCT_CLASS,
    ss.SEGMENT_TYPE,
    TRY_TO_TIMESTAMP(LEFT(SS.RESERVATION_EXPIRY_TIME,14),'YYYYMMDDHHMISS') AS RESERVATION_EXPIRY_TIME,
        SS.INTERNAL_STATUS,
        TRY_TO_TIMESTAMP(SS.CREATETS,'YYYYMMDDHHMISS') AS CREATETS,
        TRY_TO_TIMESTAMP(SS.MODIFYTS,'YYYYMMDDHHMISS') AS MODIFYTS,
    ss.CREATEUSERID,
    ss.MODIFYUSERID,
    ss.CREATEPROGID,
    ss.MODIFYPROGID,
    ss.LOCKID,
    CURRENT_TIMESTAMP,
    ord.Revision
FROM TRANSFORMED.stg_order_gtin_data ss
INNER JOIN insertedGtinRecords ord ON ord.GTIN_KEY = ss.GTIN_KEY;

UPDATE RAW.raw_order_gtin_data AS ros
SET
    ros.processing_status = 'Processed',
    ros.processing_comment = '',
    ros.processing_errortype = ''
FROM insertedGtinRecords AS tos
WHERE tos.GTIN_KEY = ros.GTIN_KEY
  AND tos.txn_id = ros.txn_id;


SELECT COUNT(*)
INTO :processedRecordCount
FROM insertedGtinRecords;


SELECT COUNT(*)
INTO :toBeProcessedRecordCount
FROM TRANSFORMED.stg_order_gtin_data;

UPDATE log_files_import_status
SET
    processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = 'Success'
WHERE
    file_name = 'EXTN_GTIN_DATA';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

COMMIT;

RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'EXTN_GTIN_DATA';
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	
	RETURN error_object;
END;