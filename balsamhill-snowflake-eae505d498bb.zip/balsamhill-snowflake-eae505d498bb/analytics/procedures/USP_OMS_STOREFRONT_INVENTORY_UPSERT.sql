USE DATABASE DEV; 

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_OMS_STOREFRONT_INVENTORY_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
  invalid_record_count INTEGER DEFAULT 0;
  message STRING DEFAULT '''';
  -- v_last_pickup_time TIMESTAMP_NTZ;
  -- v_current_time TIMESTAMP_NTZ;
  error_object OBJECT;
  --PIPELINE_NAME STRING DEFAULT '''';
  START_TIME_PROC TIMESTAMP_NTZ(9);

BEGIN
   
 -- PIPELINE_NAME := ''OMS-INVENTORY'';
  -- Insert into log pipeline tasks execution detail

  start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);
 
     CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''STARTED'',
        :start_time_proc,
        NULL,
        ''upsert started''
    );

  -- Get the current timestamp
  -- v_current_time := CURRENT_TIMESTAMP();

  -- -- Retrieve the last pickup time from the staging table
  -- SELECT COALESCE(MAX(last_pickup_time), ''1970-01-01 00:00:00''::TIMESTAMP_NTZ)
  -- INTO :v_last_pickup_time
  -- FROM TRANSFORMED.stg_storefront_inventory;

  -- Call the insert procedure
  CALL TRANSFORMED.usp_oms_insert_stg_storefront_inventory();

  -- Create a temporary table
  CREATE  OR REPLACE TEMPORARY TABLE temp_api_oms_storefront_inventory (
    sku STRING,
    organizationCode STRING,
    available INTEGER,
    alertRaisedOn TIMESTAMP_NTZ,
    futureAvailable INTEGER,
    channel STRING,
    fk_skuproductid INTEGER,
    fk_brandid INTEGER,
    locale STRING,
    fk_countryid INTEGER,
    product_name STRING,
    file_name STRING,
    ingestion_time TIMESTAMP_NTZ,
    error_message STRING
  );

  -- Insert data into the temp table
  INSERT INTO temp_api_oms_storefront_inventory (
    sku,
    organizationCode,
    available,
    alertRaisedOn,
    futureAvailable,
    channel,
    file_name,
    ingestion_time
    
  )
  SELECT
    sku,
    organization_code,
    available,
    alert_raised_on,
    future_available,
    channel,
    file_name,
    ingestion_time

        
  FROM
    TRANSFORMED.stg_storefront_inventory AS stg;
 
  -- Update the temp table with brand information
  UPDATE temp_api_oms_storefront_inventory AS tois
  SET
    fk_brandid = b.pk_brandid,
    locale = b.locale
  FROM
    MASTER.dim_brand AS b
  WHERE
    b.BrandCodeForPOTracker = UPPER(REPLACE(tois.organizationCode, ''-'', ''''));

  -- Update the temp table with product information
  UPDATE temp_api_oms_storefront_inventory AS tois
  SET
    fk_skuproductid = sku.pk_skuproductid,
    product_name = sku.bh_product_name
  FROM
    analytics.sku_product_locale AS sku
  WHERE
    sku.sku_code = tois.sku AND sku.locale = tois.locale;

  -- Update the temp table with country information
  UPDATE temp_api_oms_storefront_inventory AS tois
  SET
    fk_countryid = dc.pk_countryid
  FROM
    MASTER.dim_country AS dc
  WHERE
    UPPER(SUBSTRING(tois.organizationCode, 4, 4)) = UPPER(dc.country_code);


  -- Check for invalid records
  SELECT COUNT(*)
  INTO :invalid_record_count
  FROM temp_api_oms_storefront_inventory
  WHERE fk_skuproductid IS NULL OR fk_brandid IS NULL;

  IF (:invalid_record_count > 0) THEN
    -- Log errors
    message := ''Error: '' || invalid_record_count || '' Inputs are having Errors'';
     UPDATE temp_api_oms_storefront_inventory AS tois
      SET
        error_message = ''Error: sku Not Found in the dimproduct_locale table'' 
        WHERE fk_skuproductid IS NULL; 
    UPDATE temp_api_oms_storefront_inventory AS tois
      SET
        error_message = ''Error: organizationCode Not Found'' 
        WHERE fk_brandid IS NULL;


      MERGE INTO  RAW.raw_clean_storefront_inventory AS tgt
      USING (select * from temp_api_oms_storefront_inventory WHERE fk_skuproductid IS NULL OR fk_brandid IS NULL) AS src
        ON tgt.sku = src.sku
           AND tgt.channel = src.channel
           AND tgt.organization_Code = src.organizationCode
           AND tgt.ingestion_time = src.ingestion_time
           AND tgt.alert_raised_on = src.alertRaisedOn 
           
        WHEN MATCHED THEN
           UPDATE SET tgt.processing_status = ''Failed'',
                      tgt.processing_comment = src.error_message;
           

     
      DELETE FROM temp_api_oms_storefront_inventory
      WHERE fk_skuproductid IS NULL OR fk_brandid IS NULL;
      END IF;
      
    -- Create a final temp table for merge
    CREATE  OR REPLACE TEMPORARY TABLE temp_storefront_inventory_platform AS
    SELECT DISTINCT
      ''OMS'' AS Source,
      channel AS channel,
      sku AS sku_code,
      CONCAT(organizationCode, ''ProductCatalog'') AS catalog_version,
      CASE
        WHEN organizationCode = ''bh-au'' THEN ''10''
        WHEN organizationCode = ''bh-de'' THEN ''8''
        WHEN organizationCode = ''bh-fr'' THEN ''7''
        WHEN organizationCode = ''bh-us'' THEN ''1''
        WHEN organizationCode = ''bh-uk'' THEN ''6''
        WHEN organizationCode = ''bh-ca'' THEN ''19''
        WHEN channel = ''AMAZON-TT'' THEN ''2'' 
        WHEN channel = ''AMAZON-TC'' THEN ''4'' 
        ELSE NULL
      END AS BrandID,
      fk_countryid,
      fk_skuproductid,
      CASE
        WHEN organizationCode = ''bh-au'' THEN 715
        WHEN organizationCode = ''bh-de'' THEN 716
        WHEN organizationCode = ''bh-fr'' THEN 717
        WHEN organizationCode = ''bh-uk'' THEN 719
        ELSE 718
      END AS fk_inputfileid,
      CASE
        WHEN channel = ''WEBSITE'' THEN 3
        WHEN CHANNEL = ''AMAZON-BH'' THEN 6
        WHEN channel = ''WILLIAMSSONOMA'' THEN 17
        WHEN channel = ''AMAZON-TT'' THEN 6
        WHEN channel = ''POTTERYBARN'' THEN 19
        WHEN channel = ''SAKS'' THEN 22
        WHEN channel = ''WAYFAIR'' THEN 11
        WHEN channel = ''NORDSTROM'' THEN 14
        WHEN channel = ''NORDSTROM-RACK'' THEN 15
        WHEN channel = ''SERENAANDLILY'' THEN 28
        WHEN channel = ''WALMART'' THEN 26
        WHEN channel = ''FEEDONOMICS'' THEN 29
        WHEN channel = ''AMAZON-TC'' THEN 6
        ELSE NULL
        END as platformid,
      102 AS fk_filesourceid,
      product_name,
      available AS stock,
      ''StockLevelStatus'' AS stock_level_status_type,
      CASE
        WHEN available > 0 THEN ''InStock''
        ELSE ''outOfStock''
      END AS stock_level_status_code,
      futureAvailable AS expected_receipts,
      1::NUMBER(10, 0) AS revision
    FROM temp_api_oms_storefront_inventory;
    
   CREATE OR REPLACE TEMPORARY TABLE temp_storefront_inventory AS
    SELECT DISTINCT
       Source,
       channel,
       sku_code,
      catalog_version,
       BrandID,
      fk_countryid,
      fk_skuproductid,
      fk_inputfileid,
      platformid,
      fk_filesourceid,
       product_name,
       stock,
       stock_level_status_type,
       stock_level_status_code,
        expected_receipts,
        revision,
        ds.pk_sourceid AS SourceID
    FROM 
        temp_storefront_inventory_platform tsip
    LEFT JOIN 
        MASTER.dim_source ds
    ON 
        ds.fk_platformid = tsip.platformid 
        AND ds.fk_brandid = tsip.BrandID;
        
     -- CREATE TEMPORARY TABLE temp_distinct_storefront_inventory AS
     -- SELECT * FROM temp_storefront_inventory;
  
    -- Merge the data into txn_storefront_inventory table
    MERGE INTO ANALYTICS.txn_storefront_inventory AS Target
    USING  temp_storefront_inventory AS Source
    ON Target.sku_code = Source.sku_code AND Target.catalog_version = Source.catalog_version AND Target.channel = 
    Source.channel
    WHEN MATCHED THEN
      UPDATE SET
        Target.Source = Source.Source,
        Target.channel = Source.channel,
        Target.SourceID = Source.SourceID,
        Target.catalog_version = Source.catalog_version,
        Target.BrandID = Source.BrandID,
        Target.fk_countryid = Source.fk_countryid,
        Target.fk_skuproductid = Source.fk_skuproductid,
        Target.fk_inputfileid = Source.fk_inputfileid,
        Target.fk_filesourceid = Source.fk_filesourceid,
        Target.product_name = Source.product_name,
        Target.stock = Source.stock,
        Target.stock_level_status_type = Source.stock_level_status_type,
        Target.stock_level_status_code = Source.stock_level_status_code,
        Target.expected_receipts = Source.expected_receipts,
        Target.last_updated_date = CURRENT_TIMESTAMP(),
        Target.oms_stock = Source.stock,
        Target.oms_modified_date = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
      INSERT (
        Source,
        channel,
        SourceID,
        sku_code,
        catalog_version,
        BrandID,
        fk_countryid,
        fk_skuproductid,
        fk_inputfileid,
        fk_filesourceid,
        product_name,
        stock,
        stock_level_status_type,
        stock_level_status_code,
        expected_receipts,
        inserted_date,
        last_updated_date,
        oms_stock,
        oms_modified_date,
        hybris_stock,
        hybris_modified_date
      )
      VALUES (
        Source.Source,
        Source.channel,
        Source.SourceID,
        Source.sku_code,
        Source.catalog_version,
        Source.BrandID,
        Source.fk_countryid,
        Source.fk_skuproductid,
        Source.fk_inputfileid,
        Source.fk_filesourceid,
        Source.product_name,
        Source.stock,
        Source.stock_level_status_type,
        Source.stock_level_status_code,
        Source.expected_receipts,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        Source.stock,
        CURRENT_TIMESTAMP(),
        NULL,
        NULL
      );

    CREATE TEMPORARY TABLE TEMP_REVISIONS AS
    SELECT
        aot.sku_code,
        aot.brandId,
        aot.channel,
        COALESCE(MAX(aot.revision), 0) + 1 AS new_revision
    FROM ANALYTICS.audit_storefront_inventory AS aot
    JOIN temp_storefront_inventory AS ttd
        ON ttd.sku_code = aot.sku_code
        AND ttd.brandId = aot.brandId
        AND ttd.channel = aot.channel
    GROUP BY
        aot.sku_code,
        aot.brandId,
        aot.channel
    ;

    UPDATE temp_storefront_inventory AS ttd
    SET ttd.revision = tr.new_revision
    FROM TEMP_REVISIONS AS tr
    WHERE
        ttd.sku_code = tr.sku_code
        AND ttd.brandId = tr.brandId
        AND ttd.channel = tr.channel
    ;

    -- Insert into audit storefront inventory
    INSERT INTO ANALYTICS.audit_storefront_inventory (
      Source,
      channel,
      sku_code,
      SourceID,
      catalog_version,
      BrandID,
      fk_countryid,
      fk_skuproductid,
      fk_inputfileid,
      fk_filesourceid,
      product_name,
      stock,
      stock_level_status_type,
      stock_level_status_code,
      expected_receipts,
      inserted_date,
      revision
    )
    SELECT
      Source,
      channel,
      sku_code,
      SourceID,
      catalog_version,
      BrandID,
      fk_countryid,
      fk_skuproductid,
      fk_inputfileid,
      fk_filesourceid,
      product_name,
      stock,
      stock_level_status_type,
      stock_level_status_code,
      expected_receipts,
      CURRENT_TIMESTAMP(),
      revision
    FROM  temp_storefront_inventory;

      MERGE INTO RAW.raw_clean_storefront_inventory AS tgt
      USING temp_api_oms_storefront_inventory AS src
        ON tgt.sku = src.sku
           AND tgt.channel = src.channel
           AND tgt.organization_Code = src.organizationCode
           AND tgt.ingestion_time = src.ingestion_time
           AND tgt.alert_raised_on = src.alertRaisedOn
        WHEN MATCHED THEN
           UPDATE SET tgt.processing_status = ''Processed'',
          tgt.processing_comment = '''';
 
    -- Log successful completion
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''COMPLETED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        ''Upsert completed successfully''
    );
    SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);
    RETURN ''Success'';
EXCEPTION
  WHEN statement_error THEN
    ROLLBACK;
    MERGE INTO RAW.raw_clean_storefront_inventory AS tgt
      USING temp_api_oms_storefront_inventory AS src
        ON tgt.sku = src.sku
           AND tgt.channel = src.channel
           AND tgt.organization_Code = src.organizationCode
           AND tgt.ingestion_time = src.ingestion_time
           AND tgt.alert_raised_on = src.alertRaisedOn
        WHEN MATCHED THEN
           UPDATE SET tgt.processing_status = ''Failed'';

 error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);
    
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );
    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);
 
 
    RETURN ''Error occured: ''||:pipeline_name||'' : ''||sqlerrm;
   
END;
';
