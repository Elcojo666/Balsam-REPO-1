USE DATABASE DEV;
USE SCHEMA analytics;

CREATE OR REPLACE PROCEDURE analytics.usp_merge_gladly_conversation(pipeline_name VARCHAR DEFAULT 'gladly_conversation')
    RETURNS STRING
    LANGUAGE SQL
AS
DECLARE
    pipeline_stage_name VARCHAR := 'merge';
    start_time          TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    completed_message   VARCHAR;
    error_object        VARIANT;
BEGIN
    SYSTEM$LOG('TRACE', 'SP STARTED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'started',
            :start_time,
            NULL,
            :pipeline_stage_name || ' ' || 'started');

    BEGIN
        MERGE INTO analytics.txn_gladly_conversation AS target
            USING (
                SELECT *
                FROM transformed.stage_gladly_conversation
            ) AS source
            ON source.id = target.id
            WHEN MATCHED AND (source.conversation_id <> target.conversation_id
                OR source.content_type <> target.content_type
                OR source.content_to <> target.content_to
                OR source.content_from <> target.content_from
                OR source.content_subject <> target.content_subject
                OR source.content_content <> target.content_content
                OR source.content_body <> target.content_body
                OR source.content_status <> target.content_status
                OR source.content_started_at <> target.content_started_at
                OR source.content_answered_at <> target.content_answered_at
                OR source.content_completed_at <> target.content_completed_at
                OR source.content_recording_url <> target.content_recording_url
                OR source.content_recording_status <> target.content_recording_status
                OR source.content_recording_duration <> target.content_recording_duration
                OR source.content_message_type <> target.content_message_type
                OR source.content_session_id <> target.content_session_id
                OR source.content_added_topic_ids <> target.content_added_topic_ids
                OR source.customer_id <> target.customer_id
                OR source.initiator_type <> target.initiator_type
                OR source.initiator_id <> target.initiator_id
                OR source.timestamp <> target.timestamp
                OR source.responder_type <> target.responder_type
                OR source.responder_id <> target.responder_id)
                THEN
                UPDATE SET
                    conversation_id = source.conversation_id,
                    content_type = source.content_type,
                    content_to = source.content_to,
                    content_from = source.content_from,
                    content_subject = source.content_subject,
                    content_content = source.content_content,
                    content_body = source.content_body,
                    content_status = source.content_status,
                    content_started_at = source.content_started_at,
                    content_answered_at = source.content_answered_at,
                    content_completed_at = source.content_completed_at,
                    content_recording_url = source.content_recording_url,
                    content_recording_status = source.content_recording_status,
                    content_recording_duration = source.content_recording_duration,
                    content_message_type = source.content_message_type,
                    content_session_id = source.content_session_id,
                    content_added_topic_ids = source.content_added_topic_ids,
                    customer_id = source.customer_id,
                    initiator_type = source.initiator_type,
                    initiator_id = source.initiator_id,
                    timestamp = source.timestamp,
                    responder_type = source.responder_type,
                    responder_id = source.responder_id,
                    updated_at = CURRENT_TIMESTAMP()
            WHEN NOT MATCHED THEN
                INSERT (
                        id,
                        conversation_id,
                        content_type,
                        content_to,
                        content_from,
                        content_subject,
                        content_content,
                        content_body,
                        content_status,
                        content_started_at,
                        content_answered_at,
                        content_completed_at,
                        content_recording_url,
                        content_recording_status,
                        content_recording_duration,
                        content_message_type,
                        content_session_id,
                        content_added_topic_ids,
                        customer_id,
                        initiator_type,
                        initiator_id,
                        timestamp,
                        responder_type,
                        responder_id
                    )
                    VALUES (
                       source.id,
                       source.conversation_id,
                       source.content_type,
                       source.content_to,
                       source.content_from,
                       source.content_subject,
                       source.content_content,
                       source.content_body,
                       source.content_status,
                       source.content_started_at,
                       source.content_answered_at,
                       source.content_completed_at,
                       source.content_recording_url,
                       source.content_recording_status,
                       source.content_recording_duration,
                       source.content_message_type,
                       source.content_session_id,
                       source.content_added_topic_ids,
                       source.customer_id,
                       source.initiator_type,
                       source.initiator_id,
                       source.timestamp,
                       source.responder_type,
                       source.responder_id
                           );

        LET staged_events_count VARCHAR := (
            SELECT COUNT(1)
            FROM analytics.txn_gladly_conversation
            WHERE updated_at >= :start_time
        );

        completed_message := 'Merging completed successfully. ' || 'Merged records: ' || :staged_events_count;

        COMMIT;
    EXCEPTION
        WHEN statement_error THEN
            ROLLBACK;

            SYSTEM$LOG('ERROR', 'SP FAILED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

            error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                             'SQLCODE', sqlcode,
                                             'SQLERRM', sqlerrm,
                                             'SQLSTATE', sqlstate);

            CALL transformed.insert_into_log_pipeline_tasks_execution_details(
                    :pipeline_name,
                    :pipeline_stage_name,
                    'failed',
                    :start_time,
                    CURRENT_TIMESTAMP(),
                    TO_JSON(:error_object));

            RETURN error_object;
    END;

    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :pipeline_name,
            :pipeline_stage_name,
            'completed',
            :start_time,
            CURRENT_TIMESTAMP(),
            :completed_message);

    SYSTEM$LOG('TRACE', 'SP COMPLETED - '|| :pipeline_name || ' - ' || :pipeline_stage_name);

    RETURN :start_time || ' - ' || :completed_message;
END;

ALTER PROCEDURE analytics.usp_merge_gladly_conversation(VARCHAR)
    SET LOG_LEVEL = TRACE, TRACE_LEVEL = ALWAYS;

SELECT *
FROM transformed.log_pipeline_tasks_execution_details
WHERE pipeline_name = 'gladly_conversation'
AND start_time >= CURRENT_DATE
ORDER BY start_time DESC