

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_LINE_CHARGES_UPSERT_("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
        processedRecordCount NUMBER DEFAULT 0;
        processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );
    -- Create temp table
    CREATE OR REPLACE TEMP TABLE TempLineCharges(
        line_charges_key VARCHAR,
        header_key VARCHAR,
        line_key VARCHAR,
        record_type VARCHAR,
        charge_category VARCHAR,
        charge_name VARCHAR,
        reference VARCHAR,
        CHARGEPERUNIT FLOAT,
	    CHARGEPERLINE FLOAT,
	    CHARGEAMOUNT FLOAT,
	    INVOICED_CHARGE_PER_LINE FLOAT,
	    INVOICED_EXTENDED_CHARGE FLOAT,
	    ORIGINAL_CHARGEPERUNIT FLOAT,
	    ORIGINAL_CHARGEPERLINE FLOAT,
        is_manual VARCHAR,
        createts TIMESTAMP,
        modifyts TIMESTAMP,
        createuserid VARCHAR,
        modifyuserid VARCHAR,
        createprogid VARCHAR,
        modifyprogid VARCHAR,
        lockid VARCHAR,
        extn_charge_description VARCHAR,
        extn_coupon_code VARCHAR,
        inserted_date TIMESTAMP,
        modified_date TIMESTAMP,
        revision INT
    );
processedDate := CURRENT_TIMESTAMP(); 

    -- MERGE statement
    MERGE INTO  ANALYTICS.txn_order_line_charges tlc
    USING (
        SELECT 
            stg.line_charges_key,
            stg.header_key,
            stg.line_key,
            stg.record_type,
            stg.charge_category,
            stg.charge_name,
            stg.reference,
            TRY_CAST(stg.chargeperunit AS FLOAT) AS chargeperunit,
            TRY_CAST(stg.chargeperline AS FLOAT) AS chargeperline,
            TRY_CAST(stg.chargeamount AS FLOAT) AS chargeamount,
            TRY_CAST(stg.invoiced_charge_per_line AS FLOAT) AS invoiced_charge_per_line,
            TRY_CAST(stg.invoiced_extended_charge AS FLOAT) AS invoiced_extended_charge,
            TRY_CAST(stg.original_chargeperunit AS FLOAT) AS original_chargeperunit,
            TRY_CAST(stg.original_chargeperline AS FLOAT) AS original_chargeperline,
            stg.is_manual,
            TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS') AS createts,
            TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS') AS modifyts,
            stg.createuserid,
            stg.modifyuserid,
            stg.createprogid,
            stg.modifyprogid,
            stg.lockid,
            stg.extn_charge_description,
            stg.extn_coupon_code
        FROM  Transformed.stg_order_line_charges stg
        INNER JOIN raw.raw_order_line_charges r
            ON r.line_charges_key = stg.line_charges_key
            AND r.modifyts = stg.modifyts
            AND r.processing_status = 'Processed'
    ) slc
    ON tlc.line_charges_key = slc.line_charges_key
    WHEN MATCHED THEN
        UPDATE SET
            tlc.line_charges_key = slc.line_charges_key,
            tlc.header_key = slc.header_key,
            tlc.line_key = slc.line_key,
            tlc.record_type = slc.record_type,
            tlc.charge_category = slc.charge_category,
            tlc.charge_name = slc.charge_name,
            tlc.reference = slc.reference,
            tlc.chargeperunit = slc.chargeperunit,
            tlc.chargeperline = slc.chargeperline,
            tlc.chargeamount = slc.chargeamount,
            tlc.invoiced_charge_per_line = slc.invoiced_charge_per_line,
            tlc.invoiced_extended_charge = slc.invoiced_extended_charge,
            tlc.original_chargeperunit = slc.original_chargeperunit,
            tlc.original_chargeperline = slc.original_chargeperline,
            tlc.is_manual = slc.is_manual,
            tlc.createts = slc.createts,
            tlc.modifyts = slc.modifyts,
            tlc.createuserid = slc.createuserid,
            tlc.modifyuserid = slc.modifyuserid,
            tlc.createprogid = slc.createprogid,
            tlc.modifyprogid = slc.modifyprogid,
            tlc.lockid = slc.lockid,
            tlc.extn_charge_description = slc.extn_charge_description,
            tlc.extn_coupon_code = slc.extn_coupon_code,
            tlc.modified_date = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
            line_charges_key, header_key, line_key, record_type, charge_category, charge_name, reference, 
            chargeperunit, chargeperline, chargeamount, invoiced_charge_per_line, invoiced_extended_charge, 
            original_chargeperunit, original_chargeperline, is_manual, createts, modifyts, createuserid, 
            modifyuserid, createprogid, modifyprogid, lockid, extn_charge_description, extn_coupon_code, inserted_date
        ) VALUES (
            slc.line_charges_key, slc.header_key, slc.line_key, slc.record_type, slc.charge_category, slc.charge_name, 
            slc.reference, slc.chargeperunit, slc.chargeperline, slc.chargeamount, slc.invoiced_charge_per_line, 
            slc.invoiced_extended_charge, slc.original_chargeperunit, slc.original_chargeperline, slc.is_manual, 
            slc.createts, slc.modifyts, slc.createuserid, slc.modifyuserid, slc.createprogid, slc.modifyprogid, 
            slc.lockid, slc.extn_charge_description, slc.extn_coupon_code, CURRENT_TIMESTAMP()
        );

  INSERT INTO TempLineCharges( 
    line_charges_key,
    header_key,
    line_key,
    record_type,
    charge_category,
    charge_name,
    reference,
    chargeperunit,
    chargeperline,
    chargeamount,
    invoiced_charge_per_line,
    invoiced_extended_charge,
    original_chargeperunit,
    original_chargeperline,
    is_manual,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    extn_charge_description,
    extn_coupon_code,
    inserted_date,
    Revision
)
SELECT 
    inserted.line_charges_key,
    inserted.header_key,
    inserted.line_key,
    inserted.record_type,
    inserted.charge_category,
    inserted.charge_name,
    inserted.reference,
    inserted.chargeperunit,
    inserted.chargeperline,
    inserted.chargeamount,
    inserted.invoiced_charge_per_line,
    inserted.invoiced_extended_charge,
    inserted.original_chargeperunit,
    inserted.original_chargeperline,
    inserted.is_manual,
    inserted.createts,
    inserted.modifyts,
    inserted.createuserid,
    inserted.modifyuserid,
    inserted.createprogid,
    inserted.modifyprogid,
    inserted.lockid,
    inserted.extn_charge_description,
    inserted.extn_coupon_code,
    CURRENT_TIMESTAMP(),
    1
FROM ANALYTICS.txn_order_line_charges inserted
where  inserted_date >= :processedDate OR modified_date >= :processedDate;

   MERGE INTO TempLineCharges AS ttd
USING (
    SELECT
        MAX(aot.revision) AS revision,
        aot.line_charges_key,
        aot.header_key,
        aot.line_key
    FROM
        audit_order_line_charges AS aot
    INNER JOIN TempLineCharges AS ttd
        ON ttd.line_charges_key = aot.line_charges_key
        AND ttd.header_key = aot.header_key
        AND ttd.line_key = aot.line_key
    GROUP BY
        aot.line_charges_key,
        aot.header_key,
        aot.line_key
) AS aot
ON ttd.line_charges_key = aot.line_charges_key
AND ttd.header_key = aot.header_key
AND ttd.line_key = aot.line_key
WHEN MATCHED THEN
UPDATE SET
    ttd.Revision = CAST(COALESCE(aot.revision, 0) + 1 AS INT);


    

    -- Insert into audit tables
   INSERT INTO analytics.audit_order_line_charges (
    line_charges_key,
    header_key,
    line_key,
    record_type,
    charge_category,
    charge_name,
    reference,
    chargeperunit,
    chargeperline,
    chargeamount,
    invoiced_charge_per_line,
    invoiced_extended_charge,
    original_chargeperunit,
    original_chargeperline,
    is_manual,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    lockid,
    extn_charge_description,
    extn_coupon_code,
    inserted_date,
    Revision
)
SELECT
    stg.line_charges_key,
    stg.header_key,
    stg.line_key,
    stg.record_type,
    stg.charge_category,
    stg.charge_name,
    stg.reference,
    TRY_CAST(stg.chargeperunit AS FLOAT) AS chargeperunit,
    TRY_CAST(stg.chargeperline AS FLOAT) AS chargeperline,
    TRY_CAST(stg.chargeamount AS FLOAT) AS chargeamount,
    TRY_CAST(stg.invoiced_charge_per_line AS FLOAT) AS invoiced_charge_per_line,
    TRY_CAST(stg.invoiced_extended_charge AS FLOAT) AS invoiced_extended_charge,
    TRY_CAST(stg.original_chargeperunit AS FLOAT) AS original_chargeperunit,
    TRY_CAST(stg.original_chargeperline AS FLOAT) AS original_chargeperline,
    stg.is_manual,
    TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS') AS createts,
    TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS') AS modifyts,
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.lockid,
    stg.extn_charge_description,
    stg.extn_coupon_code,
    CURRENT_TIMESTAMP(),
    ord.Revision
FROM transformed.stg_order_line_charges stg
INNER JOIN raw.raw_order_line_charges r
    ON r.line_charges_key = stg.line_charges_key
    AND r.modifyts = stg.modifyts
    AND r.processing_status = 'Processed'
INNER JOIN TempLineCharges ord
    ON ord.line_charges_key = stg.line_charges_key
    AND ord.header_key = stg.header_key
    AND ord.line_key = stg.line_key;
    
-- Count processed records
      SELECT COUNT(*) into :processedRecordCount FROM TempLineCharges;
      
UPDATE ANALYTICS.log_files_import_status
SET
    processed = :processedRecordCount,  -- Replace with the actual value or bind variable
    status = 'Success'
WHERE
    file_name = 'YFS_LINE_CHARGES';

	
		DROP TABLE if exists TempHeaderCharges;
		
	CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);
COMMIT;
   
  RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_LINE_CHARGES';

        CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
END;