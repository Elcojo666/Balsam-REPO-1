USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.SP_NOTIFY_EMAIL_CREDIT_CONSUMPTION()
RETURNS STRING 
LANGUAGE SQL 
AS 
BEGIN
LET email_integration_name varchar :=  (select distinct integration_name from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Credit' and environment='dev'  limit 1);
    
    LET email_list varchar :=  (select LISTAGG(distinct recipient,',') from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Credit' and environment='dev');
    
    let email_subject varchar := (select DISTINCT subject_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Credit' and environment='dev' limit 1);
    
    let email_body_default  varchar := (select DISTINCT body_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Credit' and environment='dev' limit 1);
    
    LET email_body_general varchar := (
        SELECT CEIL(SUM(CREDITS_USED), 2) || ' Total Credits '  ||
                    ' ( ' || CEIL(SUM(CREDITS_USED_COMPUTE), 2) || ' Compute Credits and ' || 
                        CEIL(SUM(CREDITS_USED_CLOUD_SERVICES), 2) || ' Cloude Service Credits )' AS credit_consumption
        FROM "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY");

    LET email_body_last_week varchar := (
        SELECT CEIL(SUM(CREDITS_USED), 2) || ' Total Credits '  ||
                    ' ( ' || CEIL(SUM(CREDITS_USED_COMPUTE), 2) || ' Compute Credits and ' || 
                        CEIL(SUM(CREDITS_USED_CLOUD_SERVICES), 2) || ' Cloude Service Credits )' AS credit_consumption
        FROM "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY"
        WHERE START_TIME >= DATEADD(WEEK, -1, CURRENT_TIMESTAMP()));

    LET email_body_last_month varchar := (
        SELECT CEIL(SUM(CREDITS_USED), 2) || ' Total Credits '  ||
                    ' ( ' || CEIL(SUM(CREDITS_USED_COMPUTE), 2) || ' Compute Credits and ' || 
                        CEIL(SUM(CREDITS_USED_CLOUD_SERVICES), 2) || ' Cloude Service Credits )' AS credit_consumption
        FROM "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY"
        WHERE START_TIME >= DATEADD(MONTH, -1, CURRENT_TIMESTAMP()));
    
    CALL SYSTEM$SEND_EMAIL(
                :email_integration_name,
                :email_list,
                :email_subject,
                :email_body_default 
                ||'\n\n' || 'Overall: ' || :email_body_general || ' since the account was created.'
                ||'\n\n' || 'Last 7 Days: ' || :email_body_last_week
                ||'\n\n' || 'Last Month: ' || :email_body_last_month);
    return 'Email Alert Sent';
END;