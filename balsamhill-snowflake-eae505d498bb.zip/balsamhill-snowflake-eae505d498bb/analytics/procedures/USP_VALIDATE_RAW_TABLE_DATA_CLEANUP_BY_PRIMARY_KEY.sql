USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_VALIDATE_RAW_TABLE_DATA_CLEANUP_BY_PRIMARY_KEY("TABLE_NAME" VARCHAR(16777216), "PRIMARY_KEY_COLUMN" VARCHAR(16777216))
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE
    is_unique BOOLEAN DEFAULT TRUE;
    query_text STRING; 
    record_count INT;
    complete_raw_name STRING;
BEGIN
    complete_raw_name := ''RAW.'' || table_name;
    record_count := (
        SELECT COUNT(*)
        FROM (
            SELECT UPPER(IDENTIFIER(:primary_key_column)), modifyts, txn_id, COUNT(*)
            FROM IDENTIFIER(:complete_raw_name)
            GROUP BY UPPER(IDENTIFIER(:primary_key_column)), modifyts, txn_id
            HAVING COUNT(*) > 1
        ) AS T
    );

    IF (record_count > 0) THEN
        is_unique := FALSE;
    END IF;
    
    RETURN is_unique;
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
