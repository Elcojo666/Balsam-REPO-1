CREATE OR REPLACE PROCEDURE PRE_PROD.ANALYTICS.USP_INSERT_AND_TRUNCATE_OPTIMOVE_ORDERS_EXPORT("LAST_MODIFIED_DATE" TIMESTAMP_NTZ(9) DEFAULT NULL, "NEW_MODIFIED_DATE" TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP) COPY GRANTS 
RETURNS STRING 
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
    v_last_modified_date TIMESTAMP_NTZ;
BEGIN
    -- Get the max UpdatedDate if LAST_MODIFIED_DATE is null
    IF (LAST_MODIFIED_DATE IS NULL) THEN
        SELECT MAX(UpdatedDate)
        INTO :v_last_modified_date
        FROM ANALYTICS.optimove_orders_export;
    ELSE
        v_last_modified_date := LAST_MODIFIED_DATE- INTERVAL '1 MILLISECOND';
    END IF;

    TRUNCATE ANALYTICS.optimove_orders_export;

    INSERT INTO ANALYTICS.optimove_orders_export (
    OrderID, CustomerId, PaymentType, TotalItemPrice, Discount, ShippingCost,
    TotalPayment, OrderDate, ReturnDate, UpdatedDate, NumberOfItems,
    Brand, Currency
    )
    --;
    WITH CTE_ID AS (
        SELECT 
            toh.pk_order_headerid AS OrderID,
            dcu.source_ref_num AS CustomerId,
            dpm.Payment_method_name AS PaymentType,
            toh.discount_amount AS Discount,
            toh.shpping_fee_amount AS ShippingCost,
            CASE
                WHEN toh.fk_sourceid IN (11,13,14,15,16) THEN toh.net_amount
                WHEN toh.fk_sourceid IN (26,34,36,35,27) AND toh.source_ref_num NOT LIKE 'Y%' THEN toh.net_amount
                ELSE tod.product_price * tod.quantity
            END AS TotalPayment,
            toh.order_date AS OrderDate,
            NULL AS ReturnDate,
            toh.modified_date AS UpdatedDate,
            db.BrandCodeForPoTracker AS Brand,
            dc.currency_code AS Currency
        FROM ANALYTICS.txn_order_header toh
        LEFT JOIN ANALYTICS.txn_order_detail tod ON toh.pk_order_headerid = tod.fk_order_headerid
        LEFT JOIN ANALYTICS.txn_payment tp ON tp.fk_order_headerid = toh.pk_order_headerid
        LEFT JOIN MASTER.DIM_PAYMENT_METHOD dpm ON dpm.pk_payment_method_id = tp.fk_payment_methodid
        LEFT JOIN ANALYTICS.txn_order_status TOS ON toh.pk_order_headerid = TOS.fk_order_headerid
        LEFT JOIN ANALYTICS.TestOrders TEST ON toh.pk_order_headerid = TEST.pk_order_headerid
        LEFT JOIN MASTER.dim_source ds ON ds.pk_sourceid = toh.fk_sourceid
        LEFT JOIN MASTER.dim_brand db ON db.pk_brandid = ds.fk_brandid
        LEFT JOIN MASTER.dim_currency dc ON dc.pk_currencyid = toh.fk_currencyid
        LEFT JOIN ANALYTICS.CUSTOMER dcu ON dcu.pk_customerid = toh.fk_customerid
        WHERE toh.source_ref_num NOT LIKE 'R%'
          AND toh.source_ref_num NOT LIKE 'W%'
          AND toh.source_ref_num NOT LIKE 'P%'
          AND (
            TOS.fk_order_statusid NOT IN (2,3,13,20,21,27,28,29,30,31,32,33)
            OR TOS.fk_order_statusid IS NULL
          )
          AND toh.pk_order_headerid IS NULL
          AND toh.MODIFIED_DATE > COALESCE(:v_last_modified_date, CURRENT_TIMESTAMP() - INTERVAL '1 DAY') 
            AND toh.MODIFIED_DATE <= COALESCE(:NEW_MODIFIED_DATE, CURRENT_TIMESTAMP())
          AND (
            CASE
                WHEN toh.fk_sourceid IN (11,13,14,15,16) THEN toh.net_amount
                WHEN toh.fk_sourceid IN (26,34,36,35,27) AND toh.source_ref_num NOT LIKE 'Y%' THEN toh.net_amount
                ELSE tod.product_price * tod.quantity
            END
          ) > 0
        GROUP BY ALL
    ),
    CTE_DiscountInfo AS (
        SELECT OrderID, SUM(Discount) AS Discount
        FROM (
            SELECT DISTINCT 
                ID.OrderID, 
                ABS(OD.discount_amount) AS Discount
            FROM CTE_ID ID
            JOIN ANALYTICS.audit_order_discount OD ON OD.fk_order_headerid = ID.OrderID
            WHERE OD.discount_code NOT IN ('TEST', 'DSC-(test)', 'DSC-CC', 'DSC-CCC', 'DSC-Corp', 'TKTestBuyXGetY')
              AND OD.Revision = 1
    
            UNION ALL
    
            SELECT 
                ID.OrderID,
                ABS(SUM(ODD.discount_amount)) AS Discount
            FROM CTE_ID ID
            JOIN ANALYTICS.audit_order_detail AOD ON ID.OrderID = AOD.fk_order_headerid
            JOIN ANALYTICS.audit_order_detail_discount ODD ON ODD.fk_order_detailid = AOD.pk_order_detailid
            WHERE ODD.discount_code NOT IN ('TEST', 'DSC-(test)', 'DSC-CC', 'DSC-CCC', 'DSC-Corp', 'TKTestBuyXGetY')
              AND ODD.Revision = 1
              AND AOD.Revision = 1
            GROUP BY ID.OrderID
        ) AS T
        GROUP BY OrderID
    ),
    
    CTE_OrderDetail AS (
        SELECT 
            ID.OrderID,
            SUM(tod.quantity) AS NumberOfItems,
            SUM(tod.product_price * tod.quantity) AS TotalItemPrice
        FROM CTE_ID ID
        JOIN ANALYTICS.txn_order_detail tod ON ID.OrderID = tod.fk_order_headerid
        WHERE tod.quantity > 0
        GROUP BY ID.OrderID
    )
    SELECT DISTINCT
        ID.OrderID,
        ID.CustomerId,
        LISTAGG(DISTINCT ID.PaymentType, ' + ') WITHIN GROUP (ORDER BY ID.PaymentType) AS PaymentType,
        OD.TotalItemPrice,
        DI.Discount,
        ID.ShippingCost,
        SUM(ID.TotalPayment) AS TotalPayment,
        ID.OrderDate,
        ID.ReturnDate,
        ID.UpdatedDate,
        OD.NumberOfItems,
        ID.Brand,
        ID.Currency,
    FROM CTE_ID ID
    LEFT JOIN CTE_OrderDetail OD ON ID.OrderID = OD.OrderID
    LEFT JOIN CTE_DiscountInfo DI ON ID.OrderID = DI.OrderID
    GROUP BY 
        ID.OrderID, ID.CustomerId, OD.TotalItemPrice, DI.Discount, ID.ShippingCost,
        ID.OrderDate, ID.ReturnDate, ID.UpdatedDate, OD.NumberOfItems, ID.Brand, ID.Currency
    ORDER BY ID.OrderDate;


    RETURN 'Table Updated. Every record Updated After LAST_MODIFIED_DATE: ' || COALESCE(TO_VARCHAR(:v_last_modified_date), TO_VARCHAR(CURRENT_TIMESTAMP() - INTERVAL '1 DAY')) || ' and Before NEW_MODIFIED_DATE: ' || TO_VARCHAR(COALESCE(:NEW_MODIFIED_DATE, CURRENT_TIMESTAMP()));
END;
$$
;