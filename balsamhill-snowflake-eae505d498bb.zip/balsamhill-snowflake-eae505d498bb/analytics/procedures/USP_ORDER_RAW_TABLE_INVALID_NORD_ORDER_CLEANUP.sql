USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_RAW_TABLE_INVALID_NORD_ORDER_CLEANUP()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'BEGIN

CREATE or replace temporary TABLE  analytics.INVALID_ORDER_HEADER_KEY  as  
SELECT DISTINCT r.ORDER_HEADER_KEY, ORDER_NO
      FROM raw.raw_ORDER_header r
      INNER JOIN analytics.txn_order_header t ON t.source_ref_num = r.CUSTOMER_PO_NO 
      WHERE t.fk_sourceid IN (38, 39, 40);

-- Deletion statements
 DELETE FROM raw.raw_ORDER_container_details
 WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_payment 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_release 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_release_status 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_shipment 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_shipment_container
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_shipment_line
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_header_charges 
WHERE header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_line_charges 
WHERE header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_tax_breakup 
WHERE header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
DELETE FROM raw.raw_ORDER_line 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY From analytics.INVALID_ORDER_HEADER_KEY);
    
    -- THIS LINE NEEDS TO BE AT THE END
DELETE FROM raw.raw_ORDER_header 
WHERE order_header_key IN (SELECT ORDER_HEADER_KEY FROM analytics.INVALID_ORDER_HEADER_KEY);
  
COMMIT;
   
  RETURN ''Success'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    
            -- Return error message
    RETURN OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                            ''SQLCODE'', sqlcode,
                            ''SQLERRM'', sqlerrm,
                            ''SQLSTATE'', sqlstate);
END';
