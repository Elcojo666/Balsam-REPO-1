CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_ALL_HEADER_AND_LINE_STATUS_GENERATION()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    processedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    message TEXT;
    invalidRecordCount NUMBER DEFAULT 0;
BEGIN 

CREATE OR REPLACE TEMPORARY TABLE TempAPI_order_line_status(
order_release_status_key STRING not null
, order_line_key STRING not null 
, order_header_key STRING NOT NULL 
, status_quantity INT
, total_quantity INT 
, status STRING 
, priority INT NOT NULL 
, txn_id STRING  NULL 
);

CREATE OR REPLACE TEMPORARY TABLE TempAPI_order_header_status(
order_header_key STRING not null 
, status_quantity INT 
, total_quantity INT 
, status STRING
, header_priority INT NOT NULL 
, txn_id STRING  null
);


INSERT INTO  TempAPI_order_line_status (
  order_release_status_key,
  order_line_key,
  order_header_key,
  status_quantity,
  total_quantity,
  status,
  priority
  --,txn_id
)
SELECT distinct 
  order_release_status_key,
  order_line_key,
  order_header_key,
  status_quantity,
  total_quantity,
  status,
  priority
  --,txn_id
FROM (
  SELECT
    order_release_status_key,
    order_header_key,
    order_line_key,
    CAST(status_quantity AS NUMERIC(19, 0)) AS status_quantity,
    CAST(total_quantity AS NUMERIC(19, 0)) AS total_quantity,
    status,
    --txn_id,
    ROW_NUMBER() OVER (PARTITION BY --txn_id, 
    order_line_key ORDER BY CAST(ANALYTICS.CleanAndTrimString(COALESCE(order_release_status_key, '0')) AS DECIMAL(38, 0)) DESC) AS priority
  FROM RAW.raw_order_release_status
  WHERE CAST(status_quantity AS NUMERIC(19, 0)) > 0
    AND processing_status IN ('Pending', 'Failed')
) AS processed
WHERE priority = 1;

MERGE INTO RAW.raw_order_line AS sool
USING (
  SELECT distinct 
    MAX(order_release_status_key) AS order_release_status_key,
    order_line_key,
    order_header_key,
    status
    --txn_id
  FROM TempAPI_order_line_status
  GROUP BY order_line_key, order_header_key, status --, txn_id
) AS ls
ON sool.ORDER_HEADER_KEY = ls.order_header_key
AND sool.ORDER_LINE_KEY = ls.order_line_key
--AND sool.txn_id = ls.txn_id
AND sool.processing_status IN ('Pending', 'Failed')
WHEN MATCHED THEN
UPDATE SET
  sool.order_line_status = analytics.CleanAndTrimString(coalesce(ls.status, ''));

INSERT INTO TempAPI_order_header_status (
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority
    --txn_id
)
SELECT distinct 
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority
    ---,txn_id
FROM (
    SELECT
        order_header_key,
        status_quantity,
        total_quantity,
        status,
        --txn_id,
        ROW_NUMBER() OVER (
            PARTITION BY --txn_id, 
            order_header_key
            ORDER BY CAST(CleanAndTrimString(COALESCE(status_quantity, '0')) AS NUMBER(38, 0)) ASC
        ) AS header_priority
    FROM (
        SELECT
            order_header_key,
            SUM(status_quantity) AS status_quantity,
            SUM(total_quantity) AS total_quantity,
            status
            --txn_id
        FROM
            TempAPI_order_line_status
        GROUP BY order_header_key, status --, txn_id
    ) AS processed_line
) AS processed;

MERGE INTO  RAW.raw_order_header AS roh
USING (
  SELECT
    order_header_key,
    status_quantity,
    total_quantity,
    status,
    header_priority
    --,txn_id
  FROM (
    SELECT
      order_header_key,
      status_quantity,
      total_quantity,
      status,
      --txn_id,
      ROW_NUMBER() OVER (
        PARTITION BY --txn_id, 
        order_header_key
        ORDER BY CAST(analytics.CleanAndTrimString(IFNULL(status_quantity, '0')) AS NUMBER(38, 0)) ASC
      ) AS header_priority
    FROM (
      SELECT
        order_header_key,
        SUM(status_quantity) AS status_quantity,
        SUM(total_quantity) AS total_quantity,
        status,
        --txn_id
      FROM TempAPI_order_line_status
      GROUP BY order_header_key, status, txn_id
    ) AS processed_line
  ) AS processed
  WHERE header_priority = 1
) AS ls
ON roh.ORDER_HEADER_KEY = ls.order_header_key
--AND roh.txn_id = ls.txn_id
WHEN MATCHED AND analytics.CleanAndTrimString(IFNULL(ls.status, '')) IS NOT NULL
AND roh.processing_status IN ('Pending', 'Failed')
THEN
  UPDATE SET
    roh.order_status = CASE
      WHEN ls.header_priority > 1 THEN '_' || analytics.CleanAndTrimString(IFNULL(ls.status, ''))
      WHEN ls.header_priority = 1 THEN analytics.CleanAndTrimString(IFNULL(ls.status, ''))
      ELSE NULL
    END;


DROP TABLE IF EXISTS TempAPI_order_header_status;
DROP TABLE IF EXISTS TempAPI_order_line_status;

RETURN 'Success'; 
EXCEPTION 
    WHEN statement_error THEN
    ROLLBACK;
    RETURN OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                            'SQLCODE', sqlcode,
                            'SQLERRM', sqlerrm,
                            'SQLSTATE', sqlstate);
END;