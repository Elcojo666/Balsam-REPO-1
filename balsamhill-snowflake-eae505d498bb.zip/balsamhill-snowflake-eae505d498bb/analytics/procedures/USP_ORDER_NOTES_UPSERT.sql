
CREATE OR REPLACE PROCEDURE ANALYTICS.USP_ORDER_NOTES_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE 
    initialRevision NUMBER DEFAULT 1;
    processedRecordCount NUMBER DEFAULT 0;
    toBeProcessedRecordCount NUMBER DEFAULT 0;
    processedDate TIMESTAMP;
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);

UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount,
    raw_table = 'raw_ORDER_notes'
WHERE file_name = 'YFS_NOTES';

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

CREATE OR REPLACE TEMPORARY TABLE TempOrderNotes (
    notes_key STRING,
    table_key STRING,
    sequence_no STRING,
    table_name STRING,
    tranid STRING,
    audit_transaction_id STRING,
    customer_sat_indicator STRING,
    priority STRING,
    reason_code STRING,
    note_text STRING,
    contact_type STRING,
    contact_reference STRING,
    contact_time TIMESTAMP_NTZ(9),
    contact_user STRING,
    lockid STRING,
    createts  TIMESTAMP_NTZ(9),
    modifyts TIMESTAMP_NTZ(9),
    createuserid STRING,
    modifyuserid STRING,
    createprogid STRING,
    modifyprogid STRING,
    visible_to_all STRING,
    inserted_date TIMESTAMP_NTZ(9),
    modified_date TIMESTAMP_NTZ(9),
    revision INT
);

processedDate := CURRENT_TIMESTAMP();

MERGE INTO ANALYTICS.txn_order_notes AS ton
USING (
    SELECT 
        notes_key,
        table_key,
        sequence_no,
        table_name,
        tranid,
        audit_transaction_id,
        customer_sat_indicator,
        priority,
        reason_code,
        note_text,
        contact_type,
        contact_reference,
        contact_time,
        contact_user,
        lockid,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        visible_to_all
    FROM TRANSFORMED.stg_ORDER_notes AS stg
) AS son
ON ton.notes_key = son.notes_key
WHEN MATCHED THEN
    UPDATE SET 
        ton.notes_key = son.notes_key,
        ton.table_key = son.table_key,
        ton.sequence_no = son.sequence_no,
        ton.table_name = son.table_name,
        ton.tranid = son.tranid,
        ton.audit_transaction_id = son.audit_transaction_id,
        ton.customer_sat_indicator = son.customer_sat_indicator,
        ton.priority = son.priority,
        ton.reason_code = son.reason_code,
        ton.note_text = son.note_text,
        ton.contact_type = son.contact_type,
        ton.contact_reference = son.contact_reference,
        ton.contact_time = TRY_TO_TIMESTAMP(son.contact_time,'YYYYMMDDHHMISS'),
        ton.contact_user = son.contact_user,
        ton.lockid = son.lockid,
        ton.createts = TRY_TO_TIMESTAMP(son.createts,'YYYYMMDDHHMISS'),
        ton.modifyts = TRY_TO_TIMESTAMP(son.modifyts,'YYYYMMDDHHMISS'),
        ton.createuserid = son.createuserid,
        ton.modifyuserid = son.modifyuserid,
        ton.createprogid = son.createprogid,
        ton.modifyprogid = son.modifyprogid,
        ton.visible_to_all = son.visible_to_all,
        ton.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (
        notes_key,
        table_key,
        sequence_no,
        table_name,
        tranid,
        audit_transaction_id,
        customer_sat_indicator,
        priority,
        reason_code,
        note_text,
        contact_type,
        contact_reference,
        contact_time,
        contact_user,
        lockid,
        createts,
        modifyts,
        createuserid,
        modifyuserid,
        createprogid,
        modifyprogid,
        visible_to_all,
        inserted_date
    )
    VALUES (
        son.notes_key,
        son.table_key,
        son.sequence_no,
        son.table_name,
        son.tranid,
        son.audit_transaction_id,
        son.customer_sat_indicator,
        son.priority,
        son.reason_code,
        son.note_text,
        son.contact_type,
        son.contact_reference,
        TRY_TO_TIMESTAMP(son.contact_time,'YYYYMMDDHHMISS'),
        son.contact_user,
        son.lockid,
        TRY_TO_TIMESTAMP(son.createts,'YYYYMMDDHHMISS'),
        TRY_TO_TIMESTAMP(son.modifyts,'YYYYMMDDHHMISS'),
        son.createuserid,
        son.modifyuserid,
        son.createprogid,
        son.modifyprogid,
        son.visible_to_all,
        CURRENT_TIMESTAMP()
    );

INSERT INTO TempOrderNotes(
    notes_key,
    table_key,
    sequence_no,
    table_name,
    tranid,
    audit_transaction_id,
    customer_sat_indicator,
    priority,
    reason_code,
    note_text,
    contact_type,
    contact_reference,
    contact_time,
    contact_user,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    visible_to_all,
    inserted_date,
    Revision
)
SELECT
    ton.notes_key,
    ton.table_key,
    ton.sequence_no,
    ton.table_name,
    ton.tranid,
    ton.audit_transaction_id,
    ton.customer_sat_indicator,
    ton.priority,
    ton.reason_code,
    ton.note_text,
    ton.contact_type,
    ton.contact_reference,
    ton.contact_time,
    ton.contact_user,
    ton.lockid,
    ton.createts,
    ton.modifyts,
    ton.createuserid,
    ton.modifyuserid,
    ton.createprogid,
    ton.modifyprogid,
    ton.visible_to_all,
    CURRENT_TIMESTAMP(),  -- For inserted_date
    1  -- For Revision
FROM ANALYTICS.txn_order_notes AS ton
where inserted_date >= :processedDate or modified_date >= :processedDate;


UPDATE TempOrderNotes AS ttd
SET ttd.Revision = CAST((COALESCE(aot.revision, 0) + 1) AS INT)
FROM (
    SELECT
        MAX(aot.revision) AS revision,
        aot.notes_key
    FROM ANALYTICS.audit_order_notes AS aot
    INNER JOIN TempOrderNotes AS ttd_temp ON ttd_temp.notes_key = aot.notes_key
    GROUP BY aot.notes_key
) AS aot
WHERE ttd.notes_key = aot.notes_key;

UPDATE RAW.raw_ORDER_notes as roh
SET 
    roh.processing_status = 'Processed',
    roh.processing_comment = '',
    roh.processing_errortype = ''
FROM  (SELECT DISTINCT stg.notes_key FROM TRANSFORMED.stg_ORDER_notes AS stg 
INNER JOIN ANALYTICS.txn_order_notes AS toh ON toh.notes_key = stg.notes_key) stgt
WHERE  stgt.notes_key = roh.notes_key ;

INSERT INTO ANALYTICS.audit_order_notes(
    notes_key,
    table_key,
    sequence_no,
    table_name,
    tranid,
    audit_transaction_id,
    customer_sat_indicator,
    priority,
    reason_code,
    note_text,
    contact_type,
    contact_reference,
    contact_time,
    contact_user,
    lockid,
    createts,
    modifyts,
    createuserid,
    modifyuserid,
    createprogid,
    modifyprogid,
    visible_to_all,
    inserted_date,
    Revision
)
SELECT
    stg.notes_key,
    stg.table_key,
    stg.sequence_no,
    stg.table_name,
    stg.tranid,
    stg.audit_transaction_id,
    stg.customer_sat_indicator,
    stg.priority,
    stg.reason_code,
    stg.note_text,
    stg.contact_type,
    stg.contact_reference,
    TRY_TO_TIMESTAMP(stg.contact_time,'YYYYMMDDHHMISS'),
    stg.contact_user,
    stg.lockid,
    TRY_TO_TIMESTAMP(stg.createts,'YYYYMMDDHHMISS'),
    TRY_TO_TIMESTAMP(stg.modifyts,'YYYYMMDDHHMISS'),
    stg.createuserid,
    stg.modifyuserid,
    stg.createprogid,
    stg.modifyprogid,
    stg.visible_to_all,
    CURRENT_TIMESTAMP(),
    ord.Revision
FROM TRANSFORMED.stg_ORDER_notes stg
INNER JOIN TempOrderNotes ord ON ord.notes_key = stg.notes_key;

-- Count the number of records to be processed
SELECT COUNT(*) INTO :toBeProcessedRecordCount FROM TRANSFORMED.stg_ORDER_notes;

-- Count the number of processed records
SELECT COUNT(*) INTO :processedRecordCount FROM TempOrderNotes;

-- Update log_files_import_status with processed counts
UPDATE ANALYTICS.log_files_import_status
SET processed = :processedRecordCount,
    to_be_processed = :toBeProcessedRecordCount,
    status = 'Success'
WHERE file_name = 'YFS_NOTES';

DROP TABLE IF EXISTS TempOrderNotes;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);

COMMIT;
RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    UPDATE ANALYTICS.log_files_import_status
        SET processed = 0,
            status = 'Failed'
        WHERE file_name = 'YFS_NOTES';
            -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	
	RETURN error_object;
END;