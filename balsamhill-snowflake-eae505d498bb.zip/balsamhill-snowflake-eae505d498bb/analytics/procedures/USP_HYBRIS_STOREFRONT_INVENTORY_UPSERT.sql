CREATE OR REPLACE PROCEDURE PROD.ANALYTICS.USP_HYBRIS_STOREFRONT_INVENTORY_UPSERT("COUNTRY_CODE" VARCHAR(16777216), "PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
  message STRING DEFAULT '''';
  error_object OBJECT;
  START_TIME_PROC TIMESTAMP_NTZ(9);

BEGIN

  start_time_proc := CURRENT_TIMESTAMP();
  SYSTEM$LOG(''TRACE'', ''SP STARTED - '' || :pipeline_name);

  CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
      :pipeline_name,
      ''upsert'',
      ''STARTED'',
      :start_time_proc,
      NULL,
      ''upsert started''
  );

  -- Create Temp Table
  CREATE OR REPLACE TEMPORARY TABLE TempAPI_oms_storefront_inventory AS
  SELECT 
      tois.sku,
      tois.organizationCode,
      tois.available,
      tois.alertRaisedOn,
      tois.futureAvailable,
      null AS fk_brandid,
      null AS locale,
      null AS fk_skuproductid,
      null AS product_name,
      null AS fk_countryid,
      null AS SourceID -- Add SourceID column
  FROM 
      (SELECT * FROM TABLE(analytics.get_hybris_inventory(:country_code))) tois;

  -- Populate BrandID and Locale
  UPDATE TempAPI_oms_storefront_inventory AS tois
  SET 
      fk_brandid = b.pk_brandid,
      locale = b.locale
  FROM master.dim_brand AS b
  WHERE b.BrandCodeForPOTracker = UPPER(REPLACE(tois.organizationCode, ''-'', ''''));

  -- Populate SKU Product Details
  UPDATE TempAPI_oms_storefront_inventory AS tois
  SET 
      fk_skuproductid = sku.pk_skuproductid,
      locale = sku.locale,
      product_name = sku.bh_product_name
  FROM analytics.sku_product_locale AS sku
  WHERE sku.sku_code = tois.sku 
    AND sku.locale = tois.locale;

  -- Populate CountryID
  UPDATE TempAPI_oms_storefront_inventory AS tois
  SET 
      fk_countryid = dc.pk_countryid
  FROM master.dim_country AS dc
  WHERE UPPER(SUBSTRING(tois.organizationCode, 4, 4)) = UPPER(dc.country_code);

  -- Populate SourceID Based on BrandID
  UPDATE TempAPI_oms_storefront_inventory
  SET SourceID = CASE
      WHEN fk_brandid = 1 THEN 11
      WHEN fk_brandid = 6 THEN 13
      WHEN fk_brandid = 7 THEN 14
      WHEN fk_brandid = 8  THEN 15
      WHEN fk_brandid = 10 THEN 16
      WHEN fk_brandid = 19 THEN 42
      ELSE NULL
  END;

  -- Handle Invalid Records
  DELETE FROM TempAPI_oms_storefront_inventory
  WHERE fk_skuproductid IS NULL OR fk_brandid IS NULL OR fk_countryid IS NULL;

  -- Enrich Data for Merge
  CREATE OR REPLACE TEMPORARY TABLE TempAPI_oms_storefront_inventory_enriched AS
  SELECT DISTINCT
      ''HYBRIS'' AS Source,
      SKU AS sku_code,
      CONCAT(organizationCode, ''ProductCatalog'') AS catalog_version,
      CASE
          WHEN organizationCode = ''bh-au'' THEN ''10''
          WHEN organizationCode = ''bh-de'' THEN ''8''
          WHEN organizationCode = ''bh-fr'' THEN ''7''
          WHEN organizationCode = ''bh-us'' THEN ''1''
          WHEN organizationCode = ''bh-uk'' THEN ''6''
          WHEN organizationCode = ''bh-ca'' THEN ''19''
          ELSE NULL
      END AS BrandID,
      fk_countryid,
      fk_skuproductid,
      CASE  
          WHEN organizationCode = ''bh-au'' THEN 715  
          WHEN organizationCode = ''bh-de'' THEN 716  
          WHEN organizationCode = ''bh-fr'' THEN 717  
          WHEN organizationCode = ''bh-uk'' THEN 719  
          ELSE 718  
      END AS fk_inputfileid, 
      102 AS fk_filesourceid,
      SourceID, -- Include SourceID here
      product_name,
      available AS stock,
      ''StockLevelStatus'' AS stock_level_status_type,
      CASE 
          WHEN available > 0 THEN ''InStock''
          ELSE ''outOfStock''
      END AS stock_level_status_code,
      futureAvailable AS expected_receipts
  FROM TempAPI_oms_storefront_inventory;

  -- Merge Into txn_storefront_inventory
  MERGE INTO analytics.txn_storefront_inventory AS Target
  USING TempAPI_oms_storefront_inventory_enriched AS Source
  ON Target.sku_code = Source.sku_code
     AND Target.catalog_version = Source.catalog_version
  WHEN MATCHED THEN  
     UPDATE SET  
         Target.Source = Source.Source,  
         Target.catalog_version = Source.catalog_version,  
         Target.BrandID = Source.BrandID,  
         Target.fk_countryid = Source.fk_countryid,  
         Target.fk_skuproductid = Source.fk_skuproductid,  
         Target.fk_inputfileid = Source.fk_inputfileid,  
         Target.fk_filesourceid = Source.fk_filesourceid,  
         Target.SourceID = Source.SourceID, -- Include SourceID in update
         Target.product_name = Source.product_name,  
         Target.stock = Source.stock,  
         Target.stock_level_status_type = Source.stock_level_status_type,  
         Target.stock_level_status_code = Source.stock_level_status_code,  
         Target.expected_receipts = Source.expected_receipts,  
         Target.last_updated_date = GETDATE(),  
         Target.hybris_stock = Source.stock,   
         Target.hybris_modified_date = GETDATE()  
  WHEN NOT MATCHED THEN  
     INSERT (  
         Source,  
         sku_code,  
         catalog_version,  
         BrandID,  
         fk_countryid,  
         fk_skuproductid,  
         fk_inputfileid,  
         fk_filesourceid,  
         SourceID, -- Include SourceID in insert
         product_name,  
         stock,  
         stock_level_status_type,  
         stock_level_status_code,  
         expected_receipts,  
         inserted_date,  
         last_updated_date,  
         oms_stock,   
         oms_modified_date,    
         hybris_stock,  
         hybris_modified_date  
     )  
     VALUES (  
         Source.Source,  
         Source.sku_code,  
         Source.catalog_version,  
         Source.BrandID,  
         Source.fk_countryid,  
         Source.fk_skuproductid,  
         Source.fk_inputfileid,  
         Source.fk_filesourceid,  
         Source.SourceID, -- Include SourceID in insert
         Source.product_name,  
         Source.stock,  
         Source.stock_level_status_type,  
         Source.stock_level_status_code,  
         Source.expected_receipts,  
         CURRENT_TIMESTAMP(),  
         CURRENT_TIMESTAMP(),  
         NULL,   
         NULL,  
         Source.stock,   
         CURRENT_TIMESTAMP()  
     );  

  COMMIT;

  CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
      :pipeline_name,
      ''upsert'',
      ''COMPLETED'',
      :start_time_proc,
      CURRENT_TIMESTAMP(),
      ''Upsert completed successfully''
  );

  SYSTEM$LOG(''TRACE'', ''SP COMPLETED - '' || :pipeline_name);
  RETURN ''Success'';

EXCEPTION
  WHEN statement_error THEN
    ROLLBACK;

    error_object := OBJECT_CONSTRUCT(
        ''Error type'', ''STATEMENT_ERROR'',
        ''SQLCODE'', sqlcode,
        ''SQLERRM'', sqlerrm,
        ''SQLSTATE'', sqlstate
    );
    
    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );
    SYSTEM$LOG(''ERROR'', ''SP FAILED - '' || :pipeline_name);

    RETURN ''Error occurred: '' || :pipeline_name || '' : '' || sqlerrm;
END;
';