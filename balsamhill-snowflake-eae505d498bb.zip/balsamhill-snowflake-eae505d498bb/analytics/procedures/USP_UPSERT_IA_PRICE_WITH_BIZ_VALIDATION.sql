CREATE OR REPLACE PROCEDURE ANALYTICS.USP_UPSERT_IA_PRICE_WITH_BIZ_VALIDATION(PIPELINE_NAME VARCHAR)  copy grants
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE
    v_count INT;
    duplicates_exception EXCEPTION (-20005, 'Duplicates in Pricing File. Please check log_pricingerrors table with today''s logdate');
    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9);
BEGIN 

start_time_proc := CURRENT_TIMESTAMP();
    SYSTEM$LOG('TRACE','SP STARTED- '||:pipeline_name);
CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'STARTED',
        :start_time_proc,
        NULL,
        'upsert started'
    );

    --table analytics.product_pricing;5066887
                   
    CREATE OR REPLACE TEMPORARY TABLE sourcetabletypeone AS
    SELECT distinct ds.pk_skuproductid,
           CAST(shc.productcode AS VARCHAR)        AS productcode,
           null new_tag,
           CAST(shc.productprice AS NUMBER(10, 2)) AS productprice,
           CAST(shc.saleprice AS NUMBER(10, 2))    AS saleprice,
           shc.price_start_date,
           shc.price_end_date,
           null customer_group,
           dc.pk_currencyid,
           shc.brand as brand_name,
           shc.user_mail as user,
           shc.module,
           shc.event_name,
           shc.offer_name,
           shc.brandsku,
           shc.offer_type,
           cast(shc.offer_value AS NUMBER(10, 2)) as offer_value,
           CURRENT_TIMESTAMP()                     AS rangestartdate,
           CURRENT_TIMESTAMP()                     AS rangeenddate,
           TRUE                                    AS valid,
           shc.file_name,
           shc.strategy_name
      FROM   TRANSFORMED.STG_IA_PRICE AS shc
             INNER JOIN (SELECT productcode,
                                currency,
                                COUNT(*) AS CountOf
                         FROM TRANSFORMED.STG_IA_PRICE
                         GROUP BY productcode, currency
                         HAVING COUNT(*) = 1) AS dt
                        ON dt.productcode = shc.productcode AND dt.currency = shc.currency
             INNER JOIN MASTER.DIM_CURRENCY AS dc
                        ON CAST(shc.currency AS STRING) = dc.currency_code
             INNER JOIN ANALYTICS.SKU_PRODUCT AS ds
                        ON CAST(shc.productcode AS STRING) = ds.sku_code
             INNER JOIN MASTER.DIM_BRAND AS db
                       ON (shc.brand::String = db.CODE::string or shc.brand::String=db.BRANDCODEFORPOTRACKER);


   CREATE OR REPLACE TEMPORARY TABLE sourcetabletypetwo AS
    SELECT distinct ds.pk_skuproductid,
           CAST(shc.productcode AS VARCHAR)        AS productcode,
           null new_tag,
           CAST(shc.productprice AS NUMBER(10, 2)) AS productprice,
           CAST(shc.saleprice AS NUMBER(10, 2))    AS saleprice,
           shc.price_start_date,
           shc.price_end_date,
           null customer_group,
           dc.pk_currencyid,
           shc.brand as brand_name,
           shc.user_mail as user,
           shc.module,
           shc.event_name,
           shc.offer_name,
           shc.brandsku,
           shc.offer_type,
           cast(shc.offer_value AS NUMBER(10, 2)) as offer_value,
           CURRENT_TIMESTAMP()                     AS rangestartdate,
           CURRENT_TIMESTAMP()                     AS rangeenddate,
           TRUE                                    AS valid,
           shc.file_name,
           strategy_name
    FROM   TRANSFORMED.STG_IA_PRICE AS shc
             INNER JOIN (SELECT productcode, currency, COUNT(*) AS CountOf
                         FROM TRANSFORMED.STG_IA_PRICE
                         GROUP BY productcode, currency
                         HAVING COUNT(*) > 1) AS dt
                        ON dt.productcode = shc.productcode AND dt.currency = shc.currency
             INNER JOIN MASTER.DIM_CURRENCY dc
                        ON CAST(shc.currency AS VARCHAR) = dc.currency_code
             INNER JOIN ANALYTICS.SKU_PRODUCT ds
                        ON CAST(shc.productcode AS VARCHAR) = ds.sku_code
            INNER JOIN MASTER.DIM_BRAND AS db
                       ON (shc.brand::String = db.CODE::string or shc.brand::String=db.BRANDCODEFORPOTRACKER)
                       group by all ;


    UPDATE sourcetabletypetwo AS stt
    SET rangestartdate = rtt.MinDateTime,
        rangeenddate   = rtt.MaxDateTime
    FROM (SELECT productcode,
                 MIN(price_start_date) AS MinDateTime,
                 MAX(price_end_date)   AS MaxDateTime
          FROM sourcetabletypetwo
          GROUP BY productcode) AS rtt
    WHERE stt.productcode = rtt.productcode;


    UPDATE sourcetabletypetwo AS stt
    SET valid = FALSE
    FROM (SELECT t1.productcode, t1.col1 AS startOfGap, MIN(t2.col1) AS endOfGap
          FROM (SELECT DATEADD('day', 1, price_end_date) AS col1,
                       tbl1.productcode
                FROM sourcetabletypetwo AS tbl1
                WHERE NOT EXISTS (SELECT 1
                                  FROM sourcetabletypetwo AS tbl2
                                  WHERE tbl2.price_start_date = DATEADD('day', 1, tbl1.price_end_date))
                  AND tbl1.price_end_date <> (SELECT MAX(price_start_date)
                                              FROM sourcetabletypetwo)) AS t1
                   INNER JOIN (SELECT DATEADD('day', -1, price_start_date) AS col1,
                                      tbl1.productcode
                               FROM sourcetabletypetwo AS tbl1
                               WHERE NOT EXISTS (SELECT 1
                                                 FROM sourcetabletypetwo AS tbl2
                                                 WHERE tbl1.price_end_date = DATEADD('day', 1, tbl2.price_start_date))
                                 AND tbl1.price_start_date <> (SELECT MIN(price_end_date)
                                                               FROM sourcetabletypetwo)) AS t2
                              ON t1.col1 <= t2.col1
          WHERE t1.productcode = t2.productcode
          GROUP BY t1.productcode, t1.col1) AS trr
    WHERE stt.productcode = trr.productcode;


    CREATE OR REPLACE TEMPORARY TABLE sourcetabletypethree AS
    SELECT  tx.productcode      AS n,
           tx.price_start_date AS m,
           tx.pk_currencyid    AS o,
           tx.*
    FROM sourcetabletypetwo AS tx
    WHERE tx.price_start_date = tx.rangestartdate
      AND tx.rangestartdate > CURRENT_TIMESTAMP()
      AND tx.price_start_date > CURRENT_TIMESTAMP()
    ORDER BY tx.productcode, tx.price_start_date, tx.pk_currencyid;

    START TRANSACTION NAME TRANS;

  

     -- DELETE FROM ANALYTICS.LOG_PRICINGERRORS l
     -- USING TRANSFORMED.STG_HYBRIS_PRICE_CHILD s
     --    WHERE TO_DATE(l.logdate) = CURRENT_DATE
     --    AND l.file_name = s.file_name
     --    ;



    INSERT INTO ANALYTICS.LOG_PRICINGERRORS(PRODUCTCODE_IN_FILE,
                                            PRODUCTCODE_IN_DB,
                                            CURRENCY_IN_FILE,
                                            CURRENCY_IN_DB,
                                            PRICE_START_DATE_IN_FILE,
                                            PRICE_END_DATE_IN_FILE,
                                            PRICE_START_DATE_IN_DB,
                                            PRICE_END_DATE_IN_DB,
                                            BRAND_NAME,
                                            USER,
                                            MODULE,
                                            EVENT_NAME,
                                            LOGDATE,
                                            file_name)
    SELECT DISTINCT st.productcode      AS "ProductCode in File",
                    dp.SKU_CODE         AS "ProductCode in DB",
                    st.pk_currencyid    AS "Currency in File",
                    dp.fk_currencyid    AS "Currency in DB",
                    st.price_start_date AS "Price Start Date in File",
                    st.price_end_date   AS "Price End Date in File",
                    dp.price_start_date AS "Price Start Date in DB",
                    dp.price_end_date   AS "Price End Date in File",
                    st.brand_name,
                    st.user,
                    st.module,
                    st.event_name,
                    CURRENT_DATE        AS logdate,
                    st.file_name as file_name
                   
    FROM sourcetabletypeone AS st
             JOIN ANALYTICS.PRODUCT_PRICING AS dp
                  ON st.productcode = dp.SKU_CODE
                      AND st.pk_currencyid = dp.fk_currencyid
                      --AND dp.file_name = st.file_name
                      AND TO_DATE(st.price_start_date) <> TO_DATE(dp.price_start_date)
                      AND CURRENT_DATE BETWEEN dp.price_start_date AND dp.price_end_date
                      AND CURRENT_DATE BETWEEN st.price_start_date AND st.price_end_date;


    INSERT INTO ANALYTICS.LOG_PRICINGERRORS(PRODUCTCODE_IN_FILE,
                                            PRODUCTCODE_IN_DB,
                                            CURRENCY_IN_FILE,
                                            CURRENCY_IN_DB,
                                            PRICE_START_DATE_IN_FILE,
                                            PRICE_END_DATE_IN_FILE,
                                            PRICE_START_DATE_IN_DB,
                                            PRICE_END_DATE_IN_DB,
                                            BRAND_NAME,
                                            USER,
                                            MODULE,
                                            EVENT_NAME,
                                            LOGDATE,
                                            FILE_NAME)
    SELECT DISTINCT st.productcode      AS "ProductCode in File",
                    dp.SKU_CODE         AS "ProductCode in DB",
                    st.pk_currencyid    AS "Currency in File",
                    dp.fk_currencyid    AS "Currency in DB",
                    st.price_start_date AS "Price Start Date in File",
                    st.price_end_date   AS "Price End Date in File",
                    dp.price_start_date AS "Price Start Date in DB",
                    dp.price_end_date   AS "Price End Date in File",
                    st.brand_name,
                    st.user,
                    st.module,
                    st.event_name,
                    CURRENT_DATE        AS logdate,
                    st.file_name as file_name
    FROM sourcetabletypetwo AS st
             JOIN ANALYTICS.PRODUCT_PRICING AS dp
                  ON st.productcode = dp.SKU_CODE
                      AND st.pk_currencyid = dp.fk_currencyid
                      --AND dp.file_name = dp.file_name
                      AND TO_DATE(st.rangestartdate) <> TO_DATE(dp.price_start_date)
                      AND CURRENT_DATE BETWEEN dp.price_start_date AND dp.price_end_date
                      AND CURRENT_DATE BETWEEN st.rangestartdate AND st.rangeenddate;


    INSERT INTO ANALYTICS.LOG_PRICINGERRORS(PRODUCTCODE_IN_FILE,
                                            PRODUCTCODE_IN_DB,
                                            CURRENCY_IN_FILE,
                                            CURRENCY_IN_DB,
                                            PRICE_START_DATE_IN_FILE,
                                            PRICE_END_DATE_IN_FILE,
                                            PRICE_START_DATE_IN_DB,
                                            PRICE_END_DATE_IN_DB,
                                            BRAND_NAME,
                                            USER,
                                            MODULE,
                                            EVENT_NAME,
                                            LOGDATE,
                                            file_name)
    SELECT DISTINCT st.productcode      AS "ProductCode in File",
                    dp.SKU_CODE         AS "ProductCode in DB",
                    st.pk_currencyid    AS "Currency in File",
                    dp.fk_currencyid    AS "Currency in DB",
                    st.price_start_date AS "Price Start Date in File",
                    st.price_end_date   AS "Price End Date in File",
                    dp.price_start_date AS "Price Start Date in DB",
                    dp.price_end_date   AS "Price End Date in File",
                    st.brand_name,
                    st.user,
                    st.module,
                    st.event_name,
                    CURRENT_DATE AS logdate,
                    st.file_name as file_name
    FROM sourcetabletypetwo AS st
             JOIN  ANALYTICS.PRODUCT_PRICING AS dp
                  ON st.productcode = dp.SKU_CODE
                      AND st.pk_currencyid = dp.fk_currencyid
                      --AND dp.file_name = st.file_name
                      AND st.valid = FALSE
                      AND CURRENT_DATE BETWEEN dp.price_start_date AND dp.price_end_date
                      AND CURRENT_DATE BETWEEN st.rangestartdate AND st.rangeenddate;


    -- v_count := (SELECT COUNT(*)
    --             FROM ANALYTICS.LOG_PRICINGERRORS AS l
    --             WHERE TO_DATE(l.logdate) = CURRENT_DATE
    --               AND l.fileSourceId = :file_source_id
    --               AND l.auditSourceId = :audit_source_id);

    -- IF (v_count > 0) THEN
    --     COMMIT;
    --     v_count := 1 / 0;
    -- END IF;
    




    -- MERGE INTO table ANALYTICS.PRODUCT_PRICING AS dp
    --     USING (SELECT *
    --            FROM sourcetabletypeone
    --            WHERE price_start_date > CURRENT_TIMESTAMP()) AS st
    --     ON st.pk_skuproductid = dp.fk_skuproductid
    --         AND st.pk_currencyid = dp.fk_currencyid
    --         AND st.price_start_date <> dp.price_start_date
    --         AND st.price_start_date BETWEEN dp.price_start_date AND dp.price_end_date
    --         --AND dp.fk_filesourceid = :file_source_id
    --     WHEN MATCHED THEN
    --         UPDATE SET
    --             dp.price_end_date = DATEADD(DAY, -1, st.price_start_date),
    --             dp.last_updated_date = CURRENT_TIMESTAMP();

   

    MERGE INTO ANALYTICS.PRODUCT_PRICING AS dp
        USING (select distinct * from  sourcetabletypeone where module = 'Promo') AS st
        ON st.pk_skuproductid = dp.fk_skuproductid
            AND st.price_start_date = dp.price_start_date
            AND st.pk_currencyid = dp.fk_currencyid
            AND dp.BRAND_NAME = st.brand_name
            and lower(dp.offer_name)=lower(st.offer_name)
           
            --AND dp.fk_filesourceid = :file_source_id
        WHEN MATCHED THEN
            UPDATE SET
                dp.fk_skuproductid = st.pk_skuproductid,
               -- dp.fk_filesourceid = :file_source_id,
                dp.SKU_CODE = st.productcode,
                dp.productprice = st.productprice,
                dp.saleprice = st.saleprice,
                dp.price_start_date = st.price_start_date,
                dp.price_end_date = st.price_end_date,
                dp.BRAND_NAME = st.brand_name,
                dp.USER = st.user,
                dp.MODULE = st.module,
                dp.EVENT_NAME = st.event_name,
                dp.fk_currencyid = st.pk_currencyid,
                dp.last_updated_date = CURRENT_TIMESTAMP(),
                DP.file_name = st.file_name,
                dp.offer_name=st.offer_name,
                dp.brandsku=st.brandsku,
                dp.offer_type=st.offer_type,
                dp.offer_value = st.offer_value,
                dp.strategy_name = st.strategy_name
        WHEN NOT MATCHED THEN
            INSERT (
                    fk_skuproductid,
                    --fk_filesourceid,
                    SKU_CODE,
                    productprice,
                    saleprice,
                    price_start_date,
                    price_end_date,
                    active_flag,
                    brand_name,
                    user,
                    module,
                    event_name,
                    inserted_date,
                    last_updated_date,
                    fk_currencyid,file_name,
                    offer_name,
                    brandsku,
                    offer_type,
                    offer_value,
                    strategy_name
                )
                VALUES (st.pk_skuproductid,
                       -- :file_source_id,
                        st.productcode,
                        st.productprice,
                        st.saleprice,
                        st.price_start_date,
                        st.price_end_date,
                        1,
                        st.brand_name,
                        st.user,
                        st.module,
                        st.event_name,
                        CURRENT_TIMESTAMP(),
                        CURRENT_TIMESTAMP(),
                        st.pk_currencyid,
                        st.file_name,
                        st.offer_name,
                        st.brandsku,
                        st.offer_type,
                        st.offer_value,
                        st.strategy_name);



    -- MERGE INTO ANALYTICS.PRODUCT_PRICING AS dp
    --     USING sourcetabletypethree AS st
    --     ON st.pk_skuproductid = dp.fk_skuproductid
    --         AND st.price_start_date <> dp.price_start_date
    --         AND st.price_start_date BETWEEN dp.price_start_date AND dp.price_end_date
    --         AND st.pk_currencyid = dp.fk_currencyid
    --        -- AND dp.fk_filesourceid = :file_source_id
    --     WHEN MATCHED THEN
    --         UPDATE SET
    --             dp.price_end_date = DATEADD(DAY, -1, st.price_start_date),
    --             dp.last_updated_date = CURRENT_TIMESTAMP();

    

    MERGE INTO  ANALYTICS.PRODUCT_PRICING AS dp
        USING (select distinct * from  sourcetabletypetwo where module = 'Promo') AS st
        ON st.pk_skuproductid = dp.fk_skuproductid
            AND st.price_start_date = dp.price_start_date
            AND st.pk_currencyid = dp.fk_currencyid
            AND dp.BRAND_NAME = st.brand_name
            and lower(dp.offer_name)=lower(st.offer_name)
            
           -- AND dp.fk_filesourceid = :file_source_id
        WHEN MATCHED THEN
            UPDATE SET
                dp.fk_skuproductid = st.pk_skuproductid,
                --dp.fk_filesourceid = :file_source_id,
                dp.SKU_CODE = st.productcode,
                dp.productprice = st.productprice,
                dp.saleprice = st.saleprice,
                dp.price_start_date = st.price_start_date,
                dp.price_end_date = st.price_end_date,
                dp.BRAND_NAME = st.brand_name,
                dp.USER = st.user,
                dp.MODULE = st.module,
                dp.EVENT_NAME = st.event_name,
                dp.fk_currencyid = st.pk_currencyid,
                dp.last_updated_date = CURRENT_TIMESTAMP(),
                dp.file_name = st.file_name,
                dp.offer_name=st.offer_name,
                dp.brandsku=st.brandsku,
                dp.offer_type=st.offer_type,
                dp.offer_value = st.offer_value,
                dp.strategy_name = st.strategy_name
        WHEN NOT MATCHED THEN
            INSERT (
                    fk_skuproductid,
                    --fk_filesourceid,
                    SKU_CODE,
                    productprice,
                    saleprice,
                    price_start_date,
                    price_end_date,
                    active_flag,
                    brand_name,
                    user,
                    module,
                    event_name,
                    inserted_date,
                    last_updated_date,
                    fk_currencyid,file_name,
                    offer_name,
                    brandsku,
                    offer_type,
                    offer_value,
                    strategy_name
                )
                VALUES (st.pk_skuproductid,
                       -- :file_source_id,
                        st.productcode,
                        st.productprice,
                        st.saleprice,
                        st.price_start_date,
                        st.price_end_date,
                        1,
                        st.brand_name,
                        st.user,
                        st.module,
                        st.event_name,
                        CURRENT_TIMESTAMP(),
                        CURRENT_TIMESTAMP(),
                        st.pk_currencyid,
                        st.file_name,
                        st.offer_name,
                        st.brandsku,
                        st.offer_type,
                        st.offer_value,
                        st.strategy_name);

                         ----non promo 

                MERGE INTO ANALYTICS.PRODUCT_PRICING AS dp
        USING (select distinct * from  sourcetabletypeone where module != 'Promo') AS st
        ON st.pk_skuproductid = dp.fk_skuproductid
            AND st.price_start_date = dp.price_start_date
            AND st.pk_currencyid = dp.fk_currencyid
            AND dp.BRAND_NAME = st.brand_name
                        
            --AND dp.fk_filesourceid = :file_source_id
        WHEN MATCHED THEN
            UPDATE SET
                dp.fk_skuproductid = st.pk_skuproductid,
               -- dp.fk_filesourceid = :file_source_id,
                dp.SKU_CODE = st.productcode,
                dp.productprice = st.productprice,
                dp.saleprice = st.saleprice,
                dp.price_start_date = st.price_start_date,
                dp.price_end_date = st.price_end_date,
                dp.BRAND_NAME = st.brand_name,
                dp.USER = st.user,
                dp.MODULE = st.module,
                dp.EVENT_NAME = st.event_name,
                dp.fk_currencyid = st.pk_currencyid,
                dp.last_updated_date = CURRENT_TIMESTAMP(),
                DP.file_name = st.file_name,
                dp.offer_name=st.offer_name,
                dp.brandsku=st.brandsku,
                dp.offer_type=st.offer_type,
                dp.offer_value = st.offer_value,
                dp.strategy_name = st.strategy_name
        WHEN NOT MATCHED THEN
            INSERT (
                    fk_skuproductid,
                    --fk_filesourceid,
                    SKU_CODE,
                    productprice,
                    saleprice,
                    price_start_date,
                    price_end_date,
                    active_flag,
                    brand_name,
                    user,
                    module,
                    event_name,
                    inserted_date,
                    last_updated_date,
                    fk_currencyid,file_name,
                    offer_name,
                    brandsku,
                    offer_type,
                    offer_value,
                    strategy_name
                )
                VALUES (st.pk_skuproductid,
                       -- :file_source_id,
                        st.productcode,
                        st.productprice,
                        st.saleprice,
                        st.price_start_date,
                        st.price_end_date,
                        1,
                        st.brand_name,
                        st.user,
                        st.module,
                        st.event_name,
                        CURRENT_TIMESTAMP(),
                        CURRENT_TIMESTAMP(),
                        st.pk_currencyid,
                        st.file_name,
                        st.offer_name,
                        st.brandsku,
                        st.offer_type,
                        st.offer_value,
                        st.strategy_name);



    -- MERGE INTO ANALYTICS.PRODUCT_PRICING AS dp
    --     USING sourcetabletypethree AS st
    --     ON st.pk_skuproductid = dp.fk_skuproductid
    --         AND st.price_start_date <> dp.price_start_date
    --         AND st.price_start_date BETWEEN dp.price_start_date AND dp.price_end_date
    --         AND st.pk_currencyid = dp.fk_currencyid
    --        -- AND dp.fk_filesourceid = :file_source_id
    --     WHEN MATCHED THEN
    --         UPDATE SET
    --             dp.price_end_date = DATEADD(DAY, -1, st.price_start_date),
    --             dp.last_updated_date = CURRENT_TIMESTAMP();

    
    MERGE INTO  ANALYTICS.PRODUCT_PRICING AS dp
        USING (select distinct * from sourcetabletypetwo where module != 'Promo') AS st
        ON st.pk_skuproductid = dp.fk_skuproductid
            AND st.price_start_date = dp.price_start_date
            AND st.pk_currencyid = dp.fk_currencyid
            AND dp.BRAND_NAME = st.brand_name
            
           -- AND dp.fk_filesourceid = :file_source_id
        WHEN MATCHED THEN
            UPDATE SET
                dp.fk_skuproductid = st.pk_skuproductid,
                --dp.fk_filesourceid = :file_source_id,
                dp.SKU_CODE = st.productcode,
                dp.productprice = st.productprice,
                dp.saleprice = st.saleprice,
                dp.price_start_date = st.price_start_date,
                dp.price_end_date = st.price_end_date,
                dp.BRAND_NAME = st.brand_name,
                dp.USER = st.user,
                dp.MODULE = st.module,
                dp.EVENT_NAME = st.event_name,
                dp.fk_currencyid = st.pk_currencyid,
                dp.last_updated_date = CURRENT_TIMESTAMP(),
                dp.file_name = st.file_name,
                dp.offer_name=st.offer_name,
                dp.brandsku=st.brandsku,
                dp.offer_type=st.offer_type,
                dp.offer_value = st.offer_value,
                dp.strategy_name = st.strategy_name
        WHEN NOT MATCHED THEN
            INSERT (
                    fk_skuproductid,
                    --fk_filesourceid,
                    SKU_CODE,
                    productprice,
                    saleprice,
                    price_start_date,
                    price_end_date,
                    active_flag,
                    brand_name,
                    user,
                    module,
                    event_name,
                    inserted_date,
                    last_updated_date,
                    fk_currencyid,file_name,
                    offer_name,
                    brandsku,
                    offer_type,
                    offer_value,
                    strategy_name
                )
                VALUES (st.pk_skuproductid,
                       -- :file_source_id,
                        st.productcode,
                        st.productprice,
                        st.saleprice,
                        st.price_start_date,
                        st.price_end_date,
                        1,
                        st.brand_name,
                        st.user,
                        st.module,
                        st.event_name,
                        CURRENT_TIMESTAMP(),
                        CURRENT_TIMESTAMP(),
                        st.pk_currencyid,
                        st.file_name,
                        st.offer_name,
                        st.brandsku,
                        st.offer_type,
                        st.offer_value,
                        st.strategy_name);

    -- UPDATE TRANSFORMED.LOG_INPUTSHEET AS tgt
    -- SET staging_record_count = (SELECT COUNT(*)
    --                             FROM TRANSFORMED.STG_HYBRIS_PRICE_CHILD),
    --     is_rejected          = 0,
    --     rejection_reason     = ' '
    -- WHERE tgt.fk_inputfileid = :audit_source_id;

    COMMIT;

    DROP TABLE IF EXISTS sourcetabletypeone;
    DROP TABLE IF EXISTS sourcetabletypetwo;
    DROP TABLE IF EXISTS sourcetabletypethree;

  DROP TABLE IF EXISTS TempOrderReleaseStatus;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :pipeline_name,
            'upsert',
            'COMPLETED',
            :start_time_proc,
            CURRENT_TIMESTAMP(),
            'upsert completed successfully'
        );
    SYSTEM$LOG('TRACE','SP COMPLETED- '||:pipeline_name);
COMMIT;

RETURN 'Success';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
               -- Return error message
    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        'upsert',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- '||:pipeline_name);
	RETURN error_object;
END;
