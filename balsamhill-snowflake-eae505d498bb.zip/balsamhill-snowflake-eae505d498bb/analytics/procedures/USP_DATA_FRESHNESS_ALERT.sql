CREATE OR REPLACE PROCEDURE ANALYTICS.USP_DATA_FRESHNESS_ALERT()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS DECLARE

    error_object VARIANT;
    start_time_proc TIMESTAMP_NTZ(9); 
    v_count NUMBER;
    
    my_resultset RESULTSET;
    concatenated_values STRING DEFAULT '';

    v_table_name STRING DEFAULT '';
    v_column_name STRING DEFAULT '';
    v_threshold INT DEFAULT 0;
    v_frequency STRING DEFAULT '';
    v_alert_type STRING DEFAULT '';
    v_sql STRING DEFAULT '';
    v_max_time RESULTSET;
    output_string STRING DEFAULT '';
    v_max_inserted_time STRING DEFAULT '';


    html_header STRING DEFAULT '<tr>';
    html_rows STRING DEFAULT '';
    email_body STRING;

    email_resultset RESULTSET;

    table_name STRING DEFAULT '';
    last_inserted_time STRING DEFAULT '';
    minutes_since_insert STRING DEFAULT '';
    frequency STRING DEFAULT '';
    alert_type STRING DEFAULT '';

BEGIN

    start_time_proc := CURRENT_TIMESTAMP();

    SYSTEM$LOG('TRACE','SP STARTED- Data Freshness Alert ');

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        'Data Freshness Alert',
        'Freshness',
        'STARTED',
        :start_time_proc,
        NULL,
        'started'
    );
        

    CREATE OR REPLACE TEMP TABLE temp_alert_results (
        table_name STRING,
        last_inserted_time TIMESTAMP_NTZ,
        minutes_since_insert INT,
        frequency STRING,
        alert_type STRING
    );
    
    my_resultset := (SELECT TABLE_NAME, AUD_INSERT_DATE_COLUMN_NAME, THRESHOLD_TIME, FREQUENCY, ALERT_TYPE
         FROM analytics.pipeline_run_alerts_config);

    FOR record IN my_resultset DO

        v_table_name := record.TABLE_NAME;
        v_column_name := record.AUD_INSERT_DATE_COLUMN_NAME;
        v_threshold := record.THRESHOLD_TIME;
        v_frequency := record.FREQUENCY;
        v_alert_type := record.ALERT_TYPE;

        v_sql := 'SELECT MAX(' || :v_column_name || ') as max_time FROM analytics.' || :v_table_name;
        v_max_time := (EXECUTE IMMEDIATE :v_sql);

        FOR record IN v_max_time DO
            v_max_inserted_time := record.max_time::TIMESTAMP;
            
            LET v_minutes_diff int := DATEDIFF('minute', record.max_time::TIMESTAMP, CURRENT_TIMESTAMP());
            
            IF (v_minutes_diff > v_threshold) THEN
                INSERT INTO temp_alert_results
                VALUES (:v_table_name, :v_max_inserted_time, :v_minutes_diff, :v_frequency, :v_alert_type);
            END IF;
            
        END FOR;

    END FOR;

    html_header := html_header || '<th>TABLE NAME</th>';
    html_header := html_header || '<th>LAST INSERTED TIME</th>';
    html_header := html_header || '<th>MINUTES SINCE INSERT</th>';
    html_header := html_header || '<th>FREQUENCY</th>';
    html_header := html_header || '<th>ALERT TYPE</th>';
    html_header := html_header || '</tr>';

    email_resultset := (select * from temp_alert_results);

    FOR record IN email_resultset DO
        table_name := record.table_name;
        last_inserted_time := record.last_inserted_time;
        minutes_since_insert := record.minutes_since_insert;
        frequency := record.frequency;
        alert_type := record.alert_type;

        html_rows := html_rows || '<tr>';
        html_rows := html_rows || '<td>' || :table_name || '</td>';
        html_rows := html_rows || '<td>' || :last_inserted_time || '</td>';
        html_rows := html_rows || '<td>' || :minutes_since_insert || '(' || ROUND(:minutes_since_insert / 60, 2)
 || 'hrs)' || '</td>';
        html_rows := html_rows || '<td>' || :frequency || '</td>';
        html_rows := html_rows || '<td>' || :alert_type || '</td>';
        html_rows := html_rows || '</tr>';
    END FOR;

     email_body := 
        '<html><body>' ||
        '<h3>Data Freshness</h3>' ||
        '<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse;">' ||
        html_header || html_rows ||
        '</table>' ||
        '</body></html>';

    SELECT COUNT(*) INTO :v_count FROM temp_alert_results;

    IF (v_count > 0) THEN
        CALL SYSTEM$SEND_EMAIL(
            'data_freshness_email_integration',
            'mchinchakhandi@balsambrands.com',
            '🔴Data Freshness Alert',
            :email_body,
            'text/html'
        );
    END IF;
    
    
     CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        'Data Freshness Alert',
        'Freshness',
        'COMPLETED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        'Freshness ALERT SP executed successfully'
    );

    SYSTEM$LOG('TRACE','SP COMPLETED- Data Freshness Alert' );

    COMMIT;   
  RETURN 'Data Freshness Alert SP executed successfully';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
   

    error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                     'SQLCODE', sqlcode,
                                     'SQLERRM', sqlerrm,
                                     'SQLSTATE', sqlstate);

    --error_string := TO_JSON(error_object);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        'Data Freshness Alert',
        'Freshness',
        'FAILED',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG('ERROR','SP FAILED- Data Freshness Alert');

    RETURN error_object;
    
END;
