USE DATABASE DEV;

CREATE OR REPLACE PROCEDURE ANALYTICS.USP_MASTER_PRODUCT_UPSERT("PIPELINE_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS 'DECLARE 
start_time_proc TIMESTAMP_NTZ(9); 
error_object VARIANT;
BEGIN 
 
start_time_proc := CURRENT_TIMESTAMP();
SYSTEM$LOG(''TRACE'',''SP STARTED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
    :pipeline_name,
    ''upsert'',
    ''STARTED'',
    :start_time_proc,
    NULL,
    ''Staging started''
);

CALL TRANSFORMED.USP_UPDATE_LANGUAGE_FORMAT();

CALL TRANSFORMED.REMOVE_DUPLICATES_FROM_RAW_PRODUCT_PRODUCT();
CALL TRANSFORMED.REMOVE_DUPLICATES_FROM_RAW_PRODUCT_CARTON();
CALL TRANSFORMED.REMOVE_DUPLICATES_FROM_RAW_PRODUCT_PARTNER();
CALL TRANSFORMED.REMOVE_DUPLICATES_FROM_RAW_PRODUCT_SECTION();

CALL ANALYTICS.USP_SKU_PRODUCT_LOCALE_UPSERT();
CALL ANALYTICS.USP_UPC_UPSERT();

SYSTEM$LOG(''TRACE'',''SP COMPLETED- ''||:pipeline_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
    :pipeline_name,
    ''upsert'',
    ''COMPLETED'',
    :start_time_proc,
    CURRENT_TIMESTAMP(),
    ''Staging completed successfully''
);

RETURN ''USP_MASTER_PRODUCT_UPSERT executed successfully'';
EXCEPTION
    WHEN statement_error THEN
    ROLLBACK;
    
    error_object := OBJECT_CONSTRUCT(''Error type'', ''STATEMENT_ERROR'',
                                     ''SQLCODE'', sqlcode,
                                     ''SQLERRM'', sqlerrm,
                                     ''SQLSTATE'', sqlstate);

    CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
        :pipeline_name,
        ''upsert'',
        ''FAILED'',
        :start_time_proc,
        CURRENT_TIMESTAMP(),
        TO_JSON(:error_object)
    );

    SYSTEM$LOG(''ERROR'',''SP FAILED- ''||:pipeline_name);

    RETURN error_object;
                            
END';
