create or replace secure view PROD.ANALYTICS.CORE_SKUINVENTORY_ALLCHANNELS COPY GRANTS as 
--;
WITH CTE_Inventory AS
(
SELECT 
    pk_raw_hybris_productid
    , CASE 
        WHEN brandId IN ('10', '8', '7', '6') -- AU, DE, FR, UK
            THEN CAST(inserted_date AS DATETIME)
        ELSE CAST(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', inserted_date) AS DATETIME)
        END AS inserted_date
    , CASE 
        WHEN brandId IN ('10', '8', '7', '6') -- AU, DE, FR, UK
            THEN CAST(ALERTRAISEDTS AS DATETIME)
        ELSE CAST(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', ALERTRAISEDTS) AS DATETIME)
        END AS UPDATED_DATE
    ,sku_code
    ,brandID
    ,sourceid
FROM ANALYTICS.audit_storefront_inventory 
WHERE
sku_code NOT LIKE '%TEST%'
AND sku_code != '' 
AND sku_code NOT LIKE '1000%' --extend warranty items
),

CTE_EarliestInventory AS
(
SELECT 
    MIN(pk_raw_hybris_productid) AS pk_raw_hybris_productid
FROM CTE_Inventory
GROUP BY
    sku_code    
    ,brandID
    ,sourceid
    ,inserted_date
),

CTE_Active AS
(
SELECT
    BrandID
    ,sourceid
    ,sku_code
FROM ANALYTICS.audit_storefront_inventory
GROUP BY brandID,sourceid, sku_code
HAVING MAX(stock) > 0    
)
, PREV AS (
SELECT
    CONCAT(B.BrandCodeforPOTracker, ASI.sku_code) AS BrandSku
    ,B.BrandCodeForPOTracker AS Brand
    , CASE WHEN CHANNEL='WEBSITE' THEN 'HYBRIS'
    ELSE CHANNEL END
    AS Platform    
    , CASE 
        WHEN ASI.brandId IN ('10', '8', '7', '6') -- AU, DE, FR, UK
            THEN CAST(ASI.inserted_date AS DATETIME)
        ELSE CAST(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', ASI.inserted_date) AS DATETIME)
        END AS InventoryDate    
    , CASE 
        WHEN ASI.brandId IN ('10', '8', '7', '6') -- AU, DE, FR, UK
            THEN ASI.inserted_date
        ELSE CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', ASI.inserted_date)
        END AS InventoryDateTime
    , CASE 
        WHEN ASI.brandId IN ('10', '8', '7', '6') -- AU, DE, FR, UK
            THEN ASI.alertraisedts
        ELSE CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', ASI.alertraisedts)
        END AS InventoryAlertRaisedTS
	, ASI.sku_code AS Sku
	, CAST(ASI.stock AS NUMBER) AS OnHandInventory
FROM CTE_EarliestInventory M
    JOIN ANALYTICS.audit_storefront_inventory ASI  ON M.pk_raw_hybris_productid = ASI.pk_raw_hybris_productid
    JOIN CTE_Active WS ON ASI.brandID = WS.brandID AND ASI.sku_code = WS.sku_code AND ASI.sourceid = WS.sourceid
    JOIN MASTER.dim_brand B ON ASI.BrandID = B.pk_brandID
    JOIN MASTER.dim_source S ON pk_sourceid=ASI.sourceid and B.pk_brandid = S.fk_brandid
ORDER BY INVENTORYDATE DESC 
)
, RN AS (
SELECT BRANDSKU,
	BRAND,
	PLATFORM,
	INVENTORYDATE,
	SKU,
	ONHANDINVENTORY,
    InventoryAlertRaisedTS,
    ROW_NUMBER() OVER (PARTITION BY BRAND,SKU, INVENTORYDATE ORDER BY InventoryDateTime DESC) RN 
FROM PREV 
QUALIFY RN = 1 
)
SELECT BRANDSKU,
	BRAND,
	CASE
        WHEN PLATFORM = 'AMAZON-BH' THEN 'Amazon-BH'
        WHEN PLATFORM = 'AMAZON-TC' THEN 'Amazon-TC'
        WHEN PLATFORM = 'AMAZON-TT' THEN 'Amazon-TT'
        WHEN PLATFORM = 'NORDSTROM' THEN 'Nordstrom'
        WHEN PLATFORM = 'NORDSTROM-RACK' THEN 'NordstromRack'
        WHEN PLATFORM = 'POTTERYBARN' THEN 'PotteryBarn' 
        WHEN PLATFORM = 'SERENAANDLILY' THEN 'Serena And Lily'
        WHEN PLATFORM = 'WILLIAMSSONOMA' THEN 'WilliamSonoma'
        ELSE INITCAP(PLATFORM) 
    END 
    as PLATFORM,
    COALESCE(CAST(InventoryAlertRaisedTS AS DATETIME), CAST(INVENTORYDATE AS DATETIME)) AS INVENTORYDATE,
	SKU,
	ONHANDINVENTORY,
    CAST(INVENTORYDATE AS DATETIME) AS UPDATE_TIMESTAMP,
FROM RN  
;
