create or replace secure view PROD.ANALYTICS.VW_WAREHOUSE_RECEIPT COPY GRANTS as 
--;
WITH ValidWHReceipts AS (
    SELECT ContainerNumber
        , CAST(DateReceived AS DATETIME) AS DateReceived 
        , CAST(MODIFIEDON AS DATETIME) AS MODIFIEDON 
        , InventoryPackingListSummaryID
        , MAX(ID) AS ID -- to remove duplicate warehouse receipts (there should only be one receipt per container in an HBL)
    FROM ANALYTICS.INVENTORYWAREHOUSERECEIPT
    GROUP BY ALL
)

SELECT DISTINCT -- necessary to remove duplicates caused by different UPCs per SKU
    h.ID AS warehouse_receipt_id 
    , h.ContainerNumber AS container_number
    , d.PONumber AS po_number
    , d.Sku AS sku
    , h.DateReceived AS date_received -- date the container was received
    , d.ReceivedQty AS quantity_received 
    , h.InventoryPackingListSummaryID
    , H.MODIFIEDON AS UPDATE_TIMESTAMP
FROM ANALYTICS.InventoryWarehouseReceiptDetail d
    LEFT JOIN ValidWHReceipts h ON h.ID = d.InventoryWarehouseReceiptID
    ;
