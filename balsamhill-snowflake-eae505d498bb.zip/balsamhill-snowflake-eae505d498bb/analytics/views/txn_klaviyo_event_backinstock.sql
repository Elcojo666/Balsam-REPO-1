CREATE OR REPLACE VIEW analytics.txn_klaviyo_event_backinstock AS
WITH geo_brand AS (
    SELECT pk_brandid, substring(brandcodeforpotracker, 3, 2) as geo
    FROM master.dim_brand
    WHERE brandcodeforpotracker IN (
        'BHUS',
        'BHFR',
        'BHUK',
        'BHAU',
        'BHDE',
        'BHCA' // only dev use BHCAN
        )
    )
SELECT sku, email, datetime, gb.pk_brandid AS fk_brandid
FROM transformed.klaviyo_event_notifyme AS src
         LEFT JOIN geo_brand AS gb ON gb.geo = src.geo
WHERE email IS NOT NULL
    QUALIFY ROW_NUMBER() OVER (PARTITION BY sku, email, src.geo, datetime ORDER BY inserted_date DESC) = 1
UNION
SELECT sku, emial, datetime, fk_brandid
FROM analytics.txn_klaviyo_event_notifyme
         QUALIFY ROW_NUMBER() OVER (PARTITION BY sku, emial ORDER BY modified_date DESC, inserted_date DESC) = 1;