create or replace secure view PROD.ANALYTICS.CORE_ORDERALLLEVELINFORMATION_PLUS_RETURNS_MAX_SECURE(
	PK_ORDER_HEADERID,
	BRAND,
	PLATFORM,
	ORDERID,
	ORDERDATE,
	CURRENCY,
	ORDERSTATUS,
	PAYMENTMETHODID,
	SHIPCOUNTRY,
	SHIPSTATE,
	FOREXRATE,
	TOTALPAYMENTRECEIVED,
	TOTALSHIPPINGCOST,
	TOTALTAX,
	SKU,
	PRODUCTNAME,
	DEPARTMENT,
	SUBDEPARTMENT,
	CLASS,
	UNITSOLD,
	PRODUCTPRICE,
	DISCOUNTCODE,
	DISCOUNTNAME,
	DISCOUNTAMOUNT,
	ORDERLEVEL,
	MODIFIED_DATE
) as 
--;
WITH CTE_ID AS
(
SELECT * FROM ANALYTICS.MIGRATED_ORDERIDS_MAX_RETURNS_WARRANTY_INCLUDED
--WHERE CAST(ORDER_DATE AS DATE) between '2022-01-01' AND CURRENT_DATE - INTERVAL '1 DAY'
),

CTE_Tax AS
(
SELECT *
FROM ANALYTICS.MIGRATED_OrderTax_max_RETURNS_WARRANTY_INCLUDED
), 

CTE_ExtendedWarranty AS
(
SELECT 
    pk_order_headerid
    ,SUM(UnitSold * ProductPrice) AS ExtendWarranty
FROM ANALYTICS.MIGRATED_ExtendedWarranty_max
GROUP BY pk_order_headerid
),

CTE_ExtendWarrantyDetail AS
(
SELECT
    pk_order_detailid
    ,ProductPrice
FROM ANALYTICS.MIGRATED_ExtendedWarranty_max_RETURNS_WARRANTY_INCLUDED
),

CTE_PaymentMethod AS
(
SELECT *
FROM ANALYTICS.MIGRATED_PaymentMethod_RETURNS_WARRANTY_INCLUDED
),

CTE_Shipping AS
(
SELECT *
FROM ANALYTICS.MIGRATED_TotalShippingCost_max_RETURNS_WARRANTY_INCLUDED
),

--- DISCOUNT 
CTE_DiscountInfo_PRE AS (
--ORDER LEVEL DISCOUNTS
--preTSU
SELECT 
    ID.pk_order_headerid
    ,OD.discount_code AS DiscountCode
    ,OD.discount_name AS DiscountName
    ,OD.coupon_code AS CouponCode
    ,'Order' AS DiscountLevel
	,ABS(OD.discount_amount) AS DiscountAmount
FROM CTE_ID ID
    JOIN ANALYTICS.TXN_order_discount OD  ON OD.fk_order_headerid = ID.pk_order_headerid
WHERE
    (OD.discount_code NOT IN
    (
        'TEST', 
        'DSC-(test)',
        'DSC-CC',
        'DSC-CCC',
        'DSC-Corp'
        ,'TKTestBuyXGetY'
    ) or  OD.DISCOUNT_CODE IS NULL)
    AND ID.order_date < '2023-06-13'
    AND ABS(OD.discount_amount) > 0

UNION

--postTSU
SELECT 
    ID.pk_order_headerid
    ,COALESCE(OD.discount_name, 'UNKNOWN') AS DiscountCode
    ,COALESCE(OD.discount_code, 'UNKNOWN') AS DiscountName
    ,OD.coupon_code AS CouponCode
    ,'Order' AS DiscountLevel
	,ABS(OD.discount_amount) AS DiscountAmount
FROM CTE_ID ID
    JOIN ANALYTICS.TXN_order_discount OD  ON OD.fk_order_headerid = ID.pk_order_headerid
WHERE
    (OD.discount_code NOT IN
    (
        'TEST', 
        'DSC-(test)',
        'DSC-CC',
        'DSC-CCC',
        'DSC-Corp'
        ,'TKTestBuyXGetY'
    ) OR OD.DISCOUNT_CODE IS NULL)
    AND ID.order_date >= '2023-06-13'
    AND ABS(OD.discount_amount) > 0


UNION 

--LINE LEVEL DISCOUNTS
--preTSU
SELECT 
    ID.pk_order_headerid
	,ODD.discount_code AS DiscountCode
    ,ODD.discount_name AS DiscountName
    ,IFNULL(ODD.coupon_code,OLC.coupon_code) AS CouponCode
    ,'Line' AS DiscountLevel
	,SUM(ABS(ODD.discount_amount)) AS DiscountAmount
FROM CTE_ID ID
    JOIN ANALYTICS.TXN_order_detail OD  ON ID.pk_order_headerid = OD.fk_order_headerid
    JOIN ANALYTICS.TXN_order_detail_discount ODD  ON ODD.fk_order_detailid = OD.pk_order_detailid
    LEFT JOIN ANALYTICS.map_order_line_coupon_codes OLC ON OD.pk_order_detailid = OLC.order_detailid --postTSU coupons backfill
WHERE
   (ODD.discount_code NOT IN 
    (
        'TEST', 
        'DSC-(test)',
        'DSC-CC',
        'DSC-CCC',
        'DSC-Corp'
        ,'TKTestBuyXGetY'
        ) OR ODD.DISCOUNT_CODE IS NULL)
    AND ID.order_date < '2023-06-13'
    AND ABS(ODD.discount_amount) > 0
    
GROUP BY 
    ID.pk_order_headerid
	,ODD.discount_code
    ,ODD.discount_name
    ,ODD.coupon_code
    ,OLC.coupon_code

UNION

--postTSU
SELECT 
    ID.pk_order_headerid
    ,COALESCE(ODD.discount_name, 'UNKNOWN') AS DiscountCode
    ,COALESCE(ODD.discount_code, 'UNKNOWN') AS DiscountName
    ,IFNULL(ODD.coupon_code,OLC.coupon_code) AS CouponCode
    ,'Line' AS DiscountLevel
	,SUM(ABS(ODD.discount_amount)) AS DiscountAmount
FROM CTE_ID ID
    JOIN ANALYTICS.TXN_order_detail OD  ON ID.pk_order_headerid = OD.fk_order_headerid
    JOIN ANALYTICS.TXN_order_detail_discount ODD  ON ODD.fk_order_detailid = OD.pk_order_detailid
    LEFT JOIN ANALYTICS.map_order_line_coupon_codes OLC ON OD.pk_order_detailid = OLC.order_detailid --postTSU coupons backfill
WHERE
   (ODD.discount_code NOT IN 
    (
        'TEST', 
        'DSC-(test)',
        'DSC-CC',
        'DSC-CCC',
        'DSC-Corp'
        ,'TKTestBuyXGetY'
        ) OR ODD.DISCOUNT_CODE IS NULL)
    AND ID.order_date >= '2023-06-13'
    AND ABS(ODD.discount_amount) > 0
    
GROUP BY 
    ID.pk_order_headerid
	,ODD.discount_code
    ,ODD.discount_name
    ,ODD.coupon_code
    ,OLC.coupon_code
),

CTE_ExchangeRate AS
(
SELECT *
FROM ANALYTICS.MIGRATED_ExchangeRate
)
, CTE_DEFINITE_DISCOUNT AS (
SELECT
    DI.pk_order_headerid
    ,DB.BrandCodeForPOTracker AS Brand
    ,DP.platform_name AS Platform
    ,OH.source_ref_num AS OrderID
    ,ID.order_date AS OrderDate
    ,ID.order_date_local AS OrderDateLocal
    ,DI.DiscountCode
    ,DI.DiscountName
    ,DI.CouponCode
    ,DI.DiscountAmount
    ,DI.DiscountLevel
    ,DC.currency_code AS Currency 
    ,ER.ForexRate
FROM CTE_DiscountInfo_PRE DI
    JOIN CTE_ID ID ON DI.pk_order_headerid = ID.pk_order_headerid
    JOIN ANALYTICS.TXN_order_header OH  ON DI.pk_order_headerid = OH.pk_order_headerid
    LEFT JOIN MASTER.dim_currency DC  ON OH.fk_currencyid = DC.pk_currencyid
    JOIN MASTER.dim_source DS  ON OH.fk_sourceid = DS.pk_sourceid
    JOIN MASTER.dim_brand DB  ON DS.fk_brandid = DB.pk_brandid
    JOIN MASTER.dim_platform DP  ON DS.fk_platformid = DP.pk_platformid
    LEFT JOIN CTE_ExchangeRate ER  ON ER.PublishDate = CAST(ID.order_date AS DATE) AND ER.Currency = DC.currency_code
)
, CTE_DiscountInfo AS (
SELECT
    pk_order_headerid
    ,DiscountCode
    ,DiscountName
    ,CouponCode
    ,DiscountAmount
    ,DiscountLevel
FROM CTE_DEFINITE_DISCOUNT
),

CTE_ProductMaster AS
(
SELECT 
    CASE 
        WHEN Brand = 'BHAU' THEN 10
        WHEN Brand = 'BHCA' THEN 19
        WHEN Brand = 'BHDE' THEN 8
        WHEN Brand = 'BHFR' THEN 7
        WHEN Brand = 'BHUK' THEN 6
        WHEN Brand = 'BHUS' THEN 1
        WHEN Brand = 'TC' THEN 15
        WHEN Brand = 'TT' THEN 16
    ELSE 0
    END AS BrandID
    ,Sku
    ,PRODUCT_NAME
    ,Department
    ,SubDepartment
    ,Class
FROM ANALYTICS.CORE_SKUMASTER_COPY SM 
WHERE Brand IS NOT NULL
),

CTE_Everyline AS (
--INSERT INTO #Everyline
SELECT DISTINCT
    ID.pk_order_headerid
    ,DB.BrandCodeForPOTracker AS Brand
    ,DP.platform_name AS Platform
    ,OH.Source_Ref_Num AS OrderID
    ,CAST(ID.order_date AS DATE) AS OrderDate
    ,DC.currency_code AS Currency 
    ,DOS.order_status_name AS OrderStatus
    ,PM.payment_method_name AS PaymentMethodID
    ,SHIPADDR.State AS ShipState
    ,SHIPADDR.Country AS ShipCountry
    ,ER.ForexRate
FROM CTE_ID ID
    JOIN ANALYTICS.TXN_order_header OH  ON ID.pk_order_headerid = OH.pk_order_headerid
	LEFT JOIN ANALYTICS.TXN_order_status TOS  ON OH.pk_order_headerid = TOS.fk_order_headerid
    JOIN MASTER.dim_order_status DOS  ON TOS.fk_order_statusid = DOS.pk_order_statusid
    JOIN MASTER.dim_source DS  ON ID.fk_sourceid = DS.pk_sourceid
    JOIN MASTER.dim_brand DB  ON DS.fk_brandid = DB.pk_brandid
    JOIN MASTER.dim_platform DP  ON DS.fk_platformid = DP.pk_platformid
    LEFT JOIN CTE_PaymentMethod PM ON ID.pk_order_headerid = PM.pk_order_headerid
    LEFT JOIN MASTER.dim_currency DC ON OH.fk_currencyid = DC.pk_currencyid
    LEFT JOIN CTE_ExchangeRate ER  ON ER.PublishDate = CAST(ID.order_date AS DATE) AND ER.Currency = DC.currency_code
    LEFT JOIN ANALYTICS.audit_address SHIPADDR  ON OH.fk_shipping_addressid = SHIPADDR.pk_addressid
WHERE SHIPADDR.Revision = 1 OR SHIPADDR.Revision IS NULL
),
CTE_OrderInformation AS (
--Header Level  
SELECT DISTINCT
    ID.pk_order_headerid
    ,ID.TotalPaymentReceived - IFNULL(EW.ExtendWarranty,0) AS TotalPaymentReceived  --LESS 60% for Extendwarranty
    ,IFNULL(SHIPPING.TotalShippingCost,0) AS TotalShippingCost    
    ,IFNULL(Tax.TotalTax,0) AS TotalTax
    ,'' AS Sku
    ,'' AS ProductName
    ,'' AS Department
    ,'' AS SubDepartment
    ,'' AS Class
    ,0 AS UnitSold
    ,0 AS ProductPrice
    ,'' AS DiscountCode
    ,'' AS DiscountName
    ,0 AS DiscountAmount
    ,'Header' AS OrderLevel
    , ID.MODIFIED_DATE
FROM CTE_ID ID
    LEFT JOIN CTE_Tax Tax  ON ID.pk_order_headerid = Tax.pk_order_headerid
    LEFT JOIN CTE_ExtendedWarranty EW ON ID.pk_order_headerid = EW.pk_order_headerid
    LEFT JOIN CTE_Shipping SHIPPING ON ID.pk_order_headerid = SHIPPING.pk_order_headerid

UNION
--Line Level
SELECT DISTINCT
    ID.pk_order_headerid
    ,0 AS TotalPaymentReceived 
    ,0 AS TotalShippingCost
    ,0 AS TotalTax 
    ,SKU.SKU_code AS Sku
    ,OD.product_name AS ProductName
    ,PM.Department
    ,PM.SubDepartment
    ,PM.Class
    ,OD.quantity AS UnitSold
    , CASE
        WHEN ID.order_date >= '2023-06-13' AND DS.locale NOT IN ('en_WW','en_CA') THEN (CAST(OD.product_price * OD.quantity AS FLOAT) + CAST(EOD.tax AS FLOAT))/ OD.quantity --postTSU add Vat Tax to BHI products
        WHEN OD.product_name LIKE 'Extend%' THEN CAST(OD.product_price *0.4 AS FLOAT) --Extend Warranty
        ELSE OD.product_price END AS ProductPrice
    ,'' AS DiscountCode
    ,'' AS DiscountName
    ,0 AS DiscountAmount
    ,'Line' AS OrderLevel
    , ID.MODIFIED_DATE
FROM CTE_ID ID
    JOIN ANALYTICS.TXN_order_detail OD  ON ID.pk_order_headerid = OD.fk_order_headerid
    JOIN MASTER.dim_source DS  ON ID.fk_sourceid = DS.pk_sourceid
	JOIN ANALYTICS.MIGRATED_SkuProduct SKU ON SKU.pk_skuproductid = OD.fk_skuproductid AND SKU.pk_brandID = DS.fk_brandid
    LEFT JOIN ANALYTICS.ext_order_detail EOD  ON OD.order_line_key = EOD.order_line_key
    LEFT JOIN CTE_ProductMaster PM  ON PM.BRANDID = DS.fk_brandid AND PM.Sku = SKU.sku_code

WHERE 
    OD.quantity > 0

UNION
--Discount Level
SELECT 
    DI.pk_order_headerid
    ,0 AS TotalPaymentReceived 
    ,0 AS TotalShippingCost
    ,0 AS TotalTax 
    ,'' AS Sku
    ,'' AS ProductName
    ,'' AS Department
    ,'' AS SubDepartment
    ,'' AS Class
    ,0 AS UnitSold
    ,0 AS ProductPrice
    ,DI.DiscountCode
    ,DI.DiscountName
    ,DI.DiscountAmount
    ,'Discount' AS OrderLevel
    , ID.MODIFIED_DATE
FROM CTE_ID ID
    JOIN CTE_DiscountInfo DI ON ID.pk_order_headerid = DI.pk_order_headerid
)
SELECT
	E.pk_order_headerid
    ,Brand
    ,(REGEXP_REPLACE(Platform, '(DSCO|EDI).*$', '')
    ||
    CASE 
        WHEN Platform = 'Amazon' THEN '-' || SUBSTR(BRAND, 1, 2)
        ELSE ''
    END) 
    AS Platform   
    ,OrderID
	,OrderDate
	,Currency
	,OrderStatus
	,PaymentMethodID
    ,ShipCountry
    ,ShipState
    ,ForexRate
    ,TotalPaymentReceived 
    ,TotalShippingCost 
    ,TotalTax 
	,Sku

    ,ProductName
    ,Department
    ,SubDepartment
    ,Class
	,UnitSold
	,ProductPrice
	,DiscountCode
	,DiscountName
	,DiscountAmount
	,OrderLevel
    , CAST(O.MODIFIED_DATE AS DATETIME) MODIFIED_DATE
	
FROM CTE_EveryLine E
    JOIN CTE_OrderInformation O ON O.pk_order_headerid = E.pk_order_headerid
--where OrderDate between '2022-01-01' AND CURRENT_DATE - INTERVAL '1 DAY'
  --  and Brand = 'BHCA'
 --   and OrderID = 'J101100980'
;