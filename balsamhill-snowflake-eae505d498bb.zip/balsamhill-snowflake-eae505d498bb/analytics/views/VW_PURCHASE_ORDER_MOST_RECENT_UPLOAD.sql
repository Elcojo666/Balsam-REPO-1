CREATE OR REPLACE SECURE VIEW ANALYTICS.VW_PURCHASE_ORDER_MOST_RECENT_UPLOAD AS 
 SELECT h.fk_supplierid AS vendor_id
        , s.supplier_name AS vendor_name
        , co.country_desc AS origin_country    
        , cd.country_desc AS destination_country
        , h.po_number 
        , h.season_name -- company fiscal year
        , h.po_date 
        , w.warehouse_name AS receiving_warehouse
        , d.fk_brandid AS brand_id 
        , b.brandcode AS brand
        , h.pk_po_headerid 
        , d.skuproductcode AS sku
        , CASE 
            WHEN h.initial_eta IS NOT NULL THEN h.initial_eta 
            WHEN h.initial_eta IS NULL AND co.country_code = 'US' AND cd.country_code = 'US' THEN DATEADD(day, 5, h.etd_shipping_end)
            WHEN h.etd_shipping_end IS NULL THEN NULL
            ELSE DATEADD(day, 45, h.etd_shipping_end)
            END AS initial_eta
        , d.ordered_quantity
        , t.POTypeName AS po_type -- e.g. dropship, regular, dummy
        , d.initial_unit_price -- unit price of the sku    
        , ROW_NUMBER() OVER(PARTITION BY d.po_number, d.skuproductcode ORDER BY d.fk_po_headerid DESC ) AS RN -- assign row number to each PO-SKU combo in descending order based on po_headerid (necessary for cases wherein the PO is registered twice in POD)
    FROM ANALYTICS.TXN_po_header h 
        LEFT JOIN ANALYTICS.TXN_po_detail d ON h.pk_po_headerid = d.fk_po_headerid 
        LEFT JOIN MASTER.DIM_po_brand b ON d.fk_brandid = b.Id -- to get BrandCode
        LEFT JOIN MASTER.DIM_warehouse w ON h.fk_destination_warehouseid = w.pk_warehouseid -- to get h_receiving_warehouse    
        LEFT JOIN MASTER.DIM_country co ON h.fk_origin_countryid = co.pk_countryid -- to get h_origin_country    
        LEFT JOIN MASTER.DIM_country cd ON h.fk_destination_countryid = cd.pk_countryid -- to get h_destination_country
        LEFT JOIN MASTER.DIM_supplier s ON h.fk_supplierid = s.pk_supplierid -- to get h_supplier_name
        LEFT JOIN MASTER.DIM_po_type t ON h.fk_po_typeid = t.ID -- to get po type
        LEFT JOIN MASTER.DIM_po_status st ON h.fk_po_statusid = st.pk_po_statusid -- to get po status    
    WHERE st.po_status_name <> 'Cancelled' -- filter out cancelled POs 
        AND pk_po_detailid is not null
        AND season_name IN ('2023', '2024', '2025')
QUALIFY RN = 1 -- limit results to most recent upload of PO into IIT to avoid duplicates
;