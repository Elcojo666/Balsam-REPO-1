create or replace secure view PROD.ANALYTICS.CORE_VERIFIED_DISCOUNT_SECURE COPY GRANTS as
--;
WITH CTE_ID AS
(
    SELECT DISTINCT
        OH.pk_order_headerid
        ,CASE
            WHEN OH.order_date < '2023-06-13 07:00:00' THEN OH.order_date --PRE TSU
            ELSE CAST(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', OH.order_date) AS DATETIME) END AS order_date --POST TSU
        ,CASE
            WHEN OH.inserted_date < '2023-06-13 07:00:00' THEN OH.inserted_date --PRE TSU
            ELSE CAST(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', OH.inserted_date) AS DATETIME) END AS inserted_date --POST TSU
    FROM ANALYTICS.AUDIT_order_header OH  
        LEFT JOIN ANALYTICS.AUDIT_order_detail OD  ON OH.pk_order_headerid = OD.fk_order_headerid
        LEFT JOIN ANALYTICS.MIGRATED_INVALIDTESTORDERS TEST ON OH.pk_order_headerid = TEST.pk_order_headerid
        JOIN MASTER.DIM_source S  ON OH.fk_sourceid = S.pk_sourceid
    WHERE 
        OH.source_ref_num NOT LIKE 'P%' --remove UAT test orders
        AND OH.source_ref_num NOT LIKE 'W%' --remove Warranty orders
        AND (OH.Revision = 1 OR OH.Revision IS NULL) --1 for initial revision. NULL to capture Amazon orders
        AND (OD.Revision = 1 OR OD.Revision IS NULL) --1 for initial revision. NULL to capture Amazon orders
        AND TEST.pk_order_headerid IS NULL --remove Test Orders
--       AND OH.ORDER_DATE >= '2025-02-20'  --TO CHECK IF ORDER WILL RUN
),
CTE_ExchangeRate AS
(
SELECT * FROM ANALYTICS.MIGRATED_EXCHANGERATE
),
CTE_SkuProduct AS
(
SELECT * FROM ANALYTICS.MIGRATED_SKUPRODUCT
),
CTE_LineDiscount AS
(
SELECT 
    ID.pk_order_headerid
    ,OD.pk_order_detailid
    ,ODD.discount_code AS DiscountCode
    ,ODD.discount_name AS DiscountName
    ,IFNULL(ODD.coupon_code,OLC.coupon_code) AS CouponCode
    ,'Line' AS DiscountLevel
    ,SUM(ABS(ODD.discount_amount)) AS DiscountAmount
FROM CTE_ID ID
    JOIN ANALYTICS.AUDIT_order_detail OD  ON ID.pk_order_headerid = OD.fk_order_headerid
    JOIN ANALYTICS.AUDIT_order_detail_discount ODD  ON ODD.fk_order_detailid = OD.pk_order_detailid
    LEFT JOIN ANALYTICS.MAP_ORDER_LINE_COUPON_CODES OLC ON OD.pk_order_detailid = OLC.order_detailid --postTSU coupons backfill
WHERE
   (ODD.discount_code NOT IN 
    (
        'TEST', 
        'DSC-(test)',
        'DSC-CC',
        'DSC-CCC',
        'DSC-Corp'
        ,'TKTestBuyXGetY'
        )
        OR ODD.discount_code IS NULL 
        )
    AND ODD.Revision = 1
    AND OD.Revision = 1
    AND ID.order_date < '2023-06-13'
    AND ABS(ODD.discount_amount) > 0
    
GROUP BY 
    ID.pk_order_headerid
    ,OD.pk_order_detailid
    ,ODD.discount_code
    ,ODD.discount_name
    ,ODD.coupon_code
    ,OLC.coupon_code
UNION
--postTSU
SELECT 
    ID.pk_order_headerid
    ,OD.pk_order_detailid
    ,ODD.discount_name AS DiscountCode
    ,ODD.discount_code AS DiscountName
    ,IFNULL(ODD.coupon_code,OLC.coupon_code) AS CouponCode
    ,'Line' AS DiscountLevel
    ,SUM(ABS(ODD.discount_amount)) AS DiscountAmount
FROM CTE_ID ID
    JOIN ANALYTICS.AUDIT_order_detail OD  ON ID.pk_order_headerid = OD.fk_order_headerid
    JOIN ANALYTICS.AUDIT_order_detail_discount ODD  ON ODD.fk_order_detailid = OD.pk_order_detailid
    LEFT JOIN ANALYTICS.MAP_ORDER_LINE_COUPON_CODES OLC ON OD.pk_order_detailid = OLC.order_detailid --postTSU coupons backfill
WHERE
  (ODD.discount_code NOT IN 
    (
        'TEST', 
        'DSC-(test)',
        'DSC-CC',
        'DSC-CCC',
        'DSC-Corp'
        ,'TKTestBuyXGetY'
        )
        OR ODD.discount_code IS NULL 
        )
    AND ODD.Revision = 1
    AND OD.Revision = 1
    AND ID.order_date >= '2023-06-13'
    AND ABS(ODD.discount_amount) > 0
    
GROUP BY 
    ID.pk_order_headerid
    ,OD.pk_order_detailid
    ,ODD.discount_code
    ,ODD.discount_name
    ,ODD.coupon_code
    ,OLC.coupon_code
),
CTE_Warehouse AS
(
--preTSU
SELECT DISTINCT 
    TRK.fk_order_detailid as fk_order_detailid
    ,WHSE.warehouse_name AS Warehouse
    ,WHSE.pk_warehouseid 
FROM CTE_ID ID
JOIN ANALYTICS.AUDIT_order_detail OD ON ID.pk_order_headerid = OD.fk_order_headerid
JOIN ANALYTICS.TXN_TRACKING TRK  ON OD.pk_order_detailid = TRK.fk_order_detailid
JOIN ANALYTICS.MIGRATED_WAREHOUSE WHSE  ON WHSE.pk_warehouseid = TRK.fk_warehouseid -- to get warehouse names
WHERE OD.Revision = 1
UNION
--postTSU
--v1: ANALYTICS.TXN_order_container_details OCD ON OCD.order_line_key = OD.order_line_key
SELECT DISTINCT
    OD.pk_order_detailid AS fk_order_detailid
    ,W.warehouse_name AS Warehouse
    ,W.pk_warehouseid
FROM CTE_ID ID
JOIN ANALYTICS.AUDIT_order_detail OD  ON ID.pk_order_headerid = OD.fk_order_headerid
LEFT JOIN ANALYTICS.TXN_order_shipment_line OSL  ON OD.order_line_key = OSL.order_line_key
LEFT JOIN ANALYTICS.TXN_order_shipment TRK ON TRK.shipment_key = OSL.shipment_key
LEFT JOIN ANALYTICS.MIGRATED_Warehouse W ON 
        CASE 
            WHEN TRY_CAST(TRK.shipnode_key AS INT) IS NOT NULL 
            THEN CAST(TRK.shipnode_key AS INT) 
        END = CAST(W.pk_warehouseid AS INT)
),
CTE_OrderDetails AS (
SELECT DISTINCT
    ID.pk_order_headerid
    ,OD.pk_order_detailid
    ,OD.order_line_key
    ,DB.BrandCodeForPOTracker AS Brand
    ,DP.platform_name AS Platform
    ,OH.Source_Ref_Num AS OrderID
    ,ID.order_date AS OrderDate
    ,SKU.SKU_CODE AS Sku
    ,OD.Quantity AS UnitSold
    ,CASE
        WHEN ID.order_date >= '2023-06-13' AND DS.locale NOT IN ('en_WW', 'en_CA') THEN (CAST(OD.product_price * OD.quantity AS FLOAT) + CAST(EOD.tax AS FLOAT))/ OD.quantity --postTSU add Vat Tax to BHI products
        WHEN OD.product_name LIKE 'Extend%' THEN CAST(OD.product_price *0.4 AS FLOAT) --Extend Warranty
        ELSE OD.product_price END AS ProductPrice
    ,DC.currency_code AS Currency 
    ,ER.ForexRate
    ,DP.pk_platformid
    ,ID.inserted_date
FROM CTE_ID ID
    JOIN ANALYTICS.AUDIT_order_header OH  ON ID.pk_order_headerid = OH.pk_order_headerid
    JOIN ANALYTICS.AUDIT_order_detail OD  ON ID.pk_order_headerid = OD.fk_order_headerid 
    LEFT JOIN MASTER.DIM_currency DC ON OH.fk_currencyid = DC.pk_currencyid
    JOIN MASTER.DIM_source DS  ON OH.fk_sourceid = DS.pk_sourceid
    JOIN MASTER.DIM_brand DB  ON DS.fk_brandid = DB.pk_brandid
    JOIN MASTER.DIM_platform DP  ON DS.fk_platformid = DP.pk_platformid
    JOIN CTE_SkuProduct SKU ON SKU.pk_skuproductid = OD.fk_skuproductid AND SKU.pk_brandID = DB.pk_brandid
    LEFT JOIN CTE_ExchangeRate ER  ON ER.PublishDate = CAST(ID.order_date AS DATE) AND ER.Currency = DC.currency_code
    LEFT JOIN ANALYTICS.ext_order_detail EOD  ON OD.order_line_key = EOD.order_line_key
WHERE 
    (OH.Revision = 1 OR OH.Revision IS NULL)
    AND (OD.Revision = 1 OR OD.Revision IS NULL)
    AND OD.quantity > 0
)
SELECT DISTINCT
    OD.pk_order_detailid AS Channel_ID
    ,OD.Platform AS Channel_Desc
    ,OD.OrderID AS Transaction_ID
    ,OD.OrderDate AS Transaction_Date
    ,CASE WHEN OD.OrderID LIKE 'R%' THEN 'Return' ELSE 'Normal Sales' END AS Transaction_Type
    ,OD.pk_order_detailid AS Line_ID
    ,LD.CouponCode
    ,OD.SKU AS Sku_ID
    ,OD.Brand AS Brand
    ,LD.DiscountAmount AS Discount_Amount
    ,LD.DiscountCode
    ,LD.DiscountName
    ,OD.OrderDate AS Created_Timestamp
    ,OD.inserted_date AS Updated_TimeStamp
    ,OD.Currency
FROM CTE_OrderDetails OD
--LEFT JOIN CTE_ProductPricing PP ON OD.Brand = PP.Brand AND OD.Sku = PP.Sku AND YEAR(PP.price_start_date) = YEAR(OD.OrderDate) -- still need to fix the logic for accurate match
LEFT JOIN CTE_LineDiscount LD ON OD.pk_order_detailid = LD.pk_order_detailid
WHERE cast(OD.OrderDate as date) between '2022-01-01' and CURRENT_DATE - INTERVAL '1 DAY'
   -- and OD.OrderID = 'J100878866'
;
