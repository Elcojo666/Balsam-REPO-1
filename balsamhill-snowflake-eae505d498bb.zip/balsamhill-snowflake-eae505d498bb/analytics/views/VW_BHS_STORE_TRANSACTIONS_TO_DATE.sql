create or replace secure view PROD.ANALYTICS.VW_BHS_STORE_TRANSACTIONS_TO_DATE(
	_AIRBYTE_RAW_ID,
	_AIRBYTE_EXTRACTED_AT,
	_AIRBYTE_META,
	_AIRBYTE_GENERATION_ID,
	ID,
	EAN,
	QTY,
	TAX,
	DATE,
	TOTAL,
	RETAIL,
	SOURCE,
	CUSTOMER,
	DISCOUNT,
	SUBTOTAL,
	DESCRIPTION,
	"EAN(FORMULA)",
	"SUBTOTAL - DISCOUNT",
	_AB_SOURCE_FILE_URL,
	"WORK ORDER INTERNAL NOTE",
	_AB_SOURCE_FILE_LAST_MODIFIED,
	STORE_NAME
) as 
--;
WITH BASE AS (
SELECT LS."SaleID" as ID
    , TRY_CAST(LS."TimeStamp" AS DATE) AS DATE
    , LI."Ean" AS EAN 
    , LI."CustomSku" AS "EAN(FORMULA)"
    , LI."Description" AS Description
    , LSL."UnitQuantity" AS Qty 
    , LSL."UnitPrice" AS Retail
    , LSL."CalcSubtotal" as Subtotal
    , LSL."CalcLineDiscount" as Discount
    , LSL."CalcSubtotal" - LSL."CalcLineDiscount" AS "SUBTOTAL - DISCOUNT"
    , LSL."Tax1Rate" as TAX 
    , LSL."CalcTotal" as TOTAL 
    , LC."FirstName" || ' ' || LC."LastName" as Customer
    , LS."ReferenceNumberSource" as SOURCE 
    , NULL AS "Work Order Internal Note"
    , S."Name" AS STORE_NAME
FROM PROD.RAW.LIGHTSPEED_SALE LS 
    LEFT JOIN PROD.RAW.LIGHTSPEED_SALELINE LSL 
        ON LS."SaleID" = LSL."SaleID"
    LEFT JOIN PROD.RAW.LIGHTSPEED_ITEM LI 
        ON LSL."ItemID" = LI."ItemID"
    LEFT JOIN PROD.RAW.LIGHTSPEED_CUSTOMER LC 
        ON LS."CustomerID" = LC."CustomerID"
    LEFT JOIN PROD.RAW.LIGHTSPEED_SHOP S 
        ON LS."ShopID" = S."ShopID"
)
SELECT NULL AS _AIRBYTE_RAW_ID
    , NULL AS _AIRBYTE_EXTRACTED_AT
    , NULL AS _AIRBYTE_META
    , NULL AS _AIRBYTE_GENERATION_ID
    , ID 
    , EAN 
    , QTY 
    , TAX
    , CAST(DATE AS DATETIME) AS DATE
    , TOTAL 
    , RETAIL 
    , SOURCE 
    , CUSTOMER 
    , DISCOUNT 
    , SUBTOTAL 
    , DESCRIPTION 
    , "EAN(FORMULA)"
    , "SUBTOTAL - DISCOUNT"
    , NULL AS _AB_SOURCE_FILE_URL
    , NULL AS "WORK ORDER INTERNAL NOTE"
    , NULL AS _AB_SOURCE_FILE_LAST_MODIFIED
    , STORE_NAME 
FROM BASE B 
;