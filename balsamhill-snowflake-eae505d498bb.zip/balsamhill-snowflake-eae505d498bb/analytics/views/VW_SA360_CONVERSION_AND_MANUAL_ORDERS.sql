CREATE OR REPLACE VIEW PRE_PROD.ANALYTICS.VW_SA360_CONVERSION_AND_MANUAL_ORDERS AS 
WITH Temp_SA360_OrderID AS (
    SELECT DISTINCT
    c.campaign_id,
    cv.customer_id,
    c.campaign_name,
    cv.segments_date,
    cv.segments_device,
    cv.customer_account_type,
    a.customer_descriptive_name,
    cv.conversion_floodlight_order_id,
    cv.segments_conversion_action_name,
    cv.conversion_floodlight_original_revenue,    
    FROM PRE_PROD.GA4_REPORTING.VW_P_SA_CAMPAIGN c
        JOIN PRE_PROD.GA4_REPORTING.VW_P_SA_CONVERSION cv ON c.campaign_id = cv.campaign_id
        JOIN PRE_PROD.GA4_REPORTING.VW_P_SA_ACCOUNT a ON cv.customer_id = a.customer_id
    WHERE
    cv.segments_conversion_action_name = '2205 | Balsam Hill - Confirmation/Thank You Page'
    OR cv.segments_conversion_action_name = '2205 | Balsam Hill UK - Confirmation/Thank You Page floodlight'
    OR cv.segments_conversion_action_name = '2205 | Balsam Hill AU - Confirmation/Thank You Page'
    OR cv.segments_conversion_action_name = '2205 | Balsam Hill DE - Confirmation/Thank You Page'
    OR cv.segments_conversion_action_name = '2205 | Balsam Hill FR - Confirmation/Thank You Page'
    OR cv.segments_conversion_action_name = '2205 | Balsam Hill CA - Confirmation/Thank You Page'
    )
SELECT * FROM Temp_SA360_OrderID
UNION ALL
SELECT campaign_id,
    customer_id,
    campaign_name,
    segments_date,
    segments_device,
    customer_account_type,
    customer_descriptive_name,
    conversion_floodlight_order_id,
    segments_conversion_action_name,
    conversion_floodlight_original_revenue, 
FROM PRE_PROD.GA4_REPORTING.VW_SA360_MANUALORDERID
;