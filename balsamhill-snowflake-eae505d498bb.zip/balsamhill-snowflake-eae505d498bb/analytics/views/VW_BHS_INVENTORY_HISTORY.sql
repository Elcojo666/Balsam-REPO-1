create or replace secure view PROD.ANALYTICS.VW_BHS_INVENTORY_HISTORY(
	"#",
	"DATE/TIME",
	EAN,
	EMPLOYEE,
	REASON,
	"EAN (FORMULA)",
	ITEM,
	"SYSTEM ID",
	"CHANGE IN QTY",
	"CHANGE IN COST",
	LOCATION,
	"Source",
	"Customer"
) as 
SELECT IL."InventoryLogID" as "#"
    , IL."CreateTime" as "DATE/TIME"
    , LI."Ean" as EAN
    , IL."EmployeeID" as EMPLOYEE 
    , il."Reason" AS REASON 
    , LI."CustomSku" as "EAN (FORMULA)"
    , LI."Description" as ITEM
    , LI."SystemSku" as "SYSTEM ID"
    , IL."QohChange" as "CHANGE IN QTY"
    , IL."CostChange" as "CHANGE IN COST"
    , LS."Name" as LOCATION
    , CASE 
        WHEN "TransferID" <> 0 THEN 'Transfer' || ' # ' || "TransferID"
        WHEN "SaleID" <> 0 THEN 'Sale' || ' # ' || "SaleID"
        WHEN "InventoryCountID" <> 0 THEN 'Import' || ' # ' || "InventoryCountID"
    END AS "Source" 
    , NULL as "Customer"
FROM PROD.RAW.LIGHTSPEED_INVENTORYLOG IL 
    LEFT JOIN PROD.RAW.LIGHTSPEED_ITEM LI 
        ON IL."ItemID" = LI."ItemID"
    LEFT JOIN PROD.RAW.LIGHTSPEED_SHOP LS 
        ON IL."ShopID" = LS."ShopID"
;