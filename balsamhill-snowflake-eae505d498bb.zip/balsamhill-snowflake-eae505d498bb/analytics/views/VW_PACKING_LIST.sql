CREATE OR REPLACE SECURE VIEW ANALYTICS.VW_PACKING_LIST AS 
WITH ValidPackingLists AS (
    SELECT ID, InvoiceDate, DateLoaded, modifiedon
        FROM (
                SELECT *, ROW_NUMBER () OVER(PARTITION BY File ORDER BY ID DESC) AS RN
                FROM ANALYTICS.InventoryPackingListSummary
                WHERE DeletedDate IS NULL                
            ) sq  
        WHERE RN = 1 -- subquery to ensure that only the latest uploaded version of a PL will be pulled to avoid duplicates
)

SELECT DISTINCT -- necessary to remove duplicates caused by different UPCs per SKU
    REPLACE(REPLACE(pl.BillOfLading,'-',''),'.','') AS bill_of_lading -- removes extraneous characters from BillOfLading
    , pl.ContainerNumber AS container_number -- a shipment will have multiple containers that may or may not go to the same warehouse
    , pls.InvoiceDate AS invoice_date
    , pl.InvoiceID AS po_number         
    , w.warehouse_name AS receiving_warehouse
    , pl.StoreSku AS sku
    , pl.Qty AS quantity_shipped
    , pl.DepartureDate AS date_shipped
    , pls.DateLoaded AS created_timestamp
    , pls.modifiedon AS updated_timestamp
    , pl.InventoryPackingListSummaryID
FROM ANALYTICS.InventoryPackingList pl 
    JOIN ValidPackingLists pls ON pl.InventoryPackingListSummaryID = pls.ID
    JOIN MASTER.dim_warehouse w ON pl.WarehouseID = w.pk_warehouseid  -- to get receiving_warehouse
;
