USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_OrderHeader AS (

    SELECT 
    initial.order_header_key,
    initial.customer_id,
    initial.scid,
    initial.brand,
    initial.channel,
    initial.order_source,
    initial.order_id,
    initial.order_date_pt,
    initial.order_date_local,
    initial.gross_revenue_initial,
    initial.net_revenue_initial,
    initial.total_payment_received_initial,
    initial.total_tax_initial,
    initial.total_shipping_payment_initial,
    initial.total_discounts_initial,
    initial.total_product_price_initial,
    initial.total_ordered_quantity_initial,
    initial.total_sku_count_initial,
    latest.total_payment_received_latest,
    latest.gross_revenue_latest,
    latest.net_revenue_latest,
    latest.total_shipping_payment_latest,
    latest.total_tax_latest,
    latest.total_discounts_latest, 
    latest.total_product_price_latest,
    latest.total_ordered_quantity_latest,
    latest.total_sku_count_latest,
    latest.total_refund_header,
    latest.total_refund_principal,
    latest.total_refund_shipping,
    latest.total_refund_tax,
    initial.payment_method,
    initial.currency,
    initial.currency_conversion_rate,
    initial.current_order_status,
    initial.fulfillment_status,
    initial.financial_status,
    initial.extend_warranty,
    initial.returned,
    initial.discounted,
    initial.gift_flag,
    initial.warranted,
    initial.is_campaign,
    CASE WHEN initial.total_payment_received_initial != latest.total_payment_received_latest THEN 'Y' ELSE 'N' END AS post_order_adjustment
FROM analytics.core_orderheader_initial initial
LEFT JOIN analytics.core_orderheader_latest latest 
    ON initial.order_header_key = latest.order_header_key

);