USE DATABASE PROD;
CREATE OR REPLACE VIEW analytics.core_GladlyConversations AS (

WITH Conversations AS (
    SELECT
        c.conversation_id
        , c.content_type
        , CASE
            WHEN c.content_type = 'CONVERSATION_NOTE' 
                THEN CONCAT (c.content_type, ': ', c.content_body) -- content_body contains the notes entered for conversation_note content type
            WHEN c.content_type = 'TOPIC_CHANGE' 
                THEN CONCAT (c.content_type, ': ', t.name) -- name of actual topics are stored in a table called txn_gladly_topics
            WHEN c.content_type = 'CONVERSATION_STATUS_CHANGE' 
                THEN CONCAT (c.content_type, ': ', c.content_status) -- content_status contains the status for each status change content; either OPEN, CLOSED, or NULL
            ELSE CONCAT (c.initiator_type, ': ', c.content_content) -- content_content contains the actual messages sent by the initiator (i.e, the customer, agent, bot, system)
            END AS conversation_element
        , timestamp AS conversation_started_UTC -- timestamp of event 
        , ROW_NUMBER() OVER(PARTITION BY conversation_id ORDER BY timestamp) AS RN -- assigns a row number to each element of a conversation with RN=1 being the first, i.e. the element that initiated the conversation
    FROM analytics.txn_gladly_conversation c
        LEFT JOIN analytics.txn_gladly_topics t ON c.content_added_topic_ids = t.id        
),

Conversation_start AS (
    SELECT 
        conversation_id
        , content_type AS conversation_started_from
        , conversation_started_UTC
    FROM Conversations
    WHERE RN = 1    
), -- this CTE takes the first content_type and its timestamp for each conversation; this allows us to see how the conversation started (sms, email, phone call, etc.) and when it started

Conversation_lines AS (
    SELECT 
        conversation_id 
        , LISTAGG (conversation_element, '\n') WITHIN GROUP (ORDER BY RN) AS conversation
    FROM Conversations
    GROUP BY conversation_id
) -- this CTE takes all elements of a conversation and aggregates them into a single cell/string

SELECT
    xCS.conversation_id 
    , xCS.conversation_started_UTC
    , xCS.conversation_started_from 
    , xCL.conversation
FROM Conversation_start xCS
    JOIN Conversation_lines xCL on xCS.conversation_id = xCL.conversation_id
-- WHERE xCL.conversation LIKE '%Sidekick%' -- limits the results to conversations that triggered the Sidekick bot
);