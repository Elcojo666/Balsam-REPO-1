use database prod;


CREATE  TABLE if not exists  analytics.exchange_rate (
    ID INT,
    GBP_to_USD DECIMAL(19, 6),
    EUR_to_USD DECIMAL(19, 6),
    EUR_to_GBP DECIMAL(19, 6),
    AUD_to_USD DECIMAL(19, 6),
    PublishDate TIMESTAMP_NTZ,
    DateEntered TIMESTAMP_NTZ,
    DateModified TIMESTAMP_NTZ
);



CREATE  VIEW if not exists analytics.TestOrders AS

SELECT * FROM (

-- By TEST Sku
    SELECT DISTINCT
        AOH.pk_order_headerid,
        AOD.pk_order_detailid
    FROM analytics.audit_order_header AOH 
    JOIN analytics.audit_order_detail AOD 
        ON AOH.pk_order_headerid = AOD.fk_order_headerid
    JOIN analytics.sku_product_locale SKU 
        ON AOD.fk_skuproductid = SKU.pk_skuproductid
    WHERE
        SKU.Sku_code  LIKE '%z%' 
        OR SKU.Sku_code LIKE '%Test%'
        
UNION 

-- By email address
    SELECT DISTINCT
        AOH.pk_order_headerid,
        AOD.pk_order_detailid
    FROM analytics.audit_order_header AOH
    JOIN analytics.audit_order_detail AOD 
        ON AOH.pk_order_headerid = AOD.fk_order_headerid
    WHERE AOH.email_address IN (
        'asanjuan@balsambrands.com',
        'QA@balsambrands.com',
        'qidwai.suhaib@gmail.com',
        'bbqa.kara@gmail.com',
        'hayleydeane@live.co.uk',
        'ludovic.hittinger@gmail.com',
        'rebecca@web.de',
        'bourlandnick@gmail.com',
        'amelie.ladevez@gmail.com',
        'info@textwelet.com',
        'kpenalba@balsambrands.com',
        'mandy.dimiero@gmail.com',
        'rebecca.mckay@live.com.au',
        'rebeccaleese@web.de',
        'D3M0LQ54MK51X8X@marketplace.amazon.com',
        'dropship@nordstorm.com',
        'kbratt@balsambrands.com',
        'housermati@gmail.com',
        'ldienes@stanfordalumni.org',
        'desg44@gmail.com',
        'dtj234@live.co.uk',
        'peter.kuras@nagarro.com',
        'faraud.becker@gmail.com',
        'm.kostka87@web.de',
        'a.kasapoglu@incupot.com',
        'test+declined@signifyd.com',
        't.h.e.a.j.celestin.o@gmail.com',
        'agbristol@wsgc.com',
        'axel.jach@argosmultilingual.com',
        'lganzagan@balsambrands.com',
        'lyssatest16@gmail.com',
        'rperez@balsambrands.com'
    )

) T

GROUP BY
    pk_order_headerid,
    pk_order_detailid;




CREATE  VIEW if not exists analytics.core_OrderHeader_min AS


WITH CTE_ID AS
(
SELECT 
    pk_order_headerid
    ,SUM(TotalPaymentReceived) AS TotalPaymentReceived
    ,order_date
FROM (
    SELECT DISTINCT
        AOH.pk_order_headerid
        ,CASE
            WHEN AOH.fk_sourceid IN (11,13,14,15,16) THEN AOH.net_amount --Hybris
            WHEN AOH.fk_sourceid IN (26,34,36,35,27) AND AOH.source_ref_num NOT LIKE 'Y%' THEN AOH.net_amount --Amazon orders pre TSU
            ELSE AOD.product_price * AOD.quantity --Amazon and Retails post TSU
            END AS TotalPaymentReceived 
        ,CASE
            WHEN AOH.order_date < '2023-06-13 07:00:00' THEN AOH.order_date     --PRE TSU
            ELSE CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', AOH.order_date)
            END AS order_date --POST TSU
    FROM analytics.audit_order_header AOH  
        LEFT JOIN analytics.audit_order_detail AOD  ON AOH.pk_order_headerid = AOD.fk_order_headerid
        LEFT JOIN analytics.txn_order_status TOS  ON AOH.pk_order_headerid = TOS.fk_order_headerid
        LEFT JOIN analytics.TestOrders TEST ON AOH.pk_order_headerid = TEST.pk_order_headerid
    WHERE 
        AOH.fk_sourceid IN (
            11  --BHUS Hybris        
            ,26 --BHUS Amazon            
            ,13 --BHUK Hybris     
            ,34 --BHUK Amazon
            ,14 --BHFR Hybris     
            ,7  --BHFR Volusion   
            ,35 --BHFR Amazon 
            ,15 --BHDE Hybris     
            ,8  --BHDE Volusion
            ,36 --BHDE Amazon
            ,16 --BHAU Hybris     
            ,10 --BHAU Volusion  
            ,2  --Treetopia Volusion     
            ,27 --Treetopia Amazon
            ,38 --NordstromDSCO
            ,41 --WilliamSonomaEDI
            ,43 --PotteryBarnEDI
            ,50 --NordstromRackDSCO              
        )
        AND AOH.source_ref_num NOT LIKE 'R%' --Returns
        AND AOH.source_ref_num NOT LIKE 'W%' --Warranty
        AND AOH.source_ref_num NOT LIKE 'P%' --UAT Test orders
        AND (AOH.Revision = 1 OR AOH.Revision IS NULL) --1 for initial revision. NULL to capture Amazon orders
        AND (AOD.Revision = 1 OR AOD.Revision IS NULL) --1 for initial revision. NULL to capture Amazon orders
        AND (TOS.fk_order_statusid NOT IN ( --invalid Order Status
                2   -- PAYMENT_CAPTURED
                ,3  -- CANCELLED
                ,13 -- CANCELED
                ,20 -- ERROR
                ,21 -- DONOTPROCESS
                ,27 -- CANCELLING
                ,28 -- CANCELLLING
                ,29 -- PAYMENT_NOT_CAPTURED
                ,30 -- PAYMENT_AUTHORIZED
                ,31 -- REMORSE
                ,32 -- Deleted
                ,33 -- CHECKED_INVALID
        )
        OR TOS.fk_order_statusid IS NULL) --NULL to capture Amazon orders
        AND TEST.pk_order_headerid IS NULL --remove Test Orders
) T
WHERE TotalPaymentReceived > 0 --remove $0 orders, can only apply here since TotalPaymentReceived vary Post TSU and per Platform
GROUP BY
    pk_order_headerid
    ,order_date
),

CTE_OrderTax AS
(
    SELECT 
        ID.pk_order_headerid
        ,SUM(tax_amount) AS OrderTax
    FROM CTE_ID ID
        JOIN analytics.audit_order_tax TAX  ON TAX.fk_order_headerid = ID.pk_order_headerid
    WHERE
        TAX.revision = 1
        AND TAX.tax_amount > 0
    GROUP BY pk_order_headerid
),

CTE_DetailTax AS
(
    SELECT 
        ID.pk_order_headerid
        ,SUM(tax_amount) AS LineTax
    FROM CTE_ID ID
        JOIN analytics.audit_order_detail AOD  ON ID.pk_order_headerid = AOD.fk_order_headerid
        JOIN analytics.audit_order_detail_tax TAX  ON TAX.fk_order_detailid = AOD.pk_order_detailid
    WHERE
        AOD.revision = 1
        AND TAX.revision = 1
        AND TAX.tax_amount > 0 
    GROUP BY pk_order_headerid
),

CTE_Tax AS
(
SELECT
    ID.pk_order_headerid
    ,(COALESCE(O.OrderTax,0) + COALESCE(D.LineTax,0)) TotalTax
FROM CTE_ID AS ID
LEFT JOIN CTE_OrderTax AS O ON O.pk_order_headerid = ID.pk_order_headerid
LEFT JOIN CTE_DetailTax AS D ON D.pk_order_headerid = ID.pk_order_headerid
), 

CTE_ExtendedWarranty AS
(
    SELECT
        ID.pk_order_headerid
        ,SUM(AOD.product_price * AOD.quantity * 0.6) AS ExtendWarranty
    FROM CTE_ID AS ID
        JOIN analytics.audit_order_detail AOD  ON ID.pk_order_headerid = AOD.fk_order_headerid 
    WHERE
        AOD.Revision = 1
        AND AOD.product_name LIKE 'Extend%'
    GROUP BY ID.pk_order_headerid
),

CTE_PaymentMethod AS
(
    SELECT
        ID.pk_order_headerid
        ,MAX(CASE WHEN DPM.payment_method_name IS NOT NULL THEN DPM.payment_method_name ELSE PT.payment_type_name END) AS payment_method_name
    FROM CTE_ID AS ID
        JOIN analytics.txn_payment TP  ON ID.pk_order_headerid = TP.fk_order_headerid
        LEFT JOIN master.dim_payment_method DPM  ON DPM.pk_payment_method_id = TP.fk_payment_methodid
        LEFT JOIN master.dim_payment_type PT on TP.fk_payment_typeid = PT.pk_payment_typeid
    WHERE TP.seq_no = 1
    GROUP BY ID.pk_order_headerid
),

CTE_Shipping AS
(
    SELECT 
        ID.pk_order_headerid
        ,SUM(AOF.fee_amount) AS ShippingCost 
    FROM CTE_ID ID
        JOIN analytics.audit_order_fee AOF  ON AOF.fk_order_headerid = ID.pk_order_headerid
    WHERE
       AOF.Revision = 1
       AND AOF.fee_type = 'Order Shipping' 
    GROUP BY ID.pk_order_headerid
) 


SELECT DISTINCT
    ID.pk_order_headerid,
    DB.BrandCodeForPOTracker AS Brand,
    DP.platform_name AS Platform,
    AOH.Source_Ref_Num AS OrderID,
    ID.order_date AS OrderDate,
    ID.TotalPaymentReceived - COALESCE(EW.ExtendWarranty, 0) AS TotalPaymentReceived, -- Less 60% for ExtendWarranty
    COALESCE(AOH.shpping_fee_amount, SH.ShippingCost, 0) AS TotalShippingCost,
    COALESCE(Tax.TotalTax, 0) AS TotalTax,
    PM.payment_method_name AS PaymentMethodID,
    DC.currency_code AS Currency,
    DOS.order_status_name AS OrderStatus,
    CASE
        WHEN DP.platform_name = 'Amazon' THEN 'Amazon'
        WHEN AOH.salesrep_customerID IS NOT NULL OR AOH.entered_by IS NOT NULL THEN 'Phone'
        ELSE '' 
    END AS OrderSource,
    CASE
        WHEN DC.currency_code = 'GBP' THEN ER.GBP_to_USD
        WHEN DC.currency_code = 'EUR' THEN ER.EUR_to_USD
        WHEN DC.currency_code = 'AUD' THEN ER.AUD_to_USD
        ELSE 1 
    END AS ForexRate
FROM CTE_ID ID
INNER JOIN analytics.audit_order_header AOH ON ID.pk_order_headerid = AOH.pk_order_headerid
LEFT JOIN CTE_Tax Tax ON ID.pk_order_headerid = Tax.pk_order_headerid
LEFT JOIN analytics.txn_order_status TOS ON AOH.Source_Ref_Num = TOS.Source_Ref_Num AND AOH.fk_sourceid = TOS.fk_sourceid
INNER JOIN master.dim_order_status DOS ON TOS.fk_order_statusid = DOS.pk_order_statusid
LEFT JOIN master.dim_currency DC ON AOH.fk_currencyid = DC.pk_currencyid
LEFT JOIN analytics.exchange_rate ER ON CAST(ER.PublishDate AS DATE) = CAST(ID.order_date AS DATE)
LEFT JOIN CTE_ExtendedWarranty EW ON ID.pk_order_headerid = EW.pk_order_headerid
LEFT JOIN CTE_PaymentMethod PM ON ID.pk_order_headerid = PM.pk_order_headerid
LEFT JOIN CTE_Shipping SH ON ID.pk_order_headerid = SH.pk_order_headerid
JOIN master.dim_source DS ON AOH.fk_sourceid = DS.pk_sourceid
JOIN master.dim_brand DB ON DS.fk_brandid = DB.pk_brandid
JOIN master.dim_platform DP ON DS.fk_platformid = DP.pk_platformid
WHERE AOH.Revision = 1 OR AOH.Revision IS NULL;