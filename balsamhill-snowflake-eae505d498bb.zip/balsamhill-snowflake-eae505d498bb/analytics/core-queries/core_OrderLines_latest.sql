create or replace view ANALYTICS.core_OrderLines_latest
as
(
with 
cte_id as 
(
    select *
    from analytics.core_orderids_initial
),

cte_returns AS (
    select distinct
        rsf.original_order_line_key,
        sum(coalesce(rsf.return_quantity, r.return_quantity)) as total_return_quantity,
        sum(coalesce(r.refund_principal, rsf.return_cost)) as total_refund_line,
        sum(r.refund_tax) AS total_refund_tax_line
    from analytics.core_returns_sf rsf
    left join balsam_sc_data.direct_access.sc_return_items r on rsf.return_order_id = r.order_id and rsf.sku = r.sku
    group by rsf.original_order_line_key
),

cte_line as
(
select distinct
    id.order_header_key,
    i.source_line_item_id as order_line_key,
    i.sku,
    i.title as order_product_name,
    i.quantity as ordered_quantity_initial,
    (CASE
        WHEN i.scope NOT IN ('bhus', 'bhca', 'tcus', 'ttus') THEN CAST((((i.price * i.quantity) + coalesce(tax.line_tax_initial,0)) / i.quantity) AS FLOAT)
        WHEN i.title LIKE 'Extend Protect%' THEN i.price * 0.4
        ELSE i.price
        END) AS product_price,
    coalesce(i.tax,0) as line_tax_latest,
    coalesce(i.item_discount,0) as line_discounts_latest,
    CASE WHEN i.title LIKE 'Extend Protect%' THEN 'YES' ELSE 'NO' END AS extend_warranty
from cte_id id
join balsam_sc_data.direct_access.sc_org_items i on id.order_header_key = i.source_order_id
left join analytics.core_linetax_initial tax on i.source_line_item_id = tax.order_line_key
WHERE 
    i.quantity > 0
    AND i.price > 0
    AND i.item_canceled = FALSE 
),

CTE_OLD AS
(
select distinct
    line.order_line_key,
    line.ordered_quantity_initial - coalesce(r.total_return_quantity,0) as ordered_quantity_latest,
    line.product_price,
    line.line_tax_latest - coalesce(r.total_refund_tax_line,0) AS line_tax_latest,
    line.line_discounts_latest,    
    ordered_quantity_latest * line.product_price as total_product_price_latest,
    greatest((ordered_quantity_latest * line.product_price) - line.line_tax_latest - coalesce(r.total_refund_line,0),0) as product_revenue_latest,
    greatest(product_revenue_latest - coalesce(line.line_discounts_latest,0),0) AS discounted_product_revenue_latest,
from cte_id id
join cte_line line on id.order_header_key = line.order_header_key
left join cte_returns r on line.order_line_key = r.original_order_line_key    
)

select distinct
    id.order_header_key,
    line.order_line_key,
    o.scid,
    o.cuid as customer_id,
    UPPER(CONCAT(id.brand , line.sku)) AS brand_sku,
    id.brand,
    id.channel,
    id.order_source,
    id.order_id,
    id.order_date_pt,
    id.order_date_local,
    line.sku,
    line.order_product_name,
    line.ordered_quantity_initial - coalesce(r.total_return_quantity,0) as ordered_quantity_latest,
    line.product_price,
    line.line_tax_latest - coalesce(r.total_refund_tax_line,0) AS line_tax_latest,
    line.line_discounts_latest,    
    ordered_quantity_latest * line.product_price as total_product_price_latest,
    greatest((case when id.brand not in ('BHUS', 'BHUS', 'TCUS', 'TTUS')
        then total_product_price_latest - line.line_tax_latest 
        else total_product_price_latest
        end)
        - coalesce(r.total_refund_line,0),0)
        as product_revenue_latest,
    greatest(product_revenue_latest - coalesce(line.line_discounts_latest,0),0) AS discounted_product_revenue_latest,
    coalesce(r.total_return_quantity, 0) as return_quantity,
    coalesce(r.total_refund_line, 0) as refund_line,
    coalesce(r.total_refund_tax_line, 0) as refund_tax,
    refund_line + refund_tax as total_refund_line,
    o.payment_method as payment_method,
    o.currency as currency,
    o.currency_conversion_rate as currency_conversion_rate,
    upper(coalesce(o.properties:"OrderStatus"::text, o.fulfillment_status)) as current_order_status,
    case when current_order_status like '%RETURN%' then 'YES' else 'NO' end as returned,
    line.extend_warranty,
    case when line_discounts_latest is not null then 'YES' else 'NO' end as discounted
from cte_id id
join cte_line line on id.order_header_key = line.order_header_key
join balsam_sc_data.direct_access.sc_org_orders o on id.order_header_key = o.source_order_id
left join cte_returns r on line.order_line_key = r.original_order_line_key
);