USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_ReshippedOrders AS
(
with cte_nonreship as
(
select DISTINCT
source_order_id
,sku
,max(price) price
from balsam_sc_data.direct_access.sc_items
where linetype IS NULL --to check how about warrant
GROUP BY ALL
)

SELECT DISTINCT
    i.source_order_id AS order_header_key,
    i.source_line_item_id AS order_line_key,
    UPPER(CONCAT(i.scope , i.sku)) AS brand_sku,
    o.cuid AS customer_id,
    o.scid AS scid,
    UPPER(i.scope) AS brand,
    CASE
        WHEN o.order_type ILIKE 'ASM' THEN 'HYBRIS' 
        WHEN o.channel ILIKE '%AMAZON' THEN 'AMAZON'
        WHEN o.channel ILIKE '%VOLUSION%' THEN 'VOLUSION'
        ELSE o.order_type 
    END AS channel,
    CASE 
        WHEN o.order_type ILIKE 'ASM' THEN 'Phone' 
        ELSE o.properties:"EntryType"::TEXT 
    END AS order_source,
    o.order_id AS order_id,
    o.order_date AS order_date_pt,
    CASE
        WHEN o.scope = 'bhuk' THEN CONVERT_TIMEZONE('UTC', 'Europe/London', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'bhde' THEN CONVERT_TIMEZONE('UTC', 'Europe/Berlin', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'bhfr' THEN CONVERT_TIMEZONE('UTC', 'Europe/Paris', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'bhau' THEN CONVERT_TIMEZONE('UTC', 'Australia/Sydney', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'bhus' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'bhca' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'ttus' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'tcus' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', o.order_timestamp::TIMESTAMP_NTZ)
        ELSE o.order_timestamp 
    END AS order_date_local,
    i.sku,
    i.title AS order_product_name,
    i.quantity AS reshipped_quantity,
    n.price AS reshipped_original_product_price,
    i.quantity * n.price AS reshipped_original_total_product_price,
    o.currency,
    o.currency_conversion_rate,
    o.fulfillment_status,
    o.financial_status
FROM balsam_sc_data.direct_access.sc_items i
JOIN balsam_sc_data.direct_access.sc_orders o ON i.source_order_id = o.source_order_id
left JOIN CTE_NONRESHIP n ON i.source_order_id = n.source_order_id and i.sku = n.sku
WHERE i.linetype = 'Reship'
and order_date_pt >= '2022-02-01'
and i.quantity > 0

);