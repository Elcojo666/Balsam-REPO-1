USE DATABASE prod;
CREATE OR REPLACE VIEW analytics.core_ContainerTracking AS (
    SELECT BillOfLading AS bill_of_lading
        , ContainerNumber AS container_number
        , CalculatedETAtoInStock AS calcualted_eta_to_instock
        , GateInFull_ActualDate -- The actual date when the container was received at the Origin Port from Vendor
        , DepartureFromStop_ActualDate -- The actual date when the container left the last stop (could be the origin port or one of the intermittent stops
        , Discharge_ActualDate -- The actual date when the container was off-loaded at the destination port
        , GateOutFull_ActualDate -- The actual date when the container went out of the Destination Port heading to the Destination Warehouse        
    FROM analytics.container_tracking
    WHERE BillOfLading IS NOT NULL 
        AND ContainerNumber IS NOT NULL
    QUALIFY ROW_NUMBER() OVER (PARTITION BY BillOfLading, ContainerNumber ORDER BY ID DESC) = 1 -- gets only the latest entry for a BillOfLading-ContainerNumber
);