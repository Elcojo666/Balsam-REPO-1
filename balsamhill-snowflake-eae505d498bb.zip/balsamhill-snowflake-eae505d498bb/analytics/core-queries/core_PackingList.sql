USE DATABASE prod;

CREATE OR REPLACE VIEW analytics.core_PackingList AS (

--CTE to limit results to the latest uploaded version of a PL that has not been deleted (DeletedDate is NULL) 
WITH ValidPLs AS (
    SELECT ID
    FROM analytics.InventoryPackingListSummary
    WHERE DeletedDate IS NULL
    QUALIFY ROW_NUMBER () OVER(PARTITION BY [File] ORDER BY ID DESC) = 1
)

SELECT
    CASE WHEN InvoiceID LIKE '% %' THEN LEFT(InvoiceID, charindex(' ', InvoiceID) - 1) ELSE InvoiceID END AS invoice_id -- limits the InvoiceID field to the first PO listed
    , StoreSku AS sku
    , ProductDescription AS product_description
    , Upc AS upc
    , Qty AS upc_quantity
    , Vendor AS vendor
    , UnitCost AS sku_unit_cost
    , REPLACE(REPLACE(BillOfLading,'-',''),'.','') AS bill_of_lading -- removes extraneous characters from BillOfLading
    , ContainerNumber AS container_number
    , DepartureDate AS departure_date
    , DestinationPort AS destination_port
    , CartonNumber AS carton_number    
    , InventoryPackingListSummaryID AS packing_list_summary_id
    , W.warehouse_name AS receiving_warehouse
FROM analytics.InventoryPackingList pl
    LEFT JOIN master.dim_warehouse w ON pl.WarehouseID = w.pk_warehouseid  -- to get ipl_receiving_warehouse
    JOIN ValidPLs pls ON pls.ID = pl.InventoryPackingListSummaryID
WHERE UPPER(CartonNumber) NOT LIKE '%MASTER%' -- to avoid overcounting
    AND DepartureDate > '2020-02-01'
);