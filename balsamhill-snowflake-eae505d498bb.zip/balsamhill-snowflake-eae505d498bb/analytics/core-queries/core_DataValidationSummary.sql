USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_DataValidationSummary AS (

WITH 
-- Common subquery for duplicate order headers
duplicate_order_headers AS (
    SELECT order_header_key
    FROM analytics.core_orderheader
    GROUP BY order_header_key
    HAVING COUNT(*) > 1
),

-- Common subquery for missing order header dates
missing_orderheader_dates AS (
SELECT expected_date
    FROM (
        SELECT DATEADD(DAY, -seq4(), CONVERT_TIMEZONE('America/Los_Angeles', CURRENT_TIMESTAMP))::DATE AS expected_date
        FROM TABLE(GENERATOR(ROWCOUNT => 365))
    ) expected_dates
    LEFT JOIN (
        SELECT DISTINCT CAST(order_date_pt AS DATE) AS actual_date
        FROM analytics.core_orderheader
    ) actual_dates
    ON expected_dates.expected_date = actual_dates.actual_date
    WHERE actual_dates.actual_date IS NULL
),

-- Common freshness timestamp for order header
order_header_freshness AS (
SELECT 
    DATEDIFF(
        'hour',
        MAX(order_timestamp::TIMESTAMP), -- no conversion
        CONVERT_TIMEZONE('America/Los_Angeles', CURRENT_TIMESTAMP())
    ) AS hours_old
FROM balsam_sc_data.direct_access.sc_orders
),

-- Common subquery for duplicate order lines
duplicate_order_lines AS (
    SELECT order_line_key
    FROM analytics.core_orderlines
    GROUP BY order_line_key
    HAVING COUNT(*) > 1
),

-- Common subquery for missing order line dates
missing_orderline_dates AS (
    SELECT expected_date
    FROM (
        SELECT DATEADD(DAY, -seq4(), CONVERT_TIMEZONE('America/Los_Angeles', CURRENT_TIMESTAMP))::DATE AS expected_date
        FROM TABLE(GENERATOR(ROWCOUNT => 365))
    ) expected_dates
    LEFT JOIN (
        SELECT DISTINCT CAST(order_date_pt AS DATE) AS actual_date
        FROM analytics.core_orderlines
    ) actual_dates
    ON expected_dates.expected_date = actual_dates.actual_date
    WHERE actual_dates.actual_date IS NULL
),

-- Missing inventory data
missing_oms_historical_dates AS (
    SELECT expected_date
    FROM (
        SELECT DATEADD(DAY, -seq4(), CONVERT_TIMEZONE('America/Los_Angeles', CURRENT_TIMESTAMP))::DATE AS expected_date
        FROM TABLE(GENERATOR(ROWCOUNT => 365))
    ) expected_dates
    LEFT JOIN (
        SELECT DISTINCT CAST(inventory_date_pt AS DATE) AS actual_date
        FROM analytics.core_omsinventory_historical_pacific
    ) actual_dates
    ON expected_dates.expected_date = actual_dates.actual_date
    WHERE actual_dates.actual_date IS NULL    
),

-- Common subquery for duplicate order discounts
duplicate_orderdiscounts AS (
    SELECT CONCAT(ORDER_ID, DISCOUNT_CODE)
    FROM analytics.core_orderdiscounts
    GROUP BY CONCAT(ORDER_ID, DISCOUNT_CODE)
    HAVING COUNT(*) > 1
),

-- Common subquery for duplicate order line discounts
duplicate_orderlinediscounts AS (
    SELECT CONCAT(ORDER_ID, SKU, DISCOUNT_CODE)
    FROM analytics.core_linediscounts
    GROUP BY CONCAT(ORDER_ID, SKU, DISCOUNT_CODE)
    HAVING COUNT(*) > 1
),

-- Common subquery for duplicate orderalllevelinformation_initial
duplicate_core_orderalllevelinformation_initial AS (
    SELECT CONCAT(ORDER_ID, SKU, DISCOUNT_CODE, order_level)
    FROM analytics.core_orderalllevelinformation_initial
    GROUP BY CONCAT(ORDER_ID, SKU, DISCOUNT_CODE, order_level)
    HAVING COUNT(*) > 1
),

duplicate_orderheader_initial AS (
    SELECT order_header_key
    FROM analytics.core_orderheader_initial
    GROUP BY order_header_key
    HAVING COUNT(*) > 1
),

duplicate_orderheader_latest AS (
    SELECT order_header_key
    FROM analytics.core_orderheader_latest
    GROUP BY order_header_key
    HAVING COUNT(*) > 1
),

duplicate_orderlines_initial AS (
    SELECT order_line_key
    FROM analytics.core_orderlines_initial
    GROUP BY order_line_key
    HAVING COUNT(*) > 1
),

duplicate_orderlines_latest AS (
    SELECT order_line_key
    FROM analytics.core_orderlines_latest
    GROUP BY order_line_key
    HAVING COUNT(*) > 1
),

duplicate_customerinformation AS (
    SELECT order_header_key
    FROM analytics.core_customerinformation
    GROUP BY order_header_key
    HAVING COUNT(*) > 1
),

duplicate_hybrisinventory AS (
    SELECT CONCAT(brand_sku,inventory_date_pt)
    FROM analytics.core_hybrisinventory
    GROUP BY CONCAT(brand_sku,inventory_date_pt)
    HAVING COUNT(*) > 1
)

-- Main query begins here
SELECT 
    'core_OrderHeader' AS Core_Query,
    'Duplicate Rows' AS Validation, 
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED') AS Status, 
    CONCAT('Found ', COUNT(*), ' duplicate rows') AS Error,
    CURRENT_DATE AS validation_timestamp
FROM duplicate_order_headers

UNION ALL

SELECT 
    'core_OrderHeader',
    'Order Freshness',
    IFF(hours_old > 2, 'FAILED', 'PASSED'),
    CONCAT('Latest order is ', hours_old, ' hours old'),
    CURRENT_DATE
FROM order_header_freshness

UNION ALL

SELECT 
    'core_OrderHeader',
    'Missing Data',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' missing dates for last 30 days'),
    CURRENT_DATE
FROM missing_orderheader_dates

UNION ALL

SELECT 
    'core_OrderHeader',
    'Invalid Values',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' invalid metric values'),
    CURRENT_DATE
FROM (
    SELECT 1
    FROM analytics.core_orderheader
    WHERE 
        COALESCE(total_payment_received_initial, -1) < 0 OR
        COALESCE(gross_revenue_initial, -1) < 0 OR
        COALESCE(net_revenue_initial, -1) < 0 OR
        COALESCE(total_shipping_payment_initial, -1) < 0 OR
        COALESCE(total_tax_initial, -1) < 0 OR
        COALESCE(total_discounts_initial, -1) < 0 OR
        COALESCE(total_payment_received_latest, -1) < 0 OR
        COALESCE(gross_revenue_latest, -1) < 0 OR
        COALESCE(net_revenue_latest, -1) < 0 OR
        COALESCE(total_shipping_payment_latest, -1) < 0 OR
        COALESCE(total_tax_latest, -1) < 0
)

UNION ALL

SELECT 
    'core_OrderLines',
    'Duplicate Rows',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' duplicate rows'),
    CURRENT_DATE
FROM duplicate_order_lines

UNION ALL

SELECT 
    'core_OrderLines',
    'Invalid Values',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' invalid metric values'),
    CURRENT_DATE
FROM analytics.core_orderlines
WHERE 
    COALESCE(TOTAL_PRODUCT_PRICE_INITIAL, -1) < 0 OR
    COALESCE(TOTAL_PRODUCT_PRICE_LATEST, -1) < 0 OR
    LINE_DISCOUNTS_INITIAL < 0 OR
    LINE_DISCOUNTS_LATEST < 0 OR
    LINE_TAX_INITIAL < 0 OR
    LINE_TAX_LATEST < 0 OR
    COALESCE(PRODUCT_PRICE, -1) < 0 OR
    COALESCE(PRODUCT_REVENUE_INITIAL, -1) < 0 OR
    COALESCE(PRODUCT_REVENUE_LATEST, -1) < 0 OR
    COALESCE(discounted_product_revenue_initial, -1) < 0 OR
    COALESCE(discounted_product_revenue_latest, -1) < 0

UNION ALL

SELECT 
    'core_OrderLines',
    'Data Completeness',
    IFF(COUNT(DISTINCT OH.ORDER_HEADER_KEY) - COUNT(DISTINCT OL.ORDER_HEADER_KEY) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(DISTINCT OH.ORDER_HEADER_KEY) - COUNT(DISTINCT OL.ORDER_HEADER_KEY), ' missing orders'),
    CURRENT_DATE
FROM analytics.core_orderlines OL
LEFT JOIN analytics.core_orderheader OH 
    ON OL.ORDER_HEADER_KEY = OH.ORDER_HEADER_KEY

UNION ALL

SELECT 
    'core_OrderLines',
    'Missing Data',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' missing dates for last 30 days'),
    CURRENT_DATE
FROM missing_orderline_dates

UNION ALL

SELECT 
    'core_SkuMaster',
    'Missing Data',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' missing SKUs in SkuMaster'),
    CURRENT_DATE
FROM (
    SELECT CONCAT(OL.BRAND, OL.SKU)
    FROM analytics.core_orderlines OL
    LEFT JOIN analytics.core_skumaster SM 
        ON OL.BRAND = SM.BRAND AND OL.SKU = SM.SKU
    WHERE SM.SKU IS NULL AND OL.SKU NOT LIKE '100%'
    GROUP BY OL.BRAND, OL.SKU
)

UNION ALL

SELECT 
    'core_SkuMaster',
    'Missing Attributes',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' rows with missing attributes'),
    CURRENT_DATE
FROM analytics.core_skumaster S
JOIN analytics.core_orderlines OL 
    ON S.BRAND = OL.BRAND AND S.SKU = OL.SKU
WHERE COALESCE(NULLIF(DEPARTMENT, ''), '') = '' 
   OR COALESCE(NULLIF(SUBDEPARTMENT, ''), '') = ''
   OR COALESCE(NULLIF(CLASS, ''), '') = ''

UNION ALL

SELECT 
    'core_SkuMaster',
    'Duplicate Rows',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' duplicate rows'),
    CURRENT_DATE
FROM (
    SELECT brand_sku
    FROM analytics.core_skumaster
    GROUP BY brand_sku
    HAVING COUNT(*) > 1
)

UNION ALL

SELECT 
    'core_OMSinventory_historical_pacific',
    'Missing Data',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' missing dates for last 30 days'),
    CURRENT_DATE
FROM missing_oms_historical_dates

UNION ALL

SELECT 
    'core_OrderDiscounts',
    'Duplicate Rows',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' duplicate rows'),
    CURRENT_DATE
FROM duplicate_orderdiscounts

UNION ALL

SELECT 
    'core_LineDiscounts',
    'Duplicate Rows',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' duplicate rows'),
    CURRENT_DATE
FROM duplicate_orderlinediscounts

UNION ALL

SELECT 
    'core_OrderAllLevelInformation_initial',
    'Duplicate Rows',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' duplicate rows'),
    CURRENT_DATE
FROM duplicate_core_orderalllevelinformation_initial

UNION ALL

SELECT 
    'core_OrderHeader_initial',
    'Duplicate Rows',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' duplicate rows'),
    CURRENT_DATE
FROM duplicate_orderheader_initial

UNION ALL

SELECT 
    'core_OrderHeader_latest',
    'Duplicate Rows',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' duplicate rows'),
    CURRENT_DATE
FROM duplicate_orderheader_latest

UNION ALL

SELECT 
    'core_OrderLines_initial',
    'Duplicate Rows',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' duplicate rows'),
    CURRENT_DATE
FROM duplicate_orderlines_initial

UNION ALL

SELECT 
    'core_OrderLines_latest',
    'Duplicate Rows',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' duplicate rows'),
    CURRENT_DATE
FROM duplicate_orderlines_latest

UNION ALL

SELECT 
    'core_CustomerInformation',
    'Duplicate Rows',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' duplicate rows'),
    CURRENT_DATE
FROM duplicate_customerinformation

UNION ALL

SELECT 
    'core_HybrisInventory',
    'Duplicate Rows',
    IFF(COUNT(*) = 0, 'PASSED', 'FAILED'),
    CONCAT('Found ', COUNT(*), ' duplicate rows'),
    CURRENT_DATE
FROM duplicate_hybrisinventory



);
