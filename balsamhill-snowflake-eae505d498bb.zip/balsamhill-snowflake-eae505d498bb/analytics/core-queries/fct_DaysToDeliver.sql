USE DATABASE prod;
CREATE OR REPLACE VIEW analytics.fct_DaysToDeliver AS (
SELECT
    h.source_ref_num AS order_id
    , s.shipment_key
    , s.shipnode_key
    , w.warehouse_name AS warehouse
    , s.tracking_no
    , REGEXP_SUBSTR(cd.item_id, '^[^_]+') AS sku
    , cd.extn_upc_item_id AS upc
    , CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', h.order_date) AS order_date_pt    
    , DATE(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', s.actual_shipment_date)) AS ship_date_pt
    , DATE(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', s.actual_delivery_date)) AS delivery_date_pt
    , CASE 
        WHEN DAYOFWEEKISO(order_date_pt) BETWEEN 1 AND 4 AND EXTRACT(HOUR FROM order_date_pt) >= 9 
            THEN DATEADD('day', 1, DATE(order_date_pt)) -- Mon-Thur after 9am: following day
        WHEN DAYOFWEEKISO(order_date_pt) = 5 AND EXTRACT(HOUR FROM order_date_pt) >= 9 
            THEN DATEADD('day', 3, DATE(order_date_pt)) -- Fri afteer 9am: next Monday        
        WHEN DAYOFWEEKISO(order_date_pt) IN (6, 7) 
            THEN DATEADD('day', CASE WHEN DAYOFWEEKISO(order_date_pt) = 6 THEN 2 ELSE 1 END, DATE(order_date_pt)) -- Sat-Sun: next Monday
        ELSE DATE(order_date_pt) -- Mon-Fri before 9am: same day
        END AS calculated_ship_date_pt
    , DATEDIFF('day', ship_date_pt, delivery_date_pt) AS warehouse_to_customer
    , DATEDIFF('day', calculated_ship_date_pt, delivery_date_pt) AS hybris_to_customer
    , s.order_type    
    , s.level_of_service
    , s.shipment_type
    , s.delivery_method    
    , s.scac
    , s.carrier_type    
    , s.carrier_service_code
    , s.requested_carrier_service_code    
FROM analytics.txn_order_header h
    JOIN analytics.txn_order_shipment s ON h.order_header_key = s.order_header_key        
    JOIN analytics.txn_order_shipment_line sl ON s.shipment_key = sl.shipment_key
    JOIN analytics.txn_order_container_details cd ON s.shipment_key = cd.shipment_key AND sl.shipment_line_key = cd.shipment_line_key
    LEFT JOIN master.dim_warehouse w ON s.shipnode_key = w.pk_warehouseid
WHERE h.source_ref_num LIKE 'J%' -- filter out warranty orders, indirect orders
    AND s.actual_delivery_date <= GETDATE() -- filter out invalid delivery dates 
    AND s.actual_shipment_date <= GETDATE() -- filter out invalid shipment dates 
    AND s.actual_shipment_date <= s.actual_delivery_date -- filter out invalid shipment and delivery date combinations
    AND h.fk_sourceid = 11 -- limit to BHUS only
    AND s.status IN ('1600.300', '1600.3') -- limit to shipments with delivered status
    -- those with status '1600.3' appear to have manually input ship dates and/or delivery dates that appear inaccurate
);