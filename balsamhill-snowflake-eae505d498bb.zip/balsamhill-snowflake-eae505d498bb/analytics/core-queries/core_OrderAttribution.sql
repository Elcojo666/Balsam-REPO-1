USE DATABASE PROD;


CREATE OR REPLACE VIEW analytics.core_OrderAttribution AS (

          SELECT 
        oh.brand
        , oh.order_id 
        , order_date_pt
        , order_date_local
        , channel
        , CASE WHEN source_medium_campaign is not null THEN source_medium_campaign 
            WHEN LOWER(order_source) = 'phone' THEN 'phone / phone / phone'
            WHEN LOWER(channel) = 'hybris' AND lower(order_source) != 'phone' THEN '(not tracked) / (not tracked) / (not tracked)' 
            ELSE CONCAT(channel, ' / ', channel, ' / ', channel)
            END as session_source_medium_campaign
        , GA4_Channel
        , CASE WHEN session_source_medium_campaign = '(not tracked) / (not tracked) / (not tracked)' THEN '(not tracked)' ELSE IFNULL(device_category, '(not set)') END as device_category
        , CASE WHEN session_source_medium_campaign = '(not tracked) / (not tracked) / (not tracked)' THEN '(not tracked)' ELSE IFNULL(hostName, '(not set)') END as hostName
        , CASE WHEN session_source_medium_campaign = '(not tracked) / (not tracked) / (not tracked)' THEN '(not tracked)' ELSE IFNULL(landing_page_path, '(not set)') END as landing_page_path
        , CASE WHEN session_source_medium_campaign = '(not tracked) / (not tracked) / (not tracked)' THEN '(not tracked)' ELSE IFNULL(session_manual_ad_content, '(not set)') END as session_manual_ad_content
        , CASE WHEN session_source_medium_campaign = '(not tracked) / (not tracked) / (not tracked)' THEN '(not tracked)' ELSE user_type END as user_type                                                                   
        , event_source
    FROM PRE_PROD.ANALYTICS.CORE_ORDERHEADER_INITIAL as oh
    LEFT JOIN (
        SELECT DISTINCT
            "Brand" as brand
--            , "Date" as order_date
            , "transactionID" as order_id
--            , CONCAT("sessionSource", ' / ', "sessionMedium") as source_medium
            , CONCAT("sessionSource", ' / ', "sessionMedium", ' / ', "sessionCampaign") as source_medium_campaign
            , "deviceCategory" as device_category
            , "sessionAdContent" as session_manual_ad_content
            , "hostName" as hostname
            , "userType" as user_type
            , "landingPage" as landing_page_path
            , "event_source" as event_source
            , tf.Channel as GA4_Channel
        FROM PRE_PROD.GA4_REPORTING.GA4_SESSION_TRANSACTIONS as ga4_trx

--remove CTE_TrafficSource after Traffic Sources table/view is published. Purpose is to join 'GA4 Channel' from Traffic Sources. Key is 'source_medium'.
        LEFT JOIN core_TrafficSources tf ON CONCAT(ga4_trx."sessionSource", ' / ', ga4_trx."sessionMedium") = tf.source_medium         
    ) as ga4 ON oh.brand = ga4.brand AND oh.order_id = ga4.order_id
);