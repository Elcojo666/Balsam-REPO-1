USE DATABASE PROD;
CREATE OR REPLACE VIEW analytics.fct_OrderAllNotes AS (
--warranties
SELECT
    UPPER(scope) AS brand
    , order_id
    , order_date AS order_date_pt
    , INITCAP(properties:"OrderStatus"::string) AS order_status
    , ARRAY_TO_STRING(ARRAY_AGG(flattened_notes.KEY || ': ' || flattened_notes.VALUE), '; ') AS internal_notes
    , flattened_properties.value:sku::STRING AS sku
    , flattened_properties.value:title::STRING AS product_name    
FROM balsam_priv_data.priv.sc_warranty_orders w,
    LATERAL FLATTEN(input => PARSE_JSON(line_items)) AS flattened_properties,
    LATERAL FLATTEN(input => w.note_attributes) AS flattened_notes
WHERE order_date >= DATEADD(YEAR, -4, DATE_TRUNC('YEAR', CURRENT_DATE) + INTERVAL '1 MONTH')
    AND note_attributes IS NOT NULL
GROUP BY ALL

UNION 

--returns
SELECT
    UPPER(r.scope) AS brand
    , r.order_id
    , DATE(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', r.created_at)) AS order_date_pt
    , INITCAP(r.return_status) AS order_status
    , r.internal_notes
    , ri.sku 
    , ri.title AS product_name
FROM balsam_sc_data.direct_access.sc_returns r 
    JOIN balsam_sc_data.direct_access.sc_return_items ri ON r.scid = ri.scid
WHERE created_at >= DATEADD(YEAR, -4, DATE_TRUNC('YEAR', CURRENT_DATE) + INTERVAL '1 MONTH')
    AND r.internal_notes IS NOT NULL
);