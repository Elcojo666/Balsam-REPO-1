use database prod;

create or replace view analytics.core_WarehouseInventory_UPC_Historical AS (
-- this CTE allows us to filter and limit the date and time of the inserted_date with the RK and RN rows as defined
WITH ShipnodeSnapshot AS (
    SELECT shipNode 
        , productID
        , onhandAvailableQuantity 
        , segmentType -- AMAZON, WEBSITE, etc.
        , created_at
        , fulfillmentallowed
        , CASE WHEN REGEXP_LIKE(productid, '.*_[0-9]+$') THEN  SPLIT_PART(productID, '_', 1)
                ELSE productid
                END AS productID_for_join -- warranty sections are not in ProductMap CTE below; this allows us to join warranty sections to skus
    FROM analytics.txn_shipnode_snapshot
    WHERE segment != 'MISSING' -- to show only ONLINE and EDI segments
        AND segmentType != 'MISSINGTYPE'          
        AND onhandAvailableQuantity > 0
    QUALIFY ROW_NUMBER() OVER(PARTITION BY shipnode, productID, segmentType, CAST(created_at AS DATE) ORDER BY created_at DESC) = 1 -- limit to latest snapshot per UPC per segment per shipnode per date       
) 

-- this CTE filters out older upc-sku associations that are probably outdated (which aren't really many, but worth filtering out to avoid duplicates...?)
,ProductMap AS (
    SELECT DISTINCT
        s.sku_code
        , u.upc_code
        , u.upc_year
        , u.totalcartons
        , u.is_rtp
        , u.cartonnumber
    FROM analytics.map_sku_upc m
        JOIN analytics.upc u ON m.fk_upcid = u.pk_upcid 
        JOIN analytics.sku_product_locale s ON m.fk_productid = s.pk_skuproductid
    WHERE 1=1
        AND s.sku_code NOT LIKE '%TEST%' 
        AND s.sku_code NOT LIKE 'U%' 
    QUALIFY ROW_NUMBER() OVER(PARTITION BY m.fk_upcid ORDER BY m.pk_map_sku_upcid DESC) = 1 -- to remove duplicate mappings
)

-- this query provides the onhandinventory per UPC per shipnode per segmentType; can be the final output if only UPC level inventory per shipnode is desired
    SELECT
        c.country_code AS geo
      , w.warehouse_name AS warehouse
      , i.segmentType AS segment-- several warehouses follow segementation rules for website and amazon      
      , p.sku_code AS Sku
      , i.productID AS Upc
      , p.upc_year 
      , p.cartonnumber AS Carton_Number
      , p.totalcartons AS Total_Cartons_per_Sku
      , CASE
            WHEN p.is_rtp = 0 THEN 'false'
            WHEN p.is_rtp = 1 THEN 'true'
            ELSE null
            END AS is_rtp
      , i.onhandAvailableQuantity AS Number_of_Units_UPC
      , i.created_at AS Inventory_Date
      , i.fulfillmentallowed as fulfillment_allowed
    FROM ShipnodeSnapshot i 
        LEFT JOIN ProductMap p ON i.productID_for_join = p.upc_code
        JOIN master.dim_warehouse w ON i.shipnode = w.pk_warehouseid
        JOIN master.dim_country c ON w.CountryId = c.pk_countryid
);