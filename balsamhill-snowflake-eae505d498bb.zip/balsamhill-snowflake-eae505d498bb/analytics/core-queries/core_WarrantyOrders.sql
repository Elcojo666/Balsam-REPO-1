USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_WarrantyOrders AS (
SELECT distinct
UPPER(scope) AS brand
,source_order_id
,warranty_order_id
,warranty_order_date
,warranty_sku
,warranty_product_name
,warranty_quantity
,warranty_primary_reason
,warranty_secondary_reason
,fulfillment_status as current_order_status
,original_order_id
,original_order_sku
,warranty_start_date
,warranty_end_date
,premium_guarantee_start_date
,premium_guarantee_end_date
FROM sc.vw_warranty_orders
WHERE warranty_quantity > 0
AND original_order_id IS NOT NULL
);