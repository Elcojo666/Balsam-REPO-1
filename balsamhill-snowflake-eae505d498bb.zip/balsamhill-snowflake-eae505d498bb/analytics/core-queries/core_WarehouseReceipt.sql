USE DATABASE prod;

CREATE OR REPLACE VIEW analytics.core_WarehouseReceipt AS (

WITH ValidReceipts AS (
    SELECT warehouse_name
        , ContainerNumber
        , DateReceived
        , InventoryPackingListSummaryID
        , MAX(ID) AS ID -- to remove duplicate warehouse receipts (happens when ops uploads a receipt more than once)
    FROM analytics.InventoryWarehouseReceipt r 
        LEFT JOIN master.dim_warehouse w ON r.warehouseid = w.pk_warehouseid
    WHERE DateReceived >= '2018-02-01'
    GROUP BY ALL
),

ValidReceiptDetails AS (
    SELECT PONumber
        , Upc
        , SUM(ReceivedQty) AS ReceivedQty -- to remove duplicate warehouse receipt details
        , SUM(ExpectedQty) AS ExpectedQty -- to remove duplicate warehouse receipt details
        , MAX(DiscrepancyReason) AS DiscrepancyReason -- to remove duplicate warehouse receipt details
        , InventoryWarehouseReceiptID
        , IsUnexpectedUpc        
    FROM analytics.InventoryWarehouseReceiptDetail
    WHERE PONumber IN (
        SELECT po_number 
        FROM analytics.txn_po_header
        WHERE season_name NOT IN ('2018', '2019', '2020') -- limit to the past four FYs and current FY
    )
    GROUP BY ALL
)

SELECT
    r.warehouse_name
    , r.InventoryPackingListSummaryID AS packing_list_ID 
    , r.ContainerNumber AS container_number
    , r.DateReceived AS date_received
    , rd.PONumber AS po_number
    , rd.Upc
    , rd.ExpectedQty AS expected_qty    
    , rd.ReceivedQty AS received_qty
    , rd.DiscrepancyReason AS discrepancy_reason    
    , CASE WHEN rd.IsUnexpectedUpc = 1 THEN true ELSE false END AS IsUnexpectedUpc
FROM ValidReceipts r
    JOIN ValidReceiptDetails rd ON r.ID = rd.InventoryWarehouseReceiptID
);