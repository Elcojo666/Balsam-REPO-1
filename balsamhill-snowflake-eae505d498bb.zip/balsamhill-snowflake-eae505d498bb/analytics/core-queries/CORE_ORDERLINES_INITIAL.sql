create or replace view ANALYTICS.CORE_ORDERLINES_INITIAL
 as
( 
with cte_id as 
(
    select *
    from analytics.core_orderids_initial
),

cte_discounts as
(
    select
        order_line_key,
        sum(line_discounts_initial) as line_discounts_initial
    from analytics.core_linediscounts_initial
    group by order_line_key
),

cte_line as
(
select distinct
    id.order_header_key,
    i.source_line_item_id as order_line_key,
    i.sku,
    i.title as order_product_name,
    i.quantity as ordered_quantity_initial,
    (CASE
        WHEN i.scope NOT IN ('bhus', 'bhca', 'tcus', 'ttus') THEN CAST((((i.price * i.quantity) + coalesce(tax.line_tax_initial,0)) / i.quantity) AS FLOAT)
        WHEN i.title LIKE 'Extend Protect%' THEN i.price * 0.4
        ELSE i.price
        END) AS product_price,
    coalesce(tax.line_tax_initial,0) line_tax_initial,
    i.quantity * product_price as total_product_price_initial,
    CASE WHEN i.title LIKE 'Extend Protect%' THEN 'YES' ELSE 'NO' END AS extend_warranty
from cte_id id
join balsam_sc_data.direct_access.sc_org_items i on id.order_header_key = i.source_order_id
left join analytics.core_linetax_initial tax on i.source_line_item_id = tax.order_line_key
WHERE 
    i.quantity > 0
    AND i.price > 0
    AND i.item_canceled = FALSE 
)

select distinct
    id.order_header_key,
    line.order_line_key,
    o.scid,
    o.cuid as customer_id,
    UPPER(CONCAT(id.brand , line.sku)) AS brand_sku,
    id.brand,
    id.channel,
    id.order_source,
    id.order_id,
    id.order_date_pt,
    id.order_date_local,
    line.sku,
    line.order_product_name,
    line.ordered_quantity_initial,
    line.product_price,
    line.line_tax_initial,
    coalesce(discount.line_discounts_initial,0) line_discounts_initial,    
    line.total_product_price_initial,
    case when id.brand not in ('BHUS', 'BHUS', 'TCUS', 'TTUS')
        then line.total_product_price_initial - line.line_tax_initial 
        else line.total_product_price_initial
        end AS product_revenue_initial,
    product_revenue_initial - coalesce(discount.line_discounts_initial,0) AS discounted_product_revenue_initial,
    o.payment_method as payment_method,
    o.currency as currency,
    o.currency_conversion_rate as currency_conversion_rate,
    upper(ifnull(o.properties:"OrderStatus"::text, o.fulfillment_status)) as current_order_status,
    line.extend_warranty,
    case when line_discounts_initial is not null then 'YES' else 'NO' end as discounted
from cte_id id
join cte_line line on id.order_header_key = line.order_header_key
join balsam_sc_data.direct_access.sc_org_orders o on id.order_header_key = o.source_order_id
left join cte_discounts discount on line.order_line_key = discount.order_line_key
);