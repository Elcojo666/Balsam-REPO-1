use database prod;
create or replace view analytics.core_CustomerInformation AS (

SELECT
        o.order_header_key    
        ,CASE
            WHEN UPPER(ba.address1) LIKE '%PO BOX%' 
                THEN UPPER(CONCAT(
                        LEFT(COALESCE(REGEXP_REPLACE(ba.first_name, '[^a-zA-Z0-9]', ''), ''), 2) 
                        , LEFT(COALESCE(REGEXP_REPLACE(ba.last_name, '[^a-zA-Z0-9]', ''), ''), 5)
                        , LEFT(COALESCE(REGEXP_REPLACE(ba.postal_code, '[^a-zA-Z0-9]', ''), ''), 2)
                        , RIGHT(COALESCE(REGEXP_REPLACE(ba.address1, '[^a-zA-Z0-9]', ''), ''), 5)
                        ))
            ELSE UPPER(CONCAT(
                    LEFT(COALESCE(REGEXP_REPLACE(ba.first_name, '[^a-zA-Z0-9]', ''), ''), 2) 
                    , LEFT(COALESCE(REGEXP_REPLACE(ba.last_name, '[^a-zA-Z0-9]', ''), ''), 5)
                    , LEFT(COALESCE(REGEXP_REPLACE(ba.postal_code, '[^a-zA-Z0-9]', ''), ''), 2)
                    , LEFT(COALESCE(REGEXP_REPLACE(ba.address1, '[^a-zA-Z0-9]', ''), ''), 5)
                    ))
            END AS customer_id_hash
        ,SUBSTRING(o.email_address,CHARINDEX('|',o.email_address)+1,Len(o.email_address)) AS email
        ,ba.first_name AS billing_first_name
        ,ba.last_name AS billing_last_name
        ,ba.phone_number AS billing_phone_number
        ,ba.company_name AS billing_company_name
        ,ba.address1 AS billing_address1
        ,ba.address2 AS billing_address2
        ,ba.city AS billing_city
        ,ba.state AS billing_state
        ,ba.postal_code AS billing_postal_code
        ,ba.country AS billing_country
        ,sa.first_name AS ship_first_name
        ,sa.last_name AS ship_last_name
        ,sa.phone_number AS ship_phone_number
        ,sa.company_name AS ship_company_name
        ,sa.address1 AS ship_address1
        ,sa.address2 AS ship_address2
        ,sa.city AS ship_city
        ,sa.state AS ship_state
        ,sa.postal_code AS ship_postal_code
        ,sa.country AS ship_country
        ,c.source_ref_num AS platform_customer_id
        ,c.ext_customer_id AS registered_customer_id
        ,ct.customer_type AS customer_type
    FROM analytics.txn_order_header o 	
        JOIN master.dim_order_status s ON o.fk_order_statusid = s.pk_order_statusid
        JOIN analytics.txn_address ba ON o.fk_billing_addressid = ba.pk_addressid
        JOIN analytics.txn_address sa ON o.fk_shipping_addressid = sa.pk_addressid
        JOIN analytics.customer c ON o.fk_customerid = c.pk_customerid
        LEFT JOIN master.dim_customer_type ct ON c.fk_customer_typeid = ct.pk_customer_typeid
        LEFT JOIN analytics.core_testorders tst ON o.order_header_key = tst.order_header_key
    WHERE o.order_date >= '2020-01-01' -- limit data to recent four years
        AND o.order_header_key IS NOT NULL -- limit data to post-TSU orders and migrated orders
        AND tst.order_header_key IS NULL -- filter out test orders
);
