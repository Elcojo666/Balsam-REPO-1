create or replace view ANALYTICS.CORE_PHONEORDERS_HEADER
as
(
WITH cte_phoneorders as
(
SELECT distinct
    source_ref_num as order_id
    ,COALESCE(SalesRep_CustomerID, entered_by) AS sales_representative
FROM analytics.txn_order_header
WHERE (SalesRep_CustomerID IS NOT NULL OR entered_by IS NOT NULL) --filter Phone orders only
AND COALESCE(SalesRep_CustomerID, entered_by) != 'Online'
)

SELECT 
    o.order_header_key,
    o.scid,
    o.customer_id,
    o.brand,
    o.channel,
    o.order_source,
    o.order_id,
    o.order_date_pt,
    o.order_date_local,
    o.total_payment_received_initial,
    o.total_ordered_quantity_initial,
    o.current_order_status,
    o.currency,
    o.currency_conversion_rate,
    CASE
        WHEN p.sales_representative ILIKE '%taskus%' THEN 'TaskUS'
        WHEN p.sales_representative ILIKE '%proserviceboise.com' THEN 'ProService'
        WHEN p.sales_representative ILIKE '%s2G.net' THEN 'S2G'
        WHEN p.sales_representative ILIKE '%aremaconnect.com' THEN 'Arema'
        ELSE 'OTHER' END AS sales_representative_company,    
    p.sales_representative,
    case
        when sales_representative ILIKE '%support.co' THEN 'B2B'
        when sales_representative ILIKE '%balsamhill.com' THEN 'Design Consultant'
        when sales_representative ILIKE '%balsambrands.com' THEN 'BH Studios'
    else 'phone'
    end as phone_order_category
from cte_phoneorders p
join analytics.core_orderheader_initial o on p.order_id = o.order_id
);