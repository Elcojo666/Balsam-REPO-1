USE DATABASE PROD;
CREATE OR REPLACE VIEW analytics.core_OrderAllocation AS (
--postTSU:
    -- this CTE pulls the order details at header level
    -- one order will have one row of data
    WITH OrderHeader AS (
        SELECT TOH.source_ref_num            
            , BrandCodeForPOTracker
            , platform_name
            , CAST(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', order_date) AS DATETIME) AS order_date
            , TOH.order_header_key        
        FROM analytics.txn_order_header TOH 
            JOIN master.dim_source DS ON DS.pk_sourceid = TOH.fk_sourceid
            JOIN master.dim_platform DP ON DP.pk_platformid = DS.fk_platformid
            JOIN master.dim_brand DB ON DB.pk_brandid = DS.fk_brandid
            JOIN analytics.txn_order_status TOS ON TOS.fk_order_headerid = TOH.pk_order_headerid
        WHERE order_date > '2023-06-12'
            AND TOH.source_ref_num NOT LIKE 'P%' -- pre-tsu test orders
            AND TOH.source_ref_num NOT LIKE 'R%'-- return created
            --AND TOS.fk_order_statusid NOT IN (3, 13, 27, 28) -- cancelled orders (various spellings)            
    ),

    -- this CTE pulls the order release details (i.e., when an order is released/assigned to a warehouse)
    -- one order will have as many rows as it has releases (an order may be released at header level, yet it may also be released at SKU level or quantity level)
    OrderRelease AS (
        SELECT TOR.order_header_key
            , TOR.order_release_key -- same as "Order Reference Key" in WMS        
            , TOR.shipnode_key -- the warehouse to which the order (either at header level or line level) is assigned        
            , TOR.scac
            , TOR.carrier_service_code
            , MAX(createts) AS createts -- timestamp of the release; use MAX to get the latest release of the order (some orders are released more than once for whatever reason)
        FROM analytics.txn_order_release TOR          
        GROUP BY ALL -- necessary for MAX function above
    ),

    -- this CTE pulls the timestamp for when the order status of the order release changes to RELEASED
    -- we use this as a second option in case this timestamp is not available or accurate in txn_order_release
    -- 231121: there will be one row for each carton: a single-carton item will return one row while a four-carton tree will return four rows.
    OrderReleaseStatus AS (
        SELECT TORS.order_header_key        
            , TORS.order_release_key
            , TORS.order_line_key
            , SUM(CAST(TORS.total_quantity AS DECIMAL)) AS total_quantity -- each carton will have an order_line_key; SUM is needed to get all quantities per carton
            , MAX(TORS.status_date) AS DateReleased-- MAX to get the latest release
        FROM analytics.txn_order_release_status TORS
        WHERE LEFT(TORS.status, 4) = '3200' -- we've seen [status] = '3200' and '3200.0' for an order where 3200.0 is the second release; limits results to status = released
        GROUP BY ALL
    ), 

    OrderDetail AS (
        SELECT DISTINCT d.order_header_key -- distinct to eliminate duplicates in ext_order_detail
            , d.order_line_key
            , e.customer_item
            , e.customer_item_description
            , d.quantity
        FROM analytics.txn_order_detail d 
            JOIN analytics.ext_order_detail e ON d.order_line_key = e.order_line_key
    )

    -- main query combines all above CTEs
    SELECT xOH.source_ref_num AS Order_ID
        , xOH.order_date AS Order_Date_PT
        , xORS.order_line_key
        , xOH.BrandCodeForPOTracker AS Brand 
        , xOH.platform_name AS Channel
        , DW.warehouse_name AS Warehouse
        , CASE 
            WHEN DW.is_domestic = 0 THEN 'International'
            WHEN DW.is_domestic = 1 THEN 'Domestic'
            ELSE NULL
            END AS Warehouse_Type
        , xOR.scac AS Carrier 
        , xOR.carrier_service_code AS Warehouse_Shipping_Method
        , xOD.customer_item AS sku
        , xORS.total_quantity AS Carton_Count
        , CASE
            WHEN xOR.createts IS NOT NULL THEN
                CAST(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', createts) AS DATETIME)
            ELSE
                CAST(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', xORS.DateReleased) AS DATETIME)
            END AS Date_Released_PT
        , si.item_canceled
    FROM OrderHeader xOH
        LEFT JOIN OrderRelease xOR ON xOH.order_header_key = xOR.order_header_key
        LEFT JOIN OrderReleaseStatus xORS ON xOR.order_header_key = xORS.order_header_key AND xOR.order_release_key = xORS.order_release_key 
        LEFT JOIN OrderDetail xOD ON xORS.order_line_key = xOD.order_line_key
        LEFT JOIN master.dim_warehouse DW ON CAST(xOR.shipnode_key AS DECIMAL) = DW.pk_warehouseid
        LEFT JOIN balsam_sc_data.direct_access.sc_items si ON xOH.order_header_key = si.source_order_id AND xORS.order_line_key = si.source_line_item_id
    WHERE xOH.order_date > '2023-06-12'
        AND xOR.scac IS NOT NULL
        -- AND source_ref_num = 'J100255442' -- one tree collar, one four-carton tree
        -- AND source_ref_num = 'J100034912' -- one wreath, one two-carton tree
        -- AND source_ref_num = 'J100842960' -- multiple stockings with different personalizations
        -- AND source_ref_num = 'J100024215' -- has unexplained duplicates in ext_order_detail                

UNION ALL 

    --pre-TSU
    SELECT DISTINCT
            OH.source_ref_num AS Order_ID            
            ,OH.order_date AS Order_Date_PT
            ,OD.order_line_key
            ,B.BrandCodeForPOTracker AS Brand 
            ,P.platform_name AS Channel
            ,W.warehouse_name AS Warehouse
            , CASE 
                WHEN W.is_domestic = 0 THEN 'International'
                WHEN W.is_domestic = 1 THEN 'Domestic'
                ELSE NULL
                END AS Warehouse_Type
            ,TOD.CarrierCode AS Carrier 
            ,TOD.WarehouseShippingMethodID AS Warehouse_Shipping_Method
            ,e.customer_item AS sku
            ,TOD.Qty AS Carton_Count
            ,TOD.DateDelivered AS Date_Released_PT
            ,si.item_canceled
        FROM analytics.txn_order_header OH
            JOIN analytics.txn_order_detail OD ON OH.pk_order_headerid = OD.fk_order_headerid
            JOIN analytics.txn_order_delivered TOD ON OH.source_ref_num = TOD.sourcerefnum AND OD.fk_skuproductid = TOD.fk_skuproductid
            JOIN master.dim_warehouse W ON TOD.fk_warehouseid = W.pk_warehouseid
            JOIN master.dim_source S ON S.pk_sourceid = OH.fk_sourceid
            JOIN master.dim_brand B ON S.fk_brandid = B.pk_brandid
            JOIN master.dim_platform P ON S.fk_platformid = P.pk_platformid
            LEFT JOIN analytics.ext_order_detail e ON od.order_line_key = e.order_line_key
            LEFT JOIN balsam_sc_data.direct_access.sc_items si ON OH.order_header_key = si.source_order_id AND OD.order_line_key = si.source_line_item_id
        WHERE OH.order_date BETWEEN '2021-02-01' AND '2023-06-12'
);