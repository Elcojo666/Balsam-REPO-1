use database prod;

create or replace view analytics.core_WarehouseInventory_SKU_Historical AS (
-- this CTE allows us to filter and limit the date and time of the inserted_date with the RK and RN rows as defined
WITH ShipnodeSnapshot AS (
    SELECT shipNode 
        , productID
        , onhandAvailableQuantity 
        , segmentType -- AMAZON, WEBSITE, etc.
        , created_at
        , CASE WHEN REGEXP_LIKE(productid, '.*_[0-9]+$') THEN  SPLIT_PART(productID, '_', 1)
                ELSE productid
                END AS productID_for_join -- warranty sections are not in ProductMap CTE below; this allows us to join warranty sections to skus
    FROM analytics.txn_shipnode_snapshot
    WHERE segment != 'MISSING' -- to show only ONLINE and EDI segments
        AND segmentType != 'MISSINGTYPE'
        AND onhandAvailableQuantity > 0
        AND fulfillmentallowed
    QUALIFY ROW_NUMBER() OVER(PARTITION BY shipnode, productID, segmentType, CAST(created_at AS DATE) ORDER BY created_at DESC) = 1 -- limit to latest snapshot per UPC per segment per shipnode per date
) 

-- this CTE filters out older upc-sku associations that are probably outdated (which aren't really many, but worth filtering out to avoid duplicates...?)
,ProductMap AS (
    SELECT DISTINCT
        s.sku_code
        , u.upc_code
        , u.upc_year
        , u.totalcartons
        , u.is_rtp
        , u.cartonnumber
    FROM analytics.map_sku_upc m
        JOIN analytics.upc u ON m.fk_upcid = u.pk_upcid 
        JOIN analytics.sku_product_locale s ON m.fk_productid = s.pk_skuproductid
    WHERE 1=1
        AND s.sku_code NOT LIKE '%TEST%' 
        AND s.sku_code NOT LIKE 'U%' 
    QUALIFY ROW_NUMBER() OVER(PARTITION BY m.fk_upcid ORDER BY m.pk_map_sku_upcid DESC) = 1 -- to remove duplicate mappings
)

-- this CTE groups together regular UPCs with warranty sections
,GroupedInventory AS (
    SELECT
        c.country_code AS geo
      , i.shipNode
      , w.warehouse_name AS warehouse
      , i.segmentType-- several warehouses follow segementation rules for website and amazon      
      , p.sku_code AS Sku
      , i.productID_for_join AS Upc
      , p.upc_year 
      , p.cartonnumber 
      , p.totalcartons
      , p.is_rtp
      , SUM(i.onhandAvailableQuantity) AS onhandAvailableQuantity -- sum together regular UPCs with warranty sections
      , CAST(i.created_at AS DATE) AS inventory_date_only
      , MAX(i.created_at) AS created_at
    FROM ShipnodeSnapshot i 
        JOIN ProductMap p ON i.productID_for_join = p.upc_code
        JOIN master.dim_warehouse w ON i.shipnode = w.pk_warehouseid
        JOIN master.dim_country c ON w.CountryId = c.pk_countryid    
    GROUP BY ALL
)

-- this query provides the onhandinventory per UPC per shipnode per segmentType
, UPCInventory AS (
    SELECT
        geo
      , warehouse
      , segmentType
      , Sku
      , Upc
      , upc_year 
      , cartonnumber 
      , totalcartons
      , is_rtp
      , onhandAvailableQuantity
      , created_at
      , COUNT(*) OVER(PARTITION BY shipnode, segmentType, sku, upc_year, is_rtp, CAST(created_at AS DATE)) AS UpcCounter -- counts how many UPCs have inventory in each shipnode per segment per sku per year and differentiates between RTP and non-RTP UPCs
    FROM GroupedInventory
)

-- this query provides the onhandinventory per SKU per RTP per shipnode per segmentType
, SkuRTPInventory AS (
    SELECT geo
        , warehouse 
        , segmentType
        , sku
        , upc_year
        , is_rtp
        , CAST(created_at AS DATE) AS inventory_date_only
        , MAX(created_at) as created_at -- group together inventory reports in the same day but in different hours
        , MIN(onhandAvailableQuantity) AS onhandAvailableQuantity -- if a warehouse has 10 units of carton 1 and 12 units of carton 2, it only has 10 units of the complete tree, so we take only the min        
    FROM UPCInventory 
    WHERE UpcCounter = totalcartons -- to filter out Upcs that do not have their partner Upcs (e.g. carton1 only of a two-carton tree)        
    GROUP BY ALL
)

SELECT geo
    , warehouse 
    , segmentType AS segment
    , sku   
    , SUM(onhandAvailableQuantity) AS Number_of_Units_sku -- adds rtp and non-rtp sku units; and units of different years
    , MAX(created_at) AS Inventory_Date -- group together inventory reports in the same day but in different hours
    , inventory_date_only
FROM SkuRTPInventory 
GROUP BY ALL
);