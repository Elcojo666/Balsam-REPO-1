USE DATABASE PRE_PROD;

CREATE OR REPLACE VIEW analytics.core_LineDiscounts AS (
SELECT 
    source_order_id AS order_header_key,
    source_order_line_item_id AS order_line_key,
    scid,
    D.order_id,
    UPPER(scope) AS brand,
    order_type AS channel,
    CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', order_timestamp::TIMESTAMP_NTZ)AS order_date_pt,
    CASE
        WHEN scope = 'bhuk' THEN CONVERT_TIMEZONE('UTC', 'Europe/London', order_timestamp::TIMESTAMP_NTZ)
        WHEN scope = 'bhde' THEN CONVERT_TIMEZONE('UTC', 'Europe/Berlin', order_timestamp::TIMESTAMP_NTZ)
        WHEN scope = 'bhfr' THEN CONVERT_TIMEZONE('UTC', 'Europe/Paris', order_timestamp::TIMESTAMP_NTZ)
        WHEN scope = 'bhau' THEN CONVERT_TIMEZONE('UTC', 'Australia/Sydney', order_timestamp::TIMESTAMP_NTZ)
        WHEN scope = 'bhus' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', order_timestamp::TIMESTAMP_NTZ)
        WHEN scope = 'bhca' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', order_timestamp::TIMESTAMP_NTZ)
        WHEN scope = 'ttus' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', order_timestamp::TIMESTAMP_NTZ)
        WHEN scope = 'tcus' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', order_timestamp::TIMESTAMP_NTZ)
        ELSE order_timestamp 
    END AS order_date_local,
    sku,
    discount_code,
    discount_name,
    promo_code,
    SUM(discount_amount) AS discount_amount,
    currency_conversion_code,
    C.CURRENCY_EXCHANGE_RATE
FROM pre_prod.sc.VW_DISCOUNTS_PROMOS D
JOIN analytics.core_OrderIDs_initial I ON D.ORDER_ID = I.ORDER_ID
LEFT JOIN analytics.core_currencyexchangerate C ON D.CURRENCY_CONVERSION_CODE = C.CURRENCY AND CAST(D.ORDER_DATE AS DATE) = C.PUBLISH_DATE
WHERE discount_amount != 0
AND discount_amount IS NOT NULL
AND DISCOUNT_NAME NOT IN
(
'MigratedDiscount'
,'Migrated One Cent Discount'
,'DSC-CC'
,'DSC-CCC'
,'DSC-PGTY'
,'For QA/Testing purposes'
,'Funds transferred from order 8436'
,'Groupon'
,'New Promotional Voucher'
,'OFF-SHIP'
,'offset (Coupon Code: BHSAS75OFFA)'
,'Offset BALSAMHILL90A'
,'Offset discount'
,'Offset shipping'
,'Post Order Discount'
,'test'
,'Test Coupon Applied'
,'Z084 - $0 Value Order-PR-BHUS'
,'Z085 - $0 Value Order-PR-BHUS'
,'Zero Cost - Marketing Order Placed'
,'Zero Cost - Order Placed'
,'Zero-Cost Marketing coupon applied!')
AND DISCOUNT_CODE IS NOT NULL
AND DISCOUNT_CODE NOT IN
(
'Branch Sample Kit Credit'
,'BSK'
,'Large Branch Sample Kit'    
)
GROUP BY ALL
);