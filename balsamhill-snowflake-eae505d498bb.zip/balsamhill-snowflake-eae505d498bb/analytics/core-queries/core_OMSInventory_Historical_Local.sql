USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_OMSInventory_Historical_Local AS (

SELECT
    CONCAT(b.BrandCodeForPOTracker, si.sku_code) AS Brand_Sku    
    , b.BrandCodeForPOTracker AS Brand
    , si.sku_code AS Sku    
    , p.platform_name as channel
    , CASE 
        WHEN b.BrandCodeForPOTracker = 'BHAU' THEN CONVERT_TIMEZONE('UTC', 'Australia/Sydney', si.inserted_date) -- AU
        WHEN b.BrandCodeForPOTracker = 'BHUK' THEN CONVERT_TIMEZONE('UTC', 'Europe/London', si.inserted_date) -- UK
        WHEN b.BrandCodeForPOTracker = 'BHDE' OR b.BrandCodeForPOTracker = 'BHFR' THEN CONVERT_TIMEZONE('UTC', 'Europe/Berlin', si.inserted_date) --DE/FR
        WHEN b.BrandCodeForPOTracker = 'BHCA' OR b.BrandCodeForPOTracker = 'BHUS' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', si.inserted_date) -- CA/US
        ELSE si.inserted_date
        END AS Inventory_Date_Local    
    , stock AS OMS_Inventory
FROM analytics.audit_storefront_inventory si
    JOIN master.dim_source s ON si.sourceid = s.pk_sourceid
    JOIN master.dim_brand b ON s.fk_brandid = b.pk_brandid
    JOIN master.dim_platform p ON s.fk_platformid = p.pk_platformid
WHERE si.sku_code NOT LIKE '%TEST%' --remove test skus
    AND si.sku_code NOT LIKE '10001-balsamhill-base%' --remove extend warranty items
    --AND si.stock > 0 -- remove OOS skus       
QUALIFY ROW_NUMBER() OVER(PARTITION BY b.BrandCodeForPOTracker, si.sku_code, p.platform_name, CAST(Inventory_Date_Local AS date) ORDER BY Inventory_Date_Local) = 1 -- 1 is the first for each local date
);