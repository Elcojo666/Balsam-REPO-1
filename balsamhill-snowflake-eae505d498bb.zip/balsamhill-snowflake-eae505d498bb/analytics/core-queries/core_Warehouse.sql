USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_Warehouse AS (
    
    SELECT 
    pk_warehouseid AS warehouse_id
    ,W.warehouse_name AS warehouse_name
    ,CASE
    WHEN C.country_code  IS NOT NULL THEN (CASE WHEN C.country_code = 'DE' THEN 'EU' ELSE C.country_code END)
    ELSE (CASE WHEN S.country = 'GB' THEN 'UK' WHEN S.country = 'NE' THEN 'EU' ELSE S.country END)
    END AS warehouse_region
    ,C.country_code AS warehouse_country
FROM master.dim_warehouse W
LEFT JOIN master.dim_country C ON W.CountryId = C.pk_countryid
LEFT JOIN master.dim_shipnode S ON S.first_name = W.warehouse_name 

WHERE warehouse_name NOT LIKE '%TBD%'
);
