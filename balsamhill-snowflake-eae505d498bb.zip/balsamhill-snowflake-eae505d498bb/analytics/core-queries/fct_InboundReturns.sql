USE DATABASE prod;

CREATE OR REPLACE VIEW analytics.fct_InboundReturns AS (
SELECT
    sl.order_no AS order_id
    , DATE(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', h.order_date)) AS order_date_pt    
    , DATE(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', s.carrier_pickup_time)) AS carrier_pickup_time_pt
    , s.shipment_key
    , w.warehouse_name AS receiving_warehouse    
    , s.scac 
    , s.carrier_service_code 
    , s.order_type -- can be BALSAM_HILL, ASM, HYBRIS, NORDSTROM, TREETOPIA, or WARRANTY
    , cd.item_id AS sku
    , sl.item_description
    , cd.extn_upc_item_id AS upc    
    , SUM(sl.quantity) AS quantity 
        -- in some cases, the same shipment_key is used for multiple units of a UPC; we add those here so that they do not appear in separate rows, which could make them look like duplicates when they are not (they have different prime_line_no)
        -- see sl-order_no = 'R100338685': customer returned two units of 2807703: carton1of2 had two different shipment_key but carton2of2 has the same shipment_key for the two units (but had different prime_line_no)
FROM analytics.txn_order_shipment s 
    JOIN analytics.txn_order_shipment_line sl ON s.shipment_key = sl.shipment_key
    JOIN analytics.txn_order_container_details cd ON s.shipment_key = cd.shipment_key AND sl.shipment_line_key = cd.shipment_line_key
    LEFT JOIN master.dim_warehouse w ON SPLIT_PART(s.receiving_node, '.', 1) = w.pk_warehouseid
    JOIN analytics.txn_order_header h ON h.source_ref_num = sl.order_no
WHERE sl.order_no LIKE 'R%'
GROUP BY ALL
);