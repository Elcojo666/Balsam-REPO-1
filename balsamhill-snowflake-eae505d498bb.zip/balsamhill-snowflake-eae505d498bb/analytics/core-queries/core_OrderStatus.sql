USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_OrderStatus AS (
WITH CTE_OrderStatus AS (
  SELECT
    order_header_key,
    MIN(STATUS_DATE) AS status_timestamp_min,
    MAX(STATUS_DATE) as status_timestamp_max,
    CASE
      WHEN STATUS = '3350.0' THEN '3350'
      WHEN STATUS = '3700.0' THEN '3700'
      WHEN STATUS = '3700.300' THEN '3700.3'
      ELSE STATUS
    END AS order_line_status
  FROM txn_order_release_status
  WHERE STATUS IN (
    '3200', '3350', '3350.0',
    '3700', '3700.0', '3700.001',
    '3700.003', '3700.300'
  )
    AND STATUS_DATE IS NOT NULL
  GROUP BY order_header_key, STATUS
),

CTE_status AS (
  SELECT DISTINCT
    TOR.order_header_key,
    CASE
      WHEN UPPER(TRIM(order_status_name)) = 'RELEASED' THEN 'RELEASED'
      WHEN UPPER(TRIM(order_status_name)) = 'INCLUDED IN SHIPMENT' THEN 'INCLUDED_IN_SHIPMENT'
      WHEN UPPER(TRIM(order_status_name)) = 'SHIPPED' THEN 'SHIPPED'
      WHEN UPPER(TRIM(order_status_name)) = 'IN TRANSIT' THEN 'IN_TRANSIT'
      WHEN UPPER(TRIM(order_status_name)) = 'DELIVERED' THEN 'DELIVERED'
      ELSE NULL
    END AS order_status,
    TOR.status_timestamp_min,
    TOR.status_timestamp_max
  FROM CTE_OrderStatus TOR
  JOIN master.dim_order_status DOS 
    ON TOR.order_line_status = DOS.oms_order_status_code
  WHERE TOR.status_timestamp_min IS NOT NULL
)

SELECT
    order_header_key,
    MIN(CASE WHEN order_status = 'RELEASED' THEN status_timestamp_min ELSE NULL END) AS RELEASED_timestamp_earliest,
    MIN(CASE WHEN order_status = 'INCLUDED_IN_SHIPMENT' THEN status_timestamp_min ELSE NULL END) AS INCLUDED_IN_SHIPMENT_timestamp_earliest,
    MIN(CASE WHEN order_status = 'SHIPPED' THEN status_timestamp_min ELSE NULL END) AS SHIPPED_timestamp_earliest,
    MIN(CASE WHEN order_status = 'IN_TRANSIT' THEN status_timestamp_min ELSE NULL END) AS IN_TRANSIT_timestamp_earliest,
    MIN(CASE WHEN order_status = 'DELIVERED' THEN status_timestamp_min ELSE NULL END) AS DELIVERED_timestamp_earliest,
    MAX(CASE WHEN order_status = 'RELEASED' THEN status_timestamp_max ELSE NULL END) AS RELEASED_timestamp_latest,
    MAX(CASE WHEN order_status = 'INCLUDED_IN_SHIPMENT' THEN status_timestamp_max ELSE NULL END) AS INCLUDED_IN_SHIPMENT_timestamp_latest,
    MAX(CASE WHEN order_status = 'SHIPPED' THEN status_timestamp_max ELSE NULL END) AS SHIPPED_timestamp_latest,
    MAX(CASE WHEN order_status = 'IN_TRANSIT' THEN status_timestamp_max ELSE NULL END) AS IN_TRANSIT_timestamp_latest,
    MAX(CASE WHEN order_status = 'DELIVERED' THEN status_timestamp_max ELSE NULL END) AS DELIVERED_timestamp_latest
FROM CTE_status
GROUP BY order_header_key
);