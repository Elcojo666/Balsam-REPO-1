USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_IndirectOrders_initial AS (

WITH 
cte_items AS (
    SELECT 
        i.source_order_id,
        SUM(i.quantity) AS total_ordered_quantity_initial,
        SUM(i.quantity * i.price) AS total_product_price_initial_usd,
        SUM(i.quantity * oi.price) AS total_product_price_initial_local
    FROM balsam_sc_data.direct_access.sc_org_items oi
    JOIN balsam_sc_data.direct_access.sc_items i on oi.source_line_item_id = i.source_line_item_id
    WHERE
    i.quantity > 0
    AND i.price > 0
    AND i.item_canceled = FALSE
    GROUP BY i.source_order_id
)

SELECT DISTINCT
    o.source_order_id AS order_header_key,
    o.scid,
    o.cuid AS customer_id,
    UPPER(o.scope) AS brand,
    CASE
        WHEN o.order_type ILIKE 'ASM' THEN 'HYBRIS' 
        WHEN O.channel ILIKE '%AMAZON' THEN 'AMAZON'
        WHEN O.channel ILIKE '%VOLUSION%' THEN 'VOLUSION'
        ELSE o.order_type 
    END AS channel,
    CASE 
        WHEN o.order_type ILIKE 'ASM' THEN 'Phone' 
        ELSE o.properties:"EntryType"::TEXT 
    END AS order_source,
    o.order_id AS order_id,
    IFNULL(o.properties:"CustomerPONo"::STRING, O.order_id) AS customer_po_number,
    o.order_date AS order_date_pt,
    CASE
        WHEN o.scope = 'bhuk' THEN CONVERT_TIMEZONE('UTC', 'Europe/London', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'bhde' THEN CONVERT_TIMEZONE('UTC', 'Europe/Berlin', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'bhfr' THEN CONVERT_TIMEZONE('UTC', 'Europe/Paris', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'bhau' THEN CONVERT_TIMEZONE('UTC', 'Australia/Sydney', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'bhus' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'bhca' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'ttus' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', o.order_timestamp::TIMESTAMP_NTZ)
        WHEN o.scope = 'tcus' THEN CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', o.order_timestamp::TIMESTAMP_NTZ)
        ELSE o.order_timestamp 
    END AS order_date_local,
    o.total_price AS total_payment_received_initial_usd,
    o.total_tax  AS total_tax_initial_usd,
    o.total_shipping  AS total_shipping_payment_initial_usd,
    oo.total_price AS total_payment_received_initial_local,
    oo.total_tax AS total_tax_initial_local,
    oo.total_shipping AS total_shipping_payment_initial_local,
    i.total_ordered_quantity_initial,
    i.total_product_price_initial_local,
    o.total_discounts AS total_discounts_initial_usd,
    oo.total_discounts AS total_discounts_initial_local,
    o.payment_method AS payment_method,
    o.currency AS currency_local,
    o.fulfillment_status AS current_order_status,
    CASE 
        WHEN o.properties:"GiftFlag" = TRUE THEN 'YES' 
        ELSE 'NO' 
    END AS gift_flag
FROM balsam_sc_data.direct_access.sc_orders o
JOIN balsam_sc_data.direct_access.sc_org_orders oo ON o.source_order_id = oo.source_order_id
LEFT JOIN cte_items i ON o.source_order_id = i.source_order_id
WHERE
o.order_id NOT LIKE 'P%'
AND UPPER(o.order_type) NOT IN ('SFORDERMIGRATION', 'HYBRIS', 'ASM')
AND total_payment_received_initial_usd > 0 
AND UPPER(o.fulfillment_status) NOT IN ('CANCELLED', 'CANCELED')
AND UPPER(o.channel) != 'HYBRIS'
);