USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_Transactions AS (
    SELECT DISTINCT
    "BRAND" as brand,
    TO_DATE("DATE", 'YYYYMMDD') as transaction_date,
    "TRANSACTION_ID" as order_id,
    CONCAT(LOWER("SESSION_SOURCE"), ' / ', LOWER("SESSION_MEDIUM")) as session_source_medium,
    LOWER("SESSION_CAMPAIGN") as session_campaign,
    LOWER("DEVICE_CATEGORY") as device_category,
    LOWER("HOSTNAME") as host_name,
    CASE WHEN EXTRACT(YEAR FROM TO_DATE("DATE", 'YYYYMMDD')) = 2023 AND EXTRACT(MONTH FROM TO_DATE("DATE", 'YYYYMMDD')) IN (2, 3, 4, 5, 6, 7) AND LOWER("LANDING_PAGE") = '' THEN '/' ELSE LOWER("LANDING_PAGE") END AS landing_page_path,
    LOWER("SESSION_AD_CONTENT") as session_manual_ad_content,
    LOWER("USER_TYPE") as user_type,
    CASE WHEN "REVENUE" = '' THEN 0 ELSE CAST("REVENUE" AS FLOAT) END as transaction_revenue,
    "EVENT_SOURCE" as event_source,
    CONCAT("BRAND", ' ', "TRANSACTION_ID") as brand_order_id,
FROM PROD.GA4_REPORTING.GA4_SESSION_TRANSACTIONS
);