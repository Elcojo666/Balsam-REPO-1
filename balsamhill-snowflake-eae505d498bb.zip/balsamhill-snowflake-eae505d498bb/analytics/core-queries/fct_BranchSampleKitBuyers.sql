USE DATABASE prod;
CREATE OR REPLACE VIEW analytics.fct_BranchSampleKitBuyers AS (
SELECT
    o.order_id    
    , o.brand
    , o.channel
    , o.current_order_status AS order_status
    , lower(c.email) AS email
    , INITCAP(c.ship_first_name) AS ship_first_name
    , INITCAP(c.ship_last_name) AS ship_last_name
    , c.ship_company_name
    , INITCAP(c.ship_address1) AS ship_address1
    , INITCAP(c.ship_address2) AS ship_address2
    , INITCAP(c.ship_city) AS ship_city
    , c.ship_state 
    , c.ship_postal_code AS ship_postal
    , c.ship_country     
    , o.sku 
    , o.order_product_name AS product_name
    , o.ordered_quantity_initial AS quantity
    , o.order_date_pt
FROM analytics.core_OrderLines o 
    JOIN analytics.core_CustomerInformation c ON o.order_header_key = c.order_header_key
WHERE sku IN ('2808339','4120263','2808338','2808338','2808338','2805283','2810463','2808339','2810597')
);