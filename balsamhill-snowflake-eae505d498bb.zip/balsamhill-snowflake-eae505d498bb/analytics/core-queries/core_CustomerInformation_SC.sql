use database prod;

create or replace view analytics.core_CustomerInformation AS (
    SELECT 
        p.cuid
        , o.source_order_id AS order_header_key
        , p.email AS email
        , b.first_name AS billing_first_name
        , b.last_name AS billing_last_name
        , b.phone AS billing_phone_number
        , b.company_name AS billing_company_name
        , b.address1 AS billing_address1
        , b.address2 AS billing_address2
        , b.city AS billing_city
        , b.state_code AS billing_state
        , b.zip AS billing_postal_code
        , b.country AS billing_country
        , p.first_name AS ship_first_name
        , p.last_name AS ship_last_name
        , p.phone AS ship_phone_number
        , p.shipping_address_company AS ship_company_name
        , p.shipping_address_address1 AS ship_address1
        , p.shipping_address_address2 AS ship_address2
        , p.shipping_address_city AS ship_city
        , p.shipping_address_state_code AS ship_state 
        , p.shipping_address_zip AS ship_postal_code
        , p.shipping_address_country AS ship_country
    FROM balsam_priv_data.priv.sc_customer_billing_addresses b
        JOIN balsam_priv_data.priv.sc_customer_pii p ON b.cuid = p.cuid    
        JOIN balsam_sc_data.direct_access.sc_orders o ON o.cuid = p.cuid -- AND o.scid = p.scid -- will need SC to surface scid in p first
    -- WHERE p.is_latest -- limit to the lastest record in sc_customer_pii for each cuid
);