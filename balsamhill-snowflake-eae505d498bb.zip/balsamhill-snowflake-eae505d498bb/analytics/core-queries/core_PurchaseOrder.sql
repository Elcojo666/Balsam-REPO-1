USE DATABASE prod;

CREATE OR REPLACE VIEW analytics.core_PurchaseOrder AS (

SELECT d.po_number
        , d.skuproductcode AS d_sku
        , d.description AS d_description
        , d.master_upccode AS d_master_upc
        , d.ordered_quantity AS d_ordered_quantity
        , d.received_quantity AS d_received_quantity
        , d.initial_unit_price AS d_initial_unit_price
        , d.total_spend AS d_total_spend
        , d.DiscrepancyReason AS d_discrepancy_reason
        , h.season_name AS h_season_name
        , h.etd_shipping_start AS h_etd_shipping_start
        , h.etd_shipping_end AS h_etd_shipping_end
        , b.BrandCode AS d_brand
        , w.warehouse_name AS h_receiving_warehouse
        , p.port_name AS h_port_name
        , co.country_desc AS h_origin_country
        , su.supplier_name AS h_supplier_name
        , pt.POTypeName AS h_po_type
        , CASE 
            WHEN h.initial_eta IS NOT NULL THEN h.initial_eta 
            WHEN h.initial_eta IS NULL AND co.country_code = 'US' AND cd.country_code = 'US' THEN DATEADD(day, 5, h.etd_shipping_end)
            WHEN h.etd_shipping_end IS NULL THEN NULL
            ELSE DATEADD(day, 45, h.etd_shipping_end)
            END AS h_initial_eta -- calculation logic for initial_eta as defined by Aaeon Monminie        
    FROM analytics.txn_po_detail d
        LEFT JOIN analytics.txn_po_header h ON d.fk_po_headerid = h.pk_po_headerid 
        LEFT JOIN master.dim_po_brand b ON d.fk_brandid = b.Id -- to get BrandCode
        LEFT JOIN master.dim_warehouse w ON h.fk_destination_warehouseid = w.pk_warehouseid -- to get h_receiving_warehouse
        LEFT JOIN master.dim_port p ON h.fk_portid = p.pk_portid -- to get h_port_name
        LEFT JOIN master.dim_country co ON h.fk_origin_countryid = co.pk_countryid -- to get h_origin_country
        LEFT JOIN master.dim_country cd ON h.fk_destination_countryid = cd.pk_countryid -- to get h_origin_country
        LEFT JOIN master.dim_supplier su ON h.fk_supplierid = su.pk_supplierid -- to get h_supplier_name
        LEFT JOIN master.dim_po_type pt ON h.fk_po_typeid = pt.ID -- to get po type
        LEFT JOIN master.dim_po_status st ON h.fk_po_statusid = st.pk_po_statusid -- to get po status
        -- use LEFT JOIN instead of JOIN to ensure that records will still be pulled even if there are null values for warehouseid, portid, origin_countrid, and supplierid (edited 2023-Aug-24)   
    WHERE st.po_status_name <> 'Cancelled' -- filter out cancelled POs 240927
        AND h.season_name NOT IN ('2018', '2019', '2020') -- limit to the past four FYs and current FY
    QUALIFY DENSE_RANK() OVER(PARTITION BY d.po_number ORDER BY d.fk_po_headerid DESC ) = 1 -- assign rank to each PO in descending order based on po_headerid (necessary for cases wherein the PO is registered more than once in POD)
        AND DENSE_RANK() OVER(PARTITION BY d.po_number, d.skuproductcode ORDER BY d.pk_po_detailid DESC) = 1 -- assign rank to each sku in a po based on id (necessary for cases wherein the sku is registered more than once in a PO)
);