use database Dev; 


CREATE  TABLE if not exists  analytics.map_order_line_coupon_codes (
    order_detailid BIGINT NOT NULL,
    discount_code VARCHAR(255),
    discount_name VARCHAR(1000),
    coupon_code VARCHAR(50) NOT NULL,
    discount_amount DECIMAL(9, 2)
);

CREATE VIEW if not exists analytics.core_OrderDiscounts_min AS

/*
Documentation: https://confluence.balsambrands.com/x/2EdEBQ
Author: Fay Tan
Create Date: 2022-04-25 <yyyy-mm-dd> 
Description: Getting order discounts in first revision
*/


WITH CTE_ID AS
(
SELECT *
FROM (
    SELECT DISTINCT
        AOH.source_ref_num 
        ,pk_order_headerid
        ,AOH.fk_sourceid
        ,CASE
            WHEN AOH.fk_sourceid IN (11,13,14,15,16) THEN AOH.net_amount --Hybris
            WHEN AOH.fk_sourceid IN (26,34,36,35,27) AND AOH.source_ref_num NOT LIKE 'Y%' THEN AOH.net_amount --Amazon orders pre TSU
            ELSE AOD.product_price * AOD.quantity --Amazon and Retails post TSU
            END AS TotalPaymentReceived 
        ,CASE
            WHEN AOH.order_date < '2023-06-13 07:00:00' THEN AOH.order_date     --PRE TSU
            ELSE CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', AOH.order_date)
            END AS order_date --POST TSU
    FROM analytics.audit_order_header AOH 
        LEFT JOIN analytics.audit_order_detail AOD ON AOH.pk_order_headerid = AOD.fk_order_headerid
        LEFT JOIN analytics.txn_order_status TOS ON AOH.Source_Ref_Num = TOS.Source_Ref_Num AND AOH.fk_sourceid = TOS.fk_sourceid
        LEFT JOIN analytics.sku_product_locale SKU ON SKU.pk_skuproductid = AOD.fk_skuproductid
    WHERE 
        AOH.fk_sourceid IN (
            11  --BHUS Hybris        
            ,26 --BHUS Amazon            
            ,13 --BHUK Hybris     
            ,34 --BHUK Amazon
            ,14 --BHFR Hybris     
            ,7  --BHFR Volusion   
            ,35 --BHFR Amazon 
            ,15 --BHDE Hybris     
            ,8  --BHDE Volusion
            ,36 --BHDE Amazon
            ,16 --BHAU Hybris     
            ,10 --BHAU Volusion  
            ,2  --Treetopia Volusion     
            ,27 --Treetopia Amazon
            ,38 --NordstromDSCO
            ,41 --WilliamSonomaEDI
            ,43 --PotteryBarnEDI
            ,50 --NordstromRackDSCO         
        )
        AND AOH.source_ref_num NOT LIKE 'R%' --Returns
        AND AOH.source_ref_num NOT LIKE 'W%' --Warranty
        AND AOH.source_ref_num NOT LIKE 'P%' --UAT Test orders
        AND (AOH.Revision = 1 OR AOH.Revision IS NULL) --1 for initial revision. NULL to capture Amazon orders
        AND (SKU.sku_code NOT LIKE '%TEST%')--remove Test Orders which can be determined through Test Skus
        AND (AOD.Revision = 1 OR AOD.Revision IS NULL) --1 for initial revision. NULL to capture Amazon orders
        AND (TOS.fk_order_statusid NOT IN ( --invalid Order Status
                2   -- PAYMENT_CAPTURED
                ,3  -- CANCELLED
                ,13 -- CANCELED
                ,20 -- ERROR
                ,21 -- DONOTPROCESS
                ,27 -- CANCELLING
                ,28 -- CANCELLLING
                ,29 -- PAYMENT_NOT_CAPTURED
                ,30 -- PAYMENT_AUTHORIZED
                ,31 -- REMORSE
                ,32 -- Deleted
                ,33 -- CHECKED_INVALID
        )
        OR TOS.fk_order_statusid IS NULL) --NULL to capture Amazon orders
        AND AOH.email_address NOT IN ( --QA email address
            'RPEREZ@BALSAMBRANDS.COM'
            ,'LYSSATEST16@GMAIL.COM'
            ,'axel.jach@argosmultilingual.com'
            ,'qidwai.suhaib@gmail.com'
            ,'qa@balsambrands.com'
            ,'ldienes@stanfordalumni.org'
            ,'mandy.dimiero@gmail.com'
            ,'kpenalba@balsambrands.com'
        )
) T
WHERE TotalPaymentReceived > 0 --remove $0 orders, can only apply here since TotalPaymentReceived vary Post TSU and per Platform
),

CTE_DiscountInfo AS (
--ORDER LEVEL DISCOUNTS
SELECT DISTINCT
    ID.order_date
    ,ID.pk_order_headerid
	,ID.fk_sourceid
    ,OD.discount_code AS DiscountCode
    ,OD.discount_name AS DiscountName
    ,OD.coupon_code AS CouponCode
    ,'Order' AS DiscountLevel
	,ABS(OD.discount_amount) AS DiscountAmount
FROM CTE_ID ID
    JOIN analytics.audit_order_discount OD ON OD.fk_order_headerid = ID.pk_order_headerid
WHERE
    OD.discount_code NOT IN
    (
        'TEST', 
        'DSC-(test)',
        'DSC-CC',
        'DSC-CCC',
        'DSC-Corp'
        ,'TKTestBuyXGetY'
    )
    AND OD.Revision = 1

UNION 

--LINE LEVEL DISCOUNTS

SELECT 
    ID.order_date
    ,ID.pk_order_headerid
    ,ID.fk_sourceid
	,ODD.discount_code AS DiscountCode
    ,ODD.discount_name AS DiscountName
    ,coalesce(ODD.coupon_code,OLC.coupon_code) AS CouponCode
    ,'Line' AS DiscountLevel
	,ABS(SUM(ODD.discount_amount)) AS DiscountAmount
FROM CTE_ID ID
    JOIN analytics.audit_order_detail AOD ON ID.pk_order_headerid = AOD.fk_order_headerid
    JOIN analytics.audit_order_detail_discount ODD ON ODD.fk_order_detailid = AOD.pk_order_detailid
    LEFT JOIN analytics.map_order_line_coupon_codes OLC ON AOD.pk_order_detailid = OLC.order_detailid
WHERE
   ODD.discount_code NOT IN 
    (
        'TEST', 
        'DSC-(test)',
        'DSC-CC',
        'DSC-CCC',
        'DSC-Corp'
        ,'TKTestBuyXGetY'
        )
    AND ODD.Revision = 1
    AND AOD.Revision = 1
    
GROUP BY 
    ID.order_date
    ,ID.pk_order_headerid
    ,ID.fk_sourceid
	,ODD.discount_code
    ,ODD.discount_name
    ,ODD.coupon_code
    ,OLC.coupon_code
)

SELECT DISTINCT
    DI.pk_order_headerid
    ,DB.BrandCodeForPOTracker AS Brand
    ,DP.platform_name AS Platform
    ,AOH.source_ref_num AS OrderID
    ,DI.order_date AS OrderDate
    ,DI.DiscountCode
    ,DI.DiscountName
    ,DI.CouponCode
    ,DI.DiscountAmount
    ,DI.DiscountLevel
    ,DC.currency_code AS Currency 
    ,CASE
        WHEN DC.currency_code = 'GBP' THEN ER.GBP_to_USD
        WHEN DC.currency_code = 'EUR' THEN ER.EUR_to_USD
        WHEN DC.currency_code = 'AUD' THEN ER.AUD_to_USD
        ELSE 1 END AS ForexRate
FROM CTE_DiscountInfo DI
    JOIN analytics.audit_order_header AOH ON DI.pk_order_headerid = AOH.pk_order_headerid
    LEFT JOIN master.dim_currency DC ON AOH.fk_currencyid = DC.pk_currencyid
    JOIN master.dim_source DS ON AOH.fk_sourceid = DS.pk_sourceid
    JOIN master.dim_brand DB ON DS.fk_brandid = DB.pk_brandid
    JOIN master.dim_platform DP ON DS.fk_platformid = DP.pk_platformid
    LEFT JOIN analytics.exchange_rate ER ON CAST(ER.PublishDate AS DATE) = CAST(AOH.order_date AS DATE)

WHERE 
    AOH.Revision = 1 OR AOH.Revision IS NULL
;