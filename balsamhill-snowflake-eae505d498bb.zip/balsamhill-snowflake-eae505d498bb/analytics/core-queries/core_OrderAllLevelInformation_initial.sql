
USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_OrderAllLevelInformation_initial AS (
WITH
CTE_AllLevel AS
(
--Header
SELECT 
    order_header_key
    ,total_payment_received_initial
    ,total_shipping_payment_initial
    ,total_tax_initial
    ,total_ordered_quantity_initial
    ,'' AS sku
    ,'' AS order_product_name
    ,0 AS ordered_quantity_initial
    ,0 AS product_price
    ,'' AS discount_code
    ,'' AS discount_name
    ,0 AS discount_amount
    ,'header' AS order_level
FROM analytics.core_OrderHeader
WHERE order_date_pt >= '2022-02-01'

UNION
--Line
SELECT 
    order_header_key
    ,0 AS total_payment_received_initial
    ,0 AS total_shipping_payment_initial
    ,0 AS total_tax_initial
    ,0 AS total_ordered_quantity_initial
    ,sku
    ,order_product_name
    ,ordered_quantity_initial
    ,product_price
    ,'' AS discount_code
    ,'' AS discount_name
    ,0 AS discount_amount
    ,'line' AS order_level
FROM analytics.core_OrderLines
WHERE order_date_pt >= '2022-02-01'

UNION
--Discount
SELECT 
    order_header_key
    ,0 AS total_payment_received_initial
    ,0 AS total_shipping_payment_initial
    ,0 AS total_tax_initial
    ,0 AS total_ordered_quantity_initial
    ,'' AS sku
    ,'' AS order_product_name
    ,0 AS ordered_quantity_initial
    ,0 AS product_price
    ,discount_code
    ,discount_name
    ,SUM(discount_amount) discount_amount
    ,'discount' AS order_level
FROM analytics.core_OrderDiscounts
WHERE order_date_pt >= '2022-02-01'
group by all
)


SELECT 
    O.order_header_key
    ,brand
    ,channel
    ,order_id
    ,CAST(order_date_pt AS DATE) AS order_date_pt
    ,current_order_status
    ,currency
    ,currency_conversion_rate
    ,payment_method
    ,A.total_payment_received_initial
    ,A.total_shipping_payment_initial
    ,A.total_tax_initial
    ,A.total_ordered_quantity_initial
    ,A.sku
    ,A.order_product_name
    ,A.ordered_quantity_initial
    ,A.product_price
    ,A.discount_code
    ,A.discount_name
    ,A.discount_amount
    ,A.order_level
FROM analytics.core_OrderHeader O 
LEFT JOIN CTE_AllLevel A ON O.order_header_key = A.order_header_key
WHERE order_date_pt >= '2022-02-01'
);