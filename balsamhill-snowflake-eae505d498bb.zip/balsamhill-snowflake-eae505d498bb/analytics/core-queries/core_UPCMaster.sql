USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_UPCMaster AS (

WITH CTE_InvalidUPC AS
(    
SELECT InvalidUPC
FROM (VALUES 
        ('CABLE'), 
        ('P-TRANS-CABLE16'),
        ('RETURNS-DPD'),
        ('3-PLUG JUNCTION CORD'),
        ('TREE BAG LARGE'),
        ('TREE BAG SMALL'),
        ('QA'),
        ('UNKNOWN'),
        ('Case_500_BAL04'),
        ('Note_CMA'),
        ('RTP_BALLOGOTAPE'),
        ('RTP_DECOR_PALLET'),
        ('RTP_FLIP_PALLET'),
        ('RTP_TT_PALLET'),
        ('RTP_BALLOGOTAPE'),
        ('outlet_decor'),
        ('outlet_flip'),
        ('outlet_mddecor'),
        ('outlet_trees'),
        ('RTP_FLIP_PALLET'),
        ('RTP_TT_PALLET')
            
) AS t(InvalidUPC)    
)


select 
upc_code as upc
,M.PK_MAP_SKU_UPCID AS sku
,upc_year
,UPC.upc_type
,inner_upc
,cartonnumber as carton_number
,totalcartons as total_cartons
,is_masterpack
,is_rtp
,length
,width
,height
,lotcode as lot_code
,CASE
    WHEN I.InvalidUPC IS NOT NULL THEN 'no'
    WHEN upc_code ILIKE '%Balsam Packing Box%' THEN 'no'
    WHEN upc_code ILIKE '%label%' THEN 'no'
    WHEN upc_code ILIKE '%ADAPTER%' THEN 'no'
    WHEN upc_code ILIKE '%_U' THEN 'no'
    ELSE 'yes'
    END AS valid_UPC
from analytics.upc UPC
LEFT JOIN CTE_InvalidUPC I ON UPC.UPC_CODE = I.InvalidUPC
LEFT JOIN analytics.map_sku_upc M ON UPC.PK_UPCID = M.FK_UPCID
);