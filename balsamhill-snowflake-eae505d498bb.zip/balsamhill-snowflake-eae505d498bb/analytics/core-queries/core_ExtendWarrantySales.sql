use database prod;

CREATE OR REPLACE VIEW analytics.core_ExtendWarrantySales AS 

(

WITH WarrantySales AS (
SELECT
    o.scope    
    , order_type
    , o.source_order_id
    , o.order_id
    , o.order_date  
    , COALESCE(
        f.value:ChildLine['@OrderLineKey']::STRING,        
        o.properties:OrderLineRelationship.ChildLine['@OrderLineKey']::STRING        
        ) AS ExtendPurchased
    , COALESCE(
        f.value:ParentLine['@OrderLineKey']::STRING,        
        o.properties:OrderLineRelationship.ParentLine['@OrderLineKey']::STRING
        ) AS WarrantedItem
FROM balsam_sc_data.direct_access.sc_orders o
LEFT JOIN LATERAL FLATTEN(input => CASE 
        WHEN IS_ARRAY(o.properties:OrderLineRelationship) THEN o.properties:OrderLineRelationship
        ELSE [o.properties:OrderLineRelationship]
        END) f
WHERE 1=1 
AND
    COALESCE(
        f.value:ParentLine['@OrderLineKey'],
        o.properties:OrderLineRelationship.ParentLine['@OrderLineKey']
    ) IS NOT NULL -- these COALESCE statements are necessary because OrderLineRelationships are stored as arrays in some cases, and objects in other cases
)

SELECT xWS.scope AS Brand    
    , xWS.order_type
    , xWS.order_id
    , xWS.source_order_id AS Order_Header_Key
    , xWS.order_date AS order_date_Pacific
    , i1.sku AS Extend_Purchased
    , i1.quantity AS Extend_Purchased_Qty
    , i1.price * 0.40 AS Extend_Purchased_Unit_Price
    , i1.item_canceled AS Extend_Canceled
    , i2.sku AS Warranted_Item
    , i2.quantity AS Warranted_Item_Qty
    , i2.price AS Warranted_Item_Unit_price
    , i2.item_canceled AS Warranted_Item_Canceled  
FROM WarrantySales xWS 
JOIN balsam_sc_data.direct_access.sc_items i1
    ON (xWS.order_id = i1.order_id AND xWS.ExtendPurchased = i1.source_line_item_id)
JOIN balsam_sc_data.direct_access.sc_items i2
    ON (xWS.order_id = i2.order_id AND xWS.WarrantedItem = i2.source_line_item_id)
);