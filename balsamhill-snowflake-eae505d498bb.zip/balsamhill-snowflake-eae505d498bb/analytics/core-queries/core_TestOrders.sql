USE DATABASE prod;

CREATE OR REPLACE VIEW analytics.core_TestOrders AS (

SELECT o.order_header_key, o.source_ref_num AS order_id--, o.order_date, o.email_address, a.last_name
FROM analytics.txn_order_header o 
    JOIN analytics.txn_address a ON o.fk_shipping_addressid = a.pk_addressid
WHERE (o.order_date >= '2020-01-01' -- limit data to recent four years
        AND o.order_header_key IS NOT NULL) -- limit data to post-TSU orders and migrated orders
    AND (o.source_ref_num LIKE 'P%'
        OR POSITION('balsambrands' IN SUBSTRING(o.email_address, 1, POSITION('@' IN o.email_address) - 1)) > 0 -- 'balsambrands' is in email username (not domain)
        OR LOWER(o.email_address) = 'bbqa.kara@gmail.com' -- specific email address used by qa team
        OR LOWER(o.email_address) LIKE 'test%@signifyd.com' -- email addresses used by qa team
        OR UPPER(a.last_name) LIKE '%TEST%ORDER%' -- last_name contains the word 'test' and 'order'
        )
);