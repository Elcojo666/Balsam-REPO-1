USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_CanceledOrders AS (
    
SELECT
     CASE
        WHEN o.order_type ILIKE 'TREECLASSICS' THEN 'TCUS'
        WHEN o.order_type ILIKE 'TREETOPIA' THEN 'TTUS'
        ELSE UPPER(o.scope) END AS Brand
    , CASE
        WHEN o.order_type ILIKE 'ASM' THEN 'HYBRIS'
        WHEN o.CHANNEL ILIKE '%AMAZON' THEN 'AMAZON'
        WHEN o.CHANNEL ILIKE '%VOLUSION%' THEN 'VOLUSION'
        ELSE o.order_type END AS channel
    , o.order_id
    , o.order_date AS order_date_PT
    , CAST(CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', o.cancelled_at) AS DATE) AS canceled_date_PT
    , o.canceled_reason
    , CASE 
        WHEN i.canceled THEN 'full'
        ELSE 'partial'
        END AS cancel_type
    , LISTAGG (sku, ', ') WITHIN GROUP (ORDER BY sku) AS cancel_sku
FROM balsam_sc_data.direct_access.sc_orders o
    JOIN balsam_sc_data.direct_access.sc_items i on o.scid = i.scid
WHERE i.item_canceled -- limit results to canceled orders only
    AND o.order_id NOT LIKE 'P%' -- filter out test orders    
    AND sku NOT LIKE '%^_%' ESCAPE '^' -- filter out all Skus with an underscore    
GROUP BY ALL
);