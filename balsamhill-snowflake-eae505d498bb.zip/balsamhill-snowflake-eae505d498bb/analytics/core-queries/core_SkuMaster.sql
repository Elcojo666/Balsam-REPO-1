USE DATABASE prod;

CREATE OR REPLACE VIEW analytics.core_SkuMaster AS (

SELECT
    Brand
    , CONCAT(Brand, Sku) AS Brand_Sku     
    , CASE
        WHEN category1 = category2 AND category2 = category3 THEN category1
        ELSE ARRAY_TO_STRING(ARRAY_COMPACT(ARRAY_CONSTRUCT(category1, category2, category3)),' » ')
        END AS Category_Path
    , attributes:"Channel Approval"::string AS Channel_Approval
    , attributes:"Class"::string AS Class
    , CASE
        WHEN CHARINDEX('&', attributes:"Collection"::string) = 0 THEN attributes:"Collection"::string
        ELSE CASE 
                WHEN CHARINDEX('&', attributes:"Collection"::string, CHARINDEX('&', attributes:"Collection"::string) + 1) > 0 
                    THEN RTRIM(LEFT(attributes:"Collection"::string, CHARINDEX('&', attributes:"Collection"::string, CHARINDEX('&', attributes:"Collection"::string) + 1) - 2))
                WHEN CHARINDEX('&', attributes:"Collection"::string) = LEN(attributes:"Collection"::string) - 1 
                    THEN attributes:"Collection"::string
                ELSE RTRIM(LEFT(attributes:"Collection"::string, CHARINDEX('&', attributes:"Collection"::string) - 2))
                END
        END AS Collection 
    , CASE
        WHEN CHARINDEX('&', attributes:"Color"::string) = 0 THEN attributes:"Color"::string
        ELSE CASE
                WHEN CHARINDEX('&', attributes:"Color"::string, CHARINDEX('&', attributes:"Color"::string) + 1) > 0 
                    THEN RTRIM(LEFT(attributes:"Color"::string, CHARINDEX('&', attributes:"Color"::string, CHARINDEX('&', attributes:"Color"::string) + 1) - 2))
                WHEN CHARINDEX('&', attributes:"Color"::string) = LEN(attributes:"Color"::string) - 1 
                    THEN attributes:"Color"::string
                ELSE RTRIM(LEFT(attributes:"Color"::string,CHARINDEX('&', attributes:"Color"::string) - 2))
                END
        END AS Color
    , attributes:"Department"::string AS Department
    , attributes:"Display Product on Site Even if Out of Stock"::string AS DisplayEIOOS
    , COALESCE(attributes:"Drop Ship"::string, 'No') AS Dropshipped -- to default nulls to No
    , attributes:"Entity Type"::string AS Entity
    , CASE 
        WHEN attributes:"Subdepartment"::string in ('Christmas Trees', 'Potted Trees', 'Tabletop Christmas Trees')
            OR attributes:"Class"::string in ('Flower Stems', 'Planters') 
            THEN LEFT(attributes:"Height"::string,LEN(attributes:"Height"::string) - 3)
        WHEN attributes:"Subdepartment"::string in ('Fall Foliage', 'Autumn Foliage')
            OR attributes:"Class"::string in ('Hanging Baskets', 'Window Boxes', 'Halloween Decor', 'Candle Holders') 
            THEN LEFT(attributes:"Width"::string,LEN(attributes:"Width"::string) - 3)
        WHEN attributes:"Class"::string in ('Garlands') 
            THEN LEFT(attributes:"Length"::string,LEN(attributes:"Length"::string) - 3)
        WHEN attributes:"Class"::string in ('Wreaths', 'Tree Skirts') 
            THEN LEFT(attributes:"Diameter"::string,LEN(attributes:"Diameter"::string) - 3)
        ELSE LEFT(attributes:"Height"::string,LEN(attributes:"Height"::string) - 3)
        END AS Exact_Size
    , attributes:"Family"::string AS Family
    , COALESCE(primary_image_url, attributes:"Additional Image Link 2"::string, attributes:"Additional Image Link 3"::string) AS image_url
    , LEFT(attributes:"Decoration Level"::string, CHARINDEX(' &', attributes:"Decoration Level"::string) -1) AS Level_Of_Decoration
    , attributes:"Light Count"::string Light_Count
    , LEFT(attributes:"Light Type"::string, CHARINDEX(' &', attributes:"Light Type"::string) -1) AS Light_Type
    , created_at AS Live_On_Site_Date
    , LEFT(attributes:"Material"::string, CHARINDEX(' &', attributes:"Material"::string) -1) AS Material
    , LEFT(attributes:"Needle Type"::string, CHARINDEX(' &', attributes:"Needle Type"::string) -1) AS Needle_Type
    , updated_at AS Out_Of_Stock_Date
    , attributes:"Parent Code"::string AS Parent_Code
    , CASE
        WHEN supplier ILIKE '%Polygroup%' THEN 'PG'
        ELSE 'D'
        END AS Polygroup_or_Decor
    , COALESCE(REGEXP_REPLACE(title, '[\\r\\n\\t\\f\\v]', ' '), attributes:"Product Name"::string) AS Product_Name
    , attributes:"Channel Status"::string AS Product_Status
    , attributes:"Product Type"::string AS Product_Type
    , CASE
        WHEN attributes:"Realism"::string = 'NA' THEN ''
        ELSE attributes:"Realism"::string
        END AS Realism -- to replace NAs with an empty string
    , CASE
        WHEN CHARINDEX('&', attributes:"Season"::string) > 0 
        THEN LEFT(attributes:"Season"::string, CHARINDEX(' &', attributes:"Season"::string) -1)
        ELSE attributes:"Season"::string
        END AS Season
    , LEFT(attributes:"Tree Setup Type"::string, CHARINDEX(' &', attributes:"Tree Setup Type"::string) -1) AS Setup_Type
    , LEFT(attributes:"Size S/M/L"::string, CHARINDEX(' &', attributes:"Size S/M/L"::string) -1) AS Size_SML
    , attributes:"Display Size Range"::string AS Size_range
    , Sku
    , attributes:"Subdepartment"::string AS SubDepartment 
    , attributes:"Tree Shape"::string AS Tree_Shape
FROM balsam_sc_data.direct_access.sc_products p
WHERE Category1 != 'Test'
GROUP BY ALL
);