USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_OrderBasketMix AS (


WITH CTE_MerchRanking AS (
    SELECT 'Christmas Trees' AS Department, 'Christmas Trees' AS SubDepartment, 1 AS Rank
    UNION ALL SELECT 'Christmas Trees', 'Potted Trees', 2
    UNION ALL SELECT 'Christmas Trees', 'Tabletop Christmas Trees', 3
    UNION ALL SELECT 'Christmas Trees', 'Branch Sample Kit', 4
    UNION ALL SELECT 'Christmas Trees', '<uncategorized>', 4.5
    UNION ALL SELECT 'Holiday Greenery', 'Holiday Greenery', 5
    UNION ALL SELECT 'Holiday Greenery', '<uncategorized>', 5.5
    UNION ALL SELECT 'Christmas Decorations', 'Candles and Scents', 6
    UNION ALL SELECT 'Christmas Decorations', 'Holiday Decor', 7
    UNION ALL SELECT 'Christmas Decorations', 'Holiday Lights', 8
    UNION ALL SELECT 'Christmas Decorations', 'Ornaments', 9
    UNION ALL SELECT 'Christmas Decorations', 'Outdoor Decor and Accessories', 10
    UNION ALL SELECT 'Christmas Decorations', 'Stockings Tree Skirts and Tree Collars', 11
    UNION ALL SELECT 'Christmas Decorations', 'Storage and Hardware', 12
    UNION ALL SELECT 'Christmas Decorations', 'Trim', 13
    UNION ALL SELECT 'Christmas Decorations', '<uncategorized>', 13.5
    UNION ALL SELECT 'Home Decor Hearth', 'and Fire', 14
    UNION ALL SELECT 'Home Decor', 'Pillows and Throws', 15
    UNION ALL SELECT 'Home Decor', 'Planters and Vessels', 16
    UNION ALL SELECT 'Home Decor', 'Tabletop and Entertaining', 17
    UNION ALL SELECT 'Home Decor', '<uncategorized>', 17.5
    UNION ALL SELECT 'Spring', 'Faux Florals and Plants', 18
    UNION ALL SELECT 'Spring', 'Spring Decor', 19
    UNION ALL SELECT 'Spring', '<uncategorized>', 19.5
    UNION ALL SELECT 'Fall', 'Fall Decor', 20
    UNION ALL SELECT 'Fall', 'Fall Foliage', 21
    UNION ALL SELECT 'Fall', '<uncategorized>', 21.5
    UNION ALL SELECT '<uncategorized>', '<uncategorized>', 999
),

CTE_OrderDetails AS
(
SELECT 
    O.order_header_key,
    O.BRAND,
    O.ORDER_ID,
    O.ORDER_DATE_PT,
    O.SKU,
    O.ORDERED_QUANTITY_INITIAL AS ORDERED_QUANTITY,
    CONCAT(COALESCE(O.SKU, ''), ' (', IFNULL(SM.Product_Name, ''), ')') AS sku_with_product_name,
    CASE 
        WHEN SM.parent_Code IS NULL OR SM.parent_Code = '' THEN '' 
        ELSE SM.parent_Code 
    END AS parent_code,
    CASE 
        WHEN SM.parent_Code IS NULL OR SM.parent_Code = '' THEN NULL 
        ELSE CONCAT(SM.parent_Code, ' (', SM.family, ')') 
    END AS parent_code_with_name,
    COALESCE(SM.Department, '<uncategorized>') AS Department,
    COALESCE(SM.subDepartment, '<uncategorized>') AS subDepartment,
    COALESCE(SM.Class, '<uncategorized>') AS Class
FROM core_orderlines O
JOIN core_skumaster SM 
    ON O.BRAND = SM.BRAND 
    AND O.SKU = SM.SKU
WHERE
    O.ORDER_DATE_PT >= '2024-02-01'
    AND O.channel IN ('HYBRIS','AMAZON')
    AND O.order_product_name NOT LIKE 'Extend Warranty%'
),

CTE_skumix AS
(
SELECT
    order_header_key,
    LISTAGG(sku, ' + ') AS sku_mix,
    LISTAGG(sku_with_product_name, ' + ') AS sku_with_product_name_mix
FROM (
    SELECT DISTINCT 
        order_header_key, 
        sku, 
        sku_with_product_name 
    FROM CTE_OrderDetails
) T
GROUP BY order_header_key
),

CTE_parmix AS
(
SELECT
    order_header_key,
    LISTAGG(parent_code, ' + ') AS parent_mix,
    LISTAGG(parent_code_with_name, ' + ') AS parent_code_with_product_name_mix
FROM (
    SELECT DISTINCT 
        order_header_key, 
        parent_code, 
        parent_code_with_name 
    FROM CTE_OrderDetails
) T
GROUP BY order_header_key
),

CTE_deptmix AS
(
SELECT
    order_header_key,
    LISTAGG(department, ' + ') WITHIN GROUP (ORDER BY deptRanking) AS departmentMix
FROM (
    SELECT DISTINCT 
        order_header_key, 
        O.department, 
        MIN(rank) AS deptRanking
    FROM CTE_OrderDetails O
    LEFT JOIN CTE_MerchRanking M ON O.Department = M.Department
    GROUP BY order_header_key, O.department
) T
GROUP BY order_header_key
),

CTE_subdeptmix AS
(
SELECT
    order_header_key,
    LISTAGG(subdepartment, ' + ') WITHIN GROUP (ORDER BY subdeptRanking) AS subdepartmentMix
FROM (
    SELECT DISTINCT 
        order_header_key, 
        O.subdepartment, 
        MIN(rank) AS subdeptRanking
    FROM CTE_OrderDetails O
    LEFT JOIN CTE_MerchRanking M ON O.subdepartment = M.subdepartment
    GROUP BY order_header_key, O.subdepartment
) T
GROUP BY order_header_key
),

CTE_classmix AS
(
SELECT
    order_header_key,
    LISTAGG(class, ' + ') WITHIN GROUP (ORDER BY CLASS) AS classMix
FROM (
    SELECT DISTINCT 
        order_header_key, 
        O.class
    FROM CTE_OrderDetails O
) T
GROUP BY order_header_key
),

CTE_samefamily AS
(
SELECT DISTINCT
order_header_key
FROM
(
SELECT
    order_header_key
    ,parent_code
    ,CASE WHEN COUNT(Sku) > 1 THEN 'Y' ELSE 'N' END AS same
    FROM CTE_OrderDetails
    GROUP BY ALL
) T
WHERE same = 'Y'
)

--MAIN
SELECT
    O.Brand
    ,o.order_id
    , o.order_date_pt
    , a.sku_Mix
    , a.sku_with_product_name_mix
    , b.parent_mix
    , b.parent_code_with_product_name_mix
    , e.departmentMix
    , f.subDepartmentMix
    , g.classMix
    , CASE WHEN s.order_header_key is null THEN 'N' ELSE 'Y' END as sameFamily
    , COUNT(o.SKU) as skuCount
    , SUM(o.ORDERED_QUANTITY) as ORDERED_QUANTITY
FROM cte_orderdetails o
JOIN cte_skumix a ON o.order_header_key = a.order_header_key
LEFT JOIN cte_parmix b ON o.order_header_key = b.order_header_key
LEFT JOIN cte_deptmix e ON o.order_header_key = e.order_header_key
LEFT JOIN cte_subDeptMix f ON o.order_header_key = f.order_header_key
LEFT JOIN cte_classMix g ON o.order_header_key = g.order_header_key
LEFT JOIN cte_sameFamily s ON o.order_header_key = s.order_header_key
GROUP BY ALL
ORDER BY skuCount DESC
);