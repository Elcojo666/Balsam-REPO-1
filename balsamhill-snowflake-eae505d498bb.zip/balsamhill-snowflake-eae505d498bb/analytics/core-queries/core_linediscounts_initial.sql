CREATE OR REPLACE VIEW analytics.core_linediscounts_initial AS (
WITH CTE_ID AS
(
SELECT DISTINCT 
    id.*
    ,source_line_item_id as order_line_key
FROM analytics.core_orderids_initial id
join balsam_sc_data.direct_access.sc_items  i on id.order_header_key = i.source_order_id
),

CTE_DiscountInfo AS (
--LINE LEVEL DISCOUNTS
--preTSU
SELECT 
    od.order_line_key
	,ODD.discount_code 
    ,ODD.discount_name 
    ,COALESCE(ODD.coupon_code,OLC.coupon_code) AS promo_code
	,SUM(ABS(ODD.discount_amount)) AS line_discounts_initial
FROM CTE_ID ID
    JOIN analytics.audit_order_detail OD ON ID.order_line_key = OD.order_line_key
    JOIN analytics.audit_order_detail_discount ODD ON ODD.fk_order_detailid = OD.pk_order_detailid
    LEFT JOIN analytics.map_order_line_coupon_codes OLC ON OD.pk_order_detailid = OLC.order_detailid --postTSU coupons backfill
WHERE
   ODD.discount_code NOT IN 
    (
        'TEST', 
        'DSC-(test)',
        'DSC-CC',
        'DSC-CCC',
        'DSC-Corp'
        ,'TKTestBuyXGetY'
        )
    AND ODD.Revision = 1
    AND OD.Revision = 1
    AND ID.order_date_pt < '2023-06-13'
    AND ABS(ODD.discount_amount) > 0
    
GROUP BY 
    od.order_line_key
	,ODD.discount_code
    ,ODD.discount_name
    ,ODD.coupon_code
    ,OLC.coupon_code

UNION

--postTSU
SELECT 
    od.order_line_key
    ,ODD.discount_name 
    ,ODD.discount_code 
    ,COALESCE(ODD.coupon_code,OLC.coupon_code) AS promo_code
	,SUM(ABS(ODD.discount_amount)) AS DiscountAmount
FROM CTE_ID ID
    JOIN analytics.audit_order_detail OD ON ID.order_line_key = OD.order_line_key
    JOIN analytics.audit_order_detail_discount ODD ON ODD.fk_order_detailid = OD.pk_order_detailid
    LEFT JOIN analytics.map_order_line_coupon_codes OLC ON OD.pk_order_detailid = OLC.order_detailid --postTSU coupons backfill
WHERE
   ODD.discount_code NOT IN 
    (
        'TEST', 
        'DSC-(test)',
        'DSC-CC',
        'DSC-CCC',
        'DSC-Corp'
        ,'TKTestBuyXGetY'
        )
    AND ODD.Revision = 1
    AND OD.Revision = 1
    AND ID.order_date_pt >= '2023-06-13'
    AND ABS(ODD.discount_amount) > 0
    
GROUP BY 
    od.order_line_key
	,ODD.discount_code
    ,ODD.discount_name
    ,ODD.coupon_code
    ,OLC.coupon_code
)

SELECT
    id.order_header_key
    ,id.order_line_key
    ,id.order_id
    ,id.brand
    ,id.channel
    ,id.order_date_pt
    ,id.order_date_local
    ,i.sku
    ,DI.discount_code
    ,DI.discount_name
    ,DI.promo_code
    ,line_discounts_initial
    ,o.currency
    ,o.currency_conversion_rate
FROM CTE_DiscountInfo di
JOIN CTE_ID id on di.order_line_key = id.order_line_key
join balsam_sc_data.direct_access.sc_items i on id.order_line_key = i.source_line_item_id
join balsam_sc_data.direct_access.sc_orders o on id.order_header_key = o.source_order_id
WHERE i.quantity > 0 and i.price > 0
);