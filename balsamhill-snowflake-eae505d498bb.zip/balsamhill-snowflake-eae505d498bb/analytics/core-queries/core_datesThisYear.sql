use database prod;
create or replace view analytics.core_datesThisYear as (
    WITH DateSeries AS (
        SELECT DATEADD(DAY, ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1, DATE_TRUNC('YEAR', CURRENT_DATE) + INTERVAL '1 MONTH') AS Date
        FROM TABLE(GENERATOR(ROWCOUNT => 400))
    )

SELECT 
    Date AS Date_TY
    , DAYNAME(Date) AS Day_Name  -- Mon, Tue, etc.
    , DAY(Date) AS Day_Number  -- 1 through 28/30/31
    , MONTHNAME(Date) AS Month_Name  -- Feb, Mar, etc.
    , MONTH(Date) AS Month_Number  -- 2 for February, 3 for March, etc.
    , YEAR(Date) AS Calendar_Year  -- 2025, 2026, etc.
    , CASE 
        WHEN MONTH(Date) = 1 THEN YEAR(Date) - 1  -- January belongs to previous fiscal year
        ELSE YEAR(Date)  -- Feb–Dec belong to the current fiscal year
        END AS Fiscal_Year 
    , CASE 
        WHEN MONTH(Date) = 1 THEN 12  -- forces January to be last in sorting
        ELSE MONTH(Date) - 1  -- February comes first, then March etc.
        END AS Month_Sort_Order  -- enables easy sorting for fiscal year
FROM DateSeries
WHERE Date BETWEEN DATEADD('YEAR', 0, DATE_TRUNC('YEAR', CURRENT_DATE) + INTERVAL '1 MONTH')
               AND DATEADD('YEAR', 1, DATE_TRUNC('YEAR', CURRENT_DATE) + INTERVAL '1 MONTH' - INTERVAL '1 DAY')
);