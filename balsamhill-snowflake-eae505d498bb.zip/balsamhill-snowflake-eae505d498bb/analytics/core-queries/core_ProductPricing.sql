USE DATABASE prod;

CREATE OR REPLACE VIEW analytics.core_ProductPricing AS (
WITH date_ranges AS (
    SELECT
        c.currency_code
        , p.sku_code
        , p.productprice
        , p.saleprice
        , p.price_start_date
        , p.price_end_date
        , p.inserted_date
        , DATEDIFF(DAY, price_start_date, price_end_date) AS date_diff
     FROM analytics.product_pricing p
        JOIN master.dim_currency c ON p.fk_currencyid = c.pk_currencyid        
    WHERE UPPER(p.sku_code) NOT LIKE '%TEST%' -- filter out test skus
        AND p.productprice IS NOT NULL -- filter out rows without prices;
        AND p.price_start_date >= DATEADD('year', -5, DATEADD('month', 1, DATE_TRUNC('year', CURRENT_DATE)))
)

,flattened_data AS (
    SELECT
        d.currency_code
        , d.sku_code
        , d.productprice
        , d.saleprice
        , d.inserted_date
        , DATEADD(DAY, s.day_offset, d.price_start_date) AS price_date
    FROM date_ranges d
    JOIN LATERAL (
        SELECT SEQ4() AS day_offset
        FROM TABLE(GENERATOR(ROWCOUNT => 1000))  -- as of 250430, MAX(DATEDIFF(DAY, price_start_date, price_end_date)) is 729
        ) s
    WHERE s.day_offset <= d.date_diff
)

SELECT currency_code AS currency 
    , sku_code AS sku
    , CAST(price_date AS DATE) AS price_date
    , productprice AS list_price
    , saleprice AS sale_price 
FROM flattened_data
QUALIFY ROW_NUMBER() OVER (PARTITION BY currency_code, sku_code, price_date ORDER BY inserted_date DESC) = 1
);