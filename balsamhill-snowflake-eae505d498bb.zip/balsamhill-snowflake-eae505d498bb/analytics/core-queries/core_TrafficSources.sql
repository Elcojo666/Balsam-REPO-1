USE DATABASE PROD;


CREATE OR REPLACE VIEW analytics.core_TrafficSources AS (
    
    SELECT DISTINCT
    LOWER("sessionSource") as source
    , LOWER("sessionMedium") as medium
    , CONCAT("sessionSource", ' / ', "sessionMedium") as source_medium
    , LOWER(IFNULL("sessionCampaign", '(not set)')) as campaign
    , LOWER(IFNULL("sessionAdContent", '(not set)')) as ad_content
    , CASE
    -- Organic Social
    WHEN medium IN ('organic_social', 'social', 'social_network', 'social_media')
        OR (source = 'trustpilot' AND medium IN ('categories', 'company_profile', '(not set)'))
        OR (source IN ('admin.yelp.com', 'bize.admin.yelp.com', 'facebook', 'l.facebook.com', 'lm.facebook.com', 'instagram.com',
                        'm.facebook.com', 'facebook.com', 'l.instagram.com', 'l.messenger.com', 'pinterest', 'pinterest.com',
                        't.co', 'm.youtube.com', 'youtube.com', 'tiktok.com') AND medium = 'referral')
    THEN 'Organic Social'

    -- Paid Social
    WHEN medium IN ('paid_social', 'paid_social_network')
        OR (source IN ('facebook', 'fb', 'pinterest', 'social', 'instagram', 'facebook_gateway') AND medium = 'cpc')
        OR (source LIKE '%facebook%' AND medium = 'cpc')
        OR (source LIKE '%cpc%' AND medium = 'facebook')
        OR (source IN ('facebook', 'fb', 'ig', 'tiktok', 'pinterest') AND medium = 'cpm')
        OR (source = 'facebook' AND medium = 'display')
        OR (source = 'googleads.g.doubleclick.net' AND medium = 'referral')
    THEN 'Paid Social'

    -- Programmatic
    WHEN medium IN ('cpm', 'programmatic', 'paid-media')
        OR (source IN ('dfa', 'dbm', 'display', 'hulu') AND medium = 'cpc')
        OR (source = 'dfa' AND medium = '(not set)')
        OR (source = 'pandora' AND medium = 'display')
    THEN 'Programmatic'

    -- Influencers
    WHEN (source IN ('influencer', 'influencers', 'youtube') AND medium = 'organic_content')
        OR (source = 'organic_content' AND medium IN ('bhau_cij2023', 'bhau_ba2023', 'bhau_ui2023', 'influencers'))
    THEN 'Influencers'

    -- Organic Search
    WHEN medium IN ('organic', 'organic_blog', 'organic_content', 'blog')
    THEN 'Organic Search'

    -- PPC
    WHEN (source IN ('(not set)', 'gemini', 'other engines', 'bing', 'google', 'msn', 'youtube') AND medium = 'cpc')
        OR (source = 'google gsp' AND medium = 'display')
    THEN 'PPC'

    -- Affiliates
    WHEN medium LIKE '%affiliate%'
        OR (source LIKE '%shareasale%' AND medium = 'referral')
        OR (source IN ('partnerize', 'shareasale') AND medium = '(not set)')
    THEN 'Affiliates'

    -- Direct
    WHEN source IN ('(direct)', 'bvod')
        OR medium = 'tv'
    THEN 'Direct'

    -- Print
    WHEN (source = 'catalog' AND medium IN ('qr', 'publitas', 'uspsridealong'))
        OR (source IN ('directmail', 'mailer', 'treebook', 'print') AND medium = 'qr')
        OR (source = 'directmail' AND medium = 'uspsridealong')
        OR (source = '(not set)' AND medium = 'publitas')
        OR (source LIKE '%catalog?em-email%' AND medium = 'publitas')
    THEN 'Print'

    -- PR
    WHEN source = 'pr'
        OR medium = 'pr'
        OR (source = 'crown' AND medium = '(not set)')
    THEN 'PR'

    -- Email
    WHEN medium = 'email'
        OR medium LIKE '%bronto%'
        OR source = 'klaviyo'
        OR ((source LIKE '%email%' OR source LIKE '%hy%') AND medium = '(not set)')
    THEN 'Email'

    -- CSE
    WHEN medium = 'cse'
    THEN 'CSE'

    -- Referral Grouping
    WHEN medium = 'referral'
    THEN 'Referral'

    -- Phone
    WHEN medium = 'phone'
    THEN 'Phone'

    -- Amazon
    WHEN medium = 'amazon'
    THEN 'Amazon'

    -- SMS
    WHEN medium = 'sms'
        OR source = 'attentive'
    THEN 'SMS'

    -- (not tracked)
    WHEN medium = '(not tracked)'
    THEN '(not tracked)'

    ELSE 'Unassigned' END as Channel
    FROM PRE_PROD.GA4_REPORTING.GA4_SESSION_TRANSACTIONS
);