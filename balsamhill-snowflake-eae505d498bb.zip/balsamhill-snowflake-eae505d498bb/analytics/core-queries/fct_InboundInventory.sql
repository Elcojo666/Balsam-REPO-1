use database prod;
create or replace view analytics.fct_InboundInventory AS (
    SELECT po.po_number AS d_po_number
        , pl.Invoice_ID AS pl_po_number
        , pl.Bill_Of_Lading AS pl_bill_of_lading
        , pl.Container_Number AS pl_Container_Number
        , po.d_brand AS d_brand
        , po.h_po_type AS po_type
        , po.d_sku AS d_sku
        , pl.sku AS pl_sku
        , pl.upc AS pl_upc
        , pl.carton_number AS pl_carton_number
        , po.d_master_upc AS d_master_upccode
        , COALESCE(pl.product_description, po.d_description) AS d_description 
        , CASE 
            WHEN (wr.date_received IS NULL OR wr.discrepancy_reason = '') THEN po.d_discrepancy_reason
            ELSE wr.discrepancy_reason
            END AS d_discrepancy_reason -- 240927    
        , CASE WHEN pl.carton_number LIKE '%Master%' THEN '' -- 230925
            WHEN (LAG(po.po_number) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = po.po_number
            AND (LAG(po.d_sku) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = po.d_sku        
            AND (((LAG(pl.upc) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = pl.upc AND (LAG(pl.container_number) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) <> pl.container_number) -- same UPCs in diff containers
            OR ((LAG(pl.upc) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = PL.Upc AND (LAG(pl.bill_of_lading) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) <> pl.bill_of_lading) -- different shipments, same container (as in LTLs) // 231204
            OR ((LAG(pl.upc) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) <> PL.Upc AND (LAG(pl.container_number) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = pl.container_number) -- diff UPCs in same container
            OR ((LAG(pl.carton_number) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = pl.carton_number AND (LAG(pl.container_number) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) <> pl.container_number)) -- same cartonnumber, diff containers
            THEN ''
            ELSE TO_VARCHAR(po.d_ordered_quantity)
            END AS d_ordered_quantity -- new formula s.t. ordered_quantity will always be assigned to only one inner pack 230923         
        , CASE WHEN pl.carton_number LIKE '%Master%' THEN '' -- 230925
            WHEN (LAG(po.po_number) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = po.po_number
            AND (LAG(po.d_sku) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = po.d_sku
            AND (((LAG(pl.upc) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = pl.upc AND (LAG(pl.container_number) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) <> pl.container_number) -- same UPCs in diff containers
            OR ((LAG(pl.upc) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = pl.upc AND (LAG(pl.bill_of_lading) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) <> pl.bill_of_lading) -- different shipments, same container (as in LTLs) // 231204
            OR ((LAG(pl.upc) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) <> pl.upc AND (LAG(pl.container_number) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = pl.container_number) -- diff UPCs in same container
            OR ((LAG(pl.carton_number) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) = pl.carton_number AND (LAG(pl.container_number) OVER (ORDER BY po.po_number, po.d_sku, pl.carton_number)) <> pl.container_number)) -- same cartonnumber, diff containers
            THEN ''
            ELSE TO_VARCHAR(po.d_received_quantity)
            END AS d_received_quantity -- new formula s.t. received_quantity will always be assigned to an inner pack 230923          
        , CASE WHEN pl.carton_number LIKE '%Master%' THEN ''
            ELSE TO_VARCHAR(pl.upc_quantity)
            END AS pl_expected_quantity -- zero out the quantity for masterpacks to avoid incorrect counts when quantities are summed in PowerBI   
        , CASE WHEN pl.carton_number LIKE '%Master%' THEN ''
            WHEN (LAG(pl.container_number) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku, pl.upc)) = pl.container_number
            AND (LAG(po.po_number) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku, pl.upc)) = po.po_number 
            AND (LAG(po.d_sku) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku, pl.upc)) = po.d_sku
            AND (LAG(pl.upc_quantity) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku, pl.upc)) = pl.upc_quantity 
            THEN '' 
            ELSE TO_VARCHAR(pl.upc_quantity) 
            END AS pl_expected_sku_quantity -- assigns the pl_expected_quantity (per sku) to the first row of po_number-sku-container line 240925    
        , CASE WHEN pl.carton_number LIKE '%Master%' THEN ''
            ELSE TO_VARCHAR(wr.received_qty)
            END AS iwrd_received_quantity -- zero out the quantity for masterpacks to avoid incorrect counts when quantities are summed in PowerBI
        , CASE 
            WHEN pl.carton_number LIKE '%Master%' THEN ''
            WHEN(LAG(wr.received_qty) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku)) = wr.received_qty
            AND (LAG(pl.container_number) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku)) = pl.container_number
            AND (LAG(po.po_number) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku)) = po.po_number
            AND (LAG(po.d_sku) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku)) = po.d_sku
            THEN '' 
            ELSE TO_VARCHAR(wr.received_qty) 
            END AS iwrd_received_sku_quantity -- assigns the d_received_quantity (per sku) to the first row of po_number-sku-container line
        , CAST(pl.departure_date AS DATE) AS pl_actual_ship_date
        , CAST(wr.date_received AS DATE) AS iwr_received_on
        , CASE WHEN po.po_number IS NULL THEN TO_VARCHAR(po.d_total_spend)
            WHEN(LAG(po.d_total_spend) OVER (ORDER BY po.po_number, po.d_sku, pl.upc)) = po.d_total_spend
            AND (LAG(po.po_number) OVER (ORDER BY po.po_number, po.d_sku, pl.upc)) = po.po_number
            AND (LAG(po.d_sku) OVER (ORDER BY po.po_number, po.d_sku, pl.upc)) = po.d_sku
            THEN '' 
            ELSE TO_VARCHAR(po.d_total_spend) 
            END AS d_total_spend  -- assigns the total_spend (per sku) to the first row of po_number-sku combination regardless of container, HBL, PL
        , CASE WHEN po.po_number IS NULL THEN TO_VARCHAR(wr.received_qty)
            WHEN(LAG(wr.received_qty) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku)) = wr.received_qty
            AND (LAG(pl.container_number) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku)) = pl.container_number
            AND (LAG(po.po_number) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku)) = po.po_number 
            AND (LAG(po.d_sku) OVER (ORDER BY pl.container_number, po.po_number, po.d_sku)) = po.d_sku
            THEN NULL 
            ELSE po.d_initial_unit_price * wr.received_qty
            END AS calc_spend_by_qty_received -- calculates the cost per SKU based on initial_unit_price in PO multiplied by the number of actual units received 
        , CAST(po.h_etd_shipping_start AS DATE) AS h_etd_shipping_start
        , CAST(po.h_etd_shipping_end AS DATE) AS h_etd_shipping_end
        , po.h_receiving_warehouse AS h_receiving_warehouse
        , pl.receiving_warehouse AS pl_receiving_warehouse
        , po.h_port_name AS h_port_name
        , pl.destination_port  AS pl_destination_port
        , po.h_origin_country AS h_origin_country 
        , po.h_supplier_name AS h_supplier_name
        , po.h_season_name AS h_season_name
        , CASE 
            WHEN pl.invoice_id IS NULL AND DATEADD(day, 45, GETDATE()) > po.h_initial_eta THEN CAST(DATEADD(day, 45, GETDATE()) AS DATE) -- there is no packing list, current date + fixed number of days > h_initial_eta
            WHEN pl.invoice_id IS NULL AND DATEADD(day, 45, GETDATE()) < po.h_initial_eta THEN CAST(po.h_initial_eta AS DATE) -- there is no packing list, current date + fixed number of days < h_initial_eta
            WHEN pl.invoice_id IS NOT NULL AND wr.date_received IS NOT NULL THEN CAST(wr.date_received AS DATE) -- there is a packing list and the item has been received at the warehouse
            WHEN pl.invoice_id IS NOT NULL AND wr.date_received IS NULL AND ct.calcualted_eta_to_instock IS NOT NULL THEN CAST(ct.calcualted_eta_to_instock AS DATE)-- there is a packing list, the item has not been received at the warehouse, but Podium has CalculatedETAtoInStock
            WHEN pl.invoice_id IS NOT NULL AND wr.date_received IS NULL AND ct.calcualted_eta_to_instock IS NULL THEN CAST(DATEADD(day, 45, pl.departure_date) AS DATE) -- there is a packing list, the item has not been received at the warehouse, and Podium has no CalculatedETAtoInStock
            END AS in_stock_date -- logic defined 240912
        , CASE 
            WHEN wr.date_received IS NOT NULL         
            THEN CAST(IFNULL(ct.calcualted_eta_to_instock, wr.date_received) AS DATE)
            ELSE CAST(ct.calcualted_eta_to_instock AS DATE)
            END AS ct_calculated_eta_to_instock -- case when defined 231024 
        , CAST(po.h_initial_eta AS DATE) AS h_initial_eta
        , CASE WHEN pl.invoice_id IS NULL THEN 'NO' ELSE 'YES' END AS in_packing_list
        , CASE 
            WHEN wr.date_received IS NOT NULL THEN 'Delivered'
            WHEN ct.gateoutfull_actualdate IS NOT NULL -- AND Discharge_ActualDate IS NOT NULL -- removed 240911 as we no longer get Discharge_ActualDate since shifting from P44 to Podium
                THEN 'Final Transit to Warehouse' -- shipment not tracked by P44/Podium will not go through this status
            WHEN ct.discharge_actualdate IS NOT NULL THEN 'At Arrival Port' -- shipment not tracked by P44/Podium will not go through this status
            WHEN ct.departurefromstop_actualdate IS NOT NULL OR pl.departure_date IS NOT NULL THEN 'In Transit' 
            WHEN ct.gateinfull_actualdate IS NOT NULL THEN 'At Origin Port' -- shipment not tracked by P44/Podium will not go through this status
            ELSE 'To be shipped' 
            END AS Shipment_Status  -- added 230918 
        , CAST(ct.GateInFull_ActualDate AS DATE) AS ct_Gate_In_Full_Date
        , CAST(ct.DepartureFromStop_ActualDate AS DATE) AS ct_Departure_From_Stop_Date
        , CAST(ct.Discharge_ActualDate AS DATE) AS ct_Discharge_Date
        , CAST(ct.GateOutFull_ActualDate AS DATE) AS ct_Gate_Out_Full_Date
        , CASE 
            WHEN po.d_brand = 'BHS' THEN 'BH Studio'
            WHEN po.d_brand = 'TC&NN' THEN 'TC'        
            WHEN po.d_brand = 'TCUS' THEN 'TC'        
            WHEN po.d_brand = 'TTUS' THEN 'TT'        
            WHEN (po.d_brand = 'BH WHOLESALE' OR po.d_brand = 'TT/TC WHOLESALE' OR po.d_brand = 'TC WHOLESALE') THEN 'Growth'
            ELSE po.d_brand
            END AS brand_key -- added 240926 from Power Query
    FROM analytics.core_PurchaseOrder po
        LEFT JOIN analytics.core_PackingList pl ON po.po_number = pl.invoice_id AND po.d_sku = pl.sku
        LEFT JOIN analytics.core_WarehouseReceipt wr ON pl.container_number = wr.container_number AND pl.packing_list_summary_id = wr.packing_list_id AND pl.Upc = wr.Upc AND pl.invoice_id = wr.po_number
        LEFT JOIN analytics.core_ContainerTracking ct ON pl.container_number = ct.container_number and pl.bill_of_lading = ct.bill_of_lading
);