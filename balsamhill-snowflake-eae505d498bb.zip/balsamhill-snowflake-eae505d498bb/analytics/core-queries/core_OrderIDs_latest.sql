USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_OrderIDs_latest AS (

SELECT DISTINCT
    o.order_id AS order_id
FROM balsam_sc_data.direct_access.sc_org_orders o
WHERE
o.order_id NOT LIKE 'P%'
AND UPPER(o.order_type) != 'SFORDERMIGRATION'
AND (CASE
        WHEN o.order_type IN ('ASM', 'HYBRIS') THEN IFNULL(IFNULL(o.properties:"OriginalTotalAmount"::DECIMAL(10,2),o.properties:"@OriginalTotalAmount"::DECIMAL(10,2)),o.total_price)
        ELSE o.total_price END) > 0
AND UPPER(o.fulfillment_status) NOT IN ('CANCELLED', 'CANCELED')
AND O.properties:"OrderStatus"::TEXT NOT IN ('RETURN RECEIVED')
);