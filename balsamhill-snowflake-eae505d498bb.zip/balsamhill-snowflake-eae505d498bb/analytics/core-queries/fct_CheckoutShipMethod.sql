USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.fct_CheckoutShipMethod AS (
SELECT 
    ch.brand
    , ch.order_header_key
    , ch.order_id
    , ch.order_date_pt
    , CASE WHEN LAG(ch.order_id) OVER(ORDER BY ch.order_id, d.customer_item) = ch.order_id THEN 0 ELSE ch.gross_revenue_initial END AS gross_revenue_initial
    , CASE WHEN LAG(ch.order_id) OVER(ORDER BY ch.order_id, d.customer_item) = ch.order_id THEN 0 ELSE ch.total_shipping_payment_initial END AS shipping_payment
    , d.customer_item AS sku
    , d.customer_item_description AS product_name
    , s.shipnode_key
    , w.warehouse_name AS warehouse
    , d.level_of_service AS checkout_los
    , r.level_of_service AS oms_los    
    , s.level_of_service AS warehouse_los    
    , r.scac AS oms_scac    
    , s.scac AS warehouse_scac
    , r.carrier_service_code AS oms_ship_method
    , s.carrier_service_code AS warehouse_ship_method
    , s.shipment_key
    , s.tracking_no
FROM analytics.core_orderheader ch    
    JOIN analytics.txn_order_shipment s ON ch.order_header_key = s.order_header_key
    JOIN analytics.txn_order_shipment_line sl ON s.shipment_key = sl.shipment_key
    JOIN analytics.txn_order_release r ON sl.order_release_key = r.order_release_key
    JOIN analytics.ext_order_detail d ON sl.order_header_key = d.order_header_key AND sl.order_line_key = d.order_line_key 
    LEFT JOIN master.dim_warehouse w ON s.shipnode_key = w.pk_warehouseid     
WHERE ch.order_id LIKE 'J%' -- filter out warranty orders, indirect orders    
    --AND order_id = 'J100940020' AND sku = '4002925' -- valid tracking_no should be only: 281906277053 and 281906277487
    --AND order_id = 'J101160155' AND sl.item_id = '4001990'
);