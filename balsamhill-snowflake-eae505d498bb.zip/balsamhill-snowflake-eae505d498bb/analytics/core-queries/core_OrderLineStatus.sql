-- Step 1: Line status normalization
USE DATABASE PRE_PROD;

CREATE OR REPLACE VIEW analytics.core_OrderLineStatus AS (
WITH CTE_LineStatus AS (
  SELECT
    order_line_key,
    MIN(STATUS_DATE) AS status_timestamp,
    CASE
      WHEN STATUS = '3350.0' THEN '3350'
      WHEN STATUS = '3700.0' THEN '3700'
      WHEN STATUS = '3700.300' THEN '3700.3'
      ELSE STATUS
    END AS order_line_status
  FROM txn_order_release_status
  WHERE STATUS IN (
    '3200', '3350', '3350.0',
    '3700', '3700.0', '3700.001',
    '3700.003', '3700.300'
  )
    AND STATUS_DATE IS NOT NULL
  GROUP BY order_line_key, STATUS
),

-- Step 2: Clean up order statuses
CTE_status AS (
  SELECT DISTINCT
    TOR.order_line_key,
    CASE
      WHEN UPPER(TRIM(order_status_name)) = 'RELEASED' THEN 'RELEASED'
      WHEN UPPER(TRIM(order_status_name)) = 'INCLUDED IN SHIPMENT' THEN 'INCLUDED_IN_SHIPMENT'
      WHEN UPPER(TRIM(order_status_name)) = 'SHIPPED' THEN 'SHIPPED'
      WHEN UPPER(TRIM(order_status_name)) = 'IN TRANSIT' THEN 'IN_TRANSIT'
      WHEN UPPER(TRIM(order_status_name)) = 'DELIVERED' THEN 'DELIVERED'
      ELSE NULL
    END AS order_status,
    TOR.status_timestamp
  FROM CTE_LineStatus TOR
  JOIN master.dim_order_status DOS 
    ON TOR.order_line_status = DOS.oms_order_status_code
  WHERE TOR.status_timestamp IS NOT NULL
)

-- Step 3: Aggregate the data manually
SELECT
    order_line_key,
    MAX(CASE WHEN order_status = 'RELEASED' THEN status_timestamp ELSE NULL END) AS RELEASED_TIMESTAMP,
    MAX(CASE WHEN order_status = 'INCLUDED_IN_SHIPMENT' THEN status_timestamp ELSE NULL END) AS INCLUDED_IN_SHIPMENT_TIMESTAMP,
    MAX(CASE WHEN order_status = 'SHIPPED' THEN status_timestamp ELSE NULL END) AS SHIPPED_TIMESTAMP,
    MAX(CASE WHEN order_status = 'IN_TRANSIT' THEN status_timestamp ELSE NULL END) AS IN_TRANSIT_TIMESTAMP,
    MAX(CASE WHEN order_status = 'DELIVERED' THEN status_timestamp ELSE NULL END) AS DELIVERED_TIMESTAMP
FROM CTE_status
GROUP BY order_line_key
);