use database prod;

create or replace view analytics.core_ContainerUsage_SkuLevel as (

-- ContainerUsage table in Inbound Inventory Dataflow (PowerBI/Power Platforms)
-- each row shows data on a specific BillOfLading-ContainerNumber-StoreSku combination
-- The SkuCBM is the volume of a specific Sku within the specific Container (ContainerNumber) in that Shipment (BillOfLading), regardless of Purchase Order
-- The MaxCTCapacity is the maximum capacity of the container while the MinCTCapacity is the minimum capacity of the container
-- Ideally, SUM(SkuCBM) for a specific BillOfLading-ContainerNumber would be more than the MinCTCapacity (otherwise, the container is not being utilized optimally)
-- If SUM(SkuCBM) is greater than MaxCTCapacity, there may be an error in Qty or the dimensions of cartons within that Container
-- Scope: this table only includes shipments from Polygroup for Purchase Orders in the season 2022 onwards
-- mzabala 2023-aug-03

WITH ContainerDetails AS ( 
    SELECT 
        REPLACE(REPLACE(BillOfLading,'-',''),'.','') AS BillOfLading -- removes extraneous characters from the BillOfLading
        , ContainerNumber
        , InvoiceID -- for filtering on how volume is calculated; prior to 2023, cartons were counted numerically (1 of 2, 2 of 2 etc.)
        , CartonNumber -- for filtering on how volume is calculated; prior to 2023, cartons were counted numerically (1 of 2, 2 of 2 etc.)
        , CASE WHEN ContainerSize = '20''GP'
                THEN '33'
            WHEN ContainerSize IN ('40', '40''', '40''GP')
                THEN '67'
            WHEN ContainerSize IN ('40 H', '40''H', '40HQ', '40''HQ', '40''''HQ', '40''HR') 
                THEN '76'
            WHEN ContainerSize LIKE '45%'
                THEN '86'
            ELSE NULL
            END AS MaxCTCapacity -- Maximum capacity of containers; definitions from Ops team
        , CASE WHEN ContainerSize = '20''GP'
                THEN '30'
            WHEN ContainerSize IN ('40', '40''', '40''GP')
                THEN '60'
            WHEN ContainerSize IN ('40 H', '40''H', '40HQ', '40''HQ', '40''''HQ', '40''HR') 
                THEN '69'
            WHEN ContainerSize LIKE '45%'
                THEN '78'
            ELSE NULL
            END AS MinCTCapacity -- Minimum capacity of containers; definitions from Ops team
        , StoreSku
        , CAST((0.0254*CAST(Length AS decimal(10,2)) * 0.0254*CAST(Width AS decimal(10,2)) * 0.0254*CAST(Height AS decimal(10,2)) * CAST(Qty AS decimal(10,2))) AS decimal(10,3)) AS UpcCBM
            -- UpcCBM is CBM per UPC in that container. This is length x width x height (of the carton) x number of cartons
            -- length, width, and height are stored in EDW in inches; this formula converts them to meters in order to calculate CBM
            -- while InventoryPackingList has a CBM field, we cannot use it because it lists the TotalCBM for a Sku for the specific BillOfLading regardless of container; thus it is not usable for calculating actual container utilization 
    FROM analytics.InventoryPackingList
    WHERE 1=1
    AND InventoryPackingListSummaryID IN (
            SELECT ID 
            FROM analytics.InventoryPackingListSummary
            WHERE DeletedDate IS NULL 
        ) -- limits the results to PackingLists that were not deleted from IIT
    AND NOT (BillOfLading = 'FLXT00001569368A' AND ContainerNumber = 'FCIU7552547') -- this specific container has an erroneous quantity (Qty=15000) that blows up the CBM
) 

-- 2022 season
SELECT BillOfLading AS Bill_Of_Lading
    , ContainerNumber AS Container_NUmber
    , MinCTCapacity AS Min_CT_Capacity
    , MaxCTCapacity AS Max_CT_Capacity
    , StoreSku AS Sku
    , SUM(UpcCBM) AS Sku_CBM -- this is the sum of the TotalCBM of all the cartons that make up the SKU; for a single-carton item, UpcCBM=CBM
FROM ContainerDetails
WHERE 1=1
AND CartonNumber <> 'Inner'
AND InvoiceID IN (
    SELECT po_number 
    FROM analytics.txn_po_header
    WHERE qb_vendor = 'Polygroup' 
    AND season_name = '2022'
    ) -- limits the results to packing lists from Polygroup for the 2022 season
GROUP BY BillOfLading, ContainerNumber,  MaxCTCapacity, MinCTCapacity, StoreSku


UNION


-- 2023 season onwards
SELECT BillOfLading AS Bill_Of_Lading
    , ContainerNumber AS Container_NUmber
    , MinCTCapacity AS Min_CT_Capacity
    , MaxCTCapacity AS Max_CT_Capacity
    , StoreSku AS Sku
    , SUM(UpcCBM) AS Sku_CBM -- this is the sum of the TotalCBM of all the cartons that make up the SKU; for a single-carton item, UpcCBM=CBM
FROM ContainerDetails 
WHERE 1=1
AND InvoiceID IN (
    SELECT po_number
    FROM analytics.txn_po_header 
    WHERE qb_vendor = 'Polygroup' 
    AND season_name NOT IN ('2018', '2019', '2020', '2021', '2022') -- for 2023 onwards
    ) 
AND (( 
        StoreSku NOT IN (
            SELECT StoreSku 
            FROM analytics.InventoryPackingList 
            WHERE CartonNumber = 'Master'
            ) 
        AND CartonNumber = 'Inner' 
    ) -- includes inner packs that are NOT packed in a masterpack 
    OR CartonNumber = 'Master' -- includes Masterpacks but not their innerpacks
    )
GROUP BY BillOfLading, ContainerNumber,  MaxCTCapacity, MinCTCapacity, StoreSku
ORDER BY 1, 2
);