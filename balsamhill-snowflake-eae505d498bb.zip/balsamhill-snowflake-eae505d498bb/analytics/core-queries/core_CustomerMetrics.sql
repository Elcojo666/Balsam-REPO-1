USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_CustomerMetrics AS (

SELECT 
customer_id
,MIN(ORDER_DATE_PT) as first_order_date
,MAX(ORDER_DATE_PT) as last_order_date
,COUNT(DISTINCT order_id) as total_orders
,SUM(NET_REVENUE_LATEST) as total_net_revenue_
,SUM(TOTAL_ORDERED_QUANTITY_LATEST) as total_ordered_quantity
,'' total_availed_discounts --to add once core_orderdiscounts is avaiable
,SUM(TOTAL_DISCOUNTS_LATEST) as total_discounts
,SUM(IFNULL(total_refund_header,0)) as total_refund
,IFNULL(count(distinct R.ORIGINAL_ORDER_ID),0) AS total_returned_orders
,IFNULL(SUM(RETURN_QUANTITY),0) AS total_returned_quantity
,0 as total_warranty_orders
,0 as total_warranty_cost
from analytics.core_orderheader O --should we limit the order date like in core queries?
left join analytics.core_returns r on o.order_id = r.original_order_id
--LEFT JOIN core_warrantyorders w on o.order_id = w.original_order_id --to add as soon as warranty is available in prod
--TO ADD OTHER ATTRIBUTES
GROUP BY ALL


);