USE DATABASE PROD;
CREATE OR REPLACE VIEW analytics.core_FullyLoadedCost AS (
SELECT
    CONCAT(FISCALYEAR,brand,sku) AS fiscalyear_brand_sku
    ,brand
    ,sku
    ,fullyloadedcost AS fully_loaded_cost
    ,initialcost AS initial_cost
    ,landedcost AS landed_cost
    ,variableforecastflc AS variable_forecast_flc
    ,fiscalyear AS fiscal_year
FROM analytics.flc
);