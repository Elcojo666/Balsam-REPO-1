USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_OrderAssociation AS (
    
-- MULTI SKU ORDERS
WITH CTE_Orders_Multi AS
(
    SELECT order_header_key
    FROM analytics.core_OrderLines_initial
    WHERE order_date_pt >= '2024-02-01'
      AND channel IN ('HYBRIS', 'AMAZON')
      AND extendwarranty = FALSE
    GROUP BY order_header_key
    HAVING COUNT(sku) > 1
),
CTE_OrderDetails_Multi AS
(
    SELECT 
        O.order_header_key,
        OL.brand,
        OL.order_id,
        CAST(OL.order_date_pt AS DATE) AS order_date_pt,
        OL.sku AS product_code,
        SM.parent_code,
        SM.department,
        SM.subdepartment,
        SM.class
    FROM CTE_Orders_Multi O
    JOIN analytics.core_OrderLines_initial OL ON O.order_header_key = OL.order_header_key
    LEFT JOIN analytics.core_SkuMaster SM ON OL.brand = SM.brand AND OL.sku = SM.sku
),
CTE_Associations_Multi AS
(
    -- SKU level
    SELECT 
        A.brand, A.order_id, A.order_date_pt,
        A.product_code AS association_product1,
        B.product_code AS association_product2,
        'SKU' AS association_product_level
    FROM CTE_OrderDetails_Multi A
    LEFT JOIN CTE_OrderDetails_Multi B 
        ON A.order_header_key = B.order_header_key
    WHERE A.product_code < B.product_code

    UNION ALL
    -- Parent level
    SELECT DISTINCT brand, order_id, order_date_pt, association_product1, association_product2, 'Parent' AS association_product_level
    FROM (
        SELECT DISTINCT
            A.brand, A.order_id, A.order_date_pt,
            A.product_code AS sku1, B.product_code AS sku2,
            A.parent_code AS association_product1, B.parent_code AS association_product2,
            CASE WHEN A.product_code = B.product_code THEN 'N'
                 WHEN A.parent_code <= B.parent_code THEN 'Y'
                 ELSE 'N' END AS filtered
        FROM CTE_OrderDetails_Multi A
        LEFT JOIN (
            SELECT DISTINCT order_header_key, product_code, parent_code
            FROM CTE_OrderDetails_Multi
        ) B ON A.order_header_key = B.order_header_key
    ) T WHERE filtered = 'Y'

    UNION ALL
    -- Department level
    SELECT DISTINCT brand, order_id, order_date_pt, association_product1, association_product2, 'department' AS association_product_level
    FROM (
        SELECT DISTINCT
            A.brand, A.order_id, A.order_date_pt,
            A.product_code AS sku1, B.product_code AS sku2,
            A.department AS association_product1, B.department AS association_product2,
            CASE WHEN A.product_code = B.product_code THEN 'N'
                 WHEN A.department <= B.department THEN 'Y'
                 ELSE 'N' END AS filtered
        FROM CTE_OrderDetails_Multi A
        LEFT JOIN (
            SELECT DISTINCT order_header_key, product_code, department
            FROM CTE_OrderDetails_Multi
        ) B ON A.order_header_key = B.order_header_key
    ) T WHERE filtered = 'Y'

    UNION ALL
    -- Subdepartment level
    SELECT DISTINCT brand, order_id, order_date_pt, association_product1, association_product2, 'subdepartment' AS association_product_level
    FROM (
        SELECT DISTINCT
            A.brand, A.order_id, A.order_date_pt,
            A.product_code AS sku1, B.product_code AS sku2,
            A.subdepartment AS association_product1, B.subdepartment AS association_product2,
            CASE WHEN A.product_code = B.product_code THEN 'N'
                 WHEN A.subdepartment <= B.subdepartment THEN 'Y'
                 ELSE 'N' END AS filtered
        FROM CTE_OrderDetails_Multi A
        LEFT JOIN (
            SELECT DISTINCT order_header_key, product_code, subdepartment
            FROM CTE_OrderDetails_Multi
        ) B ON A.order_header_key = B.order_header_key
    ) T WHERE filtered = 'Y'

    UNION ALL
    -- Class level
    SELECT DISTINCT brand, order_id, order_date_pt, association_product1, association_product2, 'class' AS association_product_level
    FROM (
        SELECT DISTINCT
            A.brand, A.order_id, A.order_date_pt,
            A.product_code AS sku1, B.product_code AS sku2,
            A.class AS association_product1, B.class AS association_product2,
            CASE WHEN A.product_code = B.product_code THEN 'N'
                 WHEN A.class <= B.class THEN 'Y'
                 ELSE 'N' END AS filtered
        FROM CTE_OrderDetails_Multi A
        LEFT JOIN (
            SELECT DISTINCT order_header_key, product_code, class
            FROM CTE_OrderDetails_Multi
        ) B ON A.order_header_key = B.order_header_key
    ) T WHERE filtered = 'Y'
),
Final_Multi AS (
    SELECT 
        brand, order_id, order_date_pt, association_product1, association_product2, association_product_level, 'MULTI' AS association_type
    FROM CTE_Associations_Multi
),

-- SINGLE SKU ORDERS

CTE_Orders_Single AS
(
    SELECT order_header_key
    FROM analytics.core_OrderLines_initial
    WHERE order_date_pt >= '2024-02-01'
      AND channel IN ('HYBRIS', 'AMAZON')
      AND extendwarranty = FALSE
    GROUP BY order_header_key
    HAVING COUNT(sku) = 1
),
CTE_OrderDetails_Single AS
(
    SELECT 
        O.order_header_key,
        OL.brand,
        OL.order_id,
        CAST(OL.order_date_pt AS DATE) AS order_date_pt,
        OL.sku AS product_code,
        SM.parent_code,
        SM.department,
        SM.subdepartment,
        SM.class
    FROM CTE_Orders_Single O
    JOIN analytics.core_OrderLines_initial OL ON O.order_header_key = OL.order_header_key
    LEFT JOIN analytics.core_SkuMaster SM ON OL.brand = SM.brand AND OL.sku = SM.sku
),
CTE_Associations_Single AS
(
    -- SKU level
    SELECT 
        brand, order_id, order_date_pt,
        A.product_code AS association_product1,
        '' AS association_product2,
        'SKU' AS association_product_level
    FROM CTE_OrderDetails_Single A

    UNION ALL
    -- Parent level
    SELECT DISTINCT brand, order_id, order_date_pt, parent_code AS association_product1, '' AS association_product2, 'Parent' AS association_product_level
    FROM CTE_OrderDetails_Single

    UNION ALL
    -- Department level
    SELECT DISTINCT brand, order_id, order_date_pt, department AS association_product1, '' AS association_product2, 'department' AS association_product_level
    FROM CTE_OrderDetails_Single

    UNION ALL
    -- Subdepartment level
    SELECT DISTINCT brand, order_id, order_date_pt, subdepartment AS association_product1, '' AS association_product2, 'subdepartment' AS association_product_level
    FROM CTE_OrderDetails_Single

    UNION ALL
    -- Class level
    SELECT DISTINCT brand, order_id, order_date_pt, class AS association_product1, '' AS association_product2, 'class' AS association_product_level
    FROM CTE_OrderDetails_Single
),
Final_Single AS (
    SELECT 
        brand, order_id, order_date_pt, association_product1, association_product2, association_product_level, 'SINGLE' AS association_type
    FROM CTE_Associations_Single
)

-- FINAL UNION


SELECT * FROM Final_Multi
UNION ALL
SELECT * FROM Final_Single


);