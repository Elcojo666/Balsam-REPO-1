CREATE OR REPLACE VIEW analytics.core_OrderHeader_latest AS (
with 
cte_id as (
    select *
    from analytics.core_orderids_initial
),

cte_line as (
    select 
        order_header_key,
        sum(case when extend_warranty = 'YES' then total_product_price_latest * 1.5 else 0 end) as extend_warranty_latest,
        sum(ordered_quantity_latest) as total_ordered_quantity_latest,
        sum(total_product_price_latest) as total_product_price_latest,
        count(distinct case when ordered_quantity_latest > 0 then sku else null end) as total_sku_count_latest
    from analytics.core_orderlines
    group by order_header_key
),

cte_returns AS (
    select distinct
        rsf.original_order_header_key,
        sum(coalesce(coalesce(r.total_refund, rsf.return_cost), 0)) as total_refund_order,
        sum(r.total_refund_principal) AS total_refund_principal,
        sum(r.total_refund_shipping) AS total_refund_shipping,
        sum(r.total_refund_tax) AS total_refund_tax
    from analytics.core_returns_sf rsf
    left join balsam_sc_data.direct_access.sc_returns r on rsf.return_order_id = r.order_id
    group by rsf.original_order_header_key
)

select distinct
    id.order_header_key,
    o.scid,
    o.cuid as customer_id,
    id.brand,
    id.channel,
    id.order_source,
    o.order_id,
    id.order_date_pt,
    id.order_date_local,
    greatest(o.total_price - coalesce(r.total_refund_order,0),0) as total_payment_received_latest,
    greatest(total_payment_received_latest - IFNULL(o.total_tax, 0),0) AS gross_revenue_latest,
    gross_revenue_latest AS net_revenue_latest, --to update again
    coalesce(o.total_tax,0) AS total_tax_latest,
    coalesce(o.total_shipping,0) AS total_shipping_payment_latest,
    o.total_discounts AS total_discounts_latest,
    line.total_product_price_latest,
    line.total_ordered_quantity_latest,
    line.total_sku_count_latest,
    coalesce(r.total_refund_order, 0) AS total_refund_header,
    coalesce(r.total_refund_principal, 0) AS total_refund_principal,
    coalesce(r.total_refund_shipping, 0) AS total_refund_shipping,
    coalesce(r.total_refund_tax, 0) AS total_refund_tax,
    o.payment_method as payment_method,
    o.currency as currency,
    o.currency_conversion_rate as currency_conversion_rate,
    upper(ifnull(properties:"OrderStatus"::text, fulfillment_status)) as current_order_status,
    case when properties:"OrderStatus"::text ilike 'return%' then 'YES' else 'NO' end as returned,
    case when o.total_discounts > 0 then 'YES' else 'NO' end as discounted,
    case 
        when properties:"GiftFlag" = true then 'YES' 
        else 'NO' 
    end as gift_flag
from cte_id id
join balsam_sc_data.direct_access.sc_org_orders o on id.order_header_key = o.source_order_id
left join cte_line line on id.order_header_key = line.order_header_key
left join cte_returns r on id.order_header_key = r.original_order_header_key
);