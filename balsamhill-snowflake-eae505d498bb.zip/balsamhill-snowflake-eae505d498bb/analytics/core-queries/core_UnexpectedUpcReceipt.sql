USE DATABASE prod;

CREATE OR REPLACE VIEW analytics.core_UnexpectedUpcReceipt AS (

-- this CTE removes duplicate warehouse receipts for specific containers (different IDs for one ContainerNumber-InventoryPackingListSummaryID combination) ; occurred in 2020 - 2022
WITH ValidReceipts AS (
    SELECT ContainerNumber
        , DateReceived
        , InventoryPackingListSummaryID
        , WarehouseID
        , MAX(ID) AS ID -- to remove duplicate warehouse receipts (happens when ops uploads a receipt more than once)
    FROM analytics.InventoryWarehouseReceipt
    WHERE InventoryPackingListSummaryID IN (
        SELECT ID 
        FROM analytics.InventoryPackingListSummary
        WHERE DeletedDate IS NULL
        ) -- limit results to PLs that have not been deleted in IIT
    GROUP BY ALL
)

SELECT DISTINCT h.season_name AS season
    , rd.PONumber AS po_number
    , pl.InvoiceID AS invoice_ID
    , r.ContainerNumber AS container_number
    , w.warehouse_name
    , rd.Sku
    , rd.Upc
    , rd.ReceivedQty AS received_qty
    , CAST(r.DateReceived AS DATE) AS date_received
    , rd.DiscrepancyReason AS discrepancy_reason
FROM analytics.InventoryWarehouseReceiptDetail rd    
    LEFT JOIN ValidReceipts r ON rd.InventoryWarehouseReceiptID = r.ID
    LEFT JOIN analytics.txn_po_header h ON rd.PONumber = h.po_number 
    LEFT JOIN master.dim_warehouse w ON r.WarehouseID = w.pk_warehouseid 
    LEFT JOIN analytics.InventoryPackingListSummary pl ON r.InventoryPackingListSummaryID = pl.ID
WHERE DateReceived IS NOT NULL
    AND IsUnexpectedUpc = 1
);