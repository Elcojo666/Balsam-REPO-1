USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_OrderFulfillments AS (
--v1: txn_order_container_details OCD ON OCD.order_line_key = OD.order_line_key
SELECT 
    OD.order_line_key 
    ,OH.source_ref_num AS order_id
    ,CASE WHEN B.BRANDCODEFORWHM = 'BAL' THEN 'BHUS'
    WHEN B.BRANDCODEFORWHM = 'TREE' THEN 'TTUS' 
    ELSE B.BRANDCODEFORWHM END AS brand
    ,P.PLATFORM_NAME AS channel
    ,W.warehouse_region
    ,W.warehouse_name
    ,TRK.tracking_no AS tracking_number
    ,TRK.carrier_service_code as warehouse_shipping_method
    ,OCD.item_id AS sku
    ,OCD.extn_upc_item_id AS upc
    ,OCD.quantity  AS shipped_quantity
    ,order_date
    ,OLS.RELEASED_TIMESTAMP
    ,OLS.INCLUDED_IN_SHIPMENT_TIMESTAMP
    ,OLS.SHIPPED_TIMESTAMP
    ,OLS.IN_TRANSIT_TIMESTAMP
    ,OLS.DELIVERED_TIMESTAMP
    ,ADDR.SHIP_CITY
    ,ADDR.SHIP_STATE
    ,ADDR.SHIP_POSTAL_CODE
    ,ADDR.SHIP_COUNTRY
FROM analytics.audit_order_header OH
JOIN analytics.audit_order_detail OD ON OD.fk_order_headerid = OH.PK_ORDER_HEADERID
LEFT JOIN analytics.core_orderlinestatus OLS ON OLS.order_line_key = OD.order_line_key
LEFT JOIN analytics.txn_order_shipment_line OSL ON OD.order_line_key = OSL.order_line_key
LEFT JOIN analytics.txn_order_shipment TRK ON TRK.shipment_key = OSL.shipment_key
JOIN analytics.txn_order_container_details OCD ON OCD.order_line_key = OD.order_line_key
LEFT JOIN analytics.core_warehouse W ON CAST(TRK.shipnode_key AS DECIMAL) = CAST(W.warehouse_id AS DECIMAL)
LEFT JOIN analytics.core_orderbillingandshippinginformation ADDR ON ADDR.ORDER_ID = OH.source_ref_num
JOIN master.dim_source S ON S.pk_sourceid = OH.fk_sourceid
JOIN master.dim_brand B ON S.FK_BRANDID = B.PK_BRANDID
JOIN master.dim_platform P ON S.FK_PLATFORMID = P.PK_PLATFORMID

WHERE
    TRK.tracking_no IS NOT NULL
    AND OCD.item_id IS NOT NULL
    AND (OD.Revision = 1 OR OD.Revision IS NULL)
    AND (OH.Revision = 1 OR OH.Revision IS NULL)
    
) ;