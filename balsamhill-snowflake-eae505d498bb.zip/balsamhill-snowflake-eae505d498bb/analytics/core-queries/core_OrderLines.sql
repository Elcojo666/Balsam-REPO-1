USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_OrderLines AS (
    SELECT 
    initial.order_header_key,
    initial.order_line_key,
    initial.brand_sku,
    initial.customer_id,
    initial.scid,
    initial.brand,
    initial.channel,
    initial.order_source,
    initial.order_id,
    initial.order_date_pt,
    initial.order_date_local,
    UPPER(CONCAT(CAST(CASE 
            WHEN EXTRACT(MONTH FROM initial.order_date_pt) > 1 
            THEN EXTRACT(YEAR FROM initial.order_date_pt) 
            ELSE EXTRACT(YEAR FROM initial.order_date_pt) - 1 
            END AS STRING), initial.brand_sku)) AS fiscal_year_brand_sku,
        CAST(CASE 
            WHEN EXTRACT(MONTH FROM initial.order_date_pt) > 1 
            THEN EXTRACT(YEAR FROM initial.order_date_pt) 
            ELSE EXTRACT(YEAR FROM initial.order_date_pt) - 1 
            END AS STRING) AS fiscal_year,
    initial.sku,
    initial.order_product_name,
    initial.ordered_quantity_initial,
    initial.product_price,
    initial.line_tax_initial,
    initial.line_discounts_initial,
    initial.total_product_price_initial,
    initial.product_revenue_initial,
    initial.discounted_product_revenue_initial,
    latest.ordered_quantity_latest,
    latest.line_tax_latest,
    latest.line_discounts_latest,
    latest.total_product_price_latest,
    latest.product_revenue_latest,
    latest.discounted_product_revenue_latest,
    latest.total_refund_line,
    latest.return_quantity,
    latest.refund_line,
    latest.refund_tax,
    latest.returned,
    initial.extend_warranty,
    initial.discounted,
    initial.currency,
    initial.currency_conversion_rate,
    initial.current_order_status
FROM analytics.core_orderlines_initial initial
LEFT JOIN analytics.core_orderlines_latest latest 
    ON initial.order_line_key = latest.order_line_key
);