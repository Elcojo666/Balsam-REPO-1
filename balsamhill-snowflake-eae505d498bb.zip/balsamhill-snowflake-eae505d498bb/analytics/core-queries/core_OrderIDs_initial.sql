USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_orderids_initial AS (
SELECT DISTINCT
    order_id AS order_id,
    source_order_id as order_header_key,
    UPPER(scope) AS brand,
    CASE
        WHEN order_type ILIKE 'ASM' THEN 'HYBRIS' 
        WHEN channel ILIKE '%AMAZON' THEN 'AMAZON'
        WHEN channel ILIKE '%VOLUSION%' THEN 'VOLUSION'
        ELSE order_type 
    END AS channel,
    UPPER(CASE 
        WHEN order_type ILIKE 'ASM' THEN 'PHONE' 
        WHEN order_type = 'Amazon' THEN 'AMAZON'
        ELSE properties:"EntryType"::TEXT 
    END) AS order_source,   
    order_date AS order_date_pt,
    CASE
            WHEN scope = 'bhuk' THEN CONVERT_TIMEZONE('UTC', 'Europe/London', order_timestamp::TIMESTAMP_NTZ)
            WHEN scope = 'bhde' THEN CONVERT_TIMEZONE('UTC', 'Europe/Berlin', order_timestamp::TIMESTAMP_NTZ)
            WHEN scope = 'bhfr' THEN CONVERT_TIMEZONE('UTC', 'Europe/Paris', order_timestamp::TIMESTAMP_NTZ)
            WHEN scope = 'bhau' THEN CONVERT_TIMEZONE('UTC', 'Australia/Sydney', order_timestamp::TIMESTAMP_NTZ)
            else CONVERT_TIMEZONE('UTC', 'America/Los_Angeles', order_timestamp::TIMESTAMP_NTZ)
        END AS order_date_local,
FROM balsam_sc_data.direct_access.sc_org_orders o
WHERE
order_id NOT LIKE 'P%'
AND UPPER(order_type) != 'SFORDERMIGRATION'
AND (CASE
        WHEN order_type IN ('ASM', 'HYBRIS') THEN IFNULL(IFNULL(properties:"OriginalTotalAmount"::DECIMAL(10,2),properties:"@OriginalTotalAmount"::DECIMAL(10,2)),total_price)
        ELSE total_price END) > 0
AND UPPER(IFNULL(properties:"OrderStatus"::TEXT,fulfillment_status)) NOT IN ('CANCELLED', 'CANCELED')
AND order_date >= '2022-01-30'
);