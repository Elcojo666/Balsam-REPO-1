USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_UPCOrders AS (
WITH CTE_GTIN AS
(
SELECT 
    ORDER_NO 
    ,CASE
        WHEN CHARINDEX('_', sku_item_id) > 0 THEN SUBSTRING(sku_item_id,1,CHARINDEX('_', sku_item_id) - 1)
        ELSE sku_item_id END AS sku
    ,UPC_ITEM_ID as upc
    ,ship_node
    ,CAST(quantity AS FLOAT) AS UPCQuantity
FROM analytics.txn_gtin_data 
WHERE UPC_ITEM_ID IS NOT NULL
),

CTE_skuproduct AS
(
    SELECT DISTINCT
        pk_skuproductid
        ,sku_code
        ,B.BrandCodeForPOTracker AS Brand
        ,B.pk_brandid AS pk_brandid
    FROM ANALYTICS.sku_product_locale SKU 
    LEFT JOIN master.dim_source S ON SKU.locale = S.locale
    JOIN master.dim_brand B ON S.fk_brandid = B.pk_brandid
    WHERE B.BrandCodeForPOTracker IS NOT NULL
    AND B.pk_brandid IN --active brands only, to prevent duplicates
    (
        1   --BHUS
        ,2  --TTUS
        ,4 --TCUS
        ,6  --BHUK
        ,7  --BHFR
        ,8  --BHDE
        ,10 --BHAU
        ,19 --BHCA
    )
)

SELECT DISTINCT
    OD.order_line_key
    ,OH.source_ref_num AS order_id
    ,WHSE.warehouse_name
    ,GTIN.sku
    ,GTIN.UPC
    ,CASE WHEN GTIN.UPC LIKE '%[_]%' then RIGHT(GTIN.UPC,LEN(GTIN.UPC) - CHARINDEX('_',GTIN.UPC)) ELSE '' END AS upc_section
    ,GTIN.UPCQuantity as shipped_quantity
    ,order_date
    ,DOS.order_status_name AS current_order_status
FROM CTE_GTIN GTIN
JOIN audit_order_header OH ON GTIN.ORDER_NO = OH.source_ref_num
JOIN master.dim_source S ON S.pk_sourceid = OH.fk_sourceid
JOIN master.dim_brand B ON S.FK_BRANDID = B.PK_BRANDID
JOIN master.dim_platform P ON S.FK_PLATFORMID = P.PK_PLATFORMID
JOIN CTE_SKUPRODUCT SKU ON S.fk_brandid = SKU.pk_brandid AND GTIN.Sku = SKU.sku_code
JOIN audit_order_detail OD ON OD.fk_order_headerid = OH.pk_order_headerid AND OD.fk_skuproductid = SKU.pk_skuproductid
JOIN analytics.core_Warehouse WHSE ON WHSE.warehouse_id = GTIN.ship_node
LEFT JOIN analytics.txn_order_status TOS ON TOS.fk_order_headerid= OH.pk_order_headerid
JOIN master.dim_order_status DOS ON TOS.fk_order_statusid = DOS.pk_order_statusid

WHERE (OD.Revision = 1 OR OD.Revision IS NULL)
AND (OH.Revision = 1 OR OH.Revision IS NULL)
);
