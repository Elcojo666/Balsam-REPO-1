use database prod;
create or replace view analytics.core_OrderBillingandShippingInformation AS (
SELECT 
    o.source_order_id AS order_header_key    
    , UPPER(o.scope) AS brand    
    , CASE
        WHEN UPPER(o.order_type) LIKE 'ASM' THEN 'HYBRIS' 
        WHEN UPPER(o.channel) LIKE '%AMAZON' THEN 'AMAZON'
        WHEN UPPER(o.channel) LIKE '%VOLUSION%' THEN 'VOLUSION'
        ELSE UPPER(o.order_type)
        END AS channel
    , o.order_id
    , o.order_date AS order_date_PT
    , UPPER(COALESCE(o.properties:"OrderStatus"::string, o.fulfillment_status)) AS order_status
    , b.city AS billing_city
    , b.state_code AS billing_state
    , b.zip AS billing_postal_code
    , b.country AS billing_country
    , o.shipping_address_city AS ship_city 
    , o.shipping_address_state_code AS ship_state
    , o.shipping_address_zip AS ship_postal_code
    , o.shipping_address_country AS ship_country
FROM balsam_sc_data.direct_access.sc_orders o
    JOIN balsam_priv_data.priv.sc_customer_billing_addresses b ON o.cuid = b.cuid
);