USE DATABASE PROD;

CREATE OR REPLACE VIEW analytics.core_OrderHeader_initial AS (

with 
cte_id as 
(
    select *
    from analytics.core_orderids_initial
),

cte_line as 
(
    select 
        order_header_key,
        sum(case when extend_warranty = 'YES' then total_product_price_initial * 1.5 else 0 end) as extend_warranty_initial,
        sum(ordered_quantity_initial) as total_ordered_quantity_initial,
        sum(total_product_price_initial) as total_product_price_initial,
        count(distinct sku) as total_sku_count_initial
    from analytics.core_orderlines
    group by order_header_key
),

cte_discounts as 
(
    select
        order_header_key,
        sum(order_discounts_initial) as total_discounts_initial
    from analytics.core_orderdiscounts_initial
    group by order_header_key
),

cte_amounts as (
    select distinct
        id.order_header_key,
        (case
            when o.order_type in ('ASM', 'HYBRIS') then ifnull(o.properties:"OriginalTotalAmount"::decimal(10,2), o.properties:"@OriginalTotalAmount"::decimal(10,2))
            else o.total_price
        end)
            - ifnull(line.extend_warranty_initial, 0) as total_payment_received_initial,
        coalesce(tax.total_tax_initial, 0) as total_tax_initial,
        coalesce(discount.total_discounts_initial, 0) as total_discounts_initial,
        coalesce(o.total_shipping, 0) as total_shipping_payment_initial
    from cte_id id
    join balsam_sc_data.direct_access.sc_org_orders o on id.order_header_key = o.source_order_id
    left join analytics.core_totaltax_initial tax on id.order_header_key = tax.order_header_key
    left join cte_line line on id.order_header_key = line.order_header_key
    left join cte_discounts discount on id.order_header_key = discount.order_header_key
),

cte_warranty as
(
    select 
        distinct original_order_header_key
    from analytics.core_warrantyorders_sf
)

select distinct
    id.order_header_key,
    o.scid,
    o.cuid as customer_id,
    id.brand,
    id.channel,
    id.order_source,
    o.order_id,
    id.order_date_pt,
    id.order_date_local,
    a.total_payment_received_initial - a.total_tax_initial as gross_revenue_initial,
    gross_revenue_initial * .93 as net_revenue_initial, --temp value while we update the discount rates
    a.total_payment_received_initial,
    a.total_tax_initial,
    a.total_shipping_payment_initial,
    a.total_discounts_initial,
    line.total_product_price_initial,
    line.total_ordered_quantity_initial,
    line.total_sku_count_initial,
    o.payment_method as payment_method,
    o.currency as currency,
    o.currency_conversion_rate as currency_conversion_rate,
    upper(ifnull(o.properties:"OrderStatus"::text, o.fulfillment_status)) as current_order_status,
    UPPER(o.fulfillment_status) AS fulfillment_status,
    UPPER(o.financial_status) AS financial_status,
    case when a.total_discounts_initial > 0 then 'YES' else 'NO' end as discounted,
    case when properties:"GiftFlag" = true then 'YES' else 'NO' end as gift_flag,
    case when line.extend_warranty_initial > 0 then 'YES' else 'NO' end as extend_warranty,
    case when ifnull(o.properties:"OrderStatus"::text, fulfillment_status) like '%RETURN%' then 'YES' else 'NO' end as returned,
    case when w.original_order_header_key is not null then 'YES' else 'NO' end as warranted,
    case when o.campaign != 'none' then 'YES' else 'NO' end as is_campaign
from cte_id id
join balsam_sc_data.direct_access.sc_org_orders o on id.order_header_key = o.source_order_id
left join cte_amounts a on id.order_header_key = a.order_header_key
left join cte_line line on id.order_header_key = line.order_header_key
left join cte_warranty w on id.order_header_key = w.original_order_header_key
);