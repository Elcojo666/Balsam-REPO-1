USE DATABASE DEV;

CREATE OR REPLACE FUNCTION ANALYTICS.FN_GENERATE_PHONE_E164(phone_input VARCHAR)
RETURNS STRING
LANGUAGE SQL
AS
$$
WITH cleaned_phone AS (
    SELECT 
        REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone_input, ' ', ''), '-', ''), ')', ''), '(', ''), '.', ''), '=', ''), ',', ''), '*', '') AS phone,
        LOWER(phone_input) AS phone_lower
),
phone_length AS (
    SELECT 
        phone,
        phone_lower,
        LENGTH(phone) AS phone_len
    FROM cleaned_phone
)
SELECT
    CASE
        -- Format 10-digit phone numbers without country code
        WHEN phone_len = 10 AND phone NOT LIKE '1%' AND phone NOT LIKE '+1%' THEN '+1' || phone

        -- Format 11-digit phone numbers starting with '1' but missing '+'
        WHEN phone_len = 11 AND phone LIKE '1%' AND phone NOT LIKE '+1%' THEN '+' || phone

        -- Handle extensions for numbers with '+1' country code
        WHEN phone_lower LIKE '%ext.%' AND phone LIKE '+1%' THEN
            '+' || SUBSTRING(phone, 1, CHARINDEX('ext.', phone_input) - 1)

        -- Handle extensions for numbers starting with '1'
        WHEN phone_lower LIKE '%ext.%' AND phone LIKE '1%' THEN
            '+' || SUBSTRING(phone, 1, CHARINDEX('ext.', phone_input) - 1)

        -- Nullify numbers starting with '11'
        WHEN phone LIKE '11%' THEN NULL

        -- Handle numbers starting with '+001' and replace with '+1'
        WHEN phone LIKE '+001%' THEN
            REPLACE(phone, '+001', '+1')

        -- Return original phone number for cases that don't match
        ELSE phone_input
    END AS formatted_phone
FROM phone_length
$$;