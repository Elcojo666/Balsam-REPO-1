USE DATABASE DEV;

CREATE OR REPLACE FUNCTION PRE_PROD.ANALYTICS.GETORDERSLISTCALLCENTER("EMAIL" VARCHAR(16777216), "SOURCE_REF_NUM" VARCHAR(16777216), "FIRSTNAME" VARCHAR(16777216), "LASTNAME" VARCHAR(16777216), "SHIPTOFIRSTNAME" VARCHAR(16777216), "SHIPTOLASTNAME" VARCHAR(16777216), "SHIPTOZIP" VARCHAR(16777216), "PHONE" VARCHAR(16777216), "ZIP" VARCHAR(16777216), "DATEFROM" DATE, "DATETO" DATE) COPY GRANTS 
RETURNS TABLE ("OrderNo" VARCHAR(16777216), "PKHeaderKey" NUMBER(38,0), "Detailid" NUMBER(38,0), "CustomerEMailID" VARCHAR(16777216), "CustomerFirstName" VARCHAR(16777216), "CustomerLaststName" VARCHAR(16777216), "MOBI_PHONE_PRIMARY" VARCHAR(16777216), "POSTAL_CODE" VARCHAR(16777216), "order_date" TIMESTAMP_NTZ(9), "source_ref_num" VARCHAR(16777216), "Currency" VARCHAR(16777216), "TotalAmount" NUMBER(15,6), "bill_address1" VARCHAR(16777216), "bill_address2" VARCHAR(16777216), "bill_city" VARCHAR(16777216), "bill_country" VARCHAR(16777216), "bill_day_phone" VARCHAR(16777216), "bill_email" VARCHAR(16777216), "bill_first_name" VARCHAR(16777216), "bill_ship_residential" INTEGER, "bill_last_name" VARCHAR(16777216), "ship_address1" VARCHAR(16777216), "ship_address2" VARCHAR(16777216), "ship_city" VARCHAR(16777216), "ship_country" VARCHAR(16777216), "ship_day_phone" VARCHAR(16777216), "ship_email_address" VARCHAR(16777216), "ship_first_name" VARCHAR(16777216), "ship_residential" BOOLEAN, "ship_last_name" VARCHAR(16777216), "ship_mobile_phone" VARCHAR(16777216), "OrderQuantity" NUMBER(38,0), "itemId" VARCHAR(16777216), "extendeddisplaydescription" VARCHAR(16777216), "display_status" VARCHAR(16777216), "order_line_status" VARCHAR(16777216))
LANGUAGE SQL
AS '
  SELECT DISTINCT
        toh.source_ref_num AS OrderNo,
        toh.pk_order_headerid AS PKHeaderKey,
        tod.pk_order_detailid AS Detailid,
        COALESCE(dc_info.EMAIL_PRIMARY, toh.email_address) AS CustomerEMailID,
        dc_info.FIRST_NAME AS CustomerFirstName,
        dc_info.LAST_NAME AS CustomerLaststName,
        dc_info.MOBI_PHONE_PRIMARY,
        COALESCE(dca.POSTAL_CODE, tas.postal_code) AS POSTAL_CODE,
        toh.order_date,
        toh.source_ref_num, 
        dcr.currency_code AS Currency,
        toh.net_amount AS TotalAmount,
        tab.address1 AS bill_address1,
        tab.address2 AS bill_address2,
        tab.city AS bill_city,
        tab.country AS bill_country,
        tab.phone_number AS bill_day_phone,
        toh.email_address AS bill_email,
        tab.first_name AS bill_first_name,
        CAST(toh.ship_residential AS INTEGER) AS bill_ship_residential,
        tab.last_name AS bill_last_name,
        tas.address1 AS ship_address1,
        tas.address2 AS ship_address2,
        tas.city AS ship_city,
        tas.country AS ship_country,
        tas.phone_number AS ship_day_phone,
        toh.email_address AS ship_email_address,
        tas.first_name AS ship_first_name,
        toh.ship_residential AS ship_residential,
        tas.last_name AS ship_last_name,
        tas.phone_number AS ship_mobile_phone,
        tod.quantity AS OrderQuantity,
        dsp.sku_code AS itemId,
        tod.product_name AS extendeddisplaydescription,
        dos.order_status_name AS display_status,
        CASE WHEN dos.order_status_name = ''DELIVERED'' THEN ''DELIVERED'' ELSE dos2.order_status_name END AS order_line_status
    FROM
        prod_extract.ANALYTICS.txn_order_header toh
    LEFT JOIN prod_extract.ANALYTICS.txn_order_detail tod ON toh.pk_order_headerid = tod.fk_order_headerid
    LEFT JOIN prod_extract.MASTER.dim_source ds ON ds.pk_sourceid = toh.fk_sourceid
    LEFT JOIN prod_extract.ANALYTICS.txn_order_delivered todel ON todel.fk_order_headerid = toh.pk_order_headerid
    LEFT JOIN prod_extract.MASTER.dim_currency dcr ON dcr.pk_currencyid = toh.fk_currencyid
    LEFT JOIN prod_extract.ANALYTICS.txn_address tas ON toh.fk_shipping_addressid = tas.pk_addressid
    LEFT JOIN prod_extract.ANALYTICS.txn_address tab ON toh.fk_billing_addressid = tab.pk_addressid
    LEFT JOIN prod_extract.ANALYTICS.customer dc ON dc.pk_customerid = toh.fk_customerid
    LEFT JOIN prod_extract.ANALYTICS.customer_info dc_info ON dc_info.FK_CUSTOMERID = dc.pk_customerid
    LEFT JOIN prod_extract.ANALYTICS.customer_address dca ON dc_info.pk_customer_info_id = dca.fk_customer_info_id
    LEFT JOIN prod_extract.ANALYTICS.txn_order_status tos ON toh.pk_order_headerid = tos.fk_order_headerid
    LEFT JOIN prod_extract.MASTER.dim_order_status dos ON COALESCE(tos.fk_order_statusid, toh.fk_order_statusid) = dos.pk_order_statusid
    LEFT JOIN prod_extract.ANALYTICS.txn_order_detail_status tods ON tods.pk_order_detailid = tod.pk_order_detailid
    LEFT JOIN prod_extract.MASTER.dim_order_status dos2 ON tods.fk_order__detail_statusid = dos2.pk_order_statusid
    LEFT JOIN prod_extract.ANALYTICS.sku_product dsp ON dsp.pk_skuproductid = tod.fk_skuproductid
    WHERE
        (email IS NULL OR UPPER(dc_info.EMAIL_PRIMARY) ILIKE ''%'' || UPPER(email) || ''%'' OR UPPER(toh.email_address) ILIKE ''%'' || UPPER(email) || ''%'')
        AND (source_ref_num IS NULL OR toh.source_ref_num = source_ref_num)
        AND (firstName IS NULL OR UPPER(dc_info.FIRST_NAME) = UPPER(firstName))
        AND (lastName IS NULL OR UPPER(dc_info.LAST_NAME) = UPPER(lastName))
        AND (shipToFirstName IS NULL OR UPPER(tas.first_name) = UPPER(shipToFirstName))
        AND (shipToLastName IS NULL OR UPPER(tas.last_name) = UPPER(shipToLastName))
        AND (shipToZip IS NULL OR tas.postal_code = shipToZip)
        AND (phone IS NULL OR dc_info.phone1_input = phone OR dc_info.phone2_input = phone OR dc_info.phone3_input = phone OR dc_info.phone4_input = phone
             OR dc_info.phone1_E164 = phone OR dc_info.phone2_E164 = phone OR dc_info.phone3_E164 = phone OR dc_info.phone4_E164 = phone)
        AND (zip IS NULL OR dca.POSTAL_CODE = zip)
        AND toh.order_date BETWEEN datefrom AND dateto
';
