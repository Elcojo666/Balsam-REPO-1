USE DATABASE DEV;

CREATE OR REPLACE FUNCTION ANALYTICS.udf_GetNPSReport(
    date DATE
)
    RETURNS TABLE (
                      FIRST_NAME           VARCHAR,
                      LAST_NAME            VARCHAR,
                      FK_CUSTOMERID        NUMBER(38,0),
                      EMAIL_PRIMARY        VARCHAR,
                      OrderDate            TIMESTAMP_NTZ,
                      OrderNo              VARCHAR,
                      ProductImageURL      VARCHAR,
                      ProductName          VARCHAR,
                      ProductCode          VARCHAR,
                      Subcategory          VARCHAR,
                      Category             VARCHAR,
                      OrderDiscountAmount  NUMBER(9,2),
                      TotalOrderAmount     NUMBER(15,6),
                      OrderSubtotal        NUMBER(9,2),
                      TotalTaxAmount       DOUBLE,
                      TotalDiscount        NUMBER(21,2),
                      ShippingCost         NUMBER(15,6),
                      BrandCode            VARCHAR
                  )
    LANGUAGE SQL
AS
$$
SELECT DISTINCT
    finalResult.FIRST_NAME,
    finalResult.LAST_NAME,
    finalResult.FK_CUSTOMERID,
    finalResult.EMAIL_PRIMARY,
    finalResult.OrderDate,
    finalResult.OrderNo,
    finalResult.ProductImageURL,
    finalResult.ProductName,
    finalResult.ProductCode,
    finalResult.Subcategory,
    finalResult.Category,
    finalResult.OrderDiscountAmount,
    finalResult.TotalOrderAmount,
    finalResult.OrderSubtotal ,
    finalResult.TotalTaxAmount,
    finalResult.TotalDiscount,
    finalResult.ShippingCost,
    finalResult.BrandCode
FROM
    (
        SELECT
            res.FIRST_NAME,
            res.LAST_NAME,
            res.FK_CUSTOMERID,
            res.EMAIL_PRIMARY,
            res.OrderDate,
            res.OrderNo,
            res.ProductImageURL,
            res.ProductName,
            res.ProductCode,
            res.Subcategory,
            res.Category,
            res.OrderDiscountAmount,
            res.TotalOrderAmount,
            res.OrderSubtotal AS OrderSubtotal,
            res.TotalTaxAmount,
            res.TotalDiscount,
            res.ShippingCost,
            res.BrandCode,
            ROW_NUMBER() OVER(PARTITION BY res.OrderNo ORDER BY res.OrderNo, res.OrderSubtotal DESC) AS Revision
        FROM
            (
                SELECT DISTINCT dci.FIRST_NAME,
                                dci.LAST_NAME,
                                dci.FK_CUSTOMERID,
                                dci.EMAIL_PRIMARY,
                                toh.ORDER_DATE            AS OrderDate,
                                toh.SOURCE_REF_NUM        AS OrderNo,
                                dsp.PRODUCT_PHOTO         AS ProductImageURL,
                                dspl.BH_PRODUCT_NAME      AS ProductName,
                                dsp.SKU_CODE              AS ProductCode,
                                dsp.SUB_CATEGORY          AS Subcategory,
                                dsp.PILLAR_CATEGORY       AS Category,
                                todc.DISCOUNT_AMOUNT      AS OrderDiscountAmount,
                                toh.NET_AMOUNT            AS TotalOrderAmount,
                                tod.TOTAL_PRICE           AS OrderSubtotal,
                                SUM(totx.TAX_AMOUNT)      AS TotalTaxAmount,
                                SUM(todc.DISCOUNT_AMOUNT) AS TotalDiscount,
                                toh.SHPPING_FEE_AMOUNT    AS ShippingCost,
                                db.BRANDCODEFORWHM        AS BrandCode,
                                tod.PK_ORDER_DETAILID
                FROM ANALYTICS.TXN_ORDER_HEADER AS toh
                         LEFT JOIN ANALYTICS.TXN_ORDER_DETAIL AS tod
                                   ON tod.FK_ORDER_HEADERID = toh.PK_ORDER_HEADERID
                         LEFT JOIN ANALYTICS.CUSTOMER AS dcc
                                   ON dcc.PK_CUSTOMERID = toh.FK_CUSTOMERID
                         LEFT JOIN ANALYTICS.CUSTOMER_INFO AS dci
                                   ON dci.FK_CUSTOMERID = toh.FK_CUSTOMERID
                         LEFT JOIN MASTER.DIM_SOURCE AS ds
                                   ON ds.PK_SOURCEID = toh.FK_SOURCEID
                         LEFT JOIN MASTER.DIM_BRAND AS db
                                   ON db.PK_BRANDID = ds.FK_BRANDID
                         LEFT JOIN ANALYTICS.SKU_PRODUCT AS dsp
                                   ON dsp.PK_SKUPRODUCTID = tod.FK_SKUPRODUCTID
                         LEFT JOIN ANALYTICS.SKU_PRODUCT_LOCALE AS dspl
                                   ON dspl.PK_SKUPRODUCTID = dsp.PK_SKUPRODUCTID
                                       AND dspl.LOCALE = ds.LOCALE
                         LEFT JOIN ANALYTICS.TXN_ORDER_TAX AS totx
                                   ON totx.FK_ORDER_HEADERID = toh.PK_ORDER_HEADERID
                         LEFT JOIN ANALYTICS.TXN_ORDER_DISCOUNT AS todc
                                   ON todc.FK_ORDER_HEADERID = toh.PK_ORDER_HEADERID
                         INNER JOIN ANALYTICS.TXN_ORDER_SHIPMENT AS tt
                                    ON tt.ORDER_NO = toh.SOURCE_REF_NUM
                WHERE CAST(tt.SHIP_DATE AS DATE) = DATEADD(DAY, -14, date)
                  AND toh.SOURCE_REF_NUM NOT LIKE '%W'
                  AND toh.FK_SOURCEID NOT IN (26, 27, 28, 29, 30, 34, 35, 36, 66)
                GROUP BY
                    dci.FIRST_NAME,
                    dci.LAST_NAME,
                    dci.FK_CUSTOMERID,
                    dci.EMAIL_PRIMARY,
                    toh.ORDER_DATE,
                    toh.SOURCE_REF_NUM,
                    dsp.PRODUCT_PHOTO,
                    dspl.BH_PRODUCT_NAME,
                    dsp.SKU_CODE,
                    dsp.SUB_CATEGORY,
                    dsp.PILLAR_CATEGORY,
                    todc.DISCOUNT_AMOUNT,
                    toh.NET_AMOUNT,
                    tod.TOTAL_PRICE,
                    toh.SHPPING_FEE_AMOUNT,
                    db.BRANDCODEFORWHM,
                    tod.PK_ORDER_DETAILID
            ) AS res
        GROUP BY
            res.FIRST_NAME,
            res.LAST_NAME,
            res.FK_CUSTOMERID,
            res.EMAIL_PRIMARY,
            res.OrderDate,
            res.OrderNo,
            res.ProductImageURL,
            res.ProductName,
            res.ProductCode,
            res.Subcategory,
            res.Category,
            res.OrderDiscountAmount,
            res.TotalOrderAmount,
            res.TotalTaxAmount,
            res.TotalDiscount,
            res.ShippingCost,
            res.BrandCode,
            res.PK_ORDER_DETAILID,
            res.OrderSubtotal
    ) AS finalResult
WHERE Revision = 1
    $$
;