CREATE OR REPLACE FUNCTION analytics.udf_get_customer_details_by_email(
    p_email VARCHAR DEFAULT NULL,
    p_source_ref_num VARCHAR DEFAULT NULL,
    p_firstname VARCHAR DEFAULT NULL,
    p_lastname VARCHAR DEFAULT NULL,
    p_phone VARCHAR DEFAULT NULL,
    p_zip VARCHAR DEFAULT NULL,
    p_brand VARCHAR DEFAULT NULL
)
    RETURNS TABLE
            (
                "CREATED_DATE"                TIMESTAMP_NTZ,
                "source_ref_num"              VARCHAR,
                "Account"                     VARCHAR,
                "fk_customerid"               NUMBER,
                "legal_name"                  VARCHAR,
                "first_name"                  VARCHAR,
                "last_name"                   VARCHAR,
                "TITLE"                       VARCHAR,
                "COMPANY_NAME"                VARCHAR,
                "EMAIL_PRIMARY"               VARCHAR,
                "EXTERNAL_EMAIL1"             VARCHAR,
                "EXTERNAL_EMAIL2"             VARCHAR,
                "EMAIL_SECONDARY"             VARCHAR,
                "phone1_input"                VARCHAR,
                "home_phone_primary_sms"      BOOLEAN,
                "home_phone_primary_pref"     BOOLEAN,
                "home_phone_primary_region"   VARCHAR,
                "phone2_input"                VARCHAR,
                "phone1_E164"                 VARCHAR,
                "phone2_E164"                 VARCHAR,
                "phone3_E164"                 VARCHAR,
                "phone4_E164"                 VARCHAR,
                "home_phone_secondary_sms"    BOOLEAN,
                "home_phone_secondary_pref"   BOOLEAN,
                "home_phone_secondary_region" VARCHAR,
                "phone3_input"                VARCHAR,
                "mobi_phone_primary_sms"      BOOLEAN,
                "mobi_phone_primary_pref"     BOOLEAN,
                "mobi_phone_primary_region"   VARCHAR,
                "phone4_input"                VARCHAR,
                "mobi_phone_secondary_sms"    BOOLEAN,
                "mobi_phone_secondary_pref"   BOOLEAN,
                "mobi_phone_secondary_region" VARCHAR,
                "ADDRESS_LINE_1"              VARCHAR,
                "ADDRESS_LINE_2"              VARCHAR,
                "CITY"                        VARCHAR,
                "STATE"                       VARCHAR,
                "POSTAL_CODE"                 VARCHAR,
                "COUNTRY_CODE"                VARCHAR,
                "CUST_TYPE"                   VARCHAR,
                "cust_tier"                   VARCHAR,
                "Number_of_Orders"            NUMBER,
                "TAX_EXEMPT_ACCOUNT"          VARCHAR,
                "tax_id"                      VARCHAR,
                "CATALOG_SUBSCRIBER"          VARCHAR,
                "email_subscriber"            VARCHAR,
                "IsNordstromCustomer"         BOOLEAN,
                "IsWilliamsonomaCustomer"     BOOLEAN,
                "business_cust"               BOOLEAN,
                "business_category"           VARCHAR,
                "Business_#_of_Locations"     NUMBER,
                "DesignTradeFlag"             BOOLEAN,
                "social_handle_facebook"      VARCHAR,
                "social_handle_instagram"     VARCHAR,
                "social_handle_twitter"       VARCHAR
            )
AS
$$
    SELECT DISTINCT dci.created_date,
                    dc.source_ref_num,
                    db.code                                                  AS account,
                    dci.fk_customerid,
                    dci.legal_name,
                    dci.first_name,
                    dci.last_name,
                    dci.title,
                    dci.company_name,
                    dci.email_primary,
                    dci.external_email1,
                    dci.external_email2,
                    dci.email_secondary,
                    COALESCE(dci.phone1_input, dci.home_phone_primary)       AS phone1_input,
                    dci.home_phone_primary_sms,
                    dci.home_phone_primary_pref,
                    dci.home_phone_primary_region,
                    COALESCE(dci.phone2_input, dci.home_phone_secondary)     AS phone2_input,
                    COALESCE(dci.phone1_e164, dci.home_phone_primary_e164)   AS phone1_e164,
                    COALESCE(dci.phone2_e164, dci.home_phone_secondary_e164) AS phone2_e164,
                    COALESCE(dci.phone3_e164, dci.mobi_phone_primary_e164)   AS phone3_e164,
                    COALESCE(dci.phone4_e164, dci.mobi_phone_secondary_e164) AS phone4_e164,
                    dci.home_phone_secondary_sms,
                    dci.home_phone_secondary_pref,
                    dci.home_phone_secondary_region,
                    COALESCE(dci.phone3_input, dci.mobi_phone_primary)       AS phone3_input,
                    dci.mobi_phone_primary_sms,
                    dci.mobi_phone_primary_pref,
                    dci.mobi_phone_primary_region,
                    COALESCE(dci.phone4_input, dci.mobi_phone_secondary)     AS phone4_input,
                    dci.mobi_phone_secondary_sms,
                    dci.mobi_phone_secondary_pref,
                    dci.mobi_phone_secondary_region,
                    dca.address_line_1,
                    dca.address_line_2,
                    dca.city,
                    dca.state,
                    dca.postal_code,
                    dca.country_code,
                    dci.cust_type,
                    dci.cust_tier,
                    COUNT(DISTINCT toh.source_ref_num)                       AS number_of_orders,
                    dci.tax_exempt_account,
                    dci.tax_id,
                    dci.catalog_subscriber,
                    dci.email_subscriber,
                    dci.isnordstromcustomer,
                    dci.iswilliamsonomacustomer,
                    dci.business_cust,
                    dci.business_category,
                    dci."BUSINESS_#_OF_LOCATIONS",
                    dci.designtradeflag,
                    dci.social_handle_facebook,
                    dci.social_handle_instagram,
                    dci.social_handle_twitter
    FROM analytics.customer AS dc
             JOIN master.dim_source AS ds ON dc.fk_sourceid = ds.pk_sourceid
             JOIN master.dim_brand AS db ON ds.fk_brandid = db.pk_brandid
             JOIN analytics.customer_info AS dci ON dc.pk_customerid = dci.fk_customerid
             LEFT JOIN analytics.customer_address AS dca ON dci.pk_customer_info_id = dca.fk_customer_info_id
             LEFT JOIN analytics.txn_order_header AS toh ON dc.pk_customerid = toh.fk_customerid
    WHERE (
        p_email IS NULL OR
        LOWER(TRIM(p_email)) IN (LOWER(TRIM(dci.email_primary)), LOWER(TRIM(dci.email_secondary)), LOWER(TRIM(dci.external_email1)), LOWER(TRIM(dci.external_email2)))
        )
      AND (
        p_source_ref_num IS NULL OR
        LOWER(TRIM(dc.source_ref_num)) = LOWER(TRIM(p_source_ref_num))
    )
      AND (
        p_firstname IS NULL OR
        LOWER(TRIM(dci.first_name)) = LOWER(TRIM(p_firstname))
        )
      AND (
        p_lastname IS NULL OR
        LOWER(TRIM(dci.last_name)) = LOWER(TRIM(p_lastname))
        )
      AND (
        p_phone IS NULL OR
        LOWER(TRIM(p_phone)) IN (
                                 LOWER(TRIM(dci.home_phone_primary)),
                                 LOWER(TRIM(dci.home_phone_secondary)),
                                 LOWER(TRIM(dci.mobi_phone_primary)),
                                 LOWER(TRIM(dci.mobi_phone_secondary)),
                                 LOWER(TRIM(dci.home_phone_primary_e164)),
                                 LOWER(TRIM(dci.home_phone_secondary_e164)),
                                 LOWER(TRIM(dci.mobi_phone_primary_e164)),
                                 LOWER(TRIM(dci.mobi_phone_secondary_e164)),
                                 LOWER(TRIM(dci.phone1_e164)),
                                 LOWER(TRIM(dci.phone1_input)),
                                 LOWER(TRIM(dci.phone2_e164)),
                                 LOWER(TRIM(dci.phone2_input)),
                                 LOWER(TRIM(dci.phone3_e164)),
                                 LOWER(TRIM(dci.phone3_input)),
                                 LOWER(TRIM(dci.phone4_e164)),
                                 LOWER(TRIM(dci.phone4_input))
            )
        )
      AND (
        p_zip IS NULL OR
        LOWER(TRIM(dca.postal_code)) = LOWER(TRIM(p_zip))
        )
      AND (
        p_brand IS NULL OR
        LOWER(TRIM(db.code)) = LOWER(TRIM(p_brand))
        )
    GROUP BY dc.source_ref_num,
             db.code,
             dci.fk_customerid,
             dci.legal_name,
             dci.first_name,
             dci.last_name,
             dci.title,
             dci.company_name,
             dci.email_primary,
             dci.external_email1,
             dci.external_email2,
             dci.email_secondary,
             dci.home_phone_primary,
             dci.home_phone_primary_sms,
             dci.home_phone_primary_pref,
             dci.home_phone_primary_region,
             dci.home_phone_secondary,
             dci.home_phone_secondary_sms,
             dci.home_phone_secondary_pref,
             dci.home_phone_secondary_region,
             dci.mobi_phone_primary,
             dci.mobi_phone_primary_sms,
             dci.mobi_phone_primary_pref,
             dci.mobi_phone_primary_region,
             dci.mobi_phone_secondary,
             dci.mobi_phone_secondary_sms,
             dci.mobi_phone_secondary_pref,
             dci.mobi_phone_secondary_region,
             dci.home_phone_primary_e164,
             dci.home_phone_secondary_e164,
             dci.mobi_phone_primary_e164,
             dci.mobi_phone_secondary_e164,
             dca.address_line_1,
             dca.address_line_2,
             dca.city,
             dca.state,
             dca.postal_code,
             dca.country_code,
             dci.cust_type,
             dci.cust_tier,
             dci.tax_exempt_account,
             dci.tax_id,
             dci.catalog_subscriber,
             dci.email_subscriber,
             dci.isnordstromcustomer,
             dci.iswilliamsonomacustomer,
             dci.business_cust,
             dci.business_category,
             dci."BUSINESS_#_OF_LOCATIONS",
             dci.designtradeflag,
             dci.social_handle_facebook,
             dci.social_handle_instagram,
             dci.social_handle_twitter,
             dci.created_date,
             dci.phone1_e164,
             dci.phone1_input,
             dci.phone2_e164,
             dci.phone2_input,
             dci.phone3_e164,
             dci.phone3_input,
             dci.phone4_e164,
             dci.phone4_input
    LIMIT 100
$$;