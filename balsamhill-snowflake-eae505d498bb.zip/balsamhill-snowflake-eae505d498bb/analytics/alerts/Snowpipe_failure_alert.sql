USE DATABASE BALSAM_EDW_DEV;

--check the table presence and data 

select * from ANALYTICS.EVENT_EMAIL_CONFIGURATION;

CREATE TABLE IF NOT EXISTS ANALYTICS.EVENT_EMAIL_CONFIGURATION (
   event STRING,                 
    recipient STRING,             
    frequency STRING,            
    priority STRING,             
    environment STRING,          
    subject_template STRING, 
    body_template STRING,
    integration_name STRING,
    module string
);

--insert emails and other data  into config table 

INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Snowpipe failure', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'prod', 'P1: Prod: Snowpipe failure ', 'Following data ingestion pipelines failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Snowpipe failure', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'qa', 'P1: QA: Snowpipe failure ', 'The following data ingestion pipelines are  failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Snowpipe failure', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'dev', 'P1: Dev: Snowpipe failure ', 'Following data ingestion pipelines failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');


-- Snowpipe failure
INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Snowpipe failure', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'prod', 'P1: Prod: Snowpipe failure ', 'Following data ingestion pipelines failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Snowpipe failure', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'qa', 'P1: QA: Snowpipe failure ', 'Following data ingestion pipelines failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Snowpipe failure', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'dev', 'P1: Dev: Snowpipe failure ', 'Following data ingestion pipelines failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');

INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Snowpipe failure', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'prod', 'P1: prod: Snowpipe failure ', 'Following data ingestion pipelines failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Snowpipe failure', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'qa', 'P1: QA: Snowpipe failure ', 'Following data ingestion pipelines failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Snowpipe failure', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'dev', 'P1: dev: Snowpipe failure ', 'Following data ingestion pipelines failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');
    
--alert creation

CREATE OR REPLACE ALERT ANALYTICS.SNOWPIPE_FAILURE 
  --WAREHOUSE = my_warehouse
  SCHEDULE = 'USING CRON 15 10 * * * UTC'
  --SCHEDULE = '30 MINUTE'
  IF (EXISTS
    (SELECT PIPE_NAME,TABLE_NAME,STAGE_LOCATION,FILE_NAME,LAST_LOAD_TIME
FROM
    SNOWFLAKE.ACCOUNT_USAGE.COPY_HISTORY 
    WHERE status !='Loaded' and 
     LAST_LOAD_TIME  between  DATEADD('day',-10,current_timestamp()) and current_timestamp()
    order by LAST_LOAD_TIME desc))  Then 

BEGIN

USE DATABASE BALSAM_EDW_DEV;


LET email_integration_name varchar :=  (select distinct integration_name from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Snowpipe failure' and environment='dev'  limit 1);

LET email_list varchar :=  (select LISTAGG(distinct recipient,',') from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Snowpipe failure' and environment='dev');

let email_subject varchar := (select DISTINCT subject_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Snowpipe failure' and environment='dev' limit 1);

let email_body_default  varchar := (select DISTINCT body_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Snowpipe failure' and environment='dev' limit 1);


	create or replace temp table analytics.result_json_data_pipe as 
select object_construct(*) as rows_ ,row_number() over (order by _LAST_LOAD_TIME desc) as rn from 
(SELECT
    PIPE_NAME,TABLE_NAME,STAGE_LOCATION as _STAGE_LOCATION,FILE_NAME as __FILE_NAME,LAST_LOAD_TIME as _LAST_LOAD_TIME
FROM
    SNOWFLAKE.ACCOUNT_USAGE.COPY_HISTORY 
    WHERE status !='Loaded' and PIPE_NAME is not null and 
     LAST_LOAD_TIME  between  DATEADD('day',-10,current_timestamp()) and current_timestamp()
     order by LAST_LOAD_TIME desc 
    );

  LET email_body varchar := (WITH ordered_data AS (
    SELECT rn, TO_VARIANT(rn || ':' || TO_JSON(rows_)) AS formatted_json
     FROM analytics.result_json_data_pipe
    ORDER BY rn)
SELECT LISTAGG(formatted_json,'\n\n') WITHIN GROUP (ORDER BY rn) AS merged_json FROM ordered_data);

CALL SYSTEM$SEND_EMAIL(
            :email_integration_name,
            :email_list,
            :email_subject,
            :email_body_default ||'\n\n'||:email_body);
return 'Email Alert Sent';
END;

--alert resume,suspend,execute 

alter alert ANALYTICS.SNOWPIPE_FAILURE resume;

alter alert ANALYTICS.SNOWPIPE_FAILURE suspend;

execute alert ANALYTICS.SNOWPIPE_FAILURE;

--if any changes required in config table 

select * from ANALYTICS.EVENT_EMAIL_CONFIGURATION where event ='Snowpipe failure';


UPDATE ANALYTICS.EVENT_EMAIL_CONFIGURATION set body_template='Following data ingestion pipelines failed :' where event='Snowpipe failure';
