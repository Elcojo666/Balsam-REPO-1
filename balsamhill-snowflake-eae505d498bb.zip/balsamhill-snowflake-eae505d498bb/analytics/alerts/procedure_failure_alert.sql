USE DATABASE BALSAM_EDW_DEV;

select * from ANALYTICS.EVENT_EMAIL_CONFIGURATION;

CREATE TABLE IF NOT EXISTS ANALYTICS.EVENT_EMAIL_CONFIGURATION (
   event STRING,                 
    recipient STRING,             
    frequency STRING,            
    priority STRING,             
    environment STRING,          
    subject_template STRING, 
    body_template STRING,
    integration_name STRING,
    module string
);


--insert emails and other data  into config table 

INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Procedure failure ', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'prod', 'P1: Prod: Procedure failure  ', 'Following data load stored procedures failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Procedure failure ', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'qa', 'P1: QA: Procedure failure  ', 'The following data load stored procedures are  failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Procedure failure ', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'dev', 'P1: Dev: Procedure failure  ', 'Following data load stored procedures failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');


-- Procedure failure 
INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Procedure failure ', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'prod', 'P1: Prod: Procedure failure  ', 'Following data load stored procedures failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Procedure failure ', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'qa', 'P1: QA: Procedure failure  ', 'Following data load stored procedures failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Procedure failure ', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'dev', 'P1: Dev: Procedure failure  ', 'Following data load stored procedures failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');

INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Procedure failure ', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'prod', 'P1: prod: Procedure failure  ', 'Following data load stored procedures failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Procedure failure ', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'qa', 'P1: QA: Procedure failure  ', 'Following data load stored procedures failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Procedure failure ', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'dev', 'P1: dev: Procedure failure  ', 'Following data load stored procedures failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');
    
--alert creation

CREATE OR REPLACE ALERT ANALYTICS.PROCEDURE_FAILURE 
  --WAREHOUSE = my_warehouse
  SCHEDULE = 'USING CRON 25 10 * * * UTC'
  --SCHEDULE = '30 MINUTE'
  IF (EXISTS
    (SELECT QUERY_ID,QUERY_TEXT,USER_NAME,START_TIME,END_TIME
        FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY 
        WHERE execution_status = 'FAIL' AND
         QUERY_TYPE='CALL' AND SCHEMA_ID <>4 AND 
         WAREHOUSE_SIZE IS NOT NULL AND 
         DATE(START_TIME) BETWEEN  dateadd('hour',-20,current_timestamp()) and current_timestamp()
         ORDER BY START_TIME DESC))  Then 

BEGIN

USE DATABASE BALSAM_EDW_DEV;


LET email_integration_name varchar :=  (select distinct integration_name from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Procedure failure ' and environment='dev'  limit 1);

LET email_list varchar :=  (select LISTAGG(distinct recipient,',') from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Procedure failure ' and environment='dev');

let email_subject varchar := (select DISTINCT subject_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Procedure failure ' and environment='dev' limit 1);

let email_body_default  varchar := (select DISTINCT body_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Procedure failure ' and environment='dev' limit 1);


	create or replace temp table analytics.result_json_data_sps as 
select object_construct(*) as rows_ ,row_number() over (order by __FAILED_AT desc) as rn from 
(SELECT QUERY_ID,left(QUERY_TEXT,200) as QUERY,USER_NAME,START_TIME AS _STARTED_AT,END_TIME AS __FAILED_AT
        FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY 
        WHERE execution_status = 'FAIL' AND
         QUERY_TYPE='CALL' AND SCHEMA_ID <>4 AND 
         WAREHOUSE_SIZE IS NOT NULL AND 
         DATE(START_TIME) BETWEEN  dateadd('hour',-20,current_timestamp()) and current_timestamp()
         ORDER BY START_TIME DESC 
    );

  LET email_body varchar := (WITH ordered_data AS (
    SELECT rn, TO_VARIANT(rn || ':' || TO_JSON(rows_)) AS formatted_json
     FROM analytics.result_json_data_sps
    ORDER BY rn)
SELECT LISTAGG(formatted_json,'\n\n') WITHIN GROUP (ORDER BY rn) AS merged_json FROM ordered_data);

CALL SYSTEM$SEND_EMAIL(
            :email_integration_name,
            :email_list,
            :email_subject,
            :email_body_default ||'\n\n'||:email_body);
return 'Email Alert Sent';
END;

--alert resume,suspend,execute 

alter alert ANALYTICS.PROCEDURE_FAILURE resume;

alter alert ANALYTICS.PROCEDURE_FAILURE suspend;

execute alert ANALYTICS.PROCEDURE_FAILURE;