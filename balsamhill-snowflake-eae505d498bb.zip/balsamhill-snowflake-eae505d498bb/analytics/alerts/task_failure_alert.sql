USE DATABASE BALSAM_EDW_DEV;

--check the table presence and data 

select * from ANALYTICS.EVENT_EMAIL_CONFIGURATION;

CREATE TABLE IF NOT EXISTS ANALYTICS.EVENT_EMAIL_CONFIGURATION (
   event STRING,                 
    recipient STRING,             
    frequency STRING,            
    priority STRING,             
    environment STRING,          
    subject_template STRING, 
    body_template STRING,
    integration_name STRING,
    module string
);

-- Task failure
INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Task failure', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'prod', 'P1: Prod: Task failure ', 'Following tasks failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Task failure', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'qa', 'P1: QA: Task failure ', 'Following tasks failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Task failure', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'dev', 'P1: Dev: Task failure ', 'Following tasks failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');


-- Task failure
INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Task failure', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'prod', 'P1: Prod: Task failure ', 'Following tasks failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Task failure', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'qa', 'P1: QA: Task failure ', 'Following tasks failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Task failure', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'dev', 'P1: Dev: Task failure ', 'Following tasks failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');

INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Task failure', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'prod', 'P1: Prod: Task failure ',
    'Following tasks failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Task failure', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'qa', 'P1: QA: Task failure ', 
    'Following tasks failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Task failure', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'dev', 'P1: Dev: Task failure ', 
    'Following tasks failed :','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');

--alert creation


CREATE OR REPLACE ALERT ANALYTICS.TASK_FAILURE 
  --WAREHOUSE = my_warehouse
  SCHEDULE = 'USING CRON 35 10 * * * UTC'
  --SCHEDULE = '30 MINUTE'
  IF (EXISTS
    (SELECT  QUERY_ID,DATABASE_NAME,SCHEMA_NAME,NAME AS TASK_NAME,
    STATE,ERROR_MESSAGE,QUERY_START_TIME,COMPLETED_TIME
     from (SELECT *
  FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
  ORDER BY SCHEDULED_TIME) 
  where SCHEDULED_TIME between  DATEADD('day',-20,current_timestamp()) and current_timestamp()
  and STATE='FAILED'))  Then 

BEGIN

USE DATABASE BALSAM_EDW_DEV;


LET email_integration_name varchar :=  (select distinct integration_name from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Task failure' and environment='dev'  limit 1);

LET email_list varchar :=  (select LISTAGG(distinct recipient,',') from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Task failure' and environment='dev');

let email_subject varchar := (select DISTINCT subject_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Task failure' and environment='dev' limit 1);

let email_body_default  varchar := (select DISTINCT body_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Task failure' and environment='dev' limit 1);

create or replace temp table analytics.result_json_data_task as 
select object_construct(*) as rows_ ,row_number() over (order by TASK_ID desc) as rn from 
(SELECT  NAME AS TASK_NAME,QUERY_ID as TASK_ID,QUERY_START_TIME AS TASK_STARTED_AT,COMPLETED_TIME AS TASK__FAILED_AT
     from (SELECT *
  FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
  ORDER BY SCHEDULED_TIME) 
  where SCHEDULED_TIME between  DATEADD('day',-20,current_timestamp()) and current_timestamp()
  and STATE='FAILED');

  LET email_body varchar := (WITH ordered_data AS (
    SELECT rn, TO_VARIANT(rn || ':' || TO_JSON(rows_)) AS formatted_json
     FROM analytics.result_json_data_task
    ORDER BY rn)
SELECT LISTAGG(formatted_json,'\n\n') WITHIN GROUP (ORDER BY rn) AS merged_json FROM ordered_data);

CALL SYSTEM$SEND_EMAIL(
            :email_integration_name,
            :email_list,
            :email_subject,
            :email_body_default ||'\n\n'||:email_body);
return 'Email Alert Sent';
END;

--Alert resume ,suspend,execute 


alter alert ANALYTICS.TASK_FAILURE resume;

alter alert ANALYTICS.TASK_FAILURE suspend;

execute alert ANALYTICS.TASK_FAILURE;

---Update event config table if required 

UPDATE ANALYTICS.EVENT_EMAIL_CONFIGURATION set body_template='Following tasks failed :' where event='Task failure';

select * from ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Task failure';

select * from ANALYTICS.EVENT_EMAIL_CONFIGURATION;