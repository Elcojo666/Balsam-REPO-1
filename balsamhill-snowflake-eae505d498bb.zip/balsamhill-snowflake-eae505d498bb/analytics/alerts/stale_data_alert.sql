USE DATABASE BALSAM_EDW_DEV;

select * from ANALYTICS.EVENT_EMAIL_CONFIGURATION;

CREATE TABLE IF NOT EXISTS ANALYTICS.EVENT_EMAIL_CONFIGURATION (
   event STRING,                 
    recipient STRING,             
    frequency STRING,            
    priority STRING,             
    environment STRING,          
    subject_template STRING, 
    body_template STRING,
    integration_name STRING,
    module string
);




--insert parameters

INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Stale Data', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'prod', 'P1: Prod: Stale Data ', 'We have not received data for the following tables in the past ','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Stale Data', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'qa', 'P1: QA: Stale Data ', 'We have not received data for the following tables in the past .','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Stale Data', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'dev', 'P1: Dev: Stale Data ', 'We have not received data for the following tables in the past ','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');


-- Stale Data
INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Stale Data', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'prod', 'P1: Prod: Stale Data ', 'We have not received data for the following tables in the past ','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Stale Data', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'qa', 'P1: QA: Stale Data ', 'We have not received data for the following tables in the past ','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Stale Data', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'dev', 'P1: Dev: Stale Data ', 'We have not received data for the following tables in the past ','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');

INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Stale Data', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'prod', 'P1: prod: Stale Data ', 'We have not received data for the following tables in the past ','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Stale Data', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'qa', 'P1: QA: Stale Data ', 'We have not received data for the following tables in the past ','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Stale Data', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'dev', 'P1: dev: Stale Data ', 'We have not received data for the following tables in the past ','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');

--create tables for alert input 

create table ANALYTICS.STALE_DATA_TABLES
(TABLE_NAME STRING,LAST_UPDATED TIMESTAMP_NTZ(9),CURRENT_DATETIME TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP());

--create table to load all tables to check for stale data 

create or replace TABLE ANALYTICS.TABLES_FOR_FRESHNESS (
	TABLE_NAME VARCHAR(16777216),
	STALE_THRESHOLD NUMBER(38,0)
);

insert into ANALYTICS.TABLES_FOR_FRESHNESS ('table-name',number);

--set new threshold if needed 

update   ANALYTICS.TABLES_FOR_FRESHNESS set stale_threshold= 24;


--creating stored  proc 

CALL analytics.usp_check_stale_data_tables();

CREATE OR REPLACE PROCEDURE analytics.usp_check_stale_data_tables()
RETURNS STRING
LANGUAGE SQL
AS
DECLARE
    table_name STRING;
    last_updated TIMESTAMP;
    stale_table_count number ;
    stale_threshold number default (select max(stale_threshold) from  ANALYTICS.TABLES_FOR_FRESHNESS);
    cursor CURSOR FOR (
        SELECT
            table_name,
            last_altered AS last_updated
        FROM
            information_schema.tables where table_name in 
            (select distinct table_name from  ANALYTICS.TABLES_FOR_FRESHNESS));
BEGIN


LET email_integration_name varchar :=  (select distinct integration_name from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Stale Data' and environment='dev'  limit 1);

LET email_list varchar :=  (select LISTAGG(distinct recipient,',') from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Stale Data' and environment='dev');

let email_subject varchar := (select DISTINCT subject_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Stale Data' and environment='dev' limit 1);

let email_body_default  varchar := (select DISTINCT body_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Stale Data' and environment='dev' limit 1);

truncate table ANALYTICS.stale_data_tables;

    -- Open cursor and fetch rows one by one
    FOR rec IN cursor DO
        -- Fetch the values from the cursor into local variables
        table_name := rec.table_name;
        last_updated := rec.last_updated;
        
        -- Check if the table is stale based on the threshold (in hours)
        IF (DATEDIFF('hour', :last_updated, CURRENT_TIMESTAMP()) > :stale_threshold) THEN 
            -- Insert stale table names into the tracking table         
            INSERT INTO ANALYTICS.stale_data_tables (table_name, last_updated)
            VALUES (:table_name, :last_updated);
        END IF;
    END FOR;
     select count(*) into :stale_table_count  FROM ANALYTICS.stale_data_tables;
     
     IF (:stale_table_count>0) THEN 
     
      create or replace temp table analytics.result_json_data_stale as 
select object_construct(*) as rows_ ,row_number() over (order by _LAST_UPDATED desc) as rn from 
(select TABLE_NAME,LAST_UPDATED AS _LAST_UPDATED,CURRENT_DATETIME AS __CURRENT_DATETIME from ANALYTICS.stale_data_tables);

  LET email_body varchar := (WITH ordered_data AS (
    SELECT rn, TO_VARIANT(rn || ':' || TO_JSON(rows_)) AS formatted_json
     FROM analytics.result_json_data_stale
    ORDER BY rn)
SELECT LISTAGG(formatted_json,'\n\n') WITHIN GROUP (ORDER BY rn) AS merged_json FROM ordered_data);

CALL SYSTEM$SEND_EMAIL(
            :email_integration_name,
            :email_list,
            :email_subject,
            :email_body_default ||' '||:stale_threshold||' Hours.'||'\n\n'||:email_body);
      END IF;
      
    RETURN 'Stale table check completed.';
END;


--running stored proc with schedule 


CREATE OR REPLACE TASK ANALYTICS.STALE_DATA_NOTIFY_TASK
  SCHEDULE = 'USING CRON 51 12 * * * UTC'
  USER_TASK_MANAGED_INITIAL_WAREHOUSE_SIZE = 'SMALL' 
  AS
  BEGIN 
   USE DATABASE BALSAM_EDW_DEV;
  call  analytics.usp_check_stale_data_tables();
  END;

--task enable 

ALTER TASK ANALYTICS.STALE_DATA_NOTIFY_TASK RESUME;

ALTER TASK ANALYTICS.STALE_DATA_NOTIFY_TASK SUSPEND;

EXECUTE  TASK ANALYTICS.STALE_DATA_NOTIFY_TASK;