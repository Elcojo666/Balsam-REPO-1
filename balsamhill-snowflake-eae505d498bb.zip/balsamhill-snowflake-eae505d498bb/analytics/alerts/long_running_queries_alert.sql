USE DATABASE BALSAM_EDW_DEV;

--Create configuration table 

CREATE  TABLE IF NOT EXISTS ANALYTICS.EVENT_EMAIL_CONFIGURATION (
   event STRING,                 
    recipient STRING,             
    frequency STRING,            
    priority STRING,             
    environment STRING,          
    subject_template STRING, 
    body_template STRING,
    integration_name STRING,
    module string
);

--Inserting the data into configuration table 

INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Long Running queries', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'prod', 'P1: Prod: Long running queries ', 'These queries are taking too long to run:','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Long Running queries', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'qa', 'P1: QA: Long running queries ', 'These queries are taking too long to run:','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Long Running queries', 'lava.kumar@balsambrands.com', 'immediate', 'P1', 'dev', 'P1: Dev: Long running queries ', 'These queries are taking too long to run:','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');


-- Long query time
INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Long Running queries', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'prod', 'P1: Prod: Long running queries ', 'These queries are taking too long to run:','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Long Running queries', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'qa', 'P1: QA: Long running queries ', 'These queries are taking too long to run:','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Long Running queries', 'angel.rodriguez@balsambrands.com', 'immediate', 'P1', 'dev', 'P1: Dev: Long running queries ', 'These queries are taking too long to run:','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');

INSERT INTO ANALYTICS.EVENT_EMAIL_CONFIGURATION (event, recipient, frequency, priority, environment, subject_template, body_template,integration_name,module)
VALUES
    ('Long Running queries', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'prod', 'P1: Prod: Long running queries ', 'These queries are taking too long to run:','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Long Running queries', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'qa', 'P1: QA: Long running queries ', 'These queries are taking too long to run:','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders'),
    ('Long Running queries', 'data-engineering-aaaam5epcqqvjetzjmmj4caftq@balsam.slack.com', 'immediate', 'P1', 'dev', 'P1: Dev: Long running queries ', 'These queries are taking too long to run:','BALSAM_OMS_ORDERS_TASK_STATUS_EMAIL_INT_DEV','orders');


--create alert, Note: Conditions must be vefiried and set accordingly .


CREATE OR REPLACE ALERT ANALYTICS.LONG_RUNNING_QUERIES 
  --WAREHOUSE = my_warehouse
  SCHEDULE = 'USING CRON 31 10 * * * UTC'
  --SCHEDULE = '30 MINUTE'
  IF (EXISTS

    (WITH QH1 AS (select QUERY_ID,  SUBSTRING(TRIM(QUERY_TEXT),1,300) AS QRYTXT,

WAREHOUSE_NAME, WAREHOUSE_SIZE,START_TIME,USER_NAME,

round(CASE 
     WHEN warehouse_size='X-Small' then (execution_time/(1000*60))

     WHEN warehouse_size='Small' then (execution_time/(1000))*2

     WHEN warehouse_size='Medium' then (execution_time/(1000))*4

     WHEN warehouse_size='Large' then (execution_time/(1000))*8

     WHEN warehouse_size='X-Large' then (execution_time/(1000))*16

     WHEN warehouse_size='2X-Large' then (execution_time/(1000))*32

     WHEN warehouse_size='3X-Large' then (execution_time/(1000))*64  

     WHEN warehouse_size='4X-Large' then (execution_time/(1000))*128

     WHEN warehouse_size='5X-Large' then (execution_time/(1000))*256

     WHEN warehouse_size='6X-Large' then (execution_time/(1000))*512

END) as WEIGHTED_TIME_SECONDS,

(TO_CHAR(TRUNC((WEIGHTED_TIME_SECONDS)/3600),'FM9900')|| ':' ||TO_CHAR(TRUNC(MOD((WEIGHTED_TIME_SECONDS),3600)/60),'FM00')|| ':' || TO_CHAR(MOD((WEIGHTED_TIME_SECONDS),60),'FM00')) AS WEIGHTED_RUN_TIME

,(TO_CHAR(TRUNC((EXECUTION_TIME/1000)/3600),'FM9900')|| ':' ||TO_CHAR(TRUNC(MOD((EXECUTION_TIME/1000),3600)/60),'FM00')|| ':' || TO_CHAR(MOD((EXECUTION_TIME/1000),60),'FM00')) AS ACTUAL_RUN_TIME

from snowflake.account_usage.query_history
where 
--execution_status='RUNNING' and 
execution_time != 0
and USER_NAME<>'SYSTEM'
and weighted_time_seconds > 10
order by weighted_time_seconds desc)

SELECT QUERY_ID, WAREHOUSE_NAME, WAREHOUSE_SIZE,START_TIME,USER_NAME,WEIGHTED_RUN_TIME,ACTUAL_RUN_TIME,QRYTXT

       FROM QH1 where QRYTXT is not null)) Then 

BEGIN

USE DATABASE BALSAM_EDW_DEV;


LET email_integration_name varchar :=  (select distinct integration_name from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Long Running queries' and environment='dev' limit 1);

LET email_list varchar :=  (select LISTAGG(distinct recipient,',') from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Long Running queries' and environment='dev');

let email_subject varchar := (select DISTINCT subject_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Long Running queries' and environment='dev' limit 1);

let email_body_default  varchar := (select DISTINCT body_template from  ANALYTICS.EVENT_EMAIL_CONFIGURATION where event='Long Running queries' and environment='dev' limit 1);

create or replace temp table analytics.result_json_data as 
select object_construct(*) as rows_ ,row_number() over (order by weighted_time_seconds desc) as rn from 
(WITH QH1 AS (select QUERY_ID,  left(TRIM(QUERY_TEXT),150) AS QRYTXT,

WAREHOUSE_NAME, WAREHOUSE_SIZE,START_TIME,USER_NAME,

round(CASE WHEN warehouse_size='X-Small' then (execution_time/(1000*60))

     WHEN warehouse_size='Small' then (execution_time/(1000))*2

     WHEN warehouse_size='Medium' then (execution_time/(1000))*4

     WHEN warehouse_size='Large' then (execution_time/(1000))*8

     WHEN warehouse_size='X-Large' then (execution_time/(1000))*16

     WHEN warehouse_size='2X-Large' then (execution_time/(1000))*32

     WHEN warehouse_size='3X-Large' then (execution_time/(1000))*64  

     WHEN warehouse_size='4X-Large' then (execution_time/(1000))*128

     WHEN warehouse_size='5X-Large' then (execution_time/(1000))*256

     WHEN warehouse_size='6X-Large' then (execution_time/(1000))*512

END) as WEIGHTED_TIME_SECONDS,

(TO_CHAR(TRUNC((WEIGHTED_TIME_SECONDS)/3600),'FM9900')|| ':' ||TO_CHAR(TRUNC(MOD((WEIGHTED_TIME_SECONDS),3600)/60),'FM00')|| ':' || TO_CHAR(MOD((WEIGHTED_TIME_SECONDS),60),'FM00')) AS WEIGHTED_RUN_TIME

,(TO_CHAR(TRUNC((EXECUTION_TIME/1000)/3600),'FM9900')|| ':' ||TO_CHAR(TRUNC(MOD((EXECUTION_TIME/1000),3600)/60),'FM00')|| ':' || TO_CHAR(MOD((EXECUTION_TIME/1000),60),'FM00')) AS ACTUAL_RUN_TIME

from snowflake.account_usage.query_history

where 
--execution_status='RUNNING' and 
execution_time != 0

and USER_NAME<>'SYSTEM'

and weighted_time_seconds > 30
order by weighted_time_seconds desc)

SELECT QUERY_ID,START_TIME,USER_NAME,weighted_time_seconds,WEIGHTED_RUN_TIME

       FROM QH1 order by weighted_time_seconds desc ) order by rn ;
  
LET email_body varchar := (WITH ordered_data AS (
    SELECT rn, TO_VARIANT(rn || ':' || TO_JSON(rows_)) AS formatted_json
     FROM analytics.result_json_data
    ORDER BY rn)
SELECT LISTAGG(formatted_json,'\n\n') WITHIN GROUP (ORDER BY rn) AS merged_json FROM ordered_data);

CALL SYSTEM$SEND_EMAIL(
            :email_integration_name,
            :email_list,
            :email_subject,
            :email_body_default ||'\n\n'||:email_body);
return 'Email Alert Sent';
END;

--Altering alert to resume , suspend and run immediately 

alter alert ANALYTICS.LONG_RUNNING_QUERIES resume;

alter alert ANALYTICS.LONG_RUNNING_QUERIES suspend;

execute alert ANALYTICS.LONG_RUNNING_QUERIES;