USE DATABASE BALSAM_EDW_DEV;

CREATE OR REPLACE ALERT ANALYTICS.ACCOUNT_WIDE_CREDIT_CONSUMPTION_REPORT
SCHEDULE = 'USING CRON 0 19 * * 4 UTC'  -- Runs every Thursday at 12 noon PST
IF 
(EXISTS
    (SELECT CEIL(SUM(CREDITS_USED), 2) || ' Total Credits '  ||
                    ' ( ' || CEIL(SUM(CREDITS_USED_COMPUTE), 2) || ' Compute Credits and ' || 
                        CEIL(SUM(CREDITS_USED_CLOUD_SERVICES), 2) || ' Cloude Service Credits )' AS credit_consumption
        FROM "SNOWFLAKE"."ACCOUNT_USAGE"."WAREHOUSE_METERING_HISTORY")) THEN
BEGIN 
    LET current_month := EXTRACT(MONTH FROM CURRENT_DATE());

    IF (current_month BETWEEN 3 AND 8) THEN
        IF (DAYOFMONTH(CURRENT_DATE()) <= 7) THEN -- once a month off-season
            CALL ANALYTICS.SP_NOTIFY_EMAIL_CREDIT_CONSUMPTION();
        END IF;
    ELSE 
        CALL ANALYTICS.SP_NOTIFY_EMAIL_CREDIT_CONSUMPTION();
    END IF
    ; 
END 
;