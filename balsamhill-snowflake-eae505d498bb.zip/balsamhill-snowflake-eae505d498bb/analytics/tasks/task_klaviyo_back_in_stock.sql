/**
 * Task Name: analytics.task_klaviyo_back_in_stock
 *
 * Description:
 * This task schedules the execution of the `usp_klaviyo_back_in_stock_upsert` stored procedure.
 * It logs the start and completion of the task, and handles any exceptions by rolling back the transaction,
 * logging the error, and returning the error object.
 *
 * Schedule:
 * - Runs daily at 7 AM PST.
 *
 * Execution Flow:
 * 1. Logs the start of the task.
 * 2. Calls the `usp_stg_klaviyo_back_in_stock_insert` procedure to stage data.
 * 3. Calls the `usp_klaviyo_back_in_stock_upsert` procedure to upsert data.
 * 4. Commits the transaction.
 * 5. Handles any exceptions by rolling back the transaction, logging the error, and returning the error object.
 * 6. Logs the completion of the task.
 * 7. Returns a message indicating the success of the task.
 */
CREATE TASK analytics.task_klaviyo_back_in_stock
    WAREHOUSE = dev_eng
    SCHEDULE = 'USING CRON 0 7 * * * PST'
    TRACE_LEVEL = 'ALWAYS'
    LOG_LEVEL = 'TRACE'
AS
DECLARE
    task_name VARCHAR := 'task_klaviyo_back_in_stock';
    task_start_time TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    error_object VARIANT;
BEGIN
    SYSTEM$LOG('TRACE','TASK STARTED - ' || task_name);

    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :task_name,
            'task',
            'started',
            :task_start_time,
            NULL,
            'Task started');

    BEGIN

        // staging
        CALL transformed.usp_stg_klaviyo_back_in_stock_insert();
        // load
        CALL analytics.usp_klaviyo_back_in_stock_upsert();

        COMMIT;
    EXCEPTION
        WHEN statement_error THEN
            ROLLBACK;

            error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                             'SQLCODE', sqlcode,
                                             'SQLERRM', sqlerrm,
                                             'SQLSTATE', sqlstate);

            CALL transformed.insert_into_log_pipeline_tasks_execution_details(
                    :task_name,
                    'task',
                    'failed',
                    :task_start_time,
                    CURRENT_TIMESTAMP(),
                    TO_JSON(:error_object));


            SYSTEM$LOG('ERROR','TASK FAILED - ' || task_name);

            RETURN error_object;
    END;

    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :task_name,
            'task',
            'completed',
            :task_start_time,
            CURRENT_TIMESTAMP(),
            'Task completed successfully');

    SYSTEM$LOG('TRACE','TASK COMPLETED - ' || task_name);

    RETURN 'Task ' || task_name || ' completed successfully';
END;

ALTER TASK analytics.task_klaviyo_back_in_stock RESUME;