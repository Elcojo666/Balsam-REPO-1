USE DATABASE DEV;
USE SCHEMA ANALYTICS;

CREATE OR REPLACE TASK ANALYTICS.TASK_REFRESH_GLADLY_BRIDGE_HDR
    WAREHOUSE = DEV_ENG
    SCHEDULE  = 'USING CRON 0 0,12 * * * UTC'
    TRACE_LEVEL = 'ALWAYS'
    LOG_LEVEL   = 'TRACE'
AS
DECLARE
task_name        VARCHAR := 'gladly_bridge_hdr';
task_start_time  TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
error_object     VARIANT;
BEGIN
    SYSTEM$LOG('TRACE', 'TASK STARTED - ' || task_name);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :task_name,
            'task',
            'started',
            :task_start_time,
            NULL,
            'Task started'
         );

BEGIN

CALL ANALYTICS.USP_REFRESH_GLADLY_DETAILED_LOOKUP_BRIDGE_HDR();

COMMIT;
EXCEPTION
        WHEN statement_error THEN
            ROLLBACK;

            error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                             'SQLCODE', SQLCODE,
                                             'SQLERRM', SQLERRM,
                                             'SQLSTATE', SQLSTATE);

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
                    :task_name,
                    'task',
                    'failed',
                    :task_start_time,
                    CURRENT_TIMESTAMP(),
                    TO_JSON(:error_object)
                 );

SYSTEM$LOG('ERROR','TASK FAILED - ' || task_name);

RETURN error_object;
END;

CALL TRANSFORMED.INSERT_INTO_LOG_PIPELINE_TASKS_EXECUTION_DETAILS(
            :task_name,
            'task',
            'completed',
            :task_start_time,
            CURRENT_TIMESTAMP(),
            'Task completed successfully');

SYSTEM$LOG('TRACE', 'TASK COMPLETED - ' || task_name);

RETURN 'Task ' || task_name || ' completed successfully';
END;

ALTER TASK ANALYTICS.TASK_REFRESH_GLADLY_BRIDGE_HDR RESUME;