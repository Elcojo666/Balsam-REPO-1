create or replace task PRE_PROD.ANALYTICS.UPDATE_LSDIRECT_EXPORTS 
	warehouse=PRE_PROD_ENG
	schedule='USING CRON 0 14 * * * UTC'
	TRACE_LEVEL='ALWAYS'
	LOG_LEVEL='TRACE'
	as 
DECLARE
task_name VARCHAR := 'UPDATE_LSDIRECT_EXPORTS';
task_start_time TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
error_object VARIANT;
BEGIN
SYSTEM$LOG('TRACE',:TASK_NAME || ' Task Has Been Started');

SYSTEM$LOG('TRACE', 'Insert and Truncate LSDIRECT Tables');
CALL ANALYTICS.USP_INSERT_AND_TRUNCATE_LSDIRECT_CUSTOMERS_EXPORT();
CALL ANALYTICS.USP_INSERT_AND_TRUNCATE_LSDIRECT_TRANSACTIONS_EXPORT();
SYSTEM$LOG('TRACE', 'LSDIRECT Tables Updated');

SYSTEM$LOG('TRACE', 'Export LSDIRECT Tables to Files in S3');
CALL ANALYTICS.USP_EXPORT_LSDIRECT_customerS();
CALL ANALYTICS.USP_EXPORT_LSDIRECT_transactionS();
SYSTEM$LOG('TRACE', 'Export LSDIRECT Tables Complete');

SYSTEM$LOG('TRACE',:TASK_NAME || ' Task Has Completed');
  RETURN 'Task Successfully Completed';
  
EXCEPTION
    WHEN STATEMENT_ERROR THEN
    ROLLBACK;
    
    SYSTEM$LOG('ERROR','Task: ' ||:TASK_NAME|| ' : Failed and The Error Message is : ' || :SQLERRM);
            -- RETURN ERROR MESSAGE
    RETURN 'Task Has Been Failed  Due To Error:  '|| :SQLERRM;
END;
;