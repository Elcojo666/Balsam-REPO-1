USE DATABASE dev;
USE SCHEMA analytics;

CREATE OR REPLACE TASK analytics.task_load_gladly_conversation
    WAREHOUSE = dev_eng
    -- SCHEDULE = 'USING CRON 20 7,16 * * * UTC' --revisar
    TRACE_LEVEL = 'ALWAYS'
    LOG_LEVEL = 'TRACE'
    AS
    DECLARE
    task_name VARCHAR := 'gladly_conversation';
task_start_time TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
error_object VARIANT;
BEGIN
    SYSTEM$LOG('TRACE', 'TASK STARTED - ' || task_name);

    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :task_name,
            'task',
            'started',
            :task_start_time,
            NULL,
            'Task started');

    BEGIN

        CALL raw.usp_load_gladly_conversation();
        CALL transformed.usp_insert_stg_gladly_conversation();
        CALL analytics.usp_merge_gladly_conversation();

        COMMIT;
    EXCEPTION
        WHEN statement_error THEN
            ROLLBACK;

            error_object := OBJECT_CONSTRUCT('Error type', 'STATEMENT_ERROR',
                                             'SQLCODE', sqlcode,
                                             'SQLERRM', sqlerrm,
                                             'SQLSTATE', sqlstate);

            CALL transformed.insert_into_log_pipeline_tasks_execution_details(
                    :task_name,
                    'task',
                    'failed',
                    :task_start_time,
                    CURRENT_TIMESTAMP(),
                    TO_JSON(:error_object));

            SYSTEM$LOG('ERROR','TASK FAILED - ' || task_name);

            RETURN error_object;
    END;

    CALL transformed.insert_into_log_pipeline_tasks_execution_details(
            :task_name,
            'task',
            'completed',
            :task_start_time,
            CURRENT_TIMESTAMP(),
            'Task completed successfully');

    SYSTEM$LOG('TRACE', 'TASK COMPLETED - ' || task_name);

    RETURN 'Task ' || task_name || ' completed successfully';
END;