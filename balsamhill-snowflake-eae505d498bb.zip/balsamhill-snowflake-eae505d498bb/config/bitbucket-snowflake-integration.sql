--use database and schema for object creation

USE DATABASE BALSAM_EDW_DEV;
USE SCHEMA TRANSFORMED;

--create secrets

CREATE SECRET dev_bitbucket_secret
    TYPE = password
    USERNAME = 'lavakumar1'
    PASSWORD = 'ATBBCexusW4yHLJGQqUSTUNHGd6MAF516F57';

    show secrets;

-- create api integration 

create or replace api integration dev_bitbucket_api_integration
    api_provider= git_https_api
    api_allowed_prefixes=('https://bitbucket.org/balsamhill/')
    allowed_authentication_secrets= (dev_bitbucket_secret)
    enabled=true;

    show integrations;

--create git repository

CREATE OR REPLACE GIT REPOSITORY dev_bitbucket_snowflake_repository
  API_INTEGRATION = dev_bitbucket_api_integration
  GIT_CREDENTIALS = dev_bitbucket_secret
  ORIGIN = 'https://bitbucket.org/balsamhill/snowflake';

  show git repositories;

  desc GIT REPOSITORY dev_bitbucket_snowflake_repository;

--list all available files from repository

  ls @dev_bitbucket_snowflake_repository/branches/main;

-- show available branches in repository

   show git branches in GIT REPOSITORY dev_bitbucket_snowflake_repository;

  show git tags in GIT REPOSITORY dev_bitbucket_snowflake_repository;

--Fetch all files from repository

  alter GIT REPOSITORY dev_bitbucket_snowflake_repository fetch;

-- execute the code from repository 

  execute immediate from @dev_bitbucket_snowflake_repository/branches/main/stg_oms_order_header.sql;

  



  




  