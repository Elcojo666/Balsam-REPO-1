USE ROLE ACCOUNTADMIN;

-- TRANSFER OWNERSHIP 
GRANT OWNERSHIP ON ALL EXTERNAL TABLES IN DATABASE PRE_PROD TO ROLE DATA_ENGINEER COPY CURRENT GRANTS;

GRANT OWNERSHIP ON ALL FILE FORMATS IN DATABASE PRE_PROD TO ROLE DATA_ENGINEER COPY CURRENT GRANTS;

GRANT OWNERSHIP ON ALL STAGES IN DATABASE PRE_PROD TO ROLE DATA_ENGINEER COPY CURRENT GRANTS;

GRANT OWNERSHIP ON ALL TABLES IN DATABASE PRE_PROD TO ROLE DATA_ENGINEER COPY CURRENT GRANTS;

GRANT OWNERSHIP ON ALL STREAMS IN DATABASE PRE_PROD TO ROLE DATA_ENGINEER COPY CURRENT GRANTS;

GRANT OWNERSHIP ON ALL VIEWS IN DATABASE PRE_PROD TO ROLE DATA_ENGINEER COPY CURRENT GRANTS;

GRANT OWNERSHIP ON ALL TASKS IN DATABASE PRE_PROD TO ROLE DATA_ENGINEER COPY CURRENT GRANTS;

GRANT OWNERSHIP ON ALL FUNCTIONS IN DATABASE PRE_PROD TO ROLE DATA_ENGINEER COPY CURRENT GRANTS;

GRANT OWNERSHIP ON ALL ALERTS IN DATABASE PRE_PROD TO ROLE DATA_ENGINEER COPY CURRENT GRANTS;

CREATE SCHEMA IF NOT EXISTS PRE_PROD.ADMIN;
    
CREATE OR REPLACE PROCEDURE PRE_PROD.ADMIN.BULK_GRANT_PIPE_OWNERSHIP()
RETURNS STRING
LANGUAGE PYTHON
RUNTIME_VERSION = '3.8'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'run_all'
EXECUTE AS CALLER
AS
$$
def run_all(session):
    # 1) Query all pipes in the PRE_PROD database
    pipes = session.sql("""
        SELECT PIPE_CATALOG, PIPE_SCHEMA, PIPE_NAME
          FROM INFORMATION_SCHEMA.PIPES
         WHERE PIPE_CATALOG = 'PRE_PROD'
    """).collect()

    for pipe_rec in pipes:
        pipe_catalog = pipe_rec['PIPE_CATALOG']  
        pipe_schema  = pipe_rec['PIPE_SCHEMA']
        pipe_name    = pipe_rec['PIPE_NAME']

        # (A) Pause the pipe
        stmt_pause = f'''
            ALTER PIPE "{pipe_catalog}"."{pipe_schema}"."{pipe_name}"
            SET PIPE_EXECUTION_PAUSED = TRUE
        '''
        session.sql(stmt_pause).collect()

        # (B) Transfer ownership to DATA_ENGINEER
        stmt_own = f'''
            GRANT OWNERSHIP ON PIPE "{pipe_catalog}"."{pipe_schema}"."{pipe_name}"
            TO ROLE DATA_ENGINEER
            COPY CURRENT GRANTS
        '''
        session.sql(stmt_own).collect()

        # (C) Grant all on the pipe to ACCOUNTADMIN
        stmt_usage = f'''
            GRANT ALL ON PIPE "{pipe_catalog}"."{pipe_schema}"."{pipe_name}"
            TO ROLE ACCOUNTADMIN
        '''
        session.sql(stmt_usage).collect()

        # (D) Force-resume the pipe
        #    Normal 'ALTER PIPE ... SET PIPE_EXECUTION_PAUSED = FALSE' won't work
        #    after an ownership change.
        stmt_force_resume = f'''
            SELECT SYSTEM$PIPE_FORCE_RESUME('{pipe_catalog}.{pipe_schema}.{pipe_name}');
        '''
        session.sql(stmt_force_resume).collect()

    return "Ownership transferred to DATA_ENGINEER, USAGE granted to ACCOUNTADMIN, pipes paused, and force-resumed."
$$;

CALL PRE_PROD.ADMIN.BULK_GRANT_PIPE_OWNERSHIP();

