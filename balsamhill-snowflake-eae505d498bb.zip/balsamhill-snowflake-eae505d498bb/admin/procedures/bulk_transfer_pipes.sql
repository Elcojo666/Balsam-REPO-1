CREATE OR REPLACE PROCEDURE DEV.ADMIN.BULK_GRANT_PIPE_OWNERSHIP()
RETURNS STRING
LANGUAGE PYTHON
RUNTIME_VERSION = '3.8'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'run_all'
EXECUTE AS CALLER
AS
$$
def run_all(session):
    # 1) Query all pipes in the DEV database
    pipes = session.sql("""
        SELECT PIPE_CATALOG, PIPE_SCHEMA, PIPE_NAME
          FROM INFORMATION_SCHEMA.PIPES
         WHERE PIPE_CATALOG = 'DEV'
    """).collect()

    for pipe_rec in pipes:
        pipe_catalog = pipe_rec['PIPE_CATALOG']  
        pipe_schema  = pipe_rec['PIPE_SCHEMA']
        pipe_name    = pipe_rec['PIPE_NAME']

        # (A) Pause the pipe
        stmt_pause = f'''
            ALTER PIPE "{pipe_catalog}"."{pipe_schema}"."{pipe_name}"
            SET PIPE_EXECUTION_PAUSED = TRUE
        '''
        session.sql(stmt_pause).collect()

        # (B) Transfer ownership to DATA_ENGINEER
        stmt_own = f'''
            GRANT OWNERSHIP ON PIPE "{pipe_catalog}"."{pipe_schema}"."{pipe_name}"
            TO ROLE DATA_ENGINEER
            COPY CURRENT GRANTS
        '''
        session.sql(stmt_own).collect()

        # (C) Grant all on the pipe to ACCOUNTADMIN
        stmt_usage = f'''
            GRANT ALL ON PIPE "{pipe_catalog}"."{pipe_schema}"."{pipe_name}"
            TO ROLE ACCOUNTADMIN
        '''
        session.sql(stmt_usage).collect()

        # (D) Force-resume the pipe
        #    Normal 'ALTER PIPE ... SET PIPE_EXECUTION_PAUSED = FALSE' won't work
        #    after an ownership change.
        stmt_force_resume = f'''
            SELECT SYSTEM$PIPE_FORCE_RESUME('{pipe_catalog}.{pipe_schema}.{pipe_name}');
        '''
        session.sql(stmt_force_resume).collect()

    return "Ownership transferred to DATA_ENGINEER, USAGE granted to ACCOUNTADMIN, pipes paused, and force-resumed."
$$;
