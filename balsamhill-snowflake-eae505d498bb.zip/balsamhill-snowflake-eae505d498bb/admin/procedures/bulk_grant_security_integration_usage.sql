CREATE OR REPLACE PROCEDURE DEV.ADMIN.BULK_GRANT_SECURITY_INTEGRATION_USAGE()
RETURNS STRING
LANGUAGE PYTHON
RUNTIME_VERSION = '3.8'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'run_sp'
EXECUTE AS CALLER
AS
$$
def run_sp(session):
    # 1. Get all security integrations
    security_integrations = session.sql("SHOW INTEGRATIONS").collect()

    # 2. For each integration, grant USAGE to DATA_ENGINEER
    for row in security_integrations:
        # The 'NAME' column is typically uppercase in the result of SHOW SECURITY INTEGRATIONS
        integration_name = row['name']

        grant_stmt = f'GRANT USAGE ON INTEGRATION "{integration_name}" TO ROLE DATA_ENGINEER'
        session.sql(grant_stmt).collect()

    return "Successfully granted USAGE on all security integrations to DATA_ENGINEER."
$$;