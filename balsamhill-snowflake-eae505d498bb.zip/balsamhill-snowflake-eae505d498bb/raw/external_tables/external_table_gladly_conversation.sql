USE DATABASE dev;
USE SCHEMA raw;

CREATE OR REPLACE EXTERNAL TABLE raw.external_table_gladly_conversation (
    id                              STRING AS (value:id::STRING),
    conversation_id                 STRING AS (value:conversationId::STRING),
    content_type                    STRING AS (value:content:type::STRING),
    content_to                      STRING AS (value:content:to::STRING),
    content_from                    STRING AS (value:content:from::STRING),
    content_subject                 STRING AS (value:content:subject::STRING),
    content_content                 STRING AS (value:content:content::STRING),
    content_body                    STRING AS (value:content:body::STRING),
    content_status                  STRING AS (value:content:status::STRING),
    content_started_at              STRING AS (value:content:startedAt::STRING),
    content_answered_at             STRING AS (value:content:answeredAt::STRING),
    content_completed_at            STRING AS (value:content:completedAt::STRING),
    content_recording_URL           STRING AS (value:content:recordingUrl::STRING),
    content_recording_status        STRING AS (value:content:recordingStatus::STRING),
    content_recording_duration      STRING AS (value:content:recordingDuration::STRING),
    content_message_type            STRING AS (value:content:messageType::STRING),
    content_session_id              STRING AS (value:content:sessionId::STRING),
    content_added_topic_ids         STRING AS (value:content:addedTopicIds::STRING),
    customer_id                     STRING AS (value:customerId::STRING),
    initiator_type                  STRING AS (value:initiator:type::STRING),
    initiator_id                    STRING AS (value:initiator:id::STRING),
    timestamp                       TIMESTAMP_NTZ AS (TRY_TO_TIMESTAMP(value:timestamp::STRING, 'YYYY-MM-DD"T"HH24:MI:SS.FF3Z')),
    responder_type                  STRING AS (value:responder:type::STRING),
    responder_id                    STRING AS (value:responder:id::STRING),

    job_id STRING AS (
    REGEXP_REPLACE(REGEXP_SUBSTR(metadata$filename, '[^/]+$', 1, 1), '\\.json$', '')
    ),

    execution_date TIMESTAMP_NTZ AS (
        TRY_TO_TIMESTAMP_NTZ(
                  SPLIT_PART(SPLIT_PART(metadata$filename, '/', 2),'=',2),
                    'YYYY-MM-DD"T"HH24:MI:SS.FF3Z'
        )
    ),

    file_updated_at STRING AS (
    SPLIT_PART(SPLIT_PART(metadata$filename, '/', 3),'=',2)
    )
)
PARTITION BY (execution_date, file_updated_at)
LOCATION = @raw.stage_gladly_conversation
FILE_FORMAT = raw.gladly_json_format
AUTO_REFRESH = FALSE
;