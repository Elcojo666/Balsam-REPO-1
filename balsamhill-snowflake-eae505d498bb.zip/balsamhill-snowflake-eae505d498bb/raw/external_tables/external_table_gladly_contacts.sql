USE DATABASE dev;
USE SCHEMA raw;

CREATE OR REPLACE EXTERNAL TABLE raw.external_table_gladly_contacts (
    timezone_filter                               VARCHAR AS (value:c1::varchar),
    channel_filter                                VARCHAR AS (value:c2::varchar),
    inboxes_filter                                VARCHAR AS (value:c3::varchar),
    queued_at                                     VARCHAR AS (value:c4::varchar),
    customer_id                                   VARCHAR AS (value:c5::varchar),
    conversation_id                               VARCHAR AS (value:c6::varchar),
    contact_id                                    VARCHAR AS (value:c7::varchar),
    conversation_link                             VARCHAR AS (value:c8::varchar),
    channel                                       VARCHAR AS (value:c9::varchar),
    direction                                     VARCHAR AS (value:c10::varchar),
    contact_initiator                             VARCHAR AS (value:c11::varchar),
    entry_point                                   VARCHAR AS (value:c12::varchar),
    final_ivr_selection                           VARCHAR AS (value:c13::varchar),
    fulfilled_type                                VARCHAR AS (value:c14::varchar),
    status                                        VARCHAR AS (value:c15::varchar),
    inbox_when_queued                             VARCHAR AS (value:c16::varchar),
    inbox_when_ended                              VARCHAR AS (value:c17::varchar),
    agent_when_ended                              VARCHAR AS (value:c18::varchar),
    offered_at                                    VARCHAR AS (value:c19::varchar),
    accepted_at                                   VARCHAR AS (value:c20::varchar),
    fulfilled_at                                  VARCHAR AS (value:c21::varchar),
    due_at                                        VARCHAR AS (value:c22::varchar),
    ended_at                                      VARCHAR AS (value:c23::varchar),
    answered_at_outbound                          VARCHAR AS (value:c24::varchar),
    sla_target_sec                                VARCHAR AS (value:c25::varchar),
    queued_to_fulfilled_sec                       VARCHAR AS (value:c26::varchar),
    queued_to_fulfilled_within_business_hours_sec VARCHAR AS (value:c27::varchar),
    queued_to_accepted_sec                        VARCHAR AS (value:c28::varchar),
    queued_to_ended_sec                           VARCHAR AS (value:c29::varchar),
    accepted_to_fulfilled_sec                     VARCHAR AS (value:c30::varchar),
    seconds_within_or_over_sla                    VARCHAR AS (value:c31::varchar),
    fulfilled_to_ended_sec                        VARCHAR AS (value:c32::varchar),
    fulfilled_by_contact_id                       VARCHAR AS (value:c33::varchar),
    contact_handle_time_sec                       VARCHAR AS (value:c34::varchar),
    after_contact_time_sec                        VARCHAR AS (value:c35::varchar),
    total_contact_handle_time_sec                 VARCHAR AS (value:c36::varchar),
    total_talk_time                               VARCHAR AS (value:c37::varchar),
    hold_time_total_sec                           VARCHAR AS (value:c38::varchar),
    hold_time_manual_sec                          VARCHAR AS (value:c39::varchar),
    hold_time_warm_transfer_sec                   VARCHAR AS (value:c40::varchar),
    hold_time_cold_transfer_sec                   VARCHAR AS (value:c41::varchar),
    hold_time_conference_sec                      VARCHAR AS (value:c42::varchar),
    messages_total                                VARCHAR AS (value:c43::varchar),
    messages_from_customer                        VARCHAR AS (value:c44::varchar),
    messages_from_agent                           VARCHAR AS (value:c45::varchar),
    messages_from_rules                           VARCHAR AS (value:c46::varchar),
    messages_from_api                             VARCHAR AS (value:c47::varchar),
    avg_agent_reply_time_sec                      VARCHAR AS (value:c48::varchar),
    avg_customer_reply_time_sec                   VARCHAR AS (value:c49::varchar),
    times_offered                                 VARCHAR AS (value:c50::varchar),
    times_accepted                                VARCHAR AS (value:c51::varchar),
    times_missed                                  VARCHAR AS (value:c52::varchar),
    times_declined                                VARCHAR AS (value:c53::varchar),
    times_transferred                             VARCHAR AS (value:c54::varchar),
    times_on_hold_total                           VARCHAR AS (value:c55::varchar),
    times_on_hold_manual                          VARCHAR AS (value:c56::varchar),
    times_on_hold_warm_transfer                   VARCHAR AS (value:c57::varchar),
    times_on_hold_cold_transfer                   VARCHAR AS (value:c58::varchar),
    times_on_hold_conference                      VARCHAR AS (value:c59::varchar),
    payment_requests_completed                    VARCHAR AS (value:c60::varchar),
    payment_requests_declined                     VARCHAR AS (value:c61::varchar),
    payment_amount_completed_usd                  VARCHAR AS (value:c62::varchar),
    payment_amount_declined_usd                   VARCHAR AS (value:c63::varchar),

    execution_date TIMESTAMP_NTZ AS (
        TRY_TO_TIMESTAMP_NTZ(
            SPLIT_PART(SPLIT_PART(metadata$filename, '/', 2), '=', 2),
            'YYYY-MM-DD"T"HH24:MI:SS.FF5Z'
        )
    ),
    file_updated_at TIMESTAMP_NTZ AS (
        TRY_TO_TIMESTAMP_NTZ(
            SPLIT_PART(SPLIT_PART(metadata$filename, '/', 3), '=', 2),
            'YYYY-MM-DD"T"HH24:MI:SS.FF3Z'
        )
    )
)
PARTITION BY (execution_date, file_updated_at)
LOCATION = @raw.stage_gladly_contacts
FILE_FORMAT = raw.gladly_contacts_csv_format
AUTO_REFRESH = FALSE;