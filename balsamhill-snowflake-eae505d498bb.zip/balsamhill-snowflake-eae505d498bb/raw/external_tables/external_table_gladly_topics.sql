USE DATABASE dev;
USE SCHEMA raw;

CREATE OR REPLACE EXTERNAL TABLE raw.external_table_gladly_topics (
  id                STRING AS (value:id::STRING),
  disabled          STRING AS (value:disabled::STRING),
  name              STRING AS (value:name::STRING),
  job_id            STRING AS (
    REGEXP_REPLACE(REGEXP_SUBSTR(metadata$filename, '[^/]+$', 1, 1), '\\.json$', '')
  ),
  execution_date    TIMESTAMP_NTZ AS (
        TRY_TO_TIMESTAMP_NTZ(
                  SPLIT_PART(SPLIT_PART(metadata$filename, '/', 2),'=',2),
                    'YYYY-MM-DD"T"HH24:MI:SS.FF3Z'
        )
  ),
  file_updated_at   STRING AS (
    SPLIT_PART(SPLIT_PART(metadata$filename, '/', 3),'=',2)
  )
)
PARTITION BY (execution_date, file_updated_at)
LOCATION = @raw.stage_gladly_topics
FILE_FORMAT = raw.gladly_json_format
AUTO_REFRESH = FALSE
;