USE DATABASE BALSAM_EDW_DEV;
USE SCHEMA RAW;

CREATE OR REPLACE STAGE STAGE_PRODUCT_FEED
  URL = 's3://balsambrands-snowpipe-dev/products/'
  STORAGE_INTEGRATION = aws_dev
  FILE_FORMAT = custom_raw_product_csv_format
  ;



