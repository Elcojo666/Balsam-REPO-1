--FILE FORMAT--
CREATE OR REPLACE  FILE FORMAT RAW.RAW_PRICING_MANUAL_FF
	FIELD_DELIMITER = ','
    skip_header = 1
	FIELD_OPTIONALLY_ENCLOSED_BY = '\"'
    NULL_IF = ('NULL', 'null', '')
;



create  or replace pipe RAW.PIPE_raw_hybrischild_price auto_ingest=true error_integration='PROD_SNS_OMS_ORDERS_DATA_PIPELINE_NOTIFICATIONS' as 
COPY INTO RAW.raw_hybrischild_price
 (productcode ,
    productprice ,
    saleprice ,
    price_start_date ,
    price_end_date ,
     currency ,
    new_tag,
    customer_group,
    file_name,
    brand_name
    )
   
FROM (select $1,$2,$3,$4,$5,$6,$7,$8,
metadata$filename,
split_part(split_part(metadata$filename,'/',2),'_',1)
from @RAW.STAGE_PRICING)
FILE_FORMAT = RAW.RAW_PRICING_MANUAL_FF
PATTERN = '.*_ChildStandalone_.*\.csv'

;