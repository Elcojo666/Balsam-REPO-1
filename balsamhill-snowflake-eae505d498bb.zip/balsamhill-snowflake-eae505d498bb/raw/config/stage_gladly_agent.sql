USE DATABASE dev;
USE SCHEMA raw;

CREATE OR REPLACE STAGE raw.stage_gladly_agent
    URL = 's3://balsambrands-gladly-raw-dev/agents/'
    STORAGE_INTEGRATION = aws_dev
    FILE_FORMAT = raw.gladly_json_format;