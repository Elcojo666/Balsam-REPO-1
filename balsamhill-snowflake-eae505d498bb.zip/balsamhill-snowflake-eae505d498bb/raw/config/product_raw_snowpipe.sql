USE DATABASE BALSAM_EDW_DEV;
use SCHEMA RAW;

create or replace pipe PRE_PROD.RAW.PIPE_PRODUCT_CARTON auto_ingest=true error_integration='QA_SNS_OMS_PRODUCT_DATA_PIPELINE_NOTIFICATIONS' as COPY INTO RAW.RAW_PRODUCT_CARTON
(
ID ,
External_Key ,
Language ,
Label,
Child_SKU ,
Parent_Code ,
Year ,
Box_Carton_UPC,
Refurbished_Product ,
Carton_Number,
Carton_Total_Count, 
Carton_Height ,
Carton_Height_unit,
Carton_Length ,
Carton_Length_unit,
Carton_Width ,
Carton_Width_unit,
Carton_Weight ,
Carton_Weight_unit,
Is_Masterpack ,
FedEx_Freight ,
Box_Carton_SKU_Number,
CartonsInfo_ID,
CartonsInfo_ExternalKey,
Sellable_Qty_In_Carton,
Object_Type,
Year_Version,
SAP_NO,
UPC_BUNDLE_ID
) FROM 
(
SELECT $1,
$2,
$3,
$4,
$28, -- Child SKU 
$29, -- Parent Code
$27, -- Year
$9, -- UPC
$24, -- Refurbished
$11, -- Carton Number
$12, -- Carton Total Count
$15, -- Height 
$16, -- H Unit
$17, -- 
$18,
$19,
$20,
$21,
$22, -- Carton W Unit
$23, -- Masterpack 
$13, -- Fedex Freight
$8,
$5,
$6,
$14, -- Qty in Carton 
$26, -- Object Type 
$7, -- Year Version
$25, -- Sap #
$10 -- UPC_BUNDLE_ID
FROM @RAW.STAGE_PRODUCT_FEED
)
FILE_FORMAT = raw.custom_raw_product_csv_format
PATTERN = '.*Carton.*\.csv';

create or replace pipe RAW.PIPE_PRODUCT_PRODUCT auto_ingest=true as COPY INTO PRE_RAW_PRODUCT_PRODUCT 
(
ID, --3
External_Key, -- 1
Language, -- 5
Label, -- 4
Channel_Status, -- 9
Brand, -- 28
Category_Path, -- 29
CategoryPage_PDP_Badge, -- 66
Grid_Layout, -- 82
Grid_Rank, -- 94
Balsam_Hill_Exclusive, -- 107
Print_Catalog, -- 134
Product_Description_Headline, -- 144
Product_Description_Shortened, -- 152
Product_Description, -- 161
OnlineCatalog_Prod_Description, -- 170
PDPContent_Branch_Details, -- 15
FoliageModule_BranchSampleKit, -- 31
PDPContent_Realism, -- 59 
PDPContent_Shape, -- 71
PDPContent_LightGuide, -- 88
PDPContent_ShapingTree, -- 98
PDPContent_TypeOfShapingTree, -- 114
PDPContent_StoringTree, -- 133
PDPContent_TypeOfStoringTree, -- 138
PDPContent_Hyperlink_ViewCount_Weight, -- 143
PDPContent_WhatsInBoxImage, -- 160
PDPContent_WhatsInBoxText, -- 171
PDPContent_WhatsInBox, -- 178
PDPContent_AssemblingTree, -- 184
Needs_LifeSize_LargeFigureVerbiage, -- 234
SEOFollow_RobotsMetaTag, -- 18
SEOIndex_RobotsMetaTag, -- 74
SEO_MetaDescription, -- 89
SEO_Slug, -- 101
SEO_TitleTag, -- 115
Return_Standard, -- 17
Return_Shipping_Method, -- 37
California_Prop65Included, -- 232 
ProductContains_Lead, -- 73
Warranty_PeriodOfTime, --
Tax_WEEE_Eligible, -- 
Energy_Star_Certified, -- 
UL_Certification, -- 
Canadian_Standards_Association, -- 
Government_Compliance, -- 
Warehouse_Return, --
Product_Name, --
Product_Type, -- 
Parent_SKU, --?
SKU, --?
Department, --
Sub_Department, --
Class, --
Item_Type, -- 
Entity_Type, -- 
ProdName_Detailed_Reporting, --
SAP_NUMBER, --
PIM_ID, --
Species_TreeGreenery, --
Light_Color, --
Light_Type, -- 
Type_LightControl, --
Timer, -- 
Outdoor_Safe, --
Level_Realism, --
Foliage_Type, --
Number_SectionsInTree, --
Number_BranchTips, -- 
PottedTree, --
Frosted, -- 
Display_SizeRange, --
Color, -- 
Percent_Material, -- 
PE_Percent_Value, --
PE_Percent_Unit, --
PineNeedle_Percent_Value, --
PineNeedle_Percent_Unit, --
PVCPercent_Value, --
PVCPercent_Unit, --
Raw_Materials, --
Level_Of_Decoration, --
Length_Cord_Inches_Value, --
Length_Cord_Inches_Unit, --
Length_Lit_Length_Value, --
Length_Lit_Length_Unit, --
Assembly_Required, --
Batteries_Included, --
Batteries_Required, -- 
Batteries_Number_Required, --
Batteries_Type_Required, -- 
Number_PairsOfGloves, --
Tools_Included, -- 
FemaleTree_TopperCord, --
Use_Care_Cleaning_Recomdtn, --
Height_ProvidedByVendor, --
Height_Value_Converted_value, --
Height_Value_Converted_unit, --
Height_Display_SiteConverted, --
Height_Override_Display_Site_Convrt_val, --
Height_Override_Display_Site_Convrt_unit, --
Length_ProvidedByVendor, --
Length_Value_Converted_Value, --
Length_Value_Converted_Unit, -- 
Length_Display_Site_Converted, --
Length_Override_Display_Site_Convrt_Val, --
Length_Override_Display_Site_Convrt_unit, -- 
Width_ProvidedByVendor,  -- 
Width_Value_Converted_Value, --
Width_Value_Converted_Unit, -- 
Width_Display_SiteConverted, --
Width_Override_Display_Site_Convrt_val, --
Width_Override_Display_Site_Convrt_unit, --
Diameter_ProvidedByVendor, --
Diameter_Value_Converted_value, --
Diameter_Value_Converted_Unit, --
Diameter_Display_Site_Converted, --
Diameter_Override_Display_Site_Convrt_Val, --
Diameter_Override_Display_Site_Convrt_Unit, --
Weight_ProvidedByVendor, --
Weight_Value_Converted_Value, -- 
Weight_Value_Converted_Unit, --
Weight_Display_Site_Converted, --
Weight_Override_Display_Site_Convrt_Value, --
Weight_Override_Display_Site_Convrt_Unit, --
Attached_Vessel_Color, --
Attached_Vessel_Height_Value, --
Attached_Vessel_Height_Unit, --
Attached_Vessel_Length_Value, --
Attached_Vessel_Length_Unit, --
Attached_Vessel_Width_Value, --
Attached_Vessel_Width_Unit, --
Attache_Vessel_Material, --
Size_Set_Pack, --
Shatter_Resistant, --
Tree_Skirts_Collars_Shape, --
Personalization_Monogram, --
Type_Personalization, --
Scent, --
Scent_Type, -- 
Wick_Wax_Type, -- 
Candle_BurnTime, --
Plays_Music, --
Handcrafted, --
Handpainted, --
Tree_Bag_SKU, --
Number_Tree_Bags, --
Dimensions_Tree_Bag, -- 
Shipping_Method, --
Oversized_Shipping, --
Extended_LeadTimeToShip, --
Freight_Classification, --
Drop_Ship, --
Drop_Ship_Handling_Fee_value, --
Drop_Ship_Handling_Fee_unit, --
RetailPackaging_Available, --
MasterPack_Height_Inches_Value, --
MasterPack_Height_Inches_Unit, --
MasterPack_Length_Inches_Value, --
MasterPack_Length_Lnches_Unit, --
MasterPack_Width_Inches_Value, --
MasterPack_Width_Inches_Unit, --
MasterPack_Weight_Lbs_value, --
MasterPack_Weight_Lbs_unit, --
Customs_Info, --
Duty, --
Duty_Charge_HTC, --
Port_Of_Origin, --
Country_Of_Origin, -- 
Item_Restricted_Contiguous_US, -- 
Standard_Ship_Cost, -- 21 ? only cost? value?
Ship_Cost_2_Day_Value, --
Ship_Cost_2_Day_Unit, -- 
Express_Ship_Cost_Value, --
Express_Ship_Cost_Unit, --
ALHI_Ship_Cost_Value, --
ALHI_Ship_Cost_Unit, --
Canada_Ship_Cost_Value, --
Canada_Ship_Cost_Unit, --
Puerto_Rico_Ship_Cost_Value, --
Puerto_Rico_Ship_Cost_Unit, --
Vendor_ProductName, --
Vendor_PartNumber_SKU, --
Vendor_LightColor, --
Vendor_LightType, --
Light_Count, --
Vendor_Color, --
Cost_First_Product_value, --
Cost_First_Product_unit, --
Cost_Fully_Loaded_Ship_value, --
Cost_Fully_Loaded_Ship_unit, --
Minimum_Order_Quantity, --
Third_Party_LiaisonAgent, --
Vendor_Contact_Name, -- 120 
Vendor_Street_Address, -- 121
Vendor_City, -- 1122
Vendor_State, -- 123
Vendor_Zip_Code, -- 124
Vendor_Country, -- 125
Vendor_ExternalKey, -- 118
Vendor_Label, -- 119
Cart_Page_Items_Tree, -- 149
Addtnl_Categories_Item_AppearIn, -- 40
Tree_Shape, -- 116
Tree_Setup_Type, --
Needle_Type, --
Material, --
Season, --
Holiday, --
Year, --
APPROVED_LOCATIONS_CROSS_BORDER_SHIP, --Check?
RAW_MATERIALS_TYPE, --
Textile_Features, -- 
Design_Type, --
Key_Theme_Design, --
Perishable, --
Shelf_Life, --
Kosher, --
Allergens, --
Ingredients, --
country, -- 
BalsamWebsites_ExternalKey, --
F_ExternalKey, -- check 
F_Label, --
F_FamilyCode, --
F_FamilyDescription, --
F_SEO_FollowRobotsMetaTag, --
F_SEO_HreflangDomain, --
F_SEO_HreflangURL, --
F_SEO_IndexRobotsMetaTag, --
F_SEO_MetaDescription, --
F_SEO_Slug, --
F_SEO_TitleTag, --
F_SEO_CanonicalTag, --
CompatibilityCode, --
AdapterPlug, --
Transformer, --
VoltageType, --
Warranty_Eligibil_Code_Light, --
Warranty_Eligibil_Code_Product, --
Warranty_Eligibil_Code_Foliage, --
Type_Of_Serveware, --
Type_Of_Storage, --
Flavor, -- 199
Shape_Of_Topiary, --
Shape_Of_Decor, --
Candle_Type, --
Light_Design, --
Gifting, --
Size_SML, --
Decorating_Theme, --
Live_On_SiteDate, --
Display_Product_Out_Of_Stock, --
Date_Out_Of_Stock, --
Product_Name_Channel, --
Std_Ship_Cost_Value, --
Std_Ship_Cost_Unit, --
Channel_Approval 
)
FROM
(
SELECT $3 -- ID 
    , $1 -- External Key
    , $5 -- Language
    , $4 -- Label
    , $9 -- Channel Status
    , $28 -- Brand 
    , $29 -- Category Path
    , $66 -- PDP Badge
    , $82 -- Grid Layout
    , $94 -- Grid Rank
    , $107 -- Balsam Hill Exclusive
    , $134 -- Print Catalog
    , $144 -- Product Description Headline
    , $152 -- Product Description Shortened
    , $161 -- Product Description
    , $170 -- Online Catalog
    , $15 -- PDP Content Branch Details
    , $31 -- Foliage Module
    , $59 -- PDP Content Realism
    , $71 -- PDP Content Shape
    , $88 -- PDP Content Light Guide
    , $98 -- PDP Content Shaping Tree
    , $114 -- PDP Content Type of Shaping Tree
    , $133 -- PDP Content Storing Tree
    , $138 -- PDP Content Type of Storing Tree
    , $143 -- PDP Content Hyperlink
    , $160 -- Whats in the Box Image
    , $171 -- Whats in the Box Text
    , $178 -- Whats in the Box on or off
    , $184 -- PDP COntent Assembling your Tree
    , $234 -- Life Size or Large
    , $18 -- SEO_Follow 
    , $74 -- SEO_Index
    , $89 -- MetaDescription
    , $101 -- SEO_Slug
    , $115 -- SEO_Title Tag
    , $17 -- Return Standard
    , $37 -- Return Shipping
    , $232 -- California Prop
    , $73 -- 
    , $126
    , $241
    , $221
    , $224
    , $156
    , $167
    , $179
    , $16
    , $36
    , $87 -- Parent SKU, check (Using Parent Code)
    , $79 -- SKU, check (Using Child SKU)
    , $141
    , $153
    , $157
    , $175
    , $181
    , $188
    , $202
    , $211
    , $102
    , $70
    , $86
    , $117
    , $238
    , $215
    , $69
    , $150
    , $151
    , $243
    , $185
    , $195
    , $190
    , $194
    , $205
    , $251
    , $252
    , $246
    , $247
    , $249
    , $250
    , $226
    , $225
    , $236
    , $237
    , $239
    , $240
    , $155
    , $254
    , $165
    , $172
    , $255
    , $256
    , $253
    , $130
    , $139
    , $14
    , $32
    , $33
    , $58
    , $67
    , $68
    , $84
    , $95
    , $96
    , $113
    , $131
    , $132
    , $140
    , $146
    , $147
    , $154
    , $163
    , $164
    , $166
    , $173
    , $174
    , $180
    , $186
    , $187
    , $193
    , $197
    , $198
    , $203
    , $207
    , $208
    , $209
    , $213
    , $214
    , $216
    , $217
    , $219
    , $220
    , $222
    , $20
    , $218
    , $90
    , $231
    , $136
    , $189
    , $145
    , $162
    , $244
    , $191
    , $200
    , $204
    , $24
    , $34
    , $41
    , $19
    , $35
    , $45
    , $81
    , $93
    , $110
    , $111
    , $135
    , $158
    , $159
    , $168
    , $169
    , $176
    , $177
    , $182
    , $183
    , $13
    , $30
    , $42
    , $72
    , $80
    , $112
    , $21 -- Shipping Cost Value 
    , $26 
    , $27
    , $43
    , $44
    , $63
    , $64
    , $77
    , $78
    , $99
    , $100
    , $25
    , $39
    , $61
    , $76
    , $85
    , $104
    , $108
    , $109
    , $128
    , $129
    , $137
    , $23
    , $120 -- Vendor Contact Name
    , $121 -- Vendor Street
    , $122 -- 
    , $123 --
    , $124 --
    , $125 --
    , $118 --
    , $119 --
    , $149 -- 
    , $40 -- AppearIn
    , $116 -- Tree Shape
    , $257
    , $142
    , $201
    , $229
    , $230 
    , $62
    , $92
    , $223
    , $103
    , $192
    , $196
    , $228
    , $38
    , $210
    , $65
    , $83
    , $2
    , $7
    , $46 -- check
    , $47
    , $48
    , $49
    , $50
    , $51
    , $52
    , $53
    , $54
    , $55
    , $56
    , $57
    , $127
    , $242
    , $245
    , $248
    , $105
    , $106
    , $91
    , $206
    , $212
    , $199 -- Flavor
    , $75
    , $60
    , $148
    , $97
    , $235
    , $227
    , $233
    , $6
    , $10
    , $12
    , $11
    , $21
    , $22
    , $8
FROM @RAW.STAGE_PRODUCT_FEED
)
FILE_FORMAT = custom_raw_product_csv_format
PATTERN = '.*Product.*\.csv';

create or replace pipe RAW.PIPE_PRODUCT_SECTION auto_ingest=true
error_integration='DEV_SNS_OMS_PRODUCT_DATA_PIPELINE_NOTIFICATIONS'
as COPY INTO RAW.RAW_PRODUCT_SECTION
(     ID,
External_Key,
Language,
Label,
Object_Type,
Section_Information_ID,
Section_Information_ExternalKey,
Section_Information_Section_Brand,
Section_Information_Section_Carton_Number,
Section_Information_Section_Description,
Section_Information_Section_Height_value,
Section_Information_Section_Height_unit,
Section_Information_Section_Length_value,
Section_Information_Section_Length_unit,
Section_Information_Section_Manufacturing_Year_Lot_Code,
Section_Information_Section_Quantity_In_Carton,
Section_Information_Section_Total_Cartons,
Section_Information_Section_Weight_value,
Section_Information_Section_Weight_unit,
Section_Information_Section_Width_value,
Section_Information_Section_Width_unit,
Section_Information_SKU_UPC,
Section_Information_Section_SKU,
Section_Information_Section_UPC,
Section_Information_Section_Number,
Year,
Child_SKU,
Parent_Code	 )
FROM 
(SELECT 
 $1 
,$2 
,$3 
,$4 
,$5 
,$6 
,$7 
,$8 
,$9 
,$10 
,$11 
,$12 
,$13 
,$14 
,$15 
,$16 
,$17 
,$18 
,$19 
,$20 
,$21 
,$22 
,$23
,$24
,$25
,$26
,$27
,$28
FROM @RAW.STAGE_PRODUCT_FEED
)
FILE_FORMAT = custom_raw_product_csv_format
PATTERN = '.*Section.*\.csv'
;

create or replace pipe RAW.PIPE_PRODUCT_PARTNER auto_ingest=true
error_integration='DEV_SNS_OMS_PRODUCT_DATA_PIPELINE_NOTIFICATIONS'
as COPY INTO RAW.RAW_PRODUCT_PARTNER
(    ID ,
External_Key ,
Language ,
Balsam_Websites_Channel_Status ,
Balsam_Websites_External_Key ,
Partner_Information_ID ,
Partner_Information_Partner_Name ,
Partner_Information_Partner_SKU ,
Partner_Information_Product_Name_Channel ,
Partner_Information_Partner_Pack,
Partner_Information_UPC_Code ,
Amazon_Product_Name ,
Amazon_Product_Description ,
Amazon_Bullet_1 ,
Amazon_Bullet_2 ,
Amazon_Bullet_3 ,
Child_SKU ,
Parent_Code ,
Amazon_Bullet_4 ,
Amazon_Bullet_5 ,
Channel_Approval 						 )
FROM 
(SELECT 
 $1 
,$2 
,$3 
,$4 
,$5 
,$6 
,$7 
,$8 
,$9 
,$10 
,$11 
,$12 
,$13 
,$14 
,$15 
,$16 
,$17 
,$18 
,$19 
,$20 
,$21 
FROM @RAW.STAGE_PRODUCT_FEED
)
FILE_FORMAT = custom_raw_product_csv_format
PATTERN = '.*Partner.*\.csv'
;




