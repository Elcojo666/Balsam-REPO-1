USE DATABASE DEV;
USE SCHEMA RAW;

CREATE OR REPLACE STAGE raw.stage_badge_report
    URL = 's3://balsambrands-snowpipe-dev/inventory/badge-report/'
    STORAGE_INTEGRATION = aws_dev
    FILE_FORMAT = raw.badge_report_csv_format;