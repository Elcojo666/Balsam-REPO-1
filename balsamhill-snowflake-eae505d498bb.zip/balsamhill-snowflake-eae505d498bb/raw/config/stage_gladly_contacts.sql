USE DATABASE dev;
USE SCHEMA raw;

CREATE OR REPLACE STAGE raw.stage_gladly_contacts
    URL = 's3://balsambrands-gladly-raw-dev/contacts/'
    STORAGE_INTEGRATION = aws_dev
    FILE_FORMAT = raw.gladly_contacts_csv_format;