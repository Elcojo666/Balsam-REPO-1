USE DATABASE DEV;
USE SCHEMA RAW;

CREATE OR REPLACE STAGE raw.stage_gladly_transcript
    URL = 's3://balsambrands-gladly-raw-dev/transcripts/'
    STORAGE_INTEGRATION = aws_dev
    FILE_FORMAT = raw.gladly_json_format;
