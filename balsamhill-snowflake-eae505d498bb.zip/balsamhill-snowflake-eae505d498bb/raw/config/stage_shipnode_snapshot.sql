USE DATABASE dev;
USE SCHEMA raw;

CREATE OR REPLACE STAGE raw.stage_shipnode_snapshot
    URL ='s3://balsambrands-snowpipe-dev/inventory/upc/'
    STORAGE_INTEGRATION = aws_dev
    FILE_FORMAT = raw.shipnode_snapshot_json_format;