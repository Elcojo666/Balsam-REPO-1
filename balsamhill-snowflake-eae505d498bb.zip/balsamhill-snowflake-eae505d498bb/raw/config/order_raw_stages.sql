USE SCHEMA RAW;

CREATE OR REPLACE STAGE STAGE_ORDER_FEED
  URL = 's3://balsambrands-snowpipe-dev/orders/'
  STORAGE_INTEGRATION = aws_pre_prod
  FILE_FORMAT = RAW_ORDER_PARSE_HEADER_FORMAT
;

  show stages;
