USE DATABASE dev;
USE SCHEMA raw;

CREATE OR REPLACE STAGE raw.stage_gladly_topics
    URL = 's3://balsambrands-gladly-raw-dev/topics/'
    STORAGE_INTEGRATION = aws_dev
    FILE_FORMAT = raw.gladly_json_format;
